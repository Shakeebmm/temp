module.exports = {
  LOG_LABEL: "PnP Service",
  LOG_DIRECTORY: "logs",
  LOG_FILE_NAME: "logs-%DATE%.log",
  LOG_FILE_NAME_DATE_PATTERN: "YYYY_MM_DD",
  LOG_IN_CONSOLE_TIMESTAMP_PATTERN: "YYYY-MM-DD HH:mm:ss",
  LOG_FATAL_FAILURE_FILE_NAME: "fatal_failures.log"
};
