const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let MedicineTransfer = new Schema(
  {
    mno: {
      type: String
    },
    name: {
      type: String
    },
    qty: {
      type: Number
    },
    stocktype: {
      type: String
    },
    source: {
      type: String
    },
    transferto: {
      type: String
    }
  },
  {
    collection: "medicineTransfer"
  }
);

module.exports = mongoose.model("medicineTransfer", MedicineTransfer);
