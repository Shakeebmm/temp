var express = require("express");
var router = express.Router();
const logger = require("../utils/logger/logger").getLoggerInstance();

var patientRoute = require("./patient.route");
var volunteerRoute = require("./volunteer.route");
var panjayathRoute = require("./panjayath.route");
var diagnosisRoute = require("./diagnosis.route");
var centerRoute = require("./center.route");
var incomeTypeRoute = require("./incomeType.route");
var expTypeRoute = require("./expType.route");
var accountRoute = require("./account.route");
var medicineRoute = require("./medicine.route");
var loginRoute = require("./login.route");
var dashboardRoute = require("./dashboard.route");
var bankRoute = require("./bank.route");
var cashBalanceRoute = require("./cashBalance.route");
var reportRoute = require("./report.route");
var equipmentRoute = require("./equipment.route");
var ledger = require("./bankLedger.route");
var receipt = require("./receipt.route");

router.use((req, res, next) => {
  logger.log("info", "Called : " + req.path);
  next();
});

router.use(patientRoute);
router.use(volunteerRoute);
router.use(panjayathRoute);
router.use(diagnosisRoute);
router.use(centerRoute);
router.use(incomeTypeRoute);
router.use(expTypeRoute);
router.use(accountRoute);
router.use(medicineRoute);
router.use(loginRoute);
router.use(dashboardRoute);
router.use(bankRoute);
router.use(cashBalanceRoute);
router.use(reportRoute);
router.use(equipmentRoute);
router.use(ledger);
router.use(receipt);

module.exports = router;
