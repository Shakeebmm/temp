const express = require("express");
var Promise = require("promise");
const routes = express.Router();
const moment = require("moment-timezone");

let Patient = require("../database/schemas/patient.model");

function getPno() {
  return new Promise(function(resolve, reject) {
    // Do async job
    Patient.countDocuments(function(err, cnt) {
      var newCnt = ++cnt;
      resolve("P" + newCnt);
    });
  });
}

function getFormattedDate(date) {
  var arr = date.split(" ");
  return arr[2] + "-" + arr[1] + "-" + arr[3];
}

// Defined store route
routes.post("*/patient/add", function(req, res, next) {
  try {
    Patient.findOne({ pno: req.body.pno }, function(err, pat) {
      if (!pat) {
        let patient = new Patient(req.body);
        if (patient.regdate != null && patient.regdate != "") {
          patient.regdate = moment(patient.regdate)
            .tz("Asia/Calcutta")
            .format("YYYY-MM-DD");
        }

        if (patient.expdate != null && patient.expdate != "") {
          patient.expdate = moment(patient.expdate)
            .tz("Asia/Calcutta")
            .format("YYYY-MM-DD");
        }

        if (patient.dropdate != null && patient.dropdate != "") {
          patient.dropdate = moment(patient.dropdate).format("YYYY-MM-DD");
        }

        patient.save().then(res.status(200).send("Success"));
      } else {
        res.status(204).send("Duplicate");
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

// Defined get data(index or listing) route
routes.get("*/patient", function(req, res, next) {
  try {
    Patient.find(
      {
        $or: [{ temp: false }, { temp: undefined }],
        expdate: null,
        dropdate: null
      },
      function(err, patients) {
        if (err) {
          next(new Error(err));
        } else {
          res.status(200).json(patients);
        }
      }
    );
  } catch (err) {
    next(new Error(err));
  }
});

routes.get("*/patient/getNames", function(req, res, next) {
  try {
    Patient.find(
      {
        $or: [{ temp: false }, { temp: undefined }],
        expdate: null,
        dropdate: null
      },
      { _id: 0, name: 1, pno: 1 },
      function(err, patients) {
        if (err) {
          next(new Error(err));
        } else {
          res.status(200).json(patients);
        }
      }
    );
  } catch (err) {
    next(new Error(err));
  }
});

routes.get("*/patient/getAllNames", function(req, res, next) {
  try {
    Patient.find(
      {
        expdate: null,
        dropdate: null
      },
      { _id: 0, name: 1, pno: 1 },
      function(err, patients) {
        if (err) {
          next(new Error(err));
        } else {
          res.status(200).json(patients);
        }
      }
    );
  } catch (err) {
    next(new Error(err));
  }
});

// // Get list count
// routes.route("/count").get(function(req, res) {
//   Patient.countDocuments(function(err, cnt) {
//     if (err) {
//       console.log(err);
//     } else {
//       res.json(cnt + 1);
//     }
//   });
// });

// Defined edit route
routes.get("*/patient/edit/:id", function(req, res) {
  let id = req.params.id;
  Patient.findById(id, function(err, Patient) {
    res.status(200).json(Patient);
  });
});

function UpdatePatient(req, res, objPatient) {
  objPatient.pno = req.body.pno;
  objPatient.name = req.body.name;
  objPatient.age = req.body.age;
  objPatient.address = req.body.address;
  objPatient.grade = req.body.grade;
  objPatient.gender = req.body.gender;
  objPatient.panjayath = req.body.panjayath;
  objPatient.wardno = req.body.wardno;
  objPatient.phone1 = req.body.phone1;
  objPatient.phone2 = req.body.phone2;
  objPatient.volunteer = req.body.volunteer;
  objPatient.diagnosis = req.body.diagnosis;
  objPatient.temp = req.body.temp;

  if (
    req.body.regdate != null &&
    req.body.regdate != "" &&
    req.body.regdate != "1970-01-01T00:00:00.000Z"
  ) {
    objPatient.regdate = moment(req.body.regdate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD");
  }

  if (
    req.body.expdate != null &&
    req.body.expdate != "" &&
    req.body.expdate != "1970-01-01T00:00:00.000Z"
  ) {
    objPatient.expdate = moment(req.body.expdate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD");
  }

  if (
    req.body.dropdate != null &&
    req.body.dropdate != "" &&
    req.body.dropdate != "1970-01-01T00:00:00.000Z"
  ) {
    objPatient.dropdate = moment(req.body.dropdate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD");
  }

  objPatient.save().then(res.status(200).json("Update complete"));
}

//  Defined update route
routes.post("*/patient/update/:id", function(req, res, next) {
  try {
    Patient.findById(req.params.id, function(err, objPatient) {
      if (!objPatient) res.status(404).send("Data not found");
      else {
        Patient.findOne({ pno: req.body.pno }, function(err, pat) {
          if (!pat) {
            UpdatePatient(req, res, objPatient);
          } else {
            if (pat._id == req.params.id) UpdatePatient(req, res, objPatient);
            else res.status(204).send("Duplicate");
          }
        });
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

// Defined delete | remove | destroy route
routes.get("*/patient/delete/:id", function(req, res) {
  Patient.findOneAndDelete({ _id: req.params.id }, function(err, Patient) {
    if (err) res.json(err);
    else res.json("Successfully removed");
  });
});

routes.post("*/patient/detailsReport", function(req, res, next) {
  var fromDate = new Date(
    moment(req.body.fromDate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD")
  );

  var toDate = new Date(
    moment(req.body.toDate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD")
  );

  try {
    if (req.body.type === "Date") {
      Patient.aggregate(
        [
          {
            $match: {
              regdate: {
                $gte: fromDate,
                $lte: toDate
              },
              expdate: {
                $eq: null
              },
              dropdate: {
                $eq: null
              },
              $or: [{ temp: false }, { temp: undefined }]
            }
          },
          { $sort: { name: 1 } }
        ],
        function(err, result) {
          if (err) {
            next(new Error(err));
          } else {
            res.status(200).json(result);
          }
        }
      );
    } else if (req.body.type === "Grade") {
      Patient.aggregate(
        [
          {
            $match: {
              grade: {
                $eq: req.body.gradeFilter
              },
              expdate: {
                $eq: null
              },
              dropdate: {
                $eq: null
              },
              $or: [{ temp: false }, { temp: undefined }]
            }
          },
          { $sort: { name: 1 } }
        ],
        function(err, result) {
          if (err) {
            next(new Error(err));
          } else {
            res.status(200).json(result);
          }
        }
      );
    } else if (req.body.type === "Expired") {
      Patient.aggregate(
        [
          {
            $match: {
              expdate: {
                $ne: null
              },
              dropdate: {
                $eq: null
              },
              $or: [{ temp: false }, { temp: undefined }]
            }
          },
          { $sort: { name: 1 } }
        ],
        function(err, result) {
          if (err) {
            next(new Error(err));
          } else {
            res.status(200).json(result);
          }
        }
      );
    } else if (req.body.type === "Dropout") {
      Patient.aggregate(
        [
          {
            $match: {
              expdate: {
                $eq: null
              },
              dropdate: {
                $ne: null
              },
              $or: [{ temp: false }, { temp: undefined }]
            }
          },
          { $sort: { name: 1 } }
        ],
        function(err, result) {
          if (err) {
            next(new Error(err));
          } else {
            res.status(200).json(result);
          }
        }
      );
    } else if (req.body.type === "Temp") {
      Patient.aggregate(
        [
          {
            $match: {
              temp: true
            }
          },
          { $sort: { name: 1 } }
        ],
        function(err, result) {
          if (err) {
            next(new Error(err));
          } else {
            res.status(200).json(result);
          }
        }
      );
    } else if (req.body.type === "All") {
      Patient.aggregate(
        [
          {
            $match: {
              expdate: {
                $eq: null
              },
              dropdate: {
                $eq: null
              },
              $or: [{ temp: false }, { temp: undefined }]
            }
          },
          { $sort: { name: 1 } }
        ],
        function(err, result) {
          if (err) {
            next(new Error(err));
          } else {
            res.status(200).json(result);
          }
        }
      );
    }
  } catch (err) {
    next(new Error(err));
  }
});

module.exports = routes;
