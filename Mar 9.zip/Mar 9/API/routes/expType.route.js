const express = require("express");
var Promise = require("promise");
const routes = express.Router();
let ExpType = require("../database/schemas/expType.model");

// Defined store route
routes.post("*/expType/add", function(req, res, next) {
  try {
    let expType = new ExpType(req.body);
    expType.save().then(res.status(200).send("Success"));
  } catch (err) {
    next(new Error(err));
  }
});

// Defined get data(index or listing) route
routes.get("*/expType", function(req, res, next) {
  ExpType.find(function(err, expTypes) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(expTypes);
    }
  });
});

routes.get("*/expType/getExpenseTypes", function(req, res, next) {
  try {
    ExpType.find({}, { _id: 0, expType: 1 }, function(err, data) {
      if (err) {
        next(new Error(err));
      } else {
        res.status(200).json(data);
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

// Defined edit route
routes.get("*/expType/edit/:id", function(req, res) {
  let id = req.params.id;
  ExpType.findById(id, function(err, expType) {
    res.status(200).json(expType);
  });
});

//  Defined update route
routes.post("*/expType/update/:id", function(req, res, next) {
  try {
    ExpType.findById(req.params.id, function(err, expType) {
      if (!expType) res.status(404).send("Data not found");
      else {
        expType.expType = req.body.expType;

        expType.save().then(expType => {
          res.status(200).json("Update complete");
        });
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

// Defined delete | remove | destroy route
routes.get("*/expType/delete/:id", function(req, res) {
  ExpType.findOneAndDelete({ _id: req.params.id }, function(err, incomeType) {
    if (err) res.json(err);
    else res.json("Successfully removed");
  });
});

module.exports = routes;
