const express = require("express");
const routes = express.Router();
let Login = require("../database/schemas/login.model");
const crypto = require("../utils/crypto").getCrytoHelperInstance();
const moment = require("moment-timezone");
let Center = require("../database/schemas/center.model");

routes.post("*/login/validate", function(req, res, next) {
  try {
    //encrypt
    //console.log(crypto.encryptField("2030-12-31"));

    // decrypt
    // console.log(
    //   crypto.decryptField(
    //     "bd4031cd4235e35427addb6c28439169be946090eb3a2d5c988b"
    //   )
    // );

    var today = new Date(moment(new Date()).format("YYYY-MM-DD"));

    Center.findOne(function(err, center) {
      var validDate = new Date(crypto.decryptField(center.validTill));
      if (today <= validDate) {
        Login.findOne({ username: req.body.username }, function(err, user) {
          if (!user) {
            res.status(204).send("Data not found");
          } else {
            if (req.body.password === crypto.decryptField(user.pwd)) {
              res.status(200).send("Success");
            } else {
              res.status(204).send("Data not found");
            }
          }
        });
      } else {
        res.status(205).send("Account Expired");
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

module.exports = routes;
