const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let Account = new Schema(
  {
    txndate: {
      type: Date
    },
    desc: {
      type: String
    },
    type: {
      type: String
    },
    amount: {
      type: Number
    },
    txntype: {
      type: String
    },
    name: {
      type: String
    },
    receiptNo: {
      type: String
    },
    isReceipt: {
      type: Boolean
    }
  },
  {
    collection: "account"
  }
);

module.exports = mongoose.model("account", Account);
