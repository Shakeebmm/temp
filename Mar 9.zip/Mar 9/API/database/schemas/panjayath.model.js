const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let Panjayath = new Schema(
  {
    name: {
      type: String
    }
  },
  {
    collection: "panjayath"
  }
);

module.exports = mongoose.model("panjayath", Panjayath);
