const express = require("express");
var Promise = require("promise");
const routes = express.Router();
const logger = require("../utils/logger/logger").getLoggerInstance();

let Patient = require("./patient.model");

function getPno() {
  return new Promise(function(resolve, reject) {
    // Do async job
    Patient.countDocuments(function(err, cnt) {
      var newCnt = ++cnt;
      resolve("P" + newCnt);
    });
  });
}

function getFormattedDate(date) {
  //console.log(date);
  var arr = date.split(" ");
  return arr[2] + "-" + arr[1] + "-" + arr[3];
}

// Defined store route
routes.route("/add").post(function(req, res) {
  try {
    let patient = new Patient(req.body);
    if (patient.regdate != null && patient.regdate != "") {
      patient.regdate = getFormattedDate(
        new Date(patient.regdate).toDateString()
      );
    }
    if (patient.expdate != null && patient.expdate != "") {
      patient.expdate = getFormattedDate(
        new Date(patient.expdate).toDateString()
      );
    }

    patient.save();

    // var getPnoPromise = getPno();
    // getPnoPromise.then(function(res) {
    //   patient.pno = res;
    //   patient.save();
    // });
  } catch (err) {
    res.status(400).send("Error");
  }
});

// Defined get data(index or listing) route
routes.route("/").get(function(req, res) {
  logger.log("info", "Patient -> get");

  try {
    Patient.find(function(err, patients) {
      if (err) {
        console.log(err);
      } else {
        res.json(patients);
      }
    });
  } catch (err) {
    logger.log("error", "Patient -> get : " + err);
    res.status(400).send("Error");
  }
});

// Defined get data(index or listing) route
routes.route("/getNames").get(function(req, res) {
  logger.log("info", "Patient -> getNames");
  try {
    Patient.find({}, { _id: 0, name: 1, pno: 1 }, function(err, patients) {
      if (err) {
        console.log(err);
      } else {
        res.json(patients);
      }
    });
  } catch (err) {
    res.status(400).send("Error");
  }
});

// // Get list count
// routes.route("/count").get(function(req, res) {
//   Patient.countDocuments(function(err, cnt) {
//     if (err) {
//       console.log(err);
//     } else {
//       res.json(cnt + 1);
//     }
//   });
// });

// Defined edit route
routes.route("/edit/:id").get(function(req, res) {
  logger.log("info", "Patient -> edit");
  let id = req.params.id;
  Patient.findById(id, function(err, Patient) {
    res.json(Patient);
  });
});

//  Defined update route
routes.route("/update/:id").post(function(req, res) {
  logger.log("info", "Patient -> update");
  try {
    Patient.findById(req.params.id, function(err, Patient) {
      if (!Patient) res.status(404).send("Data not found");
      else {
        Patient.pno = req.body.pno;
        Patient.name = req.body.name;
        Patient.age = req.body.age;
        Patient.address = req.body.address;
        Patient.grade = req.body.grade;
        Patient.gender = req.body.gender;
        Patient.panjayath = req.body.panjayath;
        Patient.wardno = req.body.wardno;
        Patient.phone1 = req.body.phone1;
        Patient.phone2 = req.body.phone2;
        Patient.volunteer = req.body.volunteer;

        if (
          req.body.regdate != null &&
          req.body.regdate != "" &&
          req.body.regdate != "1970-01-01T00:00:00.000Z"
        ) {
          Patient.regdate = getFormattedDate(
            new Date(req.body.regdate).toDateString()
          );
        }
        if (
          req.body.expdate != null &&
          req.body.expdate != "" &&
          req.body.expdate != "1970-01-01T00:00:00.000Z"
        ) {
          Patient.expdate = getFormattedDate(
            new Date(req.body.expdate).toDateString()
          );
        }

        Patient.save().then(Patient => {
          res.json("Update complete");
        });
        // .catch(err => {
        //   res.status(400).send("Unable to update the database");
        // });
      }
    });
  } catch (err) {
    res.status(400).send("Error");
  }
});

// Defined delete | remove | destroy route
routes.route("/delete/:id").get(function(req, res) {
  Patient.findOneAndDelete({ _id: req.params.id }, function(err, Patient) {
    if (err) res.json(err);
    else res.json("Successfully removed");
  });
});

module.exports = routes;
