const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const cors = require("cors");
//const mongoose = require("mongoose");
require("./DB.js");
const patientRoute = require("./Patient/patient.route");
const volunteerRoute = require("./Volunteer/volunteer.route");
const panjayathRoute = require("./Panjayath/panjayath.route");
const centerRoute = require("./center.route");
const incomeTypeRoute = require("./IncomeType/incomeType.route");
const accountRoute = require("./Account/account.route");
const medicineRoute = require("./Medicine/medicine.route");
const loginRoute = require("./Login/login.route");
const dashboardRoute = require("./Home/dashboard.route");
const logger = require("./utils/logger/logger").getLoggerInstance();

require("dotenv").config();

app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

//app.use("/node/api/patient", patientRoute);

var env = process.env.NODE_ENV || "DEV";
var routePath = "";
if (env === "PROD") routePath = process.env.ROUTE_PATH;

app.use(routePath + "/patient", patientRoute);
app.use(routePath + "/volunteer", volunteerRoute);
app.use(routePath + "/panjayath", panjayathRoute);
app.use(routePath + "/center", centerRoute);
app.use(routePath + "/incomeType", incomeTypeRoute);
app.use(routePath + "/account", accountRoute);
app.use(routePath + "/medicine", medicineRoute);
app.use(routePath + "/login", loginRoute);
app.use(routePath + "/dashboard", dashboardRoute);

app.listen(process.env.PORT, function() {
  //http://localhost/node/api/patient

  console.log("Server is running on Port:", process.env.PORT);
});

//https://gist.github.com/rttomlinson/10c658ea276d3cfc1dc90b391af4c817
