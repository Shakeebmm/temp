const moment = require("moment-timezone");
const express = require("express");
const routes = express.Router();
const logger = require("../utils/logger/logger").getLoggerInstance();
let Account = require("./account.model");

// Defined store route
routes.route("/add").post(function(req, res) {
  logger.log("info", "Account -> add");
  try {
    let account = new Account(req.body);
    var dd = new Date(account.txndate);
    dd = new Date(dd.getUTCFullYear(), dd.getUTCMonth(), dd.getUTCDate() + 2);
    account.txndate = moment(dd)
      .tz("Asia/Calcutta")
      .format();

    account.save();
  } catch (err) {
    logger.log("error", "Account -> add : " + err);
    res.status(400).send("Error");
  }
});

// Defined get data(index or listing) route
routes.route("/").get(function(req, res) {
  logger.log("info", "Account -> get");
  Account.find(function(err, accounts) {
    if (err) {
      console.log(err);
    } else {
      res.json(accounts);
    }
  });
});

// Defined edit route
routes.route("/edit/:id").get(function(req, res) {
  logger.log("info", "Account -> edit");
  let id = req.params.id;
  Account.findById(id, function(err, account) {
    res.json(account);
  });
});

//  Defined update route
routes.route("/update/:id").post(function(req, res) {
  logger.log("info", "Account -> update");
  try {
    Account.findById(req.params.id, function(err, account) {
      if (!account) res.status(404).send("Data not found");
      else {
        //account.txndate = req.body.txndate;
        account.desc = req.body.desc;
        account.type = req.body.type;
        account.amount = req.body.amount;

        account.save().then(account => {
          res.json("Update complete");
        });
        // .catch(err => {
        //   res.status(400).send("Unable to update the database");
        // });
      }
    });
  } catch (err) {
    logger.log("error", "Account -> update : " + err);
    res.status(400).send("Error");
  }
});

// Defined delete | remove | destroy route
routes.route("/delete/:id").get(function(req, res) {
  Account.findOneAndDelete({ _id: req.params.id }, function(err, account) {
    if (err) res.json(err);
    else res.json("Successfully removed");
  });
});

//https://medium.com/@paulrohan/aggregation-in-mongodb-8195c8624337
//https://docs.mongodb.com/manual/reference/operator/aggregation/group/#pipe._S_group
routes.route("/summaryReport").post(function(req, res) {
  logger.log("info", "Account -> summaryReport");

  var fromDate = new Date(
    moment(req.body.fromDate)
      .tz("Asia/Calcutta")
      .format()
  );
  fromDate = new Date(
    fromDate.getUTCFullYear(),
    fromDate.getUTCMonth(),
    fromDate.getUTCDate() + 2
  );

  var toDate = new Date(
    moment(req.body.toDate)
      .tz("Asia/Calcutta")
      .format()
  );
  toDate = new Date(
    toDate.getUTCFullYear(),
    toDate.getUTCMonth(),
    toDate.getUTCDate() + 2
  );

  try {
    if (req.body.type === "Date") {
      Account.aggregate(
        [
          {
            $match: {
              txndate: {
                $gte: fromDate,
                $lte: toDate
              }
            }
          },
          {
            $group: {
              _id: { txntype: "$txntype", txndate: "$txndate" },
              totalAmount: { $sum: "$amount" }
            }
          },
          { $sort: { "_id.txndate": 1 } }
        ],
        function(err, result) {
          if (err) {
            next(err);
          } else {
            res.json(result);
          }
        }
      );
    } else if (req.body.type === "Month") {
      Account.aggregate(
        [
          {
            $match: {
              txndate: {
                $gte: fromDate,
                $lte: toDate
              }
            }
          },
          {
            $group: {
              _id: {
                txntype: "$txntype",
                month: { $month: "$txndate" },
                year: { $year: "$txndate" }
              },
              totalAmount: { $sum: "$amount" }
            }
          },
          { $sort: { "_id.month": 1 } }
        ],
        function(err, result) {
          if (err) {
            next(err);
          } else {
            res.json(result);
          }
        }
      );
    } else if (req.body.type === "Year") {
      Account.aggregate(
        [
          {
            $match: {
              txndate: {
                $gte: fromDate,
                $lte: toDate
              }
            }
          },
          {
            $group: {
              _id: {
                txntype: "$txntype",
                year: { $year: "$txndate" }
              },
              totalAmount: { $sum: "$amount" }
            }
          },
          { $sort: { "_id.year": 1 } }
        ],
        function(err, result) {
          if (err) {
            next(err);
          } else {
            res.json(result);
          }
        }
      );
    }
  } catch (err) {
    logger.log("error", "Account -> summaryReport : " + err);
    res.status(400).send("Error");
  }
});

routes.route("/detailsReport").post(function(req, res) {
  logger.log("info", "Account -> summaryReport");

  var fromDate = new Date(
    moment(req.body.fromDate)
      .tz("Asia/Calcutta")
      .format()
  );
  fromDate = new Date(
    fromDate.getUTCFullYear(),
    fromDate.getUTCMonth(),
    fromDate.getUTCDate() + 2
  );

  var toDate = new Date(
    moment(req.body.toDate)
      .tz("Asia/Calcutta")
      .format()
  );
  toDate = new Date(
    toDate.getUTCFullYear(),
    toDate.getUTCMonth(),
    toDate.getUTCDate() + 2
  );

  try {
    Account.aggregate(
      [
        {
          $match: {
            txndate: {
              $gte: fromDate,
              $lte: toDate
            },
            txntype: {
              $eq: req.body.txnType
            }
          }
        },
        {
          $group: {
            _id: { type: "$type" },
            totalAmount: { $sum: "$amount" }
          }
        },
        { $sort: { "_id.type": 1 } }
      ],
      function(err, result) {
        if (err) {
          next(err);
        } else {
          res.json(result);
        }
      }
    );
  } catch (err) {
    logger.log("error", "Account -> summaryReport : " + err);
    res.status(400).send("Error");
  }
});

module.exports = routes;
