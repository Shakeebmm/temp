const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let balanceEntry = new Schema({
  bankName: {
    type: String
  },
  bno: {
    type: String
  },
  open: {
    type: Number
  },
  close: {
    type: Number
  }
});

let CashBalance = new Schema(
  {
    month: {
      type: Date
    },
    balance: {
      type: [balanceEntry]
    }
  },
  {
    collection: "cashBalance"
  }
);

module.exports = mongoose.model("cashBalance", CashBalance);
