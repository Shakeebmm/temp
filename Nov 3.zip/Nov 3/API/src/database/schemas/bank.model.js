const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let Bank = new Schema(
  {
    bno: {
      type: String
    },
    name: {
      type: String
    }
  },
  {
    collection: "bank"
  }
);

module.exports = mongoose.model("bank", Bank);
