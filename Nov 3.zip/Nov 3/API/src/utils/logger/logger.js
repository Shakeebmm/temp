const { createLogger, format, transports } = require("winston");
require("winston-daily-rotate-file");
const fs = require("fs");
const loggerConstants = require("./loggerConstants");

const loggerHelper = (function() {
  if (!fs.existsSync(loggerConstants.LOG_DIRECTORY)) {
    fs.mkdirSync(loggerConstants.LOG_DIRECTORY);
  }
  let _loggerInstance = null;
  const _dailyRotatingFileTransport = new transports.DailyRotateFile({
    filename: loggerConstants.LOG_FILE_NAME,
    dirname: loggerConstants.LOG_DIRECTORY,
    datePattern: loggerConstants.LOG_FILE_NAME_DATE_PATTERN,
    json: true,
    format: format.combine(
      format.label({ label: loggerConstants.LOG_LABEL }),
      format.timestamp(),
      format.prettyPrint()
    )
  });
  const _winstonLogger = createLogger({
    format: format.combine(
      format.label(loggerConstants.LOG_LABEL),
      format.timestamp({
        format: loggerConstants.LOG_IN_CONSOLE_TIMESTAMP_PATTERN
      }),
      format.printf(info => `${info.timestamp} ${info.level} ${info.message}`)
    ),
    transports: [new transports.Console(), _dailyRotatingFileTransport],
    exceptionHandlers: [
      new transports.File({
        filename: loggerConstants.LOG_FATAL_FAILURE_FILE_NAME,
        dirname: loggerConstants.LOG_DIRECTORY
      })
    ],
    exitOnError: false
  });
  const _createLoggerInstance = () => {
    return {
      log: (level, message) => {
        setTimeout(() => {
          _winstonLogger.log(level, message);
        }, 100);
      }
    };
  };
  return {
    getLoggerInstance: () => {
      if (_loggerInstance == null) {
        _loggerInstance = _createLoggerInstance();
      }
      return _loggerInstance;
    }
  };
})();

module.exports = loggerHelper;
