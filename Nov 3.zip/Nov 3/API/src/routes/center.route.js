const express = require("express");
const centerRoutes = express.Router();
const logger = require("../utils/logger/logger").getLoggerInstance();
let Center = require("../database/schemas/center.model");

// Defined edit route
centerRoutes.route("/getName").get(function(req, res, next) {
  logger.log("info", "Center -> getName");
  try {
    Center.findOne(function(err, center) {
      res.json(center.name);
    });
  } catch (err) {
    next(new Error(err));
  }
});

centerRoutes.route("/edit").get(function(req, res, next) {
  logger.log("info", "Center -> edit");
  try {
    Center.findOne(function(err, center) {
      res.json(center);
    });
  } catch (err) {
    next(new Error(err));
  }
});

//  Defined update route
centerRoutes.route("/update/:id").post(function(req, res, next) {
  logger.log("info", "Center -> update");
  try {
    Center.findById(req.params.id, function(err, center) {
      if (!center) res.status(404).send("data is not found");
      else {
        center.name = req.body.name;
        center.desc = req.body.desc;
        center.location = req.body.location;
        center.regno = req.body.regno;
        center.address = req.body.address;
        center.phone = req.body.phone;

        center.save().then(center => {
          res.json("Update complete");
        });
        // .catch(err => {
        //   res.status(400).send("unable to update the database");
        // });
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

module.exports = centerRoutes;
