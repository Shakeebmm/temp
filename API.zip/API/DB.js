const mongoose = require("mongoose");
require("dotenv").config();
const logger = require("./utils/logger/logger").getLoggerInstance();
const crypto = require("./utils/crypto").getCrytoHelperInstance();

//logger.log("info", "DB..");

var env = process.env.NODE_ENV || "DEV";
var config = require("./utils/config_mongo.json")[env];

let connString =
  "mongodb://" +
  config.MONGO_USER +
  ":" +
  crypto.decryptDB(config.MONGO_PASSWORD) +
  "@" +
  config.MONGO_SERVER;

mongoose.Promise = global.Promise;
mongoose.connect(connString, { useNewUrlParser: true }).then(
  () => {
    console.log("Database is connected..");
  },
  err => {
    console.log("Can not connect to the database" + err);
  }
);
