const express = require("express");
const routes = express.Router();
const logger = require("../utils/logger/logger").getLoggerInstance();
let Medicine = require("../Medicine/medicine.model");
let Patient = require("../Patient/patient.model");

routes.route("/").get(function(req, res) {
  logger.log("info", "Dashboard -> get");
  try {
    let resultObj;

    // Get Stock
    Medicine.aggregate(
      [
        {
          $group: {
            _id: null,
            main: { $sum: "$stock.main" },
            sub: { $sum: "$stock.sub" },
            a_kit: { $sum: "$stock.a_kit" },
            b_kit: { $sum: "$stock.b_kit" }
          }
        }
      ],
      function(err, result) {
        if (err) {
          next(err);
        } else {
          resultObj = {
            stock: result
          };
          // console.log("1");
          // console.log(resultObj);
          // Get Grade
          Patient.aggregate(
            [
              {
                $group: {
                  _id: "$grade",
                  total: { $sum: 1 }
                }
              }
            ],
            function(err, resultGrade) {
              if (err) {
                next(err);
              } else {
                resultObj.grade = resultGrade;
                res.json(resultObj);
              }
            }
          );
        }
      }
    );
  } catch (err) {
    logger.log("error", "Account -> summaryReport : " + err);
    res.status(400).send("Error");
  }
});

module.exports = routes;
