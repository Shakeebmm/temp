const moment = require("moment-timezone");
const express = require("express");
const routes = express.Router();
let Account = require("../database/schemas/account.model");
let Center = require("../database/schemas/center.model");
let Bank = require("../database/schemas/bank.model");

// Defined store route
routes.post("*/account/add", function(req, res, next) {
  try {
    let account = new Account(req.body);
    account.txndate = moment(account.txndate).format("YYYY-MM-DD");

    account.chdate =
      account.chdate !== null
        ? moment(account.chdate).format("YYYY-MM-DD")
        : null;

    if (account.bankMode === "Cheque") {
      account.chAmount = account.amount;
      account.amount = 0;
    }

    if (account.isReceipt) {
      Center.findOne(function(err, center) {
        account.receiptNo = center.receiptNo;

        center.receiptNo++;
        center.save();
        account.save();
      });
    } else {
      account.save();
    }

    res.status(200).send(account._id);
  } catch (err) {
    next(new Error(err));
  }
});

routes.post("*/account", function(req, res, next) {
  var fromDate = new Date(
    moment(req.body.fromDate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD")
  );

  var toDate = new Date(
    moment(req.body.toDate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD")
  );

  Account.find(
    {
      $or: [{ txntype: "Income" }, { txntype: "Expense" }],
      txndate: { $gte: fromDate, $lte: toDate },
      amount: { $ne: 0 }
    },
    function(err, accounts) {
      if (err) {
        next(new Error(err));
      } else {
        res.status(200).json(accounts);
      }
    }
  );
});

routes.get("*/account/getCheques", function(req, res, next) {
  Account.find(
    {
      bankMode: "Cheque",
      amount: 0
    },
    function(err, accounts) {
      if (err) {
        next(new Error(err));
      } else {
        res.status(200).json(accounts);
      }
    }
  );
});

routes.post("*/account/receipts", function(req, res, next) {
  var fromDate = new Date(moment(req.body.fromDate).format("YYYY-MM-DD"));

  var toDate = new Date(moment(req.body.toDate).format("YYYY-MM-DD"));

  Account.find(
    {
      $or: [{ txntype: "Income" }, { txntype: "Expense" }],
      txndate: { $gte: fromDate, $lte: toDate },
      isReceipt: true
    },
    function(err, accounts) {
      if (err) {
        next(new Error(err));
      } else {
        res.status(200).json(accounts);
      }
    }
  );
});

// Defined edit route
routes.get("*/account/edit/:id", function(req, res) {
  let id = req.params.id;
  Account.findById(id, function(err, account) {
    res.status(200).json(account);
  });
});

//  Defined update route
routes.post("*/account/update/:id", function(req, res, next) {
  try {
    Account.findById(req.params.id, function(err, account) {
      if (!account) res.status(404).send("Data not found");
      else {
        account.desc = req.body.desc;
        account.type = req.body.type;
        account.amount = req.body.amount;
        account.name = req.body.name;
        account.isReceipt = req.body.isReceipt;

        account.paymentMode = req.body.paymentMode;
        account.bankMode = req.body.bankMode;
        account.bankName = req.body.bankName;
        account.txnNo = req.body.txnNo;
        account.chNo = req.body.chNo;
        account.chBank = req.body.chBank;
        account.chdate =
          req.body.chdate !== null && req.body.chdate !== ""
            ? moment(req.body.chdate).format("YYYY-MM-DD")
            : null;

        account.save().then(account => {
          res.status(200).json("Update complete");
        });
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

// Defined delete | remove | destroy route
routes.get("*/account/delete/:id", function(req, res) {
  Account.findOneAndDelete({ _id: req.params.id }, function(err, account) {
    if (err) res.json(err);
    else res.json("Successfully removed");
  });
});

//https://medium.com/@paulrohan/aggregation-in-mongodb-8195c8624337
//https://docs.mongodb.com/manual/reference/operator/aggregation/group/#pipe._S_group
routes.post("*/account/summaryReport", function(req, res, next) {
  var fromDate = new Date(
    moment(req.body.fromDate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD")
  );

  var toDate = new Date(
    moment(req.body.toDate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD")
  );

  try {
    if (req.body.type === "Date") {
      Account.aggregate(
        [
          {
            $match: {
              txndate: {
                $gte: fromDate,
                $lte: toDate
              }
            }
          },
          {
            $group: {
              _id: { txntype: "$txntype", txndate: "$txndate" },
              totalAmount: { $sum: "$amount" }
            }
          },
          { $sort: { "_id.txndate": 1 } }
        ],
        function(err, result) {
          if (err) {
            next(new Error(err));
          } else {
            res.json(result);
          }
        }
      );
    } else if (req.body.type === "Month") {
      Account.aggregate(
        [
          {
            $match: {
              txndate: {
                $gte: fromDate,
                $lte: toDate
              }
            }
          },
          {
            $group: {
              _id: {
                txntype: "$txntype",
                month: { $month: "$txndate" },
                year: { $year: "$txndate" }
              },
              totalAmount: { $sum: "$amount" }
            }
          },
          { $sort: { "_id.month": 1 } }
        ],
        function(err, result) {
          if (err) {
            next(new Error(err));
          } else {
            res.json(result);
          }
        }
      );
    } else if (req.body.type === "Year") {
      Account.aggregate(
        [
          {
            $match: {
              txndate: {
                $gte: fromDate,
                $lte: toDate
              }
            }
          },
          {
            $group: {
              _id: {
                txntype: "$txntype",
                year: { $year: "$txndate" }
              },
              totalAmount: { $sum: "$amount" }
            }
          },
          { $sort: { "_id.year": 1 } }
        ],
        function(err, result) {
          if (err) {
            next(new Error(err));
          } else {
            res.status(200).json(result);
          }
        }
      );
    }
  } catch (err) {
    next(new Error(err));
  }
});

routes.post("*/account/detailsReport", function(req, res, next) {
  var report = { data: "", totalAmount: 0 };

  var fromDate = new Date(
    moment(req.body.fromDate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD")
  );

  var toDate = new Date(
    moment(req.body.toDate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD")
  );

  try {
    Account.aggregate(
      [
        {
          $match: {
            txndate: {
              $gte: fromDate,
              $lte: toDate
            },
            txntype: {
              $eq: req.body.txnType
            },
            amount: { $ne: 0 }
          }
        },
        {
          $group: {
            _id: { type: "$type", txntype: "$txntype" },
            totalAmount: { $sum: "$amount" }
          }
        },
        { $sort: { "_id.type": 1 } }
      ],
      function(err, result) {
        if (err) {
          next(new Error(err));
        } else {
          report.data = result;

          var total = 0;
          result.forEach(function(obj) {
            total += obj.totalAmount;
          });
          report.totalAmount = total;

          res.status(200).json(report);
        }
      }
    );
  } catch (err) {
    next(new Error(err));
  }
});

routes.post("*/account/receiptDetails", function(req, res, next) {
  try {
    console.log(req.body);
    if (req.body.count === 1) {
      Account.findById(req.body.ids, function(err, receipt) {
        if (!receipt) res.status(404).send("Data not found");
        else {
          res.status(200).json(receipt);
        }
      });
    } else {
      Account.find(
        { _id: { $in: req.body.ids.split(",") }, isReceipt: true },
        function(err, receipt) {
          if (!receipt) res.status(404).send("Data not found");
          else {
            res.status(200).json(receipt);
          }
        }
      );
    }
  } catch (err) {
    next(new Error(err));
  }
});

routes.post("*/account/daybookLedger", function(req, res, next) {
  try {
    var fromDate = new Date(moment(req.body.fromDate).format("YYYY-MM-DD"));
    var retData = { totalIncome: 0, totalExp: 0, ledger: [] };
    var totalIncome = 0,
      totalExp = 0;

    Account.find(
      { txndate: fromDate, amount: { $ne: 0 } },
      null,
      { sort: { type: 1 } },
      function(err, ledger) {
        if (err) {
          next(new Error(err));
        } else {
          ledger.forEach(function(x) {
            let op = {
              type: x.type,
              txntype: x.txntype,
              amount: x.amount,
              bankName: x.bankName,
              _id: x._id
            };

            if (x.txntype === "Income") totalIncome += x.amount;
            else totalExp += x.amount * -1;

            retData.ledger.push(op);
          });
          retData.totalIncome = totalIncome;
          retData.totalExp = totalExp;
          res.status(200).json(retData);
        }
      }
    );
  } catch (err) {
    next(new Error(err));
  }
});

routes.post("*/account/daybookBalance", function(req, res, next) {
  try {
    var fromDate = new Date(moment(req.body.fromDate).format("YYYY-MM-DD"));
    var openingBal;
    var closingBal;

    Account.aggregate(
      [
        {
          $match: {
            txndate: {
              $lt: fromDate
            }
          }
        },
        {
          $group: {
            _id: { bankName: "$bankName" },
            totalAmount: { $sum: "$amount" }
          }
        }
      ],
      function(err, result) {
        if (err) {
          next(new Error(err));
        } else {
          openingBal = result;
          Account.aggregate(
            [
              {
                $match: {
                  txndate: {
                    $lte: fromDate
                  }
                }
              },
              {
                $group: {
                  _id: { bankName: "$bankName" },
                  totalAmount: { $sum: "$amount" }
                }
              }
            ],
            function(err, result) {
              if (err) {
                next(new Error(err));
              } else {
                closingBal = result;
                var retData = [];

                Bank.find(function(err, banks) {
                  banks.forEach(function(bank) {
                    let amount1 = 0,
                      amount2 = 0;

                    let obj1, obj2;

                    if (bank.name === "Cash In Hand") {
                      obj1 = openingBal.filter(b => b._id.bankName === "")[0];
                      obj2 = closingBal.filter(b => b._id.bankName === "")[0];
                    } else {
                      obj1 = openingBal.filter(
                        b => b._id.bankName === bank.name
                      )[0];

                      obj2 = closingBal.filter(
                        b => b._id.bankName === bank.name
                      )[0];
                    }

                    if (obj1 != undefined) amount1 = obj1.totalAmount;
                    if (obj2 != undefined) amount2 = obj2.totalAmount;

                    let op = {
                      bankName: bank.name,
                      openingBal: amount1,
                      closingBal: amount2
                    };

                    retData.push(op);
                  });
                  res.status(200).json(retData);
                });
              }
            }
          );
        }
      }
    );
  } catch (err) {
    next(new Error(err));
  }
});

routes.post("*/account/monthlyBalance", function(req, res, next) {
  var report = { cash: [], openSum: 0, closeSum: 0 };
  try {
    var fromMonth = new Date(moment(req.body.fromDate).format("YYYY-MM-DD"));
    var toMonth = new Date(moment(req.body.toDate).format("YYYY-MM-DD"));

    var openingBal,
      closingBal,
      openSum = 0,
      closeSum = 0;

    Account.aggregate(
      [
        {
          $match: {
            txndate: {
              $lt: fromMonth
            }
          }
        },
        {
          $group: {
            _id: { bankName: "$bankName" },
            totalAmount: { $sum: "$amount" }
          }
        }
      ],
      function(err, result) {
        if (err) {
          next(new Error(err));
        } else {
          openingBal = result;
          Account.aggregate(
            [
              {
                $match: {
                  txndate: {
                    $lte: toMonth
                  }
                }
              },
              {
                $group: {
                  _id: { bankName: "$bankName" },
                  totalAmount: { $sum: "$amount" }
                }
              }
            ],
            function(err, result) {
              if (err) {
                next(new Error(err));
              } else {
                closingBal = result;
                var retData = [];

                Bank.find(function(err, banks) {
                  banks.forEach(function(bank) {
                    let amount1 = 0,
                      amount2 = 0;

                    let obj1, obj2;

                    if (bank.name === "Cash In Hand") {
                      obj1 = openingBal.filter(b => b._id.bankName === "")[0];
                      obj2 = closingBal.filter(b => b._id.bankName === "")[0];
                    } else {
                      obj1 = openingBal.filter(
                        b => b._id.bankName === bank.name
                      )[0];

                      obj2 = closingBal.filter(
                        b => b._id.bankName === bank.name
                      )[0];
                    }

                    if (obj1 != undefined) amount1 = obj1.totalAmount;
                    if (obj2 != undefined) amount2 = obj2.totalAmount;

                    openSum += amount1;
                    closeSum += amount2;

                    let op = {
                      bankName: bank.name,
                      openingBal: amount1,
                      closingBal: amount2
                    };

                    retData.push(op);
                  });
                  report.cash = retData;
                  report.openSum = openSum;
                  report.closeSum = closeSum;
                  res.status(200).json(report);
                });
              }
            }
          );
        }
      }
    );
  } catch (err) {
    next(new Error(err));
  }
});

routes.post("*/account/processCheque", function(req, res, next) {
  try {
    Account.findById(req.body._id, function(err, account) {
      if (!account) res.status(404).send("Data not found");
      else {
        account.amount = account.chAmount;
        account.txndate = moment(new Date()).format("YYYY-MM-DD");

        account.save().then(account => {
          res.status(200).json("Update complete");
        });
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

routes.post("*/account/chequeReport", function(req, res, next) {
  console.log(req.body);
  try {
    var match;
    switch (req.body.status) {
      case "All":
        console.log("1");
        match = {
          bankMode: "Cheque"
        };
        break;
      case "Pending":
        match = {
          bankMode: "Cheque",
          amount: 0
        };
        break;
      case "Cleared":
        match = {
          bankMode: "Cheque",
          amount: {
            $ne: 0
          }
        };
        break;
    }

    Account.find(match, function(err, accounts) {
      if (err) {
        next(new Error(err));
      } else {
        console.log(accounts);

        res.status(200).json(accounts);
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

module.exports = routes;
