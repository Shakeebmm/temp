const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let ExpType = new Schema(
  {
    expType: {
      type: String
    }
  },
  {
    collection: "expType"
  }
);

module.exports = mongoose.model("expType", ExpType);
