const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let Account = new Schema(
  {
    txndate: {
      type: Date
    },
    desc: {
      type: String
    },
    type: {
      type: String
    },
    amount: {
      type: Number
    },
    txntype: {
      type: String
    },
    name: {
      type: String
    },
    receiptNo: {
      type: String
    },
    isReceipt: {
      type: Boolean
    },
    paymentMode: {
      type: String
    },
    bankMode: {
      type: String
    },
    bankName: {
      type: String
    },
    txnNo: {
      type: String
    },
    chNo: {
      type: String
    },
    chdate: {
      type: Date
    },
    chBank: {
      type: String
    },
    chAmount: {
      type: Number
    }
  },
  {
    collection: "account"
  }
);

module.exports = mongoose.model("account", Account);
