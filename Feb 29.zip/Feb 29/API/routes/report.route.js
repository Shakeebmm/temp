const express = require("express");
const routes = express.Router();
let CashBalance = require("../database/schemas/cashBalance.model");
const moment = require("moment-timezone");

routes.post("*/report/monthly", function(req, res, next) {
  try {
    var report = { cash: [], openSum: 0, closeSum: 0 };

    var fromMonth = new Date(moment(req.body.fromDate).format("YYYY-MM-DD"));
    var toMonth = new Date(
      moment(
        new Date(
          moment(req.body.toDate).get("year"),
          moment(req.body.toDate).get("month"),
          1
        )
      ).format("YYYY-MM-DD")
    );

    CashBalance.find(
      { $or: [{ month: fromMonth }, { month: toMonth }] },
      null,
      { sort: { month: 1 } },
      function(err, result) {
        var openSum = 0,
          closeSum = 0;
        if (!result) {
          res.status(200).json("NA");
        } else {
          if (result.length === 1) {
            result[0].balance.forEach(function(obj) {
              openSum += obj.open;
              closeSum += obj.close;
            });
            report.openSum = openSum;
            report.closeSum = closeSum;
            report.cash = result[0].balance;
          } else {
            // Opening
            result[0].balance.forEach(function(obj) {
              openSum += obj.open;
            });
            report.openSum = openSum;

            // Closing
            result[1].balance.forEach(function(obj) {
              closeSum += obj.close;
            });
            report.closeSum = closeSum;

            result[0].balance.forEach(function(bal) {
              var close = 0;
              var objClose = result[1].balance.filter(
                x => x.bno === bal.bno
              )[0];
              if (objClose != undefined) close = objClose.close;

              var op = {
                _id: bal._id,
                bankName: bal.bankName,
                open: bal.open,
                close: close
              };
              report.cash.push(op);
            });
          }
        }
        res.status(200).json(report);
      }
    );
  } catch (err) {
    next(new Error(err));
  }
});

module.exports = routes;
