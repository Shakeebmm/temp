const express = require("express");
var Promise = require("promise");
const routes = express.Router();
let CashBalance = require("../database/schemas/cashBalance.model");
const moment = require("moment-timezone");

// Defined store route
routes.post("*/cashBalance/save", function(req, res, next) {
  try {
    let cash = new CashBalance(req.body);
    cash.month = moment(cash.month).format("YYYY-MM-DD");

    CashBalance.findOne({ month: cash.month }, function(err, balance) {
      if (!balance) {
        cash.save().then(res.status(200).send("Success"));
      } else {
        Object.values(cash.balance).forEach(function(obj) {
          if (obj.bno != undefined) {
            var available = false;
            Object.values(balance.balance).forEach(function(objCash) {
              if (objCash.bno != undefined) {
                if (objCash.bno == obj.bno) {
                  objCash.open = obj.open;
                  objCash.close = obj.close;
                  available = true;
                }
              }
            });
            // Add new bank
            if (!available) {
              balance.balance.push({
                bno: obj.bno,
                bankName: obj.bankName,
                open: obj.open,
                close: obj.close
              });
            }
          }
        });
        balance.save().then(res.status(200).send("Success"));
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

routes.post("*/cashBalance/load", function(req, res, next) {
  try {
    var month = new Date(moment(req.body.month).format("YYYY-MM-DD"));
    CashBalance.findOne({ month: month }, function(err, balance) {
      res.status(200).json(balance);
    });
  } catch (err) {
    next(new Error(err));
  }
});

// Defined get data(index or listing) route
routes.get("*/cashBalance", function(req, res, next) {
  IncomeType.find(function(err, incomeTypes) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(incomeTypes);
    }
  });
});

module.exports = routes;
