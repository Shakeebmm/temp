const express = require("express");
const routes = express.Router();
let Ledger = require("../database/schemas/bankLedger.model");
let Bank = require("../database/schemas/bank.model");
const moment = require("moment-timezone");

routes.post("*/bankLedger/add", function(req, res, next) {
  try {
    let ledger = new Ledger(req.body);
    if (ledger.txnDate != null && ledger.txnDate != "") {
      ledger.txnDate = moment(ledger.txnDate).format("YYYY-MM-DD");
    }

    ledger.save().then(res.status(200).send("Success"));
  } catch (err) {
    next(new Error(err));
  }
});

routes.get("*/bankLedger/:bno", function(req, res, next) {
  Ledger.find({ bno: req.params.bno }, function(err, ledger) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(ledger);
    }
  });
});

routes.get("*/bankLedger/getBalance/:bno", function(req, res, next) {
  Ledger.aggregate(
    [
      {
        $match: {
          bno: {
            $eq: req.params.bno
          }
        }
      },
      {
        $group: {
          _id: null,
          balance: { $sum: "$amount" }
        }
      }
    ],
    function(err, result) {
      if (err) {
        next(new Error(err));
      } else {
        res.json(result);
      }
    }
  );
});

routes.post("*/bankLedger/update/:id", function(req, res, next) {
  try {
    Ledger.findById(req.params.id, function(err, ledger) {
      if (!ledger) res.status(404).send("Data not found");
      else {
        ledger.txnType = req.body.txnType;
        ledger.amount = req.body.amount;
        ledger.save().then(medicine => {
          res.status(200).json("Update completed");
        });
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

routes.post("*/bankLedger/daybookBalance", function(req, res, next) {
  try {
    var fromDate = new Date(moment(req.body.fromDate).format("YYYY-MM-DD"));
    var openingBal;
    var closingBal;

    Ledger.aggregate(
      [
        {
          $match: {
            txnDate: {
              $lt: fromDate
            }
          }
        },
        {
          $group: {
            _id: { bno: "$bno" },
            totalAmount: { $sum: "$amount" }
          }
        }
      ],
      function(err, result) {
        if (err) {
          next(new Error(err));
        } else {
          openingBal = result;
          Ledger.aggregate(
            [
              {
                $match: {
                  txnDate: {
                    $lte: fromDate
                  }
                }
              },
              {
                $group: {
                  _id: { bno: "$bno" },
                  totalAmount: { $sum: "$amount" }
                }
              }
            ],
            function(err, result) {
              if (err) {
                next(new Error(err));
              } else {
                closingBal = result;
                var retData = [];

                Bank.find({ cash: false }, function(err, banks) {
                  banks.forEach(function(bank) {
                    let amount1 = 0,
                      amount2 = 0;

                    let obj1 = openingBal.filter(
                      b => b._id.bno === bank.bno
                    )[0];

                    let obj2 = closingBal.filter(
                      b => b._id.bno === bank.bno
                    )[0];

                    if (obj1 != undefined) amount1 = obj1.totalAmount;
                    if (obj2 != undefined) amount2 = obj2.totalAmount;

                    let op = {
                      bankName: bank.name,
                      openingBal: amount1,
                      closingBal: amount2
                    };

                    retData.push(op);
                  });
                  res.status(200).json(retData);
                });
              }
            }
          );
        }
      }
    );
  } catch (err) {
    next(new Error(err));
  }
});

routes.post("*/bankLedger/daybookLedger", function(req, res, next) {
  try {
    var fromDate = new Date(moment(req.body.fromDate).format("YYYY-MM-DD"));
    var retData = { totalDeposit: 0, totalWithdraw: 0, ledger: [] };
    var totalDeposit = 0,
      totalWithdraw = 0;

    Ledger.find({ txnDate: fromDate }, null, { sort: { bno: 1 } }, function(
      err,
      ledger
    ) {
      if (err) {
        next(new Error(err));
      } else {
        Bank.find({ cash: false }, function(err, banks) {
          ledger.forEach(function(x) {
            let bankName = "";

            let objBank = banks.filter(b => b.bno === x.bno)[0];
            if (objBank != undefined) bankName = objBank.name;

            let op = {
              bankName: bankName,
              txnType: x.txnType,
              amount: x.amount,
              _id: x._id
            };

            if (x.txnType === "Deposit") totalDeposit += x.amount;
            else totalWithdraw += x.amount * -1;

            retData.ledger.push(op);
          });
          retData.totalDeposit = totalDeposit;
          retData.totalWithdraw = totalWithdraw;

          res.status(200).json(retData);
        });
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

module.exports = routes;
