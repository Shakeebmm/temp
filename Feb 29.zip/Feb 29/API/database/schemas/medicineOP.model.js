const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let MedicineOP = new Schema(
  {
    mno: {
      type: String
    },
    medicinename: {
      type: String
    },
    qty: {
      type: Number
    },
    pno: {
      type: String
    },
    patientname: {
      type: String
    },
    updatedon: {
      type: Date
    }
  },
  {
    collection: "medicineOP"
  }
);

module.exports = mongoose.model("medicineOP", MedicineOP);
