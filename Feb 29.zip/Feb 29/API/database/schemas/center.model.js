const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let Center = new Schema(
  {
    name: {
      type: String
    },
    desc: {
      type: String
    },
    location: {
      type: String
    },
    regno: {
      type: String
    },
    address: {
      type: String
    },
    phone: {
      type: String
    },
    nameMal: {
      type: String
    },
    descMal: {
      type: String
    },
    locationMal: {
      type: String
    },
    addressMal: {
      type: String
    },
    receiptNo: {
      type: Number
    },
    medExpiryDays: {
      type: Number
    },
    medThresholdCount: {
      type: Number
    }
  },
  {
    collection: "centerDetails"
  }
);

module.exports = mongoose.model("centerDetails", Center);
