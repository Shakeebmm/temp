const express = require("express");
const routes = express.Router();
let Equipment = require("../database/schemas/equipment.model");
const moment = require("moment-timezone");

function getEno() {
  return new Promise(function(resolve, reject) {
    Equipment.countDocuments(function(err, cnt) {
      var newCnt = ++cnt;
      resolve("E" + newCnt);
    });
  });
}

// Defined store route
routes.post("*/equipment/add", function(req, res, next) {
  try {
    let eq = new Equipment(req.body);
    Equipment.findOne({ name_lower: eq.name.toLowerCase() }, function(
      err,
      equipment
    ) {
      if (!equipment) {
        // Add new equipment
        var getEnoPromise = getEno();
        getEnoPromise.then(function(res) {
          eq.eno = res;
          eq.name_lower = eq.name.toLowerCase();

          eq.save();
        });
      } else {
        //Update equipment
        equipment.stock.inuse = parseInt(req.body.stock.inuse);
        equipment.stock.damage = parseInt(req.body.stock.damage);
        equipment.stock.stock = parseInt(req.body.stock.stock);
        equipment.save();
      }
    });
    res.status(200).json("Equipment added");
  } catch (err) {
    next(new Error(err));
  }
});

// Defined get data(index or listing) route
routes.get("*/equipment", function(req, res, next) {
  Equipment.find({}, null, { sort: { name: 1 } }, function(err, equipments) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(equipments);
    }
  });
});

// Defined edit route
routes.get("*/equipment/edit/:id", function(req, res) {
  let id = req.params.id;
  Equipment.findById(id, function(err, equipment) {
    res.status(200).json(equipment);
  });
});

//  Defined update route
routes.post("*/equipment/update/:id", function(req, res, next) {
  try {
    Equipment.findById(req.params.id, function(err, equipment) {
      if (!equipment) res.status(404).send("Data not found");
      else {
        equipment.name = req.body.name;
        equipment.name_lower = equipment.name.toLowerCase();
        equipment.stock.inuse = req.body.stock.inuse;
        equipment.stock.stock = req.body.stock.stock;
        equipment.stock.damage = req.body.stock.damage;
        equipment.save();
      }
    });
    res.status(200).json("Update completed");
  } catch (err) {
    next(new Error(err));
  }
});

routes.get("*/equipment/getNames", function(req, res, next) {
  Equipment.find({}, { _id: 0, eno: 1, name: 1 }, function(err, equipments) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(equipments);
    }
  });
});

routes.get("*/equipment/getStock/:eno", function(req, res, next) {
  Equipment.findOne({ eno: req.params.eno }, { _id: 0, stock: 1 }, function(
    err,
    stock
  ) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(stock);
    }
  });
});

routes.get("*/equipment/tracker/:eno", function(req, res, next) {
  Equipment.findOne({ eno: req.params.eno }, {}, function(err, eq) {
    if (err) {
      next(new Error(err));
    } else {
      var result = eq.tracker.filter(obj => obj.indate === null);
      res.status(200).json(result);
    }
  });
});

routes.post("*/equipment/transfer", function(req, res, next) {
  try {
    Equipment.findOne({ eno: req.body.eno }, function(err, equipment) {
      if (!equipment) res.status(404).send("Data not found");
      else {
        equipment.stock.stock =
          parseInt(equipment.stock.stock) - parseInt(req.body.qty);
        equipment.stock.inuse =
          parseInt(equipment.stock.inuse) + parseInt(req.body.qty);

        const objTracker = {
          patientname: req.body.patientname,
          qty: req.body.qty,
          outdate: req.body.outdate,
          indate: null
        };

        objTracker.outdate = moment(objTracker.outdate).format("YYYY-MM-DD");
        equipment.tracker.push(objTracker);
        equipment.save();
      }
    });

    res.status(200).json("Equipment Transferred");
  } catch (err) {
    next(new Error(err));
  }
});

routes.post("*/equipment/return", function(req, res, next) {
  try {
    Equipment.findOne({ eno: req.body.eno }, function(err, eq) {
      eq.stock.stock = parseInt(eq.stock.stock) + parseInt(req.body.qty);
      eq.stock.inuse = parseInt(eq.stock.inuse) - parseInt(req.body.qty);

      eq.tracker.forEach(function(obj) {
        if (obj._id == req.body._id) {
          obj.indate = req.body.indate;
          obj.indate = moment(obj.indate).format("YYYY-MM-DD");
          eq.save();
        }
      });
    });

    res.status(200).json("Equipment Returned");
  } catch (err) {
    next(new Error(err));
  }
});

routes.post("*/equipment/report", function(req, res, next) {
  var ret = [];
  if (req.body.eno === "") {
    Equipment.find({}, null, { sort: { name: 1 } }, function(err, eq) {
      if (err) {
        next(new Error(err));
      } else {
        res.status(200).json(eq);
      }
    });
  } else {
    Equipment.findOne({ eno: req.body.eno }, function(err, eq) {
      if (err) {
        next(new Error(err));
      } else {
        ret.push(eq);
        res.status(200).json(ret);
      }
    });
  }
});

module.exports = routes;
