const express = require("express");
const routes = express.Router();
let Medicine = require("../database/schemas/medicine.model");
let MedicineNew = require("../database/schemas/medicineNew.model");
//let MedicineHistory = require("../database/schemas/medicineHistory.model");
//let Transfer = require("../database/schemas/medicineTransfer.model");
let OP = require("../database/schemas/medicineOP.model");
const moment = require("moment-timezone");
let Center = require("../database/schemas/center.model");

function getMno() {
  return new Promise(function(resolve, reject) {
    Medicine.countDocuments(function(err, cnt) {
      var newCnt = ++cnt;
      resolve("M" + newCnt);
    });
  });
}

// function getHistoryId() {
//   return new Promise(function(resolve, reject) {
//     MedicineHistory.countDocuments(function(err, cnt) {
//       resolve(++cnt);
//     });
//   });
// }

// function saveHistory(his) {
//   //Save history
//   let history = new MedicineHistory();
//   var getHistoryPromise = getHistoryId();
//   getHistoryPromise.then(function(resid) {
//     history.id = resid;
//     history.mno = his.mno;
//     history.qty = his.qty;
//     history.stock = his.stock;
//     history.source = his.source;
//     history.transferto = his.transferto;
//     history.stocktype = his.stocktype;
//     history.updatedon = new Date();
//     history.name = his.name;
//     history.save();
//   });
// }

// Defined store route
routes.post("*/medicine/add", function(req, res, next) {
  try {
    let medicineParam = new Medicine(req.body);

    Medicine.findOne({ name_lower: medicineParam.name.toLowerCase() }, function(
      err,
      medicine
    ) {
      if (!medicine) {
        // Add new medicine
        var getMnoPromise = getMno();
        getMnoPromise.then(function(result) {
          medicineParam.mno = result;
          medicineParam.name_lower = medicineParam.name.toLowerCase();

          medicineParam.purchase[0].invdate =
            medicineParam.purchase[0].invdate !== null
              ? moment(medicineParam.purchase[0].invdate).format("YYYY-MM-DD")
              : null;

          medicineParam.purchase[0].expdate =
            medicineParam.purchase[0].expdate !== null
              ? moment(medicineParam.purchase[0].expdate).format("YYYY-MM-DD")
              : null;

          medicineParam.purchase[0].mfgdate =
            medicineParam.purchase[0].mfgdate !== null
              ? moment(medicineParam.purchase[0].mfgdate).format("YYYY-MM-DD")
              : null;

          medicineParam.save();
          res.status(200).json("Medicine Added !!");
          // //Save history
          // const his = {
          //   mno: medicineParam.mno,
          //   qty: medicineParam.stock.main,
          //   stock: medicineParam.stock.main,
          //   source: "Add",
          //   transferto: "",
          //   stocktype: "Main Stock",
          //   name: medicineParam.name
          // };
          // saveHistory(his);
        });
      } else {
        res.status(200).json("Duplicate Medicine !!");
        // Update medicine
        // medicine.stock.main =
        //   parseInt(medicine.stock.main) + parseInt(req.body.stock.main);
        // medicine.save();
        //.then(medicine => {
        //   //Save history
        //   const his = {
        //     mno: medicine.mno,
        //     qty: req.body.stock.main,
        //     stock: medicine.stock.main,
        //     source: "Edit",
        //     transferto: "",
        //     stocktype: "Main Stock",
        //     name: medicine.name
        //   };
        //   saveHistory(his);
        // });
      }
    });
    // res.status(200).json("Medicine added");
  } catch (err) {
    next(new Error(err));
  }
});

// Defined get data(index or listing) route
routes.get("*/medicine", function(req, res, next) {
  Medicine.find({}, null, { sort: { name: 1 } }, function(err, medicines) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(medicines);
    }
  });
});

// Defined edit route
routes.get("*/medicine/edit/:id", function(req, res) {
  let id = req.params.id;
  Medicine.findById(id, function(err, medicine) {
    res.status(200).json(medicine);
  });
});

//  Defined update route
routes.post("*/medicine/update/:id", function(req, res, next) {
  try {
    Medicine.findById(req.params.id, function(err, medicine) {
      if (!medicine) res.status(404).send("Data not found");
      else {
        medicine.name = req.body.name;
        medicine.name_lower = medicine.name.toLowerCase();
        // medicine.stock.main = req.body.stock.main;
        // medicine.stock.sub = req.body.stock.sub;
        // medicine.stock.a_kit = req.body.stock.a_kit;
        // medicine.stock.b_kit = req.body.stock.b_kit;

        medicine.save().then(medicine => {
          res.status(200).json("Update completed");
        });
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

// Defined delete | remove | destroy route
routes.get("*/medicine/delete/:id", function(req, res) {
  Medicine.findOneAndDelete({ _id: req.params.id }, function(err, medicine) {
    if (err) res.json(err);
    else res.json("Successfully removed");
  });
});

routes.get("*/medicine/getNames", function(req, res, next) {
  Medicine.find({}, { _id: 0, mno: 1, name: 1 }, function(err, medicines) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(medicines);
    }
  });
});

routes.get("*/medicine/getStock/:mno", function(req, res, next) {
  Medicine.findOne({ mno: req.params.mno }, { _id: 0, stock: 1 }, function(
    err,
    stock
  ) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(stock);
    }
  });
});

routes.get("*/medicine/getDetails/:mno", function(req, res, next) {
  Medicine.findOne({ mno: req.params.mno }, function(err, stock) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(stock);
    }
  });
});

routes.get("*/medicine/getPurchaseDetails/:mno", function(req, res, next) {
  Medicine.findOne({ mno: req.params.mno }, {}, function(err, med) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(med);
    }
  });
});

// Transfer main stock
routes.post("*/medicine/transfer", function(req, res, next) {
  try {
    if (req.body.stocktype === "Sub Stock") {
      saveTransferSubStock(req, res);
    } else {
      saveTransfer(req, res);
    }
    res.status(200).json("Medicine Transferred");
  } catch (err) {
    next(new Error(err));
  }
});

// Transfer from Main to Sub
function saveTransfer(req, res) {
  Medicine.findOne({ mno: req.body.mno }, function(err, medicine) {
    if (!medicine) res.status(404).send("Data not found");
    else {
      let qty = parseInt(req.body.qty);

      medicine.stock.main = parseInt(medicine.stock.main) - qty;
      medicine.stock.sub = parseInt(medicine.stock.sub) + qty;

      medicine.purchase
        .filter(x => x.mainStock > 0 && x.expdate != null)
        .sort((a, b) => a.expdate - b.expdate)
        .forEach(function(pur) {
          if (qty > 0) {
            if (pur.mainStock <= qty) {
              pur.subStock += pur.mainStock;
              qty -= pur.mainStock;
              pur.mainStock = 0;
            } else {
              pur.subStock += qty;
              pur.mainStock -= qty;
              qty = 0;
            }
            pur.save({ suppressWarning: true });
          }
        });

      medicine.save();
    }
  });
}

// Transfer from Sub to Kit
function saveTransferSubStock(req, res) {
  Medicine.findOne({ mno: req.body.mno }, function(err, medicine) {
    if (!medicine) res.status(404).send("Data not found");
    else {
      let qty = parseInt(req.body.qty);

      medicine.stock.sub = parseInt(medicine.stock.sub) - qty;

      if (req.body.transferto === "A Kit") {
        medicine.stock.a_kit =
          (isNaN(parseInt(medicine.stock.a_kit))
            ? 0
            : parseInt(medicine.stock.a_kit)) + parseInt(req.body.qty);
      } else if (req.body.transferto === "B Kit") {
        medicine.stock.b_kit =
          (isNaN(parseInt(medicine.stock.b_kit))
            ? 0
            : parseInt(medicine.stock.b_kit)) + parseInt(req.body.qty);
      }

      medicine.purchase
        .filter(x => x.subStock > 0 && x.expdate != null)
        .sort((a, b) => a.expdate - b.expdate)
        .forEach(function(pur) {
          if (qty > 0) {
            if (pur.subStock <= qty) {
              qty -= pur.subStock;
              pur.subStock = 0;
            } else {
              pur.subStock -= qty;
              qty = 0;
            }
            pur.save({ suppressWarning: true });
          }
        });

      medicine.save();
    }
  });
}

function saveTransferKitStock(req, res) {
  Medicine.findOne({ mno: req.body.mno }, function(err, medicine) {
    if (!medicine) res.status(404).send("Data not found");
    else {
      if (req.body.stocktype === "A Kit") {
        medicine.stock.a_kit =
          parseInt(medicine.stock.a_kit) - parseInt(req.body.qty);
      } else {
        medicine.stock.b_kit =
          parseInt(medicine.stock.b_kit) - parseInt(req.body.qty);
      }

      medicine.save();
    }
  });
}

// Transfer OP
routes.post("*/medicine/transferOP", function(req, res, next) {
  try {
    saveTransferSubStock(req);

    let patDet = req.body.patient.split("] ");
    let pno = patDet[0].replace("[", "");
    let pname = patDet[1];

    // save OP history
    let op = new OP();
    op.mno = req.body.mno;
    op.medicinename = req.body.medicinename;
    op.qty = req.body.qty;
    op.pno = pno;
    op.patientname = pname;
    op.updatedon = new Date();

    op.save();
    res.status(200).json("Medicine Transferred");
  } catch (err) {
    next(new Error(err));
  }
});

// Transfer Kit
routes.post("*/medicine/transferKit", function(req, res, next) {
  try {
    saveTransferKitStock(req);

    let patDet = req.body.patient.split("] ");
    let pno = patDet[0].replace("[", "");
    let pname = patDet[1];

    // save OP history
    let op = new OP();
    op.mno = req.body.mno;
    op.medicinename = req.body.medicinename;
    op.qty = req.body.qty;
    op.pno = pno;
    op.patientname = pname;
    op.updatedon = new Date();

    op.save();
    res.status(200).json("Medicine Transferred");
  } catch (err) {
    next(new Error(err));
  }
});

// Inbound main stock
routes.post("*/medicine/inbound", function(req, res, next) {
  try {
    Medicine.findOne({ mno: req.body.mno }, function(err, medicine) {
      if (!medicine) res.status(404).send("Data not found");
      else {
        medicine.stock.main =
          parseInt(medicine.stock.main) + parseInt(req.body.qty);

        let invdate =
          req.body.purchase.invdate != null && req.body.purchase.invdate != ""
            ? moment(req.body.purchase.invdate).format("YYYY-MM-DD")
            : null;

        let expdate =
          req.body.purchase.expdate != null && req.body.purchase.expdate != ""
            ? moment(req.body.purchase.expdate).format("YYYY-MM-DD")
            : null;

        mfgdate =
          req.body.purchase.mfgdate != null && req.body.purchase.mfgdate != ""
            ? moment(req.body.purchase.mfgdate).format("YYYY-MM-DD")
            : null;

        const objPur = {
          expdate: expdate,
          mfgdate: mfgdate,
          rate: req.body.purchase.rate,
          dealer: req.body.purchase.dealer,
          invdate: invdate,
          invno: req.body.purchase.invno,
          batchno: req.body.purchase.batchno,
          mainStock: req.body.purchase.qty,
          subStock: 0
        };

        medicine.purchase.push(objPur);

        medicine.save();
        //.then(medicine => {
        //   //Save history - Main
        //   const hisMain = {
        //     mno: medicine.mno,
        //     qty: req.body.qty,
        //     stock: medicine.stock.main,
        //     source: "Inbound",
        //     transferto: "",
        //     stocktype: "Main Stock",
        //     name: medicine.name
        //   };

        //   saveHistory(hisMain);
        // });
      }
    });

    res.status(200).json("Medicine Added");
  } catch (err) {
    next(new Error(err));
  }
});

routes.post("*/medicine/return", function(req, res, next) {
  try {
    Medicine.findOne({ mno: req.body.mno }, function(err, medicine) {
      if (!medicine) res.status(404).send("Data not found");
      else {
        medicine.stock.main =
          parseInt(medicine.stock.main) - parseInt(req.body.mainRet);

        medicine.stock.sub =
          parseInt(medicine.stock.sub) - parseInt(req.body.subRet);

        medicine.purchase
          .filter(x => x._id == req.body.purId)
          .forEach(function(pur) {
            pur.mainStock -= req.body.mainRet;
            pur.subStock -= req.body.subRet;
            pur.save({ suppressWarning: true });
          });

        const objPur = {
          expdate: null,
          mfgdate: null,
          rate: 0,
          dealer: "",
          invdate: new Date(moment(new Date()).format("YYYY-MM-DD")),
          invno: "",
          batchno: "",
          mainStock: parseInt(req.body.mainRet) + parseInt(req.body.subRet),
          subStock: 0,
          return: 1
        };

        medicine.purchase.push(objPur);
        medicine.save();
      }
    });

    res.status(200).json("Medicine Returned");
  } catch (err) {
    next(new Error(err));
  }
});

routes.post("*/medicine/updateStock", function(req, res, next) {
  try {
    Medicine.findOne({ mno: req.body.mno }, function(err, medicine) {
      if (!medicine) res.status(404).send("Data not found");
      else {
        medicine.stock.main =
          parseInt(medicine.stock.main) - parseInt(req.body.mainDiff);

        medicine.stock.sub =
          parseInt(medicine.stock.sub) - parseInt(req.body.subDiff);

        medicine.purchase
          .filter(x => x._id == req.body.purId)
          .forEach(function(pur) {
            pur.mainStock = req.body.mainNew;
            pur.subStock = req.body.subNew;
            pur.save({ suppressWarning: true });
          });

        medicine.save().then(med => {
          res.status(200).json("Medicine Update");
        });
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

routes.get("*/medicine/reportExpiry", function(req, res, next) {
  //YYYY-MM-DD

  Center.findOne(function(err, center) {
    var dtStart = new Date(moment(new Date()).format("YYYY-MM-DD"));
    var dtEnd = new Date(
      moment(
        new Date().setTime(
          new Date().getTime() + center.medExpiryDays * 86400000
        )
      ).format("YYYY-MM-DD")
    );

    Medicine.aggregate(
      [
        { $unwind: "$purchase" },
        { $unwind: "$purchase.expdate" },
        {
          $match: {
            "purchase.expdate": {
              $gte: dtStart,
              $lte: dtEnd
            },
            $or: [
              { "purchase.mainStock": { $gt: 0 } },
              { "purchase.subStock": { $gt: 0 } }
            ]
          }
        },
        {
          $group: {
            _id: {
              _id: "$_id",
              name: "$name",
              mno: "$mno",
              expDate: "$purchase.expdate",
              mainStock: "$purchase.mainStock",
              subStock: "$purchase.subStock"
            }
          }
        },

        { $sort: { "_id.expDate": 1 } }
      ],
      function(err, result) {
        if (err) {
          next(new Error(err));
        } else {
          res.json(result);
        }
      }
    );
  });
});

routes.get("*/medicine/reportExpiryCount", function(req, res, next) {
  Center.findOne(function(err, center) {
    var dtStart = new Date(moment(new Date()).format("YYYY-MM-DD"));
    var dtEnd = new Date(
      moment(
        new Date().setTime(
          new Date().getTime() + center.medExpiryDays * 86400000
        )
      ).format("YYYY-MM-DD")
    );

    Medicine.aggregate(
      [
        { $unwind: "$purchase" },
        { $unwind: "$purchase.expdate" },
        {
          $match: {
            "purchase.expdate": {
              $gte: dtStart,
              $lte: dtEnd
            },
            $or: [
              { "purchase.mainStock": { $gt: 0 } },
              { "purchase.subStock": { $gt: 0 } }
            ]
          }
        },
        { $group: { _id: null, count: { $sum: 1 } } }
      ],
      function(err, result) {
        if (err) {
          next(new Error(err));
        } else {
          res.json(result);
        }
      }
    );
  });
});

routes.get("*/medicine/reportThreshold", function(req, res, next) {
  //YYYY-MM-DD

  Center.findOne(function(err, center) {
    Medicine.aggregate(
      [
        { $unwind: "$purchase" },
        { $unwind: "$purchase.mainStock" },
        { $unwind: "$purchase.subStock" },
        {
          $match: {
            "purchase.mainStock": {
              $gt: 0,
              $lte: center.medThresholdCount
            }
          }
        },
        {
          $group: {
            _id: {
              _id: "$_id",
              name: "$name",
              mno: "$mno",
              mainStock: "$purchase.mainStock"
            }
          }
        },

        { $sort: { "_id.name": 1 } }
      ],
      function(err, result) {
        if (err) {
          next(new Error(err));
        } else {
          res.json(result);
        }
      }
    );
  });
});

routes.get("*/medicine/reportThresholdCount", function(req, res, next) {
  Center.findOne(function(err, center) {
    Medicine.aggregate(
      [
        { $unwind: "$purchase" },
        { $unwind: "$purchase.mainStock" },
        { $unwind: "$purchase.subStock" },
        {
          $match: {
            "purchase.mainStock": {
              $gt: 0,
              $lte: center.medThresholdCount
            }
          }
        },
        { $group: { _id: null, count: { $sum: 1 } } }
      ],
      function(err, result) {
        if (err) {
          next(new Error(err));
        } else {
          res.json(result);
        }
      }
    );
  });
});

routes.get("*/medicine/migrate", function(req, res, next) {
  Medicine.find(function(err, medicines) {
    if (err) {
      next(new Error(err));
    } else {
      medicines.forEach(function(medOld) {
        let medNew = new MedicineNew();
        medNew.mno = medOld.mno;
        medNew.name = medOld.name;
        medNew.name_lower = medOld.name_lower;
        medNew.stock.main = medOld.stock.main;
        medNew.stock.sub = medOld.stock.sub;
        medNew.stock.a_kit = medOld.stock.a_kit;
        medNew.stock.b_kit = medOld.stock.b_kit;

        let i = 1;

        medOld.purchase
          .filter(x => x.return == undefined)
          .forEach(function(purOld) {
            let mainStock = 0,
              subStock = 0;

            if (
              i === medOld.purchase.filter(x => x.return == undefined).length
            ) {
              mainStock = medOld.stock.main;
              subStock = medOld.stock.sub;
            }

            const objPur = {
              expdate: purOld.expdate,
              mfgdate: purOld.mfgdate,
              rate: purOld.rate,
              dealer: purOld.dealer,
              invdate: purOld.invdate,
              invno: purOld.invno,
              batchno: purOld.batchno,
              mainStock: mainStock,
              subStock: subStock,
              return: purOld.return
            };
            medNew.purchase.push(objPur);
            i++;
          });

        medNew.save();
      });

      res.status(200).json("done");
    }
  });
});

routes.get("*/medicine/validate", function(req, res, next) {
  Medicine.find(function(err, medicines) {
    if (err) {
      next(new Error(err));
    } else {
      medicines.forEach(function(medOld) {
        if (
          medOld.purchase.filter(x => x.return == undefined && x.qty > 0)
            .length > 1
        ) {
          console.log(medOld.mno);
        }
      });

      res.status(200).json("done");
    }
  });
});

module.exports = routes;
