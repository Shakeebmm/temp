const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let bankLedger = new Schema(
  {
    bno: {
      type: String
    },
    txnType: {
      type: String
    },
    txnDate: {
      type: Date
    },
    amount: {
      type: Number
    }
  },
  {
    collection: "bankLedger"
  }
);

module.exports = mongoose.model("bankLedger", bankLedger);
