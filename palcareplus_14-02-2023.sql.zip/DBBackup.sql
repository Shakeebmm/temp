-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: palcareplus
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `txndate` datetime DEFAULT NULL,
  `desc` varchar(200) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `txntype` varchar(45) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `receiptNo` varchar(45) DEFAULT NULL,
  `isReceipt` tinyint DEFAULT NULL,
  `paymentMode` varchar(45) DEFAULT NULL,
  `bankMode` varchar(45) DEFAULT NULL,
  `bankName` varchar(200) DEFAULT NULL,
  `txnNo` varchar(100) DEFAULT NULL,
  `chNo` varchar(45) DEFAULT NULL,
  `chdate` datetime DEFAULT NULL,
  `chBank` varchar(200) DEFAULT NULL,
  `chAmount` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=1946 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (7,'2022-05-11 00:00:00','gash','dfdf',0.00,'Income','lllll','756',1,'Cash','','','','',NULL,'',0.00),(8,'2022-04-02 00:00:00','6078',' Monthly Subscription',1000.00,'Income','Mohamed Rafi K V','46',1,'Cash','','','','',NULL,'',0.00),(9,'2022-04-03 00:00:00','6079',' Monthly Subscription',1000.00,'Income','Musthafa K V','47',1,'Cash','','','','',NULL,'',0.00),(10,'2022-04-03 00:00:00','6080',' Monthly Subscription',1000.00,'Income','Wasif K V','48',1,'Cash','','','','',NULL,'',0.00),(11,'2022-04-03 00:00:00','6081',' Monthly Subscription',4000.00,'Income','Saidalavi K P','49',1,'Cash','','','','',NULL,'',0.00),(12,'2022-04-04 00:00:00','1571',' Monthly Subscription',2000.00,'Income','Shahul Hameed P K','50',1,'Cash','','','','',NULL,'',0.00),(13,'2022-04-04 00:00:00','1572','Donation',6000.00,'Income','Y ahu haji','51',1,'Cash','','','','',NULL,'',0.00),(14,'2022-04-06 00:00:00','6082','Donation',1000.00,'Income','Abdurahman Master','52',1,'Cash','','','','',NULL,'',0.00),(15,'2022-04-08 00:00:00','6083',' Monthly Subscription',500.00,'Income','Moideen Master R','53',1,'Cash','','','','',NULL,'',0.00),(16,'2022-04-08 00:00:00','6301April 22 To March 23',' Monthly Subscription',6000.00,'Income','Basheer V','54',1,'Cash','','','','',NULL,'',0.00),(17,'2022-04-08 00:00:00','1573','Donation',2000.00,'Income','Mohamed Shafi V M','55',1,'Cash','','','','',NULL,'',0.00),(18,'2022-04-09 00:00:00','1574','Donation',10000.00,'Income','Hamsutty K  Kanhikoth','56',1,'Cash','','','','',NULL,'',0.00),(19,'2022-04-09 00:00:00','6084  May 21 To April 22',' Monthly Subscription',1200.00,'Income','Anwar Sadath V K','57',1,'Cash','','','','',NULL,'',0.00),(20,'2022-04-09 00:00:00','6085 May 22 To April 23',' Monthly Subscription',1200.00,'Income','Anwar Sadath V K','58',1,'Cash','','','','',NULL,'',0.00),(21,'2022-04-10 00:00:00','6251','Donation',1000.00,'Income','Basheer Mathoor','59',1,'Cash','','','','',NULL,'',0.00),(22,'2022-04-11 00:00:00','6086','Donation',500.00,'Income','Anwar Sadath P K','60',1,'Cash','','','','',NULL,'',0.00),(23,'2022-04-11 00:00:00','1575',' Monthly Subscription',2000.00,'Income','Jabbar C T','61',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(24,'2022-04-11 00:00:00','1576','Donation',10000.00,'Income','Hamsakutty Haji T, Thoombil','62',1,NULL,'','','','',NULL,'',0.00),(25,'2022-04-12 00:00:00','6252','Donation',3000.00,'Income','Aboobacker Poothottil,Kavancheri','63',1,'Cash','','','','',NULL,'',0.00),(26,'2022-04-12 00:00:00','6253','Donation',2500.00,'Income','Abdurasak Parakkat, Kavancheri','64',1,'Cash','','','','',NULL,'',0.00),(27,'2022-04-12 00:00:00','6254','Donation',1000.00,'Income','Maeiyam Vazhappulli,Tirur','65',1,'Cash','','','','',NULL,'',0.00),(28,'2022-04-12 00:00:00','6255','Donation',2000.00,'Income','Nadeera Vazhappuuli,Tirur','66',1,'Cash','','','','',NULL,'',0.00),(29,'2022-04-12 00:00:00','6256','Donation',2500.00,'Income','Thasneem Vazhappulli','67',1,'Cash','','','','',NULL,'',0.00),(30,'2022-04-12 00:00:00','6257','Donation',2500.00,'Income','Kassim M','68',1,'Cash','','','','',NULL,'',0.00),(31,'2022-04-13 00:00:00','6087','Rent',2250.00,'Income','Thilakam','69',1,'Cash','','','','',NULL,'',0.00),(32,'2022-04-12 00:00:00','6088','Donation',500.00,'Income','Abrar Kottakkal','70',1,'Cash','','','','',NULL,'',0.00),(33,'2022-04-14 00:00:00','6089','Donation',500.00,'Income','Habeebrahman K','71',1,'Cash','','','','',NULL,'',0.00),(34,'2022-04-14 00:00:00','6090',' Monthly Subscription',1200.00,'Income','Abdurahman V M','72',1,'Cash','','','','',NULL,'',0.00),(35,'2022-04-14 00:00:00','6091',' Monthly Subscription',500.00,'Income','Rabiya V M','73',1,'Cash','','','','',NULL,'',0.00),(36,'2022-04-14 00:00:00','6258','Donation',500.00,'Income','Mariyakutty C','74',1,'Cash','','','','',NULL,'',0.00),(37,'2022-04-14 00:00:00','6259','Donation',500.00,'Income','Nisam K K','75',1,'Cash','','','','',NULL,'',0.00),(38,'2022-04-15 00:00:00','1701','Donation',2000.00,'Income','Faisal Thandasseri','76',1,'Cash','','','','',NULL,'',0.00),(39,'2022-04-15 00:00:00','1702','Donation',1000.00,'Income','Mohamed Sabu K V','77',1,'Cash','','','','',NULL,'',0.00),(40,'2022-04-15 00:00:00','1703','Donation',500.00,'Income','Sheeba Teacher','78',1,'Cash','','','','',NULL,'',0.00),(41,'2022-04-15 00:00:00','1704','Donation',2000.00,'Income','Sreeja M','79',1,'Cash','','','','',NULL,'',0.00),(42,'2022-04-15 00:00:00','1705','Donation',1001.00,'Income','Divya , K H M H S','80',1,'Cash','','','','',NULL,'',0.00),(43,'2022-04-15 00:00:00','1706','Donation',500.00,'Income','Priya PA< KHMHS','81',1,'Cash','','','','',NULL,'',0.00),(44,'2022-04-15 00:00:00','1707','Donation',5000.00,'Income','Nabeel, 10 B Batch 97-98','82',1,'Cash','','','','',NULL,'',0.00),(45,'2022-04-15 00:00:00','1708','Donation',1000.00,'Income','Bindu M,KHMHS','83',1,'Cash','','','','',NULL,'',0.00),(46,'2022-04-15 00:00:00','1709','Donation',2500.00,'Income','Abdul Jaleel I P,10 B Bach 97-98','84',1,'Cash','','','','',NULL,'',0.00),(47,'2022-04-15 00:00:00','1710','Donation',5000.00,'Income','Jafar Sha, 10 I 97-98 Bach','85',1,'Cash','','','','',NULL,'',0.00),(48,'2022-04-15 00:00:00','1711','Donation',1000.00,'Income','Saifunneesa 10 I,97-98 Batch','86',1,'Cash','','','','',NULL,'',0.00),(49,'2022-04-15 00:00:00','1712','Donation',1000.00,'Income','Jaya K S , KHMHS','87',1,'Cash','','','','',NULL,'',0.00),(50,'2022-04-19 00:00:00','1713','Donation',500.00,'Income','Navas.10 B 2009-10 Batch','88',1,'Cash','','','','',NULL,'',0.00),(51,'2022-04-19 00:00:00','1714','Donation',1000.00,'Income','Rahila,10 B 2009-10 Batch','89',1,'Cash','','','','',NULL,'',0.00),(52,'2022-04-19 00:00:00','1715','Donation',1500.00,'Income','Shafeeq T ,KHMHS','90',1,'Cash','','','','',NULL,'',0.00),(53,'2022-04-19 00:00:00','1716','Donation',500.00,'Income','Harifa M,KHMHS','91',1,'Cash','','','','',NULL,'',0.00),(54,'2022-04-19 00:00:00','1717','Donation',500.00,'Income','Sameera P , KHMHS','92',1,'Cash','','','','',NULL,'',0.00),(55,'2022-04-19 00:00:00','1718','Donation',500.00,'Income','Zakiyya Parveen PP , KHMHS','93',1,'Cash','','','','',NULL,'',0.00),(56,'2022-04-19 00:00:00','1719','Donation',1000.00,'Income','Bindya B Nair, KHMHS','94',1,'Cash','','','','',NULL,'',0.00),(57,'2022-04-19 00:00:00','1720','Donation',1000.00,'Income','Bejoy Thomas, KHMHS','95',1,'Cash','','','','',NULL,'',0.00),(58,'2022-04-19 00:00:00','1721','Donation',15000.00,'Income','Ramzy Pookayil,KHMHS 10 I Batch 98-99','96',1,'Cash','','','','',NULL,'',0.00),(59,'2022-04-19 00:00:00','1722','Donation',1000.00,'Income','Rameesha R V, KHMHS','97',1,'Cash','','','','',NULL,'',0.00),(60,'2022-04-19 00:00:00','1723','Donation',2000.00,'Income','Fida,10 B,97-98 Batch','98',1,'Cash','','','','',NULL,'',0.00),(61,'2022-04-19 00:00:00','1724','Donation',1000.00,'Income','Mufeeda T, KHMHS','99',1,'Cash','','','','',NULL,'',0.00),(62,'2022-04-19 00:00:00','1725','Donation',500.00,'Income','Fasil,10 B,97-98 Batch','100',1,'Cash','','','','',NULL,'',0.00),(63,'2022-04-19 00:00:00','1726','Donation',1000.00,'Income','Sameera Thoufeeq,KHMHS','101',1,'Cash','','','','',NULL,'',0.00),(64,'2022-04-19 00:00:00','1727','Donation',5000.00,'Income','Nadeer G M T,Poozhikkunnu','102',1,'Cash','','','','',NULL,'',0.00),(65,'2022-04-19 00:00:00','1728','Donation',500.00,'Income','Jalaina,10 i 97-98 Batch','103',1,'Cash','','','','',NULL,'',0.00),(66,'2022-04-19 00:00:00','1729','Donation',1000.00,'Income','Febin C T, KHMHS','104',1,'Cash','','','','',NULL,'',0.00),(67,'2022-04-19 00:00:00','1730','Donation',500.00,'Income','Romila, KHMHS','105',1,'Cash','','','','',NULL,'',0.00),(68,'2022-04-19 00:00:00','1731','Donation',0.00,'Income','Fathima,KHMHS','106',1,'Cash','','','','',NULL,'',0.00),(69,'2022-04-19 00:00:00','1732','Donation',1000.00,'Income','Fousiya, KHMHS','107',1,'Cash','','','','',NULL,'',0.00),(70,'2022-04-19 00:00:00','1733','Donation',500.00,'Income','Ranju,KHMHS','108',1,'Cash','','','','',NULL,'',0.00),(71,'2022-04-19 00:00:00','1734','Donation',500.00,'Income','Ramsheeda,KHMHS','109',1,'Cash','','','','',NULL,'',0.00),(72,'2022-04-19 00:00:00','1735','Donation',500.00,'Income','Manjula ,KHMHS','110',1,'Cash','','','','',NULL,'',0.00),(73,'2022-04-19 00:00:00','1736','Donation',1000.00,'Income','Safiya Teacher,KHMHS','111',1,'Cash','','','','',NULL,'',0.00),(74,'2022-04-19 00:00:00','1737','Donation',1000.00,'Income','Ramzeena Teacher,KHMHS','112',1,'Cash','','','','',NULL,'',0.00),(75,'2022-04-19 00:00:00','1738','Donation',1000.00,'Income','Abdul Gafoor K, KHMHS','113',1,'Cash','','','','',NULL,'',0.00),(76,'2022-04-19 00:00:00','1739','Donation',1000.00,'Income','Amina Teacher, KHMHS','114',1,'Cash','','','','',NULL,'',0.00),(77,'2022-04-19 00:00:00','1740','Donation',1000.00,'Income','Nusaiba,10I Batch','115',1,'Cash','','','','',NULL,'',0.00),(78,'2022-05-19 00:00:00','1741','Donation',0.00,'Income','Jamshy Teacher,KHMHS','759',1,'Cash','','','','',NULL,'',0.00),(79,'2022-04-19 00:00:00','1742','Donation',3000.00,'Income','Asmabi NP,10iBatch','117',1,'Cash','','','','',NULL,'',0.00),(80,'2022-04-19 00:00:00','1743','Donation',500.00,'Income','Sameera akk,KHMHS','118',1,'Cash','','','','',NULL,'',0.00),(81,'2022-04-19 00:00:00','1744','Donation',500.00,'Income','Suhail,KHMHS','119',1,'Cash','','','','',NULL,'',0.00),(82,'2022-04-19 00:00:00','1745','Donation',0.00,'Income','Cancell','120',1,'Cash','','','','',NULL,'',0.00),(83,'2022-04-21 00:00:00','1746','Donation',1000.00,'Income','Jaseena Teacher,KHMHS','121',1,'Cash','','','','',NULL,'',0.00),(84,'2022-04-21 00:00:00','1747','Donation',1500.00,'Income','Shyni Noor,KHMHS','122',1,'Cash','','','','',NULL,'',0.00),(85,'2022-04-21 00:00:00','1748','Donation',5000.00,'Income','Faslurahman P K,10i,98-99 Batch','123',1,'Cash','','','','',NULL,'',0.00),(86,'2022-04-21 00:00:00','1749','Donation',2000.00,'Income','Sakeena Teacher,KHMHS','124',1,'Cash','','','','',NULL,'',0.00),(87,'2022-04-21 00:00:00','1750','Donation',1000.00,'Income','Sainudheen T, KHMHS','125',1,'Cash','','','','',NULL,'',0.00),(88,'2022-04-16 00:00:00','6092',' Monthly Subscription',500.00,'Income','ABDUL hAMEED p k','126',1,'Cash','','','','',NULL,'',0.00),(89,'2022-04-17 00:00:00','6093','Donation',1000.00,'Income','Hussain Haji N','127',1,'Cash','','','','',NULL,'',0.00),(90,'2022-04-17 00:00:00','6094','Donation',1000.00,'Income','Aboobacker Sidheeq K T','128',1,'Cash','','','','',NULL,'',0.00),(91,'2022-04-17 00:00:00','6095',' Monthly Subscription',500.00,'Income','Kadeeja P K','129',1,'Cash','','','','',NULL,'',0.00),(92,'2022-04-17 00:00:00','6096','Donation',1000.00,'Income','Gafoor C V O','130',1,'Cash','','','','',NULL,'',0.00),(93,'2022-04-17 00:00:00','6097','Donation',750.00,'Income','Mohamed Ashraf K','131',1,'Cash','','','','',NULL,'',0.00),(94,'2022-04-17 00:00:00','6098','Donation',500.00,'Income','Abdul Nasr ','132',1,'Cash','','','','',NULL,'',0.00),(95,'2022-04-17 00:00:00','6099','Donation',1000.00,'Income','Ishak V M','133',1,'Cash','','','','',NULL,'',0.00),(96,'2022-04-18 00:00:00','6100','Donation',1000.00,'Income','Faisal V M','134',1,'Cash','','','','',NULL,'',0.00),(97,'2022-04-16 00:00:00','6302','Donation',500.00,'Income','Hamsuppa k k','135',1,'Cash','','','','',NULL,'',0.00),(98,'2022-04-19 00:00:00','6303','Freezer& O2 Rent',4000.00,'Income','Nandhana','136',1,'Cash','','','','',NULL,'',0.00),(99,'2022-04-19 00:00:00','6304','Donation',800.00,'Income','Abdurahman T','137',1,'Cash','','','','',NULL,'',0.00),(100,'2022-04-20 00:00:00','6305','Donation',100.00,'Income','Noushad A P','138',1,'Cash','','','','',NULL,'',0.00),(101,'2022-04-22 00:00:00','6306',' Monthly Subscription',500.00,'Income','Kunhimohamed Master R','139',1,'Cash','','','','',NULL,'',0.00),(102,'2022-04-23 00:00:00','6307','Freezer& O2 Rent',2000.00,'Income','Ayyappan P','140',1,'Cash','','','','',NULL,'',0.00),(103,'2022-04-26 00:00:00','6308',' Monthly Subscription',100.00,'Income','Kerala Store','141',1,'Cash','','','','',NULL,'',0.00),(104,'2022-04-26 00:00:00','6309',' Monthly Subscription',200.00,'Income','Perfect Electricals','142',1,'Cash','','','','',NULL,'',0.00),(105,'2022-04-26 00:00:00','6310',' Monthly Subscription',150.00,'Income','Friends Banana Shop','143',1,'Cash','','','','',NULL,'',0.00),(106,'2022-04-26 00:00:00','6311',' Monthly Subscription',200.00,'Income','Colors ','144',1,'Cash','','','','',NULL,'',0.00),(107,'2022-04-26 00:00:00','6312',' Monthly Subscription',250.00,'Income','Bose Textails','145',1,'Cash','','','','',NULL,'',0.00),(108,'2022-04-26 00:00:00','6313',' Monthly Subscription',100.00,'Income','Soubhagya Tyre Works','146',1,'Cash','','','','',NULL,'',0.00),(109,'2022-04-26 00:00:00','6314',' Monthly Subscription',100.00,'Income','Shajahan On Line','147',1,'Cash','','','','',NULL,'',0.00),(110,'2022-04-26 00:00:00','6315',' Monthly Subscription',200.00,'Income','Munthiri Footware','148',1,'Cash','','','','',NULL,'',0.00),(111,'2022-04-26 00:00:00','6316',' Monthly Subscription',500.00,'Income','Corner Vegitable','149',1,'Cash','','','','',NULL,'',0.00),(112,'2022-04-26 00:00:00','6317',' Monthly Subscription',100.00,'Income','Rak Pharma','150',1,'Cash','','','','',NULL,'',0.00),(113,'2022-04-26 00:00:00','6318',' Monthly Subscription',1000.00,'Income','Ismail A','151',1,'Cash','','','','',NULL,'',0.00),(114,'2022-04-26 00:00:00','6319',' Monthly Subscription',100.00,'Income','I One mobile','152',1,'Cash','','','','',NULL,'',0.00),(115,'2022-04-26 00:00:00','6320',' Monthly Subscription',100.00,'Income','Nadiya Fancy','153',1,'Cash','','','','',NULL,'',0.00),(116,'2022-04-26 00:00:00','6321',' Monthly Subscription',100.00,'Income','Akhila','154',1,'Cash','','','','',NULL,'',0.00),(117,'2022-04-26 00:00:00','6322',' Monthly Subscription',500.00,'Income','dental Clinic','155',1,'Cash','','','','',NULL,'',0.00),(118,'2022-04-26 00:00:00','6323',' Monthly Subscription',100.00,'Income','Care Clinic','156',1,'Cash','','','','',NULL,'',0.00),(119,'2022-04-26 00:00:00','6324',' Monthly Subscription',100.00,'Income','Siraj Sweet Shop','157',1,'Cash','','','','',NULL,'',0.00),(120,'2022-04-26 00:00:00','6325',' Monthly Subscription',300.00,'Income','Kunhuttimon','158',1,'Cash','','','','',NULL,'',0.00),(121,'2022-04-26 00:00:00','6326',' Monthly Subscription',300.00,'Income','Alfa store','159',1,'Cash','','','','',NULL,'',0.00),(122,'2022-04-26 00:00:00','6327',' Monthly Subscription',100.00,'Income','Ration Shop','160',1,'Cash','','','','',NULL,'',0.00),(123,'2022-04-26 00:00:00','6328',' Monthly Subscription',100.00,'Income','ATR Chikken','161',1,'Cash','','','','',NULL,'',0.00),(124,'2022-04-26 00:00:00','6329',' Monthly Subscription',100.00,'Income','E K Traders','162',1,'Cash','','','','',NULL,'',0.00),(125,'2022-04-26 00:00:00','6330',' Monthly Subscription',500.00,'Income','B Sqare','163',1,'Cash','','','','',NULL,'',0.00),(126,'2022-04-26 00:00:00','6331',' Monthly Subscription',500.00,'Income','M T C Mangalam','164',1,'Cash','','','','',NULL,'',0.00),(127,'2022-04-26 00:00:00','6332',' Monthly Subscription',100.00,'Income','Lillis Bakery','165',1,'Cash','','','','',NULL,'',0.00),(128,'2022-04-26 00:00:00','6333',' Monthly Subscription',250.00,'Income','P K C Store','166',1,'Cash','','','','',NULL,'',0.00),(129,'2022-04-26 00:00:00','6334',' Monthly Subscription',100.00,'Income','K P K Vegitable','167',1,'Cash','','','','',NULL,'',0.00),(130,'2022-04-27 00:00:00','6335',' Monthly Subscription',250.00,'Income','A K Store','168',1,'Cash','','','','',NULL,'',0.00),(131,'2022-04-27 00:00:00','6336',' Monthly Subscription',500.00,'Income','Dheema Jewellary','169',1,'Cash','','','','',NULL,'',0.00),(132,'2022-04-27 00:00:00','6337',' Monthly Subscription',100.00,'Income','Kishore Master','170',1,'Cash','','','','',NULL,'',0.00),(133,'2022-04-27 00:00:00','6338',' Monthly Subscription',100.00,'Income','Impress','171',1,'Cash','','','','',NULL,'',0.00),(134,'2022-04-27 00:00:00','6339',' Monthly Subscription',250.00,'Income','Aswas Community ','172',1,'Cash','','','','',NULL,'',0.00),(135,'2022-04-27 00:00:00','6340',' Monthly Subscription',500.00,'Income','Foot Beet','173',1,'Cash','','','','',NULL,'',0.00),(136,'2022-04-27 00:00:00','6341',' Monthly Subscription',100.00,'Income','K K Vegitable','174',1,'Cash','','','','',NULL,'',0.00),(137,'2022-04-27 00:00:00','6342',' Monthly Subscription',100.00,'Income','V P Chikken','175',1,'Cash','','','','',NULL,'',0.00),(138,'2022-04-27 00:00:00','6343',' Monthly Subscription',100.00,'Income','Freh Cool','176',1,'Cash','','','','',NULL,'',0.00),(139,'2022-04-27 00:00:00','6344',' Monthly Subscription',200.00,'Income','TechnoPoint','177',1,'Cash','','','','',NULL,'',0.00),(140,'2022-04-27 00:00:00','6345',' Monthly Subscription',100.00,'Income','Shanoos Buty','178',1,'Cash','','','','',NULL,'',0.00),(141,'2022-04-27 00:00:00','6346',' Monthly Subscription',500.00,'Income','A M Store','179',1,'Cash','','','','',NULL,'',0.00),(142,'2022-04-27 00:00:00','6347',' Monthly Subscription',400.00,'Income','P K C Bakery','180',1,'Cash','','','','',NULL,'',0.00),(143,'2022-04-27 00:00:00','6348',' Monthly Subscription',200.00,'Income','Thanima Chappathy Company','181',1,'Cash','','','','',NULL,'',0.00),(144,'2022-04-27 00:00:00','6349',' Monthly Subscription',100.00,'Income','Rajan Hotel','182',1,'Cash','','','','',NULL,'',0.00),(145,'2022-04-27 00:00:00','6350',' Monthly Subscription',100.00,'Income','Rafi  Chikke shop','183',1,'Cash','','','','',NULL,'',0.00),(146,'2022-04-16 00:00:00','1577','Donation',5000.00,'Income','Abdurahman P P','184',1,'Cash','','','','',NULL,'',0.00),(147,'2022-04-17 00:00:00','1578','Donation',2000.00,'Income','Gafoor  C M','185',1,'Cash','','','','',NULL,'',0.00),(148,'2022-04-17 00:00:00','1579','Donation',2000.00,'Income','Majeed P P','186',1,'Cash','','','','',NULL,'',0.00),(149,'2022-04-17 00:00:00','1580','Donation',500.00,'Income','Kadeeja T K','187',1,'Cash','','','','',NULL,'',0.00),(150,'2022-04-17 00:00:00','1581','Donation',2000.00,'Income','Seenath P K','188',1,'Cash','','','','',NULL,'',0.00),(151,'2022-04-17 00:00:00','1582','Donation',1000.00,'Income','Nusaiba P K','189',1,'Cash','','','','',NULL,'',0.00),(152,'2022-04-17 00:00:00','1583','Donation',2000.00,'Income','Kadeeja P K','190',1,'Cash','','','','',NULL,'',0.00),(153,'2022-04-17 00:00:00','1584','Donation',2500.00,'Income','Saleem P K','191',1,'Cash','','','','',NULL,'',0.00),(154,'2022-04-17 00:00:00','1585','Donation',2000.00,'Income','Abdul Jabbar Haji P K','192',1,'Cash','','','','',NULL,'',0.00),(155,'2022-04-17 00:00:00','1586','Donation',20000.00,'Income','Musthafa K P','193',1,'Cash','','','','',NULL,'',0.00),(156,'2022-04-17 00:00:00','1587','Donation',2000.00,'Income','Seethi Master M','194',1,'Cash','','','','',NULL,'',0.00),(157,'2022-04-18 00:00:00','1588',' Monthly Subscription',6000.00,'Income','Bapputty K T','195',1,'Cash','','','','',NULL,'',0.00),(158,'2022-04-18 00:00:00','1589','Donation',5000.00,'Income','Abdul Kader CP','196',1,'Cash','','','','',NULL,'',0.00),(159,'2022-04-18 00:00:00','1590','Donation',3000.00,'Income','Muhamed Musthafa C ','197',1,'Cash','','','','',NULL,'',0.00),(160,'2022-04-19 00:00:00','1591','Donation',10000.00,'Income','Bava sahib C P','198',1,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(161,'2022-04-19 00:00:00','1592','Donation',2500.00,'Income','Ashraf C P','199',1,'Cash','','','','',NULL,'',0.00),(162,'2022-04-19 00:00:00','1593','Donation',2000.00,'Income','Sidheeq Pottammal','200',1,'Cash','','','','',NULL,'',0.00),(163,'2022-04-19 00:00:00','1594','Donation',5000.00,'Income','Ali sahib T V','201',1,'Cash','','','','',NULL,'',0.00),(164,'2022-04-18 00:00:00','1595','Donation',12000.00,'Income','Aboobacker Sidheeq K K','202',1,'Cash','','','','',NULL,'',0.00),(165,'2022-04-18 00:00:00','1596','Donation',5000.00,'Income','Aboobacker Sidheeq K K','203',1,'Bank','Transfer','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(166,'2022-04-21 00:00:00','1597','Donation',5000.00,'Income','Jamsheera K K','204',1,'Cash','','','','',NULL,'',0.00),(167,'2022-04-21 00:00:00','1598','Donation',4000.00,'Income','Haneefa M P','205',1,'Cash','','','','',NULL,'',0.00),(168,'2022-04-21 00:00:00','1599','Donation',2000.00,'Income','Fairos K V','206',1,'Cash','','','','',NULL,'',0.00),(169,'2022-04-21 00:00:00','1600','Donation',3000.00,'Income','Kassim E','207',1,'Bank','Transfer','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(170,'2022-04-17 00:00:00','6260','Donation',1000.00,'Income','Abdul Jabbar P K','208',1,'Cash','','','','',NULL,'',0.00),(171,'2022-04-17 00:00:00','6261','Donation',500.00,'Income','Abdullakutty P K','209',1,'Cash','','','','',NULL,'',0.00),(172,'2022-04-17 00:00:00','6262','Donation',2000.00,'Income','Mohamedali Haji K K','210',1,'Cash','','','','',NULL,'',0.00),(173,'2022-04-17 00:00:00','6263','Donation',500.00,'Income','Mammukutty K K','211',1,'Cash','','','','',NULL,'',0.00),(174,'2022-04-19 00:00:00','6264','Donation',10000.00,'Income','Rafeeq C P','212',1,'Cash','','','','',NULL,'',0.00),(175,'2022-04-20 00:00:00','6265','Donation',5000.00,'Income','Aboobaker K N','213',1,'Cash','','','','',NULL,'',0.00),(176,'2022-04-20 00:00:00','6266','Donation',100.00,'Income','Sidheeq M','214',1,'Cash','','','','',NULL,'',0.00),(177,'2022-04-20 00:00:00','6267','Donation',200.00,'Income','Bava ','215',1,'Cash','','','','',NULL,'',0.00),(178,'2022-04-21 00:00:00','6268','Donation',2000.00,'Income','Sidheeq M P','216',1,'Cash','','','','',NULL,'',0.00),(179,'2022-04-21 00:00:00','6269','Donation',1000.00,'Income','Aslam V k','217',1,'Cash','','','','',NULL,'',0.00),(180,'2022-04-23 00:00:00','6270','Donation',2000.00,'Income','Jamshi V K','218',1,NULL,'','','','',NULL,'',0.00),(181,'2022-04-25 00:00:00','6271','Donation',250.00,'Income','Majeed V K','219',1,'Cash','','','','',NULL,'',0.00),(182,'2022-04-24 00:00:00','6272','Donation',500.00,'Income','Abdullakuty C','220',1,'Cash','','','','',NULL,'',0.00),(183,'2022-04-24 00:00:00','6273','Donation',2000.00,'Income','Abdul MAjeed ','221',1,'Cash','','','','',NULL,'',0.00),(184,'2022-04-25 00:00:00','6274','Donation',2000.00,'Income','Haneefa P','222',1,'Cash','','','','',NULL,'',0.00),(185,'2022-04-24 00:00:00','6275','Donation',1000.00,'Income','Shafi M V','223',1,'Cash','','','','',NULL,'',0.00),(186,'2022-04-26 00:00:00','6276','Donation',2000.00,'Income','Raliya V K','224',1,'Cash','','','','',NULL,'',0.00),(187,'2022-04-26 00:00:00','6277','Donation',1000.00,'Income','Musthafa K p','225',1,'Cash','','','','',NULL,'',0.00),(188,'2022-04-28 00:00:00','6278','Donation',2000.00,'Income','Noushad ','226',1,'Cash','','','','',NULL,'',0.00),(189,'2022-04-29 00:00:00','6279','Donation',1000.00,'Income','Fsalrahman K K','227',1,'Cash','','','','',NULL,'',0.00),(190,'2022-04-29 00:00:00','6280','Donation',5000.00,'Income','Shani','228',1,'Cash','','','','',NULL,'',0.00),(191,'2022-04-29 00:00:00','6281','Donation',16500.00,'Income','Jaseena K','229',1,'Cash','','','','',NULL,'',0.00),(192,'2022-04-30 00:00:00','6282','Donation',2000.00,'Income','Thezil','230',1,'Cash','','','','',NULL,'',0.00),(193,'2022-04-30 00:00:00','6283','Donation',500.00,'Income','Jumana','231',1,'Cash','','','','',NULL,'',0.00),(194,'2022-04-30 00:00:00','6284','Donation',500.00,'Income','Jani K K','232',1,'Cash','','','','',NULL,'',0.00),(195,'2022-04-17 00:00:00','1601','Donation',5000.00,'Income','Mohamed P K','233',1,'Cash','','','','',NULL,'',0.00),(196,'2022-04-17 00:00:00','1602','Donation',500.00,'Income','Ibrahim kutty K T','234',1,'Cash','','','','',NULL,'',0.00),(197,'2022-04-17 00:00:00','1603','Donation',1000.00,'Income','Hussankutty K T','235',1,'Cash','','','','',NULL,'',0.00),(198,'2022-04-17 00:00:00','1604','Donation',2000.00,'Income','Naser T K','236',1,'Cash','','','','',NULL,'',0.00),(199,'2022-04-17 00:00:00','1605','Donation',100.00,'Income','Hashim M P','237',1,'Cash','','','','',NULL,'',0.00),(200,'2022-04-17 00:00:00','1606','Donation',500.00,'Income','Ibrahimkutty M P','238',1,'Cash','','','','',NULL,'',0.00),(201,'2022-04-17 00:00:00','1607','Donation',500.00,'Income','Bappuhaji K T','239',1,'Cash','','','','',NULL,'',0.00),(202,'2022-04-17 00:00:00','1608','Donation',1000.00,'Income','Bapputtyhaji K T','240',1,'Cash','','','','',NULL,'',0.00),(203,'2022-04-17 00:00:00','1609','Donation',500.00,'Income','Beeravunni C N','241',1,'Cash','','','','',NULL,'',0.00),(204,'2022-04-17 00:00:00','1610','Donation',2000.00,'Income','Majeed K T','242',1,'Cash','','','','',NULL,'',0.00),(205,'2022-04-17 00:00:00','1611','Donation',1500.00,'Income','Jameela V M','243',1,'Cash','','','','',NULL,'',0.00),(206,'2022-04-17 00:00:00','1612','Donation',300.00,'Income','Mohamedali M P','244',1,'Cash','','','','',NULL,'',0.00),(207,'2022-04-17 00:00:00','1613','Donation',2000.00,'Income','Shafi V M','245',1,'Cash','','','','',NULL,'',0.00),(208,'2022-04-17 00:00:00','1614','Donation',200.00,'Income','Razak P T','246',1,'Cash','','','','',NULL,'',0.00),(209,'2022-04-17 00:00:00','1615','Donation',3000.00,'Income','Noufal C','247',1,'Cash','','','','',NULL,'',0.00),(210,'2022-04-17 00:00:00','1616','Donation',500.00,'Income','Saidalavi K K','248',1,'Cash','','','','',NULL,'',0.00),(211,'2022-04-17 00:00:00','1617','Donation',500.00,'Income','Shareef K P','249',1,'Cash','','','','',NULL,'',0.00),(212,'2022-04-17 00:00:00','1618','Donation',1000.00,'Income','Sidheeq N','250',1,'Cash','','','','',NULL,'',0.00),(213,'2022-04-19 00:00:00','1619','Donation',2000.00,'Income','Rafi T K','251',1,'Cash','','','','',NULL,'',0.00),(214,'2022-04-21 00:00:00','1620','Donation',500.00,'Income','Nazermohamed','252',1,'Cash','','','','',NULL,'',0.00),(215,'2022-04-21 00:00:00','1621','Donation',250.00,'Income','Sidheeq V P','253',1,'Cash','','','','',NULL,'',0.00),(216,'2022-04-21 00:00:00','1622','Donation',2000.00,'Income','Musthafa K T','254',1,'Cash','','','','',NULL,'',0.00),(217,'2022-04-21 00:00:00','1623','Donation',500.00,'Income','Hamsa K T','255',1,'Cash','','','','',NULL,'',0.00),(218,'2022-04-21 00:00:00','1624','Donation',1000.00,'Income','Sidheeq C M','256',1,'Cash','','','','',NULL,'',0.00),(219,'2022-04-21 00:00:00','1625','Donation',1000.00,'Income','Mashood K','257',1,'Cash','','','','',NULL,'',0.00),(220,'2022-04-21 00:00:00','1626','Donation',100.00,'Income','Shabu MP','258',1,'Cash','','','','',NULL,'',0.00),(221,'2022-04-21 00:00:00','1627','Donation',1000.00,'Income','Hamsa K','259',1,'Cash','','','','',NULL,'',0.00),(222,'2022-04-21 00:00:00','1623','Donation',0.00,'Income','Mohamedkutty V P','642',1,'Cash','','','','',NULL,'',0.00),(223,'2022-04-21 00:00:00','1629','Donation',500.00,'Income','Pathummakutty K','261',1,'Cash','','','','',NULL,'',0.00),(224,'2022-04-21 00:00:00','1630','Donation',1000.00,'Income','Haneefa K','262',1,'Cash','','','','',NULL,'',0.00),(225,'2022-04-22 00:00:00','1631','Donation',15000.00,'Income','Hamsakutty Thoombil','263',1,'Cash','','','','',NULL,'',0.00),(226,'2022-04-22 00:00:00','1632','Donation',1000.00,'Income','Najeeb K P','264',1,'Cash','','','','',NULL,'',0.00),(227,'2022-04-22 00:00:00','1633','Donation',2000.00,'Income','Hamsahaji T K','265',1,'Cash','','','','',NULL,'',0.00),(228,'2022-04-24 00:00:00','1634','Donation',1000.00,'Income','Suhara Teacher','266',1,'Cash','','','','',NULL,'',0.00),(229,'2022-04-26 00:00:00','1635','Donation',2500.00,'Income','Hassankutty V P','267',1,'Cash','','','','',NULL,'',0.00),(230,'2022-04-26 00:00:00','1636','Donation',500.00,'Income','Hamsu K V','268',1,'Cash','','','','',NULL,'',0.00),(231,'2022-04-26 00:00:00','1637','Donation',1750.00,'Income','Samad P C','269',1,'Cash','','','','',NULL,'',0.00),(232,'2022-04-26 00:00:00','1638','Donation',300.00,'Income','Ghani K P','270',1,'Cash','','','','',NULL,'',0.00),(233,'2022-04-26 00:00:00','1639','Donation',500.00,'Income','Balan V P','271',1,'Cash','','','','',NULL,'',0.00),(234,'2022-04-26 00:00:00','1640','Donation',50.00,'Income','KarthyayaniTeacher','272',1,'Cash','','','','',NULL,'',0.00),(235,'2022-04-26 00:00:00','1641','Donation',500.00,'Income','Sunil Chembayil','273',1,'Cash','','','','',NULL,'',0.00),(236,'2022-04-28 00:00:00','1642','Donation',1000.00,'Income','Ismail K K','274',1,'Cash','','','','',NULL,'',0.00),(237,'2022-04-26 00:00:00','1643','Donation',2500.00,'Income','Haris K T','275',1,'Cash','','','','',NULL,'',0.00),(238,'2022-04-26 00:00:00','1644','Donation',2500.00,'Income','Saleem K T','276',1,'Cash','','','','',NULL,'',0.00),(239,'2022-04-26 00:00:00','1645','Donation',2000.00,'Income','Samad K T','277',1,'Cash','','','','',NULL,'',0.00),(240,'2022-04-26 00:00:00','1646','Donation',1000.00,'Income','Shamil K T','278',1,'Cash','','','','',NULL,'',0.00),(241,'2022-04-26 00:00:00','1647','Donation',200.00,'Income','Shahal K T','279',1,'Cash','','','','',NULL,'',0.00),(242,'2022-04-26 00:00:00','1648','Donation',500.00,'Income','Fathima K T','280',1,'Cash','','','','',NULL,'',0.00),(243,'2022-04-26 00:00:00','1649','Donation',250.00,'Income','Aneesh K T','281',1,'Cash','','','','',NULL,'',0.00),(244,'2022-04-26 00:00:00','1650','Donation',1000.00,'Income','Eandutty/ Kunhu N','282',1,'Cash','','','','',NULL,'',0.00),(245,'2022-04-17 00:00:00','1651','Donation',0.00,'Income','Dr. Makbool R','283',1,'Cash','','','','',NULL,'',0.00),(246,'2022-04-17 00:00:00','1652','Donation',1500.00,'Income','Abdulla P K','284',1,'Cash','','','','',NULL,'',0.00),(247,'2022-04-17 00:00:00','1653','Donation',1000.00,'Income','Aboobacker T K','285',1,'Cash','','','','',NULL,'',0.00),(248,'2022-04-18 00:00:00','1654','Donation',1000.00,'Income','Bava Akal Pullooni','286',1,'Cash','','','','',NULL,'',0.00),(249,'2022-04-18 00:00:00','1655','Donation',1500.00,'Income','Noorjahan A','287',1,'Cash','','','','',NULL,'',0.00),(250,'2022-04-18 00:00:00','1656','Donation',5000.00,'Income','Prabhakaran E','288',1,'Cash','','','','',NULL,'',0.00),(251,'2022-04-25 00:00:00','1657','Donation',5000.00,'Income','Abdusamad Master','289',1,'Cash','','','','',NULL,'',0.00),(252,'2022-04-25 00:00:00','1658','Donation',2500.00,'Income','Dr. Abdulkader PT','290',1,'Cash','','','','',NULL,'',0.00),(253,'2022-04-25 00:00:00','1659','Donation',0.00,'Income','Thenukutty N ','291',1,'Bank','Cheque','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',2000.00),(254,'2022-04-26 00:00:00','1660','Donation',1000.00,'Income','Moiduttymaster R','292',1,'Cash','','','','',NULL,'',0.00),(255,'2022-04-27 00:00:00','1661','Donation',1000.00,'Income','Kunhimohamed T K','293',1,'Cash','','','','',NULL,'',0.00),(256,'2022-04-27 00:00:00','1662','Donation',1000.00,'Income','Kunhippa T P','294',1,'Cash','','','','',NULL,'',0.00),(257,'2022-04-27 00:00:00','1663','Donation',1000.00,'Income','Mohamedkutty','295',1,'Cash','','','','',NULL,'',0.00),(258,'2022-04-29 00:00:00','1664','Donation',3000.00,'Income','Ayoob M P','296',1,'Cash','','','','',NULL,'',0.00),(259,'2022-04-30 00:00:00','1665','Donation',5000.00,'Income','Shabna / Meeran','297',1,'Cash','','','','',NULL,'',0.00),(260,'2022-04-21 00:00:00','1751',' Monthly Subscription',13000.00,'Income','Dr. Makbool R','298',1,'Cash','','','','',NULL,'',0.00),(261,'2022-04-22 00:00:00','1752','Donation',2000.00,'Income','Yasir V M','299',1,'Bank','Transfer','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(262,'2022-04-22 00:00:00','1758','Donation',0.00,'Income','Mohamedmaster R','626',1,'Cash','','','','',NULL,'',0.00),(263,'2022-04-23 00:00:00','1754','Donation',2000.00,'Income','Haseena K','301',1,'Cash','','','','',NULL,'',0.00),(264,'2022-04-23 00:00:00','1755','Donation',2000.00,'Income','Koyamutty K V','302',1,'Cash','','','','',NULL,'',0.00),(265,'2022-04-24 00:00:00','1756','Donation',10000.00,'Income','Finos V P','303',1,'Cash','','','','',NULL,'',0.00),(266,'2022-04-24 00:00:00','1757','Donation',30000.00,'Income','Rayinkutty R','304',1,'Cash','','','','',NULL,'',0.00),(267,'2022-04-24 00:00:00','1758','Donation',5000.00,'Income','Fathimamohamed C','305',1,'Cash','','','','',NULL,'',0.00),(268,'2022-04-24 00:00:00','1759','Donation',5000.00,'Income','Jamsheerali VP','306',1,'Cash','','','','',NULL,'',0.00),(269,'2022-04-24 00:00:00','1760','Donation',5000.00,'Income','Alimon PA','307',1,'Cash','','','','',NULL,'',0.00),(270,'2022-04-24 00:00:00','1761','Donation',1000.00,'Income','Hassan P','308',1,'Cash','','','','',NULL,'',0.00),(271,'2022-04-24 00:00:00','1762','Donation',10000.00,'Income','Suneermohamed','309',1,'Bank','Transfer','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(272,'2022-04-25 00:00:00','1763','Donation',5000.00,'Income','Muneer M','310',1,'Cash','','','','',NULL,'',0.00),(273,'2022-04-25 00:00:00','1764','Donation',5000.00,'Income','Musthafa K V &Bro','311',1,'Cash','','','','',NULL,'',0.00),(274,'2022-04-25 00:00:00','1765','Donation',1500.00,'Income','Faisal K V','312',1,'Cash','','','','',NULL,'',0.00),(275,'2022-04-25 00:00:00','1766','Donation',5000.00,'Income','Shakir V M','313',1,'Cash','','','','',NULL,'',0.00),(276,'2022-05-25 00:00:00','1767','Donation',0.00,'Income','Fousiya V M','760',1,'Cash','','','','',NULL,'',0.00),(277,'2022-04-25 00:00:00','1768',' Monthly Subscription',12000.00,'Income','Naseema M V','315',1,'Cash','','','','',NULL,'',0.00),(278,'2022-04-25 00:00:00','1769',' Monthly Subscription',3000.00,'Income','Moideenkutty P K','316',1,'Cash','','','','',NULL,'',0.00),(279,'2022-04-25 00:00:00','1770',' Monthly Subscription',3000.00,'Income','Rajulshanis CP','317',1,'Cash','','','','',NULL,'',0.00),(280,'2022-04-25 00:00:00','1771',' Monthly Subscription',3000.00,'Income','Rifa shalees C P','318',1,'Cash','','','','',NULL,'',0.00),(281,'2022-04-25 00:00:00','1772',' Monthly Subscription',3000.00,'Income','Zainudheenmaster CP','319',1,'Cash','','','','',NULL,'',0.00),(282,'2022-04-25 00:00:00','1773','Donation',3000.00,'Income','Fidhasalu','320',1,'Cash','','','','',NULL,'',0.00),(283,'2022-04-25 00:00:00','1774','Donation',5000.00,'Income','Shiras C P','321',1,'Cash','','','','',NULL,'',0.00),(284,'2022-04-25 00:00:00','1775','Donation',5000.00,'Income','Fathahurahman P K','322',1,'Cash','','','','',NULL,'',0.00),(285,'2022-04-26 00:00:00','1776','Donation',3000.00,'Income','Aboobaker C T','323',1,'Cash','','','','',NULL,'',0.00),(286,'2022-04-26 00:00:00','1777','Donation',10000.00,'Income','Fasil K','324',1,'Cash','','','','',NULL,'',0.00),(287,'2022-04-26 00:00:00','1778','Donation',5000.00,'Income','Ibrahim C','325',1,'Cash','','','','',NULL,'',0.00),(288,'2022-04-26 00:00:00','1779','Donation',5000.00,'Income','Mohamed N','326',1,'Cash','','','','',NULL,'',0.00),(289,'2022-04-26 00:00:00','1780','Donation',5000.00,'Income','Abdul Naser CV','327',1,'Cash','','','','',NULL,'',0.00),(290,'2022-04-26 00:00:00','1781','Donation',3000.00,'Income','Kunhavu k','328',1,'Cash','','','','',NULL,'',0.00),(291,'2022-04-26 00:00:00','1782','Donation',1000.00,'Income','Muneer K K','329',1,'Cash','','','','',NULL,'',0.00),(292,'2022-04-26 00:00:00','1783','Donation',2000.00,'Income','Baputty P V','330',1,'Cash','','','','',NULL,'',0.00),(293,'2022-04-26 00:00:00','1784','Donation',1000.00,'Income','Ibrahimkutty TP','331',1,'Cash','','','','',NULL,'',0.00),(294,'2022-04-26 00:00:00','1785','Donation',1000.00,'Income','Shameer R P','332',1,'Cash','','','','',NULL,'',0.00),(295,'2022-04-26 00:00:00','1786','Donation',4500.00,'Income','Shahalrahman','333',1,'Cash','','','','',NULL,'',0.00),(296,'2022-04-26 00:00:00','1787','Donation',2500.00,'Income','Shamsudheen Charath','334',1,'Cash','','','','',NULL,'',0.00),(297,'2022-04-26 00:00:00','1788','Donation',5000.00,'Income','Abdurahman V M','335',1,'Cash','','','','',NULL,'',0.00),(298,'2022-04-26 00:00:00','1789','Donation',3000.00,'Income','Mohamed Kabeer M','336',1,'Cash','','','','',NULL,'',0.00),(299,'2022-04-26 00:00:00','1790','Donation',50000.00,'Income','Ameeer C M C','337',1,'Bank','Transfer','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(300,'2022-04-26 00:00:00','1791','Donation',10000.00,'Income','Ashraf Koat','338',1,'Cash','','','','',NULL,'',0.00),(301,'2022-04-27 00:00:00','1792','Donation',5000.00,'Income','Jasmirali','339',1,'Cash','','','','',NULL,'',0.00),(302,'2022-04-27 00:00:00','1793','Donation',5000.00,'Income','Mohamed N','340',1,'Cash','','','','',NULL,'',0.00),(303,'2022-04-27 00:00:00','1794','Donation',1500.00,'Income','Nasr=er T K','341',1,'Cash','','','','',NULL,'',0.00),(304,'2022-04-28 00:00:00','1795','Donation',2500.00,'Income','Bava M P','342',1,'Cash','','','','',NULL,'',0.00),(305,'2022-04-28 00:00:00','1796','Donation',25000.00,'Income','Mohamedalimaster &sons','343',1,'Cash','','','','',NULL,'',0.00),(306,'2022-04-28 00:00:00','1797','Donation',2000.00,'Income','Bava V P','344',1,'Cash','','','','',NULL,'',0.00),(307,'2022-04-28 00:00:00','1798','Donation',2000.00,'Income','Shamina Teacher','345',1,'Cash','','','','',NULL,'',0.00),(308,'2022-04-28 00:00:00','1799','Donation',5000.00,'Income','Riyas C p','346',1,'Bank','Transfer','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(309,'2022-04-27 00:00:00','1800','Donation',2000.00,'Income','Faisal Purathoor','347',1,'Cash','','','','',NULL,'',0.00),(310,'2022-04-22 00:00:00','.','..',0.00,'Income','Cancelled','348',1,'Cash','','','','',NULL,'',0.00),(311,'2022-04-22 00:00:00','1802','Donation',1000.00,'Income','Zakariya,KHMHS ','349',1,'Cash','','','','',NULL,'',0.00),(312,'2022-04-22 00:00:00','1803','Donation',2000.00,'Income','SafeedaTeacher,KHMHS','350',1,'Cash','','','','',NULL,'',0.00),(313,'2022-04-22 00:00:00','1804','Donation',2000.00,'Income','Sukumaran master,KHMHS','351',1,'Cash','','','','',NULL,'',0.00),(314,'2022-04-22 00:00:00','1805','Donation',2000.00,'Income','Omana S,KHMHS','352',1,'Cash','','','','',NULL,'',0.00),(315,'2022-04-22 00:00:00','1806','Donation',500.00,'Income','Shafini,KHMHS','353',1,'Cash','','','','',NULL,'',0.00),(316,'2022-04-23 00:00:00','1807','Donation',2000.00,'Income','Kanhikoth Electricals','354',1,'Cash','','','','',NULL,'',0.00),(317,'2022-04-23 00:00:00','1808','Donation',2000.00,'Income','Azhar Kanhikoth','355',1,'Cash','','','','',NULL,'',0.00),(318,'2022-04-23 00:00:00','1809','Donation',7500.00,'Income','Mohamedmon','356',1,'Cash','','','','',NULL,'',0.00),(319,'2022-04-23 00:00:00','1810','Donation',500.00,'Income','Irshad C N','357',1,'Cash','','','','',NULL,'',0.00),(320,'2022-04-23 00:00:00','1811','Donation',3000.00,'Income','Rashhed M P','358',1,'Cash','','','','',NULL,'',0.00),(321,'2022-04-23 00:00:00','1812','Donation',4000.00,'Income','VaheedaTeacher,KHMHS','359',1,'Cash','','','','',NULL,'',0.00),(322,'2022-04-23 00:00:00','1813','Donation',500.00,'Income','Babu I A, KHMHS','360',1,'Cash','','','','',NULL,'',0.00),(323,'2022-04-23 00:00:00','1814','Donation',1000.00,'Income','Hyjas,KHMHS','361',1,'Cash','','','','',NULL,'',0.00),(324,'2022-04-23 00:00:00','1815','Donation',500.00,'Income','SuneeraTeacher,KHMHS','362',1,'Cash','','','','',NULL,'',0.00),(325,'2022-04-23 00:00:00','1816','Donation',1000.00,'Income','Febin,KHMHS','363',1,'Cash','','','','',NULL,'',0.00),(326,'2022-04-23 00:00:00','1817','Donation',1500.00,'Income','Nusrath,KHMHS','364',1,'Cash','','','','',NULL,'',0.00),(327,'2022-04-23 00:00:00','1818','Donation',1500.00,'Income','Jaseera Annassery, KHMHS','365',1,'Cash','','','','',NULL,'',0.00),(328,'2022-04-23 00:00:00','1819','Donation',10000.00,'Income','Adam Sajid,KHMHS','366',1,'Cash','','','','',NULL,'',0.00),(329,'2022-04-23 00:00:00','1820','Donation',1000.00,'Income','Abdul Naser V K','367',1,'Cash','','','','',NULL,'',0.00),(330,'2022-04-23 00:00:00','1821','Donation',750.00,'Income','Shanavas,KHMHS','368',1,'Cash','','','','',NULL,'',0.00),(331,'2022-04-23 00:00:00','1822','Donation',500.00,'Income','Shareefa,Alathiyur KHMHS','369',1,'Cash','','','','',NULL,'',0.00),(332,'2022-04-23 00:00:00','1823','Donation',1000.00,'Income','Sumayya,KHMHS','370',1,'Cash','','','','',NULL,'',0.00),(333,'2022-04-24 00:00:00','1824','Donation',2500.00,'Income','Sumayyatyh,KHMHS','371',1,'Cash','','','','',NULL,'',0.00),(334,'2022-04-24 00:00:00','1825','Donation',1500.00,'Income','Swalih K V ,KHMHS','372',1,'Cash','','','','',NULL,'',0.00),(335,'2022-04-24 00:00:00','1826','Donation',2000.00,'Income','Abid B P. Angadi. ','373',1,'Cash','','','','',NULL,'',0.00),(336,'2022-04-24 00:00:00','1827','Donation',500.00,'Income','Abdul Latheef ,B P Angadi','374',1,'Cash','','','','',NULL,'',0.00),(337,'2022-04-24 00:00:00','1828','Donation',1000.00,'Income','Ishak Ali,Vettam','375',1,'Cash','','','','',NULL,'',0.00),(338,'2022-04-24 00:00:00','1829','Donation',500.00,'Income','Saleem Master CP','376',1,'Cash','','','','',NULL,'',0.00),(339,'2022-04-24 00:00:00','1830','Donation',2200.00,'Income','Shaharban V M,KHMHS','377',1,'Cash','','','','',NULL,'',0.00),(340,'2022-04-25 00:00:00','1831','Donation',500.00,'Income','Joy Mamalayil,KHMHS','378',1,'Cash','','','','',NULL,'',0.00),(341,'2022-04-25 00:00:00','1832','Donation',2000.00,'Income','Shamma,KHMHS','379',1,'Cash','','','','',NULL,'',0.00),(342,'2022-04-25 00:00:00','1833','Donation',2000.00,'Income','Soniya Teacher,KHMHS','380',1,'Cash','','','','',NULL,'',0.00),(343,'2022-04-25 00:00:00','1834','Donation',1000.00,'Income','Dhavya,KHMHS','381',1,'Cash','','','','',NULL,'',0.00),(344,'2022-04-25 00:00:00','1835','Donation',1000.00,'Income','Abdul Gafoor I P,KHMHS','382',1,'Cash','','','','',NULL,'',0.00),(345,'2022-04-25 00:00:00','1836','Donation',500.00,'Income','Hafsath A P,KHMHS','383',1,'Cash','','','','',NULL,'',0.00),(346,'2022-04-25 00:00:00','1837','Donation',1000.00,'Income','Raihanath,Muttanur,KHMHS','384',1,'Cash','','','','',NULL,'',0.00),(347,'2022-04-25 00:00:00','1838','Donation',1000.00,'Income','Fuad Moiden,KHMHS','385',1,'Cash','','','','',NULL,'',0.00),(348,'2022-04-26 00:00:00','1839','Donation',1000.00,'Income','Saleena A,KHMHS','386',1,'Cash','','','','',NULL,'',0.00),(349,'2022-04-26 00:00:00','1840','Donation',1000.00,'Income','Abdurasheed Master,KHMHS','387',1,'Cash','','','','',NULL,'',0.00),(350,'2022-04-26 00:00:00','1841','Donation',500.00,'Income','Muneera,KHMHS','388',1,'Cash','','','','',NULL,'',0.00),(351,'2022-04-26 00:00:00','1842','Donation',500.00,'Income','Risana ,KHMHS','389',1,'Cash','','','','',NULL,'',0.00),(352,'2022-04-26 00:00:00','1843','Donation',750.00,'Income','Sajir,M ,KHMHS','390',1,'Cash','','','','',NULL,'',0.00),(353,'2022-04-26 00:00:00','1844','Donation',500.00,'Income','Jaleela,KHMHS','391',1,'Cash','','','','',NULL,'',0.00),(354,'2022-04-26 00:00:00','1845','Donation',500.00,'Income','Kadeeja Mayyeri,MMHS Kootayi','392',1,'Cash','','','','',NULL,'',0.00),(355,'2022-04-26 00:00:00','1846','Donation',1000.00,'Income','Fathima Vettam,KHMHS','393',1,'Cash','','','','',NULL,'',0.00),(356,'2022-04-26 00:00:00','1847','Donation',2000.00,'Income','Prajula,KHMHS','394',1,'Cash','','','','',NULL,'',0.00),(357,'2022-04-26 00:00:00','1848','Donation',2000.00,'Income','Afrah ,KHMHS','395',1,'Cash','','','','',NULL,'',0.00),(358,'2022-04-26 00:00:00','1849','Donation',1000.00,'Income','Jamsad TP,','396',1,'Cash','','','','',NULL,'',0.00),(359,'2022-04-26 00:00:00','1850','Donation',3000.00,'Income','Shamooma T P,KHMHS','397',1,'Cash','','','','',NULL,'',0.00),(360,'2022-04-26 00:00:00','1851','Donation',100.00,'Income','Shukoor KT','398',1,'Cash','','','','',NULL,'',0.00),(361,'2022-04-27 00:00:00','1852','Donation',3000.00,'Income','Koya K V, Thavanoor','399',1,'Cash','','','','',NULL,'',0.00),(362,'2022-04-27 00:00:00','1853','Donation',3000.00,'Income','Saiduttyhaji K V, Puthuppally','400',1,'Cash','','','','',NULL,'',0.00),(363,'2022-04-27 00:00:00','1854','Donation',2500.00,'Income','Sakeerhusain KT','401',1,'Cash','','','','',NULL,'',0.00),(364,'2022-04-27 00:00:00','1855','Donation',2000.00,'Income','Mujeeb K T','402',1,'Cash','','','','',NULL,'',0.00),(365,'2022-04-27 00:00:00','1856','Donation',2000.00,'Income','Suhara K T','403',1,'Cash','','','','',NULL,'',0.00),(366,'2022-04-27 00:00:00','1857','Donation',2000.00,'Income','Yoosaf K T','404',1,'Cash','','','','',NULL,'',0.00),(367,'2022-04-27 00:00:00','1858','Donation',500.00,'Income','Shafi K T','405',1,'Cash','','','','',NULL,'',0.00),(368,'2022-04-27 00:00:00','1859','Donation',500.00,'Income','shareer K T','406',1,'Cash','','','','',NULL,'',0.00),(369,'2022-04-27 00:00:00','1860','Donation',500.00,'Income','Manu KT','407',1,'Cash','','','','',NULL,'',0.00),(370,'2022-04-27 00:00:00','1861','Donation',4000.00,'Income','Shareef K K','408',1,'Cash','','','','',NULL,'',0.00),(371,'2022-04-28 00:00:00','1862','Donation',8000.00,'Income','Moidutty K K','409',1,'Cash','','','','',NULL,'',0.00),(372,'2022-04-29 00:00:00','1863','Donation',2500.00,'Income','Ramla K V','410',1,'Cash','','','','',NULL,'',0.00),(373,'2022-04-29 00:00:00','1864','Donation',2500.00,'Income','Ikbal Master K T','411',1,'Cash','','','','',NULL,'',0.00),(374,'2022-04-29 00:00:00','1865','Donation',2000.00,'Income','Mohamedali/Alibava CN','412',1,'Cash','','','','',NULL,'',0.00),(375,'2022-04-29 00:00:00','1866','Donation',1000.00,'Income','Jalal K K','413',1,'Cash','','','','',NULL,'',0.00),(376,'2022-04-29 00:00:00','1867','Donation',1000.00,'Income','Kunhu KK','414',1,'Cash','','','','',NULL,'',0.00),(377,'2022-04-29 00:00:00','1868','Donation',500.00,'Income','Nisar K T','415',1,'Cash','','','','',NULL,'',0.00),(378,'2022-04-25 00:00:00','1901','Donation',2000.00,'Income','Ayshabeegam,KHMHS','416',1,'Cash','','','','',NULL,'',0.00),(379,'2022-04-26 00:00:00','1902','Donation',1000.00,'Income','Sameena,Chamravattam,KHMHS','417',1,'Cash','','','','',NULL,'',0.00),(380,'2022-04-25 00:00:00','1903','Donation',1000.00,'Income','Raheela CN,KHMHS','418',1,'Cash','','','','',NULL,'',0.00),(381,'2022-04-25 00:00:00','1904','Donation',1500.00,'Income','FidhaTeacher,KHMHS','419',1,'Cash','','','','',NULL,'',0.00),(382,'2022-04-25 00:00:00','1905','Donation',10000.00,'Income','Dr.Saleena K K, Mangalam','420',1,'Cash','','','','',NULL,'',0.00),(383,'2022-04-25 00:00:00','1906','Donation',2000.00,'Income','Abdulla, KHMHS','421',1,'Cash','','','','',NULL,'',0.00),(384,'2022-04-27 00:00:00','1907','Donation',1000.00,'Income','Shoukathali,KHMHS','422',1,'Cash','','','','',NULL,'',0.00),(385,'2022-04-27 00:00:00','1908','Donation',2000.00,'Income','Suresh K P ,KHMHS','423',1,'Cash','','','','',NULL,'',0.00),(386,'2022-04-28 00:00:00','1909','Donation',5000.00,'Income','Abdurasak T P ,KHMHS','424',1,'Cash','','','','',NULL,'',0.00),(387,'2022-04-27 00:00:00','1910','Donation',1000.00,'Income','Jubairya, KHMHS','425',1,'Cash','','','','',NULL,'',0.00),(388,'2022-04-28 00:00:00','1911','Donation',1000.00,'Income','saleena,Murivazhikkal,KHMHS','426',1,'Cash','','','','',NULL,'',0.00),(389,'2022-04-28 00:00:00','1912','Donation',1500.00,'Income','Naseema.KHMHS','427',1,'Cash','','','','',NULL,'',0.00),(390,'2022-04-28 00:00:00','1913','Donation',2500.00,'Income','Shafi,KHMHS','428',1,'Cash','','','','',NULL,'',0.00),(391,'2022-04-25 00:00:00','1914','Donation',2000.00,'Income','MaseeraPuthukayil,KHMHS','429',1,'Cash','','','','',NULL,'',0.00),(392,'2022-04-28 00:00:00','1915','Donation',6000.00,'Income','Jaseel KHMHS','430',1,'Cash','','','','',NULL,'',0.00),(393,'2022-04-28 00:00:00','1916','Donation',2000.00,'Income','Jeeja Teacher,KHMHS','431',1,'Cash','','','','',NULL,'',0.00),(394,'2022-04-28 00:00:00','1917','Donation',10000.00,'Income','shareef,Valamaruthur,KHMHS','432',1,'Cash','','','','',NULL,'',0.00),(395,'2022-04-29 00:00:00','1918','Donation',1000.00,'Income','Ramakrishnan C,KHMHS','433',1,'Cash','','','','',NULL,'',0.00),(396,'2022-04-29 00:00:00','1919','Donation',2000.00,'Income','Zubair TP, KHMHS','434',1,'Cash','','','','',NULL,'',0.00),(397,'2022-04-29 00:00:00','1920','Donation',10000.00,'Income','Zubair,KHMHS','435',1,'Cash','','','','',NULL,'',0.00),(398,'2022-04-29 00:00:00','1921','Donation',2000.00,'Income','SalahudheenK,KHMHS','436',1,'Cash','','','','',NULL,'',0.00),(399,'2022-04-29 00:00:00','1922','Donation',5000.00,'Income','Abdusamad,BP Angadi,KHMHS','437',1,'Cash','','','','',NULL,'',0.00),(400,'2022-04-29 00:00:00','1923','Donation',7000.00,'Income','Ameer E.KHMHS','438',1,'Cash','','','','',NULL,'',0.00),(401,'2022-04-29 00:00:00','1924','Donation',2000.00,'Income','Riyas U,KHMHS','439',1,'Cash','','','','',NULL,'',0.00),(402,'2022-04-29 00:00:00','1925','Donation',5000.00,'Income','Naseda E,KHMHS','440',1,'Cash','','','','',NULL,'',0.00),(403,'2022-04-29 00:00:00','1926','Donation',500.00,'Income','Lukman K P,KHMHS','441',1,'Cash','','','','',NULL,'',0.00),(404,'2022-04-29 00:00:00','1927','Donation',1000.00,'Income','Mirdas,KHMHS','442',1,'Cash','','','','',NULL,'',0.00),(405,'2022-04-29 00:00:00','1928','Donation',1000.00,'Income','Jamsheer I P,KHMHS','443',1,'Cash','','','','',NULL,'',0.00),(406,'2022-04-29 00:00:00','1929','Donation',1000.00,'Income','RajaniTeacher,KHMHS','444',1,'Cash','','','','',NULL,'',0.00),(407,'2022-04-29 00:00:00','1930','Donation',500.00,'Income','Sreeja Teacher,KHMHS','445',1,'Cash','','','','',NULL,'',0.00),(408,'2022-04-29 00:00:00','1931','Donation',1000.00,'Income','Jasiya, KHMHS','446',1,'Cash','','','','',NULL,'',0.00),(409,'2022-04-29 00:00:00','1932','Donation',1000.00,'Income','Thasleenabanu,KHMHS','447',1,'Cash','','','','',NULL,'',0.00),(410,'2022-04-29 00:00:00','1933','Donation',1000.00,'Income','Mohamed ashraf E,KHMHS','448',1,'Cash','','','','',NULL,'',0.00),(411,'2022-04-30 00:00:00','1934','Donation',1000.00,'Income','Ramla Alingal,KHMHS','449',1,'Cash','','','','',NULL,'',0.00),(412,'2022-04-30 00:00:00','1935','Donation',1000.00,'Income','Salih P K,KHMHS','450',1,'Cash','','','','',NULL,'',0.00),(413,'2022-04-30 00:00:00','1936','Donation',10000.00,'Income','Abdulrahman KHMHS','451',1,'Cash','','','','',NULL,'',0.00),(414,'2022-04-30 00:00:00','1937','Donation',5000.00,'Income','Saleem,KHMHS','452',1,'Cash','','','','',NULL,'',0.00),(415,'2022-04-30 00:00:00','1938','Donation',1000.00,'Income','Anas,KHMHS','453',1,'Cash','','','','',NULL,'',0.00),(416,'2022-04-30 00:00:00','1939','Donation',1000.00,'Income','Muneer,Alathiyur. KHMHS','454',1,'Cash','','','','',NULL,'',0.00),(417,'2022-04-17 00:00:00','6351','Donation',1000.00,'Income','Beerankutty,POokaitha','455',1,'Cash','','','','',NULL,'',0.00),(418,'2022-04-17 00:00:00','6352','Donation',500.00,'Income','Aboobacker CP','456',1,'Cash','','','','',NULL,'',0.00),(419,'2022-04-17 00:00:00','6353','Donation',100.00,'Income','Basheer A','457',1,'Cash','','','','',NULL,'',0.00),(420,'2022-04-25 00:00:00','6354','Donation',200.00,'Income','Mohamed Koya','458',1,'Cash','','','','',NULL,'',0.00),(421,'2022-04-25 00:00:00','6355','Donation',200.00,'Income','samad Master','459',1,'Cash','','','','',NULL,'',0.00),(422,'2022-04-25 00:00:00','6356','-',0.00,'Income','Cancell','460',1,'Cash','','','','',NULL,'',0.00),(423,'2022-04-25 00:00:00','6357','Donation',200.00,'Income','Marakkar','461',1,'Cash','','','','',NULL,'',0.00),(424,'2022-04-25 00:00:00','6358','Donation',500.00,'Income','Kunhikammu R','462',1,'Cash','','','','',NULL,'',0.00),(425,'2022-04-25 00:00:00','6359','Donation',500.00,'Income','Naseeda R','463',1,'Cash','','','','',NULL,'',0.00),(426,'2022-04-26 00:00:00','6360','Donation',500.00,'Income','Saidalihaji','464',1,'Cash','','','','',NULL,'',0.00),(427,'2022-04-27 00:00:00','6361','Donation',200.00,'Income','Hamsa','465',1,'Cash','','','','',NULL,'',0.00),(428,'2022-04-27 00:00:00','6362','Donation',1000.00,'Income','Seethi','466',1,'Cash','','','','',NULL,'',0.00),(429,'2022-04-29 00:00:00','6363','Donation',500.00,'Income','Mohamed / Bava','467',1,'Cash','','','','',NULL,'',0.00),(430,'2022-04-28 00:00:00','6365','Donation',2200.00,'Income','Bava KT','468',1,'Cash','','','','',NULL,'',0.00),(431,'2022-04-29 00:00:00','6366','Donation',1000.00,'Income','Alikutty T P','469',1,'Cash','','','','',NULL,'',0.00),(432,'2022-04-30 00:00:00','6367','Donation',500.00,'Income','Kunhimoideenkutty','470',1,'Cash','','','','',NULL,'',0.00),(433,'2022-04-18 00:00:00','6401','Donation',500.00,'Income','Bava V M','471',1,'Cash','','','','',NULL,'',0.00),(434,'2022-04-18 00:00:00','6402',' Monthly Subscription',1200.00,'Income','Bava V M','472',1,'Cash','','','','',NULL,'',0.00),(435,'2022-04-18 00:00:00','6403','Donation',1000.00,'Income','Mohamedali Haji N','473',1,'Cash','','','','',NULL,'',0.00),(436,'2022-04-19 00:00:00','6404','Donation',500.00,'Income','Assainar Haji PK','474',1,'Cash','','','','',NULL,'',0.00),(437,'2022-04-19 00:00:00','6405','Donation',1000.00,'Income','Hamsa T','475',1,'Cash','','','','',NULL,'',0.00),(438,'2022-04-19 00:00:00','6406','Donation',500.00,'Income','Hamsa E','476',1,'Cash','','','','',NULL,'',0.00),(439,'2022-04-19 00:00:00','6407','Donation',1000.00,'Income','Hamsa V A','477',1,'Cash','','','','',NULL,'',0.00),(440,'2022-04-19 00:00:00','6408','Donation',500.00,'Income','Naseera R','478',1,'Cash','','','','',NULL,'',0.00),(441,'2022-04-19 00:00:00','6409',' Monthly Subscription',600.00,'Income','Abid Master','479',1,'Cash','','','','',NULL,'',0.00),(442,'2022-04-21 00:00:00','6410','Donation',500.00,'Income','Asya V M','480',1,'Cash','','','','',NULL,'',0.00),(443,'2022-04-21 00:00:00','6411','Donation',500.00,'Income','Mufeed V M','481',1,'Cash','','','','',NULL,'',0.00),(444,'2022-04-21 00:00:00','6412','Donation',1000.00,'Income','Ibrahim V P','482',1,'Cash','','','','',NULL,'',0.00),(445,'2022-04-22 00:00:00','6413','Donation',1000.00,'Income','Anwar R','483',1,'Cash','','','','',NULL,'',0.00),(446,'2022-04-22 00:00:00','6414','Donation',500.00,'Income','Asya','484',1,'Cash','','','','',NULL,'',0.00),(447,'2022-04-24 00:00:00','6415',' Monthly Subscription',1000.00,'Income','Yahutty M P','485',1,'Cash','','','','',NULL,'',0.00),(448,'2022-04-24 00:00:00','6416',' Monthly Subscription',250.00,'Income','Abdul Hamed PK','486',1,'Cash','','','','',NULL,'',0.00),(449,'2022-04-24 00:00:00','6417','Donation',500.00,'Income','Rasak C P','487',1,'Cash','','','','',NULL,'',0.00),(450,'2022-04-24 00:00:00','6418',' Monthly Subscription',500.00,'Income','Shafeek MV','488',1,'Cash','','','','',NULL,'',0.00),(451,'2022-04-24 00:00:00','6419','Donation',700.00,'Income','Abdullahaji','489',1,'Cash','','','','',NULL,'',0.00),(452,'2022-04-24 00:00:00','6420','Donation',1000.00,'Income','Shoukath','490',1,'Cash','','','','',NULL,'',0.00),(453,'2022-04-25 00:00:00','6421','Donation',1000.00,'Income','Aneesh K','491',1,'Cash','','','','',NULL,'',0.00),(454,'2022-04-25 00:00:00','6422','Donation',500.00,'Income','Umer P K','492',1,'Cash','','','','',NULL,'',0.00),(455,'2022-04-25 00:00:00','6423','Donation',1000.00,'Income','Aboobakker Sidheeq K T','493',1,'Cash','','','','',NULL,'',0.00),(456,'2022-04-25 00:00:00','6424','Donation',500.00,'Income','Aboobakker P','494',1,'Cash','','','','',NULL,'',0.00),(457,'2022-04-25 00:00:00','6425','Donation',2000.00,'Income','Abdulsalam TP','495',1,'Cash','','','','',NULL,'',0.00),(458,'2022-04-25 00:00:00','6426',' Monthly Subscription',1200.00,'Income','ManafM P','496',1,'Cash','','','','',NULL,'',0.00),(459,'2022-04-25 00:00:00','6427','Donation',500.00,'Income','Bava R M','497',1,'Cash','','','','',NULL,'',0.00),(460,'2022-04-25 00:00:00','6428','Donation',1000.00,'Income','Fathima CP','498',1,NULL,'','','','',NULL,'',0.00),(461,'2022-04-25 00:00:00','6429','Donation',1000.00,'Income','Jumana','499',1,'Cash','','','','',NULL,'',0.00),(462,'2022-04-25 00:00:00','6430','Donation',1000.00,'Income','Sainudheen C P','500',1,'Cash','','','','',NULL,'',0.00),(463,'2022-04-25 00:00:00','6431','Donation',1000.00,'Income','Musfira CP','501',1,'Cash','','','','',NULL,'',0.00),(464,'2022-04-25 00:00:00','6432','Donation',1000.00,'Income','Mohamed Ashraf T P','502',1,'Cash','','','','',NULL,'',0.00),(465,'2022-04-25 00:00:00','6433','Donation',1000.00,'Income','Mohamed Ayub PK','503',1,'Cash','','','','',NULL,'',0.00),(466,'2022-04-26 00:00:00','6434','Donation',200.00,'Income','Muneer R','504',1,'Cash','','','','',NULL,'',0.00),(467,'2022-04-26 00:00:00','6435','Donation',500.00,'Income','Abdurahman KM','505',1,'Cash','','','','',NULL,'',0.00),(468,'2022-04-27 00:00:00','6436','Donation',1000.00,'Income','Hamsahaji M','506',1,'Cash','','','','',NULL,'',0.00),(469,'2022-04-27 00:00:00','6437',' Monthly Subscription',250.00,'Income','Postoffice','507',1,'Cash','','','','',NULL,'',0.00),(470,'2022-04-28 00:00:00','6438','Donation',1000.00,'Income','Mohamed suhaib TK','508',1,'Cash','','','','',NULL,'',0.00),(471,'2022-04-28 00:00:00','6439','Donation',1000.00,'Income','Mohamedshareef PK','509',1,'Cash','','','','',NULL,'',0.00),(472,'2022-04-28 00:00:00','6440',' Monthly Subscription',2000.00,'Income','Kunhibava KV','510',1,'Cash','','','','',NULL,'',0.00),(473,'2022-04-28 00:00:00','6441',' Monthly Subscription',1000.00,'Income','AbdulMajeed K V','511',1,'Cash','','','','',NULL,'',0.00),(474,'2022-04-28 00:00:00','6442',' Monthly Subscription',1000.00,'Income','Jaseem K V','512',1,'Cash','','','','',NULL,'',0.00),(475,'2022-04-28 00:00:00','6443','Donation',500.00,'Income','AbdulAsees K','513',1,'Cash','','','','',NULL,'',0.00),(476,'2022-04-29 00:00:00','6444','Donation',500.00,'Income','Thasneem','514',1,'Cash','','','','',NULL,'',0.00),(477,'2022-04-29 00:00:00','6445','Donation',1000.00,'Income','Kunhimon C T','515',1,'Cash','','','','',NULL,'',0.00),(478,'2022-04-30 00:00:00','6446','Donation',1000.00,'Income','Aboobakker M','516',1,'Cash','','','','',NULL,'',0.00),(479,'2022-04-21 00:00:00','6451','Donation',200.00,'Income','Hanoona T','517',1,'Cash','','','','',NULL,'',0.00),(480,'2022-04-27 00:00:00','6452','Donation',5000.00,'Income','Abdul Gafoor N','518',1,'Cash','','','','',NULL,'',0.00),(481,'2022-06-24 00:00:00','6453','Donation',500.00,'Income','Bushra Annassery','519',1,'Cash','','','','',NULL,'',0.00),(482,'2022-04-26 00:00:00','6454','Donation',250.00,'Income','Santhosh, KHMHS','520',1,'Cash','','','','',NULL,'',0.00),(483,'2022-04-25 00:00:00','6455','Donation',500.00,'Income','Ashiq, KHMHS','521',1,'Cash','','','','',NULL,'',0.00),(484,'2022-04-26 00:00:00','6456','Donation',200.00,'Income','Najma,KHMHS','522',1,'Cash','','','','',NULL,'',0.00),(485,'2022-04-25 00:00:00','6457','Donation',500.00,'Income','Asifa,KHMHS','523',1,'Cash','','','','',NULL,'',0.00),(486,'2022-04-27 00:00:00','6458','Donation',500.00,'Income','Abdul jabbar,KHMHS','524',1,'Cash','','','','',NULL,'',0.00),(487,'2022-04-28 00:00:00','6459','Donation',500.00,'Income','Asmabi MP,KHMHS','525',1,'Cash','','','','',NULL,'',0.00),(488,'2022-04-29 00:00:00','6460','Donation',0.00,'Income','Mufsil ,KHMHs','526',1,'Cash','','','','',NULL,'',0.00),(489,'2022-04-29 00:00:00','6461','Donation',500.00,'Income','Muhsina ,KHMHS','527',1,'Cash','','','','',NULL,'',0.00),(490,'2022-04-29 00:00:00','6462','Donation',500.00,'Income','Shahid, KHMHS','528',1,'Cash','','','','',NULL,'',0.00),(491,'2022-04-29 00:00:00','6463','Donation',100.00,'Income','Ashifa C V. KHMHS','529',1,'Cash','','','','',NULL,'',0.00),(492,'2022-04-29 00:00:00','6464','Donation',500.00,'Income','Sunatha, KHMHS','530',1,'Cash','','','','',NULL,'',0.00),(493,'2022-04-30 00:00:00','6465','Donation',500.00,'Income','Muneer Alingal,KHMHS','531',1,'Cash','','','','',NULL,'',0.00),(494,'2022-04-30 00:00:00','6466','Donation',500.00,'Income','Satheesh, KHMHS','532',1,'Cash','','','','',NULL,'',0.00),(495,'2022-04-01 00:00:00','1','Homecare Refreshment',-240.00,'Expense','Shilpa','533',1,'Cash','','','','',NULL,'',0.00),(496,'2022-04-01 00:00:00','2','Salary',-15000.00,'Expense','Hasna ','534',1,'Cash','','','','',NULL,'',0.00),(497,'2022-04-02 00:00:00','3','Homecare Refreshment',-260.00,'Expense','Shilpa','535',1,'Cash','','','','',NULL,'',0.00),(498,'2022-04-03 00:00:00','4','Salary',-8100.00,'Expense','Shilpa','536',1,'Cash','','','','',NULL,'',0.00),(499,'2022-04-04 00:00:00','5','Homecare Refreshment',-75.00,'Expense','Shilpa','537',1,'Cash','','','','',NULL,'',0.00),(500,'2022-04-04 00:00:00','6','Vehicle Expense',-500.00,'Expense','Fidha Petrolium','538',1,'Cash','','','','',NULL,'',0.00),(501,'2022-04-05 00:00:00','7','Salary',-2500.00,'Expense','Radha','539',1,'Cash','','','','',NULL,'',0.00),(502,'2022-04-05 00:00:00','8','Homecare Refreshment',-80.00,'Expense','Shilpa','540',1,'Cash','','','','',NULL,'',0.00),(503,'2022-04-05 00:00:00','9','Salary',-10800.00,'Expense','Musthafa K P','541',1,'Cash','','','','',NULL,'',0.00),(504,'2022-04-06 00:00:00','10','Homecare Refreshment',-150.00,'Expense','Shilpa','542',1,'Cash','','','','',NULL,'',0.00),(505,'2022-04-06 00:00:00','11','Salary',-8000.00,'Expense','Mohamed Yoosaf V P','543',1,'Cash','','','','',NULL,'',0.00),(506,'2022-04-06 00:00:00','12','Salary',-3150.00,'Expense','Mohamed Rafi','544',1,'Cash','','','','',NULL,'',0.00),(507,'2022-04-06 00:00:00','13','Ambulance',-810.00,'Expense','Mohamed Rafi','545',1,'Cash','','','','',NULL,'',0.00),(508,'2022-04-07 00:00:00','14','Salary',-5625.00,'Expense','Smitha','546',1,'Cash','','','','',NULL,'',0.00),(509,'2022-04-07 00:00:00','15','D H C Fees',-3000.00,'Expense','Dr.Majidha','803',1,'Cash','','','','',NULL,'',0.00),(510,'2022-04-07 00:00:00','16','Homecare Refreshment',-170.00,'Expense','Shilpa','548',1,'Cash','','','','',NULL,'',0.00),(511,'2022-04-08 00:00:00','17','Homecare Refreshment',-60.00,'Expense','Musthafa K P','549',1,'Cash','','','','',NULL,'',0.00),(512,'2022-04-09 00:00:00','18','Homecare Refreshment',-60.00,'Expense','Musthafa K P','550',1,'Cash','','','','',NULL,'',0.00),(513,'2022-04-09 00:00:00','19','Vehicle Expense',-2000.00,'Expense','K P K Petrolium','551',1,'Cash','','','','',NULL,'',0.00),(514,'2022-04-09 00:00:00','20','Missallanios Expense',-1600.00,'Expense','Kanhikoth Electrical','552',1,'Cash','','','','',NULL,'',0.00),(515,'2022-04-11 00:00:00','21','Homecare Refreshment',-90.00,'Expense','Shilpa','553',1,'Cash','','','','',NULL,'',0.00),(516,'2022-04-12 00:00:00','22','Printing & Stationary',-80.00,'Expense','Mohamed Yoosaf','554',1,'Cash','','','','',NULL,'',0.00),(517,'2022-04-13 00:00:00','23','Homecare Refreshment',-60.00,'Expense','Shilpa','555',1,'Cash','','','','',NULL,'',0.00),(518,'2022-04-13 00:00:00','24','Medicines',-6212.00,'Expense','Kims Pharma','556',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(519,'2022-04-13 00:00:00','25','Medicines',-1032.00,'Expense','Kims Pharma','692',1,'Cash','','','','',NULL,'',0.00),(520,'2022-04-13 00:00:00','26','Medicines',-3861.00,'Expense','Kims Medical Agencies','693',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(521,'2022-04-14 00:00:00','27','Homecare Refreshment',-65.00,'Expense','Shilpa','559',1,'Cash','','','','',NULL,'',0.00),(522,'2022-04-14 00:00:00','27','Homecare Refreshment',0.00,'Expense','Shilpa','606',1,'Cash','','','','',NULL,'',0.00),(523,'2022-04-15 00:00:00','28','Printing & Stationary',-70.00,'Expense','Mohamed Yoosaf','561',1,'Cash','','','','',NULL,'',0.00),(524,'2022-04-17 00:00:00','29','Homecare Refreshment',-120.00,'Expense','Mustahafa','562',1,'Cash','','','','',NULL,'',0.00),(525,'2022-04-30 00:00:00','30','Homecare Refreshment',-85.00,'Expense','Musthafa K P','563',1,'Cash','','','','',NULL,'',0.00),(526,'2022-04-19 00:00:00','31','Homecare Refreshment',-65.00,'Expense','Sreenitha','564',1,'Cash','','','','',NULL,'',0.00),(527,'2022-04-20 00:00:00','33','Homecare Refreshment',-160.00,'Expense','Shilpa','565',1,'Cash','','','','',NULL,'',0.00),(528,'2022-04-21 00:00:00','34','Homecare Refreshment',-120.00,'Expense','Shilpa','566',1,'Cash','','','','',NULL,'',0.00),(529,'2022-04-23 00:00:00','35','Homecare Refreshment',-70.00,'Expense','Shilpa','567',1,'Cash','','','','',NULL,'',0.00),(530,'2022-04-23 00:00:00','36','Telephone Charge',-150.00,'Expense','Shilpa','568',1,'Cash','','','','',NULL,'',0.00),(531,'2022-04-23 00:00:00','37','Printing & Stationary',-540.00,'Expense','M I P','569',1,'Cash','','','','',NULL,'',0.00),(532,'2022-04-23 00:00:00','38','Ambulance',-500.00,'Expense','Benzy Petolium','570',1,'Cash','','','','',NULL,'',0.00),(533,'2022-04-23 00:00:00','39','Vehicle Expense',-2000.00,'Expense','K P K Petrolium','571',1,'Cash','','','','',NULL,'',0.00),(534,'2022-04-24 00:00:00','40','Homecare Refreshment',-80.00,'Expense','Shilpa','572',1,'Cash','','','','',NULL,'',0.00),(535,'2022-04-25 00:00:00','41','Homecare Refreshment',-90.00,'Expense','Shilpa','573',1,'Cash','','','','',NULL,'',0.00),(536,'2022-04-26 00:00:00','42','Homecare Refreshment',-130.00,'Expense','Shilpa','574',1,'Cash','','','','',NULL,'',0.00),(537,'2022-04-27 00:00:00','43','Homecare Refreshment',-170.00,'Expense','Shilpa','575',1,'Cash','','','','',NULL,'',0.00),(538,'2022-04-27 00:00:00','44','Electricitty Charge',-3840.00,'Expense','K S E B','576',1,'Cash','','','','',NULL,'',0.00),(539,'2022-04-28 00:00:00','45','Homecare Refreshment',-70.00,'Expense','Shilpa','577',1,'Cash','','','','',NULL,'',0.00),(540,'2022-04-28 00:00:00','46','Vehicle Expense',-600.00,'Expense','Car Care','578',1,'Cash','','','','',NULL,'',0.00),(541,'2022-04-28 00:00:00','47','Vehicle Expense',-300.00,'Expense','Texmo','579',1,'Cash','','','','',NULL,'',0.00),(542,'2022-04-29 00:00:00','48','Homecare Refreshment',-160.00,'Expense','Shilpa','580',1,'Cash','','','','',NULL,'',0.00),(543,'2022-04-30 00:00:00','49','Missallanios Expense',-200.00,'Expense','Mohamed Yusaf','581',1,'Cash','','','','',NULL,'',0.00),(544,'2022-04-30 00:00:00','50','Homecare Refreshment',-60.00,'Expense','Shilpa','582',1,'Cash','','','','',NULL,'',0.00),(545,'2022-04-01 00:00:00','3751',' Monthly Subscription',200.00,'Income','Juvairiya','583',1,'Cash','','','','',NULL,'',0.00),(546,'2022-04-01 00:00:00','3752',' Monthly Subscription',1100.00,'Income','Jemshi haroon','584',1,'Cash','','','','',NULL,'',0.00),(547,'2022-04-01 00:00:00','3753',' Monthly Subscription',500.00,'Income','Farhan','585',1,'Cash','','','','',NULL,'',0.00),(548,'2022-04-01 00:00:00','3754',' Monthly Subscription',2000.00,'Income','Ayshakunhi','586',1,'Cash','','','','',NULL,'',0.00),(549,'2022-04-01 00:00:00','3755',' Monthly Subscription',500.00,'Income','Juvairiya','587',1,'Cash','','','','',NULL,'',0.00),(550,'2022-04-01 00:00:00','3756',' Monthly Subscription',1000.00,'Income','Shahana','588',1,'Cash','','','','',NULL,'',0.00),(551,'2022-04-01 00:00:00','3757',' Monthly Subscription',1000.00,'Income','Kunhimmu','589',1,'Cash','','','','',NULL,'',0.00),(552,'2022-04-01 00:00:00','3758',' Monthly Subscription',800.00,'Income','Ruby Naser','590',1,'Cash','','','','',NULL,'',0.00),(553,'2022-04-15 00:00:00','3759',' Monthly Subscription',1000.00,'Income','Farhan P T','591',1,'Cash','','','','',NULL,'',0.00),(554,'2022-04-21 00:00:00','3760',' Monthly Subscription',500.00,'Income','Rajeena C K','592',1,'Cash','','','','',NULL,'',0.00),(555,'2022-04-22 00:00:00','3761',' Monthly Subscription',500.00,'Income','Rajeena C K','593',1,'Cash','','','','',NULL,'',0.00),(556,'2022-04-24 00:00:00','3762',' Monthly Subscription',2100.00,'Income','Jemshi Haroon','594',1,'Cash','','','','',NULL,'',0.00),(557,'2022-04-27 00:00:00','3763',' Monthly Subscription',500.00,'Income','Peechu Basheer','595',1,'Cash','','','','',NULL,'',0.00),(558,'2022-04-29 00:00:00','3764',' Monthly Subscription',500.00,'Income','Sayeda Ibrahim','596',1,'Cash','','','','',NULL,'',0.00),(559,'2022-04-29 00:00:00','3765',' Monthly Subscription',500.00,'Income','Fathima P T','597',1,'Cash','','','','',NULL,'',0.00),(560,'2022-04-29 00:00:00','3766','Donation',5000.00,'Income','Sajida Shareef','598',1,'Cash','','','','',NULL,'',0.00),(561,'2022-07-01 00:00:00','Equipemnt Deposit. Equipment # : E1','EQUIPMENT DEPOSIT',0.00,'Income','ABDURAHMAN',NULL,0,'Cash','','','','',NULL,'',0.00),(562,'2022-07-16 00:00:00','Equipemnt Return. Equipment # : E1','EQUIPMENT DEPOSIT BALANCE',0.00,'Expense','',NULL,0,'Cash','','','','',NULL,'',0.00),(563,'2022-03-31 00:00:00','Opening balance','Opening balance',274623.00,'Income','',NULL,0,'Cash','','','','',NULL,'',0.00),(564,'2022-03-31 00:00:00','Opening balance','Opening balance',287286.73,'Income','',NULL,0,'Bank','Transfer','Kerala Gramin Bank - 40687111000159','1','',NULL,'',0.00),(565,'2022-03-31 00:00:00','Opening balance','Opening balance',1087139.00,'Income','',NULL,0,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801','1','',NULL,'',0.00),(566,'2022-04-16 00:00:00','-','Land Purchase',-5000.00,'Expense','Mohamed Yoosaf V P','599',1,'Cash','','','','',NULL,'',0.00),(567,'2022-04-16 00:00:00','Ch No:3754','Land Purchase',-195000.00,'Expense','Mohamed Yoosaf K V','600',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(568,'2022-07-16 00:00:00','Contra Entry - Cash','Contra Entry',0.00,'Expense','',NULL,0,'Cash','','','','',NULL,'',0.00),(569,'2022-07-16 00:00:00','Contra Entry - Bank','Contra Entry',0.00,'Income','',NULL,0,'Bank','Transfer','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(570,'2022-04-13 00:00:00','25','Medicines',0.00,'Expense','Kims Pharma','784',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(571,'2022-04-13 00:00:00','26','Medicines',0.00,'Expense','Kims Medical Agencies','785',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(572,'2022-04-30 00:00:00','Contra Entry - Cash','Contra Entry',-34001.00,'Expense','',NULL,0,'Cash','','',NULL,NULL,NULL,NULL,0.00),(573,'2022-04-30 00:00:00','Contra Entry - Bank','Contra Entry',34001.00,'Income','',NULL,0,'Bank','Transfer','Kerala Gramin Bank - 40687111000159',NULL,NULL,NULL,NULL,0.00),(574,'2022-04-30 00:00:00','Contra Entry - Bank','Contra Entry',0.00,'Expense','',NULL,0,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(575,'2022-04-30 00:00:00','Contra Entry - Cash','Contra Entry',0.00,'Income','',NULL,0,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(576,'2022-04-30 00:00:00','Contra Entry - Cash','Contra Entry',0.00,'Expense','',NULL,0,'Cash','','','','',NULL,'',0.00),(577,'2022-04-30 00:00:00','Contra Entry - Bank','Contra Entry',0.00,'Income','',NULL,0,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(578,'2022-04-05 00:00:00','-','Bank loan',-12648.00,'Expense','vehicle Loan','603',1,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(579,'2022-04-30 00:00:00','Contra Entry - Bank','Contra Entry',0.00,'Expense','',NULL,0,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(580,'2022-04-30 00:00:00','Contra Entry - Cash','Contra Entry',0.00,'Income','',NULL,0,'Cash','','','','',NULL,'',0.00),(581,'2022-04-30 00:00:00','Contra Entry - Cash','Contra Entry',0.00,'Expense','',NULL,0,'Cash','','','','',NULL,'',0.00),(582,'2022-04-30 00:00:00','Contra Entry - Bank','Contra Entry',0.00,'Income','',NULL,0,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(583,'2022-04-19 00:00:00','Contra Entry - Bank','Contra Entry',-100000.00,'Expense','',NULL,0,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801',NULL,NULL,NULL,NULL,0.00),(584,'2022-04-19 00:00:00','Contra Entry - Cash','Contra Entry',100000.00,'Income','',NULL,0,'Cash','','',NULL,NULL,NULL,NULL,0.00),(585,'2022-04-17 00:00:00','1651','Donation',10000.00,'Income','Dr. Makbool','599',1,'Cash','','','','',NULL,'',0.00),(586,'2022-04-25 00:00:00','1659','Donation',2000.00,'Income','Thenukutty N','600',1,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(587,'2022-04-19 00:00:00','1731','Donation',2000.00,'Income','Fathima. KHMHS','601',1,'Cash','','','','',NULL,'',0.00),(588,'2022-04-19 00:00:00','1741','Donation',3000.00,'Income','Jemshi Teacher,KHMHS','602',1,'Cash','','','','',NULL,'',0.00),(589,'2022-04-22 00:00:00','1753','Donation',1000.00,'Income','Mohamed Master R','603',1,'Cash','','','','',NULL,'',0.00),(590,'2022-04-25 00:00:00','1767','Donation',1000.00,'Income','Fousiya V M','604',1,'Cash','','','','',NULL,'',0.00),(591,'2022-04-22 00:00:00','1801','cancelled',0.00,'Income','Cancelled','605',1,'Cash','','','','',NULL,'',0.00),(592,'2022-04-28 00:00:00','6364','Donation',500.00,'Income','Komukutty Haji I P','606',1,'Cash','','','','',NULL,'',0.00),(593,'2022-04-24 00:00:00','6453','Donation',500.00,'Income','Bushra Annassery','607',1,'Cash','','','','',NULL,'',0.00),(594,'2022-04-29 00:00:00','6460','Donation',500.00,'Income','Mufsil , KHMHS','608',1,'Cash','','','','',NULL,'',0.00),(595,'2022-05-01 00:00:00','6368','Donation',200.00,'Income','Shahida','609',1,'Cash','','','','',NULL,'',0.00),(596,'2022-05-01 00:00:00','6370','Donation',250.00,'Income','Rasak M','610',1,'Cash','','','','',NULL,'',0.00),(597,'2022-05-01 00:00:00','6447','Donation',1000.00,'Income','Hamsa Thanikkad','733',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(598,'2022-05-01 00:00:00','6448','Donation',1000.00,'Income','Shamhoon R','612',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(599,'2022-05-01 00:00:00','6449','Donation',1000.00,'Income','Hyder Alloor','613',1,'Cash','','','','',NULL,'',0.00),(600,'2022-05-01 00:00:00','6450','Donation',300.00,'Income','Abdul Majeed V M','614',1,'Cash','','','','',NULL,'',0.00),(601,'2022-05-01 00:00:00','6467','Donation',500.00,'Income','Sameera,KHMHS','615',1,'Cash','','','','',NULL,'',0.00),(602,'2022-05-02 00:00:00','6468','Donation',500.00,'Income','Jamsheerbabu M','616',1,'Cash','','','','',NULL,'',0.00),(603,'2022-05-02 00:00:00','6469','Donation',500.00,'Income','Jensy R R,KHMHS','617',1,'Cash','','','','',NULL,'',0.00),(604,'2022-05-02 00:00:00','6470','Donation',500.00,'Income','Muhsina,KHMHS','618',1,'Cash','','','','',NULL,'',0.00),(605,'2022-05-01 00:00:00','1869','Donation',2500.00,'Income','Babu C P','619',1,'Cash','','','','',NULL,'',0.00),(606,'2022-05-01 00:00:00','1870','Donation',5000.00,'Income','Shajahan K T','620',1,'Cash','','','','',NULL,'',0.00),(607,'2022-05-15 00:00:00','1871','Donation',11500.00,'Income','Majeed K V & Family','621',1,'Cash','','','','',NULL,'',0.00),(608,'2022-05-01 00:00:00','1666','Donation',2000.00,'Income','Alibava P K','622',1,'Cash','','','','',NULL,'',0.00),(609,'2022-05-01 00:00:00','1667','Donation',1000.00,'Income','Abdussalam ,chennara','623',1,'Cash','','','','',NULL,'',0.00),(610,'2022-05-04 00:00:00','6285','Donation',2200.00,'Income','Jaseena K','624',1,'Cash','','','','',NULL,'',0.00),(611,'2022-05-22 00:00:00','6286','Donation',2000.00,'Income','Abdul Kader K P','625',1,'Cash','','','','',NULL,'',0.00),(612,'2022-04-29 00:00:00','1951','Donation',15000.00,'Income','Jalee,Lillees,Tirur','627',1,'Cash','','','','',NULL,'',0.00),(613,'2022-04-29 00:00:00','1952','Donation',3500.00,'Income','Shameer .K P O','628',1,'Cash','','','','',NULL,'',0.00),(614,'2022-04-29 00:00:00','1953','Donation',3000.00,'Income','Hameed. KPO','629',1,'Cash','','','','',NULL,'',0.00),(615,'2022-04-29 00:00:00','1954','Donation',3000.00,'Income','Bava Nalakath','630',1,'Cash','','','','',NULL,'',0.00),(616,'2022-04-29 00:00:00','1955','Donation',4000.00,'Income','Aslsm','631',1,'Cash','','','','',NULL,'',0.00),(617,'2022-04-29 00:00:00','1956','Donation',2000.00,'Income','Sajna Alavi','632',1,'Cash','','','','',NULL,'',0.00),(618,'2022-04-29 00:00:00','1957','Donation',6000.00,'Income','Haris C','633',1,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(619,'2022-04-29 00:00:00','1958',' Monthly Subscription',4000.00,'Income','Haris c','634',1,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(620,'2022-04-29 00:00:00','1959','Donation',2000.00,'Income','Umer Farook','635',1,'Cash','','','','',NULL,'',0.00),(621,'2022-04-29 00:00:00','1960','Donation',3500.00,'Income','Noorul Ameen .R','636',1,'Cash','','','','',NULL,'',0.00),(622,'2022-04-29 00:00:00','1961','Donation',10000.00,'Income','Banu,Kuttoor','637',1,'Cash','','','','',NULL,'',0.00),(623,'2022-04-30 00:00:00','1962','Donation',1500.00,'Income','Qamarullaila','638',1,'Cash','','','','',NULL,'',0.00),(624,'2022-04-30 00:00:00','1963','Donation',1000.00,'Income','Fahas','639',1,'Cash','','','','',NULL,'',0.00),(625,'2022-04-30 00:00:00','1964','Donation',8000.00,'Income','Rukkiya K T','640',1,'Cash','','','','',NULL,'',0.00),(626,'2022-04-30 00:00:00','1965','Donation',5000.00,'Income','Ismail P K','641',1,'Cash','','','','',NULL,'',0.00),(627,'2022-04-12 00:00:00','22','Printing & Stationary',0.00,'Expense','Mohamed Yoosaf','605',1,'Cash','','','','',NULL,'',0.00),(628,'2022-04-21 00:00:00','1628','Donation',500.00,'Income','Mohamedkutty. V P','643',1,'Cash','','','','',NULL,'',0.00),(629,'2022-04-01 00:00:00','90-91','HOPE',2000.00,'Income','Hope','644',1,'Cash','','','','',NULL,'',0.00),(630,'2022-04-02 00:00:00','92-93','HOPE',400.00,'Income','hope','645',1,'Cash','','','','',NULL,'',0.00),(631,'2022-04-04 00:00:00','94','HOPE',200.00,'Income','hope','646',1,'Cash','','','','',NULL,'',0.00),(632,'2022-04-05 00:00:00','95','HOPE',200.00,'Income','hope','647',1,'Cash','','','','',NULL,'',0.00),(633,'2022-04-06 00:00:00','96-97','HOPE',400.00,'Income','hope','648',1,'Cash','','','','',NULL,'',0.00),(634,'2022-04-07 00:00:00','98-99','HOPE',400.00,'Income','hope','649',1,'Cash','','','','',NULL,'',0.00),(635,'2022-04-08 00:00:00','100-104','HOPE',1800.00,'Income','hope','650',1,'Cash','','','','',NULL,'',0.00),(636,'2022-04-09 00:00:00','105-108','HOPE',800.00,'Income','hope','651',1,'Cash','','','','',NULL,'',0.00),(637,'2022-04-11 00:00:00','109-115','HOPE',1200.00,'Income','hope','652',1,'Cash','','','','',NULL,'',0.00),(638,'2022-04-12 00:00:00','116-119','HOPE',800.00,'Income','hope','653',1,'Cash','','','','',NULL,'',0.00),(639,'2022-04-13 00:00:00','120-123','HOPE',800.00,'Income','hope','654',1,'Cash','','','','',NULL,'',0.00),(640,'2022-04-14 00:00:00','124-129','HOPE',1200.00,'Income','hope','655',1,'Cash','','','','',NULL,'',0.00),(641,'2022-04-16 00:00:00','130-135','HOPE',1200.00,'Income','hope','656',1,'Cash','','','','',NULL,'',0.00),(642,'2022-04-18 00:00:00','136-137','HOPE',400.00,'Income','hope','657',1,'Cash','','','','',NULL,'',0.00),(643,'2022-04-20 00:00:00','138-141','HOPE',800.00,'Income','hope','658',1,'Cash','','','','',NULL,'',0.00),(644,'2022-04-21 00:00:00','142-145','HOPE',800.00,'Income','hope','659',1,'Cash','','','','',NULL,'',0.00),(645,'2022-04-22 00:00:00','146-147','HOPE',300.00,'Income','hope','660',1,'Cash','','','','',NULL,'',0.00),(646,'2022-04-23 00:00:00','148-151','HOPE',600.00,'Income','hope','661',1,'Cash','','','','',NULL,'',0.00),(647,'2022-04-25 00:00:00','152-157','HOPE',900.00,'Income','hope','662',1,'Cash','','','','',NULL,'',0.00),(648,'2022-04-26 00:00:00','158-164','HOPE',1300.00,'Income','hope','663',1,'Cash','','','','',NULL,'',0.00),(649,'2022-04-27 00:00:00','165-172','HOPE',1700.00,'Income','hjope','664',1,'Cash','','','','',NULL,'',0.00),(650,'2022-04-28 00:00:00','173-181','HOPE',1500.00,'Income','hope','665',1,'Cash','','','','',NULL,'',0.00),(651,'2022-04-29 00:00:00','182-186','HOPE',800.00,'Income','hope','666',1,'Cash','','','','',NULL,'',0.00),(652,'2022-04-30 00:00:00','187-195','HOPE',6400.00,'Income','hope','667',1,'Cash','','','','',NULL,'',0.00),(653,'2022-05-02 00:00:00','201','HOPE',100.00,'Income','hope','668',1,'Cash','','','','',NULL,'',0.00),(654,'2022-05-05 00:00:00','202-205','HOPE',800.00,'Income','hope','669',1,'Cash','','','','',NULL,'',0.00),(655,'2022-05-06 00:00:00','206-208','HOPE',600.00,'Income','hope','670',1,'Cash','','','','',NULL,'',0.00),(656,'2022-05-07 00:00:00','209-213','HOPE',900.00,'Income','hope','671',1,'Cash','','','','',NULL,'',0.00),(657,'2022-05-09 00:00:00','214-218','HOPE',1000.00,'Income','hope','764',1,'Cash','','','','',NULL,'',0.00),(658,'2022-05-10 00:00:00','219-222','HOPE',800.00,'Income','hope','673',1,'Cash','','','','',NULL,'',0.00),(659,'2022-05-11 00:00:00','223-229','HOPE',1300.00,'Income','hope','765',1,'Cash','','','','',NULL,'',0.00),(660,'2022-05-12 00:00:00','230-233','HOPE',700.00,'Income','hope','675',1,NULL,'','','','',NULL,'',0.00),(661,'2022-05-13 00:00:00','234-237','HOPE',700.00,'Income','hope','676',1,'Cash','','','','',NULL,'',0.00),(662,'2022-05-14 00:00:00','238-243','HOPE',1000.00,'Income','hope','677',1,'Cash','','','','',NULL,'',0.00),(663,'2022-05-16 00:00:00','244-251','HOPE',1900.00,'Income','hope','678',1,'Cash','','','','',NULL,'',0.00),(664,'2022-05-17 00:00:00','252-255','HOPE',700.00,'Income','hope','679',1,'Cash','','','','',NULL,'',0.00),(665,'2022-05-18 00:00:00','256-261','HOPE',1400.00,'Income','hope','680',1,'Cash','','','','',NULL,'',0.00),(666,'2022-05-19 00:00:00','262-264','HOPE',600.00,'Income','hope','681',1,'Cash','','','','',NULL,'',0.00),(667,'2022-05-20 00:00:00','265-270','HOPE',1300.00,'Income','hope','682',1,'Cash','','','','',NULL,'',0.00),(668,'2022-05-21 00:00:00','271-274','HOPE',800.00,'Income','hope','683',1,'Cash','','','','',NULL,'',0.00),(669,'2022-05-23 00:00:00','275-282','HOPE',1100.00,'Income','hope','684',1,'Cash','','','','',NULL,'',0.00),(670,'2022-05-24 00:00:00','283-286','HOPE',900.00,'Income','hope','685',1,'Cash','','','','',NULL,'',0.00),(671,'2022-05-25 00:00:00','287-297','HOPE',2000.00,'Income','hope','686',1,'Cash','','','','',NULL,'',0.00),(672,'2022-05-26 00:00:00','298-301','HOPE',500.00,'Income','hope','687',1,'Cash','','','','',NULL,'',0.00),(673,'2022-05-27 00:00:00','302-308','HOPE',1100.00,'Income','hope','688',1,'Cash','','','','',NULL,'',0.00),(674,'2022-05-28 00:00:00','309-314','HOPE',1100.00,'Income','hope','689',1,'Cash','','','','',NULL,'',0.00),(675,'2022-05-30 00:00:00','315-321','HOPE',1300.00,'Income','hope','690',1,'Cash','','','','',NULL,'',0.00),(676,'2022-05-31 00:00:00','322-330','HOPE',1600.00,'Income','hope','691',1,'Cash','','','','',NULL,'',0.00),(677,'2022-05-01 00:00:00','1666','Donation',0.00,'Income','Alibava P K','757',1,'Cash','','','','',NULL,'',0.00),(678,'2022-05-01 00:00:00','1667','Donation',0.00,'Income','Abdul Salam,Chennara','758',1,'Cash','','','','',NULL,'',0.00),(679,'2022-05-01 00:00:00','1869','Donation',0.00,'Income','Babu C P','761',1,'Cash','','','','',NULL,'',0.00),(680,'2022-05-01 00:00:00','1870','Donation',0.00,'Income','Shajahan K T','762',1,'Cash','','','','',NULL,'',0.00),(681,'2022-05-15 00:00:00','1871','Donation',0.00,'Income','K V. Majeed& Family','763',1,'Cash','','','','',NULL,'',0.00),(682,'2022-05-01 00:00:00','1940','Donation',1000.00,'Income','Shabeer Sir,KHMHS ','697',1,'Cash','','','','',NULL,'',0.00),(683,'2022-05-01 00:00:00','1941','Donation',1000.00,'Income','Niyas,Poilissery','698',1,'Cash','','','','',NULL,'',0.00),(684,'2022-05-02 00:00:00','1942','Donation',1000.00,'Income','Bavakutty CP,KHMHS','699',1,'Cash','','','','',NULL,'',0.00),(685,'2022-05-02 00:00:00','1943','Donation',2000.00,'Income','Afeelarasak,KHMHS','700',1,'Cash','','','','',NULL,'',0.00),(686,'2022-05-02 00:00:00','1944','Donation',1000.00,'Income','Shamitha,KHMHS','701',1,'Cash','','','','',NULL,'',0.00),(687,'2022-05-02 00:00:00','1945','Donation',2000.00,'Income','Ameer, KHMHS','702',1,'Cash','','','','',NULL,'',0.00),(688,'2022-05-02 00:00:00','1946','Donation',1000.00,'Income','Shakeeb,Poozhikkunnu','703',1,'Cash','','','','',NULL,'',0.00),(689,'2022-05-02 00:00:00','1947','Donation',5000.00,'Income','Sajid,Poozhikkunnu','704',1,'Cash','','','','',NULL,'',0.00),(690,'2022-05-02 00:00:00','1948','Donation',1000.00,'Income','Nisha,KHMHS','705',1,'Cash','','','','',NULL,'',0.00),(691,'2022-05-05 00:00:00','1949','Donation',1000.00,'Income','Salma, KHMHs','706',1,'Cash','','','','',NULL,'',0.00),(692,'2022-05-07 00:00:00','1950','Donation',1000.00,'Income','Shyni.K','707',1,'Cash','','','','',NULL,'',0.00),(693,'2022-05-01 00:00:00','1966','Donation',10000.00,'Income','Raheena V M','708',1,'Cash','','','','',NULL,'',0.00),(694,'2022-05-01 00:00:00','1967','Donation',1500.00,'Income','Miyandad','709',1,'Cash','','','','',NULL,'',0.00),(695,'2022-05-01 00:00:00','1968','Donation',1500.00,'Income','Hiba Fathima','710',1,'Cash','','','','',NULL,'',0.00),(696,'2022-05-01 00:00:00','1969','Donation',2000.00,'Income','Yoosaf K M','711',1,'Cash','','','','',NULL,'',0.00),(697,'2022-05-01 00:00:00','1970','Donation',10000.00,'Income','Ibrahim M','712',1,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(698,'2022-05-01 00:00:00','1971','Donation',5000.00,'Income','Sirajudheen V M','713',1,'Cash','','','','',NULL,'',0.00),(699,'2022-05-07 00:00:00','1972','Donation',2000.00,'Income','Shabeer A P','714',1,'Cash','','','','',NULL,'',0.00),(700,'2022-05-07 00:00:00','1973','Donation',2000.00,'Income','Shamsudheen AP','715',1,'Cash','','','','',NULL,'',0.00),(701,'2022-05-12 00:00:00','1974','Donation',2500.00,'Income','Mohamed Jaseer K','716',1,'Cash','','','','',NULL,'',0.00),(702,'2022-05-12 00:00:00','1975','Donation',1000.00,'Income','Muhsina T','717',1,'Cash','','','','',NULL,'',0.00),(703,'2022-05-12 00:00:00','1976','Donation',4000.00,'Income','Ibrahim,kurumbdi','718',1,'Cash','','','','',NULL,'',0.00),(704,'2022-05-12 00:00:00','1977','Donation',5000.00,'Income','Abdul Razak P','719',1,'Cash','','','','',NULL,'',0.00),(705,'2022-05-12 00:00:00','1978','Donation',2000.00,'Income','Zainudheen K','720',1,'Cash','','','','',NULL,'',0.00),(706,'2022-05-12 00:00:00','1979','Donation',1000.00,'Income','Shabeerali,poozhikkunnu','721',1,'Cash','','','','',NULL,'',0.00),(707,'2022-05-17 00:00:00','1980',' Monthly Subscription',2000.00,'Income','Jabbar C T','722',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(708,'2022-05-25 00:00:00','1981','Donation',7000.00,'Income','Saidalavi V','723',1,'Cash','','','','',NULL,'',0.00),(709,'2022-05-25 00:00:00','1982',' Monthly Subscription',2000.00,'Income','Jasmir ali V P','724',1,'Cash','','','','',NULL,'',0.00),(710,'2022-05-25 00:00:00','1983','Donation',5000.00,'Income','Nisar V P','725',1,'Cash','','','','',NULL,'',0.00),(711,'2022-05-25 00:00:00','1984','Donation',2000.00,'Income','Mohamed Sha R','726',1,'Cash','','','','',NULL,'',0.00),(712,'2022-05-04 00:00:00','6285','Donation',0.00,'Income','Jaseena K','768',1,'Cash','','','','',NULL,'',0.00),(713,'2022-05-22 00:00:00','6286','Donation',0.00,'Income','Abdul Kader K P','767',1,'Cash','','','','',NULL,'',0.00),(714,'2022-05-01 00:00:00','6368','Donation',0.00,'Income','Shafida','769',1,'Cash','','','','',NULL,'',0.00),(715,'2022-05-01 00:00:00','6369','Donation',500.00,'Income','Saheed A','730',1,'Cash','','','','',NULL,'',0.00),(716,'2022-05-01 00:00:00','6370','Donation',0.00,'Income','Rasak M','770',1,'Cash','','','','',NULL,'',0.00),(717,'2022-05-01 00:00:00','6447','Donation',0.00,'Income','Hamsa Thanikad','771',1,'Cash','','','','',NULL,'',0.00),(718,'2022-05-01 00:00:00','6448','Donation',0.00,'Income','Shamhoon R','772',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(719,'2022-05-01 00:00:00','6449','Donation',0.00,'Income','Hydru A','773',1,'Cash','','','','',NULL,'',0.00),(720,'2022-05-01 00:00:00','6450',' Monthly Subscription',0.00,'Income','Abdul Majeed V m','774',1,'Cash','','','','',NULL,'',0.00),(721,'2022-05-01 00:00:00','6467','Donation',0.00,'Income','Sameera ,KHMHS','775',1,'Cash','','','','',NULL,'',0.00),(722,'2022-05-02 00:00:00','6468','Donation',0.00,'Income','Jamsheerbabu M,KHMHS','776',1,'Cash','','','','',NULL,'',0.00),(723,'2022-05-02 00:00:00','6469','Donation',0.00,'Income','Jensy , KHMHS','777',1,'Cash','','','','',NULL,'',0.00),(724,'2022-05-02 00:00:00','6470','Donation',0.00,'Income','Muhsina ,KHMHS','778',1,'Cash','','','','',NULL,'',0.00),(725,'2022-05-01 00:00:00','6851','Donation',1000.00,'Income','Shajid V M','741',1,'Cash','','','','',NULL,'',0.00),(726,'2022-05-01 00:00:00','6852','Donation',1000.00,'Income','Jusna V M','742',1,'Cash','','','','',NULL,'',0.00),(727,'2022-05-05 00:00:00','6853','Donation',1000.00,'Income','Ilyas CT','743',1,'Cash','','','','',NULL,'',0.00),(728,'2022-05-05 00:00:00','6854','Donation',1000.00,'Income','AbdulkabrKabeer P K','744',1,'Cash','','','','',NULL,'',0.00),(729,'2022-05-09 00:00:00','6855','Donation',1000.00,'Income','Hamzu N','745',1,'Cash','','','','',NULL,'',0.00),(730,'2022-05-11 00:00:00','6856',' Monthly Subscription',250.00,'Income','Abdul Salam M V','746',1,NULL,'','','','',NULL,'',0.00),(731,'2022-05-11 00:00:00','6857','Rent',2250.00,'Income','Thilakam','747',1,'Cash','','','','',NULL,'',0.00),(732,'2022-05-14 00:00:00','6858','Donation',300.00,'Income','Hanna anwarsadat R','748',1,'Cash','','','','',NULL,'',0.00),(733,'2022-05-14 00:00:00','6859','Donation',200.00,'Income','Fathima R','749',1,'Cash','','','','',NULL,'',0.00),(734,'2022-05-25 00:00:00','3860','Donation',0.00,'Income','Rasheed BP Angadi','766',1,'Cash','','','','',NULL,'',0.00),(735,'2022-05-25 00:00:00','6861','Donation',500.00,'Income','Priya P P , BHSS','751',1,'Cash','','','','',NULL,'',0.00),(736,'2022-05-25 00:00:00','6862','Donation',500.00,'Income','Abdurahman V M','752',1,'Cash','','','','',NULL,'',0.00),(737,'2022-05-31 00:00:00','6863',' Monthly Subscription',600.00,'Income','Abidmaster','753',1,'Cash','','','','',NULL,'',0.00),(738,'2022-05-31 00:00:00','6864','Donation',500.00,'Income','Hameed','754',1,'Cash','','','','',NULL,'',0.00),(739,'2022-05-31 00:00:00','6865','Rent',250.00,'Income','PostOffice','755',1,'Cash','','','','',NULL,'',0.00),(740,'2022-05-25 00:00:00','6860','Donation',500.00,'Income','Rasheed,BP Angadi','779',1,'Cash','','','','',NULL,'',0.00),(741,'2022-05-01 00:00:00','51','Homecare Refreshment',-40.00,'Expense','Shilpa','607',1,'Cash','','','','',NULL,'',0.00),(742,'2022-05-01 00:00:00','52','Salary',-12000.00,'Expense','Musthafa K P','683',1,'Cash','','','','',NULL,'',0.00),(743,'2022-05-01 00:00:00','53','Salary,(eadallavance)',-1000.00,'Expense','Musthafa K P','609',1,'Cash','','','','',NULL,'',0.00),(744,'2022-05-02 00:00:00','54','Homecare Refreshment',-60.00,'Expense','Shilpa','610',1,'Cash','','','','',NULL,'',0.00),(745,'2022-05-04 00:00:00','55','Building Work',-900.00,'Expense','S&S Associates','611',1,'Cash','','','','',NULL,'',0.00),(746,'2022-05-05 00:00:00','56','Building Work',-937.00,'Expense','S. S Color Care','612',1,'Cash','','','','',NULL,'',0.00),(747,'2022-05-05 00:00:00','57','Building Work',-3330.00,'Expense','S. S Color Care','613',1,'Cash','','','','',NULL,'',0.00),(748,'2022-05-05 00:00:00','58','Vehicle Expense',-2000.00,'Expense','K.P.K Petrolium','614',1,'Cash','','','','',NULL,'',0.00),(749,'2022-05-05 00:00:00','59','Missallanios Expense',-5500.00,'Expense','Hashmi Digital Press','615',1,'Cash','','','','',NULL,'',0.00),(750,'2022-05-05 00:00:00','60','Missallanios Expense',-3000.00,'Expense','C K Groop','616',1,'Cash','','','','',NULL,'',0.00),(751,'2022-05-05 00:00:00','61','Missallanios Expense (LED Bord)',-6500.00,'Expense','C K Groop','617',1,'Cash','','','','',NULL,'',0.00),(752,'2022-05-05 00:00:00','62','Homecare Refreshment',-170.00,'Expense','Shilpa','618',1,'Cash','','','','',NULL,'',0.00),(753,'2022-05-05 00:00:00','63','Missallanios Expense',-100.00,'Expense','Secratary','619',1,'Cash','','','','',NULL,'',0.00),(754,'2022-05-05 00:00:00','64','Building Work',-6003.00,'Expense','Associated Buisness Corporation','620',1,'Cash','','','','',NULL,'',0.00),(755,'2022-05-06 00:00:00','65','Building Work',-10142.00,'Expense','My Brother Bazar','621',1,'Cash','','','','',NULL,'',0.00),(756,'2022-05-06 00:00:00','66','Telephone Charge',-150.00,'Expense','shilpa','622',1,'Cash','','','','',NULL,'',0.00),(757,'2022-05-06 00:00:00','67','Homecare Refreshment',-235.00,'Expense','Shilpa','623',1,'Cash','','','','',NULL,'',0.00),(758,'2022-05-06 00:00:00','68','Missallanios Expense',-205.00,'Expense','Mohamed Yoosaf','624',1,'Cash','','','','',NULL,'',0.00),(759,'2022-05-07 00:00:00','69','Homecare Refreshment',-270.00,'Expense','Shilpa','625',1,'Cash','','','','',NULL,'',0.00),(760,'2022-05-08 00:00:00','70','Homecare Refreshment',-190.00,'Expense','Shilpa','626',1,'Cash','','','','',NULL,'',0.00),(761,'2022-05-09 00:00:00','71','Homecare Refreshment',-210.00,'Expense','Shilpa','627',1,'Cash','','','','',NULL,'',0.00),(762,'2022-05-10 00:00:00','72','Homecare Refreshment',-220.00,'Expense','Shilpa','628',1,'Cash','','','','',NULL,'',0.00),(763,'2022-05-11 00:00:00','73','Electricitty Charge',-195.00,'Expense','Shilpa','629',1,'Cash','','','','',NULL,'',0.00),(764,'2022-05-11 00:00:00','74','Homecare Refreshment',-155.00,'Expense','Mohamed Yoosaf','630',1,'Cash','','','','',NULL,'',0.00),(765,'2022-05-12 00:00:00','75','Homecare Refreshment',-260.00,'Expense','Shilpa','631',1,'Cash','','','','',NULL,'',0.00),(766,'2022-05-13 00:00:00','76','Homecare Refreshment',-190.00,'Expense','Shilpa','632',1,'Cash','','','','',NULL,'',0.00),(767,'2022-05-13 00:00:00','77','Building Work',-957.00,'Expense','My Broyher Bazar','633',1,'Cash','','','','',NULL,'',0.00),(768,'2022-05-13 00:00:00','78','Building Work',-3680.00,'Expense','S & S Associates','634',1,'Cash','','','','',NULL,'',0.00),(769,'2022-05-13 00:00:00','79','Building Work',-17824.00,'Expense','Diamond Glass Mart','635',1,'Cash','','','','',NULL,'',0.00),(770,'2022-05-13 00:00:00','80','Missallanios Expense',-260.00,'Expense','Rafi','636',1,'Cash','','','','',NULL,'',0.00),(771,'2022-05-13 00:00:00','81','Ambulance',-1000.00,'Expense','Haji Mohamedali Sons','637',1,'Cash','','','','',NULL,'',0.00),(772,'2022-05-13 00:00:00','82','Ambulance',-2289.00,'Expense','Popular Mega Motors','638',1,'Cash','','','','',NULL,'',0.00),(773,'2022-05-13 00:00:00','83','Building Work',-608.00,'Expense','Secratary','639',1,'Cash','','','','',NULL,'',0.00),(774,'2022-05-13 00:00:00','84','Printing & Stationary',-550.00,'Expense','Senior Buisness Centre','640',1,'Cash','','','','',NULL,'',0.00),(775,'2022-05-13 00:00:00','85','Printing & Stationary',-300.00,'Expense','KPM Agencies','641',1,'Cash','','','','',NULL,'',0.00),(776,'2022-05-14 00:00:00','86','Telephone Charge',-180.00,'Expense','Mohamed Yoosaf','642',1,'Cash','','','','',NULL,'',0.00),(777,'2022-05-14 00:00:00','87','Homecare Refreshment',-200.00,'Expense','Smitha','643',1,'Cash','','','','',NULL,'',0.00),(778,'2022-05-14 00:00:00','88','Printing & Stationary',-540.00,'Expense','M I P','644',1,'Cash','','','','',NULL,'',0.00),(779,'2022-05-15 00:00:00','89','Homecare Refreshment',-160.00,'Expense','Shilpa','645',1,'Cash','','','','',NULL,'',0.00),(780,'2022-05-16 00:00:00','90','Printing & Stationary',-600.00,'Expense','Mohamed Yoosaf','646',1,'Cash','','','','',NULL,'',0.00),(781,'2022-05-16 00:00:00','91','Homecare Refreshment',-280.00,'Expense','Shilpa','647',1,'Cash','','','','',NULL,'',0.00),(782,'2022-05-17 00:00:00','92','Homecare Refreshment',-250.00,'Expense','Shilpa','648',1,'Cash','','','','',NULL,'',0.00),(783,'2022-05-17 00:00:00','93','Medicines',-7873.00,'Expense','Kims Medical Agencies','649',1,'Cash','','','','',NULL,'',0.00),(784,'2022-05-17 00:00:00','94','Medicines',-1117.00,'Expense','Bismik Medical Agencies','650',1,'Cash','','','','',NULL,'',0.00),(785,'2022-05-18 00:00:00','95','Homecare Refreshment',-230.00,'Expense','Shilpa','651',1,'Cash','','','','',NULL,'',0.00),(786,'2022-05-18 00:00:00','96','Vehicle Expense',-2000.00,'Expense','K.P.K Petrolium','652',1,'Cash','','','','',NULL,'',0.00),(787,'2022-05-18 00:00:00','97','Building Work',-38900.00,'Expense','Royal Paints','653',1,'Cash','','','','',NULL,'',0.00),(788,'2022-05-19 00:00:00','98','D H C Fees',-3000.00,'Expense','Dr. Majida','795',1,'Cash','','','','',NULL,'',0.00),(789,'2022-05-19 00:00:00','99','Homecare Refreshment',-80.00,'Expense','Shilpa','655',1,'Cash','','','','',NULL,'',0.00),(790,'2022-05-21 00:00:00','100','Missallanios Expense',-500.00,'Expense','Press Clubb','656',1,'Cash','','','','',NULL,'',0.00),(791,'2022-05-21 00:00:00','101','Homecare Refreshment',-210.00,'Expense','Shilpa','657',1,'Cash','','','','',NULL,'',0.00),(792,'2022-05-21 00:00:00','102','Building Work',-2155.00,'Expense','Libra Paints','658',1,'Cash','','','','',NULL,'',0.00),(793,'2022-05-22 00:00:00','103','Homecare Refreshment',-250.00,'Expense','Smitha','659',1,'Cash','','','','',NULL,'',0.00),(794,'2022-07-22 00:00:00','104','Building Work',0.00,'Expense','C V Paints','804',1,'Cash','','','','',NULL,'',0.00),(795,'2022-05-23 00:00:00','105','Homecare Refreshment',-180.00,'Expense','Shilpa','661',1,'Cash','','','','',NULL,'',0.00),(796,'2022-05-23 00:00:00','106','Building Work',-80.00,'Expense','Kairali Hardware','662',1,'Cash','','','','',NULL,'',0.00),(797,'2022-05-24 00:00:00','107','D H C Fees',-2500.00,'Expense','DR. Sabiq Asim','796',1,'Cash','','','','',NULL,'',0.00),(798,'2022-05-24 00:00:00','108','Printing & Stationary',-580.00,'Expense','Secratary','664',1,'Cash','','','','',NULL,'',0.00),(799,'2022-05-24 00:00:00','109','Printing & Stationary',-500.00,'Expense','Nadiya Collection','665',1,'Cash','','','','',NULL,'',0.00),(800,'2022-05-23 00:00:00','110','Building Work',-960.00,'Expense','Powertech','666',1,'Cash','','','','',NULL,'',0.00),(801,'2022-05-24 00:00:00','111','Building Work',-431.00,'Expense','Secretary','667',1,'Cash','','','','',NULL,'',0.00),(802,'2022-05-24 00:00:00','112','Printing & Stationary',-100.00,'Expense','New Rose Textiles','668',1,'Cash','','','','',NULL,'',0.00),(803,'2022-05-24 00:00:00','113','Printing & Stationary',-155.00,'Expense','Secratary','669',1,'Cash','','','','',NULL,'',0.00),(804,'2022-05-24 00:00:00','114','Printing & Stationary',-25.00,'Expense','Secratary','670',1,'Cash','','','','',NULL,'',0.00),(805,'2022-05-24 00:00:00','115','Homecare Refreshment',-180.00,'Expense','Smitha','671',1,'Cash','','','','',NULL,'',0.00),(806,'2022-05-25 00:00:00','116','Homecare Refreshment',-180.00,'Expense','Smitha','672',1,'Cash','','','','',NULL,'',0.00),(807,'2022-05-25 00:00:00','117','Vehicle Expense',-2000.00,'Expense','K.P.K Petrolium','673',1,'Cash','','','','',NULL,'',0.00),(808,'2022-05-26 00:00:00','118','Homecare Refreshment',-240.00,'Expense','Smitha','674',1,'Cash','','','','',NULL,'',0.00),(809,'2022-05-27 00:00:00','119','Homecare Refreshment',-190.00,'Expense','Smitha','675',1,'Cash','','','','',NULL,'',0.00),(810,'2022-05-28 00:00:00','120','Homecare Refreshment',-260.00,'Expense','Smitha','676',1,'Cash','','','','',NULL,'',0.00),(811,'2022-05-28 00:00:00','121','Medicines',-10924.00,'Expense','Medico Surgicals','677',1,'Cash','','','','',NULL,'',0.00),(812,'2022-05-29 00:00:00','122','Homecare Refreshment',-290.00,'Expense','Smitha','678',1,'Cash','','','','',NULL,'',0.00),(813,'2022-05-30 00:00:00','123','Homecare Refreshment',-250.00,'Expense','Smitha','679',1,'Cash','','','','',NULL,'',0.00),(814,'2022-05-31 00:00:00','124','Homecare Refreshment',-250.00,'Expense','Smitha','680',1,'Cash','','','','',NULL,'',0.00),(815,'2022-05-22 00:00:00','104','Building Work',-438.00,'Expense','C V .Paints','681',1,'Cash','','','','',NULL,'',0.00),(816,'2022-05-31 00:00:00','Contra Entry - Bank','Contra Entry',0.00,'Expense','',NULL,0,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(817,'2022-05-31 00:00:00','Contra Entry - Cash','Contra Entry',0.00,'Income','',NULL,0,'Cash','','','','',NULL,'',0.00),(818,'2022-05-31 00:00:00','Contra Entry - Cash','Contra Entry',0.00,'Expense','',NULL,0,'Cash','','','','',NULL,'',0.00),(819,'2022-05-31 00:00:00','Contra Entry - Bank','Contra Entry',0.00,'Income','',NULL,0,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(820,'2022-05-05 00:00:00','-','Bank loan',-12648.00,'Expense',' ICIC Bank','682',1,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(821,'2022-05-31 00:00:00','Contra Entry - Cash','Contra Entry',-468276.00,'Expense','',NULL,0,'Cash','','','','',NULL,'',0.00),(822,'2022-05-31 00:00:00','Contra Entry - Bank','Contra Entry',468276.00,'Income','',NULL,0,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(823,'2022-04-30 00:00:00','Contra Entry - Cash','Contra Entry',-356150.00,'Expense','',NULL,0,'Cash','','',NULL,NULL,NULL,NULL,0.00),(824,'2022-04-30 00:00:00','Contra Entry - Bank','Contra Entry',356150.00,'Income','',NULL,0,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801',NULL,NULL,NULL,NULL,0.00),(825,'2022-04-30 00:00:00','Contra Entry - Bank','Contra Entry',0.00,'Expense','',NULL,0,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(826,'2022-04-30 00:00:00','Contra Entry - Cash','Contra Entry',0.00,'Income','',NULL,0,'Cash','','','','',NULL,'',0.00),(827,'2022-05-31 00:00:00','125','Salary',-15000.00,'Expense','Hasna Physiotherapist','684',1,'Cash','','','','',NULL,'',0.00),(828,'2022-05-31 00:00:00','126','Salary',-13000.00,'Expense','Shilpa Nurse','685',1,'Cash','','','','',NULL,'',0.00),(829,'2022-05-31 00:00:00','127','Salary',-2925.00,'Expense','Smitha Nurse','686',1,'Cash','','','','',NULL,'',0.00),(830,'2022-05-31 00:00:00','128','Salary',-1800.00,'Expense','Rafi Draiver','687',1,'Cash','','','','',NULL,'',0.00),(831,'2022-05-31 00:00:00','129','Salary',-8000.00,'Expense','Mohamed Yusaf,Office Secratary','688',1,'Cash','','','','',NULL,'',0.00),(832,'2022-05-31 00:00:00','130','Salary',-2500.00,'Expense','Radha,sweeper','786',1,'Cash','','','','',NULL,'',0.00),(833,'2022-05-31 00:00:00','131','Salary',-15000.00,'Expense','Rasly,Physiotherapist','787',1,'Cash','','','','',NULL,'',0.00),(834,'2022-05-31 00:00:00','132','Ambulance Commision',-720.00,'Expense','Mohamed rafi, Draiver','788',1,'Cash','','','','',NULL,'',0.00),(835,'2022-06-06 00:00:00','1985','Donation',2500.00,'Income','Abdul manaf T P','780',1,'Cash','','','','',NULL,'',0.00),(836,'2022-06-06 00:00:00','1986',' Monthly Subscription',2000.00,'Income','Shahul PK','781',1,'Cash','','','','',NULL,'',0.00),(837,'2022-06-14 00:00:00','1987','Donation',5000.00,'Income','Safreen K V, KHMHS','782',1,'Cash','','','','',NULL,'',0.00),(838,'2022-06-14 00:00:00','1988',' Monthly Subscription',2000.00,'Income','Jabbar C T','783',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(839,'2022-06-23 00:00:00','1989','Donation',10000.00,'Income','Rasheedali M P','784',1,'Cash','','','','',NULL,'',0.00),(840,'2022-06-23 00:00:00','1990','Donation',6300.00,'Income','Raashid K P','785',1,'Cash','','','','',NULL,'',0.00),(841,'2022-06-07 00:00:00','6866',' Monthly Subscription',1000.00,'Income','Mohamed Rafi K V','786',1,'Cash','','','','',NULL,'',0.00),(842,'2022-06-07 00:00:00','6867',' Monthly Subscription',500.00,'Income','Mohamed Saleem C P','787',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(843,'2022-06-08 00:00:00','6868',' Monthly Subscription',500.00,'Income','Moideen Master R','788',1,'Cash','','','','',NULL,'',0.00),(844,'2022-06-12 00:00:00','6869','Donation',500.00,'Income','Rukkiya A','789',1,'Cash','','','','',NULL,'',0.00),(845,'2022-06-14 00:00:00','6870','Rent',2250.00,'Income','Thilakam','790',1,'Cash','','','','',NULL,'',0.00),(846,'2022-06-16 00:00:00','6871','Donation',200.00,'Income','Nisthar P V','791',1,'Cash','','','','',NULL,'',0.00),(847,'2022-06-19 00:00:00','6872',' Monthly Subscription',1000.00,'Income','Musthafa K V','792',1,'Cash','','','','',NULL,'',0.00),(848,'2022-06-19 00:00:00','6873',' Monthly Subscription',1000.00,'Income','Wasif K V','793',1,'Cash','','','','',NULL,'',0.00),(849,'2022-06-20 00:00:00','6874','Donation',500.00,'Income','Marhoom Abdurahman Master V M','794',1,'Cash','','','','',NULL,'',0.00),(850,'2022-06-27 00:00:00','6875',' Monthly Subscription',300.00,'Income','Abdul Majeed V M','795',1,'Cash','','','','',NULL,'',0.00),(851,'2022-06-01 00:00:00','6946','Donation',1000.00,'Income','Abdul kader k','796',1,'Cash','','','','',NULL,'',0.00),(852,'2022-06-10 00:00:00','6947','Freezer& O2 Rent',1000.00,'Income','Chandrika','797',1,'Cash','','','','',NULL,'',0.00),(853,'2022-06-11 00:00:00','6948','Donation',500.00,'Income','Kunhimohamed T','798',1,'Cash','','','','',NULL,'',0.00),(854,'2022-06-12 00:00:00','6949','Donation',1000.00,'Income','Ayshakutty E P, KHMHS','799',1,'Cash','','','','',NULL,'',0.00),(855,'2022-06-13 00:00:00','6950','Donation',150.00,'Income','Manu ','800',1,'Cash','','','','',NULL,'',0.00),(856,'2022-06-14 00:00:00','6951','Missallanios Income',1000.00,'Income','Shihabudheen','801',1,'Cash','','','','',NULL,'',0.00),(857,'2022-06-15 00:00:00','6952','Freezer& O2 Rent',2000.00,'Income','Kopi,k','802',1,'Cash','','','','',NULL,'',0.00),(858,'2022-06-15 00:00:00','6953','Donation',100.00,'Income','Nitheesh K','803',1,'Cash','','','','',NULL,'',0.00),(859,'2022-06-24 00:00:00','6954',' Monthly Subscription',500.00,'Income','Kunhimohamed R P','804',1,'Cash','','','','',NULL,'',0.00),(860,'2022-06-27 00:00:00','6955',' Monthly Subscription',200.00,'Income','Thanima chapathi compani','805',1,'Cash','','','','',NULL,'',0.00),(861,'2022-06-27 00:00:00','6956',' Monthly Subscription',100.00,'Income','Rajan ,hotel','806',1,'Cash','','','','',NULL,'',0.00),(862,'2022-06-27 00:00:00','6957',' Monthly Subscription',100.00,'Income','Rafi, chikken stal','807',1,'Cash','','','','',NULL,'',0.00),(863,'2022-06-27 00:00:00','6958',' Monthly Subscription',100.00,'Income','Noufal , jameela store','808',1,'Cash','','','','',NULL,'',0.00),(864,'2022-06-27 00:00:00','6959',' Monthly Subscription',100.00,'Income','Babu store','809',1,'Cash','','','','',NULL,'',0.00),(865,'2022-06-27 00:00:00','6960',' Monthly Subscription',1000.00,'Income','Bake palce','810',1,'Cash','','','','',NULL,'',0.00),(866,'2022-06-27 00:00:00','6961',' Monthly Subscription',100.00,'Income','Chambayil Medicals','811',1,'Cash','','','','',NULL,'',0.00),(867,'2022-06-27 00:00:00','6962',' Monthly Subscription',100.00,'Income','Koyambthur Farmacy','812',1,'Cash','','','','',NULL,'',0.00),(868,'2022-06-27 00:00:00','6963',' Monthly Subscription',100.00,'Income','Times,Mangalam','813',1,'Cash','','','','',NULL,'',0.00),(869,'2022-06-27 00:00:00','6964',' Monthly Subscription',100.00,'Income','Citty medicals','814',1,'Cash','','','','',NULL,'',0.00),(870,'2022-06-27 00:00:00','6965',' Monthly Subscription',100.00,'Income','Thanweer','815',1,'Cash','','','','',NULL,'',0.00),(871,'2022-06-27 00:00:00','6966',' Monthly Subscription',100.00,'Income','Husain','816',1,'Cash','','','','',NULL,'',0.00),(872,'2022-06-27 00:00:00','6967',' Monthly Subscription',150.00,'Income','Kanhikoth Electricals','817',1,'Cash','','','','',NULL,'',0.00),(873,'2022-06-27 00:00:00','6968',' Monthly Subscription',200.00,'Income','Rose Textiles','818',1,'Cash','','','','',NULL,'',0.00),(874,'2022-06-27 00:00:00','6969',' Monthly Subscription',150.00,'Income','Naser Saloon','819',1,'Cash','','','','',NULL,'',0.00),(875,'2022-06-27 00:00:00','6970',' Monthly Subscription',100.00,'Income','Bismi Store','820',1,'Cash','','','','',NULL,'',0.00),(876,'2022-06-27 00:00:00','6971',' Monthly Subscription',250.00,'Income','A K Store','821',1,'Cash','','','','',NULL,'',0.00),(877,'2022-06-28 00:00:00','6972',' Monthly Subscription',500.00,'Income','Dheema Jwellary','822',1,'Cash','','','','',NULL,'',0.00),(878,'2022-06-28 00:00:00','6973',' Monthly Subscription',100.00,'Income','Kishore Master','823',1,'Cash','','','','',NULL,'',0.00),(879,'2022-06-28 00:00:00','6974',' Monthly Subscription',100.00,'Income','Impress','824',1,'Cash','','','','',NULL,'',0.00),(880,'2022-06-28 00:00:00','6975',' Monthly Subscription',250.00,'Income','Aswas Pharmacy','825',1,'Cash','','','','',NULL,'',0.00),(881,'2022-06-28 00:00:00','6976',' Monthly Subscription',500.00,'Income','Footbeet','826',1,'Cash','','','','',NULL,'',0.00),(882,'2022-06-28 00:00:00','6977',' Monthly Subscription',100.00,'Income','K K Vegitable','827',1,'Cash','','','','',NULL,'',0.00),(883,'2022-06-28 00:00:00','6978',' Monthly Subscription',100.00,'Income','V P Chikken stal','828',1,'Cash','','','','',NULL,'',0.00),(884,'2022-06-28 00:00:00','6980',' Monthly Subscription',200.00,'Income','Technopoint','829',1,'Cash','','','','',NULL,'',0.00),(885,'2022-06-28 00:00:00','6981',' Monthly Subscription',100.00,'Income','Shanus Buty','830',1,'Cash','','','','',NULL,'',0.00),(886,'2022-06-28 00:00:00','6982',' Monthly Subscription',500.00,'Income','A M Store','831',1,'Cash','','','','',NULL,'',0.00),(887,'2022-06-28 00:00:00','6983',' Monthly Subscription',400.00,'Income','P K C Bakery','832',1,'Cash','','','','',NULL,'',0.00),(888,'2022-06-28 00:00:00','6984',' Monthly Subscription',100.00,'Income','Mangalam Mill','833',1,'Cash','','','','',NULL,'',0.00),(889,'2022-06-29 00:00:00','6985',' Monthly Subscription',1000.00,'Income','Ismail Shope','834',1,'Cash','','','','',NULL,'',0.00),(890,'2022-06-29 00:00:00','6986',' Monthly Subscription',100.00,'Income','I One Mobile','835',1,'Cash','','','','',NULL,'',0.00),(891,'2022-06-29 00:00:00','6987',' Monthly Subscription',100.00,'Income','Nadiya Fancy','836',1,'Cash','','','','',NULL,'',0.00),(892,'2022-06-29 00:00:00','6988',' Monthly Subscription',100.00,'Income','Akhila','837',1,'Cash','','','','',NULL,'',0.00),(893,'2022-06-29 00:00:00','6989',' Monthly Subscription',500.00,'Income','Mangalam Dental Clinic','838',1,'Cash','','','','',NULL,'',0.00),(894,'2022-06-29 00:00:00','6990',' Monthly Subscription',100.00,'Income','Rafa Clinic','839',1,'Cash','','','','',NULL,'',0.00),(895,'2022-06-29 00:00:00','6991',' Monthly Subscription',100.00,'Income','Siraj Shop','840',1,'Cash','','','','',NULL,'',0.00),(896,'2022-06-29 00:00:00','6992',' Monthly Subscription',300.00,'Income','Kunhuttimon','841',1,'Cash','','','','',NULL,'',0.00),(897,'2022-06-29 00:00:00','6993m',' Monthly Subscription',300.00,'Income','Alimon,alfa','842',1,'Cash','','','','',NULL,'',0.00),(898,'2022-06-29 00:00:00','6994',' Monthly Subscription',100.00,'Income','Rashon Shop','843',1,'Cash','','','','',NULL,'',0.00),(899,'2022-06-29 00:00:00','6995',' Monthly Subscription',100.00,'Income','ATR Chikken stal','844',1,'Cash','','','','',NULL,'',0.00),(900,'2022-06-29 00:00:00','6996',' Monthly Subscription',100.00,'Income','Abdul Majeed M P','845',1,'Cash','','','','',NULL,'',0.00),(901,'2022-06-29 00:00:00','6997',' Monthly Subscription',500.00,'Income','B Squre','846',1,'Cash','','','','',NULL,'',0.00),(902,'2022-06-29 00:00:00','6998',' Monthly Subscription',100.00,'Income','Shaji PKS','847',1,'Cash','','','','',NULL,'',0.00),(903,'2022-06-29 00:00:00','6999',' Monthly Subscription',500.00,'Income','M T C Mangalam','848',1,'Cash','','','','',NULL,'',0.00),(904,'2022-06-29 00:00:00','7000',' Monthly Subscription',100.00,'Income','Lillis Bakery','849',1,'Cash','','','','',NULL,'',0.00),(905,'2022-06-29 00:00:00','7001',' Monthly Subscription',250.00,'Income','P K C Store','850',1,'Cash','','','','',NULL,'',0.00),(906,'2022-06-29 00:00:00','7002',' Monthly Subscription',250.00,'Income','Crimbis Bakery','851',1,'Cash','','','','',NULL,'',0.00),(907,'2022-06-29 00:00:00','7003',' Monthly Subscription',100.00,'Income','KPK Vegitables','852',1,'Cash','','','','',NULL,'',0.00),(908,'2022-06-30 00:00:00','7004',' Monthly Subscription',100.00,'Income','Kerala Store','853',1,'Cash','','','','',NULL,'',0.00),(909,'2022-06-30 00:00:00','7005',' Monthly Subscription',200.00,'Income','Perfect Electricals','854',1,'Cash','','','','',NULL,'',0.00),(910,'2022-06-30 00:00:00','7006',' Monthly Subscription',150.00,'Income','Friends Banana shop','855',1,'Cash','','','','',NULL,'',0.00),(911,'2022-06-30 00:00:00','7007',' Monthly Subscription',200.00,'Income','Colors ','856',1,'Cash','','','','',NULL,'',0.00),(912,'2022-06-30 00:00:00','7008',' Monthly Subscription',250.00,'Income','Bos Textiles','857',1,'Cash','','','','',NULL,'',0.00),(913,'2022-06-30 00:00:00','7009',' Monthly Subscription',100.00,'Income','Soubhagya Tyre Work','858',1,'Cash','','','','',NULL,'',0.00),(914,'2022-06-30 00:00:00','7010',' Monthly Subscription',100.00,'Income','Shajahan Online','859',1,'Cash','','','','',NULL,'',0.00),(915,'2022-06-30 00:00:00','7011',' Monthly Subscription',200.00,'Income','Mundiri Footware','860',1,'Cash','','','','',NULL,'',0.00),(916,'2022-06-30 00:00:00','7012',' Monthly Subscription',500.00,'Income','Corner Vegitable','861',1,'Cash','','','','',NULL,'',0.00),(917,'2022-06-30 00:00:00','7013',' Monthly Subscription',100.00,'Income','RAK Pharma','862',1,'Cash','','','','',NULL,'',0.00),(918,'2022-06-30 00:00:00','7014',' Monthly Subscription',100.00,'Income','Oushadhi','863',1,'Cash','','','','',NULL,'',0.00),(919,'2022-06-28 00:00:00','7015',' Monthly Subscription',500.00,'Income','New my Brother','864',1,'Cash','','','','',NULL,'',0.00),(920,'2022-06-30 00:00:00','7016',' Monthly Subscription',100.00,'Income','Indian Bakes','865',1,'Cash','','','','',NULL,'',0.00),(921,'2022-06-30 00:00:00','7017',' Monthly Subscription',100.00,'Income','Citty Draiwing Scool','866',1,'Cash','','','','',NULL,'',0.00),(922,'2022-06-01 00:00:00','331-337','HOPE',1100.00,'Income','HOPE','895',1,'Cash','','','','',NULL,'',0.00),(923,'2022-06-02 00:00:00','338-346','HOPE',1600.00,'Income','HOPE','896',1,'Cash','','','','',NULL,'',0.00),(924,'2022-06-03 00:00:00','347-353','HOPE',1200.00,'Income','HOPE','897',1,'Cash','','','','',NULL,'',0.00),(925,'2022-06-04 00:00:00','354-360','HOPE',1200.00,'Income','HOPE','898',1,'Cash','','','','',NULL,'',0.00),(926,'2022-06-06 00:00:00','361-369','HOPE',1600.00,'Income','HOPE','899',1,'Cash','','','','',NULL,'',0.00),(927,'2022-06-07 00:00:00','370-376','HOPE',1000.00,'Income','HOPE','900',1,'Cash','','','','',NULL,'',0.00),(928,'2022-06-08 00:00:00','377-383','HOPE',1100.00,'Income','HOPE','901',1,'Cash','','','','',NULL,'',0.00),(929,'2022-06-09 00:00:00','384-392','HOPE',1500.00,'Income','HOPE','902',1,'Cash','','','','',NULL,'',0.00),(930,'2022-06-10 00:00:00','393-399','HOPE',1200.00,'Income','HOPE','903',1,'Cash','','','','',NULL,'',0.00),(931,'2022-06-11 00:00:00','400-403','HOPE',800.00,'Income','HOPE','904',1,'Cash','','','','',NULL,'',0.00),(932,'2022-06-13 00:00:00','404-409','HOPE',1100.00,'Income','HOPE','905',1,'Cash','','','','',NULL,'',0.00),(933,'2022-06-14 00:00:00','410-414','HOPE',900.00,'Income','HOPE','906',1,'Cash','','','','',NULL,'',0.00),(934,'2022-06-15 00:00:00','415-418','HOPE',800.00,'Income','HOPE','908',1,'Cash','','','','',NULL,'',0.00),(935,'2022-06-16 00:00:00','419-425','HOPE',1200.00,'Income','JHOPE','907',1,'Cash','','','','',NULL,'',0.00),(936,'2022-06-17 00:00:00','426-429','HOPE',800.00,'Income','HOPE','909',1,'Cash','','','','',NULL,'',0.00),(937,'2022-06-18 00:00:00','430-433','HOPE',700.00,'Income','HOPE','910',1,'Cash','','','','',NULL,'',0.00),(938,'2022-06-20 00:00:00','434-437','HOPE',800.00,'Income','HOPE','911',1,'Cash','','','','',NULL,'',0.00),(939,'2022-06-21 00:00:00','438-441','HOPE',800.00,'Income','HOPE','912',1,'Cash','','','','',NULL,'',0.00),(940,'2022-06-22 00:00:00','442-446','HOPE',1000.00,'Income','HOPE','914',1,'Cash','','','','',NULL,'',0.00),(941,'2022-06-23 00:00:00','447-450','HOPE',700.00,'Income','HOPE','913',1,'Cash','','','','',NULL,'',0.00),(942,'2022-06-24 00:00:00','451-455','HOPE',800.00,'Income','HOPE','915',1,'Cash','','','','',NULL,'',0.00),(943,'2022-06-25 00:00:00','456-459','HOPE',600.00,'Income','HOPE','916',1,'Cash','','','','',NULL,'',0.00),(944,'2022-06-27 00:00:00','460-467','HOPE',1400.00,'Income','HOPE','917',1,'Cash','','','','',NULL,'',0.00),(945,'2022-06-28 00:00:00','468-473','HOPE',1100.00,'Income','HOPE','918',1,'Cash','','','','',NULL,'',0.00),(946,'2022-06-29 00:00:00','474-481','HOPE',1300.00,'Income','HOPE','919',1,'Cash','','','','',NULL,'',0.00),(947,'2022-06-30 00:00:00','482-489','HOPE',1400.00,'Income','HOPE','920',1,'Cash','','','','',NULL,'',0.00),(948,'2022-06-01 00:00:00','131A','Homecare Refreshment',-180.00,'Expense','Shilpa','789',1,'Cash','','','','',NULL,'',0.00),(949,'2022-06-01 00:00:00','132A','Telephone Charge',-180.00,'Expense','Shilpa','790',1,'Cash','','','','',NULL,'',0.00),(950,'2022-06-01 00:00:00','133','Building Work',-3525.00,'Expense','Sukumaran','696',1,'Cash','','','','',NULL,'',0.00),(951,'2022-06-02 00:00:00','134','Homecare Refreshment',-160.00,'Expense','Shilpa','697',1,'Cash','','','','',NULL,'',0.00),(952,'2022-06-02 00:00:00','135','Building Work',-5850.00,'Expense','S & S Building Solution','698',1,'Cash','','','','',NULL,'',0.00),(953,'2022-06-03 00:00:00','136','Homecare Refreshment',-210.00,'Expense','Smitha','699',1,'Cash','','','','',NULL,'',0.00),(954,'2022-06-03 00:00:00','137','Building Work',-5700.00,'Expense','S & S Building Solution','700',1,'Cash','','','','',NULL,'',0.00),(955,'2022-06-04 00:00:00','138','Vehicle Expense',-2000.00,'Expense','K P K petrolium','701',1,'Cash','','','','',NULL,'',0.00),(956,'2022-06-04 00:00:00','139','Homecare Refreshment',-200.00,'Expense','Smitha','702',1,'Cash','','','','',NULL,'',0.00),(957,'2022-06-04 00:00:00','140','Building Work',-280.00,'Expense','Jabir','703',1,'Cash','','','','',NULL,'',0.00),(958,'2022-06-05 00:00:00','141A','Homecare Refreshment',-160.00,'Expense','Shilpa','791',1,'Cash','','','','',NULL,'',0.00),(959,'2022-06-05 00:00:00','141 Msand','Building Work',-6000.00,'Expense','Yoonus','705',1,'Cash','','','','',NULL,'',0.00),(960,'2022-06-05 00:00:00','142','Building Work',-9000.00,'Expense','Murali','706',1,'Cash','','','','',NULL,'',0.00),(961,'2022-06-06 00:00:00','143','D H C Fees',-2500.00,'Expense','Dr. Farisa M Baheer','799',1,'Cash','','','','',NULL,'',0.00),(962,'2022-06-06 00:00:00','144','Homecare Refreshment',-230.00,'Expense','Shilpa','708',1,'Cash','','','','',NULL,'',0.00),(963,'2022-06-06 00:00:00','145','Building Work',-8000.00,'Expense','Murali','709',1,'Cash','','','','',NULL,'',0.00),(964,'2022-06-07 00:00:00','146','Homecare Refreshment',-175.00,'Expense','Shilpa','710',1,'Cash','','','','',NULL,'',0.00),(965,'2022-06-08 00:00:00','147','Homecare Refreshment',-250.00,'Expense','Shilpa','711',1,'Cash','','','','',NULL,'',0.00),(966,'2022-06-08 00:00:00','148','Building Work',-9000.00,'Expense','Murali','712',1,'Cash','','','','',NULL,'',0.00),(967,'2022-06-09 00:00:00','149','Homecare Refreshment',-210.00,'Expense','Shilpa','713',1,'Cash','','','','',NULL,'',0.00),(968,'2022-06-09 00:00:00','150','Building Work',-7000.00,'Expense','Murali','714',1,'Cash','','','','',NULL,'',0.00),(969,'2022-06-10 00:00:00','151','Furniture & Fittings',-15000.00,'Expense','Skeeb,Palcareplus','715',1,'Cash','','','','',NULL,'',0.00),(970,'2022-06-10 00:00:00','152','Homecare Refreshment',-300.00,'Expense','Smitha','716',1,'Cash','','','','',NULL,'',0.00),(971,'2022-06-11 00:00:00','153','Homecare Refreshment',-200.00,'Expense','Shimla','717',1,'Cash','','','','',NULL,'',0.00),(972,'2022-06-11 00:00:00','154','Building Work',-8000.00,'Expense','Murali','718',1,'Cash','','','','',NULL,'',0.00),(973,'2022-06-12 00:00:00','155','Homecare Refreshment',-60.00,'Expense','Shilpa','719',1,'Cash','','','','',NULL,'',0.00),(974,'2022-06-12 00:00:00','156','Ambulance Commision',-150.00,'Expense','Abdul Naser K P','720',1,'Cash','','','','',NULL,'',0.00),(975,'2022-06-12 00:00:00','157','Missallanios Expense',-100.00,'Expense','Rasheed,electrition','721',1,'Cash','','','','',NULL,'',0.00),(976,'2022-06-12 00:00:00','158','Telephone Charge',-180.00,'Expense','Shilpa','722',1,'Cash','','','','',NULL,'',0.00),(977,'2022-06-12 00:00:00','159','Building Work',-8000.00,'Expense','Murali','723',1,'Cash','','','','',NULL,'',0.00),(978,'2022-06-13 00:00:00','160, Vehicle Service','Vehicle Expense',-600.00,'Expense','Evershine Auto Village','724',1,'Cash','','','','',NULL,'',0.00),(979,'2022-06-13 00:00:00','161','Homecare Refreshment',-240.00,'Expense','Shilpa','725',1,'Cash','','','','',NULL,'',0.00),(980,'2022-06-13 00:00:00','162','Vehicle Expense',-110.00,'Expense','Pollution Control','726',1,'Cash','','','','',NULL,'',0.00),(981,'2022-06-13 00:00:00','163','Building Work',-6000.00,'Expense','Murali','727',1,'Cash','','','','',NULL,'',0.00),(982,'2022-06-14 00:00:00','164','Homecare Refreshment',-240.00,'Expense','Shilpa','728',1,'Cash','','','','',NULL,'',0.00),(983,'2022-06-15 00:00:00','165','Homecare Refreshment',-160.00,'Expense','Smitha','729',1,'Cash','','','','',NULL,'',0.00),(984,'2022-06-15 00:00:00','166','Building Work',-1700.00,'Expense','Jabir','730',1,'Cash','','','','',NULL,'',0.00),(985,'2022-06-15 00:00:00','167','Building Work',-6450.00,'Expense','Jabir','731',1,'Cash','','','','',NULL,'',0.00),(986,'2022-06-16 00:00:00','168','Vehicle Expense',-2000.00,'Expense','K P K Petrolium','732',1,'Cash','','','','',NULL,'',0.00),(987,'2022-06-16 00:00:00','169','D H C Fees',-3000.00,'Expense','Dr. Majida','800',1,'Cash','','','','',NULL,'',0.00),(988,'2022-06-16 00:00:00','170','Homecare Refreshment',-270.00,'Expense','Shilpa','734',1,'Cash','','','','',NULL,'',0.00),(989,'2022-06-16 00:00:00','171','Building Work',-200.00,'Expense','Jabir','735',1,'Cash','','','','',NULL,'',0.00),(990,'2022-06-16 00:00:00','172','Building Work',-600.00,'Expense','Jabir','736',1,'Cash','','','','',NULL,'',0.00),(991,'2022-06-17 00:00:00','171A','Building Work',-2370.00,'Expense','S & S Traders','792',1,'Cash','','','','',NULL,'',0.00),(992,'2022-06-17 00:00:00','172A','Building Work',-3100.00,'Expense','Murali','793',1,'Cash','','','','',NULL,'',0.00),(993,'2022-06-18 00:00:00','173','Homecare Refreshment',-250.00,'Expense','Smitha','739',1,'Cash','','','','',NULL,'',0.00),(994,'2022-06-19 00:00:00','174','Ambulance',-500.00,'Expense','K P K Petrolim','740',1,'Cash','','','','',NULL,'',0.00),(995,'2022-06-19 00:00:00','175','Homecare Refreshment',-245.00,'Expense','Smitha','741',1,'Cash','','','','',NULL,'',0.00),(996,'2022-06-19 00:00:00','176','Building Work',-550.00,'Expense','Murali','742',1,'Cash','','','','',NULL,'',0.00),(997,'2022-06-19 00:00:00','177','Building Work',-1590.00,'Expense','S & S Traders','743',1,'Cash','','','','',NULL,'',0.00),(998,'2022-06-19 00:00:00','178','Building Work',-1700.00,'Expense','Akku','744',1,'Cash','','','','',NULL,'',0.00),(999,'2022-06-20 00:00:00','179','Homecare Refreshment',-220.00,'Expense','Shilpa','745',1,'Cash','','','','',NULL,'',0.00),(1000,'2022-06-20 00:00:00','180','Building Work',-1700.00,'Expense','Akku','746',1,'Cash','','','','',NULL,'',0.00),(1001,'2022-06-21 00:00:00','181','Electricitty Charge',-6519.00,'Expense','K S E B','747',1,'Cash','','','','',NULL,'',0.00),(1002,'2022-06-21 00:00:00','182','Homecare Refreshment',-285.00,'Expense','Shilpa','748',1,'Cash','','','','',NULL,'',0.00),(1003,'2022-06-21 00:00:00','183','Building Work',-3800.00,'Expense','S & S Paints','749',1,'Cash','','','','',NULL,'',0.00),(1004,'2022-06-22 00:00:00','184','Homecare Refreshment',-360.00,'Expense','Shilpa','750',1,'Cash','','','','',NULL,'',0.00),(1005,'2022-06-22 00:00:00','185','Building Work',-800.00,'Expense','Jabir','751',1,'Cash','','','','',NULL,'',0.00),(1006,'2022-06-23 00:00:00','186','D H C Fees',-2500.00,'Expense','Dr. Aysha','801',1,'Cash','','','','',NULL,'',0.00),(1007,'2022-06-23 00:00:00','187','D H C Fees',-5000.00,'Expense','Dr. Henna','802',1,'Cash','','','','',NULL,'',0.00),(1008,'2022-06-23 00:00:00','188','Homecare Refreshment',-180.00,'Expense','Shilpa','754',1,'Cash','','','','',NULL,'',0.00),(1009,'2022-06-23 00:00:00','189','Building Work',-6500.00,'Expense','Sabeer','755',1,'Cash','','','','',NULL,'',0.00),(1010,'2022-06-24 00:00:00','190','Homecare Refreshment',-240.00,'Expense','Smitha','756',1,'Cash','','','','',NULL,'',0.00),(1011,'2022-06-25 00:00:00','191','Homecare Refreshment',-240.00,'Expense','Smitha','757',1,'Cash','','','','',NULL,'',0.00),(1012,'2022-06-25 00:00:00','192','Building Work',-900.00,'Expense','S $S Traders','758',1,'Cash','','','','',NULL,'',0.00),(1013,'2022-06-25 00:00:00','193','Building Work',-930.00,'Expense','Murali','759',1,'Cash','','','','',NULL,'',0.00),(1014,'2022-06-25 00:00:00','194','Building Work',-8000.00,'Expense','Nissar','760',1,'Cash','','','','',NULL,'',0.00),(1015,'2022-06-26 00:00:00','195','Homecare Refreshment',-240.00,'Expense','Shilpa','761',1,'Cash','','','','',NULL,'',0.00),(1016,'2022-06-26 00:00:00','196','Building Work',-9500.00,'Expense','Nissar','762',1,'Cash','','','','',NULL,'',0.00),(1017,'2022-06-27 00:00:00','197','Homecare Refreshment',-255.00,'Expense','Shimla','763',1,'Cash','','','','',NULL,'',0.00),(1018,'2022-06-27 00:00:00','198','Building Work',-9000.00,'Expense','Nissar','764',1,'Cash','','','','',NULL,'',0.00),(1019,'2022-06-28 00:00:00','199','Vehicle Expense',-2000.00,'Expense','K P K Petrolium','765',1,'Cash','','','','',NULL,'',0.00),(1020,'2022-06-28 00:00:00','200','Homecare Refreshment',-270.00,'Expense','Smitha','766',1,'Cash','','','','',NULL,'',0.00),(1021,'2022-06-28 00:00:00','201','Building Work',-6000.00,'Expense','Nissar','767',1,'Cash','','','','',NULL,'',0.00),(1022,'2022-06-29 00:00:00','202','Vehicle Shed',-22570.00,'Expense','Billa Build Mart','768',1,'Cash','','','','',NULL,'',0.00),(1023,'2022-06-29 00:00:00','203','Homecare Refreshment',-180.00,'Expense','Smitha','769',1,'Cash','','','','',NULL,'',0.00),(1024,'2022-06-30 00:00:00','204','Homecare Refreshment',-260.00,'Expense','Shilpa','770',1,'Cash','','','','',NULL,'',0.00),(1025,'2022-06-30 00:00:00','205','Vehicle shed',-11270.00,'Expense','Billas Build Mart','771',1,'Cash','','','','',NULL,'',0.00),(1026,'2022-06-30 00:00:00','206','Building Work',-3330.00,'Expense','Jabir','772',1,'Cash','','','','',NULL,'',0.00),(1027,'2022-06-02 00:00:00','207','Salary',-15000.00,'Expense','Hasna,Physiotherapist','773',1,'Cash','','','','',NULL,'',0.00),(1028,'2022-06-02 00:00:00','208','Salary',-15000.00,'Expense','Rasli,Physiotherapist','774',1,'Cash','','','','',NULL,'',0.00),(1029,'2022-06-04 00:00:00','209','Salary',-12000.00,'Expense','Musthafa,Draiver','775',1,'Cash','','','','',NULL,'',0.00),(1030,'2022-06-04 00:00:00','210','Salary',-8000.00,'Expense','Mohamed Yoosaf ,Ofice secratary','776',1,'Cash','','','','',NULL,'',0.00),(1031,'2022-06-04 00:00:00','211','Salary',-10480.00,'Expense','Shilpa,Nurse','777',1,'Cash','','','','',NULL,'',0.00),(1032,'2022-06-04 00:00:00','212','Salary',-6300.00,'Expense','Smitha,Nurse','781',1,'Cash','','','','',NULL,'',0.00),(1033,'2022-06-04 00:00:00','213','Salary',-2700.00,'Expense','Mohamed Rafi,Draiver','782',1,'Cash','','','','',NULL,'',0.00),(1034,'2022-06-04 00:00:00','214','Salary',-2500.00,'Expense','Radha, sweeper','783',1,'Cash','','','','',NULL,'',0.00),(1035,'2022-06-30 00:00:00','-','Bank loan',-12648.00,'Expense','',NULL,0,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(1036,'2022-06-30 00:00:00','Contra Entry - Cash','Contra Entry',-79250.00,'Expense','',NULL,0,'Cash','','',NULL,NULL,NULL,NULL,0.00),(1037,'2022-06-30 00:00:00','Contra Entry - Bank','Contra Entry',79250.00,'Income','',NULL,0,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801',NULL,NULL,NULL,NULL,0.00),(1038,'2022-06-30 00:00:00','Contra Entry - Bank','Contra Entry',-52500.00,'Expense','',NULL,0,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801',NULL,NULL,NULL,NULL,0.00),(1039,'2022-06-30 00:00:00','Contra Entry - Cash','Contra Entry',52500.00,'Income','',NULL,0,'Cash','','',NULL,NULL,NULL,NULL,0.00),(1040,'2022-04-30 00:00:00','Contra Entry - Bank','Contra Entry',-1032.00,'Expense','',NULL,0,'Bank','Transfer','Kerala Gramin Bank - 40687111000159',NULL,NULL,NULL,NULL,0.00),(1041,'2022-04-30 00:00:00','Contra Entry - Cash','Contra Entry',1032.00,'Income','',NULL,0,'Cash','','',NULL,NULL,NULL,NULL,0.00),(1042,'2022-06-27 00:00:00','Contra Entry - Cash','Contra Entry',-300.00,'Expense','',NULL,0,'Cash','','',NULL,NULL,NULL,NULL,0.00),(1043,'2022-06-27 00:00:00','Contra Entry - Bank','Contra Entry',300.00,'Income','',NULL,0,'Bank','Transfer','Kerala Gramin Bank - 40687111000159',NULL,NULL,NULL,NULL,0.00),(1044,'2022-06-30 00:00:00','Contra Entry - Bank','Contra Entry',-10700.00,'Expense','',NULL,0,'Bank','Transfer','Kerala Gramin Bank - 40687111000159',NULL,NULL,NULL,NULL,0.00),(1045,'2022-06-30 00:00:00','Contra Entry - Cash','Contra Entry',10700.00,'Income','',NULL,0,'Cash','','',NULL,NULL,NULL,NULL,0.00),(1046,'2022-07-01 00:00:00','1991','Donation',2000.00,'Income','Mohamed Kabeer M','921',1,'Cash','','','','',NULL,'',0.00),(1047,'2022-07-08 00:00:00','1992','Donation',2000.00,'Income','Shafi C P','922',1,'Cash','','','','',NULL,'',0.00),(1048,'2022-07-02 00:00:00','1993','Donation',2000.00,'Income','Abdul majeed V m','924',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1049,'2022-07-08 00:00:00','1994','Donation',2000.00,'Income','Yasir V M','925',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1050,'2022-07-08 00:00:00','1995','Donation',2000.00,'Income','Jamsheer ali V P','926',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1051,'2022-07-10 00:00:00','1996','Donation',5000.00,'Income','Fakurudheen V P','927',1,'Cash','','','','',NULL,'',0.00),(1052,'2022-07-10 00:00:00','1997','Donation',2000.00,'Income','Ibrahim V P','928',1,'Cash','','','','',NULL,'',0.00),(1053,'2022-07-10 00:00:00','1998','Donation',2000.00,'Income','Shameem Majeed K V','929',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1054,'2022-07-11 00:00:00','1999','Donation',4000.00,'Income','Abdulla Al Amarani','930',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1055,'2022-07-11 00:00:00','2000','masjid Collection',5520.00,'Income','New Juma Masjid,Perunthiruthy','931',1,'Cash','','','','',NULL,'',0.00),(1056,'2022-07-11 00:00:00','2001','masjid Collection',8180.00,'Income','Masjidui Mujahideen,chennara','932',1,'Cash','','','','',NULL,'',0.00),(1057,'2022-07-11 00:00:00','2002','masjid Collection',12500.00,'Income','Masjidu thaqwa','933',1,'Cash','','','','',NULL,'',0.00),(1058,'2022-07-12 00:00:00','2003','masjid Collection',1600.00,'Income','Perunthiruthi Old Juma masjid','934',1,'Cash','','','','',NULL,'',0.00),(1059,'2022-07-12 00:00:00','2004','Donation',2000.00,'Income','Razik M T C','935',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1060,'2022-07-12 00:00:00','2005','masjid Collection',2170.00,'Income','Thotiyil Masjid','936',1,'Cash','','','','',NULL,'',0.00),(1061,'2022-07-12 00:00:00','2006','Donation',10000.00,'Income','Jiju s/o Husain K P','937',1,'Cash','','','','',NULL,'',0.00),(1062,'2022-07-15 00:00:00','2007','Donation',4000.00,'Income','Rasik M T C','938',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1063,'2022-07-15 00:00:00','2008',' Monthly Subscription',2000.00,'Income','Jabbar C T','939',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1064,'2022-07-16 00:00:00','2009','masjid Collection',6000.00,'Income','Valamaruthur Juma Masjid','940',1,'Cash','','','','',NULL,'',0.00),(1065,'2022-07-16 00:00:00','2010','Donation',2000.00,'Income','Kunhimoosa C T','941',1,'Cash','','','','',NULL,'',0.00),(1066,'2022-07-16 00:00:00','2011','Donation',5000.00,'Income','Abduraheem K, KHMHS Alathiyur','942',1,'Cash','','','','',NULL,'',0.00),(1067,'2022-07-18 00:00:00','2012','masjid Collection',5000.00,'Income','Kurumbadi Jumamasjid','943',1,'Cash','','','','',NULL,'',0.00),(1068,'2022-07-20 00:00:00','2013','Donation',10000.00,'Income','Mohamed Hashim C K','944',1,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(1069,'2022-07-25 00:00:00','2014','Donation',2000.00,'Income','Shyam Krishnan','945',1,'Cash','','','','',NULL,'',0.00),(1070,'2022-07-26 00:00:00','2015','Donation',2000.00,'Income','Shamsudheen A','946',1,'Cash','','','','',NULL,'',0.00),(1071,'2022-07-27 00:00:00','2016','masjid Collection',3060.00,'Income','Annasseri Jumamasjid','947',1,'Cash','','','','',NULL,'',0.00),(1072,'2022-07-27 00:00:00','2017','Donation',4000.00,'Income','K Baletan & sons','948',1,'Cash','','','','',NULL,'',0.00),(1073,'2022-07-28 00:00:00','2018','Donation',2000.00,'Income','Irshad C N','949',1,'Cash','','','','',NULL,'',0.00),(1074,'2022-07-30 00:00:00','2019','Donation',6000.00,'Income','Jasmir Ali V P','950',1,'Cash','','','','',NULL,'',0.00),(1075,'2022-07-30 00:00:00','2020','Donation',4000.00,'Income','Nisthar P V','951',1,'Cash','','','','',NULL,'',0.00),(1076,'2022-07-30 00:00:00','2021','Donation',2000.00,'Income','Yahutty M P','952',1,'Cash','','','','',NULL,'',0.00),(1077,'2022-07-30 00:00:00','2022','Donation',4000.00,'Income','Alikutty M P','953',1,'Cash','','','','',NULL,'',0.00),(1078,'2022-07-30 00:00:00','2023','Donation',4000.00,'Income','Kunhimohamed K','954',1,'Cash','','','','',NULL,'',0.00),(1079,'2022-07-30 00:00:00','2024','Donation',2000.00,'Income','Yasir M P','955',1,'Cash','','','','',NULL,'',0.00),(1080,'2022-07-31 00:00:00','2025','Donation',4000.00,'Income','Abid Madani T','956',1,'Cash','','','','',NULL,'',0.00),(1081,'2022-07-31 00:00:00','2026','Donation',4000.00,'Income','Zainul Abideen','957',1,'Cash','','','','',NULL,'',0.00),(1082,'2022-07-31 00:00:00','2027','Donation',4000.00,'Income','Shamjeena P V','958',1,'Cash','','','','',NULL,'',0.00),(1083,'2022-07-31 00:00:00','2028','Donation',3000.00,'Income','Avaran kutty','959',1,'Cash','','','','',NULL,'',0.00),(1084,'2022-07-31 00:00:00','2029','Donation',2000.00,'Income','Beeran K P','960',1,'Cash','','','','',NULL,'',0.00),(1085,'2022-07-31 00:00:00','2030','Donation',2000.00,'Income','Abid Master','961',1,'Cash','','','','',NULL,'',0.00),(1086,'2022-07-31 00:00:00','2031','Donation',3000.00,'Income','Abdul Manaf P','962',1,'Cash','','','','',NULL,'',0.00),(1087,'2022-07-31 00:00:00','2032','Donation',5000.00,'Income','Kunhimoosa KP','963',1,'Cash','','','','',NULL,'',0.00),(1088,'2022-07-31 00:00:00','2033','Donation',5000.00,'Income','Abdul Kader KP','964',1,'Cash','','','','',NULL,'',0.00),(1089,'2022-07-31 00:00:00','2034','Donation',3000.00,'Income','Mujeebrahman p','965',1,'Cash','','','','',NULL,'',0.00),(1090,'2022-07-31 00:00:00','2035','Donation',3000.00,'Income','Mohamedkutty V','966',1,'Cash','','','','',NULL,'',0.00),(1091,'2022-07-03 00:00:00','Mohamed Saleem C P',' Monthly Subscription',500.00,'Income','',NULL,0,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1092,'2022-07-03 00:00:00','6877','Rent',2350.00,'Income','Saleem K A','967',1,'Cash','','','','',NULL,'',0.00),(1093,'2022-07-08 00:00:00','6878','Donation',800.00,'Income','Yoosaf K M','968',1,'Cash','','','','',NULL,'',0.00),(1094,'2022-07-08 00:00:00','6879','masjid Collection',520.00,'Income','Kuttammakal Juma masjid','969',1,'Cash','','','','',NULL,'',0.00),(1095,'2022-07-13 00:00:00','6880','masjid Collection',1000.00,'Income','Masjid Noor,Vailipadam','970',1,'Cash','','','','',NULL,'',0.00),(1096,'2022-07-12 00:00:00','6881',' Monthly Subscription',1500.00,'Income','Beerankutty K t','971',1,'Cash','','','','',NULL,'',0.00),(1097,'2022-07-15 00:00:00','6882','-',0.00,'Income','Cancelled','972',1,'Cash','','','','',NULL,'',0.00),(1098,'2022-07-15 00:00:00','6883','Rent',2250.00,'Income','Thilakam','973',1,'Cash','','','','',NULL,'',0.00),(1099,'2022-07-15 00:00:00','6884',' Monthly Subscription',1200.00,'Income','Abdurahman V M','974',1,'Cash','','','','',NULL,'',0.00),(1100,'2022-07-15 00:00:00','6885',' Monthly Subscription',500.00,'Income','Rabiya VM','975',1,'Cash','','','','',NULL,'',0.00),(1101,'2022-07-15 00:00:00','6886','masjid Collection',1000.00,'Income','Kavancheri Juma Masjid','976',1,'Cash','','','','',NULL,'',0.00),(1102,'2022-07-15 00:00:00','6887','Donation',500.00,'Income','Akshay,Kottakkal','977',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1103,'2022-07-15 00:00:00','6888','masjid Collection',600.00,'Income','Kurumpadi Jumamasjid','978',1,'Cash','','','','',NULL,'',0.00),(1104,'2022-07-16 00:00:00','6889',' Monthly Subscription',500.00,'Income','Mohamed Rafi KV','979',1,'Cash','','','','',NULL,'',0.00),(1105,'2022-07-16 00:00:00','6890','Donation',500.00,'Income','Noushadli PS','980',1,'Cash','','','','',NULL,'',0.00),(1106,'2022-07-23 00:00:00','6891','Donation',500.00,'Income','Alavikutty M','981',1,'Cash','','','','',NULL,'',0.00),(1107,'2022-07-26 00:00:00','6892','Rent',250.00,'Income','Post office','982',1,'Cash','','','','',NULL,'',0.00),(1108,'2022-07-26 00:00:00','6893','Rent',2500.00,'Income','Vishnu','983',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1109,'2022-07-26 00:00:00','6894','Donation',1200.00,'Income','Fathima R','984',1,'Cash','','','','',NULL,'',0.00),(1110,'2022-07-01 00:00:00','207','D H C Fees',-2500.00,'Expense','Dr.Sabiq','805',1,'Cash','','','','',NULL,'',0.00),(1111,'2022-07-01 00:00:00','208','Medicines',-14041.00,'Expense','Kims Medicals','806',1,'Cash','','','','',NULL,'',0.00),(1112,'2022-07-01 00:00:00','209','Medicines',-4242.00,'Expense','Bismik medicals','807',1,'Cash','','','','',NULL,'',0.00),(1113,'2022-07-01 00:00:00','210','Medicines',-1652.00,'Expense','Kims Pharma','808',1,'Cash','','','','',NULL,'',0.00),(1114,'2022-07-01 00:00:00','211','Homecare Refreshment',-320.00,'Expense','Shimla','809',1,'Cash','','','','',NULL,'',0.00),(1115,'2022-07-01 00:00:00','212','Telephone Charge',-180.00,'Expense','Shimla','810',1,'Cash','','','','',NULL,'',0.00),(1116,'2022-07-02 00:00:00','213','Salary',-450.00,'Expense','Mohamed rafi','811',1,'Cash','','','','',NULL,'',0.00),(1117,'2022-07-02 00:00:00','214','Homecare Refreshment',-260.00,'Expense','Shimla','812',1,'Cash','','','','',NULL,'',0.00),(1118,'2022-07-02 00:00:00','215','Building Work',-9000.00,'Expense','Nisar','813',1,'Cash','','','','',NULL,'',0.00),(1119,'2022-07-03 00:00:00','216','Homecare Refreshment',-255.00,'Expense','Shimla','814',1,'Cash','','','','',NULL,'',0.00),(1120,'2022-07-03 00:00:00','217','Building Work',-1800.00,'Expense','Rasheed','815',1,'Cash','','','','',NULL,'',0.00),(1121,'2022-07-04 00:00:00','218','Building Work',-2000.00,'Expense','Sreeni','816',1,'Cash','','','','',NULL,'',0.00),(1122,'2022-07-04 00:00:00','219','Homecare Refreshment',-200.00,'Expense','Rafi','817',1,'Cash','','','','',NULL,'',0.00),(1123,'2022-07-05 00:00:00','220','Telephone Charge',-180.00,'Expense','Musthafa','818',1,'Cash','','','','',NULL,'',0.00),(1124,'2022-07-05 00:00:00','221','Furniture & Fittings',-25000.00,'Expense','Power Mech Diesels','819',1,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(1125,'2022-07-05 00:00:00','222','Building Work',-3645.00,'Expense','Jabir','820',1,'Cash','','','','',NULL,'',0.00),(1126,'2022-07-05 00:00:00','223','Homecare Refreshment',-270.00,'Expense','Shimla','821',1,'Cash','','','','',NULL,'',0.00),(1127,'2022-07-05 00:00:00','224','Printing & Stationary',-185.00,'Expense','Udayakumar','822',1,'Cash','','','','',NULL,'',0.00),(1128,'2022-07-06 00:00:00','225','Homecare Refreshment',-245.00,'Expense','Rafi','823',1,'Cash','','','','',NULL,'',0.00),(1129,'2022-07-06 00:00:00','226','Building Work',-8100.00,'Expense','Jayesh','824',1,'Cash','','','','',NULL,'',0.00),(1130,'2022-07-07 00:00:00','227','Building Work',-4500.00,'Expense','Murali','825',1,'Cash','','','','',NULL,'',0.00),(1131,'2022-07-07 00:00:00','228','Homecare Refreshment',-240.00,'Expense','Shimla','826',1,'Cash','','','','',NULL,'',0.00),(1132,'2022-07-07 00:00:00','-','Salary',-8000.00,'Expense','Mohamed Yoosaf','827',1,'Cash','','','','',NULL,'',0.00),(1133,'2022-07-07 00:00:00','-','Salary',-15000.00,'Expense','Hasna , Physio','828',1,'Cash','','','','',NULL,'',0.00),(1134,'2022-07-07 00:00:00','-','Salary',-15000.00,'Expense','Rasly, Physio','829',1,'Cash','','','','',NULL,'',0.00),(1135,'2022-07-07 00:00:00','-','Salary',-12135.00,'Expense','Shilpa','830',1,'Cash','','','','',NULL,'',0.00),(1136,'2022-07-07 00:00:00','-','Salary',-6075.00,'Expense','Smitha','831',1,'Cash','','','','',NULL,'',0.00),(1137,'2022-07-07 00:00:00','-','Salary',-12000.00,'Expense','Musthafa','832',1,'Cash','','','','',NULL,'',0.00),(1138,'2022-07-07 00:00:00','-','Salary',-2700.00,'Expense','Mohamed Rafi','833',1,'Cash','','','','',NULL,'',0.00),(1139,'2022-07-07 00:00:00','-','Salary',-2500.00,'Expense','Radha','834',1,'Cash','','','','',NULL,'',0.00),(1140,'2022-07-08 00:00:00','228','Telephone Charge',-100.00,'Expense','Shimla','835',1,'Cash','','','','',NULL,'',0.00),(1141,'2022-07-07 00:00:00','229','Salary',-1350.00,'Expense','Shimla','836',1,'Cash','','','','',NULL,'',0.00),(1142,'2022-07-08 00:00:00','230','Printing & Stationary',-125.00,'Expense','Udayakumar','837',1,'Cash','','','','',NULL,'',0.00),(1143,'2022-07-08 00:00:00','231','Printing & Stationary',-280.00,'Expense','Udayakumar','838',1,'Cash','','','','',NULL,'',0.00),(1144,'2022-07-08 00:00:00','232','Printing & Stationary',-110.00,'Expense','Udayakumar','839',1,'Cash','','','','',NULL,'',0.00),(1145,'2022-07-08 00:00:00','233','Building Work',-2510.00,'Expense','Murali','840',1,'Cash','','','','',NULL,'',0.00),(1146,'2022-07-08 00:00:00','234','Ambulance',-500.00,'Expense','Hamsahaji & Sons','841',1,'Cash','','','','',NULL,'',0.00),(1147,'2022-07-09 00:00:00','235','Homecare Refreshment',-170.00,'Expense','Mohamed Rafi','842',1,'Cash','','','','',NULL,'',0.00),(1148,'2022-07-10 00:00:00','236','Building Work',-600.00,'Expense','Jabir','843',1,'Cash','','','','',NULL,'',0.00),(1149,'2022-07-11 00:00:00','237','Printing & Stationary',-124.00,'Expense','Udayakumar','844',1,'Cash','','','','',NULL,'',0.00),(1150,'2022-07-11 00:00:00','238','Homecare Refreshment',-210.00,'Expense','Shimla','845',1,'Cash','','','','',NULL,'',0.00),(1151,'2022-07-12 00:00:00','239','Building Work',-2150.00,'Expense','Jabir','846',1,'Cash','','','','',NULL,'',0.00),(1152,'2022-07-12 00:00:00','240','Medicines',-392.00,'Expense','Medico Surgicals','847',1,'Cash','','','','',NULL,'',0.00),(1153,'2022-07-12 00:00:00','241','M I P Subscription',-6000.00,'Expense','M I P','848',1,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(1154,'2022-07-12 00:00:00','242','Homecare Refreshment',-240.00,'Expense','Shimla','849',1,'Cash','','','','',NULL,'',0.00),(1155,'2022-07-12 00:00:00','243','Vehicle Expense',-2000.00,'Expense','K P K Petrolium','850',1,'Cash','','','','',NULL,'',0.00),(1156,'2022-07-12 00:00:00','244','Building Work',-4500.00,'Expense','Rasheed','851',1,'Cash','','','','',NULL,'',0.00),(1157,'2022-07-12 00:00:00','245','Building Work',-33800.00,'Expense','Billas Build Mart','852',1,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(1158,'2022-07-13 00:00:00','246','Homecare Refreshment',-260.00,'Expense','Shimla','853',1,'Cash','','','','',NULL,'',0.00),(1159,'2022-07-13 00:00:00','247','Building Work',-8150.00,'Expense','Nisar','854',1,'Cash','','','','',NULL,'',0.00),(1160,'2022-07-14 00:00:00','248','Homecare Refreshment',-255.00,'Expense','Shimla','855',1,'Cash','','','','',NULL,'',0.00),(1161,'2022-07-14 00:00:00','249','Printing & Stationary',-103.00,'Expense','Udayakumar','856',1,'Cash','','','','',NULL,'',0.00),(1162,'2022-07-14 00:00:00','250','Printing & Stationary',-200.00,'Expense','udayakumar','857',1,'Cash','','','','',NULL,'',0.00),(1163,'2022-07-14 00:00:00','251','Building Work',-4000.00,'Expense','Nisar','858',1,'Cash','','','','',NULL,'',0.00),(1164,'2022-07-15 00:00:00','252','Homecare Refreshment',-240.00,'Expense','Smitha','859',1,'Cash','','','','',NULL,'',0.00),(1165,'2022-07-15 00:00:00','253','Printing & Stationary',-115.00,'Expense','MP Button House','860',1,'Cash','','','','',NULL,'',0.00),(1166,'2022-07-16 00:00:00','254','Missallanios Expense',-1850.00,'Expense','Care One','861',1,'Cash','','','','',NULL,'',0.00),(1167,'2022-07-16 00:00:00','255','Homecare Refreshment',-270.00,'Expense','Shimla','862',1,'Cash','','','','',NULL,'',0.00),(1168,'2022-07-16 00:00:00','256','Building Work',-430.00,'Expense','Jabir','863',1,'Cash','','','','',NULL,'',0.00),(1169,'2022-07-17 00:00:00','257','Homecare Refreshment',-260.00,'Expense','Shimla','864',1,'Cash','','','','',NULL,'',0.00),(1170,'2022-07-17 00:00:00','258','Building Work',-1700.00,'Expense','Jabir','865',1,'Cash','','','','',NULL,'',0.00),(1171,'2022-07-17 00:00:00','259','Building Work',-1700.00,'Expense','Nisar','866',1,'Cash','','','','',NULL,'',0.00),(1172,'2022-07-18 00:00:00','260','Building Work',-1040.00,'Expense','Jabir','867',1,'Cash','','','','',NULL,'',0.00),(1173,'2022-07-18 00:00:00','261','D H C Fees',-2500.00,'Expense','Dr. Sabiq','868',1,'Cash','','','','',NULL,'',0.00),(1174,'2022-07-18 00:00:00','262','Homecare Refreshment',-400.00,'Expense','Shimla','869',1,'Cash','','','','',NULL,'',0.00),(1175,'2022-07-19 00:00:00','263','Homecare Refreshment',-210.00,'Expense','Shimla','870',1,'Cash','','','','',NULL,'',0.00),(1176,'2022-07-19 00:00:00','264','Building Work',-4000.00,'Expense','Sreeni','871',1,'Cash','','','','',NULL,'',0.00),(1177,'2022-07-19 00:00:00','265','Building Work',-1700.00,'Expense','Jabir','872',1,'Cash','','','','',NULL,'',0.00),(1178,'2022-07-20 00:00:00','266','Homecare Refreshment',-270.00,'Expense','Mohamed rafi','873',1,'Cash','','','','',NULL,'',0.00),(1179,'2022-07-20 00:00:00','267','Printing & Stationary',-50.00,'Expense','Udayakumar','874',1,'Cash','','','','',NULL,'',0.00),(1180,'2022-07-20 00:00:00','268','Building Work',-1700.00,'Expense','Jabir','875',1,'Cash','','','','',NULL,'',0.00),(1181,'2022-07-20 00:00:00','269','Building Work',-5625.00,'Expense','S & S traders','876',1,'Cash','','','','',NULL,'',0.00),(1182,'2022-07-20 00:00:00','270','Building Work',-4500.00,'Expense','Suku','877',1,'Cash','','','','',NULL,'',0.00),(1183,'2022-07-20 00:00:00','271','Building Work',-1400.00,'Expense','Jabir','878',1,'Cash','','','','',NULL,'',0.00),(1184,'2022-07-20 00:00:00','272','Building Work',-6000.00,'Expense','Yunus','879',1,'Cash','','','','',NULL,'',0.00),(1185,'2022-07-21 00:00:00','273','Homecare Refreshment',-200.00,'Expense','Smitha','880',1,'Cash','','','','',NULL,'',0.00),(1186,'2022-07-21 00:00:00','274','Building Work',-6100.00,'Expense','Yunus','881',1,'Cash','','','','',NULL,'',0.00),(1187,'2022-07-21 00:00:00','275','Building Work',-1400.00,'Expense','Yunus','882',1,'Cash','','','','',NULL,'',0.00),(1188,'2022-07-21 00:00:00','276','Building Work',-4740.00,'Expense','Suku','883',1,'Cash','','','','',NULL,'',0.00),(1189,'2022-07-22 00:00:00','277','Homecare Refreshment',-270.00,'Expense','Smitha','884',1,'Cash','','','','',NULL,'',0.00),(1190,'2022-07-22 00:00:00','278','Building Work',-2675.00,'Expense','Suku','885',1,'Cash','','','','',NULL,'',0.00),(1191,'2022-07-22 00:00:00','279','Building Work',-2705.00,'Expense','S& S Traders','886',1,'Cash','','','','',NULL,'',0.00),(1192,'2022-07-23 00:00:00','280','Medicines',-13140.00,'Expense','Kims Pharma','887',1,'Cash','','','','',NULL,'',0.00),(1193,'2022-07-23 00:00:00','281','Medicines',-9895.00,'Expense','Kims Medical Agencies','888',1,'Cash','','','','',NULL,'',0.00),(1194,'2022-07-23 00:00:00','282','Medicines',-918.00,'Expense','Bismik Medical Agenncies','889',1,'Cash','','','','',NULL,'',0.00),(1195,'2022-07-23 00:00:00','283','Printing & Stationary',-140.00,'Expense','Udayakumar','890',1,'Cash','','','','',NULL,'',0.00),(1196,'2022-07-23 00:00:00','284','Vehicle Expense',-100.00,'Expense','Musthafa','891',1,'Cash','','','','',NULL,'',0.00),(1197,'2022-07-23 00:00:00','285','Homecare Refreshment',-270.00,'Expense','Shimla','892',1,'Cash','','','','',NULL,'',0.00),(1198,'2022-07-24 00:00:00','286','Homecare Refreshment',-270.00,'Expense','shimla','893',1,'Cash','','','','',NULL,'',0.00),(1199,'2022-07-25 00:00:00','287','Homecare Refreshment',-270.00,'Expense','Shimla','894',1,'Cash','','','','',NULL,'',0.00),(1200,'2022-07-25 00:00:00','288','Vehicle Expense',-2000.00,'Expense','K P K Petrolium','895',1,'Cash','','','','',NULL,'',0.00),(1201,'2022-07-25 00:00:00','289','Vehicle Expense',-600.00,'Expense','Kairali Car Wash','896',1,'Cash','','','','',NULL,'',0.00),(1202,'2022-07-26 00:00:00','290','Printing & Stationary',-88.00,'Expense','Udayakumar','897',1,'Cash','','','','',NULL,'',0.00),(1203,'2022-07-26 00:00:00','291','Missallanios Expense',-370.00,'Expense','Care One','898',1,'Cash','','','','',NULL,'',0.00),(1204,'2022-07-26 00:00:00','292','Homecare Refreshment',-170.00,'Expense','Shimla','899',1,'Cash','','','','',NULL,'',0.00),(1205,'2022-07-27 00:00:00','293','Homecare Refreshment',-270.00,'Expense','Shimla','900',1,'Cash','','','','',NULL,'',0.00),(1206,'2022-07-28 00:00:00','294','Homecare Refreshment',-285.00,'Expense','Shimla','901',1,'Cash','','','','',NULL,'',0.00),(1207,'2022-07-29 00:00:00','295','Printing & Stationary',-60.00,'Expense','Udayakumar','902',1,'Cash','','','','',NULL,'',0.00),(1208,'2022-07-29 00:00:00','296','Telephone Charge',-180.00,'Expense','Musthafa','903',1,'Cash','','','','',NULL,'',0.00),(1209,'2022-07-29 00:00:00','297','Homecare Refreshment',-240.00,'Expense','smitha','904',1,'Cash','','','','',NULL,'',0.00),(1210,'2022-07-30 00:00:00','298','Homecare Refreshment',-280.00,'Expense','shimla','905',1,'Cash','','','','',NULL,'',0.00),(1211,'2022-07-31 00:00:00','299','Homecare Refreshment',-280.00,'Expense','Smitha','906',1,'Cash','','','','',NULL,'',0.00),(1212,'2022-07-08 00:00:00','7018','Donation',2000.00,'Income','Shareef V P','985',1,'Cash','','','','',NULL,'',0.00),(1213,'2022-07-20 00:00:00','7019','-',0.00,'Income','Canselled','986',1,'Cash','','','','',NULL,'',0.00),(1214,'2022-07-22 00:00:00','7020','Donation',2000.00,'Income','Baiju Kannethayil','987',1,'Cash','','','','',NULL,'',0.00),(1215,'2022-07-28 00:00:00','7021',' Monthly Subscription',100.00,'Income','Indian Bakes','988',1,'Cash','','','','',NULL,'',0.00),(1216,'2022-07-28 00:00:00','7022',' Monthly Subscription',200.00,'Income','Mangalam Times','989',1,'Cash','','','','',NULL,'',0.00),(1217,'2022-07-28 00:00:00','7023',' Monthly Subscription',100.00,'Income','Hussain','990',1,'Cash','','','','',NULL,'',0.00),(1218,'2022-07-28 00:00:00','7024',' Monthly Subscription',200.00,'Income','Rose Textiles','991',1,'Cash','','','','',NULL,'',0.00),(1219,'2022-07-28 00:00:00','7025',' Monthly Subscription',200.00,'Income','Thanima Chappathi Co`','992',1,'Cash','','','','',NULL,'',0.00),(1220,'2022-07-28 00:00:00','7026',' Monthly Subscription',100.00,'Income','rafi chikken stall','993',1,'Cash','','','','',NULL,'',0.00),(1221,'2022-07-28 00:00:00','7027',' Monthly Subscription',100.00,'Income','Babu store','994',1,'Cash','','','','',NULL,'',0.00),(1222,'2022-07-28 00:00:00','7028',' Monthly Subscription',1000.00,'Income','Bake Palce','995',1,'Cash','','','','',NULL,'',0.00),(1223,'2022-07-28 00:00:00','7029',' Monthly Subscription',100.00,'Income','Chambayil Medicals','996',1,'Cash','','','','',NULL,'',0.00),(1224,'2022-07-28 00:00:00','7030',' Monthly Subscription',100.00,'Income','Koyambathur Pharmacy','997',1,'Cash','','','','',NULL,'',0.00),(1225,'2022-07-28 00:00:00','7031',' Monthly Subscription',150.00,'Income','Kanhikoth electricals','998',1,'Cash','','','','',NULL,'',0.00),(1226,'2022-07-28 00:00:00','7032',' Monthly Subscription',500.00,'Income','New my Brother','999',1,'Cash','','','','',NULL,'',0.00),(1227,'2022-07-29 00:00:00','7033','Donation',1500.00,'Income','Rasheed K P','1000',1,'Cash','','','','',NULL,'',0.00),(1228,'2022-07-29 00:00:00','7034',' Monthly Subscription',500.00,'Income','Dheema Jewellary','1001',1,'Cash','','','','',NULL,'',0.00),(1229,'2022-07-29 00:00:00','7035',' Monthly Subscription',250.00,'Income','Aswas pharmacy','1002',1,'Cash','','','','',NULL,'',0.00),(1230,'2022-07-29 00:00:00','7036',' Monthly Subscription',100.00,'Income','K K Brothers','1003',1,'Cash','','','','',NULL,'',0.00),(1231,'2022-07-29 00:00:00','7037',' Monthly Subscription',100.00,'Income','V P Chikken','1004',1,'Cash','','','','',NULL,'',0.00),(1232,'2022-07-29 00:00:00','7038',' Monthly Subscription',100.00,'Income','Fresh Cool','1005',1,'Cash','','','','',NULL,'',0.00),(1233,'2022-07-29 00:00:00','7039',' Monthly Subscription',200.00,'Income','Technopoint','1006',1,'Cash','','','','',NULL,'',0.00),(1234,'2022-07-29 00:00:00','7040',' Monthly Subscription',1000.00,'Income','Ismail shop','1007',1,'Cash','','','','',NULL,'',0.00),(1235,'2022-07-29 00:00:00','7041',' Monthly Subscription',100.00,'Income','one mobile','1008',1,'Cash','','','','',NULL,'',0.00),(1236,'2022-07-29 00:00:00','7042',' Monthly Subscription',100.00,'Income','Nadiya Fancy`','1009',1,'Cash','','','','',NULL,'',0.00),(1237,'2022-07-29 00:00:00','7043',' Monthly Subscription',100.00,'Income','ATR Chikken','1010',1,'Cash','','','','',NULL,'',0.00),(1238,'2022-07-29 00:00:00','7044',' Monthly Subscription',250.00,'Income','Asif crymbis','1011',1,'Cash','','','','',NULL,'',0.00),(1239,'2022-07-30 00:00:00','7045','Donation',1000.00,'Income','Pathunni V P','1012',1,'Cash','','','','',NULL,'',0.00),(1240,'2022-07-30 00:00:00','7046',' Monthly Subscription',500.00,'Income','B squire','1013',1,'Cash','','','','',NULL,'',0.00),(1241,'2022-07-30 00:00:00','7047',' Monthly Subscription',100.00,'Income','AbdulMAjeed MP','1014',1,'Cash','','','','',NULL,'',0.00),(1242,'2022-07-30 00:00:00','7046',' Monthly Subscription',200.00,'Income','M T C mangalam','1015',1,'Cash','','','','',NULL,'',0.00),(1243,'2022-07-30 00:00:00','7049',' Monthly Subscription',100.00,'Income','LILLIES','1016',1,'Cash','','','','',NULL,'',0.00),(1244,'2022-07-30 00:00:00','7050',' Monthly Subscription',250.00,'Income','P K C Store','1017',1,'Cash','','','','',NULL,'',0.00),(1245,'2022-07-30 00:00:00','7051',' Monthly Subscription',100.00,'Income','K P K Vegitable','1018',1,'Cash','','','','',NULL,'',0.00),(1246,'2022-07-30 00:00:00','7052',' Monthly Subscription',300.00,'Income','Alimon Alfa','1019',1,'Cash','','','','',NULL,'',0.00),(1247,'2022-07-30 00:00:00','7053',' Monthly Subscription',300.00,'Income','Kunhuttimon','1020',1,'Cash','','','','',NULL,'',0.00),(1248,'2022-07-30 00:00:00','7054',' Monthly Subscription',100.00,'Income','Care Clinik','1021',1,'Cash','','','','',NULL,'',0.00),(1249,'2022-07-30 00:00:00','7055',' Monthly Subscription',200.00,'Income','Perfect Electricals','1022',1,'Cash','','','','',NULL,'',0.00),(1250,'2022-07-30 00:00:00','7056',' Monthly Subscription',150.00,'Income','Friends Banana shop','1023',1,'Cash','','','','',NULL,'',0.00),(1251,'2022-07-30 00:00:00','7057',' Monthly Subscription',200.00,'Income','Colors','1024',1,'Cash','','','','',NULL,'',0.00),(1252,'2022-07-30 00:00:00','7058',' Monthly Subscription',100.00,'Income','Soubhagya tyre','1025',1,'Cash','','','','',NULL,'',0.00),(1253,'2022-07-30 00:00:00','7059',' Monthly Subscription',100.00,'Income','Citty Draiving scool','1026',1,'Cash','','','','',NULL,'',0.00),(1254,'2022-07-30 00:00:00','7060',' Monthly Subscription',200.00,'Income','Munthiri Foot ware','1027',1,'Cash','','','','',NULL,'',0.00),(1255,'2022-07-30 00:00:00','7061',' Monthly Subscription',500.00,'Income','Cornur Vegitable','1028',1,'Cash','','','','',NULL,'',0.00),(1256,'2022-07-30 00:00:00','7062',' Monthly Subscription',100.00,'Income','Rak Pharma','1029',1,'Cash','','','','',NULL,'',0.00),(1257,'2022-07-30 00:00:00','7063',' Monthly Subscription',100.00,'Income','Oushadhi','1030',1,'Cash','','','','',NULL,'',0.00),(1258,'2022-07-30 00:00:00','7064',' Monthly Subscription',100.00,'Income','Thanveer mobile','1031',1,'Cash','','','','',NULL,'',0.00),(1259,'2022-07-30 00:00:00','7065',' Monthly Subscription',100.00,'Income','Bismi store','1032',1,'Cash','','','','',NULL,'',0.00),(1260,'2022-07-30 00:00:00','7066',' Monthly Subscription',100.00,'Income','Hotel Rajan','1033',1,'Cash','','','','',NULL,'',0.00),(1261,'2022-07-30 00:00:00','7067',' Monthly Subscription',150.00,'Income','Naser saloon','1034',1,'Cash','','','','',NULL,'',0.00),(1262,'2022-07-30 00:00:00','7068',' Monthly Subscription',100.00,'Income','Citty Medicals','1035',1,'Cash','','','','',NULL,'',0.00),(1263,'2022-07-30 00:00:00','7069',' Monthly Subscription',250.00,'Income','A K Store','1036',1,'Cash','','','','',NULL,'',0.00),(1264,'2022-07-30 00:00:00','7070',' Monthly Subscription',100.00,'Income','Impress','1037',1,'Cash','','','','',NULL,'',0.00),(1265,'2022-07-30 00:00:00','7071',' Monthly Subscription',500.00,'Income','Foot Beet','1038',1,'Cash','','','','',NULL,'',0.00),(1266,'2022-07-30 00:00:00','7072',' Monthly Subscription',500.00,'Income','A M store','1039',1,'Cash','','','','',NULL,'',0.00),(1267,'2022-07-01 00:00:00','490-498','HOPE',3900.00,'Income','Hope','1040',1,'Cash','','','','',NULL,'',0.00),(1268,'2022-07-02 00:00:00','499-','HOPE',200.00,'Income','Hope','1041',1,'Cash','','','','',NULL,'',0.00),(1269,'2022-07-04 00:00:00','500-505','HOPE',1500.00,'Income','Hope','1042',1,NULL,'','','','',NULL,'',0.00),(1270,'2022-07-05 00:00:00','506','HOPE',200.00,'Income','Hope','1043',1,'Cash','','','','',NULL,'',0.00),(1271,'2022-07-06 00:00:00','507-513','HOPE',1100.00,'Income','Hope','1044',1,'Cash','','','','',NULL,'',0.00),(1272,'2022-07-07 00:00:00','514-518','HOPE',1500.00,'Income','Hope','1045',1,'Cash','','','','',NULL,'',0.00),(1273,'2022-07-08 00:00:00','519-526','HOPE',1400.00,'Income','Hope','1046',1,'Cash','','','','',NULL,'',0.00),(1274,'2022-07-09 00:00:00','527-529','HOPE',400.00,'Income','Hope','1047',1,'Cash','','','','',NULL,'',0.00),(1275,'2022-07-12 00:00:00','530-534','HOPE',800.00,'Income','Hope','1048',1,'Cash','','','','',NULL,'',0.00),(1276,'2022-07-13 00:00:00','535-537','HOPE',500.00,'Income','Hope','1049',1,'Cash','','','','',NULL,'',0.00),(1277,'2022-07-14 00:00:00','538-541','HOPE',600.00,'Income','Hope','1050',1,'Cash','','','','',NULL,'',0.00),(1278,'2022-07-15 00:00:00','542-546','HOPE',800.00,'Income','Hope','1051',1,'Cash','','','','',NULL,'',0.00),(1279,'2022-07-16 00:00:00','547-549','HOPE',500.00,'Income','Hope','1052',1,'Cash','','','','',NULL,'',0.00),(1280,'2022-07-18 00:00:00','550','HOPE',200.00,'Income','Hope','1053',1,'Cash','','','','',NULL,'',0.00),(1281,'2022-07-19 00:00:00','551-','HOPE',100.00,'Income','Hope','1054',1,'Cash','','','','',NULL,'',0.00),(1282,'2022-07-20 00:00:00','552-553','HOPE',300.00,'Income','Hope','1055',1,'Cash','','','','',NULL,'',0.00),(1283,'2022-07-21 00:00:00','554','HOPE',200.00,'Income','Hope','1056',1,'Cash','','','','',NULL,'',0.00),(1284,'2022-07-22 00:00:00','555-558','HOPE',900.00,'Income','Hope','1057',1,'Cash','','','','',NULL,'',0.00),(1285,'2022-07-23 00:00:00','559-562','HOPE',800.00,'Income','Hope','1058',1,'Cash','','','','',NULL,'',0.00),(1286,'2022-07-25 00:00:00','563-565','HOPE',400.00,'Income','Hope','1059',1,'Cash','','','','',NULL,'',0.00),(1287,'2022-07-26 00:00:00','566-571','HOPE',2900.00,'Income','Hope','1060',1,'Cash','','','','',NULL,'',0.00),(1288,'2022-07-27 00:00:00','572-579','HOPE',1550.00,'Income','Hope','1061',1,'Cash','','','','',NULL,'',0.00),(1289,'2022-07-28 00:00:00','580-587','HOPE',1450.00,'Income','Hope','1062',1,'Cash','','','','',NULL,'',0.00),(1290,'2022-07-29 00:00:00','588-595','HOPE',1400.00,'Income','Hope','1063',1,'Cash','','','','',NULL,'',0.00),(1291,'2022-07-30 00:00:00','596-603','HOPE',1500.00,'Income','Hope','1064',1,'Cash','','','','',NULL,'',0.00),(1292,'2022-07-06 00:00:00','-','Bank loan',-12648.00,'Expense','I C IC I Bank','907',1,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(1293,'2022-07-30 00:00:00','Contra Entry - Bank','Contra Entry',-28925.00,'Expense','',NULL,0,'Bank','Transfer','Kerala Gramin Bank - 40687111000159',NULL,NULL,NULL,NULL,0.00),(1294,'2022-07-30 00:00:00','Contra Entry - Cash','Contra Entry',28925.00,'Income','',NULL,0,'Cash','','',NULL,NULL,NULL,NULL,0.00),(1295,'2022-07-30 00:00:00','Contra Entry - Cash','Contra Entry',-23650.00,'Expense','',NULL,0,'Cash','','',NULL,NULL,NULL,NULL,0.00),(1296,'2022-07-30 00:00:00','Contra Entry - Bank','Contra Entry',23650.00,'Income','',NULL,0,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801',NULL,NULL,NULL,NULL,0.00),(1297,'2022-07-31 00:00:00','-','Ambulance commision',-855.00,'Expense','Mohamed Rafi','908',1,'Cash','','','','',NULL,'',0.00),(1298,'2022-04-30 00:00:00','1-2','Ambulance',2400.00,'Income','Mohamed rafi','1065',1,'Cash','','','','',NULL,'',0.00),(1299,'2022-07-31 00:00:00','3-7','Ambulance',2850.00,'Income','Mohamed Rafi','1066',1,'Cash','','','','',NULL,'',0.00),(1300,'2022-07-31 00:00:00','-','Ambulance commision',0.00,'Expense','Mohamed Rafi','910',1,'Cash','','','','',NULL,'',0.00),(1301,'2022-08-05 00:00:00','1668','Donation',2000.00,'Income','Musthafa  K V','1067',1,'Cash','','','','',NULL,'',0.00),(1302,'2022-08-05 00:00:00','1669','Donation',2000.00,'Income','Sidheeq Ponnani','1068',1,'Cash','','','','',NULL,'',0.00),(1303,'2022-08-07 00:00:00','1670',' Monthly Subscription',10000.00,'Income','Kunhimoosa C P','1069',1,'Cash','','','','',NULL,'',0.00),(1304,'2022-08-08 00:00:00','1671','Donation',40000.00,'Income','Zainaba Teacher','1070',1,'Cash','','','','',NULL,'',0.00),(1305,'2022-08-08 00:00:00','1672','Donation',2000.00,'Income','Abdul Salam V P','1071',1,'Cash','','','','',NULL,'',0.00),(1306,'2022-08-12 00:00:00','1673','Donation',4000.00,'Income','Abubacker Sidheeq K K','1072',1,'Cash','','','','',NULL,'',0.00),(1307,'2022-08-13 00:00:00','1674','Donation',15000.00,'Income','Fujairah KMCC ','1073',1,'Cash','','','','',NULL,'',0.00),(1308,'2022-08-15 00:00:00','1675',' Monthly Subscription',4000.00,'Income','Saidalavi K P','1074',1,'Cash','','','','',NULL,'',0.00),(1309,'2022-08-16 00:00:00','1676','Donation',10000.00,'Income','Musthafa K P','1075',1,'Cash','','','','',NULL,'',0.00),(1310,'2022-08-21 00:00:00','1677',' Monthly Subscription',2000.00,'Income','Jabbar CT','1076',1,'Cash','','','','',NULL,'',0.00),(1311,'2022-08-23 00:00:00','1678','Donation',2500.00,'Income','Mayadevi','1077',1,'Cash','','','','',NULL,'',0.00),(1312,'2022-08-25 00:00:00','1679','Donation',5000.00,'Income','Syam, Krishnasruthi','1078',1,'Cash','','','','',NULL,'',0.00),(1313,'2022-08-27 00:00:00','1680','Donation',10000.00,'Income','Abdul Kareem V P','1079',1,'Cash','','','','',NULL,'',0.00),(1314,'2022-08-31 00:00:00','1681','Rent',12850.00,'Income','Shiyad T','1080',1,'Cash','','','','',NULL,'',0.00),(1315,'2022-08-01 00:00:00','2036','Donation',5000.00,'Income','Katheeja P V','1081',1,'Cash','','','','',NULL,'',0.00),(1316,'2022-08-01 00:00:00','2037','Donation',4000.00,'Income','Shamsudheen PK','1082',1,'Cash','','','','',NULL,'',0.00),(1317,'2022-08-01 00:00:00','2038','Donation',4000.00,'Income','Moideen kutty M M','1083',1,'Cash','','','','',NULL,'',0.00),(1318,'2022-08-01 00:00:00','2039','Donation',3000.00,'Income','Mohamed Kassim PP','1084',1,'Cash','','','','',NULL,'',0.00),(1319,'2022-08-02 00:00:00','2040','Donation',5000.00,'Income','Abdul Shukoor M K','1085',1,'Cash','','','','',NULL,'',0.00),(1320,'2022-08-02 00:00:00','2041','Donation',4000.00,'Income','Kunhimoosa P','1086',1,'Cash','','','','',NULL,'',0.00),(1321,'2022-08-02 00:00:00','2042','Donation',6000.00,'Income','Mohamed Musthafa V P','1087',1,'Cash','','','','',NULL,'',0.00),(1322,'2022-08-02 00:00:00','2043','Donation',5000.00,'Income','Khamarunneesa VV','1088',1,'Cash','','','','',NULL,'',0.00),(1323,'2022-08-03 00:00:00','2044','Donation',4000.00,'Income','Abdul Latheef P P','1089',1,'Cash','','','','',NULL,'',0.00),(1324,'2022-08-03 00:00:00','2045','Donation',3000.00,'Income','Eantheenkutty M','1090',1,'Cash','','','','',NULL,'',0.00),(1325,'2022-08-03 00:00:00','2046','Donation',6000.00,'Income','Zainudheen M','1091',1,'Cash','','','','',NULL,'',0.00),(1326,'2022-08-03 00:00:00','2047','Donation',7000.00,'Income','Moideenkutty V P','1092',1,'Cash','','','','',NULL,'',0.00),(1327,'2022-08-03 00:00:00','2048','Donation',4000.00,'Income','Ayshakutty N M','1093',1,'Cash','','','','',NULL,'',0.00),(1328,'2022-08-05 00:00:00','2049','Donation',2000.00,'Income','Makyamakutty A','1094',1,'Cash','','','','',NULL,'',0.00),(1329,'2022-08-05 00:00:00','2050',' Monthly Subscription',2000.00,'Income','Shahul Hameed P K','1095',1,'Cash','','','','',NULL,'',0.00),(1330,'2022-08-10 00:00:00','6287','Rent',2250.00,'Income','Thilakam','1096',1,'Cash','','','','',NULL,'',0.00),(1331,'2022-08-12 00:00:00','6288','Rent',2400.00,'Income','Vishnu','1097',1,'Cash','','','','',NULL,'',0.00),(1332,'2022-08-12 00:00:00','6289','Donation',500.00,'Income','Abdurahman Master VM Marhum','1098',1,'Cash','','','','',NULL,'',0.00),(1333,'2022-08-14 00:00:00','6290','Donation',200.00,'Income','Afrah V M','1126',1,'Cash','','','','',NULL,'',0.00),(1334,'2022-08-15 00:00:00','6291','masjid Collection',1000.00,'Income','Thalookara Juma Masjid','1100',1,'Cash','','','','',NULL,'',0.00),(1335,'2022-08-16 00:00:00','6292',' Monthly Subscription',500.00,'Income','Abdusalam M V','1101',1,'Cash','','','','',NULL,'',0.00),(1336,'2022-08-19 00:00:00','6293','Donation',500.00,'Income','Bapu haji KT','1102',1,'Cash','','','','',NULL,'',0.00),(1337,'2022-08-23 00:00:00','6294',' Monthly Subscription',3000.00,'Income','Kunhibava K V','1103',1,'Cash','','','','',NULL,'',0.00),(1338,'2022-08-23 00:00:00','6295',' Monthly Subscription',1500.00,'Income','Abdul Majed K V','1104',1,'Cash','','','','',NULL,'',0.00),(1339,'2022-08-23 00:00:00','6296',' Monthly Subscription',1500.00,'Income','Jaseem Abdulmajeed','1105',1,'Cash','','','','',NULL,'',0.00),(1340,'2022-08-27 00:00:00','6297',' Monthly Subscription',1200.00,'Income','Abdurahman V M','1106',1,'Cash','','','','',NULL,'',0.00),(1341,'2022-08-27 00:00:00','6298',' Monthly Subscription',500.00,'Income','Rabiya V M','1107',1,'Cash','','','','',NULL,'',0.00),(1342,'2022-08-29 00:00:00','6299',' Monthly Subscription',250.00,'Income','Dr. HAmeed','1108',1,'Cash','','','','',NULL,'',0.00),(1343,'2022-08-29 00:00:00','6300','Donation',500.00,'Income','Marseena P K','1109',1,'Cash','','','','',NULL,'',0.00),(1344,'2022-08-01 00:00:00','asper Pay roll','Salary',-10000.00,'Expense','Udayakumar','911',1,'Cash','','','','',NULL,'',0.00),(1345,'2022-08-01 00:00:00','asper Payroll','Salary',-15000.00,'Expense','Rasly,Phisiotherapist','912',1,'Cash','','','','',NULL,'',0.00),(1346,'2022-08-01 00:00:00','as per pay roll','Salary',-11030.00,'Expense','Shimla,Nurse','913',1,'Cash','','','','',NULL,'',0.00),(1347,'2022-08-01 00:00:00','asper payroll','Salary',-4500.00,'Expense','Smitha ,Nurse','914',1,'Cash','','','','',NULL,'',0.00),(1348,'2022-08-01 00:00:00','Draiver','Salary',-12000.00,'Expense','Musthafa, Draiver','915',1,'Cash','','','','',NULL,'',0.00),(1349,'2022-08-01 00:00:00','asper pay roll','Salary',-4000.00,'Expense','Rafi,Draiver','916',1,'Cash','','','','',NULL,'',0.00),(1350,'2022-08-01 00:00:00','asper payroll','Salary',-7500.00,'Expense','Jameela,Phisioassist','917',1,'Cash','','','','',NULL,'',0.00),(1351,'2022-08-01 00:00:00','asperpayroll','Salary',-2500.00,'Expense','Radha,sweeper','918',1,'Cash','','','','',NULL,'',0.00),(1352,'2022-08-01 00:00:00','300','Homecare Refreshment',-260.00,'Expense','Smitha','919',1,'Cash','','','','',NULL,'',0.00),(1353,'2022-08-01 00:00:00','301','Medicines',-450.00,'Expense','Fuad Medicals','920',1,'Cash','','','','',NULL,'',0.00),(1354,'2022-08-02 00:00:00','302','Missallanios Expense',-210.00,'Expense','Care One Surgicals','921',1,'Cash','','','','',NULL,'',0.00),(1355,'2022-08-02 00:00:00','303','Homecare Refreshment',-250.00,'Expense','Smitha','922',1,'Cash','','','','',NULL,'',0.00),(1356,'2022-08-03 00:00:00','304','Medicines',-5251.00,'Expense','Kims Pharma','923',1,'Cash','','','','',NULL,'',0.00),(1357,'2022-08-05 00:00:00','305','Homecare Refreshment',-260.00,'Expense','Smitha','924',1,'Cash','','','','',NULL,'',0.00),(1358,'2022-08-03 00:00:00','306','Printing & Stationary',-36.00,'Expense','Mohamed rafi','925',1,'Cash','','','','',NULL,'',0.00),(1359,'2022-08-03 00:00:00','307','Building Work',-5200.00,'Expense','Sanal','926',1,'Cash','','','','',NULL,'',0.00),(1360,'2022-08-04 00:00:00','308','Printing & Stationary',-65.00,'Expense','Udayakumar','927',1,'Cash','','','','',NULL,'',0.00),(1361,'2022-08-04 00:00:00','309','Homecare Refreshment',-240.00,'Expense','Smitha','928',1,'Cash','','','','',NULL,'',0.00),(1362,'2022-08-04 00:00:00','310 Software modification','Furniture & Fittings',-6000.00,'Expense','Sakeeb M M','929',1,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(1363,'2022-08-04 00:00:00','311','Medicines',-750.00,'Expense','Healing Surgicals','930',1,'Cash','','','','',NULL,'',0.00),(1364,'2022-08-05 00:00:00','312','Ambulance',-500.00,'Expense','Haji Muhammedali sons','931',1,'Cash','','','','',NULL,'',0.00),(1365,'2022-08-05 00:00:00','313','Printing & Stationary',-100.00,'Expense','M I P','932',1,'Cash','','','','',NULL,'',0.00),(1366,'2022-08-05 00:00:00','314','Printing & Stationary',-276.00,'Expense','Udayakumar','933',1,'Cash','','','','',NULL,'',0.00),(1367,'2022-08-05 00:00:00','315 ','Salary',-3000.00,'Expense','Dr, Prasanth, Psychatrist','934',1,'Cash','','','','',NULL,'',0.00),(1368,'2022-08-05 00:00:00','316','Printing & Stationary',-79.00,'Expense','Udayakumar','935',1,'Cash','','','','',NULL,'',0.00),(1369,'2022-08-05 00:00:00','317','Homecare Refreshment',-160.00,'Expense','Smitha','936',1,'Cash','','','','',NULL,'',0.00),(1370,'2022-08-05 00:00:00','318','Building Work',-4800.00,'Expense','Sanal','937',1,'Cash','','','','',NULL,'',0.00),(1371,'2022-08-06 00:00:00','319','Homecare Refreshment',-255.00,'Expense','Smitha','938',1,'Cash','','','','',NULL,'',0.00),(1372,'2022-08-06 00:00:00','320','Telephone Charge',-180.00,'Expense','Smitha','939',1,'Cash','','','','',NULL,'',0.00),(1373,'2022-08-06 00:00:00','321','Printing & Stationary',-390.00,'Expense','Ganapathy Chettiyar Textiles','940',1,'Cash','','','','',NULL,'',0.00),(1374,'2022-08-06 00:00:00','322','Printing & Stationary',-110.00,'Expense','Senior Buisness Centre','941',1,'Cash','','','','',NULL,'',0.00),(1375,'2022-08-07 00:00:00','323','Vehicle Expense',-2000.00,'Expense','KPK Petrolium','942',1,'Cash','','','','',NULL,'',0.00),(1376,'2022-08-07 00:00:00','324','Training Programe',-450.00,'Expense','Shahana Hotel','943',1,'Cash','','','','',NULL,'',0.00),(1377,'2022-08-07 00:00:00','325','Printing & Stationary',-40.00,'Expense','Udayakumar','944',1,'Cash','','','','',NULL,'',0.00),(1378,'2022-08-07 00:00:00','326','Training Programe',-120.00,'Expense','Udayakumar','945',1,'Cash','','','','',NULL,'',0.00),(1379,'2022-08-07 00:00:00','327','Training Programe',-500.00,'Expense','Secratary','946',1,'Cash','','','','',NULL,'',0.00),(1380,'2022-08-07 00:00:00','328','Homecare Refreshment',-270.00,'Expense','Smitha','947',1,'Cash','','','','',NULL,'',0.00),(1381,'2022-08-08 00:00:00','329','Vehicle Expense',-100.00,'Expense','Secratary','948',1,'Cash','','','','',NULL,'',0.00),(1382,'2022-08-08 00:00:00','330','Ambulance',-100.00,'Expense','Mohamed Rafi','949',1,'Cash','','','','',NULL,'',0.00),(1383,'2022-08-08 00:00:00','331','Ambulance',-1450.00,'Expense','KPK Petrolium','950',1,'Cash','','','','',NULL,'',0.00),(1384,'2022-08-08 00:00:00','332','Homecare Refreshment',-270.00,'Expense','Smitha','951',1,'Cash','','','','',NULL,'',0.00),(1385,'2022-08-08 00:00:00','333','Vehicle Expense',-1910.00,'Expense','Powertech','952',1,'Cash','','','','',NULL,'',0.00),(1386,'2022-08-09 00:00:00','334','Homecare Refreshment',-180.00,'Expense','Musthafa','953',1,'Cash','','','','',NULL,'',0.00),(1387,'2022-08-10 00:00:00','335','Homecare Refreshment',-240.00,'Expense','Smitha','954',1,'Cash','','','','',NULL,'',0.00),(1388,'2022-08-11 00:00:00','336','D H C Fees',-2500.00,'Expense','Dr. Aysha','955',1,'Cash','','','','',NULL,'',0.00),(1389,'2022-08-11 00:00:00','337','Homecare Refreshment',-80.00,'Expense','Smitha','956',1,'Cash','','','','',NULL,'',0.00),(1390,'2022-08-11 00:00:00','338','Building Work',-6300.00,'Expense','Mansoor, Painter','957',1,'Cash','','','','',NULL,'',0.00),(1391,'2022-08-12 00:00:00','339','Homecare Refreshment',-250.00,'Expense','Shimla','958',1,'Cash','','','','',NULL,'',0.00),(1392,'2022-08-13 00:00:00','340    Msand','Building Work',-6500.00,'Expense','Suku, Msand','959',1,'Cash','','','','',NULL,'',0.00),(1393,'2022-08-14 00:00:00','341','Building Work',-270.00,'Expense','Smitha','960',1,'Cash','','','','',NULL,'',0.00),(1394,'2022-08-15 00:00:00','342','Homecare Refreshment',-60.00,'Expense','Smitha','961',1,'Cash','','','','',NULL,'',0.00),(1395,'2022-08-15 00:00:00','343, quari west','Building Work',-6300.00,'Expense','Suku','962',1,'Cash','','','','',NULL,'',0.00),(1396,'2022-08-16 00:00:00','344','Homecare Refreshment',-250.00,'Expense','Smitha','963',1,'Cash','','','','',NULL,'',0.00),(1397,'2022-08-16 00:00:00','345','Land & Build Tax',-30.00,'Expense','Village Office','964',1,'Cash','','','','',NULL,'',0.00),(1398,'2022-08-17 00:00:00','346','Homecare Refreshment',-270.00,'Expense','Smitha','965',1,'Cash','','','','',NULL,'',0.00),(1399,'2022-08-17 00:00:00','347','Vehicle Expense',-2000.00,'Expense','KPK Petrolium','966',1,'Cash','','','','',NULL,'',0.00),(1400,'2022-08-18 00:00:00','348','Homecare Refreshment',-190.00,'Expense','Smitha','967',1,'Cash','','','','',NULL,'',0.00),(1401,'2022-08-19 00:00:00','349','Homecare Refreshment',-270.00,'Expense','Smitha','968',1,'Cash','','','','',NULL,'',0.00),(1402,'2022-08-19 00:00:00','350,  Babymettal','Building Work',-6500.00,'Expense','Suku','969',1,'Cash','','','','',NULL,'',0.00),(1403,'2022-08-18 00:00:00','351','Printing & Stationary',-100.00,'Expense','Al-Lal supermarket','970',1,'Cash','','','','',NULL,'',0.00),(1404,'2022-08-19 00:00:00','352','Electricitty Charge',-5923.00,'Expense','K S E B','971',1,'Cash','','','','',NULL,'',0.00),(1405,'2022-08-20 00:00:00','353','Homecare Refreshment',-265.00,'Expense','Shimla','972',1,'Cash','','','','',NULL,'',0.00),(1406,'2022-08-20 00:00:00','354','Missallanios Expense',-120.00,'Expense','Mangalam Times','973',1,'Cash','','','','',NULL,'',0.00),(1407,'2022-08-21 00:00:00','355','Homecare Refreshment',-240.00,'Expense','Smitha','974',1,'Cash','','','','',NULL,'',0.00),(1408,'2022-08-21 00:00:00','356','Medicines',-192.00,'Expense','Kims Pharma','975',1,'Cash','','','','',NULL,'',0.00),(1409,'2022-08-22 00:00:00','357','Ambulance',-800.00,'Expense','A P M Fuels','976',1,'Cash','','','','',NULL,'',0.00),(1410,'2022-08-22 00:00:00','358','Homecare Refreshment',-270.00,'Expense','Smitha','977',1,'Cash','','','','',NULL,'',0.00),(1411,'2022-08-23 00:00:00','359','Telephone Charge',-180.00,'Expense','Musthafa','978',1,'Cash','','','','',NULL,'',0.00),(1412,'2022-08-24 00:00:00','360','Homecare Refreshment',-270.00,'Expense','Smitha','979',1,'Cash','','','','',NULL,'',0.00),(1413,'2022-08-25 00:00:00','361','D H C Fees',-2500.00,'Expense','Dr. Aysha','980',1,'Cash','','','','',NULL,'',0.00),(1414,'2022-08-25 00:00:00','362','Homecare Refreshment',-380.00,'Expense','Smitha','981',1,'Cash','','','','',NULL,'',0.00),(1415,'2022-08-26 00:00:00','363','Medicines',-152.00,'Expense','Supriya Drug&surgicals','982',1,'Cash','','','','',NULL,'',0.00),(1416,'2022-08-27 00:00:00','364','Printing & Stationary',-134.00,'Expense','Udayakumar','983',1,'Cash','','','','',NULL,'',0.00),(1417,'2022-08-27 00:00:00','365','Homecare Refreshment',-260.00,'Expense','Shimla','984',1,'Cash','','','','',NULL,'',0.00),(1418,'2022-08-27 00:00:00','366','Printing & Stationary',-24.00,'Expense','Shimla','985',1,'Cash','','','','',NULL,'',0.00),(1419,'2022-08-27 00:00:00','367','Medicines',-250.00,'Expense','Healing Surgicals','992',1,'Cash','','','','',NULL,'',0.00),(1420,'2022-08-28 00:00:00','368','Homecare Refreshment',-300.00,'Expense','Shimla','987',1,'Cash','','','','',NULL,'',0.00),(1421,'2022-08-29 00:00:00','369','Printing & Stationary',-50.00,'Expense','Udayakumar','988',1,'Cash','','','','',NULL,'',0.00),(1422,'2022-08-29 00:00:00','370','Homecare Refreshment',-200.00,'Expense','Shimla','989',1,'Cash','','','','',NULL,'',0.00),(1423,'2022-08-30 00:00:00','371','Homecare Refreshment',-270.00,'Expense','Smitha','990',1,'Cash','','','','',NULL,'',0.00),(1424,'2022-08-31 00:00:00','371A','Homecare Refreshment',-270.00,'Expense','Smitha','1056',1,'Cash','','','','',NULL,'',0.00),(1425,'2022-08-05 00:00:00','8','Ambulance',750.00,'Income','Ambulance','1110',1,'Cash','','','','',NULL,'',0.00),(1426,'2022-08-09 00:00:00','9','Ambulance',2500.00,'Income','Ambulance','1312',1,'Cash','','','','',NULL,'',0.00),(1427,'2022-08-23 00:00:00','-','-',0.00,'Income','ambulance','1313',1,NULL,'','','','',NULL,'',0.00),(1428,'2022-08-31 00:00:00','372','Ambulance Commision',-465.00,'Expense','Mohamed Rafi','993',1,'Cash','','','','',NULL,'',0.00),(1429,'2022-08-31 00:00:00','-','Bank loan',-12648.00,'Expense','I C I C I Bank','994',1,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(1430,'2022-08-31 00:00:00','-','Rent',377.00,'Income','Mobile Shop','1113',1,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(1431,'2022-08-31 00:00:00','Contra Entry - Cash','Contra Entry',-140000.00,'Expense','',NULL,0,'Cash','','',NULL,NULL,NULL,NULL,0.00),(1432,'2022-08-31 00:00:00','Contra Entry - Bank','Contra Entry',140000.00,'Income','',NULL,0,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801',NULL,NULL,NULL,NULL,0.00),(1433,'2022-08-31 00:00:00','Contra Entry - Cash','Contra Entry',-22500.00,'Expense','',NULL,0,'Cash','','',NULL,NULL,NULL,NULL,0.00),(1434,'2022-08-31 00:00:00','Contra Entry - Bank','Contra Entry',22500.00,'Income','',NULL,0,'Bank','Transfer','Kerala Gramin Bank - 40687111000159',NULL,NULL,NULL,NULL,0.00),(1435,'2022-09-01 00:00:00','6171,Dtd 13/6','Box Collection',96.00,'Income','Abdul gafoor ,Kalitheeta','1114',1,'Cash','','','','',NULL,'',0.00),(1436,'2022-09-01 00:00:00','6172 Dtd 25/7','Box Collection',1010.00,'Income','Khais Medicals','1115',1,'Cash','','','','',NULL,'',0.00),(1437,'2022-09-01 00:00:00','6173 Dtd 25/7','Box Collection',290.00,'Income','Kevees Bakery','1116',1,'Cash','','','','',NULL,'',0.00),(1438,'2022-09-01 00:00:00','6174 Dtd 8/8','Box Collection',770.00,'Income','Sukumaran Shop','1117',1,'Cash','','','','',NULL,'',0.00),(1439,'2022-09-01 00:00:00','6175 Dtd 18/8','Box Collection',2915.00,'Income','M G M Mall','1118',1,'Cash','','','','',NULL,'',0.00),(1440,'2022-09-01 00:00:00','604-612 Dtd 1/8','HOPE',2200.00,'Income','Hope','1119',1,'Cash','','','','',NULL,'',0.00),(1441,'2022-09-01 00:00:00','613-618 Dtd 2/8','HOPE',950.00,'Income','Hope','1120',1,'Cash','','','','',NULL,'',0.00),(1442,'2022-09-03 00:00:00','619-625','HOPE',1000.00,'Income','Hope','1121',1,'Cash','','','','',NULL,'',0.00),(1443,'2022-09-01 00:00:00','626-632','HOPE',1950.00,'Income','Hope','1122',1,'Cash','','','','',NULL,'',0.00),(1444,'2022-09-01 00:00:00','633-639','HOPE',1050.00,'Income','Hope','1123',1,'Cash','','','','',NULL,'',0.00),(1445,'2022-09-01 00:00:00','640-647','HOPE',1450.00,'Income','Hope','1124',1,'Cash','','','','',NULL,'',0.00),(1446,'2022-09-01 00:00:00','648-650 Dtd 8/8','HOPE',450.00,'Income','Hope','1125',1,'Cash','','','','',NULL,'',0.00),(1447,'2022-08-01 00:00:00','7073',' Monthly Subscription',100.00,'Income','Mangalam Mill','1127',1,'Cash','','','','',NULL,'',0.00),(1448,'2022-08-01 00:00:00','7074',' Monthly Subscription',100.00,'Income','Kishor master','1128',1,'Cash','','','','',NULL,'',0.00),(1449,'2022-08-01 00:00:00','7075',' Monthly Subscription',400.00,'Income','PKC Bakery','1129',1,'Cash','','','','',NULL,'',0.00),(1450,'2022-08-01 00:00:00','7076',' Monthly Subscription',100.00,'Income','Shanoos Buty','1130',1,'Cash','','','','',NULL,'',0.00),(1451,'2022-08-01 00:00:00','7077',' Monthly Subscription',100.00,'Income','Siraj Sweets','1131',1,'Cash','','','','',NULL,'',0.00),(1452,'2022-08-01 00:00:00','7076',' Monthly Subscription',100.00,'Income','Kerala Store','1132',1,'Cash','','','','',NULL,'',0.00),(1453,'2022-08-01 00:00:00','7079',' Monthly Subscription',250.00,'Income','Boss Textiles','1133',1,'Cash','','','','',NULL,'',0.00),(1454,'2022-08-01 00:00:00','7080',' Monthly Subscription',100.00,'Income','Shajahan Online','1134',1,'Cash','','','','',NULL,'',0.00),(1455,'2022-08-02 00:00:00','7081',' Monthly Subscription',1000.00,'Income','Kadeeja saleem','1135',1,'Cash','','','','',NULL,'',0.00),(1456,'2022-08-02 00:00:00','7082',' Monthly Subscription',500.00,'Income','Dental Clinic','1136',1,'Cash','','','','',NULL,'',0.00),(1457,'2022-08-02 00:00:00','7083',' Monthly Subscription',100.00,'Income','Care Medicals','1137',1,'Cash','','','','',NULL,'',0.00),(1458,'2022-08-04 00:00:00','7084',' Monthly Subscription',300.00,'Income','Saher Tea shop','1138',1,'Cash','','','','',NULL,'',0.00),(1459,'2022-08-04 00:00:00','7085',' Monthly Subscription',100.00,'Income','Hamsa C','1139',1,'Cash','','','','',NULL,'',0.00),(1460,'2022-08-26 00:00:00','7086','Donation',300.00,'Income','Rasheed V','1140',1,'Cash','','','','',NULL,'',0.00),(1461,'2022-08-29 00:00:00','7087',' Monthly Subscription',200.00,'Income','Chappathy company','1141',1,'Cash','','','','',NULL,'',0.00),(1462,'2022-08-29 00:00:00','7088',' Monthly Subscription',100.00,'Income','Rafi chikken stall','1142',1,'Cash','','','','',NULL,'',0.00),(1463,'2022-08-29 00:00:00','7089',' Monthly Subscription',100.00,'Income','Babu store','1143',1,'Cash','','','','',NULL,'',0.00),(1464,'2022-08-29 00:00:00','7090',' Monthly Subscription',1000.00,'Income','Bake Palace','1144',1,'Cash','','','','',NULL,'',0.00),(1465,'2022-08-29 00:00:00','7091',' Monthly Subscription',100.00,'Income','Chambayil Medicals','1145',1,'Cash','','','','',NULL,'',0.00),(1466,'2022-08-29 00:00:00','7092',' Monthly Subscription',100.00,'Income','Coimbathur Pharmacy','1146',1,'Cash','','','','',NULL,'',0.00),(1467,'2022-08-29 00:00:00','7093',' Monthly Subscription',200.00,'Income','Times Managalam','1147',1,'Cash','','','','',NULL,'',0.00),(1468,'2022-08-29 00:00:00','7094',' Monthly Subscription',100.00,'Income','Citty Medicals','1148',1,'Cash','','','','',NULL,'',0.00),(1469,'2022-08-29 00:00:00','7095',' Monthly Subscription',100.00,'Income','Thanveer mobile','1149',1,'Cash','','','','',NULL,'',0.00),(1470,'2022-08-29 00:00:00','7096',' Monthly Subscription',100.00,'Income','Husain','1150',1,'Cash','','','','',NULL,'',0.00),(1471,'2022-08-29 00:00:00','7097',' Monthly Subscription',150.00,'Income','Kanhikoth Electricals','1151',1,'Cash','','','','',NULL,'',0.00),(1472,'2022-08-29 00:00:00','7098',' Monthly Subscription',200.00,'Income','Rose Textiles','1152',1,'Cash','','','','',NULL,'',0.00),(1473,'2022-08-29 00:00:00','7099',' Monthly Subscription',150.00,'Income','Naser saloon','1153',1,'Cash','','','','',NULL,'',0.00),(1474,'2022-08-29 00:00:00','7100',' Monthly Subscription',500.00,'Income','New mybrother','1154',1,'Cash','','','','',NULL,'',0.00),(1475,'2022-08-31 00:00:00','6371','Rent',377.00,'Income','Siyad','1155',1,'Cash','','','','',NULL,'',0.00),(1476,'2022-08-03 00:00:00','6895','Donation',500.00,'Income','Abdurahman VM marhum','1156',1,'Cash','','','','',NULL,'',0.00),(1477,'2022-08-03 00:00:00','6896',' Monthly Subscription',600.00,'Income','Abid master','1157',1,'Cash','','','','',NULL,'',0.00),(1478,'2022-08-03 00:00:00','6897',' Monthly Subscription',300.00,'Income','Abdulmajeed V M','1158',1,'Cash','','','','',NULL,'',0.00),(1479,'2022-08-04 00:00:00','6898',' Monthly Subscription',500.00,'Income','Kunhimohamed R P','1159',1,'Cash','','','','',NULL,'',0.00),(1480,'2022-08-07 00:00:00','6899',' Monthly Subscription',500.00,'Income','Mohamed Saleem CP','1160',1,'Cash','','','','',NULL,'',0.00),(1481,'2022-08-09 00:00:00','6900','Donation',1000.00,'Income','bdulManaf TP','1161',1,'Cash','','','','',NULL,'',0.00),(1482,'2022-09-01 00:00:00','6372','masjid Collection',1000.00,'Income','Cherupunna Masjid','1162',1,'Cash','','','','',NULL,'',0.00),(1483,'2022-09-01 00:00:00','6373',' Monthly Subscription',600.00,'Income','Abid Master','1163',1,'Cash','','','','',NULL,'',0.00),(1484,'2022-09-01 00:00:00','6374',' Monthly Subscription',300.00,'Income','AbdulMajeed VM','1164',1,'Cash','','','','',NULL,'',0.00),(1485,'2022-09-04 00:00:00','6375',' Monthly Subscription',500.00,'Income','Mohamed Saleem CP','1165',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1486,'2022-09-06 00:00:00','6376','Rent',5000.00,'Income','Siyad','1166',1,'Cash','','','','',NULL,'',0.00),(1487,'2022-09-06 00:00:00','6377','Rent',27978.00,'Income','Alikutty, Hotel','1167',1,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(1488,'2022-09-06 00:00:00','6378','Rent',1850.00,'Income','Alikutty,Hotel','1168',1,'Cash','','','','',NULL,'',0.00),(1489,'2022-09-13 00:00:00','6379','Donation',1000.00,'Income','Mohamedshafi n','1169',1,'Cash','','','','',NULL,'',0.00),(1490,'2022-09-14 00:00:00','6380',' Monthly Subscription',1000.00,'Income','Mohamed rafi KV','1170',1,'Cash','','','','',NULL,'',0.00),(1491,'2022-09-14 00:00:00','6381','Rent',11230.00,'Income','Sunil Lottary','1171',1,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(1492,'2022-09-14 00:00:00','6382','Rent',3800.00,'Income','Sunil Lottary','1172',1,'Cash','','','','',NULL,'',0.00),(1493,'2022-09-16 00:00:00','6383',' Monthly Subscription',500.00,'Income','Kunhimohamed RP','1173',1,'Cash','','','','',NULL,'',0.00),(1494,'2022-09-14 00:00:00','6384','Donation',500.00,'Income','Akshay,Kottakkal','1174',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1495,'2022-09-20 00:00:00','6385','Donation',500.00,'Income','AbdulMajeed VM','1175',1,'Cash','','','','',NULL,'',0.00),(1496,'2022-09-24 00:00:00','6386','Rent',2250.00,'Income','Thankam','1176',1,'Cash','','','','',NULL,'',0.00),(1497,'2022-09-24 00:00:00','6387','Rent',500.00,'Income','Postoffice','1177',1,'Cash','','','','',NULL,'',0.00),(1498,'2022-09-27 00:00:00','6388','Rent',2400.00,'Income','Ajmal Fayis','1178',1,'Cash','','','','',NULL,'',0.00),(1499,'2022-09-06 00:00:00','1682','Donation',1500.00,'Income','Musthafa KV','1179',1,'Cash','','','','',NULL,'',0.00),(1500,'2022-09-09 00:00:00','1683','Donation',3600.00,'Income','Shinab R','1180',1,'Cash','','','','',NULL,'',0.00),(1501,'2022-09-10 00:00:00','1684','Donation',3000.00,'Income','Kassim E','1181',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1502,'2022-09-14 00:00:00','1685','Donation',2000.00,'Income','Mohamed Kabeer M','1182',1,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(1503,'2022-09-15 00:00:00','1686',' Monthly Subscription',10000.00,'Income','Kunhimoossa CP','1183',1,'Cash','','','','',NULL,'',0.00),(1504,'2022-09-15 00:00:00','1687','Donation',0.00,'Income','Zainudheen T','1184',1,'Bank','Cheque','Mangalam Co Operative Bank - 10001001006801','','100245','2022-09-15 00:00:00','C S B ',10000.00),(1505,'2022-09-15 00:00:00','1687','Donation',10000.00,'Income','Zainudheen T','1185',1,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(1506,'2022-09-16 00:00:00','1688','Donation',3000.00,'Income','Shareena K','1186',1,'Cash','','','','',NULL,'',0.00),(1507,'2022-09-19 00:00:00','1689','Donation',10000.00,'Income','Mohamed Musthafa p','1187',1,'Cash','','','','',NULL,'',0.00),(1508,'2022-09-20 00:00:00','1690','Donation',2000.00,'Income','Yasir VM','1188',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1509,'2022-09-21 00:00:00','1691','Donation',10000.00,'Income','Zainudheen Master C P','1189',1,'Cash','','','','',NULL,'',0.00),(1510,'2022-09-21 00:00:00','1692',' Monthly Subscription',2000.00,'Income','Jabbar CT','1190',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1511,'2022-09-21 00:00:00','1693','Donation',5000.00,'Income','Nisthar PV','1191',1,'Cash','','','','',NULL,'',0.00),(1512,'2022-09-21 00:00:00','1694','Donation',5000.00,'Income','Kunhimohamed VP','1192',1,'Cash','','','','',NULL,'',0.00),(1513,'2022-09-21 00:00:00','1695','Donation',5000.00,'Income','Nizamudheen KP','1193',1,'Cash','','','','',NULL,'',0.00),(1514,'2022-09-21 00:00:00','1696','Donation',4000.00,'Income','Alavikutty K P','1194',1,'Cash','','','','',NULL,'',0.00),(1515,'2022-09-21 00:00:00','1697','Donation',3000.00,'Income','Maimoona MP','1195',1,'Cash','','','','',NULL,'',0.00),(1516,'2022-09-21 00:00:00','1698','Donation',3000.00,'Income','Alimon PK','1196',1,'Cash','','','','',NULL,'',0.00),(1517,'2022-09-21 00:00:00','1699','Donation',4000.00,'Income','Noorudhen M','1197',1,'Cash','','','','',NULL,'',0.00),(1518,'2022-09-21 00:00:00','1700','Donation',3000.00,'Income','Asif P','1198',1,'Cash','','','','',NULL,'',0.00),(1519,'2022-09-21 00:00:00','6176','Box Collection',1000.00,'Income','Azees Fish Market','1199',1,'Cash','','','','',NULL,'',0.00),(1520,'2022-09-01 00:00:00','373','Homecare Refreshment',-270.00,'Expense','Smitha','995',1,'Cash','','','','',NULL,'',0.00),(1521,'2022-09-01 00:00:00','374','Vehicle Expense',-2000.00,'Expense','K P K Petrolium','1000',1,NULL,'','','','',NULL,'',0.00),(1522,'2022-09-01 00:00:00','375','Telephone Charge',-180.00,'Expense','Musthafa','1080',1,'Cash','','','','',NULL,'',0.00),(1523,'2022-09-02 00:00:00','376','Printing & Stationary',-94.00,'Expense','Udayakumar','998',1,'Cash','','','','',NULL,'',0.00),(1524,'2022-09-02 00:00:00','377`','Printing & Stationary',-30.00,'Expense','udayakumar','999',1,'Cash','','','','',NULL,'',0.00),(1525,'2022-09-02 00:00:00','378','Ambulance Commission',-975.00,'Expense','Mohamed rafi','1001',1,'Cash','','','','',NULL,'',0.00),(1526,'2022-09-02 00:00:00','379','Homecare Refreshment',-270.00,'Expense','Smitha','1002',1,'Cash','','','','',NULL,'',0.00),(1527,'2022-09-02 00:00:00','380','Printing & Stationary',-534.00,'Expense','Alingal Store','1003',1,'Cash','','','','',NULL,'',0.00),(1528,'2022-09-03 00:00:00','381','Homecare Refreshment',-260.00,'Expense','Shimla','1004',1,'Cash','','','','',NULL,'',0.00),(1529,'2022-09-04 00:00:00','382','Homecare Refreshment',-300.00,'Expense','Smitha','1005',1,'Cash','','','','',NULL,'',0.00),(1530,'2022-09-05 00:00:00','383','Homecare Refreshment',-260.00,'Expense','Smitha','1006',1,'Cash','','','','',NULL,'',0.00),(1531,'2022-09-05 00:00:00','384','Furniture & Fittings',-310000.00,'Expense','Powermech Diesels','1013',1,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(1532,'2022-09-05 00:00:00','385 (onam Allawance)','Salary',-1000.00,'Expense','Smitha','1008',1,'Cash','','','','',NULL,'',0.00),(1533,'2022-09-06 00:00:00','386 (onam Allawance)','Salary',-1000.00,'Expense','Radha sweeper','1009',1,'Cash','','','','',NULL,'',0.00),(1534,'2022-09-06 00:00:00','asper aquitance ','Salary',-10000.00,'Expense','Udayakumar','1010',1,'Cash','','','','',NULL,'',0.00),(1535,'2022-09-06 00:00:00','as per aquitance roll','Salary',-12000.00,'Expense','Musthafa KP','1011',1,'Cash','','','','',NULL,'',0.00),(1536,'2022-09-06 00:00:00','as per aquitance roll','Salary',-10800.00,'Expense','Smitha','1012',1,'Cash','','','','',NULL,'',0.00),(1537,'2022-09-06 00:00:00','as per aquitance roll','Salary',-7500.00,'Expense','Jameel','1014',1,'Cash','','','','',NULL,'',0.00),(1538,'2022-09-06 00:00:00','as per aquitance Roll','Salary',-2725.00,'Expense','Mohamed Rafi','1015',1,'Cash','','','','',NULL,'',0.00),(1539,'2022-09-06 00:00:00','as per aquitance roll','Salary',-2500.00,'Expense','Radha','1016',1,'Cash','','','','',NULL,'',0.00),(1540,'2022-09-06 00:00:00','as per aquitance roll','Salary',-3600.00,'Expense','Shimla','1017',1,'Cash','','','','',NULL,'',0.00),(1541,'2022-09-06 00:00:00','as per aquitance roll','Salary',-13000.00,'Expense','Rasli','1018',1,'Cash','','','','',NULL,'',0.00),(1542,'2022-09-06 00:00:00','387','Printing & Stationary',-120.00,'Expense','Udayakumar','1019',1,'Cash','','','','',NULL,'',0.00),(1543,'2022-09-06 00:00:00','388','Homecare Refreshment',-300.00,'Expense','Smitha','1020',1,'Cash','','','','',NULL,'',0.00),(1544,'2022-09-06 00:00:00','389 Onam allavance','Salary',-1000.00,'Expense','Shilpa','1021',1,'Cash','','','','',NULL,'',0.00),(1545,'2022-09-07 00:00:00','390','Ambulance',-500.00,'Expense','K P K Petrolium','1022',1,'Cash','','','','',NULL,'',0.00),(1546,'2022-09-07 00:00:00','391 Onam allawance','Salary',-1000.00,'Expense','Shimla','1023',1,'Cash','','','','',NULL,'',0.00),(1547,'2022-09-07 00:00:00','392','Homecare Refreshment',-270.00,'Expense','Smitha','1024',1,'Cash','','','','',NULL,'',0.00),(1548,'2022-09-07 00:00:00','393 Onam Allavance','Salary',-1000.00,'Expense','Udayakumar','1025',1,'Cash','','','','',NULL,'',0.00),(1549,'2022-09-10 00:00:00','394','Ambulance',-500.00,'Expense','Alkos Petrolium','1026',1,'Cash','','','','',NULL,'',0.00),(1550,'2022-09-10 00:00:00','395','Homecare Refreshment',-270.00,'Expense','Smitha','1027',1,'Cash','','','','',NULL,'',0.00),(1551,'2022-09-11 00:00:00','396','Homecare Refreshment',-260.00,'Expense','Shameera habeeb','1028',1,'Cash','','','','',NULL,'',0.00),(1552,'2022-09-11 00:00:00','397','Salary',-650.00,'Expense','Shameera Habeeb','1029',1,'Cash','','','','',NULL,'',0.00),(1553,'2022-09-11 00:00:00','398','Printing & Stationary',-30.00,'Expense','Udayakumar','1030',1,'Cash','','','','',NULL,'',0.00),(1554,'2022-09-12 00:00:00','399','Homecare Refreshment',-260.00,'Expense','Smitha','1031',1,'Cash','','','','',NULL,'',0.00),(1555,'2022-09-12 00:00:00','400','Furniture & Fittings',-6000.00,'Expense','Medico Surgicals','1032',1,'Cash','','','','',NULL,'',0.00),(1556,'2022-09-12 00:00:00','401','Printing & Stationary',-300.00,'Expense','Alingal Store','1033',1,'Cash','','','','',NULL,'',0.00),(1557,'2022-09-12 00:00:00','402','Printing & Stationary',-125.00,'Expense','Udayakumar','1034',1,'Cash','','','','',NULL,'',0.00),(1558,'2022-09-13 00:00:00','403','Telephone Charge',-150.00,'Expense','Mohamed Rafi','1035',1,'Cash','','','','',NULL,'',0.00),(1559,'2022-09-13 00:00:00','404','D H C Fees',-2500.00,'Expense','Dr. Pushpavalli','1036',1,'Cash','','','','',NULL,'',0.00),(1560,'2022-09-13 00:00:00','405','Homecare Refreshment',-360.00,'Expense','Smitha','1037',1,'Cash','','','','',NULL,'',0.00),(1561,'2022-09-14 00:00:00','406 genarator unloding charge','Missallanios Expense',-1000.00,'Expense','Sreekumar','1038',1,'Cash','','','','',NULL,'',0.00),(1562,'2022-09-14 00:00:00','407','Homecare Refreshment',-270.00,'Expense','Smitha','1039',1,'Cash','','','','',NULL,'',0.00),(1563,'2022-09-14 00:00:00','408','Vehicle Expense',-2000.00,'Expense','K P K Petrolium','1040',1,'Cash','','','','',NULL,'',0.00),(1564,'2022-09-15 00:00:00','409','Homecare Refreshment',-260.00,'Expense','Smitha','1041',1,'Cash','','','','',NULL,'',0.00),(1565,'2022-08-29 00:00:00','7101',' Monthly Subscription',100.00,'Income','Bismi Store','1200',1,'Cash','','','','',NULL,'',0.00),(1566,'2022-08-29 00:00:00','7102',' Monthly Subscription',100.00,'Income','Indian Bakes','1201',1,'Cash','','','','',NULL,'',0.00),(1567,'2022-08-29 00:00:00','7103',' Monthly Subscription',500.00,'Income','Dheema Jewellary','1219',1,'Cash','','','','',NULL,'',0.00),(1568,'2022-08-29 00:00:00','7104',' Monthly Subscription',100.00,'Income','Kishor master','1203',1,'Cash','','','','',NULL,'',0.00),(1569,'2022-08-29 00:00:00','7105',' Monthly Subscription',250.00,'Income','Aswas Pharmacy','1204',1,'Cash','','','','',NULL,'',0.00),(1570,'2022-08-29 00:00:00','7106',' Monthly Subscription',500.00,'Income','Foot Beet','1205',1,'Cash','','','','',NULL,'',0.00),(1571,'2022-08-29 00:00:00','7107',' Monthly Subscription',100.00,'Income','K K Vegitable','1206',1,'Cash','','','','',NULL,'',0.00),(1572,'2022-08-29 00:00:00','7108',' Monthly Subscription',100.00,'Income','V P Chikken','1207',1,'Cash','','','','',NULL,'',0.00),(1573,'2022-08-29 00:00:00','7109',' Monthly Subscription',200.00,'Income','Techno Point','1208',1,'Cash','','','','',NULL,'',0.00),(1574,'2022-08-29 00:00:00','7110',' Monthly Subscription',100.00,'Income','Shanoos Beuty','1209',1,'Cash','','','','',NULL,'',0.00),(1575,'2022-08-29 00:00:00','7111',' Monthly Subscription',500.00,'Income',' A M Store','1210',1,'Cash','','','','',NULL,'',0.00),(1576,'2022-08-29 00:00:00','7112',' Monthly Subscription',400.00,'Income','P K C Bakery','1211',1,'Cash','','','','',NULL,'',0.00),(1577,'2022-08-29 00:00:00','7113',' Monthly Subscription',100.00,'Income','Mangalam Mill','1212',1,'Cash','','','','',NULL,'',0.00),(1578,'2022-08-29 00:00:00','7114',' Monthly Subscription',1000.00,'Income','Ismail A','1213',1,'Cash','','','','',NULL,'',0.00),(1579,'2022-09-30 00:00:00','3767',' Monthly Subscription',500.00,'Income','Juvairiya','1214',1,'Cash','','','','',NULL,'',0.00),(1580,'2022-09-30 00:00:00','3768',' Monthly Subscription',300.00,'Income','Rajeena C K','1217',1,'Cash','','','','',NULL,'',0.00),(1581,'2022-09-30 00:00:00','3769',' Monthly Subscription',500.00,'Income','Fathima P T','1216',1,'Cash','','','','',NULL,'',0.00),(1582,'2022-12-02 00:00:00','3770',' Monthly Subscription',200.00,'Income','Juvairiya','1218',1,'Cash','','','','',NULL,'',0.00),(1583,'2022-08-29 00:00:00','7115',' Monthly Subscription',100.00,'Income','A one Mobile','1220',1,'Cash','','','','',NULL,'',0.00),(1584,'2022-09-29 00:00:00','7116',' Monthly Subscription',100.00,'Income','Nadiya Fancy','1221',1,'Cash','','','','',NULL,'',0.00),(1585,'2022-08-29 00:00:00','7117',' Monthly Subscription',100.00,'Income','Ration Shop','1222',1,'Cash','','','','',NULL,'',0.00),(1586,'2022-08-29 00:00:00','7118',' Monthly Subscription',100.00,'Income','Abdul Majeed M P','1223',1,'Cash','','','','',NULL,'',0.00),(1587,'2022-08-29 00:00:00','7119',' Monthly Subscription',500.00,'Income','M T C Mangalam','1224',1,'Cash','','','','',NULL,'',0.00),(1588,'2022-08-29 00:00:00','7120',' Monthly Subscription',100.00,'Income','Lillis Bakery','1225',1,'Cash','','','','',NULL,'',0.00),(1589,'2022-08-30 00:00:00','7121',' Monthly Subscription',100.00,'Income','K P K Vegitabl','1226',1,'Cash','','','','',NULL,'',0.00),(1590,'2022-08-30 00:00:00','7122',' Monthly Subscription',250.00,'Income','P K C Bakery','1227',1,'Cash','','','','',NULL,'',0.00),(1591,'2022-08-30 00:00:00','7123',' Monthly Subscription',500.00,'Income','B squire','1228',1,'Cash','','','','',NULL,'',0.00),(1592,'2022-08-30 00:00:00','7124',' Monthly Subscription',500.00,'Income','Mangalam Dental Clinic','1229',1,'Cash','','','','',NULL,'',0.00),(1593,'2022-08-30 00:00:00','7125',' Monthly Subscription',100.00,'Income','Siraj Sweets','1230',1,'Cash','','','','',NULL,'',0.00),(1594,'2022-08-30 00:00:00','7126',' Monthly Subscription',100.00,'Income','ATR Chikken Stall','1231',1,'Cash','','','','',NULL,'',0.00),(1595,'2022-08-30 00:00:00','7127',' Monthly Subscription',300.00,'Income','ALimon Alfa','1232',1,'Cash','','','','',NULL,'',0.00),(1596,'2022-08-30 00:00:00','7128',' Monthly Subscription',250.00,'Income','Crimbis Bakery','1233',1,'Cash','','','','',NULL,'',0.00),(1597,'2022-08-30 00:00:00','7129',' Monthly Subscription',200.00,'Income','Perfect Electricals','1234',1,'Cash','','','','',NULL,'',0.00),(1598,'2022-08-30 00:00:00','7130',' Monthly Subscription',150.00,'Income','Friends Banana Shop','1235',1,'Cash','','','','',NULL,'',0.00),(1599,'2022-08-30 00:00:00','7131',' Monthly Subscription',200.00,'Income','Colors Mangalam','1236',1,'Cash','','','','',NULL,'',0.00),(1600,'2022-08-30 00:00:00','7132',' Monthly Subscription',100.00,'Income','Soubhagya Tyre Work','1237',1,'Cash','','','','',NULL,'',0.00),(1601,'2022-08-30 00:00:00','7133',' Monthly Subscription',100.00,'Income','Shajahan','1238',1,'Cash','','','','',NULL,'',0.00),(1602,'2022-08-30 00:00:00','7134',' Monthly Subscription',100.00,'Income','Citty Draiving School','1239',1,'Cash','','','','',NULL,'',0.00),(1603,'2022-08-30 00:00:00','7135',' Monthly Subscription',500.00,'Income','Corner Vegitable','1240',1,'Cash','','','','',NULL,'',0.00),(1604,'2022-08-30 00:00:00','7136',' Monthly Subscription',100.00,'Income','Rak Pharma','1241',1,'Cash','','','','',NULL,'',0.00),(1605,'2022-08-30 00:00:00','7137',' Monthly Subscription',100.00,'Income','Oushadhi','1242',1,'Cash','','','','',NULL,'',0.00),(1606,'2022-08-30 00:00:00','7138',' Monthly Subscription',200.00,'Income','Munthiri Footware','1243',1,'Cash','','','','',NULL,'',0.00),(1607,'2022-08-30 00:00:00','7139',' Monthly Subscription',250.00,'Income','A K Store','1244',1,'Cash','','','','',NULL,'',0.00),(1608,'2022-08-30 00:00:00','7140',' Monthly Subscription',100.00,'Income','Fresh Cool','1245',1,'Cash','','','','',NULL,'',0.00),(1609,'2022-08-31 00:00:00','7141',' Monthly Subscription',100.00,'Income','Rajan Hotel','1246',1,'Cash','','','','',NULL,'',0.00),(1610,'2022-08-31 00:00:00','7142',' Monthly Subscription',100.00,'Income','Impress mangalam','1247',1,'Cash','','','','',NULL,'',0.00),(1611,'2022-08-31 00:00:00','7143',' Monthly Subscription',100.00,'Income','Akhila','1248',1,'Cash','','','','',NULL,'',0.00),(1612,'2022-08-31 00:00:00','7144',' Monthly Subscription',100.00,'Income','Care Clinic','1249',1,'Cash','','','','',NULL,'',0.00),(1613,'2022-08-31 00:00:00','7145','-',0.00,'Income','Cancelled','1250',1,'Cash','','','','',NULL,'',0.00),(1614,'2022-08-31 00:00:00','7146',' Monthly Subscription',300.00,'Income','Kunhuttimon','1251',1,'Cash','','','','',NULL,'',0.00),(1615,'2022-08-31 00:00:00','7147',' Monthly Subscription',250.00,'Income','BOSS Textiles','1252',1,'Cash','','','','',NULL,'',0.00),(1616,'2022-08-31 00:00:00','7148',' Monthly Subscription',100.00,'Income','Vasu Carpentary','1253',1,'Cash','','','','',NULL,'',0.00),(1617,'2022-09-12 00:00:00','7149','Donation',300.00,'Income','Nishad','1254',1,'Cash','','','','',NULL,'',0.00),(1618,'2022-09-20 00:00:00','7150','Donation',1000.00,'Income','Narayani','1255',1,'Cash','','','','',NULL,'',0.00),(1619,'2022-09-28 00:00:00','7151',' Monthly Subscription',200.00,'Income','Thanima Chapathi Co','1256',1,'Cash','','','','',NULL,'',0.00),(1620,'2022-09-28 00:00:00','7152',' Monthly Subscription',100.00,'Income','Babu Store','1257',1,'Cash','','','','',NULL,'',0.00),(1621,'2022-09-28 00:00:00','7153',' Monthly Subscription',100.00,'Income','Chambayil Medicals','1258',1,'Cash','','','','',NULL,'',0.00),(1622,'2022-09-28 00:00:00','7154',' Monthly Subscription',100.00,'Income','Coimbathur Pharmacy','1259',1,'Cash','','','','',NULL,'',0.00),(1623,'2022-09-28 00:00:00','7155',' Monthly Subscription',100.00,'Income','Indian Bakes','1260',1,'Cash','','','','',NULL,'',0.00),(1624,'2022-09-28 00:00:00','7156',' Monthly Subscription',200.00,'Income','Mangalam Times','1261',1,'Cash','','','','',NULL,'',0.00),(1625,'2022-09-28 00:00:00','7157',' Monthly Subscription',100.00,'Income','Husain','1262',1,'Cash','','','','',NULL,'',0.00),(1626,'2022-09-28 00:00:00','7156',' Monthly Subscription',150.00,'Income','Kanhikoth Eectricals','1263',1,'Cash','','','','',NULL,'',0.00),(1627,'2022-09-28 00:00:00','7159',' Monthly Subscription',200.00,'Income','RoseTextiles','1264',1,'Cash','','','','',NULL,'',0.00),(1628,'2022-09-28 00:00:00','7160',' Monthly Subscription',150.00,'Income','Naser Saloon','1265',1,'Cash','','','','',NULL,'',0.00),(1629,'2022-09-28 00:00:00','7161',' Monthly Subscription',100.00,'Income','Rafi Chikken','1266',1,'Cash','','','','',NULL,'',0.00),(1630,'2022-09-28 00:00:00','7162',' Monthly Subscription',500.00,'Income','New My Brother Hardware','1267',1,'Cash','','','','',NULL,'',0.00),(1631,'2022-09-28 00:00:00','7163',' Monthly Subscription',250.00,'Income','A K Store','1268',1,'Cash','','','','',NULL,'',0.00),(1632,'2022-09-28 00:00:00','7164',' Monthly Subscription',500.00,'Income','DheemaJwellary','1269',1,'Cash','','','','',NULL,'',0.00),(1633,'2022-09-28 00:00:00','7165',' Monthly Subscription',100.00,'Income','Kishore Master','1270',1,'Cash','','','','',NULL,'',0.00),(1634,'2022-09-28 00:00:00','7166',' Monthly Subscription',250.00,'Income','Aswas Pharmacy','1271',1,'Cash','','','','',NULL,'',0.00),(1635,'2022-09-28 00:00:00','7167',' Monthly Subscription',500.00,'Income','Foot Beet','1272',1,'Cash','','','','',NULL,'',0.00),(1636,'2022-09-28 00:00:00','7168',' Monthly Subscription',100.00,'Income','Mangalam Mill','1273',1,'Cash','','','','',NULL,'',0.00),(1637,'2022-09-28 00:00:00','7169',' Monthly Subscription',100.00,'Income','K K Vegitable','1274',1,'Cash','','','','',NULL,'',0.00),(1638,'2022-09-28 00:00:00','7170',' Monthly Subscription',100.00,'Income','V P Chikken','1275',1,'Cash','','','','',NULL,'',0.00),(1639,'2022-09-28 00:00:00','7171',' Monthly Subscription',100.00,'Income','Fresh Cool','1276',1,'Cash','','','','',NULL,'',0.00),(1640,'2022-09-28 00:00:00','7172',' Monthly Subscription',200.00,'Income','Techno Point','1277',1,'Cash','','','','',NULL,'',0.00),(1641,'2022-09-28 00:00:00','7173',' Monthly Subscription',100.00,'Income','Shanoos Beuty','1278',1,'Cash','','','','',NULL,'',0.00),(1642,'2022-09-28 00:00:00','7174',' Monthly Subscription',500.00,'Income','A M Store','1279',1,'Cash','','','','',NULL,'',0.00),(1643,'2022-09-28 00:00:00','7175',' Monthly Subscription',400.00,'Income','P K C Bakery','1280',1,'Cash','','','','',NULL,'',0.00),(1644,'2022-09-28 00:00:00','7176',' Monthly Subscription',100.00,'Income','A One Mobile','1281',1,'Cash','','','','',NULL,'',0.00),(1645,'2022-09-28 00:00:00','7177',' Monthly Subscription',100.00,'Income','Nadiya Fancy','1282',1,'Cash','','','','',NULL,'',0.00),(1646,'2022-09-28 00:00:00','7178',' Monthly Subscription',500.00,'Income','Dental Clinic','1283',1,'Cash','','','','',NULL,'',0.00),(1647,'2022-09-28 00:00:00','7179',' Monthly Subscription',100.00,'Income','Siraj Sweets','1284',1,'Cash','','','','',NULL,'',0.00),(1648,'2022-09-28 00:00:00','7180',' Monthly Subscription',100.00,'Income','Ration Shop','1285',1,'Cash','','','','',NULL,'',0.00),(1649,'2022-09-29 00:00:00','7181',' Monthly Subscription',300.00,'Income','Alimon Alfa','1286',1,'Cash','','','','',NULL,'',0.00),(1650,'2022-09-29 00:00:00','7182',' Monthly Subscription',100.00,'Income','Abdul Majeed MP','1287',1,'Cash','','','','',NULL,'',0.00),(1651,'2022-09-29 00:00:00','7183',' Monthly Subscription',500.00,'Income','B Sqare','1288',1,'Cash','','','','',NULL,'',0.00),(1652,'2022-09-29 00:00:00','7184',' Monthly Subscription',500.00,'Income','M T C Mangalam','1289',1,'Cash','','','','',NULL,'',0.00),(1653,'2022-09-29 00:00:00','7185',' Monthly Subscription',100.00,'Income','Lillis Bakery','1290',1,'Cash','','','','',NULL,'',0.00),(1654,'2022-09-29 00:00:00','7186',' Monthly Subscription',250.00,'Income','P K C Store','1291',1,'Cash','','','','',NULL,'',0.00),(1655,'2022-09-29 00:00:00','7187',' Monthly Subscription',200.00,'Income','Pefect Electricals','1292',1,'Cash','','','','',NULL,'',0.00),(1656,'2022-09-29 00:00:00','7188',' Monthly Subscription',150.00,'Income','Friends Banana Shop','1293',1,'Cash','','','','',NULL,'',0.00),(1657,'2022-09-29 00:00:00','7189',' Monthly Subscription',200.00,'Income','Colors Mangalam','1294',1,'Cash','','','','',NULL,'',0.00),(1658,'2022-09-29 00:00:00','7190',' Monthly Subscription',250.00,'Income','Boss Textiles','1295',1,'Cash','','','','',NULL,'',0.00),(1659,'2022-09-29 00:00:00','7191',' Monthly Subscription',100.00,'Income','Soubhagya Tyre Work','1296',1,'Cash','','','','',NULL,'',0.00),(1660,'2022-09-29 00:00:00','7192',' Monthly Subscription',100.00,'Income','Shajahan On Line','1297',1,'Cash','','','','',NULL,'',0.00),(1661,'2022-09-29 00:00:00','7193',' Monthly Subscription',100.00,'Income','Citty Drag House','1298',1,'Cash','','','','',NULL,'',0.00),(1662,'2022-09-29 00:00:00','7194',' Monthly Subscription',200.00,'Income','Munthiri Footware','1299',1,'Cash','','','','',NULL,'',0.00),(1663,'2022-09-29 00:00:00','7195',' Monthly Subscription',500.00,'Income','Corner Vegitable','1300',1,'Cash','','','','',NULL,'',0.00),(1664,'2022-09-29 00:00:00','7196',' Monthly Subscription',100.00,'Income','Rak Pharma','1301',1,'Cash','','','','',NULL,'',0.00),(1665,'2022-09-29 00:00:00','7197',' Monthly Subscription',100.00,'Income','Oushadhi,Mangalam','1302',1,'Cash','','','','',NULL,'',0.00),(1666,'2022-09-29 00:00:00','7198',' Monthly Subscription',100.00,'Income','Citty Medicals','1303',1,'Cash','','','','',NULL,'',0.00),(1667,'2022-09-29 00:00:00','7199',' Monthly Subscription',100.00,'Income','Thanweer Mobile','1304',1,'Cash','','','','',NULL,'',0.00),(1668,'2022-09-29 00:00:00','7200',' Monthly Subscription',100.00,'Income','K K Vegitable','1305',1,'Cash','','','','',NULL,'',0.00),(1669,'2022-09-30 00:00:00','7201',' Monthly Subscription',1000.00,'Income','Bake Palace','1306',1,'Cash','','','','',NULL,'',0.00),(1670,'2022-09-30 00:00:00','7202',' Monthly Subscription',100.00,'Income','Impress, Mangalam','1307',1,'Cash','','','','',NULL,'',0.00),(1671,'2022-09-30 00:00:00','7203',' Monthly Subscription',100.00,'Income','Care Clinic','1308',1,'Cash','','','','',NULL,'',0.00),(1672,'2022-09-30 00:00:00','7204',' Monthly Subscription',100.00,'Income','Akhila','1309',1,'Cash','','','','',NULL,'',0.00),(1673,'2022-09-30 00:00:00','7205',' Monthly Subscription',100.00,'Income','ATR Chikken','1310',1,'Cash','','','','',NULL,'',0.00),(1674,'2022-09-30 00:00:00','7206',' Monthly Subscription',1000.00,'Income','Ismail A','1311',1,'Cash','','','','',NULL,'',0.00),(1675,'2022-09-15 00:00:00','410','Homecare Refreshment',-180.00,'Expense','Smitha','1042',1,'Cash','','','','',NULL,'',0.00),(1676,'2022-09-16 00:00:00','411','Medicines',-560.00,'Expense','Medico Surgicals','1043',1,'Cash','','','','',NULL,'',0.00),(1677,'2022-09-17 00:00:00','412','Ambulance',-1000.00,'Expense','Alkos Petrolium','1044',1,'Cash','','','','',NULL,'',0.00),(1678,'2022-09-17 00:00:00','413','D H C Fees',-3000.00,'Expense','Dr Prasanth','1045',1,'Cash','','','','',NULL,'',0.00),(1679,'2022-09-17 00:00:00','414(Aug,Sept)','M I P Subscription',-3000.00,'Expense','M I P ','1046',1,'Cash','','','','',NULL,'',0.00),(1680,'2022-09-17 00:00:00','415','Printing & Stationary',-240.00,'Expense','Udayakumar','1047',1,'Cash','','','','',NULL,'',0.00),(1681,'2022-09-17 00:00:00','416','Homecare Refreshment',-200.00,'Expense','Shimla','1048',1,'Cash','','','','',NULL,'',0.00),(1682,'2022-09-17 00:00:00','417','Printing & Stationary',-40.00,'Expense','Udayakumar','1049',1,'Cash','','','','',NULL,'',0.00),(1683,'2022-09-17 00:00:00','418','Homecare Refreshment',-180.00,'Expense','Smitha','1050',1,'Cash','','','','',NULL,'',0.00),(1684,'2022-09-19 00:00:00','419','Homecare Refreshment',-280.00,'Expense','Shimla','1051',1,'Cash','','','','',NULL,'',0.00),(1685,'2022-09-20 00:00:00','420','Printing & Stationary',-147.00,'Expense','420','1052',1,'Cash','','','','',NULL,'',0.00),(1686,'2022-09-20 00:00:00','421','Homecare Refreshment',-255.00,'Expense','Shimla','1057',1,'Cash','','','','',NULL,'',0.00),(1687,'2022-09-21 00:00:00','422','Training Programe',-560.00,'Expense','Udayakumar','1058',1,'Cash','','','','',NULL,'',0.00),(1688,'2022-09-21 00:00:00','423','Training Programe',-1500.00,'Expense','Praveen M G, Trainer','1059',1,'Cash','','','','',NULL,'',0.00),(1689,'2022-09-21 00:00:00','424','Homecare Refreshment',-250.00,'Expense','Shimla','1060',1,'Cash','','','','',NULL,'',0.00),(1690,'2022-09-23 00:00:00','425','Telephone Charge',-180.00,'Expense','Musthafa ','1061',1,'Cash','','','','',NULL,'',0.00),(1691,'2022-09-24 00:00:00','426','Homecare Refreshment',-240.00,'Expense','Smitha','1062',1,'Cash','','','','',NULL,'',0.00),(1692,'2022-09-24 00:00:00','427','Missallanios Expense',-83.00,'Expense','Udayakumar','1063',1,'Cash','','','','',NULL,'',0.00),(1693,'2022-09-24 00:00:00','428','Missallanios Expense',-65.00,'Expense','Udayakumar','1064',1,'Cash','','','','',NULL,'',0.00),(1694,'2022-09-25 00:00:00','429','Homecare Refreshment',-270.00,'Expense','Smitha','1065',1,'Cash','','','','',NULL,'',0.00),(1695,'2022-09-25 00:00:00','430','Missallanios Expense',-155.00,'Expense','K S M Kurumbadi','1066',1,'Cash','','','','',NULL,'',0.00),(1696,'2022-09-26 00:00:00','431','D H C Fees',-2500.00,'Expense','Dr.Pushpavally','1067',1,'Cash','','','','',NULL,'',0.00),(1697,'2022-09-26 00:00:00','432','Homecare Refreshment',-350.00,'Expense','Smitha','1068',1,'Cash','','','','',NULL,'',0.00),(1698,'2022-09-26 00:00:00','433','Printing & Stationary',-140.00,'Expense','Udayakumar','1069',1,'Cash','','','','',NULL,'',0.00),(1699,'2022-09-26 00:00:00','434','Printing & Stationary',-160.00,'Expense','Udayakumar','1070',1,'Cash','','','','',NULL,'',0.00),(1700,'2022-09-27 00:00:00','435','Telephone Charge',-180.00,'Expense','Musthafa','1071',1,'Cash','','','','',NULL,'',0.00),(1701,'2022-09-27 00:00:00','436','Homecare Refreshment',-270.00,'Expense','Smitha','1072',1,'Cash','','','','',NULL,'',0.00),(1702,'2022-09-28 00:00:00','437','Vehicle Expense',-2000.00,'Expense','K P K Petrolium','1073',1,'Cash','','','','',NULL,'',0.00),(1703,'2022-09-28 00:00:00','438','Medicines',-269.00,'Expense','Medico Surgicals','1074',1,'Cash','','','','',NULL,'',0.00),(1704,'2022-09-28 00:00:00','439','Homecare Refreshment',-250.00,'Expense','Smitha','1075',1,'Cash','','','','',NULL,'',0.00),(1705,'2022-09-29 00:00:00','440','Homecare Refreshment',-260.00,'Expense','Smitha','1076',1,'Cash','','','','',NULL,'',0.00),(1706,'2022-09-29 00:00:00','441','Ambulance',-600.00,'Expense','P> Hamsa haji sons','1077',1,'Cash','','','','',NULL,'',0.00),(1707,'2022-09-22 00:00:00','442','Printing & Stationary',-274.00,'Expense','K S M Kurumbadi','1078',1,'Cash','','','','',NULL,'',0.00),(1708,'2022-09-30 00:00:00','443','Vehicle Expense',-12000.00,'Expense','Riyan Tyres','1079',1,'Cash','','','','',NULL,'',0.00),(1709,'2022-09-01 00:00:00','10','Ambulance',700.00,'Income','Beeran','1314',1,'Cash','','','','',NULL,'',0.00),(1710,'2022-09-03 00:00:00','11','Ambulance',500.00,'Income','Beeran','1315',1,'Cash','','','','',NULL,'',0.00),(1711,'2022-09-07 00:00:00','12','Ambulance',500.00,'Income','Ikbal','1316',1,'Cash','','','','',NULL,'',0.00),(1712,'2022-11-10 00:00:00','13','Ambulance',1300.00,'Income','Moideenkutty','1317',1,'Cash','','','','',NULL,'',0.00),(1713,'2022-09-13 00:00:00','14','Ambulance',500.00,'Income','KOMU','1318',1,'Cash','','','','',NULL,'',0.00),(1714,'2022-09-14 00:00:00','15','Ambulance',1300.00,'Income','Moideenkutty','1319',1,'Cash','','','','',NULL,'',0.00),(1715,'2022-09-16 00:00:00','16','Ambulance',500.00,'Income','SAnu','1320',1,'Cash','','','','',NULL,'',0.00),(1716,'2022-09-19 00:00:00','17','Ambulance',500.00,'Income','Fathima','1321',1,'Cash','','','','',NULL,'',0.00),(1717,'2022-09-23 00:00:00','18','Ambulance',600.00,'Income','Hamsa','1322',1,'Cash','','','','',NULL,'',0.00),(1718,'2022-09-29 00:00:00','19','Ambulance',1200.00,'Income','Rasak','1323',1,'Cash','','','','',NULL,'',0.00),(1719,'2022-09-29 00:00:00','20','Ambulance',500.00,'Income','Fathimabeevi','1324',1,'Cash','','','','',NULL,'',0.00),(1720,'2022-09-10 00:00:00','13','Ambulance',1300.00,'Income','Moideenkutty','1325',1,'Cash','','','','',NULL,'',0.00),(1721,'2022-08-01 00:00:00','604-612','HOPE',2200.00,'Income','Hope','1326',1,'Cash','','','','',NULL,'',0.00),(1722,'2022-08-02 00:00:00','613-618','HOPE',950.00,'Income','Hope','1327',1,'Cash','','','','',NULL,'',0.00),(1723,'2022-08-03 00:00:00','619-625','HOPE',1000.00,'Income','Hope','1328',1,'Cash','','','','',NULL,'',0.00),(1724,'2022-08-04 00:00:00','626-632','HOPE',1950.00,'Income','Hope','1329',1,'Cash','','','','',NULL,'',0.00),(1725,'2022-08-05 00:00:00','633-639','HOPE',1050.00,'Income','Hope','1330',1,'Cash','','','','',NULL,'',0.00),(1726,'2022-08-06 00:00:00','640-647','HOPE',1450.00,'Income','Hope','1331',1,'Cash','','','','',NULL,'',0.00),(1727,'2022-08-08 00:00:00','648-656','HOPE',1950.00,'Income','Hope','1332',1,'Cash','','','','',NULL,'',0.00),(1728,'2022-08-09 00:00:00','657-665','HOPE',6100.00,'Income','hope','1333',1,'Cash','','','','',NULL,'',0.00),(1729,'2022-08-10 00:00:00','666-678','HOPE',1250.00,'Income','Hope','1334',1,'Cash','','','','',NULL,'',0.00),(1730,'2022-08-11 00:00:00','674-681','HOPE',1300.00,'Income','Hope','1335',1,'Cash','','','','',NULL,'',0.00),(1731,'2022-08-12 00:00:00','682-691','HOPE',1650.00,'Income','Hope','1336',1,'Cash','','','','',NULL,'',0.00),(1732,'2022-08-13 00:00:00','692-698','HOPE',1200.00,'Income','Hope','1337',1,'Cash','','','','',NULL,'',0.00),(1733,'2022-08-15 00:00:00','699-705','HOPE',1200.00,'Income','Hope','1338',1,'Cash','','','','',NULL,'',0.00),(1734,'2022-08-16 00:00:00','706-714','HOPE',1550.00,'Income','Hope','1339',1,'Cash','','','','',NULL,'',0.00),(1735,'2022-08-17 00:00:00','715-722','HOPE',1400.00,'Income','Hope','1340',1,NULL,'','','','',NULL,'',0.00),(1736,'2022-08-18 00:00:00','723-729','HOPE',2100.00,'Income','Hope','1341',1,'Cash','','','','',NULL,'',0.00),(1737,'2022-08-19 00:00:00','730-736','HOPE',1100.00,'Income','Hope','1342',1,'Cash','','','','',NULL,'',0.00),(1738,'2022-08-20 00:00:00','737-743','HOPE',1150.00,'Income','Hope','1343',1,NULL,'','','','',NULL,'',0.00),(1739,'2022-08-22 00:00:00','744-748','HOPE',850.00,'Income','Hope','1344',1,'Cash','','','','',NULL,'',0.00),(1740,'2022-08-23 00:00:00','749-750','HOPE',400.00,'Income','Hope','1345',1,'Cash','','','','',NULL,'',0.00),(1741,'2022-08-24 00:00:00','751-757','HOPE',1200.00,'Income','Hope','1346',1,'Cash','','','','',NULL,'',0.00),(1742,'2022-08-25 00:00:00','758-762','HOPE',1000.00,'Income','Hope','1347',1,'Cash','','','','',NULL,'',0.00),(1743,'2022-08-26 00:00:00','763-772','HOPE',1850.00,'Income','Hope','1348',1,'Cash','','','','',NULL,'',0.00),(1744,'2022-08-27 00:00:00','773-779','HOPE',1400.00,'Income','Hope','1349',1,'Cash','','','','',NULL,'',0.00),(1745,'2022-08-29 00:00:00','780-785','HOPE',1000.00,'Income','Hope','1350',1,'Cash','','','','',NULL,'',0.00),(1746,'2022-08-30 00:00:00','786-792','HOPE',1200.00,'Income','Hope','1351',1,'Cash','','','','',NULL,'',0.00),(1747,'2022-08-31 00:00:00','793-801','HOPE',3300.00,'Income','Hope','1352',1,'Cash','','','','',NULL,'',0.00),(1748,'2022-09-01 00:00:00','802-808','HOPE',1400.00,'Income','Hope','1353',1,'Cash','','','','',NULL,'',0.00),(1749,'2022-09-02 00:00:00','309-316','HOPE',1400.00,'Income','Hope','1354',1,'Cash','','','','',NULL,'',0.00),(1750,'2022-09-02 00:00:00','809-816','HOPE',1400.00,'Income','Hope','1355',1,NULL,'','','','',NULL,'',0.00),(1751,'2022-09-03 00:00:00','817-824','HOPE',1500.00,'Income','Hope','1356',1,'Cash','','','','',NULL,'',0.00),(1752,'2022-09-05 00:00:00','825-832','HOPE',1500.00,'Income','Hope','1357',1,'Cash','','','','',NULL,'',0.00),(1753,'2022-09-06 00:00:00','833-844','HOPE',2200.00,'Income','Hope','1358',1,'Cash','','','','',NULL,'',0.00),(1754,'2022-09-07 00:00:00','845-853','HOPE',1700.00,'Income','Hope','1359',1,'Cash','','','','',NULL,'',0.00),(1755,'2022-09-09 00:00:00','854-858','HOPE',900.00,'Income','hope','1360',1,'Cash','','','','',NULL,'',0.00),(1756,'2022-09-10 00:00:00','859-868','HOPE',1900.00,'Income','Hope','1361',1,'Cash','','','','',NULL,'',0.00),(1757,'2022-09-12 00:00:00','869-878','HOPE',1800.00,'Income','Hope','1362',1,'Cash','','','','',NULL,'',0.00),(1758,'2022-09-13 00:00:00','879-885','HOPE',1300.00,'Income','Hope','1363',1,'Cash','','','','',NULL,'',0.00),(1759,'2022-09-14 00:00:00','886-891','HOPE',1100.00,'Income','Hope','1364',1,'Cash','','','','',NULL,'',0.00),(1760,'2022-09-15 00:00:00','892-899','HOPE',1500.00,'Income','Hope','1365',1,'Cash','','','','',NULL,'',0.00),(1761,'2022-09-16 00:00:00','900-905','HOPE',1100.00,'Income','Hope','1366',1,'Cash','','','','',NULL,'',0.00),(1762,'2022-09-19 00:00:00','906-910','HOPE',800.00,'Income','Hope','1367',1,'Cash','','','','',NULL,'',0.00),(1763,'2022-09-20 00:00:00','911-915','HOPE',900.00,'Income','Hope','1368',1,'Cash','','','','',NULL,'',0.00),(1764,'2022-09-21 00:00:00','916-920','HOPE',900.00,'Income','Hope','1369',1,'Cash','','','','',NULL,'',0.00),(1765,'2022-09-22 00:00:00','921-923','HOPE',500.00,'Income','Hope','1370',1,'Cash','','','','',NULL,'',0.00),(1766,'2022-09-24 00:00:00','924-930','HOPE',1300.00,'Income','Hope','1371',1,'Cash','','','','',NULL,'',0.00),(1767,'2022-09-26 00:00:00','931-934','HOPE',700.00,'Income','Hope','1372',1,'Cash','','','','',NULL,'',0.00),(1768,'2022-09-27 00:00:00','935-939','HOPE',900.00,'Income','Hope','1373',1,'Cash','','','','',NULL,'',0.00),(1769,'2022-09-28 00:00:00','940-946','HOPE',1500.00,'Income','Hope','1374',1,'Cash','','','','',NULL,'',0.00),(1770,'2022-09-29 00:00:00','948-951','HOPE',800.00,'Income','Hope','1375',1,'Cash','','','','',NULL,'',0.00),(1771,'2022-09-30 00:00:00','951-959','HOPE',1500.00,'Income','hope','1376',1,'Cash','','','','',NULL,'',0.00),(1772,'2022-09-30 00:00:00','444','Building Work',-20708.00,'Expense','N C Traders','1081',1,'Cash','','','','',NULL,'',0.00),(1773,'2022-09-30 00:00:00','-','Bank Interest',29106.00,'Income','Mangalam Scb','1377',1,'Bank','','Mangalam Co Operative Bank - 10001001006801','','',NULL,'',0.00),(1774,'2022-09-30 00:00:00','Contra Entry - Cash','Contra Entry',-85932.00,'Expense','',NULL,0,'Cash','','',NULL,NULL,NULL,NULL,0.00),(1775,'2022-09-30 00:00:00','Contra Entry - Bank','Contra Entry',85932.00,'Income','',NULL,0,'Bank','Transfer','Mangalam Co Operative Bank - 10001001006801',NULL,NULL,NULL,NULL,0.00),(1776,'2022-10-01 00:00:00','960-965','HOPE',1100.00,'Income','Hope','1378',1,'Cash','','','','',NULL,'',0.00),(1777,'2022-10-03 00:00:00','966-975','HOPE',1900.00,'Income','Hope','1379',1,'Cash','','','','',NULL,'',0.00),(1778,'2022-10-04 00:00:00','976-980','HOPE',1000.00,'Income','Hope','1380',1,'Cash','','','','',NULL,'',0.00),(1779,'2022-10-05 00:00:00','981-984','HOPE',700.00,'Income','Hope','1381',1,'Cash','','','','',NULL,'',0.00),(1780,'2022-10-06 00:00:00','985-987','HOPE',600.00,'Income','Hope','1382',1,'Cash','','','','',NULL,'',0.00),(1781,'2022-10-07 00:00:00','988-991','HOPE',600.00,'Income','Hope','1383',1,'Cash','','','','',NULL,'',0.00),(1782,'2022-10-08 00:00:00','992-994','HOPE',600.00,'Income','Hope','1384',1,'Cash','','','','',NULL,'',0.00),(1783,'2022-10-10 00:00:00','995-1000','HOPE',1100.00,'Income','Hope','1385',1,'Cash','','','','',NULL,'',0.00),(1784,'2022-10-11 00:00:00','1001-1002','HOPE',400.00,'Income','Hope','1386',1,'Cash','','','','',NULL,'',0.00),(1785,'2022-10-12 00:00:00','1003-1011','HOPE',1550.00,'Income','Hope','1387',1,'Cash','','','','',NULL,'',0.00),(1786,'2022-10-13 00:00:00','1012-1018','HOPE',1400.00,'Income','Hope','1388',1,'Cash','','','','',NULL,'',0.00),(1787,'2022-10-14 00:00:00','1019-1026','HOPE',1500.00,'Income','Hope','1389',1,'Cash','','','','',NULL,'',0.00),(1788,'2022-10-15 00:00:00','1027-1031','HOPE',1000.00,'Income','Hope','1390',1,'Cash','','','','',NULL,'',0.00),(1789,'2022-10-17 00:00:00','1032-1041','HOPE',1900.00,'Income','Hope','1391',1,'Cash','','','','',NULL,'',0.00),(1790,'2022-10-18 00:00:00','1042-1051','HOPE',1900.00,'Income','Hope','1392',1,'Cash','','','','',NULL,'',0.00),(1791,'2022-10-01 00:00:00','7207','Donation',3800.00,'Income','Fathima beevi K p','1393',1,'Cash','','','','',NULL,'',0.00),(1792,'2022-10-13 00:00:00','7208','Freezer& O2 Rent',2000.00,'Income','Abdul Rasak','1394',1,'Cash','','','','',NULL,'',0.00),(1793,'2022-10-13 00:00:00','7209','Freezer& O2 Rent',2000.00,'Income','Aminakutty','1395',1,'Cash','','','','',NULL,'',0.00),(1794,'2022-10-14 00:00:00','7210','Freezer& O2 Rent',2000.00,'Income','Kalyani. K V','1396',1,'Cash','','','','',NULL,'',0.00),(1795,'2022-10-14 00:00:00','7211','Freezer& O2 Rent',2000.00,'Income','BAVA c v','1397',1,'Cash','','','','',NULL,'',0.00),(1796,'2022-10-15 00:00:00','7212','Freezer& O2 Rent',4000.00,'Income','Shafeek P','1398',1,'Cash','','','','',NULL,'',0.00),(1797,'2022-10-17 00:00:00','7213','Donation',2000.00,'Income','Manikandan K','1399',1,'Cash','','','','',NULL,'',0.00),(1798,'2022-10-19 00:00:00','7214','Freezer& O2 Rent',340.00,'Income','Rasak M K','1400',1,'Cash','','','','',NULL,'',0.00),(1799,'2022-10-28 00:00:00','7215',' Monthly Subscription',200.00,'Income','Thanima Chappathi Co','1401',1,'Cash','','','','',NULL,'',0.00),(1800,'2022-10-28 00:00:00','7216',' Monthly Subscription',100.00,'Income','Noufal','1402',1,'Cash','','','','',NULL,'',0.00),(1801,'2022-10-28 00:00:00','7217',' Monthly Subscription',100.00,'Income','Babu Store','1403',1,'Cash','','','','',NULL,'',0.00),(1802,'2022-10-28 00:00:00','7218',' Monthly Subscription',100.00,'Income','Chambayil Medicals','1404',1,'Cash','','','','',NULL,'',0.00),(1803,'2022-10-28 00:00:00','7219',' Monthly Subscription',100.00,'Income','Coimbathur Farmacy','1405',1,'Cash','','','','',NULL,'',0.00),(1804,'2022-10-28 00:00:00','7220',' Monthly Subscription',100.00,'Income','Indian Bakes','1406',1,'Cash','','','','',NULL,'',0.00),(1805,'2022-10-28 00:00:00','7221',' Monthly Subscription',200.00,'Income','Mangalam Times','1407',1,'Cash','','','','',NULL,'',0.00),(1806,'2022-10-28 00:00:00','7222',' Monthly Subscription',100.00,'Income','Citty Medicals','1408',1,'Cash','','','','',NULL,'',0.00),(1807,'2022-10-28 00:00:00','7223',' Monthly Subscription',100.00,'Income','Husain','1409',1,'Cash','','','','',NULL,'',0.00),(1808,'2022-10-28 00:00:00','7224',' Monthly Subscription',150.00,'Income','Kanhikoth Electricals','1410',1,'Cash','','','','',NULL,'',0.00),(1809,'2022-10-28 00:00:00','7225',' Monthly Subscription',200.00,'Income','Rose Textiles','1411',1,'Cash','','','','',NULL,'',0.00),(1810,'2022-10-28 00:00:00','7226',' Monthly Subscription',150.00,'Income','Naser Saloon','1412',1,'Cash','','','','',NULL,'',0.00),(1811,'2022-10-28 00:00:00','7227',' Monthly Subscription',500.00,'Income','New My Brother Hardware','1413',1,'Cash','','','','',NULL,'',0.00),(1812,'2022-10-29 00:00:00','7228',' Monthly Subscription',500.00,'Income','Dheema Jwellary','1414',1,'Cash','','','','',NULL,'',0.00),(1813,'2022-10-29 00:00:00','7229',' Monthly Subscription',100.00,'Income','Kishor Master','1415',1,'Cash','','','','',NULL,'',0.00),(1814,'2022-10-29 00:00:00','7230',' Monthly Subscription',100.00,'Income','Impress ','1416',1,'Cash','','','','',NULL,'',0.00),(1815,'2022-10-29 00:00:00','7231',' Monthly Subscription',250.00,'Income','Aswas Pharmacy','1417',1,'Cash','','','','',NULL,'',0.00),(1816,'2022-10-29 00:00:00','7232',' Monthly Subscription',500.00,'Income','Foot Beet','1418',1,'Cash','','','','',NULL,'',0.00),(1817,'2022-10-29 00:00:00','7233',' Monthly Subscription',100.00,'Income','Mangalam Mill','1419',1,'Cash','','','','',NULL,'',0.00),(1818,'2022-10-29 00:00:00','7234',' Monthly Subscription',100.00,'Income','Fresh Cool','1420',1,'Cash','','','','',NULL,'',0.00),(1819,'2022-10-29 00:00:00','7235',' Monthly Subscription',100.00,'Income','K K Vegitable','1421',1,'Cash','','','','',NULL,'',0.00),(1820,'2022-10-29 00:00:00','7236',' Monthly Subscription',100.00,'Income','V P Chikken','1422',1,'Cash','','','','',NULL,'',0.00),(1821,'2022-10-29 00:00:00','7237',' Monthly Subscription',600.00,'Income','Tea Shop Saheer','1423',1,'Cash','','','','',NULL,'',0.00),(1822,'2022-10-29 00:00:00','7239',' Monthly Subscription',200.00,'Income','Techno Point','1424',1,'Cash','','','','',NULL,'',0.00),(1823,'2022-10-29 00:00:00','7240',' Monthly Subscription',100.00,'Income','Shanoos Buty','1425',1,'Cash','','','','',NULL,'',0.00),(1824,'2022-10-29 00:00:00','7241',' Monthly Subscription',500.00,'Income','A M Store','1426',1,'Cash','','','','',NULL,'',0.00),(1825,'2022-10-29 00:00:00','7242',' Monthly Subscription',400.00,'Income','P K C Bakery','1427',1,'Cash','','','','',NULL,'',0.00),(1826,'2022-10-29 00:00:00','7243',' Monthly Subscription',1000.00,'Income','Ismail A','1428',1,'Cash','','','','',NULL,'',0.00),(1827,'2022-10-29 00:00:00','7244',' Monthly Subscription',100.00,'Income','I One Mobile','1429',1,'Cash','','','','',NULL,'',0.00),(1828,'2022-10-29 00:00:00','7245',' Monthly Subscription',100.00,'Income','Nadiya Fancy','1430',1,'Cash','','','','',NULL,'',0.00),(1829,'2022-10-29 00:00:00','7246',' Monthly Subscription',100.00,'Income','Siraj Sweets','1431',1,'Cash','','','','',NULL,'',0.00),(1830,'2022-10-29 00:00:00','7247',' Monthly Subscription',300.00,'Income','Kunhuttimon','1432',1,'Cash','','','','',NULL,'',0.00),(1831,'2022-10-29 00:00:00','7248',' Monthly Subscription',100.00,'Income','ATR Chikken','1433',1,'Cash','','','','',NULL,'',0.00),(1832,'2022-10-29 00:00:00','7249',' Monthly Subscription',500.00,'Income','B Square','1434',1,'Cash','','','','',NULL,'',0.00),(1833,'2022-10-29 00:00:00','7250',' Monthly Subscription',500.00,'Income','M T C mangalam','1435',1,'Cash','','','','',NULL,'',0.00),(1834,'2022-10-03 00:00:00','6389','Donation',500.00,'Income','Marhoom Abdurahman master V M','1436',1,'Cash','','','','',NULL,'',0.00),(1835,'2022-10-03 00:00:00','6390',' Monthly Subscription',500.00,'Income','Saleem CP','1437',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1836,'2022-10-05 00:00:00','6391',' Monthly Subscription',1200.00,'Income','Abdurahman V M','1438',1,'Cash','','','','',NULL,'',0.00),(1837,'2022-10-05 00:00:00','6392',' Monthly Subscription',500.00,'Income','Rabiya V M','1439',1,'Cash','','','','',NULL,'',0.00),(1838,'2022-10-05 00:00:00','6393',' Monthly Subscription',600.00,'Income','Abid Master','1440',1,'Cash','','','','',NULL,'',0.00),(1839,'2022-10-11 00:00:00','6394','Donation',1000.00,'Income','Jesmi V M','1441',1,'Cash','','','','',NULL,'',0.00),(1840,'2022-10-12 00:00:00','6395','Rent',2250.00,'Income','Thilakam','1442',1,'Cash','','','','',NULL,'',0.00),(1841,'2022-10-13 00:00:00','6396','Donation',500.00,'Income','Mohamed Rafi KV','1443',1,'Cash','','','','',NULL,'',0.00),(1842,'2022-10-13 00:00:00','6397','Rent',3000.00,'Income','Saleem K A','1444',1,'Cash','','','','',NULL,'',0.00),(1843,'2022-10-18 00:00:00','6398',' Monthly Subscription',1000.00,'Income','Kunhibava K V','1445',1,'Cash','','','','',NULL,'',0.00),(1844,'2022-10-18 00:00:00','6399',' Monthly Subscription',2000.00,'Income','Abdul Majed K V','1446',1,'Cash','','','','',NULL,'',0.00),(1845,'2022-10-18 00:00:00','6400',' Monthly Subscription',2000.00,'Income','Jaseem Abdulm Majeed K V','1447',1,'Cash','','','','',NULL,'',0.00),(1846,'2022-10-18 00:00:00','6471','Donation',500.00,'Income','Abdul Majeed K V','1448',1,'Cash','','','','',NULL,'',0.00),(1847,'2022-10-18 00:00:00','6472','Donation',500.00,'Income','Nilayoram Producers Co','1449',1,'Cash','','','','',NULL,'',0.00),(1848,'2022-10-06 00:00:00','1883','Donation',2500.00,'Income','Nisar V P','1450',1,'Cash','','','','',NULL,'',0.00),(1849,'2022-10-17 00:00:00','1884',' Monthly Subscription',2000.00,'Income','Jabbar C T','1451',1,'Cash','','','','',NULL,'',0.00),(1850,'2022-10-19 00:00:00','1885',' Monthly Subscription',10000.00,'Income','Kunhimoosa C P','1452',1,'Cash','','','','',NULL,'',0.00),(1851,'2022-10-19 00:00:00','1886','Donation',5000.00,'Income','Fathima t','1453',1,'Cash','','','','',NULL,'',0.00),(1852,'2022-10-19 00:00:00','1887','Donation',25000.00,'Income','Jaffer T K','1454',1,'Cash','','','','',NULL,'',0.00),(1853,'2022-10-21 00:00:00','1888','Donation',3000.00,'Income','Kassim E','1455',1,'Bank','','Kerala Gramin Bank - 40687111000159','','',NULL,'',0.00),(1854,'2022-10-23 00:00:00','1889','Donation',25000.00,'Income','Jafer T K','1456',1,'Cash','','','','',NULL,'',0.00),(1855,'2022-10-23 00:00:00','1890',' Monthly Subscription',4000.00,'Income','Saidalavi K P','1457',1,'Cash','','','','',NULL,'',0.00),(1856,'2022-10-29 00:00:00','7251',' Monthly Subscription',100.00,'Income','Lillis Bakery','1458',1,'Cash','','','','',NULL,'',0.00),(1857,'2022-10-29 00:00:00','7252',' Monthly Subscription',100.00,'Income','K P K Vegitable','1459',1,'Cash','','','','',NULL,'',0.00),(1858,'2022-10-29 00:00:00','7253',' Monthly Subscription',250.00,'Income','PKC Store','1460',1,'Cash','','','','',NULL,'',0.00),(1859,'2022-10-29 00:00:00','7254',' Monthly Subscription',250.00,'Income','Krimbis Bakery','1461',1,'Cash','','','','',NULL,'',0.00),(1860,'2022-10-29 00:00:00','7255',' Monthly Subscription',100.00,'Income','Kerala Store','1462',1,'Cash','','','','',NULL,'',0.00),(1861,'2022-10-29 00:00:00','7256',' Monthly Subscription',200.00,'Income','Perfect Electricals','1463',1,'Cash','','','','',NULL,'',0.00),(1862,'2022-10-29 00:00:00','7257',' Monthly Subscription',150.00,'Income','Friends Banana','1464',1,'Cash','','','','',NULL,'',0.00),(1863,'2022-10-29 00:00:00','7258',' Monthly Subscription',200.00,'Income','Colors, Mangalam','1465',1,'Cash','','','','',NULL,'',0.00),(1864,'2022-10-29 00:00:00','7259',' Monthly Subscription',250.00,'Income','Boss Textiles','1466',1,'Cash','','','','',NULL,'',0.00),(1865,'2022-10-29 00:00:00','7260',' Monthly Subscription',100.00,'Income','Soubhagya Tyre','1467',1,'Cash','','','','',NULL,'',0.00),(1866,'2022-10-29 00:00:00','7261',' Monthly Subscription',100.00,'Income','Citty Draiwing Schol','1468',1,'Cash','','','','',NULL,'',0.00),(1867,'2022-10-29 00:00:00','7262',' Monthly Subscription',500.00,'Income','Corner Vegitable','1469',1,'Cash','','','','',NULL,'',0.00),(1868,'2022-10-29 00:00:00','7263',' Monthly Subscription',100.00,'Income','Rak Pharma','1470',1,'Cash','','','','',NULL,'',0.00),(1869,'2022-10-29 00:00:00','7264',' Monthly Subscription',100.00,'Income','Oushadhy','1471',1,'Cash','','','','',NULL,'',0.00),(1870,'2022-10-29 00:00:00','7265',' Monthly Subscription',100.00,'Income','Bismi Store','1472',1,'Cash','','','','',NULL,'',0.00),(1871,'2022-10-31 00:00:00','7266','Freezer& O2 Rent',2000.00,'Income','Nizar T P','1473',1,'Cash','','','','',NULL,'',0.00),(1872,'2022-10-31 00:00:00','7267',' Monthly Subscription',200.00,'Income','Munthiri Foot Ware','1474',1,'Cash','','','','',NULL,'',0.00),(1873,'2022-10-31 00:00:00','7268',' Monthly Subscription',100.00,'Income','Akhila ','1475',1,'Cash','','','','',NULL,'',0.00),(1874,'2022-10-31 00:00:00','7269',' Monthly Subscription',100.00,'Income','Care Clinic','1476',1,'Cash','','','','',NULL,'',0.00),(1875,'2022-10-31 00:00:00','7270',' Monthly Subscription',500.00,'Income','Dental Clinic','1477',1,'Cash','','','','',NULL,'',0.00),(1876,'2022-10-31 00:00:00','7271',' Monthly Subscription',300.00,'Income','Alfa Traders','1478',1,'Cash','','','','',NULL,'',0.00),(1877,'2022-10-31 00:00:00','7272',' Monthly Subscription',100.00,'Income','Abdul Majeed M P','1479',1,'Cash','','','','',NULL,'',0.00),(1878,'2022-10-31 00:00:00','7273',' Monthly Subscription',100.00,'Income','Rafi Chikken','1480',1,'Cash','','','','',NULL,'',0.00),(1879,'2022-10-31 00:00:00','7274',' Monthly Subscription',250.00,'Income','A K Store','1481',1,'Cash','','','','',NULL,'',0.00),(1880,'2022-10-31 00:00:00','7275',' Monthly Subscription',100.00,'Income','Ration Shop','1482',1,'Cash','','','','',NULL,'',0.00),(1881,'2022-10-31 00:00:00','7276',' Monthly Subscription',100.00,'Income','Shajahan On Line','1483',1,'Cash','','','','',NULL,'',0.00),(1882,'2022-10-01 00:00:00','445','Vehicle Expense',-2000.00,'Expense','KPK Petrolium','1082',1,'Cash','','','','',NULL,'',0.00),(1883,'2022-10-01 00:00:00','446','Furniture & Fittings',-6000.00,'Expense','Medico Surgicals','1083',1,'Cash','','','','',NULL,'',0.00),(1884,'2022-10-01 00:00:00','447','Medicines',-560.00,'Expense','Medico Surgicals','1084',1,'Cash','','','','',NULL,'',0.00),(1885,'2022-10-01 00:00:00','448','Medicines',-3740.00,'Expense','Bismik Medical Agencies','1085',1,'Cash','','','','',NULL,'',0.00),(1886,'2022-10-01 00:00:00','449','Medicines',-3259.00,'Expense','Kims Pharma','1086',1,'Cash','','','','',NULL,'',0.00),(1887,'2022-10-01 00:00:00','450','Printing & Stationary',-30.00,'Expense','Udayakumar','1087',1,'Cash','','','','',NULL,'',0.00),(1888,'2022-10-01 00:00:00','451','Homecare Refreshment',-210.00,'Expense','Smitha','1088',1,'Cash','','','','',NULL,'',0.00),(1889,'2022-10-02 00:00:00','452','Homecare Refreshment',-70.00,'Expense','Smitha','1089',1,'Cash','','','','',NULL,'',0.00),(1890,'2022-10-03 00:00:00','453','Homecare Refreshment',-170.00,'Expense','Smitha','1090',1,'Cash','','','','',NULL,'',0.00),(1891,'2022-10-03 00:00:00','454','Printing & Stationary',-2500.00,'Expense','Colors Studio','1091',1,'Cash','','','','',NULL,'',0.00),(1892,'2022-10-03 00:00:00','455','Printing & Stationary',-300.00,'Expense','KOPM Agencies','1092',1,'Cash','','','','',NULL,'',0.00),(1893,'2022-10-03 00:00:00','456','Medicines',-210.00,'Expense','Healing Surgicals','1093',1,'Cash','','','','',NULL,'',0.00),(1894,'2022-10-03 00:00:00','457','Medicines',-5605.00,'Expense','Perumbavoor Surgicals','1094',1,'Cash','','','','',NULL,'',0.00),(1895,'2022-10-04 00:00:00','458','Medicines',-350.00,'Expense','Healing Surgicals','1095',1,'Cash','','','','',NULL,'',0.00),(1896,'2022-10-04 00:00:00','459','Printing & Stationary',-20.00,'Expense','Udayakumar','1096',1,'Cash','','','','',NULL,'',0.00),(1897,'2022-10-04 00:00:00','460','Homecare Refreshment',-220.00,'Expense','Smitha','1097',1,'Cash','','','','',NULL,'',0.00),(1898,'2022-10-05 00:00:00','461','Homecare Refreshment',-300.00,'Expense','Smitha','1098',1,'Cash','','','','',NULL,'',0.00),(1899,'2022-10-05 00:00:00','462','Ambulance Commission',-2430.00,'Expense','Mohamed Rafi','1099',1,'Cash','','','','',NULL,'',0.00),(1900,'2022-10-05 00:00:00','463','Printing & Stationary',-149.00,'Expense','M G M Hyper Market','1100',1,'Cash','','','','',NULL,'',0.00),(1901,'2022-10-06 00:00:00','464','Ambulance',-200.00,'Expense','National Electricals','1101',1,'Cash','','','','',NULL,'',0.00),(1902,'2022-10-06 00:00:00','465','Homecare Refreshment',-250.00,'Expense','Smitha','1102',1,'Cash','','','','',NULL,'',0.00),(1903,'2022-10-07 00:00:00','466','Homecare Refreshment',-60.00,'Expense','Smitha','1103',1,'Cash','','','','',NULL,'',0.00),(1904,'2022-10-07 00:00:00','467','Ambulance',-800.00,'Expense','Palazhi Petrolium','1104',1,'Cash','','','','',NULL,'',0.00),(1905,'2022-10-08 00:00:00','468','Printing & Stationary',-30.00,'Expense','Udayakumar','1105',1,'Cash','','','','',NULL,'',0.00),(1906,'2022-10-10 00:00:00','-','Salary',-10000.00,'Expense','Udayakumar','1106',1,'Cash','','','','',NULL,'',0.00),(1907,'2022-10-08 00:00:00','Draiver','Salary',-12000.00,'Expense','Musthafa K P','1107',1,'Cash','','','','',NULL,'',0.00),(1908,'2022-10-08 00:00:00','Physio Asst','Salary',-7500.00,'Expense','Jameela','1108',1,'Cash','','','','',NULL,'',0.00),(1909,'2022-10-08 00:00:00','Nurse','Salary',-10500.00,'Expense','Smitha','1109',1,'Cash','','','','',NULL,'',0.00),(1910,'2022-10-08 00:00:00','Draiver','Salary',-900.00,'Expense','Mohamed Rafi','1110',1,'Cash','','','','',NULL,'',0.00),(1911,'2022-10-08 00:00:00','Sweeper','Salary',-2500.00,'Expense','Radha','1111',1,'Cash','','','','',NULL,'',0.00),(1912,'2022-10-08 00:00:00','Nurse','Salary',-3000.00,'Expense','Shimla','1112',1,'Cash','','','','',NULL,'',0.00),(1913,'2022-10-08 00:00:00','Physiotherapist','Salary',-14000.00,'Expense','Jawhar','1113',1,'Cash','','','','',NULL,'',0.00),(1914,'2022-10-08 00:00:00','Draiver','Salary',-900.00,'Expense','Ishak','1114',1,'Cash','','','','',NULL,'',0.00),(1915,'2022-10-08 00:00:00','469','Homecare Refreshment',-280.00,'Expense','Smitha','1115',1,'Cash','','','','',NULL,'',0.00),(1916,'2022-10-09 00:00:00','470','Ambulance',-1000.00,'Expense','K P K Petrolium','1116',1,'Cash','','','','',NULL,'',0.00),(1917,'2022-10-09 00:00:00','471','Homecare Refreshment',-90.00,'Expense','Smitha','1117',1,'Cash','','','','',NULL,'',0.00),(1918,'2022-10-10 00:00:00','472','D H C Fees',-2500.00,'Expense','Dr. Pushpavally','1118',1,'Cash','','','','',NULL,'',0.00),(1919,'2022-10-10 00:00:00','473','Land & Build Tax',-100.00,'Expense','Village Office','1119',1,'Cash','','','','',NULL,'',0.00),(1920,'2022-10-10 00:00:00','474','Homecare Refreshment',-320.00,'Expense','Smitha','1120',1,'Cash','','','','',NULL,'',0.00),(1921,'2022-10-10 00:00:00','475','Vehicle Expense',-2000.00,'Expense','Fidha Petrolium','1121',1,'Cash','','','','',NULL,'',0.00),(1922,'2022-10-12 00:00:00','476','Missallanios Expense',-45.00,'Expense','Udayakumar','1122',1,'Cash','','','','',NULL,'',0.00),(1923,'2022-10-12 00:00:00','477','Missallanios Expense',-890.00,'Expense','Karappannan','1123',1,'Cash','','','','',NULL,'',0.00),(1924,'2022-10-12 00:00:00','478','Homecare Refreshment',-220.00,'Expense','Smitha','1124',1,'Cash','','','','',NULL,'',0.00),(1925,'2022-10-12 00:00:00','479','Printing & Stationary',-30.00,'Expense','Feston Supermarket','1125',1,'Cash','','','','',NULL,'',0.00),(1926,'2022-10-13 00:00:00','480','Printing & Stationary',-700.00,'Expense','Udayakumar','1126',1,'Cash','','','','',NULL,'',0.00),(1927,'2022-10-13 00:00:00','481','Ambulance',-800.00,'Expense','Achutha Nair & sons','1127',1,'Cash','','','','',NULL,'',0.00),(1928,'2022-10-13 00:00:00','482','Homecare Refreshment',-220.00,'Expense','Smitha','1128',1,'Cash','','','','',NULL,'',0.00),(1929,'2022-10-14 00:00:00','483','Ambulance',-130.00,'Expense','Pollution Contrl','1129',1,'Cash','','','','',NULL,'',0.00),(1930,'2022-10-14 00:00:00','480','Ambulance',-200.00,'Expense','Motor Edge','1130',1,'Cash','','','','',NULL,'',0.00),(1931,'2022-10-15 00:00:00','481','Homecare Refreshment',-240.00,'Expense','Shimla','1131',1,'Cash','','','','',NULL,'',0.00),(1932,'2022-10-15 00:00:00','482','Medicines',-1000.00,'Expense','Healing Surgicals','1132',1,'Cash','','','','',NULL,'',0.00),(1933,'2022-10-15 00:00:00','483','Printing & Stationary',-50.00,'Expense','Udayakumar','1133',1,'Cash','','','','',NULL,'',0.00),(1934,'2022-10-16 00:00:00','484','Printing & Stationary',-1130.00,'Expense','Sanha Textiles','1134',1,'Cash','','','','',NULL,'',0.00),(1935,'2022-10-16 00:00:00','485','Homecare Refreshment',-300.00,'Expense','Shimla','1135',1,'Cash','','','','',NULL,'',0.00),(1936,'2022-10-16 00:00:00','486','Training Programe',-300.00,'Expense','Mohd Rafeek','1136',1,'Cash','','','','',NULL,'',0.00),(1937,'2022-10-16 00:00:00','487','Training Programe',-500.00,'Expense','Secratary','1137',1,'Cash','','','','',NULL,'',0.00),(1938,'2022-10-17 00:00:00','488','Electricitty Charge`',-20000.00,'Expense','Ameer`','1138',1,'Cash','','','','',NULL,'',0.00),(1939,'2022-10-17 00:00:00','489','Medicines',-3147.00,'Expense','OXO Care Drugs','1139',1,'Cash','','','','',NULL,'',0.00),(1940,'2022-10-17 00:00:00','490','Homecare Refreshment',-210.00,'Expense','Shimla','1140',1,'Cash','','','','',NULL,'',0.00),(1941,'2022-10-18 00:00:00','491','Homecare Refreshment',-260.00,'Expense','Shimla','1141',1,'Cash','','','','',NULL,'',0.00),(1942,'2022-10-18 00:00:00','492','Printing & Stationary',-300.00,'Expense','Alingal Store','1142',1,'Cash','','','','',NULL,'',0.00),(1943,'2022-10-18 00:00:00','493','Homecare Refreshment',-240.00,'Expense','Shimla','1143',1,'Cash','','','','',NULL,'',0.00),(1944,'2022-10-20 00:00:00','494','Homecare Refreshment',-140.00,'Expense','Shimla','1144',1,'Cash','','','','',NULL,'',0.00),(1945,'2022-10-20 00:00:00','495','Electricitty Charge',-6066.00,'Expense','K S E B','1146',1,'Cash','','','','',NULL,'',0.00);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `asset`
--

DROP TABLE IF EXISTS `asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `asset` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ano` varchar(45) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `quantity` int DEFAULT '0',
  `cost` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `asset`
--

LOCK TABLES `asset` WRITE;
/*!40000 ALTER TABLE `asset` DISABLE KEYS */;
/*!40000 ALTER TABLE `asset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank`
--

DROP TABLE IF EXISTS `bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(200) DEFAULT NULL,
  `IsCash` tinyint DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank`
--

LOCK TABLES `bank` WRITE;
/*!40000 ALTER TABLE `bank` DISABLE KEYS */;
INSERT INTO `bank` VALUES (1,'Cash In Hand',1),(7,'Kerala Gramin Bank - 40687111000159',0),(8,'Mangalam Co Operative Bank - 10001001006801',0);
/*!40000 ALTER TABLE `bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `center`
--

DROP TABLE IF EXISTS `center`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `center` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Desc` varchar(255) DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `Phone` varchar(45) DEFAULT NULL,
  `RegNo` varchar(45) DEFAULT NULL,
  `AddressMal` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `LocationMal` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `NameMal` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `IncomeReceiptNo` int DEFAULT NULL,
  `MedExpiryDays` int DEFAULT NULL,
  `MedThresholdCount` int DEFAULT NULL,
  `ValidTill` varchar(255) DEFAULT NULL,
  `TodayAPI` varchar(255) DEFAULT NULL,
  `DescMal` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8_general_ci DEFAULT NULL,
  `ExpenseReceiptNo` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `center`
--

LOCK TABLES `center` WRITE;
/*!40000 ALTER TABLE `center` DISABLE KEYS */;
INSERT INTO `center` VALUES (1,'Karuna','P.O. Mangalam,\nMalappuram Dt, 676561','Pain & Palliative Care Association','Mangalam','9946638161','MPM/CA/1301/2014','P.O. Mangalam,\nMalappuram Dt, 676561','മംഗലം','കരുണ',1483,60,200,'1+NsCvRDQ3Pt3nsJUdaafQltoycg7t+Oc3ZwaUYUYVk5rsBEFgsNuXm9nHWzT4bIupLQ2Trp1uANvIBIJxmRCPosJlbc0L39DBJB4lHn1lDChaW0OeILBhf65xjJlLOz','HixM7jcAeNXD+dd+lUpTYd7eNI9Pj3m6PYvghTtmcMBlJEV3G0FOQtwlLQmj3JsTzPlTdXJMr6yWoOzXiJK1Ce/VRp0xiIKVLAuL4AiuGU3d0LHeStOzkU55h9pq9ZSK','പെയ്ൻ & പാലിയേറ്റീവ് കെയർ അസോസിയേഷൻ',1146);
/*!40000 ALTER TABLE `center` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diagnosis`
--

DROP TABLE IF EXISTS `diagnosis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diagnosis` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diagnosis`
--

LOCK TABLES `diagnosis` WRITE;
/*!40000 ALTER TABLE `diagnosis` DISABLE KEYS */;
INSERT INTO `diagnosis` VALUES (3,'CVA'),(4,'CAD'),(5,'COPD'),(6,'HTN'),(7,'T2 DM'),(8,'CKD'),(9,'CKD-DKD'),(10,'PSY');
/*!40000 ALTER TABLE `diagnosis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipment` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `eno` varchar(45) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `name_lower` varchar(200) DEFAULT NULL,
  `stock` int DEFAULT NULL,
  `damage` int DEFAULT NULL,
  `inuse` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment`
--

LOCK TABLES `equipment` WRITE;
/*!40000 ALTER TABLE `equipment` DISABLE KEYS */;
INSERT INTO `equipment` VALUES (2,'E1','FREEZER','freezer',1,0,0),(3,'E3','OXYGEN CONCENTRATOR','oxygen concentrator',4,1,0),(4,'E4','OXYGEN CYLINDER','oxygen cylinder',3,0,0),(5,'E5','HOSPITAL COAT','hospital coat',3,0,3),(6,'E6','WHEEL CHAIR','wheel chair',0,0,0),(7,'E7','WALKER','walker',0,0,0);
/*!40000 ALTER TABLE `equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipmentdispose`
--

DROP TABLE IF EXISTS `equipmentdispose`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipmentdispose` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `EquipmentId` int NOT NULL,
  `Eno` varchar(45) DEFAULT NULL,
  `Name` varchar(200) DEFAULT NULL,
  `Desc` varchar(200) DEFAULT NULL,
  `Qty` int DEFAULT NULL,
  `TxnDate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipmentdispose`
--

LOCK TABLES `equipmentdispose` WRITE;
/*!40000 ALTER TABLE `equipmentdispose` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipmentdispose` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipmenttracker`
--

DROP TABLE IF EXISTS `equipmenttracker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipmenttracker` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `EquipmentId` int NOT NULL,
  `patientname` varchar(200) DEFAULT NULL,
  `pno` varchar(45) DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `outdate` datetime DEFAULT NULL,
  `indate` datetime DEFAULT NULL,
  `deposit` decimal(10,2) DEFAULT NULL,
  `rent` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipmenttracker`
--

LOCK TABLES `equipmenttracker` WRITE;
/*!40000 ALTER TABLE `equipmenttracker` DISABLE KEYS */;
INSERT INTO `equipmenttracker` VALUES (3,2,'ABDURAHMAN','26/2016',1,'2022-07-01 00:00:00','2022-07-16 00:00:00',1000.00,300.00);
/*!40000 ALTER TABLE `equipmenttracker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expensetype`
--

DROP TABLE IF EXISTS `expensetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expensetype` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ExpenseType` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expensetype`
--

LOCK TABLES `expensetype` WRITE;
/*!40000 ALTER TABLE `expensetype` DISABLE KEYS */;
INSERT INTO `expensetype` VALUES (3,'Homecare Refreshment'),(4,'Vehicle Expense'),(5,'Salary'),(6,'Bank loan'),(7,'Telephone Charge'),(8,'Building Work'),(9,'Electricitty Charge'),(10,'Printing & Stationary'),(11,'Medicines'),(12,'D H C Fees'),(13,'Furniture & Fittings'),(14,'Missallanios Expense'),(15,'Training Programe'),(16,'Ambulance'),(17,'M I P Subscription'),(18,'Land & Build Tax'),(19,'Ambulance Commission');
/*!40000 ALTER TABLE `expensetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homecareplan`
--

DROP TABLE IF EXISTS `homecareplan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homecareplan` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Pno` varchar(45) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Type` varchar(45) DEFAULT NULL,
  `PatientName` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homecareplan`
--

LOCK TABLES `homecareplan` WRITE;
/*!40000 ALTER TABLE `homecareplan` DISABLE KEYS */;
/*!40000 ALTER TABLE `homecareplan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incometype`
--

DROP TABLE IF EXISTS `incometype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `incometype` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `IncomeType` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incometype`
--

LOCK TABLES `incometype` WRITE;
/*!40000 ALTER TABLE `incometype` DISABLE KEYS */;
INSERT INTO `incometype` VALUES (4,' Monthly Subscription'),(5,'Donation'),(6,'Box Collection'),(7,'Freezer& O2 Rent'),(8,'Missallanios Income'),(9,'Bank Interest'),(10,'Membership Fee'),(11,'Palliative Day Collection'),(12,'Hope'),(13,'Ambulance'),(14,'Rent'),(15,'HOPE'),(16,'masjid Collection');
/*!40000 ALTER TABLE `incometype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log` (
  `msg` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserName` varchar(45) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `UserTypeId` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (1,'admin','IgQbv7+JJxGyhkUheKb2GkuocurU2SuoLive49zMqXjqb1po5ZShm+eizTn0QXGZNHi3tZktNMwQrGCKbM4IYpRaFhuMbeoV+VVUxcOHVPEU+OaJh7E1U7KIjobzKKLx',1),(2,'shakeeb','N2hco3FE4V9JdIzexJor9bEmFjACIZgLyYErmtX6ygpYjtj64gbSRI8VFh01uepCzAhj2zp4FEGgsCIQCACdPJyZWhzE4QHHZhQWqPaZUWpMrPCqK/ZJMAsvLECrwQ24',1),(3,'accounts','7W3fCAoAKKbshdfB8QG6sb/Xb4SYfGzxw6YW0nFq42HgjTBEFqs5Qkf4JJalWpiqsSSTYvbk97DdYyIMpB0KNwzz53Ulwg4cyTNyV6uVfcvAg7PM0LhgQJYkprDXAIZf',2),(4,'medicines','Vlv15GXNN02vo2Uqd+Wp4iiCFGhZlmmBBWCQOJrrucUM46oOYosSNhbsn9q4BKaNbr7J16NHCYUlR8XCcVN/7mnvEGeN4y8j5dye4OSnn7T2xSMItXVRWsr8rvFM/jld',3),(5,'Patients','Ci9XfrCuVKLX1ikbLJCyLorf7HAG27fiEmKOGVMlHKl2pGuHuCALijPtbwP/9Bn26YjJ3nAtauGyYJDXBK/Cp1fwtbB+tvkBjO6VzC99KduaOm30vP2tbXrH49cty/p+',4);
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicine`
--

DROP TABLE IF EXISTS `medicine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicine` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Mno` varchar(45) DEFAULT NULL,
  `Name` varchar(200) DEFAULT NULL,
  `NameLower` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicine`
--

LOCK TABLES `medicine` WRITE;
/*!40000 ALTER TABLE `medicine` DISABLE KEYS */;
INSERT INTO `medicine` VALUES (1,'M1','Tab Ondansetron 4mg','tab ondansetron 4mg'),(2,'M2','Tab Hydroxychloroquine 200 mg','tab hydroxychloroquine 200 mg'),(3,'M3','Tab Bisacodyl','tab bisacodyl'),(4,'M4','Tab Metformin 500 mg','tab metformin 500 mg'),(5,'M5','Tab Tramadol and Acetaminophen (Calpol T)','tab tramadol and acetaminophen (calpol t)'),(6,'M6','Tab Torsemide 10 mg ','tab torsemide 10 mg '),(7,'M7','Tab Pantoprazole 40 mg','tab pantoprazole 40 mg'),(8,'M8','Tab Gabapentin 100 mg','tab gabapentin 100 mg'),(9,'M9','Tab Tramadol 50 mg','tab tramadol 50 mg'),(10,'M10','Tab Telmisartan 40mg','tab telmisartan 40mg'),(11,'M11','Tab Quetiapine Fumarate 50 mg','tab quetiapine fumarate 50 mg'),(12,'M12','Tab Quetiapine Fumarate 25 mg','tab quetiapine fumarate 25 mg'),(13,'M13','Tab Fluoxetine 20 mg','tab fluoxetine 20 mg'),(14,'M14','Tab Oxcarbazepine 150mg','tab oxcarbazepine 150mg'),(15,'M15','Tab Ropinirole 2mg','tab ropinirole 2mg'),(16,'M16','Sodium Acid Phosphate Granules','sodium acid phosphate granules'),(17,'M17','Inj. Sodium Chloride IV 100ml','inj. sodium chloride iv 100ml'),(18,'M18','Inj. Mannitol IV 100ml','inj. mannitol iv 100ml'),(19,'M19','Tab Carbamazepine CR 200mg','tab carbamazepine cr 200mg'),(20,'M20','Tab Levetiracetam (Levipil) 500 mg','tab levetiracetam (levipil) 500 mg'),(21,'M21','Oint Megaheal 50 g','oint megaheal 50 g'),(22,'M22','Tab Amitriptyline 10 mg ','tab amitriptyline 10 mg '),(23,'M23','Tab Risperidone 1 mg  ','tab risperidone 1 mg  '),(24,'M24','Tab Moxikind CV 625 mg','tab moxikind cv 625 mg'),(25,'M25','Tab Metformin 500mg +Glimepiride 2mg','tab metformin 500mg +glimepiride 2mg'),(26,'M26','Tab Livogen','tab livogen'),(27,'M27','Tab Spironolactone 50mg(Spiraldo)','tab spironolactone 50mg(spiraldo)'),(28,'M28','Tab Amoxyclav 625 mg','tab amoxyclav 625 mg'),(29,'M29','Tab Cefixime 200mg','tab cefixime 200mg'),(30,'M30','Tab Doxofylline 200mg(Doxoline)','tab doxofylline 200mg(doxoline)'),(31,'M31','Tab Baclofen 10 mg','tab baclofen 10 mg'),(32,'M32','Tab Fluconazole 150mg','tab fluconazole 150mg'),(33,'M33','Oint Lignocaine Jelly 30 g','oint lignocaine jelly 30 g'),(34,'M34','Water for injection 10 ml','water for injection 10 ml'),(35,'M35','Tab Dericip Retard 150mg','tab dericip retard 150mg'),(36,'M36','Inj. Dexona ','inj. dexona '),(37,'M37','Inj. Deriphyllin','inj. deriphyllin'),(38,'M38','Inj. Atropine','inj. atropine'),(39,'M39','IV Cannula 24 (Intra Cath)','iv cannula 24 (intra cath)'),(40,'M40','Inj. NS (Normal Saline) 3% 100 ml','inj. ns (normal saline) 3% 100 ml'),(41,'M41','Ascodex Plus Cough Syrup','ascodex plus cough syrup'),(42,'M42','Syrup Citralka','syrup citralka'),(43,'M43','Liquid Paraffin','liquid paraffin'),(44,'M44','Absorbent Gauze (Surgical Gauze) 100cmx10M','absorbent gauze (surgical gauze) 100cmx10m'),(45,'M45','Roller Bandage 10cm X 3M','roller bandage 10cm x 3m'),(46,'M46','Cotton Wool Absorbant 400gm','cotton wool absorbant 400gm'),(47,'M47','Disposable Syringe2.5ml (Dispovan) ','disposable syringe2.5ml (dispovan) '),(48,'M48','Disposable Syringe 5ml(Dispovan) ','disposable syringe 5ml(dispovan) '),(49,'M49','Disposable Syringe 20ml (Dispovan)','disposable syringe 20ml (dispovan)'),(50,'M50','Disposable Syringe 10 ml (Dispovan)','disposable syringe 10 ml (dispovan)'),(51,'M51','Tab Sertraline 50mg(Zosert)','tab sertraline 50mg(zosert)'),(52,'M52','Tab Ativan 2mg (Lorazepam)','tab ativan 2mg (lorazepam)'),(53,'M53','Tab Mirtaz 7.5mg(Mirtazapine)','tab mirtaz 7.5mg(mirtazapine)'),(54,'M54','Tab Pacitane 2mg','tab pacitane 2mg'),(55,'M55','Tab Atomoxetine 18 mg(Attentrol)','tab atomoxetine 18 mg(attentrol)'),(56,'M56','Tab Fluoxetine 10mg (Prodep)','tab fluoxetine 10mg (prodep)'),(57,'M57','Tab Clonazepam 0.5mg','tab clonazepam 0.5mg'),(58,'M58','Tab Clonazepam 0.25mg','tab clonazepam 0.25mg'),(59,'M59','Tab Atomoxetine 10 mg(Attenrol)','tab atomoxetine 10 mg(attenrol)'),(60,'M60','Syndopa Plus (Levodopa 100mg +Carbidopa 25mg)','syndopa plus (levodopa 100mg +carbidopa 25mg)'),(61,'M61','Tab Lithium Carbonate (Lithosun SR) 400 mg','tab lithium carbonate (lithosun sr) 400 mg'),(62,'M62','Tab Azathioprine 50 mg(AZR)','tab azathioprine 50 mg(azr)'),(63,'M63','Tab Amisulpride 50 mg(Sulpitac)','tab amisulpride 50 mg(sulpitac)'),(64,'M64','Tab Trivedom MR','tab trivedom mr'),(65,'M65','Tab Torsemide 40mg (TOR 40)','tab torsemide 40mg (tor 40)'),(66,'M66','Tab Oxcarbazepine 300 mg','tab oxcarbazepine 300 mg'),(67,'M67','Tab Cipcal 500','tab cipcal 500'),(68,'M68','Tab Prazopress XL 5mg','tab prazopress xl 5mg'),(69,'M69','Tab Deriphyllin Retard 150 mg','tab deriphyllin retard 150 mg'),(70,'M70','Tab Nexito Plus','tab nexito plus'),(71,'M71','Tab Amlodipine 5mg','tab amlodipine 5mg'),(72,'M72','Tab Encorate 500 (Sodium Valproate)','tab encorate 500 (sodium valproate)'),(73,'M73','Tab Encorate 300mg(Sodium Valporate)','tab encorate 300mg(sodium valporate)'),(74,'M74','Tab Encorate 200mg(Sodium valporate)','tab encorate 200mg(sodium valporate)'),(75,'M75','Tab Mirtaz 15mg (Mirtazapine)','tab mirtaz 15mg (mirtazapine)'),(76,'M76','Tab Arpizol 2mg((Aripiprazole)','tab arpizol 2mg((aripiprazole)'),(77,'M77','Tab Cilinitab 20( Cilnidipine)','tab cilinitab 20( cilnidipine)'),(78,'M78','Tab Clozapine 25 mg(Sizopin)','tab clozapine 25 mg(sizopin)'),(79,'M79','Tab Dyslone 6(Deflazacort)','tab dyslone 6(deflazacort)'),(80,'M80','Inj. Pantop','inj. pantop'),(81,'M81','Blood Collection Tube ','blood collection tube '),(82,'M82','Povidone Iodine Solution 500ml','povidone iodine solution 500ml'),(83,'M83','ISO PLUS (FL) 400 ML','iso plus (fl) 400 ml'),(84,'M84','Diclofenac Gel ','diclofenac gel '),(85,'M85','Infusion Set (I V Set)','infusion set (i v set)'),(86,'M86','ichthamol Glycerin','ichthamol glycerin'),(87,'M87','Scalp Vein Set','scalp vein set'),(88,'M88','Surgical Gloves non sterile (Surgicare) 6 1/2 ','surgical gloves non sterile (surgicare) 6 1/2 '),(89,'M89','Dispo needle 26 x 1 1/2','dispo needle 26 x 1 1/2'),(90,'M90','Cannula Fixator 4.5 cm x 6 cm','cannula fixator 4.5 cm x 6 cm'),(91,'M91','Vasofix IV Cannula 22 Gx1','vasofix iv cannula 22 gx1'),(92,'M92','Urine collection Bag','urine collection bag'),(93,'M93','Inj. RL (Compound Sodium Lactate)','inj. rl (compound sodium lactate)'),(94,'M94','Inj. DNS','inj. dns'),(95,'M95','Inj. N S 500ml','inj. n s 500ml'),(96,'M96','Ryle\'s Tube ','ryle\'s tube '),(97,'M97','Foley Catheter 16 ','foley catheter 16 '),(98,'M98','Foley Catheter 14 ','foley catheter 14 '),(99,'M99','Foley Catheter 20','foley catheter 20'),(100,'M100','Foley Catheter 14 FG','foley catheter 14 fg'),(101,'M101','Foley Catheter 16 FG','foley catheter 16 fg'),(102,'M102','Nel Cath 14 FG','nel cath 14 fg'),(103,'M103','Nel Cath FG 10','nel cath fg 10'),(104,'M104','Tab Syndopa 110','tab syndopa 110'),(105,'M105','Tab WARF-2','tab warf-2'),(106,'M106','Tam Amantrel','tam amantrel'),(107,'M107','Tab Lanoxin 0.25 mg','tab lanoxin 0.25 mg'),(108,'M108','Tab Clonidime 100mg','tab clonidime 100mg'),(109,'M109','Tab Cardiset-6.25','tab cardiset-6.25'),(110,'M110','Sterile Gloves (Skintac) 7.5','sterile gloves (skintac) 7.5'),(111,'M111','Tab Cinaloc T','tab cinaloc t'),(112,'M112','Tab Becotab NF','tab becotab nf'),(113,'M113','Tab Metron 400mg ','tab metron 400mg '),(114,'M114','Tab De-cal','tab de-cal'),(115,'M115','Tab Phensedyl LM ','tab phensedyl lm '),(116,'M116','Adhessive Tape 5.0 X 9.1 M (Paper Plaster)','adhessive tape 5.0 x 9.1 m (paper plaster)'),(117,'M117','Sodium Phosphate Enema ','sodium phosphate enema '),(118,'M118','Sterile Gloves (surgical) 6.5','sterile gloves (surgical) 6.5'),(119,'M119','Roller Bandage 7.5cm X 3M','roller bandage 7.5cm x 3m'),(120,'M120','Telwave 40 ( telmisarton)','telwave 40 ( telmisarton)'),(121,'M121','NICARDIA 20 MG','nicardia 20 mg'),(122,'M122','MUSINAC 600 MG','musinac 600 mg'),(123,'M123','FRUCIX 40 - FRUSEMIDE 40','frucix 40 - frusemide 40'),(124,'M124',' FRUSEMIDE 100 MG -FRUSENEX 100',' frusemide 100 mg -frusenex 100'),(125,'M125','LASILACTONE 50','lasilactone 50'),(126,'M126','ONCLANSETRON 4 MG - EMESET 4','onclansetron 4 mg - emeset 4'),(127,'M127','SURGICAL GLOVE(STERILE) 7','surgical glove(sterile) 7'),(128,'M128','ONVIN 4MD-ONDANSETRON ORALLY DISINTEGRATING TAB','onvin 4md-ondansetron orally disintegrating tab'),(129,'M129','CINALOC 10 -CILNIDIPINE 10','cinaloc 10 -cilnidipine 10'),(130,'M130','Tab Tramadol 50 mg- TRAMAZAC 50','tab tramadol 50 mg- tramazac 50'),(131,'M131','TRAMATAZ- TRAMADOL 50','tramataz- tramadol 50'),(132,'M132','ULTRASET ','ultraset '),(133,'M133','BACLOFEN 5 MG','baclofen 5 mg'),(134,'M134','CALPOL T ','calpol t '),(135,'M135','MELOXICAM 15MG','meloxicam 15mg'),(136,'M136','ATEN 50( ATENOLOL 50MG)','aten 50( atenolol 50mg)'),(137,'M137','metroninazole 400mg-metrogyl 400mg','metroninazole 400mg-metrogyl 400mg'),(138,'M138','PARACETAMOL 500MG- DOLIPRANE 500MG','paracetamol 500mg- doliprane 500mg'),(139,'M139','HALOPERIDOL 0.25MG','haloperidol 0.25mg'),(140,'M140','FERROUS FUMARATE AND FOLIC ACID TAB','ferrous fumarate and folic acid tab'),(141,'M141','TRIFIX 200 (Tab Cefixime 200mg)','trifix 200 (tab cefixime 200mg)'),(142,'M142','MOXCLAV 625MG','moxclav 625mg'),(143,'M143','AMOXCLAV 625MG','amoxclav 625mg'),(144,'M144','L QUIN 500','l quin 500'),(145,'M145','ALPRAX 0.25MG','alprax 0.25mg'),(146,'M146','ESCITALOPRAM (REXIPRA 15MG)','escitalopram (rexipra 15mg)'),(147,'M147','QUITIPIN 25MG','quitipin 25mg'),(148,'M148','dexamethazone sodium phosphate inj; dexona 4mg','dexamethazone sodium phosphate inj; dexona 4mg'),(149,'M149','FRUSEMIDE 10MG','frusemide 10mg'),(150,'M150','INJ POLYNION','inj polynion'),(151,'M151','INJ LASIX','inj lasix'),(152,'M152','inj atropine 0.6mg','inj atropine 0.6mg'),(153,'M153','INJ DERIPHYLLIN','inj deriphyllin'),(154,'M154','INJ EMESET ','inj emeset '),(155,'M155','HEMSYL 125MG','hemsyl 125mg'),(156,'M156','inj 3% saline','inj 3% saline'),(157,'M157','IVF D10 ','ivf d10 '),(158,'M158','IVF D5','ivf d5'),(159,'M159','IVF DNS ','ivf dns '),(160,'M160','IVF RL','ivf rl'),(161,'M161','INJ MANITOL 100 ML','inj manitol 100 ml'),(162,'M162','INJ 25%DEXTROSE 100 ML','inj 25%dextrose 100 ml'),(163,'M163','IVF 100ML NS ','ivf 100ml ns '),(164,'M164','UROBAG ROMO 10','urobag romo 10'),(165,'M165','DOLIPRANE 650 ( PARACETAMOL TABLETS I.P 650','doliprane 650 ( paracetamol tablets i.p 650'),(166,'M166','DEXTROSE INJECTION IP (10% W/V) 500 ML','dextrose injection ip (10% w/v) 500 ml'),(167,'M167','AJAPRIDE M2 (METFORMIN HYDROCHLORIDE PROLONGED RELEASE & GLIMEPRIDE TAB IP','ajapride m2 (metformin hydrochloride prolonged release & glimepride tab ip'),(168,'M168','MULTI9 (MULTIVITAMIN TABLETS)','multi9 (multivitamin tablets)'),(169,'M169','Tab Amlodipine BESILATE 10mg( AMLIP10)','tab amlodipine besilate 10mg( amlip10)'),(170,'M170','TRANQUILAM 0.25 CLONAZEPAM TAB IP 0.25','tranquilam 0.25 clonazepam tab ip 0.25'),(171,'M171','BLOOD LANCET 100S ','blood lancet 100s '),(172,'M172','GLUCO ONE 50S STRIP','gluco one 50s strip'),(173,'M173','sterile water for injection IP','sterile water for injection ip'),(174,'M174','SURGICAL GLOVES NON STERILE 7.5','surgical gloves non sterile 7.5'),(175,'M175','SURGICAL GLOVE 7.5','surgical glove 7.5'),(176,'M176','RISPERIDONE TAB - SIZODON4','risperidone tab - sizodon4'),(177,'M177','CLOBA5- CLOBAZAM TAB 5MG','cloba5- clobazam tab 5mg');
/*!40000 ALTER TABLE `medicine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicinehistory`
--

DROP TABLE IF EXISTS `medicinehistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicinehistory` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `MedicineId` int DEFAULT NULL,
  `txnDate` datetime DEFAULT NULL,
  `mno` varchar(45) DEFAULT NULL,
  `medName` varchar(200) DEFAULT NULL,
  `txnType` varchar(45) DEFAULT NULL,
  `desc` varchar(45) DEFAULT NULL,
  `openingMain` int DEFAULT NULL,
  `openingSub` int DEFAULT NULL,
  `openingAKit` int DEFAULT NULL,
  `openingBKit` int DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `closingMain` int DEFAULT NULL,
  `closingSub` int DEFAULT NULL,
  `closingAKit` int DEFAULT NULL,
  `closingBKit` int DEFAULT NULL,
  `pno` varchar(45) DEFAULT NULL,
  `patientName` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=617 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicinehistory`
--

LOCK TABLES `medicinehistory` WRITE;
/*!40000 ALTER TABLE `medicinehistory` DISABLE KEYS */;
INSERT INTO `medicinehistory` VALUES (1,1,'2022-11-26 00:00:00','M1','Tab Ondansetron 4mg','Add','To main stock',0,0,0,0,500,500,0,0,0,'',''),(2,2,'2022-11-26 00:00:00','M2','Tab Hydroxychloroquine 200 mg','Add','To main stock',0,0,0,0,60,60,0,0,0,'',''),(3,2,'2022-11-26 00:00:00','M2','Tab Hydroxychloroquine 200 mg','Inbound','To main stock',60,0,0,0,135,195,0,0,0,'',''),(4,2,'2022-11-26 00:00:00','M2','Tab Hydroxychloroquine 200 mg','Inbound','To main stock',195,0,0,0,30,225,0,0,0,'',''),(5,3,'2022-11-26 00:00:00','M3','Tab Bisacodyl','Add','To main stock',0,0,0,0,360,360,0,0,0,'',''),(6,4,'2022-11-26 00:00:00','M4','Tab Metformin 500 mg','Add','To main stock',0,0,0,0,340,340,0,0,0,'',''),(7,5,'2022-11-26 00:00:00','M5','Tab Tramadol and Acetaminophen (Calpol T)','Add','To main stock',0,0,0,0,29,29,0,0,0,'',''),(8,6,'2022-11-26 00:00:00','M6','Tab Torsemide 10 mg ','Add','To main stock',0,0,0,0,36,36,0,0,0,'',''),(9,7,'2022-11-26 00:00:00','M7','Tab Pantoprazole 40 mg','Add','To main stock',0,0,0,0,345,345,0,0,0,'',''),(10,8,'2022-11-26 00:00:00','M8','Tab Gabapentin 100 mg','Add','To main stock',0,0,0,0,100,100,0,0,0,'',''),(11,9,'2022-11-26 00:00:00','M9','Tab Tramadol 50 mg','Add','To main stock',0,0,0,0,120,120,0,0,0,'',''),(12,10,'2022-11-26 00:00:00','M10','Tab Telmisartan 40mg','Add','To main stock',0,0,0,0,450,450,0,0,0,'',''),(13,11,'2022-11-26 00:00:00','M11','Tab Quetiapine Fumarate 50 mg','Add','To main stock',0,0,0,0,70,70,0,0,0,'',''),(14,12,'2022-11-26 00:00:00','M12','Tab Quetiapine Fumarate 25 mg','Add','To main stock',0,0,0,0,140,140,0,0,0,'',''),(15,13,'2022-11-26 00:00:00','M13','Tab Fluoxetine 20 mg','Add','To main stock',0,0,0,0,200,200,0,0,0,'',''),(16,14,'2022-11-26 00:00:00','M14','Tab Oxcarbazepine 150mg','Add','To main stock',0,0,0,0,300,300,0,0,0,'',''),(17,15,'2022-11-26 00:00:00','M15','Tab Ropinirole 2mg','Add','To main stock',0,0,0,0,190,190,0,0,0,'',''),(18,16,'2022-11-26 00:00:00','M16','Sodium Acid Phosphate Granules','Add','To main stock',0,0,0,0,10,10,0,0,0,'',''),(19,16,'2022-11-26 00:00:00','M16','Sodium Acid Phosphate Granules','Inbound','To main stock',10,0,0,0,10,20,0,0,0,'',''),(20,17,'2022-11-26 00:00:00','M17','Inj. Sodium Chloride IV 100ml','Add','To main stock',0,0,0,0,2,2,0,0,0,'',''),(21,18,'2022-11-26 00:00:00','M18','Inj. Mannitol IV 100ml','Add','To main stock',0,0,0,0,4,4,0,0,0,'',''),(22,19,'2022-11-26 00:00:00','M19','Tab Carbamazepine CR 200mg','Add','To main stock',0,0,0,0,90,90,0,0,0,'',''),(23,7,'2022-11-26 00:00:00','M7','Tab Pantoprazole 40 mg','Inbound','To main stock',345,0,0,0,165,510,0,0,0,'',''),(24,20,'2022-11-26 00:00:00','M20','Tab Levetiracetam (Levipil) 500 mg','Add','To main stock',0,0,0,0,100,100,0,0,0,'',''),(25,21,'2022-11-26 00:00:00','M21','Oint Megaheal 50 g','Add','To main stock',0,0,0,0,2,2,0,0,0,'',''),(26,1,'2022-11-26 00:00:00','M1','Tab Ondansetron 4mg','Inbound','To main stock',500,0,0,0,200,700,0,0,0,'',''),(27,22,'2022-11-26 00:00:00','M22','Tab Amitriptyline 10 mg ','Add','To main stock',0,0,0,0,100,100,0,0,0,'',''),(28,23,'2022-11-26 00:00:00','M23','Tab Risperidone 1 mg  ','Add','To main stock',0,0,0,0,100,100,0,0,0,'',''),(29,24,'2022-11-26 00:00:00','M24','Tab Moxikind CV 625 mg','Add','To main stock',0,0,0,0,100,100,0,0,0,'',''),(30,25,'2022-11-26 00:00:00','M25','Tab Metformin 500mg +Glimepiride 2mg','Add','To main stock',0,0,0,0,90,90,0,0,0,'',''),(31,26,'2022-11-26 00:00:00','M26','Tab Livogen','Add','To main stock',0,0,0,0,225,225,0,0,0,'',''),(32,27,'2022-11-26 00:00:00','M27','Tab Spironolactone 50mg(Spiraldo)','Add','To main stock',0,0,0,0,300,300,0,0,0,'',''),(33,28,'2022-11-26 00:00:00','M28','Tab Amoxyclav 625 mg','Add','To main stock',0,0,0,0,80,80,0,0,0,'',''),(34,29,'2022-11-26 00:00:00','M29','Tab Cefixime 200mg','Add','To main stock',0,0,0,0,30,30,0,0,0,'',''),(35,30,'2022-11-26 00:00:00','M30','Tab Doxofylline 200mg(Doxoline)','Add','To main stock',0,0,0,0,300,300,0,0,0,'',''),(36,31,'2022-11-26 00:00:00','M31','Tab Baclofen 10 mg','Add','To main stock',0,0,0,0,100,100,0,0,0,'',''),(37,32,'2022-11-26 00:00:00','M32','Tab Fluconazole 150mg','Add','To main stock',0,0,0,0,45,45,0,0,0,'',''),(38,33,'2022-11-26 00:00:00','M33','Oint Lignocaine Jelly 30 g','Add','To main stock',0,0,0,0,17,17,0,0,0,'',''),(39,34,'2022-11-26 00:00:00','M34','Water for injection 10 ml','Add','To main stock',0,0,0,0,70,70,0,0,0,'',''),(40,35,'2022-11-26 00:00:00','M35','Tab Dericip Retard 150mg','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(41,36,'2022-11-26 00:00:00','M36','Inj. Dexona ','Add','To main stock',0,0,0,0,30,30,0,0,0,'',''),(42,37,'2022-11-26 00:00:00','M37','Inj. Deriphyllin','Add','To main stock',0,0,0,0,20,20,0,0,0,'',''),(43,38,'2022-11-26 00:00:00','M38','Inj. Atropine','Add','To main stock',0,0,0,0,5,5,0,0,0,'',''),(44,39,'2022-11-26 00:00:00','M39','IV Cannula 24 (Intra Cath)','Add','To main stock',0,0,0,0,10,10,0,0,0,'',''),(45,40,'2022-11-26 00:00:00','M40','Inj. NS (Normal Saline) 3% 100 ml','Add','To main stock',0,0,0,0,4,4,0,0,0,'',''),(46,41,'2022-11-26 00:00:00','M41','Ascodex Plus Cough Syrup','Add','To main stock',0,0,0,0,6,6,0,0,0,'',''),(47,42,'2022-11-26 00:00:00','M42','Syrup Citralka','Add','To main stock',0,0,0,0,21,21,0,0,0,'',''),(48,43,'2022-11-26 00:00:00','M43','Liquid Paraffin','Add','To main stock',0,0,0,0,14,14,0,0,0,'',''),(49,44,'2022-11-26 00:00:00','M44','Absorbent Gauze (Surgical Gauze) 100cmx10M','Add','To main stock',0,0,0,0,3,3,0,0,0,'',''),(50,44,'2022-11-26 00:00:00','M44','Absorbent Gauze (Surgical Gauze) 100cmx10M','Inbound','To main stock',3,0,0,0,1,4,0,0,0,'',''),(51,44,'2022-11-26 00:00:00','M44','Absorbent Gauze (Surgical Gauze) 100cmx10M','Inbound','To main stock',4,0,0,0,2,6,0,0,0,'',''),(52,45,'2022-11-26 00:00:00','M45','Roller Bandage 10cm X 3M','Add','To main stock',0,0,0,0,29,29,0,0,0,'',''),(53,46,'2022-11-26 00:00:00','M46','Cotton Wool Absorbant 400gm','Add','To main stock',0,0,0,0,1,1,0,0,0,'',''),(54,47,'2022-11-26 00:00:00','M47','Disposable Syringe2.5ml (Dispovan) ','Add','To main stock',0,0,0,0,100,100,0,0,0,'',''),(55,48,'2022-11-26 00:00:00','M48','Disposable Syringe 5ml(Dispovan) ','Add','To main stock',0,0,0,0,63,63,0,0,0,'',''),(56,48,'2022-11-26 00:00:00','M48','Disposable Syringe 5ml(Dispovan) ','Inbound','To main stock',63,0,0,0,24,87,0,0,0,'',''),(57,49,'2022-11-26 00:00:00','M49','Disposable Syringe 20ml (Dispovan)','Add','To main stock',0,0,0,0,10,10,0,0,0,'',''),(58,50,'2022-11-26 00:00:00','M50','Disposable Syringe 10 ml (Dispovan)','Add','To main stock',0,0,0,0,111,111,0,0,0,'',''),(59,50,'2022-11-26 00:00:00','M50','Disposable Syringe 10 ml (Dispovan)','Inbound','To main stock',111,0,0,0,100,211,0,0,0,'',''),(60,51,'2022-11-26 00:00:00','M51','Tab Sertraline 50mg(Zosert)','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(61,52,'2022-11-26 00:00:00','M52','Tab Ativan 2mg (Lorazepam)','Add','To main stock',0,0,0,0,150,150,0,0,0,'',''),(62,53,'2022-11-26 00:00:00','M53','Tab Mirtaz 7.5mg(Mirtazapine)','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(63,54,'2022-11-26 00:00:00','M54','Tab Pacitane 2mg','Add','To main stock',0,0,0,0,300,300,0,0,0,'',''),(64,55,'2022-11-26 00:00:00','M55','Tab Atomoxetine 18 mg(Attentrol)','Add','To main stock',0,0,0,0,149,149,0,0,0,'',''),(65,13,'2022-11-26 00:00:00','M13','Tab Fluoxetine 20 mg','Inbound','To main stock',200,0,0,0,20,220,0,0,0,'',''),(66,56,'2022-11-26 00:00:00','M56','Tab Fluoxetine 10mg (Prodep)','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(67,57,'2022-11-29 00:00:00','M57','Tab Clonazepam 0.5mg','Add','To main stock',0,0,0,0,190,190,0,0,0,'',''),(68,58,'2022-11-29 00:00:00','M58','Tab Clonazepam 0.25mg','Add','To main stock',0,0,0,0,20,20,0,0,0,'',''),(69,59,'2022-11-29 00:00:00','M59','Tab Atomoxetine 10 mg(Attenrol)','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(70,60,'2022-11-29 00:00:00','M60','Syndopa Plus (Levodopa 100mg +Carbidopa 25mg)','Add','To main stock',0,0,0,0,10,10,0,0,0,'',''),(71,60,'2022-11-29 00:00:00','M60','Syndopa Plus (Levodopa 100mg +Carbidopa 25mg)','Inbound','To main stock',10,0,0,0,20,30,0,0,0,'',''),(72,61,'2022-11-29 00:00:00','M61','Tab Lithium Carbonate (Lithosun SR) 400 mg','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(73,62,'2022-11-29 00:00:00','M62','Tab Azathioprine 50 mg(AZR)','Add','To main stock',0,0,0,0,100,100,0,0,0,'',''),(74,63,'2022-11-29 00:00:00','M63','Tab Amisulpride 50 mg(Sulpitac)','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(75,64,'2022-11-29 00:00:00','M64','Tab Trivedom MR','Add','To main stock',0,0,0,0,260,260,0,0,0,'',''),(76,65,'2022-11-29 00:00:00','M65','Tab Torsemide 40mg (TOR 40)','Add','To main stock',0,0,0,0,130,130,0,0,0,'',''),(77,14,'2022-11-29 00:00:00','M14','Tab Oxcarbazepine 150mg','Inbound','To main stock',300,0,0,0,20,320,0,0,0,'',''),(78,66,'2022-11-29 00:00:00','M66','Tab Oxcarbazepine 300 mg','Add','To main stock',0,0,0,0,20,20,0,0,0,'',''),(79,67,'2022-11-29 00:00:00','M67','Tab Cipcal 500','Add','To main stock',0,0,0,0,195,195,0,0,0,'',''),(80,68,'2022-11-29 00:00:00','M68','Tab Prazopress XL 5mg','Add','To main stock',0,0,0,0,60,60,0,0,0,'',''),(81,69,'2022-11-29 00:00:00','M69','Tab Deriphyllin Retard 150 mg','Add','To main stock',0,0,0,0,630,630,0,0,0,'',''),(82,62,'2022-11-29 00:00:00','M62','Tab Azathioprine 50 mg(AZR)','Inbound','To main stock',100,0,0,0,120,220,0,0,0,'',''),(83,70,'2022-11-29 00:00:00','M70','Tab Nexito Plus','Add','To main stock',0,0,0,0,20,20,0,0,0,'',''),(84,60,'2022-11-29 00:00:00','M60','Syndopa Plus (Levodopa 100mg +Carbidopa 25mg)','Inbound','To main stock',30,0,0,0,150,180,0,0,0,'',''),(85,71,'2022-11-29 00:00:00','M71','Tab Amlodipine 5mg','Add','To main stock',0,0,0,0,140,140,0,0,0,'',''),(86,72,'2022-11-29 00:00:00','M72','Tab Encorate 500 (Sodium Valproate)','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(87,73,'2022-11-29 00:00:00','M73','Tab Encorate 300mg(Sodium Valporate)','Add','To main stock',0,0,0,0,40,40,0,0,0,'',''),(88,73,'2022-11-29 00:00:00','M73','Tab Encorate 300mg(Sodium Valporate)','Inbound','To main stock',40,0,0,0,10,50,0,0,0,'',''),(89,74,'2022-11-29 00:00:00','M74','Tab Encorate 200mg(Sodium valporate)','Add','To main stock',0,0,0,0,30,30,0,0,0,'',''),(90,75,'2022-11-29 00:00:00','M75','Tab Mirtaz 15mg (Mirtazapine)','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(91,19,'2022-11-29 00:00:00','M19','Tab Carbamazepine CR 200mg','Inbound','To main stock',90,0,0,0,30,120,0,0,0,'',''),(92,76,'2022-11-29 00:00:00','M76','Tab Arpizol 2mg((Aripiprazole)','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(93,77,'2022-11-29 00:00:00','M77','Tab Cilinitab 20( Cilnidipine)','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(94,78,'2022-11-29 00:00:00','M78','Tab Clozapine 25 mg(Sizopin)','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(95,8,'2022-11-29 00:00:00','M8','Tab Gabapentin 100 mg','Inbound','To main stock',100,0,0,0,20,120,0,0,0,'',''),(96,60,'2022-11-29 00:00:00','M60','Syndopa Plus (Levodopa 100mg +Carbidopa 25mg)','Inbound','To main stock',180,0,0,0,10,190,0,0,0,'',''),(97,79,'2022-11-29 00:00:00','M79','Tab Dyslone 6(Deflazacort)','Add','To main stock',0,0,0,0,10,10,0,0,0,'',''),(98,80,'2022-11-29 00:00:00','M80','Inj. Pantop','Add','To main stock',0,0,0,0,10,10,0,0,0,'',''),(99,81,'2022-11-29 00:00:00','M81','Blood Collection Tube ','Add','To main stock',0,0,0,0,71,71,0,0,0,'',''),(100,82,'2022-11-29 00:00:00','M82','Povidone Iodine Solution 500ml','Add','To main stock',0,0,0,0,2,2,0,0,0,'',''),(101,83,'2022-11-29 00:00:00','M83','ISO PLUS (FL) 400 ML','Add','To main stock',0,0,0,0,1,1,0,0,0,'',''),(102,84,'2022-11-29 00:00:00','M84','Diclofenac Gel ','Add','To main stock',0,0,0,0,6,6,0,0,0,'',''),(103,40,'2022-11-29 00:00:00','M40','Inj. NS (Normal Saline) 3% 100 ml','Inbound','To main stock',4,0,0,0,2,6,0,0,0,'',''),(104,85,'2022-11-29 00:00:00','M85','Infusion Set (I V Set)','Add','To main stock',0,0,0,0,25,25,0,0,0,'',''),(105,86,'2022-11-29 00:00:00','M86','ichthamol Glycerin','Add','To main stock',0,0,0,0,2,2,0,0,0,'',''),(106,87,'2022-11-29 00:00:00','M87','Scalp Vein Set','Add','To main stock',0,0,0,0,29,29,0,0,0,'',''),(107,87,'2022-11-29 00:00:00','M87','Scalp Vein Set','Inbound','To main stock',29,0,0,0,40,69,0,0,0,'',''),(108,88,'2022-11-29 00:00:00','M88','Surgical Gloves (Surgicare) 6 1/2 ','Add','To main stock',0,0,0,0,70,70,0,0,0,'',''),(109,89,'2022-11-29 00:00:00','M89','Dispo needle 26 x 1 1/2','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(110,90,'2022-11-29 00:00:00','M90','Cannula Fixator 4.5 cm x 6 cm','Add','To main stock',0,0,0,0,89,89,0,0,0,'',''),(111,91,'2022-11-29 00:00:00','M91','Vasofix IV Cannula 22 Gx1','Add','To main stock',0,0,0,0,20,20,0,0,0,'',''),(112,91,'2022-11-29 00:00:00','M91','Vasofix IV Cannula 22 Gx1','Inbound','To main stock',20,0,0,0,4,24,0,0,0,'',''),(113,91,'2022-11-29 00:00:00','M91','Vasofix IV Cannula 22 Gx1','Inbound','To main stock',24,0,0,0,4,28,0,0,0,'',''),(114,92,'2022-11-29 00:00:00','M92','Urine collection Bag','Add','To main stock',0,0,0,0,5,5,0,0,0,'',''),(115,93,'2022-11-29 00:00:00','M93','Inj. RL (Compound Sodium Lactate)','Add','To main stock',0,0,0,0,7,7,0,0,0,'',''),(116,94,'2022-11-29 00:00:00','M94','Inj. DNS','Add','To main stock',0,0,0,0,2,2,0,0,0,'',''),(117,95,'2022-11-29 00:00:00','M95','Inj. N S 500ml','Add','To main stock',0,0,0,0,4,4,0,0,0,'',''),(118,93,'2022-11-29 00:00:00','M93','Inj. RL (Compound Sodium Lactate)','Inbound','To main stock',7,0,0,0,3,10,0,0,0,'',''),(119,93,'2022-11-29 00:00:00','M93','Inj. RL (Compound Sodium Lactate)','Inbound','To main stock',10,0,0,0,22,32,0,0,0,'',''),(120,96,'2022-11-29 00:00:00','M96','Ryle\'s Tube ','Add','To main stock',0,0,0,0,4,4,0,0,0,'',''),(121,97,'2022-11-29 00:00:00','M97','Foley Catheter 16 ','Add','To main stock',0,0,0,0,10,10,0,0,0,'',''),(122,98,'2022-11-29 00:00:00','M98','Foley Catheter 14 ','Add','To main stock',0,0,0,0,3,3,0,0,0,'',''),(123,99,'2022-11-29 00:00:00','M99','Foley Catheter 20','Add','To main stock',0,0,0,0,2,2,0,0,0,'',''),(124,100,'2022-11-29 00:00:00','M100','Foley Catheter 14 FG','Add','To main stock',0,0,0,0,2,2,0,0,0,'',''),(125,101,'2022-11-29 00:00:00','M101','Foley Catheter 16 FG','Add','To main stock',0,0,0,0,1,1,0,0,0,'',''),(126,102,'2022-11-29 00:00:00','M102','Nel Cath 14 FG','Add','To main stock',0,0,0,0,31,31,0,0,0,'',''),(127,103,'2022-11-29 00:00:00','M103','Nel Cath FG 10','Add','To main stock',0,0,0,0,2,2,0,0,0,'',''),(128,45,'2022-11-29 00:00:00','M45','Roller Bandage 10cm X 3M','Transfer','Main to Sub',29,0,0,0,9,20,9,0,0,'',''),(129,45,'2022-11-29 00:00:00','M45','Roller Bandage 10cm X 3M','Transfer','Sub to A Kit',20,9,0,0,9,20,0,9,0,'',''),(130,45,'2022-12-03 00:00:00','M45','Roller Bandage 10cm X 3M','Transfer','Main to Sub',20,0,9,0,10,10,10,9,0,'',''),(131,45,'2022-12-03 00:00:00','M45','Roller Bandage 10cm X 3M','Transfer','Sub to A Kit',10,10,9,0,10,10,0,19,0,'',''),(132,95,'2022-12-03 00:00:00','M95','Inj. N S 500ml','Transfer','Main to Sub',4,0,0,0,4,0,4,0,0,'',''),(133,95,'2022-12-03 00:00:00','M95','Inj. N S 500ml','Transfer','Sub to A Kit',0,4,0,0,4,0,0,4,0,'',''),(134,104,'2022-12-03 00:00:00','M104','Tab Syndopa 110','Add','To main stock',0,0,0,0,390,390,0,0,0,'',''),(135,104,'2022-12-03 00:00:00','M104','Tab Syndopa 110','Inbound','To main stock',390,0,0,0,60,450,0,0,0,'',''),(136,14,'2022-12-03 00:00:00','M14','Tab Oxcarbazepine 150mg','Inbound','To main stock',320,0,0,0,500,820,0,0,0,'',''),(137,15,'2022-12-03 00:00:00','M15','Tab Ropinirole 2mg','Inbound','To main stock',190,0,0,0,500,690,0,0,0,'',''),(138,105,'2022-12-03 00:00:00','M105','Tab WARF-2','Add','To main stock',0,0,0,0,300,300,0,0,0,'',''),(139,106,'2022-12-03 00:00:00','M106','Tam Amantrel','Add','To main stock',0,0,0,0,150,150,0,0,0,'',''),(140,107,'2022-12-03 00:00:00','M107','Tab Lanoxin 0.25 mg','Add','To main stock',0,0,0,0,250,250,0,0,0,'',''),(141,108,'2022-12-03 00:00:00','M108','Tab Clonidime 100mg','Add','To main stock',0,0,0,0,660,660,0,0,0,'',''),(142,109,'2022-12-03 00:00:00','M109','Tab Cardiset-6.25','Add','To main stock',0,0,0,0,220,220,0,0,0,'',''),(143,110,'2022-12-03 00:00:00','M110','Sterile Gloves (Skintac) 7.5','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(144,110,'2022-12-03 00:00:00','M110','Sterile Gloves (Skintac) 7.5','Transfer','Main to Sub',50,0,0,0,50,0,50,0,0,'',''),(145,110,'2022-12-03 00:00:00','M110','Sterile Gloves (Skintac) 7.5','Transfer','Sub to A Kit',0,50,0,0,50,0,0,50,0,'',''),(146,111,'2022-12-03 00:00:00','M111','Tab Cinaloc T','Add','To main stock',0,0,0,0,220,220,0,0,0,'',''),(147,112,'2022-12-03 00:00:00','M112','Tab Becotab NF','Add','To main stock',0,0,0,0,550,550,0,0,0,'',''),(148,92,'2022-12-03 00:00:00','M92','Urine collection Bag','Inbound','To main stock',5,0,0,0,25,30,0,0,0,'',''),(149,49,'2022-12-03 00:00:00','M49','Disposable Syringe 20ml (Dispovan)','Inbound','To main stock',10,0,0,0,25,35,0,0,0,'',''),(150,113,'2022-12-03 00:00:00','M113','Tab Metron 400mg ','Add','To main stock',0,0,0,0,900,900,0,0,0,'',''),(151,114,'2022-12-03 00:00:00','M114','Tab De-cal','Add','To main stock',0,0,0,0,330,330,0,0,0,'',''),(152,115,'2022-12-03 00:00:00','M115','Tab Phensedyl LM ','Add','To main stock',0,0,0,0,220,220,0,0,0,'',''),(153,116,'2022-12-03 00:00:00','M116','Adhessive Tape 5.0 X 9.1 M (Paper Plaster)','Add','To main stock',0,0,0,0,12,12,0,0,0,'',''),(154,117,'2022-12-03 00:00:00','M117','Sodium Phosphate Enema ','Add','To main stock',0,0,0,0,20,20,0,0,0,'',''),(155,95,'2022-12-03 00:00:00','M95','Inj. N S 500ml','Inbound','To main stock',0,0,4,0,10,10,0,4,0,'',''),(156,94,'2022-12-03 00:00:00','M94','Inj. DNS','Inbound','To main stock',2,0,0,0,10,12,0,0,0,'',''),(157,2,'2022-12-08 00:00:00','M2','Tab Hydroxychloroquine 200 mg','Transfer','Main to Sub',225,0,0,0,225,0,225,0,0,'',''),(158,2,'2022-12-08 00:00:00','M2','Tab Hydroxychloroquine 200 mg','Transfer','Sub to A Kit',0,225,0,0,225,0,0,225,0,'',''),(159,25,'2022-12-08 00:00:00','M25','Tab Metformin 500mg +Glimepiride 2mg','Transfer','Main to Sub',90,0,0,0,60,30,60,0,0,'',''),(160,25,'2022-12-09 00:00:00','M25','Tab Metformin 500mg +Glimepiride 2mg','Transfer','Sub to OP',30,60,0,0,60,30,0,0,0,'57/2021','KAUSALYA'),(161,71,'2022-12-09 00:00:00','M71','Tab Amlodipine 5mg','Transfer','Main to Sub',140,0,0,0,140,0,140,0,0,'',''),(162,71,'2022-12-09 00:00:00','M71','Tab Amlodipine 5mg','Transfer','Sub to A Kit',0,140,0,0,60,0,80,60,0,'',''),(163,118,'2022-12-13 00:00:00','M118','Sterile Gloves (surgical) 6.5','Add','To main stock',0,0,0,0,100,100,0,0,0,'',''),(164,119,'2022-12-13 00:00:00','M119','Roller Bandage 7.5cm X 3M','Add','To main stock',0,0,0,0,40,40,0,0,0,'',''),(165,45,'2022-12-13 00:00:00','M45','Roller Bandage 10cm X 3M','Transfer','Main to Sub',10,0,19,0,10,0,10,19,0,'',''),(166,45,'2022-12-13 00:00:00','M45','Roller Bandage 10cm X 3M','Transfer','Sub to A Kit',0,10,19,0,10,0,0,29,0,'',''),(167,117,'2022-12-13 00:00:00','M117','Sodium Phosphate Enema ','Transfer','Main to Sub',20,0,0,0,5,15,5,0,0,'',''),(168,117,'2022-12-13 00:00:00','M117','Sodium Phosphate Enema ','Transfer','Sub to A Kit',15,5,0,0,5,15,0,5,0,'',''),(169,82,'2022-12-14 00:00:00','M82','Povidone Iodine Solution 500ml','Transfer','Main to Sub',2,0,0,0,1,1,1,0,0,'',''),(170,82,'2022-12-14 00:00:00','M82','Povidone Iodine Solution 500ml','Transfer','Sub to A Kit',1,1,0,0,1,1,0,1,0,'',''),(171,118,'2022-12-14 00:00:00','M118','Sterile Gloves (surgical) 6.5','Transfer','Main to Sub',100,0,0,0,50,50,50,0,0,'',''),(172,118,'2022-12-14 00:00:00','M118','Sterile Gloves (surgical) 6.5','Transfer','Sub to A Kit',50,50,0,0,50,50,0,50,0,'',''),(173,6,'2022-12-14 00:00:00','M6','Tab Torsemide 10 mg ','Transfer','Main to Sub',36,0,0,0,36,0,36,0,0,'',''),(174,6,'2022-12-14 00:00:00','M6','Tab Torsemide 10 mg ','Transfer','Sub to A Kit',0,36,0,0,36,0,0,36,0,'',''),(175,68,'2022-12-14 00:00:00','M68','Tab Prazopress XL 5mg','Transfer','Main to Sub',60,0,0,0,60,0,60,0,0,'',''),(176,68,'2022-12-14 00:00:00','M68','Tab Prazopress XL 5mg','Transfer','Sub to A Kit',0,60,0,0,60,0,0,60,0,'',''),(177,34,'2022-12-14 00:00:00','M34','Water for injection 10 ml','Transfer','Main to Sub',70,0,0,0,20,50,20,0,0,'',''),(178,34,'2022-12-14 00:00:00','M34','Water for injection 10 ml','Transfer','Sub to A Kit',50,20,0,0,20,50,0,20,0,'',''),(179,15,'2022-12-15 00:00:00','M15','Tab Ropinirole 2mg','Transfer','Main to Sub',690,0,0,0,90,600,90,0,0,'',''),(180,15,'2022-12-15 00:00:00','M15','Tab Ropinirole 2mg','Transfer','Sub to A Kit',600,90,0,0,90,600,0,90,0,'',''),(181,15,'2022-12-15 00:00:00','M15','Tab Ropinirole 2mg','Transfer','A Kit to OP',600,0,90,0,90,600,0,0,0,'92/2015','SATHI'),(182,106,'2022-12-15 00:00:00','M106','Tam Amantrel','Transfer','Main to Sub',150,0,0,0,60,90,60,0,0,'',''),(183,106,'2022-12-15 00:00:00','M106','Tam Amantrel','Transfer','Sub to A Kit',90,60,0,0,60,90,0,60,0,'',''),(184,106,'2022-12-15 00:00:00','M106','Tam Amantrel','Transfer','A Kit to OP',90,0,60,0,60,90,0,0,0,'92/2015','SATHI'),(185,104,'2022-12-15 00:00:00','M104','Tab Syndopa 110','Transfer','Main to Sub',450,0,0,0,90,360,90,0,0,'',''),(186,104,'2022-12-15 00:00:00','M104','Tab Syndopa 110','Transfer','Sub to A Kit',360,90,0,0,90,360,0,90,0,'',''),(187,104,'2022-12-15 00:00:00','M104','Tab Syndopa 110','Transfer','A Kit to OP',360,0,90,0,90,360,0,0,0,'92/2015','SATHI'),(188,54,'2022-12-15 00:00:00','M54','Tab Pacitane 2mg','Transfer','Main to Sub',300,0,0,0,90,210,90,0,0,'',''),(189,54,'2022-12-15 00:00:00','M54','Tab Pacitane 2mg','Transfer','Sub to A Kit',210,90,0,0,90,210,0,90,0,'',''),(190,54,'2022-12-15 00:00:00','M54','Tab Pacitane 2mg','Transfer','A Kit to OP',210,0,90,0,90,210,0,0,0,'92/2015','SATHI'),(191,14,'2022-12-15 00:00:00','M14','Tab Oxcarbazepine 150mg','Transfer','Main to Sub',820,0,0,0,60,760,60,0,0,'',''),(192,14,'2022-12-15 00:00:00','M14','Tab Oxcarbazepine 150mg','Transfer','Sub to A Kit',760,60,0,0,60,760,0,60,0,'',''),(193,14,'2022-12-15 00:00:00','M14','Tab Oxcarbazepine 150mg','Transfer','A Kit to OP',760,0,60,0,60,760,0,0,0,'25/2017','MOIDHEENKUTTY'),(194,67,'2022-12-16 00:00:00','M67','Tab Cipcal 500','Transfer','Main to Sub',195,0,0,0,30,165,30,0,0,'',''),(195,67,'2022-12-16 00:00:00','M67','Tab Cipcal 500','Transfer','Sub to A Kit',165,30,0,0,30,165,0,30,0,'',''),(196,67,'2022-12-16 00:00:00','M67','Tab Cipcal 500','Transfer','A Kit to OP',165,0,30,0,30,165,0,0,0,'6/2022','KADEEJA'),(197,14,'2022-12-21 00:00:00','M14','Tab Oxcarbazepine 150mg','Transfer','Main to Sub',760,0,0,0,60,700,60,0,0,'',''),(198,14,'2022-12-21 00:00:00','M14','Tab Oxcarbazepine 150mg','Transfer','Sub to A Kit',700,60,0,0,60,700,0,60,0,'',''),(199,104,'2022-12-21 00:00:00','M104','Tab Syndopa 110','Transfer','Main to Sub',360,0,0,0,37,323,37,0,0,'',''),(200,104,'2022-12-21 00:00:00','M104','Tab Syndopa 110','Transfer','Sub to A Kit',323,37,0,0,37,323,0,37,0,'',''),(201,15,'2022-12-21 00:00:00','M15','Tab Ropinirole 2mg','Transfer','Main to Sub',600,0,0,0,90,510,90,0,0,'',''),(202,15,'2022-12-21 00:00:00','M15','Tab Ropinirole 2mg','Transfer','Sub to A Kit',510,90,0,0,90,510,0,90,0,'',''),(203,54,'2022-12-21 00:00:00','M54','Tab Pacitane 2mg','Transfer','Main to Sub',210,0,0,0,90,120,90,0,0,'',''),(204,54,'2022-12-21 00:00:00','M54','Tab Pacitane 2mg','Transfer','Sub to A Kit',120,90,0,0,90,120,0,90,0,'',''),(205,106,'2022-12-21 00:00:00','M106','Tam Amantrel','Transfer','Main to Sub',90,0,0,0,60,30,60,0,0,'',''),(206,106,'2022-12-21 00:00:00','M106','Tam Amantrel','Transfer','Sub to A Kit',30,60,0,0,60,30,0,60,0,'',''),(207,114,'2022-12-24 00:00:00','M114','Tab De-cal','Transfer','Main to Sub',330,0,0,0,120,210,120,0,0,'',''),(208,114,'2022-12-24 00:00:00','M114','Tab De-cal','Transfer','Sub to A Kit',210,120,0,0,120,210,0,120,0,'',''),(209,89,'2022-12-24 00:00:00','M89','Dispo needle 26 x 1 1/2','Transfer','Main to Sub',50,0,0,0,10,40,10,0,0,'',''),(210,89,'2022-12-24 00:00:00','M89','Dispo needle 26 x 1 1/2','Transfer','Sub to A Kit',40,10,0,0,10,40,0,10,0,'',''),(211,119,'2022-12-24 00:00:00','M119','Roller Bandage 7.5cm X 3M','Transfer','Main to Sub',40,0,0,0,10,30,10,0,0,'',''),(212,119,'2022-12-24 00:00:00','M119','Roller Bandage 7.5cm X 3M','Transfer','Sub to A Kit',30,10,0,0,10,30,0,10,0,'',''),(213,112,'2022-12-24 00:00:00','M112','Tab Becotab NF','Transfer','Main to Sub',550,0,0,0,100,450,100,0,0,'',''),(214,112,'2022-12-24 00:00:00','M112','Tab Becotab NF','Transfer','Sub to A Kit',450,100,0,0,100,450,0,100,0,'',''),(215,118,'2022-12-24 00:00:00','M118','Sterile Gloves (surgical) 6.5','Transfer','Main to Sub',50,0,50,0,14,36,14,50,0,'',''),(216,118,'2022-12-24 00:00:00','M118','Sterile Gloves (surgical) 6.5','Transfer','Sub to A Kit',36,14,50,0,14,36,0,64,0,'',''),(217,113,'2022-12-26 00:00:00','M113','Tab Metron 400mg ','Transfer','Main to Sub',900,0,0,0,135,765,135,0,0,'',''),(218,113,'2022-12-26 00:00:00','M113','Tab Metron 400mg ','Transfer','Sub to A Kit',765,135,0,0,135,765,0,135,0,'',''),(219,43,'2022-12-26 00:00:00','M43','Liquid Paraffin','Transfer','Main to Sub',14,0,0,0,4,10,4,0,0,'',''),(220,43,'2022-12-26 00:00:00','M43','Liquid Paraffin','Transfer','Sub to A Kit',10,4,0,0,3,10,1,3,0,'',''),(221,43,'2022-12-26 00:00:00','M43','Liquid Paraffin','Transfer','Sub to OP',10,1,3,0,1,10,0,3,0,'86/2022','Neeli'),(222,65,'2022-12-28 00:00:00','M65','Tab Torsemide 40mg (TOR 40)','Transfer','Main to Sub',130,0,0,0,60,70,60,0,0,'',''),(223,65,'2022-12-28 00:00:00','M65','Tab Torsemide 40mg (TOR 40)','Transfer','Sub to OP',70,60,0,0,60,70,0,0,0,'86/2019','KHASIM'),(224,3,'2022-12-28 00:00:00','M3','Tab Bisacodyl','Transfer','Main to Sub',360,0,0,0,30,330,30,0,0,'',''),(225,3,'2022-12-28 00:00:00','M3','Tab Bisacodyl','Transfer','Sub to OP',330,30,0,0,30,330,0,0,0,'86/2019','KHASIM'),(226,114,'2022-12-28 00:00:00','M114','Tab De-cal','Transfer','Main to Sub',210,0,120,0,60,150,60,120,0,'',''),(227,114,'2022-12-28 00:00:00','M114','Tab De-cal','Transfer','Sub to OP',150,60,120,0,60,150,0,120,0,'86/2019','KHASIM'),(228,25,'2022-12-29 00:00:00','M25','Tab Metformin 500mg +Glimepiride 2mg','Transfer','Main to Sub',30,0,0,0,30,0,30,0,0,'',''),(229,25,'2022-12-29 00:00:00','M25','Tab Metformin 500mg +Glimepiride 2mg','Transfer','Sub to OP',0,30,0,0,30,0,0,0,0,'57/2021','KAUSALYA'),(230,77,'2022-12-29 00:00:00','M77','Tab Cilinitab 20( Cilnidipine)','Transfer','Main to Sub',50,0,0,0,30,20,30,0,0,'',''),(231,77,'2022-12-29 00:00:00','M77','Tab Cilinitab 20( Cilnidipine)','Transfer','Sub to OP',20,30,0,0,30,20,0,0,0,'57/2021','KAUSALYA'),(232,68,'2022-12-29 00:00:00','M68','Tab Prazopress XL 5mg','Transfer','A Kit to OP',0,0,60,0,30,0,0,30,0,'86/2019','KHASIM'),(233,10,'2022-12-30 00:00:00','M10','Tab Telmisartan 40mg','Inbound','To main stock',450,0,0,0,128,578,0,0,0,'',''),(234,10,'2022-12-30 00:00:00','M10','Tab Telmisartan 40mg','Transfer','Main to Sub',578,0,0,0,128,450,128,0,0,'',''),(235,10,'2022-12-30 00:00:00','M10','Tab Telmisartan 40mg','Transfer','Sub to A Kit',450,128,0,0,128,450,0,128,0,'',''),(236,20,'2022-12-31 00:00:00','M20','Tab Levetiracetam (Levipil) 500 mg','Transfer','Main to Sub',100,0,0,0,30,70,30,0,0,'',''),(237,20,'2022-12-31 00:00:00','M20','Tab Levetiracetam (Levipil) 500 mg','Transfer','Sub to OP',70,30,0,0,30,70,0,0,0,'157/2017','SINDHU'),(238,19,'2022-12-31 00:00:00','M19','Tab Carbamazepine CR 200mg','Transfer','Main to Sub',120,0,0,0,60,60,60,0,0,'',''),(239,19,'2022-12-31 00:00:00','M19','Tab Carbamazepine CR 200mg','Transfer','Sub to OP',60,60,0,0,60,60,0,0,0,'115/2022','Nithinkumar'),(240,10,'2022-12-31 00:00:00','M10','Tab Telmisartan 40mg','Inbound','To main stock',450,0,128,0,17,467,0,128,0,'',''),(241,120,'2022-12-31 00:00:00','M120','Telwave 40 ( telmisarton)','Add','To main stock',0,0,0,0,17,17,0,0,0,'',''),(242,120,'2022-12-31 00:00:00','M120','Telwave 40 ( telmisarton)','Transfer','Main to Sub',17,0,0,0,17,0,17,0,0,'',''),(243,120,'2022-12-31 00:00:00','M120','Telwave 40 ( telmisarton)','Transfer','Sub to A Kit',0,17,0,0,17,0,0,17,0,'',''),(244,121,'2022-12-31 00:00:00','M121','NICARDIA 20 MG','Add','To main stock',0,0,0,0,46,46,0,0,0,'',''),(245,121,'2022-12-31 00:00:00','M121','NICARDIA 20 MG','Transfer','Main to Sub',46,0,0,0,46,0,46,0,0,'',''),(246,121,'2022-12-31 00:00:00','M121','NICARDIA 20 MG','Transfer','Sub to A Kit',0,46,0,0,46,0,0,46,0,'',''),(247,121,'2022-12-31 00:00:00','M121','NICARDIA 20 MG','Inbound','To main stock',0,0,46,0,30,30,0,46,0,'',''),(248,121,'2022-12-31 00:00:00','M121','NICARDIA 20 MG','Transfer','Main to Sub',30,0,46,0,30,0,30,46,0,'',''),(249,121,'2022-12-31 00:00:00','M121','NICARDIA 20 MG','Transfer','Sub to A Kit',0,30,46,0,30,0,0,76,0,'',''),(250,121,'2022-12-31 00:00:00','M121','NICARDIA 20 MG','Inbound','To main stock',0,0,76,0,13,13,0,76,0,'',''),(251,121,'2022-12-31 00:00:00','M121','NICARDIA 20 MG','Transfer','Main to Sub',13,0,76,0,13,0,13,76,0,'',''),(252,121,'2022-12-31 00:00:00','M121','NICARDIA 20 MG','Transfer','Sub to A Kit',0,13,76,0,13,0,0,89,0,'',''),(253,121,'2022-12-31 00:00:00','M121','NICARDIA 20 MG','Inbound','To main stock',0,0,89,0,27,27,0,89,0,'',''),(254,121,'2022-12-31 00:00:00','M121','NICARDIA 20 MG','Transfer','Main to Sub',27,0,89,0,27,0,27,89,0,'',''),(255,121,'2022-12-31 00:00:00','M121','NICARDIA 20 MG','Transfer','Sub to A Kit',0,27,89,0,27,0,0,116,0,'',''),(256,121,'2022-12-31 00:00:00','M121','NICARDIA 20 MG','Inbound','To main stock',0,0,116,0,68,68,0,116,0,'',''),(257,121,'2022-12-31 00:00:00','M121','NICARDIA 20 MG','Transfer','Main to Sub',68,0,116,0,68,0,68,116,0,'',''),(258,121,'2022-12-31 00:00:00','M121','NICARDIA 20 MG','Transfer','Sub to A Kit',0,68,116,0,68,0,0,184,0,'',''),(259,122,'2022-12-31 00:00:00','M122','MUSINAC 600 MG','Add','To main stock',0,0,0,0,18,18,0,0,0,'',''),(260,122,'2022-12-31 00:00:00','M122','MUSINAC 600 MG','Transfer','Main to Sub',18,0,0,0,18,0,18,0,0,'',''),(261,122,'2022-12-31 00:00:00','M122','MUSINAC 600 MG','Transfer','Sub to A Kit',0,18,0,0,18,0,0,18,0,'',''),(262,32,'2023-01-03 00:00:00','M32','Tab Fluconazole 150mg','Inbound','To main stock',45,0,0,0,6,51,0,0,0,'',''),(263,32,'2023-01-03 00:00:00','M32','Tab Fluconazole 150mg','Transfer','Main to Sub',51,0,0,0,6,45,6,0,0,'',''),(264,32,'2023-01-03 00:00:00','M32','Tab Fluconazole 150mg','Transfer','Sub to A Kit',45,6,0,0,6,45,0,6,0,'',''),(265,67,'2023-01-03 00:00:00','M67','Tab Cipcal 500','Inbound','To main stock',165,0,0,0,30,195,0,0,0,'',''),(266,67,'2023-01-03 00:00:00','M67','Tab Cipcal 500','Transfer','Main to Sub',195,0,0,0,30,165,30,0,0,'',''),(267,67,'2023-01-03 00:00:00','M67','Tab Cipcal 500','Transfer','Sub to A Kit',165,30,0,0,30,165,0,30,0,'',''),(268,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Add','To main stock',0,0,0,0,17,17,0,0,0,'',''),(269,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Transfer','Main to Sub',17,0,0,0,17,0,17,0,0,'',''),(270,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Transfer','Sub to A Kit',0,17,0,0,17,0,0,17,0,'',''),(271,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Inbound','To main stock',0,0,17,0,15,15,0,17,0,'',''),(272,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Transfer','Main to Sub',15,0,17,0,15,0,15,17,0,'',''),(273,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Transfer','Sub to A Kit',0,15,17,0,15,0,0,32,0,'',''),(274,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Inbound','To main stock',0,0,32,0,13,13,0,32,0,'',''),(275,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Transfer','Main to Sub',13,0,32,0,13,0,13,32,0,'',''),(276,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Transfer','Sub to A Kit',0,13,32,0,13,0,0,45,0,'',''),(277,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Inbound','To main stock',0,0,45,0,15,15,0,45,0,'',''),(278,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Transfer','Main to Sub',15,0,45,0,15,0,15,45,0,'',''),(279,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Transfer','Sub to A Kit',0,15,45,0,15,0,0,60,0,'',''),(280,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Inbound','To main stock',0,0,60,0,20,20,0,60,0,'',''),(281,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Transfer','Main to Sub',20,0,60,0,20,0,20,60,0,'',''),(282,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Transfer','Sub to A Kit',0,20,60,0,20,0,0,80,0,'',''),(283,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Inbound','To main stock',0,0,80,0,9,9,0,80,0,'',''),(284,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Transfer','Main to Sub',9,0,80,0,9,0,9,80,0,'',''),(285,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Transfer','Sub to A Kit',0,9,80,0,9,0,0,89,0,'',''),(286,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Inbound','To main stock',0,0,89,0,3,3,0,89,0,'',''),(287,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Transfer','Main to Sub',3,0,89,0,3,0,3,89,0,'',''),(288,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Transfer','Sub to A Kit',0,3,89,0,3,0,0,92,0,'',''),(289,123,'2023-01-03 00:00:00','M123','FRUCIX 40 - FRUSEMIDE 40','Inbound','To main stock',0,0,92,0,19,19,0,92,0,'',''),(290,124,'2023-01-03 00:00:00','M124',' FRUSEMIDE 100 MG -FRUSENEX 100','Add','To main stock',0,0,0,0,19,19,0,0,0,'',''),(291,124,'2023-01-03 00:00:00','M124',' FRUSEMIDE 100 MG -FRUSENEX 100','Transfer','Main to Sub',19,0,0,0,19,0,19,0,0,'',''),(292,124,'2023-01-03 00:00:00','M124',' FRUSEMIDE 100 MG -FRUSENEX 100','Transfer','Sub to A Kit',0,19,0,0,19,0,0,19,0,'',''),(293,27,'2023-01-03 00:00:00','M27','Tab Spironolactone 50mg(Spiraldo)','Inbound','To main stock',300,0,0,0,30,330,0,0,0,'',''),(294,27,'2023-01-03 00:00:00','M27','Tab Spironolactone 50mg(Spiraldo)','Transfer','Main to Sub',330,0,0,0,30,300,30,0,0,'',''),(295,27,'2023-01-03 00:00:00','M27','Tab Spironolactone 50mg(Spiraldo)','Transfer','Sub to A Kit',300,30,0,0,30,300,0,30,0,'',''),(296,125,'2023-01-03 00:00:00','M125','LASILACTONE 50','Add','To main stock',0,0,0,0,20,20,0,0,0,'',''),(297,125,'2023-01-03 00:00:00','M125','LASILACTONE 50','Transfer','Main to Sub',20,0,0,0,20,0,20,0,0,'',''),(298,125,'2023-01-03 00:00:00','M125','LASILACTONE 50','Transfer','Sub to A Kit',0,20,0,0,20,0,0,20,0,'',''),(299,126,'2023-01-03 00:00:00','M126','ONCLANSETRON 4 MG - EMESET 4','Add','To main stock',0,0,0,0,100,100,0,0,0,'',''),(300,126,'2023-01-03 00:00:00','M126','ONCLANSETRON 4 MG - EMESET 4','Transfer','Main to Sub',100,0,0,0,100,0,100,0,0,'',''),(301,126,'2023-01-03 00:00:00','M126','ONCLANSETRON 4 MG - EMESET 4','Transfer','Sub to A Kit',0,100,0,0,100,0,0,100,0,'',''),(302,118,'2023-01-05 00:00:00','M118','Sterile Gloves (surgical) 6.5','Inbound','To main stock',36,0,64,0,50,86,0,64,0,'',''),(303,127,'2023-01-05 00:00:00','M127','SURGICAL GLOVE(STERILE) 7','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(304,46,'2023-01-05 00:00:00','M46','Cotton Wool Absorbant 400gm','Inbound','To main stock',1,0,0,0,5,6,0,0,0,'',''),(305,126,'2023-01-09 00:00:00','M126','ONCLANSETRON 4 MG - EMESET 4','Inbound','To main stock',0,0,100,0,9,9,0,100,0,'',''),(306,126,'2023-01-09 00:00:00','M126','ONCLANSETRON 4 MG - EMESET 4','Transfer','Main to Sub',9,0,100,0,9,0,9,100,0,'',''),(307,126,'2023-01-09 00:00:00','M126','ONCLANSETRON 4 MG - EMESET 4','Transfer','Sub to A Kit',0,9,100,0,9,0,0,109,0,'',''),(308,128,'2023-01-09 00:00:00','M128','ONVIN 4MD-ONDANSETRON ORALLY DISINTEGRATING TAB','Add','To main stock',0,0,0,0,20,20,0,0,0,'',''),(309,128,'2023-01-09 00:00:00','M128','ONVIN 4MD-ONDANSETRON ORALLY DISINTEGRATING TAB','Transfer','Main to Sub',20,0,0,0,20,0,20,0,0,'',''),(310,128,'2023-01-09 00:00:00','M128','ONVIN 4MD-ONDANSETRON ORALLY DISINTEGRATING TAB','Transfer','Sub to A Kit',0,20,0,0,20,0,0,20,0,'',''),(311,112,'2023-01-09 00:00:00','M112','Tab Becotab NF','Inbound','To main stock',450,0,100,0,100,550,0,100,0,'',''),(312,112,'2023-01-09 00:00:00','M112','Tab Becotab NF','Transfer','Main to Sub',550,0,100,0,100,450,100,100,0,'',''),(313,112,'2023-01-09 00:00:00','M112','Tab Becotab NF','Transfer','Sub to A Kit',450,100,100,0,100,450,0,200,0,'',''),(314,129,'2023-01-09 00:00:00','M129','CINALOC 10 -CILNIDIPINE 10','Add','To main stock',0,0,0,0,110,110,0,0,0,'',''),(315,129,'2023-01-09 00:00:00','M129','CINALOC 10 -CILNIDIPINE 10','Transfer','Main to Sub',110,0,0,0,110,0,110,0,0,'',''),(316,129,'2023-01-09 00:00:00','M129','CINALOC 10 -CILNIDIPINE 10','Transfer','Sub to A Kit',0,110,0,0,110,0,0,110,0,'',''),(317,130,'2023-01-09 00:00:00','M130','Tab Tramadol 50 mg- TRAMAZAC 50','Add','To main stock',0,0,0,0,114,114,0,0,0,'',''),(318,130,'2023-01-09 00:00:00','M130','Tab Tramadol 50 mg- TRAMAZAC 50','Transfer','Main to Sub',114,0,0,0,114,0,114,0,0,'',''),(319,130,'2023-01-09 00:00:00','M130','Tab Tramadol 50 mg- TRAMAZAC 50','Transfer','Sub to A Kit',0,114,0,0,114,0,0,114,0,'',''),(320,131,'2023-01-09 00:00:00','M131','TRAMATAZ- TRAMADOL 50','Add','To main stock',0,0,0,0,30,30,0,0,0,'',''),(321,131,'2023-01-09 00:00:00','M131','TRAMATAZ- TRAMADOL 50','Transfer','Main to Sub',30,0,0,0,30,0,30,0,0,'',''),(322,131,'2023-01-09 00:00:00','M131','TRAMATAZ- TRAMADOL 50','Transfer','Sub to A Kit',0,30,0,0,30,0,0,30,0,'',''),(323,132,'2023-01-09 00:00:00','M132','ULTRASET ','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(324,132,'2023-01-09 00:00:00','M132','ULTRASET ','Transfer','Main to Sub',50,0,0,0,50,0,50,0,0,'',''),(325,132,'2023-01-09 00:00:00','M132','ULTRASET ','Transfer','Sub to A Kit',0,50,0,0,50,0,0,50,0,'',''),(326,133,'2023-01-09 00:00:00','M133','BACLOFEN 5 MG','Add','To main stock',0,0,0,0,8,8,0,0,0,'',''),(327,133,'2023-01-09 00:00:00','M133','BACLOFEN 5 MG','Transfer','Main to Sub',8,0,0,0,8,0,8,0,0,'',''),(328,133,'2023-01-09 00:00:00','M133','BACLOFEN 5 MG','Transfer','Sub to A Kit',0,8,0,0,8,0,0,8,0,'',''),(329,134,'2023-01-09 00:00:00','M134','CALPOL T ','Add','To main stock',0,0,0,0,77,77,0,0,0,'',''),(330,134,'2023-01-09 00:00:00','M134','CALPOL T ','Transfer','Main to Sub',77,0,0,0,77,0,77,0,0,'',''),(331,134,'2023-01-09 00:00:00','M134','CALPOL T ','Transfer','Sub to A Kit',0,77,0,0,77,0,0,77,0,'',''),(332,135,'2023-01-09 00:00:00','M135','MELOXICAM 15MG','Add','To main stock',0,0,0,0,30,30,0,0,0,'',''),(333,135,'2023-01-09 00:00:00','M135','MELOXICAM 15MG','Transfer','Main to Sub',30,0,0,0,30,0,30,0,0,'',''),(334,135,'2023-01-09 00:00:00','M135','MELOXICAM 15MG','Transfer','Sub to A Kit',0,30,0,0,30,0,0,30,0,'',''),(335,71,'2023-01-09 00:00:00','M71','Tab Amlodipine 5mg','Inbound','To main stock',0,80,60,0,50,50,80,60,0,'',''),(336,71,'2023-01-09 00:00:00','M71','Tab Amlodipine 5mg','Transfer','Sub to A Kit',50,80,60,0,80,50,0,140,0,'',''),(337,136,'2023-01-09 00:00:00','M136','ATEN 50( ATENOLOL 50MG)','Add','To main stock',0,0,0,0,51,51,0,0,0,'',''),(338,136,'2023-01-09 00:00:00','M136','ATEN 50( ATENOLOL 50MG)','Transfer','Main to Sub',51,0,0,0,51,0,51,0,0,'',''),(339,136,'2023-01-09 00:00:00','M136','ATEN 50( ATENOLOL 50MG)','Transfer','Sub to A Kit',0,51,0,0,51,0,0,51,0,'',''),(340,137,'2023-01-10 00:00:00','M137','metroninazole 400mg-metrogyl 400mg','Add','To main stock',0,0,0,0,15,15,0,0,0,'',''),(341,137,'2023-01-10 00:00:00','M137','metroninazole 400mg-metrogyl 400mg','Transfer','Main to Sub',15,0,0,0,15,0,15,0,0,'',''),(342,137,'2023-01-10 00:00:00','M137','metroninazole 400mg-metrogyl 400mg','Transfer','Sub to A Kit',0,15,0,0,15,0,0,15,0,'',''),(343,138,'2023-01-10 00:00:00','M138','PARACETAMOL 500MG- DOLIPRANE 500MG','Add','To main stock',0,0,0,0,40,40,0,0,0,'',''),(344,138,'2023-01-10 00:00:00','M138','PARACETAMOL 500MG- DOLIPRANE 500MG','Transfer','Main to Sub',40,0,0,0,40,0,40,0,0,'',''),(345,138,'2023-01-10 00:00:00','M138','PARACETAMOL 500MG- DOLIPRANE 500MG','Transfer','Sub to A Kit',0,40,0,0,40,0,0,40,0,'',''),(346,139,'2023-01-10 00:00:00','M139','HALOPERIDOL 0.25MG','Add','To main stock',0,0,0,0,10,10,0,0,0,'',''),(347,139,'2023-01-10 00:00:00','M139','HALOPERIDOL 0.25MG','Transfer','Main to Sub',10,0,0,0,10,0,10,0,0,'',''),(348,139,'2023-01-10 00:00:00','M139','HALOPERIDOL 0.25MG','Transfer','Sub to A Kit',0,10,0,0,10,0,0,10,0,'',''),(349,140,'2023-01-10 00:00:00','M140','FERROUS FUMARATE AND FOLIC ACID TAB','Add','To main stock',0,0,0,0,105,105,0,0,0,'',''),(350,140,'2023-01-10 00:00:00','M140','FERROUS FUMARATE AND FOLIC ACID TAB','Transfer','Main to Sub',105,0,0,0,105,0,105,0,0,'',''),(351,140,'2023-01-10 00:00:00','M140','FERROUS FUMARATE AND FOLIC ACID TAB','Transfer','Sub to A Kit',0,105,0,0,105,0,0,105,0,'',''),(352,140,'2023-01-10 00:00:00','M140','FERROUS FUMARATE AND FOLIC ACID TAB','Inbound','To main stock',0,0,105,0,21,21,0,105,0,'',''),(353,140,'2023-01-10 00:00:00','M140','FERROUS FUMARATE AND FOLIC ACID TAB','Transfer','Main to Sub',21,0,105,0,21,0,21,105,0,'',''),(354,140,'2023-01-10 00:00:00','M140','FERROUS FUMARATE AND FOLIC ACID TAB','Transfer','Sub to A Kit',0,21,105,0,21,0,0,126,0,'',''),(355,29,'2023-01-10 00:00:00','M29','Tab Cefixime 200mg','Inbound','To main stock',30,0,0,0,64,94,0,0,0,'',''),(356,29,'2023-01-10 00:00:00','M29','Tab Cefixime 200mg','Transfer','Main to Sub',94,0,0,0,64,30,64,0,0,'',''),(357,29,'2023-01-10 00:00:00','M29','Tab Cefixime 200mg','Transfer','Sub to A Kit',30,64,0,0,64,30,0,64,0,'',''),(358,29,'2023-01-10 00:00:00','M29','Tab Cefixime 200mg','Transfer','Sub to A Kit',30,64,0,0,64,30,0,64,0,'',''),(359,141,'2023-01-10 00:00:00','M141','TRIFIX 200 (Tab Cefixime 200mg)','Add','To main stock',0,0,0,0,6,6,0,0,0,'',''),(360,141,'2023-01-10 00:00:00','M141','TRIFIX 200 (Tab Cefixime 200mg)','Transfer','Main to Sub',6,0,0,0,6,0,6,0,0,'',''),(361,141,'2023-01-10 00:00:00','M141','TRIFIX 200 (Tab Cefixime 200mg)','Transfer','Sub to A Kit',0,6,0,0,6,0,0,6,0,'',''),(362,142,'2023-01-10 00:00:00','M142','MOXCLAV 625MG','Add','To main stock',0,0,0,0,7,7,0,0,0,'',''),(363,142,'2023-01-10 00:00:00','M142','MOXCLAV 625MG','Transfer','Main to Sub',7,0,0,0,7,0,7,0,0,'',''),(364,142,'2023-01-10 00:00:00','M142','MOXCLAV 625MG','Transfer','Sub to A Kit',0,7,0,0,7,0,0,7,0,'',''),(365,143,'2023-01-10 00:00:00','M143','AMOXCLAV 625MG','Add','To main stock',0,0,0,0,15,15,0,0,0,'',''),(366,143,'2023-01-10 00:00:00','M143','AMOXCLAV 625MG','Transfer','Main to Sub',15,0,0,0,15,0,15,0,0,'',''),(367,143,'2023-01-10 00:00:00','M143','AMOXCLAV 625MG','Transfer','Sub to A Kit',0,15,0,0,15,0,0,15,0,'',''),(368,144,'2023-01-10 00:00:00','M144','L QUIN 500','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(369,144,'2023-01-10 00:00:00','M144','L QUIN 500','Transfer','Main to Sub',50,0,0,0,50,0,50,0,0,'',''),(370,144,'2023-01-10 00:00:00','M144','L QUIN 500','Transfer','Sub to A Kit',0,50,0,0,50,0,0,50,0,'',''),(371,3,'2023-01-10 00:00:00','M3','Tab Bisacodyl','Inbound','To main stock',330,0,0,0,26,356,0,0,0,'',''),(372,3,'2023-01-10 00:00:00','M3','Tab Bisacodyl','Transfer','Main to Sub',356,0,0,0,26,330,26,0,0,'',''),(373,3,'2023-01-10 00:00:00','M3','Tab Bisacodyl','Transfer','Sub to A Kit',330,26,0,0,26,330,0,26,0,'',''),(374,145,'2023-01-10 00:00:00','M145','ALPRAX 0.25MG','Add','To main stock',0,0,0,0,29,29,0,0,0,'',''),(375,145,'2023-01-10 00:00:00','M145','ALPRAX 0.25MG','Transfer','Main to Sub',29,0,0,0,29,0,29,0,0,'',''),(376,145,'2023-01-10 00:00:00','M145','ALPRAX 0.25MG','Transfer','Sub to A Kit',0,29,0,0,29,0,0,29,0,'',''),(377,146,'2023-01-10 00:00:00','M146','ESCITALOPRAM (REXIPRA 15MG)','Add','To main stock',0,0,0,0,100,100,0,0,0,'',''),(378,146,'2023-01-10 00:00:00','M146','ESCITALOPRAM (REXIPRA 15MG)','Transfer','Main to Sub',100,0,0,0,100,0,100,0,0,'',''),(379,146,'2023-01-10 00:00:00','M146','ESCITALOPRAM (REXIPRA 15MG)','Transfer','Sub to A Kit',0,100,0,0,100,0,0,100,0,'',''),(380,147,'2023-01-10 00:00:00','M147','QUITIPIN 25MG','Add','To main stock',0,0,0,0,20,20,0,0,0,'',''),(381,147,'2023-01-10 00:00:00','M147','QUITIPIN 25MG','Transfer','Main to Sub',20,0,0,0,20,0,20,0,0,'',''),(382,147,'2023-01-10 00:00:00','M147','QUITIPIN 25MG','Transfer','Sub to A Kit',0,20,0,0,20,0,0,20,0,'',''),(383,42,'2023-01-11 00:00:00','M42','Syrup Citralka','Inbound','To main stock',21,0,0,0,3,24,0,0,0,'',''),(384,42,'2023-01-11 00:00:00','M42','Syrup Citralka','Transfer','Main to Sub',24,0,0,0,3,21,3,0,0,'',''),(385,42,'2023-01-11 00:00:00','M42','Syrup Citralka','Transfer','Sub to A Kit',21,3,0,0,3,21,0,3,0,'',''),(386,41,'2023-01-11 00:00:00','M41','Ascodex Plus Cough Syrup','Inbound','To main stock',6,0,0,0,5,11,0,0,0,'',''),(387,41,'2023-01-11 00:00:00','M41','Ascodex Plus Cough Syrup','Transfer','Main to Sub',11,0,0,0,5,6,5,0,0,'',''),(388,41,'2023-01-11 00:00:00','M41','Ascodex Plus Cough Syrup','Transfer','Sub to A Kit',6,5,0,0,5,6,0,5,0,'',''),(389,41,'2023-01-11 00:00:00','M41','Ascodex Plus Cough Syrup','Inbound','To main stock',6,0,5,0,1,7,0,5,0,'',''),(390,41,'2023-01-11 00:00:00','M41','Ascodex Plus Cough Syrup','Transfer','Main to Sub',7,0,5,0,1,6,1,5,0,'',''),(391,41,'2023-01-11 00:00:00','M41','Ascodex Plus Cough Syrup','Transfer','Sub to A Kit',6,1,5,0,1,6,0,6,0,'',''),(392,148,'2023-01-11 00:00:00','M148','dexamethazone sodium phosphate inj; dexona 4mg','Add','To main stock',0,0,0,0,6,6,0,0,0,'',''),(393,148,'2023-01-11 00:00:00','M148','dexamethazone sodium phosphate inj; dexona 4mg','Transfer','Main to Sub',6,0,0,0,6,0,6,0,0,'',''),(394,148,'2023-01-11 00:00:00','M148','dexamethazone sodium phosphate inj; dexona 4mg','Transfer','Sub to A Kit',0,6,0,0,6,0,0,6,0,'',''),(395,149,'2023-01-11 00:00:00','M149','FRUSEMIDE 10MG','Add','To main stock',0,0,0,0,25,25,0,0,0,'',''),(396,149,'2023-01-11 00:00:00','M149','FRUSEMIDE 10MG','Transfer','Main to Sub',25,0,0,0,25,0,25,0,0,'',''),(397,149,'2023-01-11 00:00:00','M149','FRUSEMIDE 10MG','Transfer','Sub to A Kit',0,25,0,0,25,0,0,25,0,'',''),(398,150,'2023-01-11 00:00:00','M150','INJ POLYNION','Add','To main stock',0,0,0,0,14,14,0,0,0,'',''),(399,150,'2023-01-11 00:00:00','M150','INJ POLYNION','Transfer','Main to Sub',14,0,0,0,14,0,14,0,0,'',''),(400,150,'2023-01-11 00:00:00','M150','INJ POLYNION','Transfer','Sub to A Kit',0,14,0,0,14,0,0,14,0,'',''),(401,150,'2023-01-11 00:00:00','M150','INJ POLYNION','Inbound','To main stock',0,0,14,0,5,5,0,14,0,'',''),(402,150,'2023-01-11 00:00:00','M150','INJ POLYNION','Transfer','Main to Sub',5,0,14,0,5,0,5,14,0,'',''),(403,150,'2023-01-11 00:00:00','M150','INJ POLYNION','Transfer','Sub to A Kit',0,5,14,0,5,0,0,19,0,'',''),(404,151,'2023-01-11 00:00:00','M151','INJ LASIX','Add','To main stock',0,0,0,0,1,1,0,0,0,'',''),(405,151,'2023-01-11 00:00:00','M151','INJ LASIX','Transfer','Main to Sub',1,0,0,0,1,0,1,0,0,'',''),(406,151,'2023-01-11 00:00:00','M151','INJ LASIX','Transfer','Sub to A Kit',0,1,0,0,1,0,0,1,0,'',''),(407,151,'2023-01-11 00:00:00','M151','INJ LASIX','Inbound','To main stock',0,0,1,0,2,2,0,1,0,'',''),(408,151,'2023-01-11 00:00:00','M151','INJ LASIX','Transfer','Main to Sub',2,0,1,0,2,0,2,1,0,'',''),(409,151,'2023-01-11 00:00:00','M151','INJ LASIX','Transfer','Sub to A Kit',0,2,1,0,2,0,0,3,0,'',''),(410,30,'2023-01-13 00:00:00','M30','Tab Doxofylline 200mg(Doxoline)','Transfer','Main to Sub',300,0,0,0,60,240,60,0,0,'',''),(411,30,'2023-01-13 00:00:00','M30','Tab Doxofylline 200mg(Doxoline)','Transfer','Sub to OP',240,60,0,0,60,240,0,0,0,'92/2018','UNYALAN'),(412,92,'2023-01-13 00:00:00','M92','Urine collection Bag','Transfer','Main to Sub',30,0,0,0,1,29,1,0,0,'',''),(413,92,'2023-01-13 00:00:00','M92','Urine collection Bag','Transfer','Sub to OP',29,1,0,0,1,29,0,0,0,'112/2022','Damodaran'),(414,152,'2023-01-13 00:00:00','M152','inj atropine 0.6mg','Add','To main stock',0,0,0,0,1,1,0,0,0,'',''),(415,152,'2023-01-13 00:00:00','M152','inj atropine 0.6mg','Transfer','Main to Sub',1,0,0,0,1,0,1,0,0,'',''),(416,152,'2023-01-13 00:00:00','M152','inj atropine 0.6mg','Transfer','Sub to A Kit',0,1,0,0,1,0,0,1,0,'',''),(417,153,'2023-01-13 00:00:00','M153','INJ DERIPHYLLIN','Add','To main stock',0,0,0,0,4,4,0,0,0,'',''),(418,153,'2023-01-13 00:00:00','M153','INJ DERIPHYLLIN','Transfer','Main to Sub',4,0,0,0,4,0,4,0,0,'',''),(419,153,'2023-01-13 00:00:00','M153','INJ DERIPHYLLIN','Transfer','Sub to A Kit',0,4,0,0,4,0,0,4,0,'',''),(420,154,'2023-01-13 00:00:00','M154','INJ EMESET ','Add','To main stock',0,0,0,0,2,2,0,0,0,'',''),(421,154,'2023-01-13 00:00:00','M154','INJ EMESET ','Transfer','Main to Sub',2,0,0,0,2,0,2,0,0,'',''),(422,154,'2023-01-13 00:00:00','M154','INJ EMESET ','Transfer','Sub to A Kit',0,2,0,0,2,0,0,2,0,'',''),(423,154,'2023-01-13 00:00:00','M154','INJ EMESET ','Inbound','To main stock',0,0,2,0,1,1,0,2,0,'',''),(424,154,'2023-01-13 00:00:00','M154','INJ EMESET ','Transfer','Main to Sub',1,0,2,0,1,0,1,2,0,'',''),(425,154,'2023-01-13 00:00:00','M154','INJ EMESET ','Transfer','Sub to A Kit',0,1,2,0,1,0,0,3,0,'',''),(426,155,'2023-01-13 00:00:00','M155','HEMSYL 125MG','Add','To main stock',0,0,0,0,3,3,0,0,0,'',''),(427,155,'2023-01-13 00:00:00','M155','HEMSYL 125MG','Transfer','Main to Sub',3,0,0,0,3,0,3,0,0,'',''),(428,155,'2023-01-13 00:00:00','M155','HEMSYL 125MG','Transfer','Sub to A Kit',0,3,0,0,3,0,0,3,0,'',''),(429,156,'2023-01-14 00:00:00','M156','inj 3% saline','Add','To main stock',0,0,0,0,1,1,0,0,0,'',''),(430,156,'2023-01-17 00:00:00','M156','inj 3% saline','Transfer','Main to Sub',1,0,0,0,1,0,1,0,0,'',''),(431,156,'2023-01-17 00:00:00','M156','inj 3% saline','Transfer','Sub to A Kit',0,1,0,0,1,0,0,1,0,'',''),(432,156,'2023-01-17 00:00:00','M156','inj 3% saline','Inbound','To main stock',0,0,1,0,6,6,0,1,0,'',''),(433,156,'2023-01-17 00:00:00','M156','inj 3% saline','Transfer','Main to Sub',6,0,1,0,6,0,6,1,0,'',''),(434,156,'2023-01-17 00:00:00','M156','inj 3% saline','Transfer','Sub to A Kit',0,6,1,0,6,0,0,7,0,'',''),(435,157,'2023-01-17 00:00:00','M157','IVF D10 ','Add','To main stock',0,0,0,0,1,1,0,0,0,'',''),(436,157,'2023-01-17 00:00:00','M157','IVF D10 ','Transfer','Main to Sub',1,0,0,0,1,0,1,0,0,'',''),(437,157,'2023-01-17 00:00:00','M157','IVF D10 ','Transfer','Sub to A Kit',0,1,0,0,1,0,0,1,0,'',''),(438,158,'2023-01-17 00:00:00','M158','IVF D5','Add','To main stock',0,0,0,0,1,1,0,0,0,'',''),(439,158,'2023-01-17 00:00:00','M158','IVF D5','Transfer','Main to Sub',1,0,0,0,1,0,1,0,0,'',''),(440,158,'2023-01-17 00:00:00','M158','IVF D5','Transfer','Sub to A Kit',0,1,0,0,1,0,0,1,0,'',''),(441,159,'2023-01-17 00:00:00','M159','IVF DNS ','Add','To main stock',0,0,0,0,1,1,0,0,0,'',''),(442,159,'2023-01-17 00:00:00','M159','IVF DNS ','Transfer','Main to Sub',1,0,0,0,1,0,1,0,0,'',''),(443,159,'2023-01-17 00:00:00','M159','IVF DNS ','Transfer','Sub to A Kit',0,1,0,0,1,0,0,1,0,'',''),(444,159,'2023-01-17 00:00:00','M159','IVF DNS ','Inbound','To main stock',0,0,1,0,2,2,0,1,0,'',''),(445,159,'2023-01-17 00:00:00','M159','IVF DNS ','Transfer','Main to Sub',2,0,1,0,2,0,2,1,0,'',''),(446,159,'2023-01-17 00:00:00','M159','IVF DNS ','Transfer','Sub to A Kit',0,2,1,0,2,0,0,3,0,'',''),(447,160,'2023-01-17 00:00:00','M160','IVF RL','Add','To main stock',0,0,0,0,2,2,0,0,0,'',''),(448,160,'2023-01-17 00:00:00','M160','IVF RL','Transfer','Main to Sub',2,0,0,0,2,0,2,0,0,'',''),(449,160,'2023-01-17 00:00:00','M160','IVF RL','Transfer','Sub to A Kit',0,2,0,0,2,0,0,2,0,'',''),(450,161,'2023-01-17 00:00:00','M161','INJ MANITOL 100 ML','Add','To main stock',0,0,0,0,4,4,0,0,0,'',''),(451,161,'2023-01-17 00:00:00','M161','INJ MANITOL 100 ML','Transfer','Main to Sub',4,0,0,0,4,0,4,0,0,'',''),(452,161,'2023-01-17 00:00:00','M161','INJ MANITOL 100 ML','Transfer','Sub to A Kit',0,4,0,0,4,0,0,4,0,'',''),(453,162,'2023-01-17 00:00:00','M162','INJ 25%DEXTROSE 100 ML','Add','To main stock',0,0,0,0,1,1,0,0,0,'',''),(454,162,'2023-01-17 00:00:00','M162','INJ 25%DEXTROSE 100 ML','Transfer','Main to Sub',1,0,0,0,1,0,1,0,0,'',''),(455,162,'2023-01-17 00:00:00','M162','INJ 25%DEXTROSE 100 ML','Transfer','Sub to A Kit',0,1,0,0,1,0,0,1,0,'',''),(456,163,'2023-01-17 00:00:00','M163','IVF 100ML NS ','Add','To main stock',0,0,0,0,1,1,0,0,0,'',''),(457,163,'2023-01-17 00:00:00','M163','IVF 100ML NS ','Transfer','Main to Sub',1,0,0,0,1,0,1,0,0,'',''),(458,163,'2023-01-17 00:00:00','M163','IVF 100ML NS ','Transfer','Sub to A Kit',0,1,0,0,1,0,0,1,0,'',''),(459,163,'2023-01-17 00:00:00','M163','IVF 100ML NS ','Inbound','To main stock',0,0,1,0,1,1,0,1,0,'',''),(460,163,'2023-01-17 00:00:00','M163','IVF 100ML NS ','Transfer','Main to Sub',1,0,1,0,1,0,1,1,0,'',''),(461,163,'2023-01-17 00:00:00','M163','IVF 100ML NS ','Transfer','Sub to A Kit',0,1,1,0,1,0,0,2,0,'',''),(462,65,'2023-01-18 00:00:00','M65','Tab Torsemide 40mg (TOR 40)','Transfer','Main to Sub',70,0,0,0,60,10,60,0,0,'',''),(463,65,'2023-01-18 00:00:00','M65','Tab Torsemide 40mg (TOR 40)','Transfer','Sub to A Kit',10,60,0,0,60,10,0,60,0,'',''),(464,118,'2023-01-18 00:00:00','M118','Sterile Gloves (surgical) 6.5','Transfer','Main to Sub',86,0,64,0,15,71,15,64,0,'',''),(465,118,'2023-01-18 00:00:00','M118','Sterile Gloves (surgical) 6.5','Transfer','Sub to A Kit',71,15,64,0,15,71,0,79,0,'',''),(466,34,'2023-01-18 00:00:00','M34','Water for injection 10 ml','Transfer','Main to Sub',50,0,20,0,15,35,15,20,0,'',''),(467,34,'2023-01-18 00:00:00','M34','Water for injection 10 ml','Transfer','Sub to A Kit',35,15,20,0,15,35,0,35,0,'',''),(468,118,'2023-01-18 00:00:00','M118','Sterile Gloves (surgical) 6.5','Transfer','Main to Sub',71,0,79,0,15,56,15,79,0,'',''),(469,118,'2023-01-18 00:00:00','M118','Sterile Gloves (surgical) 6.5','Transfer','Sub to A Kit',56,15,79,0,15,56,0,94,0,'',''),(470,33,'2023-01-18 00:00:00','M33','Oint Lignocaine Jelly 30 g','Transfer','Main to Sub',17,0,0,0,3,14,3,0,0,'',''),(471,33,'2023-01-18 00:00:00','M33','Oint Lignocaine Jelly 30 g','Transfer','Sub to A Kit',14,3,0,0,3,14,0,3,0,'',''),(472,89,'2023-01-18 00:00:00','M89','Dispo needle 26 x 1 1/2','Transfer','Main to Sub',40,0,10,0,20,20,20,10,0,'',''),(473,89,'2023-01-18 00:00:00','M89','Dispo needle 26 x 1 1/2','Transfer','Sub to A Kit',20,20,10,0,20,20,0,30,0,'',''),(474,95,'2023-01-18 00:00:00','M95','Inj. N S 500ml','Transfer','Main to Sub',10,0,4,0,3,7,3,4,0,'',''),(475,95,'2023-01-18 00:00:00','M95','Inj. N S 500ml','Transfer','Sub to A Kit',7,3,4,0,3,7,0,7,0,'',''),(476,118,'2023-01-18 00:00:00','M118','Sterile Gloves (surgical) 6.5','Transfer','Main to Sub',56,0,94,0,9,47,9,94,0,'',''),(477,118,'2023-01-18 00:00:00','M118','Sterile Gloves (surgical) 6.5','Transfer','Sub to A Kit',47,9,94,0,9,47,0,103,0,'',''),(478,90,'2023-01-18 00:00:00','M90','Cannula Fixator 4.5 cm x 6 cm','Transfer','Main to Sub',89,0,0,0,15,74,15,0,0,'',''),(479,90,'2023-01-18 00:00:00','M90','Cannula Fixator 4.5 cm x 6 cm','Transfer','Sub to A Kit',74,15,0,0,15,74,0,15,0,'',''),(480,127,'2023-01-18 00:00:00','M127','SURGICAL GLOVE(STERILE) 7','Transfer','Main to Sub',50,0,0,0,25,25,25,0,0,'',''),(481,127,'2023-01-18 00:00:00','M127','SURGICAL GLOVE(STERILE) 7','Transfer','Sub to A Kit',25,25,0,0,25,25,0,25,0,'',''),(482,116,'2023-01-18 00:00:00','M116','Adhessive Tape 5.0 X 9.1 M (Paper Plaster)','Transfer','Main to Sub',12,0,0,0,2,10,2,0,0,'',''),(483,116,'2023-01-18 00:00:00','M116','Adhessive Tape 5.0 X 9.1 M (Paper Plaster)','Transfer','Sub to A Kit',10,2,0,0,2,10,0,2,0,'',''),(484,119,'2023-01-18 00:00:00','M119','Roller Bandage 7.5cm X 3M','Transfer','Main to Sub',30,0,10,0,10,20,10,10,0,'',''),(485,119,'2023-01-18 00:00:00','M119','Roller Bandage 7.5cm X 3M','Transfer','Sub to A Kit',20,10,10,0,10,20,0,20,0,'',''),(486,71,'2023-01-18 00:00:00','M71','Tab Amlodipine 5mg','Transfer','Main to Sub',50,0,140,0,30,20,30,140,0,'',''),(487,71,'2023-01-18 00:00:00','M71','Tab Amlodipine 5mg','Transfer','Sub to A Kit',20,30,140,0,30,20,0,170,0,'',''),(488,7,'2023-01-18 00:00:00','M7','Tab Pantoprazole 40 mg','Transfer','Main to Sub',510,0,0,0,30,480,30,0,0,'',''),(489,7,'2023-01-18 00:00:00','M7','Tab Pantoprazole 40 mg','Transfer','Sub to A Kit',480,30,0,0,30,480,0,30,0,'',''),(490,50,'2023-01-18 00:00:00','M50','Disposable Syringe 10 ml (Dispovan)','Transfer','Main to Sub',211,0,0,0,11,200,11,0,0,'',''),(491,50,'2023-01-18 00:00:00','M50','Disposable Syringe 10 ml (Dispovan)','Transfer','Sub to A Kit',200,11,0,0,11,200,0,11,0,'',''),(492,22,'2023-01-18 00:00:00','M22','Tab Amitriptyline 10 mg ','Transfer','Main to Sub',100,0,0,0,50,50,50,0,0,'',''),(493,22,'2023-01-18 00:00:00','M22','Tab Amitriptyline 10 mg ','Transfer','Sub to A Kit',50,50,0,0,50,50,0,50,0,'',''),(494,34,'2023-01-18 00:00:00','M34','Water for injection 10 ml','Transfer','Main to Sub',35,0,35,0,35,0,35,35,0,'',''),(495,34,'2023-01-18 00:00:00','M34','Water for injection 10 ml','Transfer','Sub to A Kit',0,35,35,0,35,0,0,70,0,'',''),(496,114,'2023-01-18 00:00:00','M114','Tab De-cal','Transfer','Main to Sub',150,0,120,0,60,90,60,120,0,'',''),(497,114,'2023-01-18 00:00:00','M114','Tab De-cal','Transfer','Sub to A Kit',90,60,120,0,60,90,0,180,0,'',''),(498,89,'2023-01-18 00:00:00','M89','Dispo needle 26 x 1 1/2','Transfer','Main to Sub',20,0,30,0,20,0,20,30,0,'',''),(499,89,'2023-01-18 00:00:00','M89','Dispo needle 26 x 1 1/2','Transfer','Sub to A Kit',0,20,30,0,20,0,0,50,0,'',''),(500,119,'2023-01-18 00:00:00','M119','Roller Bandage 7.5cm X 3M','Transfer','Main to Sub',20,0,20,0,10,10,10,20,0,'',''),(501,119,'2023-01-18 00:00:00','M119','Roller Bandage 7.5cm X 3M','Transfer','Sub to A Kit',10,10,20,0,10,10,0,30,0,'',''),(502,116,'2023-01-18 00:00:00','M116','Adhessive Tape 5.0 X 9.1 M (Paper Plaster)','Transfer','Main to Sub',10,0,2,0,3,7,3,2,0,'',''),(503,116,'2023-01-18 00:00:00','M116','Adhessive Tape 5.0 X 9.1 M (Paper Plaster)','Transfer','Sub to A Kit',7,3,2,0,3,7,0,5,0,'',''),(504,101,'2023-01-18 00:00:00','M101','Foley Catheter 16 FG','Transfer','Main to Sub',1,0,0,0,1,0,1,0,0,'',''),(505,101,'2023-01-18 00:00:00','M101','Foley Catheter 16 FG','Transfer','Sub to A Kit',0,1,0,0,1,0,0,1,0,'',''),(506,97,'2023-01-18 00:00:00','M97','Foley Catheter 16 ','Transfer','Main to Sub',10,0,0,0,10,0,10,0,0,'',''),(507,97,'2023-01-18 00:00:00','M97','Foley Catheter 16 ','Transfer','Sub to A Kit',0,10,0,0,10,0,0,10,0,'',''),(508,100,'2023-01-18 00:00:00','M100','Foley Catheter 14 FG','Transfer','Main to Sub',2,0,0,0,2,0,2,0,0,'',''),(509,100,'2023-01-18 00:00:00','M100','Foley Catheter 14 FG','Transfer','Sub to A Kit',0,2,0,0,2,0,0,2,0,'',''),(510,98,'2023-01-18 00:00:00','M98','Foley Catheter 14 ','Transfer','Main to Sub',3,0,0,0,3,0,3,0,0,'',''),(511,98,'2023-01-18 00:00:00','M98','Foley Catheter 14 ','Transfer','Sub to A Kit',0,3,0,0,3,0,0,3,0,'',''),(512,99,'2023-01-18 00:00:00','M99','Foley Catheter 20','Transfer','Main to Sub',2,0,0,0,2,0,2,0,0,'',''),(513,99,'2023-01-18 00:00:00','M99','Foley Catheter 20','Transfer','Sub to A Kit',0,2,0,0,2,0,0,2,0,'',''),(514,19,'2023-01-19 00:00:00','M19','Tab Carbamazepine CR 200mg','Transfer','Main to Sub',60,0,0,0,20,40,20,0,0,'',''),(515,19,'2023-01-19 00:00:00','M19','Tab Carbamazepine CR 200mg','Transfer','Sub to OP',40,20,0,0,20,40,0,0,0,'129/2017','BINDHU'),(516,54,'2023-01-19 00:00:00','M54','Tab Pacitane 2mg','Transfer','Main to Sub',120,0,90,0,30,90,30,90,0,'',''),(517,23,'2023-01-19 00:00:00','M23','Tab Risperidone 1 mg  ','Transfer','Main to Sub',100,0,0,0,30,70,30,0,0,'',''),(518,98,'2023-01-20 00:00:00','M98','Foley Catheter 14 ','Inbound','To main stock',0,0,3,0,20,20,0,3,0,'',''),(519,97,'2023-01-20 00:00:00','M97','Foley Catheter 16 ','Inbound','To main stock',0,0,10,0,20,20,0,10,0,'',''),(520,46,'2023-01-20 00:00:00','M46','Cotton Wool Absorbant 400gm','Inbound','To main stock',6,0,0,0,5,11,0,0,0,'',''),(521,164,'2023-01-20 00:00:00','M164','UROBAG ROMO 10','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(522,165,'2023-01-20 00:00:00','M165','DOLIPRANE 650 ( PARACETAMOL TABLETS I.P 650','Add','To main stock',0,0,0,0,500,500,0,0,0,'',''),(523,49,'2023-01-20 00:00:00','M49','Disposable Syringe 20ml (Dispovan)','Inbound','To main stock',35,0,0,0,25,60,0,0,0,'',''),(524,82,'2023-01-20 00:00:00','M82','Povidone Iodine Solution 500ml','Inbound','To main stock',1,0,1,0,1,2,0,1,0,'',''),(525,166,'2023-01-20 00:00:00','M166','DEXTROSE INJECTION IP (10% W/V) 500 ML','Add','To main stock',0,0,0,0,5,5,0,0,0,'',''),(526,167,'2023-01-20 00:00:00','M167','AJAPRIDE M2 (METFORMIN HYDROCHLORIDE PROLONGED RELEASE & GLIMEPRIDE TAB IP','Add','To main stock',0,0,0,0,300,300,0,0,0,'',''),(527,168,'2023-01-20 00:00:00','M168','MULTI9 (MULTIVITAMIN TABLETS)','Add','To main stock',0,0,0,0,100,100,0,0,0,'',''),(528,71,'2023-01-20 00:00:00','M71','Tab Amlodipine 5mg','Inbound','To main stock',20,0,170,0,200,220,0,170,0,'',''),(529,169,'2023-01-20 00:00:00','M169','Tab Amlodipine BESILATE 10mg( AMLIP10)','Add','To main stock',0,0,0,0,200,200,0,0,0,'',''),(530,71,'2023-01-20 00:00:00','M71','Tab Amlodipine 5mg','Inbound','To main stock',220,0,170,0,300,520,0,170,0,'',''),(531,170,'2023-01-20 00:00:00','M170','TRANQUILAM 0.25 CLONAZEPAM TAB IP 0.25','Add','To main stock',0,0,0,0,105,105,0,0,0,'',''),(532,171,'2023-01-20 00:00:00','M171','BLOOD LANCET 100S ','Add','To main stock',0,0,0,0,200,200,0,0,0,'',''),(533,172,'2023-01-20 00:00:00','M172','GLUCO ONE 50S STRIP','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(534,173,'2023-01-20 00:00:00','M173','sterile water for injection IP','Add','To main stock',0,0,0,0,150,150,0,0,0,'',''),(535,174,'2023-01-20 00:00:00','M174','SURGICAL GLOVES NON STERILE 7.5','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(536,172,'2023-01-20 00:00:00','M172','GLUCO ONE 50S STRIP','Transfer','Main to Sub',50,0,0,0,50,0,50,0,0,'',''),(537,172,'2023-01-20 00:00:00','M172','GLUCO ONE 50S STRIP','Transfer','Sub to A Kit',0,50,0,0,50,0,0,50,0,'',''),(538,171,'2023-01-20 00:00:00','M171','BLOOD LANCET 100S ','Transfer','Main to Sub',200,0,0,0,100,100,100,0,0,'',''),(539,171,'2023-01-20 00:00:00','M171','BLOOD LANCET 100S ','Transfer','Sub to A Kit',100,100,0,0,100,100,0,100,0,'',''),(540,85,'2023-01-20 00:00:00','M85','Infusion Set (I V Set)','Transfer','Main to Sub',25,0,0,0,11,14,11,0,0,'',''),(541,85,'2023-01-20 00:00:00','M85','Infusion Set (I V Set)','Transfer','Sub to A Kit',14,11,0,0,11,14,0,11,0,'',''),(542,57,'2023-01-20 00:00:00','M57','Tab Clonazepam 0.5mg','Transfer','Main to Sub',190,0,0,0,75,115,75,0,0,'',''),(543,57,'2023-01-20 00:00:00','M57','Tab Clonazepam 0.5mg','Transfer','Sub to A Kit',115,75,0,0,75,115,0,75,0,'',''),(544,173,'2023-01-23 00:00:00','M173','sterile water for injection IP','Inbound','To main stock',150,0,0,0,100,250,0,0,0,'',''),(545,173,'2023-01-23 00:00:00','M173','sterile water for injection IP','Edit','Edit stock',250,0,0,0,0,250,0,0,0,'',''),(546,173,'2023-01-23 00:00:00','M173','sterile water for injection IP','Edit','Edit stock',250,0,0,0,0,250,0,0,0,'',''),(547,175,'2023-01-23 00:00:00','M175','SURGICAL GLOVE 7.5','Add','To main stock',0,0,0,0,100,100,0,0,0,'',''),(548,175,'2023-01-23 00:00:00','M175','SURGICAL GLOVE 7.5','Transfer','Main to Sub',100,0,0,0,50,50,50,0,0,'',''),(549,175,'2023-01-23 00:00:00','M175','SURGICAL GLOVE 7.5','Transfer','Sub to A Kit',50,50,0,0,50,50,0,50,0,'',''),(550,105,'2023-01-23 00:00:00','M105','Tab WARF-2','Transfer','Main to Sub',300,0,0,0,60,240,60,0,0,'',''),(551,105,'2023-01-23 00:00:00','M105','Tab WARF-2','Transfer','Sub to OP',240,60,0,0,60,240,0,0,0,'83/2022','Thankamani'),(552,20,'2023-01-23 00:00:00','M20','Tab Levetiracetam (Levipil) 500 mg','Transfer','Main to Sub',70,0,0,0,30,40,30,0,0,'',''),(553,20,'2023-01-23 00:00:00','M20','Tab Levetiracetam (Levipil) 500 mg','Transfer','Sub to OP',40,30,0,0,30,40,0,0,0,'83/2022','Thankamani'),(554,30,'2023-01-23 00:00:00','M30','Tab Doxofylline 200mg(Doxoline)','Transfer','Main to Sub',240,0,0,0,60,180,60,0,0,'',''),(555,30,'2023-01-23 00:00:00','M30','Tab Doxofylline 200mg(Doxoline)','Transfer','Sub to OP',180,60,0,0,60,180,0,0,0,'83/2022','Thankamani'),(556,46,'2023-01-23 00:00:00','M46','Cotton Wool Absorbant 400gm','Transfer','Main to Sub',11,0,0,0,6,5,6,0,0,'',''),(557,46,'2023-01-23 00:00:00','M46','Cotton Wool Absorbant 400gm','Transfer','Sub to A Kit',5,6,0,0,6,5,0,6,0,'',''),(558,176,'2023-01-25 00:00:00','M176','RISPERIDONE TAB - SIZODON4','Add','To main stock',0,0,0,0,100,100,0,0,0,'',''),(559,20,'2023-01-25 00:00:00','M20','Tab Levetiracetam (Levipil) 500 mg','Inbound','To main stock',40,0,0,0,150,190,0,0,0,'',''),(560,177,'2023-01-25 00:00:00','M177','CLOBA5- CLOBAZAM TAB 5MG','Add','To main stock',0,0,0,0,300,300,0,0,0,'',''),(561,71,'2023-01-26 00:00:00','M71','Tab Amlodipine 5mg','Transfer','Main to Sub',520,0,170,0,10,510,10,170,0,'',''),(562,71,'2023-01-26 00:00:00','M71','Tab Amlodipine 5mg','Transfer','Sub to OP',510,10,170,0,10,510,0,170,0,'46/2018','LAKSHMI'),(563,69,'2023-01-26 00:00:00','M69','Tab Deriphyllin Retard 150 mg','Transfer','Main to Sub',630,0,0,0,10,620,10,0,0,'',''),(564,69,'2023-01-26 00:00:00','M69','Tab Deriphyllin Retard 150 mg','Transfer','Sub to OP',620,10,0,0,10,620,0,0,0,'87/2016','CHANDRASEKARAN'),(565,41,'2023-01-26 00:00:00','M41','Ascodex Plus Cough Syrup','Transfer','Main to Sub',6,0,6,0,1,5,1,6,0,'',''),(566,41,'2023-01-26 00:00:00','M41','Ascodex Plus Cough Syrup','Transfer','Sub to OP',5,1,6,0,1,5,0,6,0,'87/2016','CHANDRASEKARAN'),(567,167,'2023-01-26 00:00:00','M167','AJAPRIDE M2 (METFORMIN HYDROCHLORIDE PROLONGED RELEASE & GLIMEPRIDE TAB IP','Transfer','Main to Sub',300,0,0,0,60,240,60,0,0,'',''),(568,167,'2023-01-26 00:00:00','M167','AJAPRIDE M2 (METFORMIN HYDROCHLORIDE PROLONGED RELEASE & GLIMEPRIDE TAB IP','Transfer','Sub to OP',240,60,0,0,60,240,0,0,0,'57/2021','KAUSALYA'),(569,110,'2023-01-27 00:00:00','M110','Sterile Gloves (Skintac) 7.5','Transfer','A Kit to OP',0,0,50,0,2,0,0,48,0,'75/2019','KHADER HAJI'),(570,49,'2023-01-27 00:00:00','M49','Disposable Syringe 20ml (Dispovan)','Transfer','Main to Sub',60,0,0,0,1,59,1,0,0,'',''),(571,49,'2023-01-27 00:00:00','M49','Disposable Syringe 20ml (Dispovan)','Transfer','Sub to OP',59,1,0,0,1,59,0,0,0,'75/2019','KHADER HAJI'),(572,50,'2023-01-27 00:00:00','M50','Disposable Syringe 10 ml (Dispovan)','Transfer','Main to Sub',200,0,11,0,1,199,1,11,0,'',''),(573,50,'2023-01-27 00:00:00','M50','Disposable Syringe 10 ml (Dispovan)','Transfer','Sub to OP',199,1,11,0,1,199,0,11,0,'75/2019','KHADER HAJI'),(574,34,'2023-01-27 00:00:00','M34','Water for injection 10 ml','Transfer','A Kit to OP',0,0,70,0,3,0,0,67,0,'75/2019','KHADER HAJI'),(575,33,'2023-01-27 00:00:00','M33','Oint Lignocaine Jelly 30 g','Transfer','Main to Sub',14,0,3,0,1,13,1,3,0,'',''),(576,33,'2023-01-27 00:00:00','M33','Oint Lignocaine Jelly 30 g','Transfer','Sub to OP',13,1,3,0,1,13,0,3,0,'75/2019','KHADER HAJI'),(577,117,'2023-01-27 00:00:00','M117','Sodium Phosphate Enema ','Transfer','Main to Sub',15,0,5,0,2,13,2,5,0,'',''),(578,117,'2023-01-27 00:00:00','M117','Sodium Phosphate Enema ','Transfer','Sub to OP',13,2,5,0,2,13,0,5,0,'45/2021','MARIYUMMA'),(579,110,'2023-01-27 00:00:00','M110','Sterile Gloves (Skintac) 7.5','Transfer','A Kit to OP',0,0,48,0,2,0,0,46,0,'45/2021','MARIYUMMA'),(580,115,'2023-01-28 00:00:00','M115','Tab Phensedyl LM ','Transfer','Main to Sub',220,0,0,0,50,170,50,0,0,'',''),(581,115,'2023-01-28 00:00:00','M115','Tab Phensedyl LM ','Transfer','Sub to A Kit',170,50,0,0,50,170,0,50,0,'',''),(582,8,'2023-01-28 00:00:00','M8','Tab Gabapentin 100 mg','Transfer','Main to Sub',120,0,0,0,60,60,60,0,0,'',''),(583,8,'2023-01-28 00:00:00','M8','Tab Gabapentin 100 mg','Transfer','Sub to A Kit',60,60,0,0,60,60,0,60,0,'',''),(584,117,'2023-02-01 00:00:00','M117','Sodium Phosphate Enema ','Transfer','Main to Sub',13,0,5,0,4,9,4,5,0,'',''),(585,117,'2023-02-01 00:00:00','M117','Sodium Phosphate Enema ','Transfer','Sub to A Kit',9,4,5,0,4,9,0,9,0,'',''),(586,9,'2023-02-02 00:00:00','M9','Tab Tramadol 50 mg','Transfer','Main to Sub',120,0,0,0,20,100,20,0,0,'',''),(587,9,'2023-02-02 00:00:00','M9','Tab Tramadol 50 mg','Transfer','Sub to OP',100,20,0,0,20,100,0,0,0,'96/2022','saritha'),(588,165,'2023-02-02 00:00:00','M165','DOLIPRANE 650 ( PARACETAMOL TABLETS I.P 650','Transfer','Main to Sub',500,0,0,0,20,480,20,0,0,'',''),(589,165,'2023-02-02 00:00:00','M165','DOLIPRANE 650 ( PARACETAMOL TABLETS I.P 650','Transfer','Sub to OP',480,20,0,0,20,480,0,0,0,'96/2022','saritha'),(590,20,'2023-02-02 00:00:00','M20','Tab Levetiracetam (Levipil) 500 mg','Transfer','Main to Sub',190,0,0,0,45,145,45,0,0,'',''),(591,20,'2023-02-02 00:00:00','M20','Tab Levetiracetam (Levipil) 500 mg','Transfer','Sub to OP',145,45,0,0,45,145,0,0,0,'96/2022','saritha'),(592,177,'2023-02-02 00:00:00','M177','CLOBA5- CLOBAZAM TAB 5MG','Transfer','Main to Sub',300,0,0,0,30,270,30,0,0,'',''),(593,177,'2023-02-02 00:00:00','M177','CLOBA5- CLOBAZAM TAB 5MG','Transfer','Sub to OP',270,30,0,0,30,270,0,0,0,'96/2022','saritha'),(594,41,'2023-02-02 00:00:00','M41','Ascodex Plus Cough Syrup','Transfer','Main to Sub',5,0,6,0,3,2,3,6,0,'',''),(595,41,'2023-02-02 00:00:00','M41','Ascodex Plus Cough Syrup','Transfer','Sub to OP',2,3,6,0,3,2,0,6,0,'9/2017','MEENAKSHIAMMA'),(596,29,'2023-02-02 00:00:00','M29','Tab Cefixime 200mg','Transfer','A Kit to OP',30,-64,128,0,10,30,-64,118,0,'9/2017','MEENAKSHIAMMA'),(597,165,'2023-02-02 00:00:00','M165','DOLIPRANE 650 ( PARACETAMOL TABLETS I.P 650','Transfer','Main to Sub',480,0,0,0,130,350,130,0,0,'',''),(598,165,'2023-02-02 00:00:00','M165','DOLIPRANE 650 ( PARACETAMOL TABLETS I.P 650','Transfer','Sub to A Kit',350,130,0,0,130,350,0,130,0,'',''),(599,169,'2023-02-02 00:00:00','M169','Tab Amlodipine BESILATE 10mg( AMLIP10)','Transfer','Main to Sub',200,0,0,0,20,180,20,0,0,'',''),(600,169,'2023-02-02 00:00:00','M169','Tab Amlodipine BESILATE 10mg( AMLIP10)','Transfer','Sub to A Kit',180,20,0,0,20,180,0,20,0,'',''),(601,71,'2023-02-02 00:00:00','M71','Tab Amlodipine 5mg','Transfer','Main to Sub',510,0,170,0,50,460,50,170,0,'',''),(602,71,'2023-02-02 00:00:00','M71','Tab Amlodipine 5mg','Transfer','Sub to A Kit',460,50,170,0,50,460,0,220,0,'',''),(603,108,'2023-02-02 00:00:00','M108','Tab Clonidime 100mg','Transfer','Main to Sub',660,0,0,0,180,480,180,0,0,'',''),(604,108,'2023-02-02 00:00:00','M108','Tab Clonidime 100mg','Transfer','Sub to A Kit',480,180,0,0,180,480,0,180,0,'',''),(605,31,'2023-02-02 00:00:00','M31','Tab Baclofen 10 mg','Transfer','Main to Sub',100,0,0,0,30,70,30,0,0,'',''),(606,31,'2023-02-02 00:00:00','M31','Tab Baclofen 10 mg','Transfer','Sub to A Kit',70,30,0,0,30,70,0,30,0,'',''),(607,77,'2023-02-02 00:00:00','M77','Tab Cilinitab 20( Cilnidipine)','Transfer','Main to Sub',20,0,0,0,20,0,20,0,0,'',''),(608,77,'2023-02-02 00:00:00','M77','Tab Cilinitab 20( Cilnidipine)','Transfer','Sub to A Kit',0,20,0,0,20,0,0,20,0,'',''),(609,7,'2023-02-10 00:00:00','M7','Tab Pantoprazole 40 mg','Transfer','Main to Sub',480,0,30,0,45,435,45,30,0,'',''),(610,7,'2023-02-10 00:00:00','M7','Tab Pantoprazole 40 mg','Transfer','Sub to A Kit',435,45,30,0,45,435,0,75,0,'',''),(611,43,'2023-02-10 00:00:00','M43','Liquid Paraffin','Transfer','Main to Sub',10,0,3,0,5,5,5,3,0,'',''),(612,43,'2023-02-10 00:00:00','M43','Liquid Paraffin','Transfer','Sub to A Kit',5,5,3,0,5,5,0,8,0,'',''),(613,33,'2023-02-10 00:00:00','M33','Oint Lignocaine Jelly 30 g','Transfer','Main to Sub',13,0,3,0,4,9,4,3,0,'',''),(614,33,'2023-02-10 00:00:00','M33','Oint Lignocaine Jelly 30 g','Transfer','Sub to A Kit',9,4,3,0,4,9,0,7,0,'',''),(615,175,'2023-02-10 00:00:00','M175','SURGICAL GLOVE 7.5','Transfer','Main to Sub',50,0,50,0,13,37,13,50,0,'',''),(616,175,'2023-02-10 00:00:00','M175','SURGICAL GLOVE 7.5','Transfer','Sub to A Kit',37,13,50,0,13,37,0,63,0,'','');
/*!40000 ALTER TABLE `medicinehistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicinepurchase`
--

DROP TABLE IF EXISTS `medicinepurchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicinepurchase` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `MedicineId` int NOT NULL,
  `invdate` datetime DEFAULT NULL,
  `invno` varchar(45) DEFAULT NULL,
  `batchno` varchar(45) DEFAULT NULL,
  `expdate` datetime NOT NULL,
  `mfgdate` datetime DEFAULT NULL,
  `rate` decimal(10,2) DEFAULT NULL,
  `dealer` varchar(100) DEFAULT NULL,
  `mainStock` int DEFAULT NULL,
  `subStock` int DEFAULT NULL,
  `return` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicinepurchase`
--

LOCK TABLES `medicinepurchase` WRITE;
/*!40000 ALTER TABLE `medicinepurchase` DISABLE KEYS */;
INSERT INTO `medicinepurchase` VALUES (1,1,NULL,'','SN20151','2024-12-24 00:00:00','2022-01-01 00:00:00',52.62,'',500,0,0),(2,2,NULL,'','GPD089036BH','2023-09-01 00:00:00','2019-10-01 00:00:00',97.44,'',0,0,0),(3,2,NULL,NULL,'GPD089011BH','2023-03-01 00:00:00','2019-04-01 00:00:00',97.44,NULL,0,0,0),(4,2,NULL,'','GPD080020BH','2024-03-01 00:00:00','2020-04-01 00:00:00',99.29,'',0,0,0),(5,3,NULL,'','ALT220163','2024-01-01 00:00:00','2022-02-01 00:00:00',11.22,'',304,0,0),(6,4,NULL,'','E700896','2023-07-01 00:00:00','2020-08-01 00:00:00',22.12,'',340,0,0),(7,5,NULL,'','MA457','2023-09-01 00:00:00','2022-04-01 00:00:00',92.90,'',29,0,0),(8,6,NULL,'','MPB210789','2023-01-01 00:00:00','2021-02-01 00:00:00',0.00,'',0,0,0),(9,7,NULL,'','JKFD22024','2025-04-01 00:00:00','2022-05-01 00:00:00',126.70,'',270,0,0),(10,8,NULL,'','SID1220A','2025-02-01 00:00:00','2022-05-01 00:00:00',80.00,'',40,0,0),(11,9,NULL,'','c-0031/21','2023-09-01 00:00:00','2021-10-01 00:00:00',50.62,'',100,0,0),(12,10,NULL,'','ICH0023','2023-12-01 00:00:00','2022-01-01 00:00:00',73.96,'',322,0,0),(13,11,NULL,'','N2200692','2025-02-01 00:00:00','2022-03-01 00:00:00',82.50,'',70,0,0),(14,12,NULL,'','N2200843','2025-02-01 00:00:00','2022-03-01 00:00:00',55.00,'',140,0,0),(15,13,NULL,'','GTD0727A','2024-03-01 00:00:00','2022-04-01 00:00:00',45.25,'',200,0,0),(16,14,NULL,'','SID1170A','2025-03-01 00:00:00','2022-04-01 00:00:00',72.50,'',180,0,0),(17,15,NULL,'','SIC2528A','2023-08-01 00:00:00','2021-09-01 00:00:00',216.00,'',10,0,0),(18,16,NULL,'','SMSG21005','2023-03-01 00:00:00','2022-04-01 00:00:00',22.50,'',10,0,0),(19,16,NULL,NULL,'SMSG 21005','2023-04-01 00:00:00','2021-05-01 00:00:00',22.50,NULL,10,0,0),(20,17,NULL,'','ABG0186','2024-05-01 00:00:00','2021-06-01 00:00:00',13.71,'',2,0,0),(21,18,NULL,'','ABG0052','2024-02-01 00:00:00','2021-03-01 00:00:00',32.45,'',4,0,0),(22,19,NULL,'','GTD0494A','2025-02-02 00:00:00','2022-03-01 00:00:00',26.21,'',10,0,0),(23,7,NULL,NULL,'JKFD22024','2025-04-01 00:00:00','2022-05-01 00:00:00',126.70,NULL,165,0,0),(24,20,NULL,'','SID0476A','2024-01-01 00:00:00','2022-02-01 00:00:00',132.70,'',0,0,0),(25,21,NULL,'','UAA2242','2024-05-01 00:00:00','2022-02-01 00:00:00',295.00,'',2,0,0),(26,1,NULL,NULL,NULL,'2024-04-01 00:00:00','2022-05-01 00:00:00',56.99,NULL,200,0,0),(27,22,NULL,'','SPT10143','2025-08-01 00:00:00','2021-09-01 00:00:00',24.25,'',50,0,0),(28,23,NULL,'','SID0490A','2025-01-01 00:00:00','2022-02-01 00:00:00',30.52,'',70,30,0),(29,24,NULL,'','B6AEV115','2024-02-01 00:00:00','2022-03-01 00:00:00',154.55,'',100,0,0),(30,25,NULL,'','HCL2074','2024-02-01 00:00:00','2022-03-01 00:00:00',86.46,'',0,0,0),(31,26,NULL,'','2010C84207','2023-12-01 00:00:00','2022-01-01 00:00:00',76.10,'',225,0,0),(32,27,NULL,'','T211827','2023-10-01 00:00:00','2021-11-01 00:00:00',63.75,'',270,0,0),(33,28,NULL,'','MFH0213','2024-02-01 00:00:00','2022-03-01 00:00:00',201.57,'',80,0,0),(34,29,NULL,'','TAAD2002A','2023-12-01 00:00:00','2022-01-01 00:00:00',107.74,'',0,0,0),(35,30,NULL,'','1203695','2024-08-01 00:00:00','2022-09-01 00:00:00',87.80,'',180,0,0),(36,31,NULL,'','N2200625','2025-02-01 00:00:00','2022-03-01 00:00:00',113.19,'',70,0,0),(37,32,NULL,'','C120678','2025-03-01 00:00:00','2022-04-01 00:00:00',14.72,'',39,0,0),(38,33,NULL,'','E2B036','2024-01-01 00:00:00','2022-02-01 00:00:00',35.95,'',9,0,0),(39,34,NULL,'','WEG0206','2025-06-01 00:00:00','2022-07-01 00:00:00',144.00,'',0,0,0),(40,35,NULL,'','M420022','2025-02-01 00:00:00','2022-03-01 00:00:00',8.64,'',50,0,0),(41,36,NULL,'','N200316','2023-08-01 00:00:00','2022-03-01 00:00:00',11.57,'',30,0,0),(42,37,NULL,'','AIY1027','2026-03-01 00:00:00','2022-04-01 00:00:00',8.19,'',20,0,0),(43,38,NULL,'','IAT9937','2023-05-01 00:00:00','2021-06-01 00:00:00',4.41,'',5,0,0),(44,39,NULL,'','11009','2027-04-01 00:00:00','2022-05-01 00:00:00',194.00,'',10,0,0),(45,40,NULL,'','108116','2023-07-01 00:00:00','2021-08-01 00:00:00',135.00,'',4,0,0),(46,41,NULL,'','11220257','2024-01-01 00:00:00','2022-02-01 00:00:00',108.00,'',0,0,0),(47,42,NULL,'','22090790','2024-05-01 00:00:00','2022-06-01 00:00:00',104.88,'',18,0,0),(48,43,NULL,'','RL151','2025-05-01 00:00:00','2022-06-01 00:00:00',100.00,'',5,0,0),(49,44,NULL,'','266','2025-03-01 00:00:00','2022-04-01 00:00:00',320.00,'',3,0,0),(50,44,NULL,NULL,'260','2025-12-01 00:00:00','2022-01-01 00:00:00',300.00,NULL,1,0,0),(51,44,NULL,'','114','2025-05-01 00:00:00','2022-06-01 00:00:00',220.00,'',2,0,0),(52,45,NULL,'','108','2025-11-01 00:00:00','2022-09-01 00:00:00',140.00,'',0,0,0),(53,46,NULL,'','30','2024-10-01 00:00:00','2022-09-01 00:00:00',260.00,'',0,0,0),(54,47,NULL,'','0252.56SL1','2025-05-01 00:00:00','2020-06-01 00:00:00',6.00,'',100,0,0),(55,48,NULL,'','030053SH2','2025-06-01 00:00:00','2020-06-01 00:00:00',7.50,'',63,0,0),(56,48,NULL,NULL,'949056SK1','2024-11-01 00:00:00','2019-12-01 00:00:00',7.00,NULL,24,0,0),(57,49,NULL,'','217202JH2','2027-03-01 00:00:00','2022-04-01 00:00:00',23.00,'',10,0,0),(58,50,NULL,'','028105JP1','2025-06-01 00:00:00','2020-07-01 00:00:00',0.00,'',111,0,0),(59,50,NULL,NULL,'025103JG1','2025-05-01 00:00:00','2020-06-01 00:00:00',9.50,NULL,88,0,0),(60,51,NULL,'','GTD0164A','2024-12-01 00:00:00','2022-01-01 00:00:00',116.00,'',50,0,0),(61,52,NULL,'','FM4529','2023-10-01 00:00:00','2021-11-01 00:00:00',82.99,'',150,0,0),(62,53,NULL,'','SIC3194A','2023-11-01 00:00:00','2021-12-01 00:00:00',90.00,'',50,0,0),(63,54,NULL,'','PD3495','2024-04-01 00:00:00','2021-05-01 00:00:00',40.15,'',90,30,0),(64,55,NULL,'','GTC0607A','2024-03-01 00:00:00','2021-04-01 00:00:00',149.00,'',149,0,0),(65,13,NULL,NULL,'GTD0273a','2024-01-01 00:00:00','2022-02-01 00:00:00',40.86,NULL,20,0,0),(66,56,NULL,'','GTD0139A','2023-12-01 00:00:00','2022-01-01 00:00:00',33.32,'',50,0,0),(67,57,NULL,'','SID0348A','2025-01-01 00:00:00','2022-02-01 00:00:00',52.23,'',115,0,0),(68,58,NULL,'','SIC2867A','2023-09-01 00:00:00','2021-10-01 00:00:00',30.73,'',20,0,0),(69,59,NULL,'','GTC0611A','2024-06-01 00:00:00','2021-07-01 00:00:00',89.00,'',50,0,0),(70,60,NULL,'','GKC0864A','2025-05-01 00:00:00','2021-06-01 00:00:00',0.00,'',10,0,0),(71,60,NULL,NULL,'GKD0568A','2025-07-01 00:00:00','2022-04-01 00:00:00',42.00,NULL,20,0,0),(72,61,NULL,'','GTD0286A','2025-01-01 00:00:00','2022-02-01 00:00:00',57.50,'',50,0,0),(73,62,NULL,'','251021','2024-09-01 00:00:00','2021-10-01 00:00:00',106.78,'',100,0,0),(74,63,NULL,'','GTC2440A','2023-11-01 00:00:00','2021-12-01 00:00:00',94.00,'',50,0,0),(75,64,NULL,'','SB00706','2023-04-01 00:00:00','2020-05-01 00:00:00',155.48,'',260,0,0),(76,65,NULL,'','VPIBE01','2023-07-01 00:00:00','2021-08-01 00:00:00',175.00,'',10,0,0),(77,14,NULL,NULL,'SID1170A','2025-03-01 00:00:00','2022-04-01 00:00:00',72.50,NULL,20,0,0),(78,66,NULL,'','SID0039A','2024-12-01 00:00:00','2022-01-01 00:00:00',112.00,'',20,0,0),(79,67,NULL,'','AFB21F16','2023-07-01 00:00:00','2021-08-01 00:00:00',86.50,'',135,0,0),(80,68,NULL,'','GTC0456A','2023-02-01 00:00:00','2021-03-01 00:00:00',415.00,'',0,0,0),(81,69,NULL,'','1002960','2023-06-01 00:00:00','2020-07-01 00:00:00',27.80,'',620,0,0),(82,62,NULL,NULL,'240921','2024-08-01 00:00:00','2021-09-01 00:00:00',106.78,NULL,120,0,0),(83,70,NULL,'','SID0068A','2024-03-01 00:00:00','2022-01-01 00:00:00',90.94,'',20,0,0),(84,60,NULL,NULL,'GKD0568A','2025-07-01 00:00:00','2022-04-01 00:00:00',42.00,NULL,150,0,0),(85,71,NULL,'','C120638','2025-03-01 00:00:00','2022-04-01 00:00:00',32.36,'',0,0,0),(86,72,NULL,'','GTD0161A','2024-12-01 00:00:00','2022-01-01 00:00:00',77.78,'',50,0,0),(87,73,NULL,'','GTC2291A','2024-10-01 00:00:00','2021-11-01 00:00:00',44.58,'',40,0,0),(88,73,NULL,NULL,'GTD0160A','2024-12-01 00:00:00','2022-01-01 00:00:00',44.58,NULL,10,0,0),(89,74,NULL,'','GTC2034A','2024-09-01 00:00:00','2021-10-01 00:00:00',34.73,'',30,0,0),(90,75,NULL,'','SIC3282A','2024-11-01 00:00:00','2021-12-01 00:00:00',120.00,'',50,0,0),(91,19,NULL,NULL,'GTD0027A','2026-08-01 00:00:00','2022-01-01 00:00:00',15.45,NULL,30,0,0),(92,76,NULL,'','SIC3264B','2023-11-01 00:00:00','2021-12-01 00:00:00',64.00,'',50,0,0),(93,77,NULL,'','T211398','2024-08-01 00:00:00','2021-09-01 00:00:00',108.90,'',0,0,0),(94,78,NULL,'','SIC3316A','2025-01-01 00:00:00','2021-12-01 00:00:00',28.15,'',50,0,0),(95,8,NULL,NULL,'SID1220A','2025-02-01 00:00:00','2022-05-01 00:00:00',80.00,NULL,20,0,0),(96,60,NULL,'','2KPBH005','2023-04-01 00:00:00','2021-05-01 00:00:00',25.25,'',10,0,0),(97,79,NULL,'','T22C713A','2024-02-01 00:00:00','2022-03-01 00:00:00',136.00,'',10,0,0),(98,80,NULL,'','T5519F2','2025-05-01 00:00:00','2022-06-01 00:00:00',55.36,'',10,0,0),(99,81,NULL,'','C1419016','2025-05-01 00:00:00','2022-06-01 00:00:00',600.00,'',71,0,0),(100,82,NULL,'','G21239','2023-11-01 00:00:00','2021-12-01 00:00:00',218.40,'',1,0,0),(101,83,NULL,'','km1718','2023-09-01 00:00:00','2020-10-01 00:00:00',200.00,'',1,0,0),(102,84,NULL,'','NSH0034','2024-01-01 00:00:00','2022-02-01 00:00:00',60.95,'',6,0,0),(103,40,NULL,NULL,'2103042032','2024-09-01 00:00:00','2021-10-01 00:00:00',138.00,NULL,2,0,0),(104,85,NULL,'','G220120505','2026-12-01 00:00:00','2022-01-01 00:00:00',162.00,'',14,0,0),(105,86,NULL,'','071','2026-08-01 00:00:00','2022-09-01 00:00:00',25.00,'',2,0,0),(106,87,NULL,'','9A23S','2023-12-01 00:00:00','2019-01-01 00:00:00',1625.00,'',29,0,0),(107,87,NULL,NULL,'9K11S','2024-08-01 00:00:00','2019-09-01 00:00:00',1625.00,NULL,40,0,0),(108,88,NULL,'','500z','2027-01-01 00:00:00','2022-02-01 00:00:00',45.00,'',70,0,0),(109,89,NULL,'','08034R','2025-01-01 00:00:00','2020-02-01 00:00:00',25.00,'',0,0,0),(110,90,NULL,'','N2103023','2024-11-01 00:00:00','2021-12-01 00:00:00',90.00,'',74,0,0),(111,91,NULL,'','4268091B','2024-01-01 00:00:00','2019-01-06 00:00:00',0.00,'',20,0,0),(112,91,NULL,NULL,'4268091B','2023-10-01 00:00:00','2018-10-07 00:00:00',193.00,NULL,4,0,0),(113,91,NULL,NULL,'83132','2023-07-01 00:00:00','2018-08-01 00:00:00',73.00,NULL,4,0,0),(114,92,NULL,'','','2027-01-01 00:00:00','2022-02-01 00:00:00',290.00,'',5,0,0),(115,93,NULL,'','IH23690','2025-07-01 00:00:00','2022-08-01 00:00:00',56.42,'',7,0,0),(116,94,NULL,'','1D21754','2025-03-01 00:00:00','2022-04-01 00:00:00',38.17,'',2,0,0),(117,95,NULL,'','930L104033','2024-10-01 00:00:00','2021-11-01 00:00:00',31.45,'',0,0,0),(118,93,NULL,NULL,'2203265','2023-07-01 00:00:00','2020-08-01 00:00:00',50.67,NULL,3,0,0),(119,93,NULL,'','39188','2023-08-01 00:00:00','2019-09-01 00:00:00',149.00,'',22,0,0),(120,96,NULL,'','G20082273','2025-07-01 00:00:00','2020-08-01 00:00:00',66.00,'',4,0,0),(121,97,NULL,'','P21B','2026-01-01 00:00:00','2021-02-01 00:00:00',125.00,'',0,0,0),(122,98,NULL,'','P19C05','2024-02-01 00:00:00','2019-03-01 00:00:00',114.00,'',0,0,0),(123,99,NULL,'','P19K06','2024-10-01 00:00:00','2019-11-01 00:00:00',114.00,'',0,0,0),(124,100,NULL,'','G21082','2027-07-01 00:00:00','2021-08-01 00:00:00',167.00,'',0,0,0),(125,101,NULL,'','G21092242','2026-08-01 00:00:00','2021-09-01 00:00:00',167.00,'',0,0,0),(126,102,NULL,'','G20102','2025-09-01 00:00:00','2020-10-01 00:00:00',54.00,'',31,0,0),(127,103,NULL,'','K20012','2024-12-01 00:00:00','2020-01-01 00:00:00',51.00,'',2,0,0),(128,104,'2022-11-30 00:00:00','122000730073594','GKD1564A','2026-04-01 00:00:00','2022-09-01 00:00:00',28.83,'KIMS Medical Agencies Kottakkal',323,0,0),(129,104,'2022-11-30 00:00:00','22000730073594','GKD0388a','2025-07-01 00:00:00','2022-02-01 00:00:00',26.09,'KIMS Medical Agencies Kottakkal',0,0,0),(130,14,'2022-11-30 00:00:00','22000730073594','SID1586A','2025-05-01 00:00:00','2022-06-01 00:00:00',72.50,'KIMS Medical Agencies Kottakkal',500,0,0),(131,15,'2022-11-30 00:00:00','22000730073594','SID1954A','2024-07-01 00:00:00','2022-08-01 00:00:00',227.00,'KIMS Medical Agencies Kottakkal',500,0,0),(132,105,'2022-11-30 00:00:00','22000730074097','SB20989','2025-02-01 00:00:00','2022-09-01 00:00:00',99.45,'BISMIK MEDICAL AGENCIES KOTTAKKAL',240,0,0),(133,106,'2022-11-30 00:00:00','22000730074097','SA22681','2024-06-01 00:00:00','2022-09-01 00:00:00',222.27,'BISMIK MEDICAL AGENCIES KOTTAKKAL',30,0,0),(134,107,'2022-11-30 00:00:00','22000730074097','E0226','2024-06-01 00:00:00','2022-07-01 00:00:00',14.78,'BISMIK MEDICAL AGENCIES KOTTAKKAL',250,0,0),(135,108,'2022-11-30 00:00:00','22000730021628','PX8AD06','2024-08-01 00:00:00','2021-09-01 00:00:00',59.80,'KIMS PHARMA KOTTAKKAL',480,0,0),(136,109,'2022-11-01 00:00:00','22000730021628','T220705','2024-05-01 00:00:00','2022-06-01 00:00:00',49.50,'KIMS PHARMA KOTTAKKAL',220,0,0),(137,110,'2022-11-30 00:00:00','22000730021628','203143675S','2026-07-01 00:00:00','2022-06-01 00:00:00',90.00,'KIMS PHARMA KOTTAKKAL',0,0,0),(138,111,'2022-11-30 00:00:00','22000730021628','PPKAM26','2024-06-01 00:00:00','2022-07-01 00:00:00',132.00,'KIMS PHARMA KOTTAKKAL',220,0,0),(139,112,'2022-11-30 00:00:00','22000730021628','T20480A','2026-05-01 00:00:00','2022-06-01 00:00:00',13.25,'KIMS PHARMA KOTTAKKAL',450,0,0),(140,92,'2022-11-30 00:00:00','22000730021628','G220950103','2026-08-01 00:00:00','2022-09-01 00:00:00',316.00,'KIMS PHARMA KOTTAKKAL',24,0,0),(141,49,'2022-11-30 00:00:00','22000730021628','242203NJH2','2023-09-01 00:00:00','2022-10-01 00:00:00',25.00,'KIMS PHARMA KOTTAKKAL',24,0,0),(142,113,'2022-11-30 00:00:00','22000730021628','MET22040SL','2023-08-01 00:00:00','2022-09-01 00:00:00',23.75,'KIMS PHARMA KOTTAKKAL',765,0,0),(143,114,'2022-11-30 00:00:00','22000730021628','STE21114','2023-11-01 00:00:00','2021-12-01 00:00:00',92.98,'KIMS PHARMA KOTTAKKAL',90,0,0),(144,115,'2022-11-30 00:00:00','22000730021628','PCH0179','2024-01-01 00:00:00','2022-02-01 00:00:00',119.79,'KIMS PHARMA KOTTAKKAL',170,0,0),(145,116,'2022-11-30 00:00:00','22000730021628','208770S','2023-07-01 00:00:00','2022-08-01 00:00:00',1100.00,'KIMS PHARMA KOTTAKKAL',7,0,0),(146,117,'2022-11-30 00:00:00','22000730021628','G236','2024-05-01 00:00:00','2022-06-01 00:00:00',75.00,'KIMS PHARMA KOTTAKKAL',9,0,0),(147,95,'2022-11-30 00:00:00','22000730021628','PT22NS0189','2024-08-01 00:00:00','2022-09-01 00:00:00',34.83,'KIMS PHARMA KOTTAKKAL',7,0,0),(148,94,'2022-11-30 00:00:00','22000730021628','1324694','2025-09-01 00:00:00','2022-10-01 00:00:00',38.17,'KIMS PHARMA KOTTAKKAL',10,0,0),(149,118,'2022-12-10 00:00:00','22000730022487','G220920626','2027-08-01 00:00:00','2022-09-01 00:00:00',70.00,'KIMS PHARMA KOTTAKKAL',36,0,0),(150,119,'2022-12-10 00:00:00','22000730022487','G220920626','2025-04-01 00:00:00','2022-04-01 00:00:00',100.00,'kiMS pHARMA KOTTAKKAL',10,0,0),(151,10,NULL,NULL,'ICH0023','2023-12-01 00:00:00','2022-01-01 00:00:00',0.00,NULL,128,0,0),(152,10,NULL,NULL,'TW2101','2023-02-01 00:00:00','2021-03-01 00:00:00',0.00,NULL,17,0,0),(153,120,NULL,'','TW2101','2023-02-01 00:00:00','2021-03-01 00:00:00',0.00,'',0,0,0),(154,121,NULL,'','AKG 21039','2024-09-01 00:00:00','2021-10-01 00:00:00',0.00,'',0,0,0),(155,121,NULL,NULL,'ACG21003','2024-01-01 00:00:00','2021-02-01 00:00:00',0.00,NULL,0,0,0),(156,121,NULL,NULL,'AKG21023','2024-06-01 00:00:00','2021-07-01 00:00:00',0.00,NULL,0,0,0),(157,121,NULL,NULL,'AKG21029','2024-07-01 00:00:00','2021-08-01 00:00:00',0.00,NULL,0,0,0),(158,121,NULL,'','AKG21040','2024-09-01 00:00:00','2021-10-01 00:00:00',0.00,NULL,0,0,0),(159,122,NULL,'','SGVC0001','2023-12-01 00:00:00','2022-01-01 00:00:00',0.00,'',0,0,0),(160,32,NULL,NULL,'C120678','2025-03-01 00:00:00','2022-04-01 00:00:00',0.00,NULL,6,0,0),(161,67,NULL,NULL,'AFB21F16','2023-07-01 00:00:00','2021-08-01 00:00:00',0.00,NULL,30,0,0),(162,123,NULL,'','FRU2008','2023-06-01 00:00:00','2020-07-01 00:00:00',0.00,'',0,0,0),(163,123,NULL,NULL,'INA0056','2024-01-01 00:00:00','2021-10-01 00:00:00',0.00,NULL,0,0,0),(164,123,NULL,NULL,'2PO576A','2023-05-01 00:00:00','2022-06-01 00:00:00',0.00,NULL,0,0,0),(165,123,NULL,NULL,'INA0038','2024-06-01 00:00:00','2021-07-01 00:00:00',0.00,NULL,0,0,0),(166,123,NULL,NULL,'INA0051','2024-07-01 00:00:00','2021-08-01 00:00:00',0.00,NULL,0,0,0),(167,123,NULL,NULL,'INA0033','2024-04-01 00:00:00','2021-05-01 00:00:00',0.00,NULL,0,0,0),(168,123,NULL,NULL,'ONA0064','2023-11-01 00:00:00','2020-12-01 00:00:00',0.00,NULL,0,0,0),(169,123,NULL,NULL,'MF021006','2024-06-01 00:00:00','2021-07-01 00:00:00',0.00,NULL,19,0,0),(170,124,NULL,'','MF021006','2024-06-01 00:00:00','2021-07-01 00:00:00',0.00,'',0,0,0),(171,27,NULL,NULL,'T211827','2023-10-01 00:00:00','2021-11-01 00:00:00',0.00,NULL,30,0,0),(172,125,NULL,'','INA0083','2024-10-01 00:00:00','2021-11-01 00:00:00',0.00,'',0,0,0),(173,126,NULL,'','SN20151','2024-12-01 00:00:00','2022-01-01 00:00:00',0.00,'',0,0,0),(174,118,'2023-01-02 00:00:00','22000730024405','G220820861','2027-07-01 00:00:00','2022-08-01 00:00:00',650.50,'KIMS PHARMA',11,0,0),(175,127,'2023-01-02 00:00:00','22000730024405','G220820861','2027-07-01 00:00:00','2022-08-01 00:00:00',650.50,'KIMS PHARMA',25,0,0),(176,46,'2023-01-02 00:00:00','22000730024405','G220820861','2025-09-01 00:00:00','2022-10-01 00:00:00',1007.00,'KIMS PHARMA',0,0,0),(177,126,NULL,NULL,'SN00780','2023-04-01 00:00:00','2020-05-01 00:00:00',0.00,NULL,0,0,0),(178,128,NULL,'','RV22012','2024-04-01 00:00:00','2022-05-01 00:00:00',0.00,'',0,0,0),(179,112,NULL,NULL,'T20480A','2024-02-01 00:00:00','2022-06-01 00:00:00',0.00,NULL,0,0,0),(180,129,NULL,'','SA9876','2024-03-01 00:00:00','2022-04-01 00:00:00',0.00,'',0,0,0),(181,130,NULL,'','1201632','2024-09-01 00:00:00','2022-04-01 00:00:00',0.00,'',0,0,0),(182,131,NULL,'','C0031/21','2023-09-01 00:00:00','2021-10-01 00:00:00',0.00,'',0,0,0),(183,132,NULL,'','N1994','2023-10-01 00:00:00','2021-11-01 00:00:00',0.00,'',0,0,0),(184,133,NULL,'','SID1384A','2024-04-01 00:00:00','2022-05-01 00:00:00',0.00,'',0,0,0),(185,134,NULL,'','MA457','2023-09-01 00:00:00','2022-04-01 00:00:00',0.00,'',0,0,0),(186,135,NULL,'','GTD0237A','2025-01-01 00:00:00','2022-02-01 00:00:00',0.00,'',0,0,0),(187,71,NULL,NULL,'C120638','2025-03-01 00:00:00','2022-04-01 00:00:00',0.00,NULL,20,0,0),(188,136,NULL,'','I003566','2023-08-01 00:00:00','2020-09-01 00:00:00',0.00,'',0,0,0),(189,137,NULL,'','TM89157','2023-06-01 00:00:00','2019-07-01 00:00:00',0.00,'',0,0,0),(190,138,NULL,'','ADG0069','2024-04-01 00:00:00','2021-05-01 00:00:00',0.00,'',0,0,0),(191,139,NULL,'','01520001','2023-02-01 00:00:00','2020-03-01 00:00:00',0.00,'',0,0,0),(192,140,NULL,'','2010C84207','2023-12-01 00:00:00','2022-01-01 00:00:00',0.00,'',0,0,0),(193,140,NULL,NULL,'1312C84201','2023-10-01 00:00:00','2021-11-01 00:00:00',0.00,NULL,0,0,0),(194,29,NULL,NULL,'TAAD2002A','2023-12-01 00:00:00','2022-01-01 00:00:00',0.00,NULL,30,0,0),(195,141,NULL,'','TRIX2202','2024-01-01 00:00:00','2022-02-01 00:00:00',0.00,'',0,0,0),(196,142,NULL,'','DFD2636A','2024-05-01 00:00:00','2022-06-01 00:00:00',0.00,'',0,0,0),(197,143,NULL,'','MFH0213','2024-02-01 00:00:00','2022-03-01 00:00:00',0.00,'',0,0,0),(198,144,NULL,'','STC21529','2024-11-01 00:00:00','2021-12-01 00:00:00',0.00,'',0,0,0),(199,3,NULL,NULL,'ALT220163','2024-01-01 00:00:00','2022-02-01 00:00:00',0.00,NULL,26,0,0),(200,145,NULL,'','2E09H020','2024-11-01 00:00:00','2021-12-01 00:00:00',0.00,'',0,0,0),(201,146,NULL,'','K2101795','2023-08-01 00:00:00','2021-09-01 00:00:00',0.00,'',0,0,0),(202,147,NULL,'','GTC2417A','2024-08-01 00:00:00','2021-12-01 00:00:00',0.00,'',0,0,0),(203,42,NULL,NULL,'22090790','2024-05-01 00:00:00','2022-06-01 00:00:00',0.00,NULL,3,0,0),(204,41,NULL,NULL,'11220254','2024-01-01 00:00:00','2022-02-01 00:00:00',0.00,NULL,2,0,0),(205,41,NULL,NULL,'11220070','2023-12-01 00:00:00','2022-01-01 00:00:00',0.00,NULL,0,0,0),(206,148,NULL,'','AHH0098','2023-09-01 00:00:00','2022-04-01 00:00:00',0.00,'',0,0,0),(207,149,NULL,'','FR202','2025-01-01 00:00:00','2022-02-01 00:00:00',0.00,'',0,0,0),(208,150,NULL,'','1289C59908','2023-05-01 00:00:00','2021-10-01 00:00:00',0.00,'',0,0,0),(209,150,NULL,NULL,'A21AM365','2023-06-01 00:00:00','2021-12-01 00:00:00',0.00,NULL,0,0,0),(210,151,NULL,'','2121041','2024-02-01 00:00:00','2021-03-01 00:00:00',0.00,'',0,0,0),(211,151,NULL,NULL,'2121161','2024-09-01 00:00:00','2021-10-01 00:00:00',0.00,NULL,0,0,0),(212,152,NULL,'','KMO38012','2023-07-01 00:00:00','2021-08-01 00:00:00',0.00,'',0,0,0),(213,153,NULL,'','6104039','2025-07-01 00:00:00','2021-10-01 00:00:00',0.00,'',0,0,0),(214,154,NULL,'','A000212','2024-03-01 00:00:00','2020-04-01 00:00:00',0.00,'',0,0,0),(215,154,NULL,NULL,'L60099','2023-01-01 00:00:00','2020-02-01 00:00:00',0.00,NULL,0,0,0),(216,155,NULL,'','HAA2CBA4','2023-02-01 00:00:00','2020-03-01 00:00:00',0.00,'',0,0,0),(217,156,NULL,'','2203042030','2025-08-01 00:00:00','2022-09-01 00:00:00',0.00,'',0,0,0),(218,156,NULL,NULL,'2103042032','2024-09-01 00:00:00','2021-10-01 00:00:00',0.00,NULL,0,0,0),(219,157,NULL,'','93RD107003','2025-03-01 00:00:00','2022-04-01 00:00:00',0.00,'',0,0,0),(220,158,NULL,'','215502','2023-08-01 00:00:00','2021-09-01 00:00:00',0.00,'',0,0,0),(221,159,NULL,'','224017','2023-12-01 00:00:00','2022-01-01 00:00:00',0.00,'',0,0,0),(222,159,NULL,NULL,'ID21754','2025-03-01 00:00:00','2022-04-01 00:00:00',0.00,NULL,0,0,0),(223,160,NULL,'','1H23690','2025-07-01 00:00:00','2022-08-01 00:00:00',0.00,'',0,0,0),(224,161,NULL,'','ABG0052','2024-02-01 00:00:00','2021-03-01 00:00:00',0.00,'',0,0,0),(225,162,NULL,'','82PL409105','2023-10-01 00:00:00','2020-11-01 00:00:00',0.00,'',0,0,0),(226,163,NULL,'','ABG0186','2024-05-01 00:00:00','2021-06-01 00:00:00',0.00,'',0,0,0),(227,163,NULL,NULL,'93QG404084','2024-06-01 00:00:00','2021-07-01 00:00:00',0.00,NULL,0,0,0),(228,98,'2023-01-18 00:00:00','22000730025806','P21D04','2026-03-01 00:00:00','2021-04-01 00:00:00',1250.00,'KIMS PHARMA',20,0,0),(229,97,'2023-01-18 00:00:00','22000730025806','P21H07','2026-07-01 00:00:00','2021-08-01 00:00:00',1250.00,'KIMS PHARMA',20,0,0),(230,46,'2023-01-18 00:00:00','22000730025806','AC063/22 RAMRAJ','2025-09-01 00:00:00','2022-10-01 00:00:00',347.00,'KIMS PHARMA',5,0,0),(231,164,'2023-01-18 00:00:00','22000730025806','G22115009','2026-10-01 00:00:00','2022-11-01 00:00:00',316.00,'KIMS PHARMA',50,0,0),(232,165,'2023-01-18 00:00:00','22000730025806','ADH0086','2025-04-01 00:00:00','2022-05-01 00:00:00',19.69,'KIMS PHARMA',350,0,0),(233,49,'2023-01-18 00:00:00','22000730025806','242203NJH2','2027-09-01 00:00:00','2022-10-01 00:00:00',25.00,'KIMS PHARMA',25,0,0),(234,82,'2023-01-18 00:00:00','22000730025806','MW22027','2024-08-01 00:00:00','2022-09-01 00:00:00',238.49,'KIMS PHARMA',1,0,0),(235,166,'2023-01-18 00:00:00','22000730025806','1G22863','2025-06-01 00:00:00','2022-07-01 00:00:00',34.93,'KIMS PHARMA',5,0,0),(236,167,'2023-01-18 00:00:00','22000730025806','HCL2222','2025-07-01 00:00:00','2022-08-01 00:00:00',86.46,'KIMS PHARMA',240,0,0),(237,168,'2023-01-18 00:00:00','22000730025806','77058','2023-11-01 00:00:00','2022-06-01 00:00:00',37.50,'KIMS PHARMA',100,0,0),(238,71,'2023-01-18 00:00:00','22000730025806','C110672','2024-05-01 00:00:00','2021-06-01 00:00:00',56.89,'KIMS PHARMA',200,0,0),(239,169,'2023-01-18 00:00:00','22000730025806','C110672','2024-05-01 00:00:00','2021-06-01 00:00:00',56.89,'KIMS PHARMA',180,0,0),(240,71,'2023-01-18 00:00:00','22000730025806','001A22AV','2023-12-01 00:00:00','2022-01-01 00:00:00',774.00,'KIMS PHARMA',240,0,0),(241,170,'2023-01-18 00:00:00','22000730025806','MRT1734','2023-10-01 00:00:00','2021-11-01 00:00:00',31.00,'KIMS PHARMA',105,0,0),(242,171,'2023-01-18 00:00:00','22000730025806','9018','2027-06-01 00:00:00','2022-07-01 00:00:00',349.00,'KIMS PHARMA',100,0,0),(243,172,'2023-01-18 00:00:00','22000730025806','520','2024-02-01 00:00:00','2022-09-01 00:00:00',849.00,'KIMS PHARMA',0,0,0),(244,173,'2023-01-18 00:00:00','22000730025806','WEJ0209WIFI','2025-09-01 00:00:00','2022-10-01 00:00:00',144.00,'KIMS PHARMA',150,0,0),(245,174,'2023-01-18 00:00:00','22000730025806','40151900','2025-04-01 00:00:00','2020-05-01 00:00:00',70.00,'KIMS PHARMA',50,0,0),(246,173,'2023-01-21 00:00:00','22000730026084','G220220593','2027-01-01 00:00:00','2022-02-01 00:00:00',70.00,'KIMS PHARMA',100,0,0),(247,175,'2023-01-21 00:00:00','22000730026084','G220220593','2027-01-01 00:00:00','2022-02-01 00:00:00',70.00,'KIMS PHARMA',37,0,0),(248,176,'2023-01-23 00:00:00','22000730089686','SID0918A','2025-03-01 00:00:00','2022-04-01 00:00:00',89.30,'KIMS MEDICAL  AGENCIES',100,0,0),(249,20,'2023-01-23 00:00:00','22000730089686','SID2011A','2024-07-01 00:00:00','2022-08-01 00:00:00',193.08,'KIMS MEDICAL AGENCIES',145,0,0),(250,177,'2023-01-23 00:00:00','2200730089686','N2203194N','2025-10-01 00:00:00','2022-11-01 00:00:00',88.48,'KIMS MEDICAL AGENCIES',270,0,0);
/*!40000 ALTER TABLE `medicinepurchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicinestock`
--

DROP TABLE IF EXISTS `medicinestock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicinestock` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `MedicineId` int NOT NULL,
  `Main` int DEFAULT NULL,
  `Sub` int DEFAULT NULL,
  `A_kit` int DEFAULT NULL,
  `B_kit` int DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `medicinestock_medicine_idx` (`MedicineId`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicinestock`
--

LOCK TABLES `medicinestock` WRITE;
/*!40000 ALTER TABLE `medicinestock` DISABLE KEYS */;
INSERT INTO `medicinestock` VALUES (1,1,700,0,0,0),(2,2,0,0,225,0),(3,3,330,0,26,0),(4,4,340,0,0,0),(5,5,29,0,0,0),(6,6,0,0,36,0),(7,7,435,0,75,0),(8,8,60,0,60,0),(9,9,100,0,0,0),(10,10,467,0,128,0),(11,11,70,0,0,0),(12,12,140,0,0,0),(13,13,220,0,0,0),(14,14,700,0,60,0),(15,15,510,0,90,0),(16,16,20,0,0,0),(17,17,2,0,0,0),(18,18,4,0,0,0),(19,19,40,0,0,0),(20,20,145,0,0,0),(21,21,2,0,0,0),(22,22,50,0,50,0),(23,23,70,30,0,0),(24,24,100,0,0,0),(25,25,0,0,0,0),(26,26,225,0,0,0),(27,27,300,0,30,0),(28,28,80,0,0,0),(29,29,30,-64,118,0),(30,30,180,0,0,0),(31,31,70,0,30,0),(32,32,45,0,6,0),(33,33,9,0,7,0),(34,34,0,0,67,0),(35,35,50,0,0,0),(36,36,30,0,0,0),(37,37,20,0,0,0),(38,38,5,0,0,0),(39,39,10,0,0,0),(40,40,6,0,0,0),(41,41,2,0,6,0),(42,42,21,0,3,0),(43,43,5,0,8,0),(44,44,6,0,0,0),(45,45,0,0,29,0),(46,46,5,0,6,0),(47,47,100,0,0,0),(48,48,87,0,0,0),(49,49,59,0,0,0),(50,50,199,0,11,0),(51,51,50,0,0,0),(52,52,150,0,0,0),(53,53,50,0,0,0),(54,54,90,30,90,0),(55,55,149,0,0,0),(56,56,50,0,0,0),(57,57,115,0,75,0),(58,58,20,0,0,0),(59,59,50,0,0,0),(60,60,190,0,0,0),(61,61,50,0,0,0),(62,62,220,0,0,0),(63,63,50,0,0,0),(64,64,260,0,0,0),(65,65,10,0,60,0),(66,66,20,0,0,0),(67,67,165,0,30,0),(68,68,0,0,30,0),(69,69,620,0,0,0),(70,70,20,0,0,0),(71,71,460,0,220,0),(72,72,50,0,0,0),(73,73,50,0,0,0),(74,74,30,0,0,0),(75,75,50,0,0,0),(76,76,50,0,0,0),(77,77,0,0,20,0),(78,78,50,0,0,0),(79,79,10,0,0,0),(80,80,10,0,0,0),(81,81,71,0,0,0),(82,82,2,0,1,0),(83,83,1,0,0,0),(84,84,6,0,0,0),(85,85,14,0,11,0),(86,86,2,0,0,0),(87,87,69,0,0,0),(88,88,70,0,0,0),(89,89,0,0,50,0),(90,90,74,0,15,0),(91,91,28,0,0,0),(92,92,29,0,0,0),(93,93,32,0,0,0),(94,94,12,0,0,0),(95,95,7,0,7,0),(96,96,4,0,0,0),(97,97,20,0,10,0),(98,98,20,0,3,0),(99,99,0,0,2,0),(100,100,0,0,2,0),(101,101,0,0,1,0),(102,102,31,0,0,0),(103,103,2,0,0,0),(104,104,323,0,37,0),(105,105,240,0,0,0),(106,106,30,0,60,0),(107,107,250,0,0,0),(108,108,480,0,180,0),(109,109,220,0,0,0),(110,110,0,0,46,0),(111,111,220,0,0,0),(112,112,450,0,200,0),(113,113,765,0,135,0),(114,114,90,0,180,0),(115,115,170,0,50,0),(116,116,7,0,5,0),(117,117,9,0,9,0),(118,118,47,0,103,0),(119,119,10,0,30,0),(120,120,0,0,17,0),(121,121,0,0,184,0),(122,122,0,0,18,0),(123,123,19,0,92,0),(124,124,0,0,19,0),(125,125,0,0,20,0),(126,126,0,0,109,0),(127,127,25,0,25,0),(128,128,0,0,20,0),(129,129,0,0,110,0),(130,130,0,0,114,0),(131,131,0,0,30,0),(132,132,0,0,50,0),(133,133,0,0,8,0),(134,134,0,0,77,0),(135,135,0,0,30,0),(136,136,0,0,51,0),(137,137,0,0,15,0),(138,138,0,0,40,0),(139,139,0,0,10,0),(140,140,0,0,126,0),(141,141,0,0,6,0),(142,142,0,0,7,0),(143,143,0,0,15,0),(144,144,0,0,50,0),(145,145,0,0,29,0),(146,146,0,0,100,0),(147,147,0,0,20,0),(148,148,0,0,6,0),(149,149,0,0,25,0),(150,150,0,0,19,0),(151,151,0,0,3,0),(152,152,0,0,1,0),(153,153,0,0,4,0),(154,154,0,0,3,0),(155,155,0,0,3,0),(156,156,0,0,7,0),(157,157,0,0,1,0),(158,158,0,0,1,0),(159,159,0,0,3,0),(160,160,0,0,2,0),(161,161,0,0,4,0),(162,162,0,0,1,0),(163,163,0,0,2,0),(164,164,50,0,0,0),(165,165,350,0,130,0),(166,166,5,0,0,0),(167,167,240,0,0,0),(168,168,100,0,0,0),(169,169,180,0,20,0),(170,170,105,0,0,0),(171,171,100,0,100,0),(172,172,0,0,50,0),(173,173,250,0,0,0),(174,174,50,0,0,0),(175,175,37,0,63,0),(176,176,100,0,0,0),(177,177,270,0,0,0);
/*!40000 ALTER TABLE `medicinestock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `op`
--

DROP TABLE IF EXISTS `op`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `op` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `PatientId` int DEFAULT NULL,
  `History` longblob,
  `Medicine` longblob,
  `Remarks` longblob,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `op`
--

LOCK TABLES `op` WRITE;
/*!40000 ALTER TABLE `op` DISABLE KEYS */;
/*!40000 ALTER TABLE `op` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `panjayath`
--

DROP TABLE IF EXISTS `panjayath`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `panjayath` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `panjayath`
--

LOCK TABLES `panjayath` WRITE;
/*!40000 ALTER TABLE `panjayath` DISABLE KEYS */;
INSERT INTO `panjayath` VALUES (1,'Mangalam'),(2,'Thriprangode'),(3,'Purathoor');
/*!40000 ALTER TABLE `panjayath` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `PNo` varchar(45) DEFAULT NULL,
  `Name` varchar(200) DEFAULT NULL,
  `Age` varchar(45) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Grade` varchar(45) DEFAULT NULL,
  `Gender` varchar(45) DEFAULT NULL,
  `Panjayath` varchar(100) DEFAULT NULL,
  `WardNo` varchar(45) DEFAULT NULL,
  `Phone1` varchar(45) DEFAULT NULL,
  `Phone2` varchar(45) DEFAULT NULL,
  `RegDate` datetime DEFAULT NULL,
  `ExpDate` datetime DEFAULT NULL,
  `DropDate` datetime DEFAULT NULL,
  `Volunteer` varchar(100) DEFAULT NULL,
  `Diagnosis` varchar(100) DEFAULT NULL,
  `Temp` tinyint DEFAULT NULL,
  `Route` varchar(100) DEFAULT NULL,
  `HomeCarePlan` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `PNo_UNIQUE` (`PNo`)
) ENGINE=InnoDB AUTO_INCREMENT=235 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES (4,'37/2021','KAMMUKUTTY','62','VAKKAYIL  HOUSE\nPAYYAPPADAM\nMANGALAM','Grade B','M','Mangalam','3','9400011841','8089951036','2021-08-19 00:00:00',NULL,NULL,'FOUSIYA','CAD',0,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY',''),(5,'85/2019','AMINA','88','VAKKAYIL HOUSE\nPAYYAPADAM\nMANGALAM','Grade B','F','Mangalam','3','9847654121','9656996672','2019-10-21 00:00:00',NULL,NULL,'FOUSIYA','CVA',0,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY',''),(6,'92/2015','SATHI','45','kovayil house\npunnamana\nmangalam','Grade C','F','Mangalam','3','9495291565','','2015-11-19 00:00:00',NULL,NULL,'','COPD ,HTN',0,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY',''),(7,'81/2019','SASIDHARAN','67','Achikkulath house\npunnamana\nmangalam','Grade B','M','Mangalam','3','9495094506','9447277248','2019-09-30 00:00:00',NULL,NULL,'Naseetha','CA LUNG&BRAIN MTS,Rt ouipital lobe',0,'PUNNAMANA-KUTTAMMAKKAL -PAYYAPADAM',''),(8,'28/2022','ABOOBACKER','75','CHAKKUNGAPARAMBIL HOUSE\nKUTTAMMAKKAL\nMANGALAM (P.O)\n','Grade A','M','TRIPRANGODE','17','9656669358','8547201406','2022-04-12 00:00:00','2022-05-26 00:00:00',NULL,'','K/C/O OLD CVA,HTN,PD,COPD.CKD.PARKINSONISM',0,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY',''),(9,'37/2015','AMINA','58','KULANGARAVEETIL HOUSE\nPAYYAPADAM\nMANGALAM','Grade B','F','Mangalam','3','04942569912','','2015-06-28 00:00:00',NULL,NULL,'','CVA,HTN',0,'PUNNAMANA-KUTTAMMAKKAL -PAYYAPADAM',''),(10,'70/2021','AMINA','66','KUTTERY HOUSE\nPUNNAMANA\nMANGALAM','Grade A','F','Mangalam','3','7567857382','8304976017','2021-12-23 00:00:00',NULL,NULL,'NOUFAL','CAD,T2DM.HTN,DLP,COVID PNEUMONIA',0,'PUNNAMANA-KUTTAMMAKKAL -PAYYAPADAM',''),(11,'22/2016','HAMZA','85','MAMMAKANAKATH HOUSE\nPUNNAMANA\nMANGALAM','Grade C','M','Mangalam','3','9645025322','7559866488','2016-02-23 00:00:00',NULL,NULL,'','HTN,DM',0,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY',''),(12,'121/2017','IYYATHUTTY','59','KARATTUKADAVATH HOUSE\nCHERIYACHAMVEETIL KATIYAKADAVATH(H)\nMANGALAM ANGADI','Grade C','F','Mangalam','6','9746897002','7994808833','2017-10-02 00:00:00',NULL,NULL,'','PARKINSONISM,HTN,DM',0,'MANGALAM',''),(13,'47/2021','HYDER','90','\n\nCHEMBALANKADAVATH HOUSE\nMANGALAM ANGADI','Grade A','M','Mangalam','6','8943100800','9562667775','2021-09-21 00:00:00','2022-07-22 00:00:00',NULL,'JASEER','HTN',0,'MANGALAM',''),(14,'150/2017','MOHANAN','50','KARIYAMTHIRUTHI HOUSE\nHARIJAN COLONY\nPULLOONI','Grade B','M','Mangalam','2','7025076387','','2017-11-21 00:00:00',NULL,NULL,'','CVA,HTN',0,'PULLOONI,ANNASSERI,THALOOKKARA',''),(15,'67/2020','MOIDEEN','75','RAMANALUKKAL HOUSE\nKAIMALASSERI\nTRIPRANGODE\n','Grade B','M','TRIPRANGODE','17','8547119212','8086707880','2020-10-23 00:00:00',NULL,NULL,'','PARKINSONISM,DM,HTN',0,'',''),(16,'80/2018','KALLYANY','55','RAMANALUKKAL PADI\nSYNDICATE\nMANGALAM','Grade B','F','Mangalam','6','8129531959','','2018-10-13 00:00:00',NULL,NULL,'','HEMIPLEGIA(L)',0,'MANGALAM',''),(17,'29/2021','ARUMUGHAN','65','KIZHAKKEPURAKKAL HOUSE\nMANGALAM ANGADI','Grade A','M','Mangalam','5','9995282174','8593083009','2021-07-25 00:00:00',NULL,NULL,'BABU','CVA(Lt),URINE RETENSIER',0,'MANGALAM',''),(18,'29/2022','AYISHAKUTTY','100','VAKKAYILPARAMBIL HOUSE\nMANGALAM','','F','MANGALAM','6','9745052725','9961189011','2022-04-27 00:00:00','2022-09-18 00:00:00',NULL,'','DM,HTN,COPD',0,'MANGALAM',''),(19,'110/2017','CHERIYA','82','CHEMBILATH HOUSE\nKAVANCHERI(Po)\nVAYALIPPADAM','Grade B','F','MANGALAM','10','9895212584','','2017-08-18 00:00:00',NULL,NULL,'','',0,'VALAMARUTHOOR',''),(20,'30/2022','BHARATHAN','61','OTTOLIL THEKKEVALAPPIL HOUSE\nPERUMTHIRUTHI\nCHENNARA','Grade A','M','Mangalam','14','9142031797','7012579070','2022-05-09 00:00:00',NULL,'2022-07-10 00:00:00','','DIABETIC FOOT ULCER',0,'CHENNARA, PERUMTHIRUTHI,KURUMPADI',''),(21,'111/2017','SUDHA','45','CHEMBILATH HOUSE\nKAVANCHERY(PO)\nVAYALIPPADAM','Grade C','F','Mangalam','10','9895212584','','2017-08-18 00:00:00',NULL,NULL,'',' DM',0,'VALAMARUTHOOR,KAVANCHERY,MARAVANTHA',''),(22,'18/2014','SATHI','42','PILAKKULANGARA HOUSE\nKAVANCHERY\nMANGALAM','Grade B','F','Mangalam','10','9539241190','8129004145','2014-05-11 00:00:00',NULL,NULL,'','',0,'VALAMARYTHOOR,KAVANCHERY,MARAVANTHA',''),(23,'29/2017','AYISHA','63','MALIYEKKAL HOUSE\nVALAMARUTHOOR\nMANGALAM','Grade B','F','Mangalam','11','7306139190','','2017-02-23 00:00:00',NULL,NULL,'','CA breast(Rt)',0,'VALAMARUTHOOR,KAVANCHERY,MARAVANTHA',''),(24,'55/2016','VALSALA','53','THEKKUMKARA HOUSE\nVALAMARUTHOOR\nMANGALAM','Grade B','F','Mangalam','9','9847207735','','2016-06-07 00:00:00',NULL,NULL,'','CARCINOMA ENDOMETRIUM',0,'VALAMARUTHOOR,KAVANCHERY,MARAVANTHA',''),(25,'90/2017','FATHIMA','80','KAIPADATH AROTTIL HOUSE\nVALAMARUTHOOR\nMANGALAM','Grade B','F','Mangalam','12','9526533391','9605633686','2017-07-01 00:00:00',NULL,NULL,'','CAD,HTN,UTERINE PROLAPSE',0,'VALAMARUTHOOR,KAVANCHERY,MARAVANTHA',''),(26,'18/2018','SURENDRAN','45','KARIYARATH HOUSE\nILLATHAPADI\nVALAMARUTHOOR','Grade B','M','Mangalam','9','9947334519','9567993544','2018-02-08 00:00:00',NULL,NULL,'','CAD,CKD,DKO,ACUTE PULM EDEMA',0,'VALAMARUTHOOR,KAVANCHERY,MARAVANTHA',''),(27,'51/2021','KUNHIBAVA','81','PATHIRAPALLI HOUSE\nVALAMARUTHOOR\nMANGALAM','Grade B','M','Mangalam','10','9526318525','9544642677','2021-10-06 00:00:00',NULL,NULL,'','POST COVID PNEUMONIA',0,'VALAMARUTHOOR,KAVANCHERY,MARAVANTHA',''),(28,'87/2017','ZUBAIDA','58','KAIPADATH HOUSE\nVALAMARUTHOOR\nMANGALAM','Grade B','F','Mangalam','10','','','2017-06-22 00:00:00',NULL,NULL,'','CAD,T2DM,',0,'VALAMARUTHOOR,KAVANCHERY,MARAVANTHA',''),(29,'13/2022','VELAYUDHAN','63','KONDAYOORPADI HOUSE\nVALAMARUTHOOR','Grade A','M','Mangalam','9','8891203437','8943693682','2022-02-16 00:00:00','2022-09-25 00:00:00',NULL,'SHAMEEMA','DM,HTN,CVA',0,'VALAMARUTHOOR,KAVANCHERY,MARAVANTHA',''),(30,'44/2021','MEENAKSHI','84','KOLOTHUVALAPPIL HOUSE\nPANAPADI ROAD\nVALAMARUTHOOR','Grade A','F','Mangalam','11','9539223316','9539964014','2021-09-16 00:00:00',NULL,NULL,'SADATH','DM,HTN,IHD',0,'VALAMARUTHOOR,KAVANCHERY,MARAVANTHA',''),(31,'120/2016','SREEDHARAN NAIR','73','CHERUPARAMBIL HOUSE\nVALAMARUTHOOR\nMANGALAM','Grade B','M','Mangalam','9','9946196552','04942568753','2016-11-30 00:00:00',NULL,NULL,'','OLD CVA,CAD,DM,SEVERE PROSTATOMEGALY',0,'VALAMARUTHOOR,KAVANCHERY,MARAVANTHA',''),(32,'9/2017','MEENAKSHIAMMA','94','CHERUPARAMBIL HOUSE\nVALAMARUTHOOR\nMANGALAM','Grade B','F','Mangalam','9','04942566119','','2017-01-18 00:00:00',NULL,NULL,'','HTN,CAD',0,'VALAMARUTHOOR,KAVANCHERY,MARAVANTHA',''),(33,'113/2016','NALINI','61','PULPATTA VARIATH HOUSE\nVALAMARUTHOOR','Grade B','F','Mangalam','9','04942565241','','2016-11-14 00:00:00','2023-01-25 00:00:00',NULL,'','HTN,DM,CAD',0,'VALAMARUTHOOR,KAVANCHERY,MARAVANTHA',''),(34,'112/2018','IYYATHUTTY','62','KALLERI HOUSE\nW/O:MOIDEENKUTTY(Late)\nSYNDICATE\nMANGALAM','Grade A','F','Mangalam','6','','','2018-12-25 00:00:00',NULL,NULL,'','CA Lung',0,'MANGALAM',''),(35,'86/2015','PATHUMMAKUTTY(KUNHIMMA)','50','THAYATTIL HOUSE\nVALAMARUTHOOR\nKAVANCHERY','Grade A','F','Mangalam','10','8547081217','8301846085','2015-11-10 00:00:00',NULL,NULL,'','PSY',0,'VALAMARUTHOOR,KAVANCHERY,MARAVANTHA',''),(36,'54/2015','SYAMALA','58','CHERUPARAMBIL HOUSE\nVALAMARUTHOOR','Grade C','F','Mangalam','9','9526136142','04942566119','2015-08-16 00:00:00',NULL,NULL,'','CA breast,(Rt)',0,'VALAMARUTHOOR,KAVANCHERY,MARAVANTHA',''),(37,'55/2018','HAMSA','56','VELUTHATTIL HOUSE\nVAYALIPADAM\nVALAMARUTHOOR','Grade A','M','Mangalam','6','8943107685','','2018-07-28 00:00:00','2022-10-07 00:00:00',NULL,'','ANAPLASTIC ASTROCYTOMA(Lt),CVA(Rt)',0,'VALAMARUTHOOR,KAVANCHERY,MARAVANTHA',''),(38,'95/2019','HALEEMA BEEVI','68','MEKATTUKALATHIL HOUSE\nSINDICATE\nVAYALIPADAM','Grade B','F','Mangalam','8','9995665914','','2019-12-25 00:00:00',NULL,NULL,'','CVA,HTN,ASTHMA,HEMIPLEGIA',0,'VALAMARUTHOOR,KAVANCHERY,MARAVANTHA',''),(39,'37/2020','BALAMANI AMMA','77','KALARIKKAL HOUSE\nVALAMARUTHOOR\nKAVANCHERY','Grade A','F','Mangalam','12','9539530806','9048481383','2020-07-05 00:00:00','2022-05-25 00:00:00',NULL,'SADATH','MULTIPLE MILOMEA,ASPIRATION PNEUMONIA',0,'VALAMARUTHOOR,KAVANCHERY,MARAVANTHA',''),(40,'83/2018','KALI','70','PANAPADIKKAL HOUSE\nKAVANCHERY(Po)\nVALAMARUTHOOR','Grade A','F','MANGALAM','10','9744913761','','2018-10-08 00:00:00',NULL,NULL,'','CVA(Lt),HEMIPLEGIA',0,'VAYALIPADAM,VALAMARUTHOOR',''),(41,'58/2017','KARTHIAYANI','85','KOLOTHUVALAPPIL HOUSE\nKAVANCHERY','Grade B','F','Mangalam','11','9497003877','','2017-05-02 00:00:00',NULL,NULL,'','OLD CVA(Rt),COPD,CAD',0,'KAVANCHERY,MARAVANTHA',''),(42,'94/2019','JIOTHI','43','KOZHISSERY HOUSE\nVAYALIPADAM\n','Grade C','F','Mangalam','8','948881167','','2019-12-21 00:00:00',NULL,NULL,'','CKD',0,'VAYALIPADAM,VALAMARUTHOOR',''),(43,'74/2017','PATHUMMU','84','THUPPATH HOUSE\nVALAMARUTHOOR','Grade B','F','Mangalam','10','8943579966','9946868066','2017-06-07 00:00:00',NULL,NULL,'','CA Aluiola',0,'VAYALIPADAM,VALAMARUTHOOR',''),(44,'81/2015','MOHAMED KUTTY','63','PARAVANNA KAMMAKANAKATH HOUSE\nKAVANCHERY','Grade B','M','Mangalam','10','9048719940','9947594708','2015-10-22 00:00:00','2022-09-18 00:00:00',NULL,'','CVA Recurrent,CA Sigmend Column,COPD',0,'KAVANCHERY,MARAVANTHA',''),(45,'03/2022','BEEKUTTY','86','VAKKALATH HOUSE\nKAVANCHERY','Grade B','F','Mangalam','11','8943454048','9961476389','2022-01-08 00:00:00',NULL,NULL,'SADATH','POST COVID PNEUMONIA,COPD,HTN',0,'KAVANCHERY,MARAVANTHA',''),(46,'64/2021','NAFEESA','80','KUTTISSERY VALAPPIL HOUSE\nKAVANCHERY','Grade A','F','Mangalam','11','9048552918','9946527699','2021-11-11 00:00:00',NULL,NULL,'SADATH','CVA(Rt),HTN,CAD',0,'KAVANCHERY,MARAVANTHA',''),(47,'79/2018','ALIKKUTTY HAJI','90','KAKKIDIPOOPARAMBIL HOUSE\nMARAVANTHA\nPURATHOOR','Grade B','M','Purathoor','5','8606383872','9539395968','2018-10-03 00:00:00',NULL,NULL,'','COPD,HTN',0,'KAVANCHERY,MARAVANTHA',''),(48,'108/2017','MARIYAKKUTTY','83','KAKKIDIPOOPARAMBIL HHOUSE\nMARAVANTHA\nPURATHOOR','Grade B','F','Purathoor','5','8606383872','9539395968','2017-08-11 00:00:00','2022-11-30 00:00:00',NULL,'','CAD,DM,PARKINSONISM,OSTEOPOROSIS',0,'KAVANCHERY,MARAVANTHA',''),(49,'26/2016','ABDURAHMAN','50','MATHOOR HOUSE\nDAM ROAD\nKAVANCHERY','Grade B','M','Mangalam','10','8593968633','','2016-03-10 00:00:00',NULL,NULL,'','CVA(Rt)',0,'KAVANCHERY,MARAVANTHA',''),(50,'53/2021','KHADEEJA','92','KAVUMPURATH HOUSE\nKOOTAI ROAD\nMANGALAM','Grade B','F','Mangalam','5','9946765153','9747082002','2021-10-14 00:00:00','2022-07-05 00:00:00',NULL,'MAJEED.K.V','CVA(Rt)',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU',''),(51,'40/2021','MADHAVAN','84','KANNETHAYIL HOUSE\nTHOTTIYILANGADI\nMANGALAM WEST','Grade A','M','Mangalam','4','9745548655','6238697566','2021-09-01 00:00:00',NULL,NULL,'','DM,HTN,HYPONATREMIA',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU',''),(52,'10/2022','ABDURAHMAN','86','VALAPPIL MEPARAMBATH HOUSE\nKOOTAYI ROAD','Grade A','M','Mangalam','5','9946818173','7902599599','2022-02-09 00:00:00','2022-05-17 00:00:00',NULL,'SULEIMAN','DM,HTN,CVA,BPH,CKD',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU',''),(53,'55/2021','AMMUNNI','69','KARUKAYIL HOUSE\nTHOTTIYILANGADI\n','Grade A','F','Mangalam','4','9745794109','9946735990','2021-10-17 00:00:00','2022-11-02 00:00:00',NULL,'ASIA','CA ovary,Old DVT,DM,HTN',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU',''),(54,'65/2020','BEERAN KUTTY','65','VANIBHAPEEDIYEKKAL HOUSE\nTHOTTIYILANGADI','Grade B','M','Mangalam','4','8086484076','9496868483','2020-10-20 00:00:00','2023-01-14 00:00:00',NULL,'ASIA','ALZHEIMER\'S,CVA(Rt),PARKINSONISM,CKD.COPD',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU',''),(55,'34/2021','HAMZA','72','KULANGARAVEETIL HOUSE\nTHOTTIYILANGADI','Grade A','M','Mangalam','4','9656547585','8592839161','2021-08-05 00:00:00',NULL,NULL,'','DM,HTN,CVA(Rt)',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU',''),(56,'61/2021','MAKKUNNI','62','KARIYAM VALAPPIL HOUSE\nKARATTUKADAVU\nMANGALAM','Grade A','M','Mangalam','2','','9072349313','2021-11-05 00:00:00',NULL,NULL,'','CA Lung,CAD,LL',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU',''),(57,'58/2021','MOHAMED KUTTY','72','MELETHPUTHIYAMALIYEKKAL HOU\nSE\nARAKKALAPARAMBU','Grade A','M','Mangalam','7','9946101093','','2021-10-03 00:00:00',NULL,NULL,'','T2 DM,AKI,PD,RECURRENT CVA,ASPIRATION PNEUMONIA',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU',''),(58,'8/2018','LAKSHMI','85','PUNNEKATTU HOUSE\nAMMATTIL HOUSE\nKOOTAYI ROAD\nMANGALAM','Grade A','F','Mangalam','5','9539449491','','2018-01-18 00:00:00',NULL,NULL,'','HTN,T2DM',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU',''),(59,'11/2022','DAMAYANTHI','60','PUNNASSERY HOUSE\nTHIRUTHUMMAL','Grade A','F','Mangalam','4','9746817838','9567402457','2022-02-11 00:00:00',NULL,NULL,'','PSY,DM',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU',''),(60,'91/2017','MANIKANDAN','46','ERUKKATTIL HOUSE\nTHIRUTHUMMAL','Grade B','M','Mangalam','4','8086440034','','2017-07-01 00:00:00',NULL,NULL,'','CVA(Rt),HEMIPLEGIA,HYPERTENSION',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU',''),(61,'23/2020','KADEEJA','62','PANDARATHIL  HOUSE\nPAZHAYAPOSTOFFICE\nBOARDSCHOOL   MNGALAM','Grade B','F','Mangalam','3','9048540676','8129725888','2020-05-04 00:00:00',NULL,NULL,'','T2 DM',0,'CHENNARA,HC,PERUNTHIRUTHI,N .O.C PADI ,KURUMBADIPADI',''),(62,'17/2022','MARIYAKUTTY','76','AASHARIPARAMBIL    HOUSE\nCHENNARA   COLLEGEROAD\nMANGALAM','Grade B','F','Mangalam','8','9895369271','9539446824','2022-03-18 00:00:00',NULL,NULL,'','HTN',0,'CHENNARA,HC,PERUNTHIRUTHI,N .O.C PADI ,KURUMBADIPADI',''),(63,'157/2017','SINDHU','25','KONDAYOORPADI\nHARIGENCOLANI\nMANGALAM','Grade C','F','Mangalam','6','9544012033','','2017-12-14 00:00:00',NULL,NULL,'','EPILEPSY',0,'CHENNARA,HC,PERUNTHIRUTHI,N .O.C PADI ,KURUMBADIPADI',''),(64,'84/2018','KALLYANI','70','KIZHAKKEVALAPPIL  HOUSE\nPERUNHTIRUTHI\nMANGALAM','Grade A','F','Mangalam','14','8086572058','','2018-10-10 00:00:00','2022-08-10 00:00:00',NULL,'','COPD,CA BREAST',0,'CHENNARA,HC,PERUNTHIRUTHI,N .O.C PADI ,KURUMBADIPADI',''),(65,'6/2022','KADEEJA','75','MAYINKANAKATH  HOUSE\nKOLAPPADAM\nMANGALAM','Grade A','F','Mangalam','7','9539868273','9895451637','2022-01-17 00:00:00',NULL,NULL,'MAJEEDV M','HTN,OLDAGE,OSTEOPOROSIS',0,'CHENNARA,HC,PERUNTHIRUTHI,N .O.C PADI ,KURUMBADIPADI',''),(66,'7/2022','KOYA','56','KAPPATTAKATH  HOUSE\nMANGALAM','Grade B','M','Mangalam','7','9847028183','9606327467','2022-01-26 00:00:00','2022-07-10 00:00:00',NULL,'','CVA LEFT',0,'CHENNARA,HC,PERUNTHIRUTHI,N .O.C PADI ,KURUMBADIPADI',''),(67,'4/2021','THITHIKUTTY','75','AALUNGAL  HOUSE\nCHENNARA\nMANGALAM','Grade B','F','Mangalam','7','9544664755','8606206925','2021-02-15 00:00:00',NULL,NULL,'NASEERA','MULTIPLE OSTEOPOROSIS',0,'CHENNARA,HC,PERUNTHIRUTHI,N .O.C PADI ,KURUMBADIPADI',''),(68,'14/2022','SARADHA','65','RAMANALUKKALPADIKKAL\nCHENNARAHARIJAN COLONI\nMANGALAM','Grade B','F','Mangalam','6','9562303743','9847887838','2022-03-06 00:00:00',NULL,NULL,'YAHUTTY','T2 DM,CKD,HYPOTHYROIDISM,HYPERLIPIDEMIA',0,'CHENNARA,HC,PERUNTHIRUTHI,N .O.C PADI ,KURUMBADIPADI',''),(69,'26/2022','ANIRUDHAN','45','THAZHATHEPURAKKAL HOUSE\nMUTTANNOOR\nPURATHOOR','Grade A','M','Purathoor','2','9826998559','9446808083','2022-04-05 00:00:00',NULL,NULL,'','TRAUMATICC-SPINE INJURY WITH QUADRIPARESIS',0,'CHENNARA,HC,PERUNTHIRUTHI,N .O.C PADI ,KURUMBADIPADI',''),(70,'8/2022','FATHIMMA','85','CHOLAKKAL  HOUSE\nCHERUPUNNA    MANGALAM','Grade A','F','Mangalam','12','8589933772','9567383394','2022-02-07 00:00:00','2022-05-16 00:00:00',NULL,'SAFIYA','CA BUCCALMUCCOSA',0,'CHENNARA,HC,PERUNTHIRUTHI,N .O.C PADI ,KURUMBADIPADI',''),(71,'51/2020','FATHIMMA','70','KOLLARIKKAL  HOUSE\nCHERUPUNNA\nMANGALAM','Grade B','F','Mangalam','12','8943127288','9946775279','2021-08-26 00:00:00',NULL,NULL,'SAFIYA','CAD ,HTN',0,'CHENNARA,HC,PERUNTHIRUTHI,N .O.C PADI ,KURUMBADIPADI',''),(72,'44/2020','FATHIMMA','68','VALAPPIL MEPPARAMBATH  HOUSE\nCHENNARA\nMANGALAM','Grade B','F','Mangalam','7','9846961110','7902599599','2020-08-02 00:00:00','2022-09-29 00:00:00',NULL,'','ALZHEIMERS,CAD,DM,OSTEOPOROSIS',0,'CHENNARA,HC,PERUNTHIRUTHI,N .O.C PADI ,KURUMBADIPADI',''),(73,'12/2022','MALU','80','VALIYAKULANGARA  HOUSE\nCHENNARA HARIJANCOLANI\nMANGALAM','Grade A','F','Mangalam','8','9745660395','8304800395','2022-02-14 00:00:00',NULL,NULL,'YAHUTTY','CA-SIGMOID,HYPONATREMIA,CAD,HTN',0,'CHENNARA,HC,PERUNTHIRUTHI,N .O.C PADI ,KURUMBADIPADI',''),(74,'45/2021','MARIYUMMA','74','CHALIPARAMBIL  HOUSE\nKURUMBADI\nMANGALAM','Grade A','F','Mangalam','12','9567862772','04942566086','2021-09-17 00:00:00',NULL,NULL,'','CVA,STROKE,DEMENTIA,DEPRESSIVE ILLNESS',0,'CHENNARA,HC,PERUNTHIRUTHI,N .O.C PADI ,KURUMBADIPADI',''),(75,'32/2018','SAROJINI','65','NALUVEETTIL  HOUSE\nPERUNTHIRUHTI\nMANGALAM','','F','Mangalam','14','8606567283','','2018-03-05 00:00:00',NULL,NULL,'','CVA(R),HTN,OLDAGE',0,'CHENNARA,HC,PERUNTHIRUTHI,N .O.C PADI ,KURUMBADIPADI',''),(76,'39/2021','RIFA AHAMMED','20','PALAKKAVALAPPIL CHALIPARAMBIL  HOUSE\nKURUMBADI\nMANGALAM','Grade A','M','Mangalam','12','9526954191','7559040054','2021-08-26 00:00:00',NULL,NULL,'','MR',0,'CHENNARA,HC,PERUNTHIRUTHI,N .O.C PADI ,KURUMBADIPADI',''),(77,'18/2021','KUNHIBAPPUHAJI','97','PUTHANPEEDIYEKKAL  HOUSE\nN O C PADI\nMANGALAM','Grade B','M','Mangalam','13','8111969451','7909223973','2021-05-04 00:00:00','2022-08-24 00:00:00',NULL,'','HTN,CAD',0,'CHENNARA,HC,PERUNTHIRUTHI,N .O.C PADI ,KURUMBADIPADI',''),(78,'67/2021','AMINA','85','MEENADATHOOR\nCHERUPUNNA\nMANGALAM','Grade B','F','Mangalam','12','9847673169','','2021-11-22 00:00:00',NULL,NULL,'','DM,HTN,CAD,PSY,DEMENSIA',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(79,'2/2021','KUNHEEMA','80','KANHIKKOTH  HOUSE\nCHENNARA\nMANGALAM','Grade B','F','Mangalam','7','9846802547','9745117285','2021-01-15 00:00:00',NULL,NULL,'SHAMSUDHEEN A','CKD,CVA,HTN',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(80,'23/2021','MINI','41','ERAMATH\nCHENNARA\nMANGALAM','Grade B','F','Mangalam','8','7592963500','9446667329','2021-06-20 00:00:00',NULL,NULL,'SHABEER','HEMOLYTIC ANEMIA&THROMBOCYTOPENIA',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(81,'59/2021','KUTTIMALU','87','KALATHIPARAMBIL HOUSE\nPAZHAYAPOSTOFFICE\nMANGALAM','Grade A','F','Mangalam','3','8086285937','','2021-11-02 00:00:00',NULL,NULL,'PUSHPA','DM,HTN,CAD,DLP,MILD T R',0,'PAZHAYAPOST OFFICE',''),(82,'33/2021','MOIDHEEN','79','CHANAYIL(KARATTUKADAVATH)  HOUSE\nPAZHAYAPOSTOFFICE\nMANGALAM','Grade B','M','Mangalam','3','9562216340','9961971371','2021-08-04 00:00:00',NULL,NULL,'PUSHPA','',0,'PAZHAYAPOST OFFICE',''),(83,'71/2019','USHA','65','CHAKKANHATTIL  HOUSE\nPAZHAYAPOSTOFFICE\nMANGALAM','Grade B','F','Mangalam','3','9995092645','','2019-08-09 00:00:00','2023-01-12 00:00:00',NULL,'','CELLULITIS,PSY',0,'PAZHAYAPOST OFFICE',''),(84,'41/2017','DHAMAYANTHI','75','CHAKKANHATTIL  HOUSE\nPAZHAYAPOSTOFFICE\nMANGALAM','Grade B','F','Mangalam','3','9995092645','','2017-03-23 00:00:00','2023-01-13 00:00:00',NULL,'','HTN,CAD',0,'PAZHAYAPOST OFFICE',''),(85,'22/2019','FATHIMMA','55','AZHEEKKOTTIL  HOUSE\nPAZHAYAPOSTOFFICE\nMANGALAM','Grade B','F','Mangalam','3','8086270769','9495491901','2019-03-13 00:00:00','2022-07-16 00:00:00',NULL,'RAJEENA','CVA ,HEMIPLEGIA,PSYCHIATRICILLNESS,HYPONATREMIA',0,'PAZHAYAPOST OFFICE',''),(86,'129/2017','BINDHU','40','CHEMBILATH  HOUSE\nVAILIPPADAM\nMANGALAM','Grade C','F','Mangalam','10','9895212584','7510169749','2017-10-12 00:00:00',NULL,NULL,'','PSY',0,'VAYALIPADAM,VALAMARUTHOOR',''),(87,'46/2018','LAKSHMI','78','MANNATH  HOUSE \nANNASSERY - THALOOKKARA\nMANGALAM','Grade C','F','Mangalam','2','9400565785','','2018-05-21 00:00:00',NULL,NULL,'','PSY',0,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY',''),(88,'46/2020','SARADHA','78','VEETTIL  HOUSE\nILLATHEPADI\nMANGALAM','Grade C','F','Mangalam','9','9745869309','9072003026','2020-08-21 00:00:00',NULL,NULL,'','PSY',0,'VAYALIPADAM,VALAMARUTHOOR',''),(89,'35/2017','LATHA','45','CHERUPARAMBIL  HOUSE\nVALAMARUTHOOR','Grade C','F','Mangalam','9','9495563322','','2017-03-07 00:00:00',NULL,NULL,'','PSY',0,'VAYALIPADAM,VALAMARUTHOOR',''),(90,'86/2016','PATHMANABHAN','55','KRISHNA   HOUSE\nAMBADI NAGAR\nCHENNARA','Grade C','M','Mangalam','','04942564658','','2016-08-28 00:00:00',NULL,NULL,'','PSY',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(91,'16/2021','HYRUNNISA','40','KARUMANNIL   HOUSE\nPERUNTHIRUTHI\nMANGALAM','Grade C','F','Mangalam','14','9048884038','8593968475','2021-04-11 00:00:00',NULL,NULL,'SAFIYA','PSY',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(92,'28/2018','SIRURAHMAN','37','CHERIYAKALYAPPURATH  HOUSE\nKAVANCHERY\nMANGALAM','Grade C','M','Mangalam','11','8547404143','','2018-02-20 00:00:00',NULL,NULL,'','PSY',0,'KAVANCHERY,MARAVANTHA',''),(93,'29/2018','SHAHULHAMEED','32','CHERIYAKALYAPPURATH  HOUSE\nKAVANCHERY\nMANGALAM','Grade C','M','Mangalam','11','8547404143','','2018-02-20 00:00:00',NULL,NULL,'','PSY',0,'KAVANCHERY,MARAVANTHA',''),(94,'65/2018','SHEHEEN AKTHAR','23','CHAKKUNGAPARAMBIL  HOUSE\nANNASSERY\nMANGALAM','Grade C','F','Mangalam','3','8547412360','','2021-08-28 00:00:00',NULL,NULL,'','PSY',0,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY',''),(95,'25/2017','MOIDHEENKUTTY','42','KADAKASSERY PARAMBIL  HOUSE\nVALAMARUTHOOR\nDAM ROAD\nMANGALAM','Grade C','M','Mangalam','10','9847029455','','2017-02-21 00:00:00',NULL,NULL,'','PSY',0,'VAYALIPADAM,VALAMARUTHOOR',''),(96,'26/2017','KUNHEEMA','64','KADAKASSERYPARAMBIL  HOUSE\nVALAMARUTHOOR\nDAM ROAD\nMANGALAM','Grade C','F','Mangalam','10','9847029455','','2020-02-21 00:00:00',NULL,NULL,'','PSY',0,'VAYALIPADAM,VALAMARUTHOOR',''),(97,'26/2020','GANESHAN','49','KALLERI  HOUSE\nCHENNARA HARIJANCOLANI\nMANGALAM','Grade C','M','MANGALAM','9','9745156011','9745225808','2020-05-15 00:00:00',NULL,NULL,'NEEMA','CKD',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(98,'92/2018','UNYALAN','63','VATHIPPADIKKAL  HOUSE\nHARIJANCOLANI\nCHENNARA','Grade C','M','Mangalam','8','9633709490','','2018-11-03 00:00:00',NULL,NULL,'','CAD,CKD,COPD.OLDPTB',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(99,'21/2022','BABU','38','PANAPPADIKKAL  HOUSE\nVALAMARUTHOOR\nMANGALAM','Grade A','M','Mangalam','10','8943109819','9539752148','2022-03-28 00:00:00',NULL,NULL,'SADATH','SPINE INJURY,QUADRIPLEGIA',0,'VAYALIPADAM,VALAMARUTHOOR',''),(100,'23/2014','SOBHANA','45','CHANDANAPPURATH  HOUSE\nKOOTTAYIKKADAV\nMANGALAM','Grade C','F','MANGALAM','5','9846788260','','2014-05-11 00:00:00',NULL,NULL,'','CA BREAST',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU',''),(101,'57/2017','JAYALAKSHMI','73','KARUMATHIL  HOUSE\nCHENNARA\nMANGALAM','Grade B','F','Mangalam','8','9544724245','','2017-05-02 00:00:00',NULL,NULL,'','CAD,DM,COPD',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(102,'100/2017','THANKAMANI','52','PEDOOR  HOUSE\nKAVANCHERY\nPURATHOOR','Grade C','F','Purathoor','5','9745112483','','2017-07-20 00:00:00',NULL,NULL,'','HTN',0,'KAVANCHERY,MARAVANTHA',''),(103,'16/2022','KAMALAM','51','THRIKKANASSERY   HOUSE\nPULLOONI\nKARATTUKADAV\nMANGALAM','Grade B','F','Mangalam','2','9961118051','','2022-03-21 00:00:00',NULL,NULL,'','CA BREAST',0,'PULLOONI-ANNASSERY-THALOOKKARA-',''),(104,'30/2021','MOHAMMED','62','PATTAYANGARA   HOUSE\nKAVANCHERY\nMANGALAM','Grade A','M','Mangalam','11','8943740247','8086245639','2021-07-21 00:00:00',NULL,NULL,'SADATH','DLP,CVA.OLD TB',0,'KAVANCHERY,MARAVANTHA',''),(105,'24/2019','GOPALAN','75','VELUTHEDATH VALAPPIL  HOUSE\nHARIJANCOLANI\nMANGALAM','Grade B','M','Mangalam','8','9747488295','','2019-04-08 00:00:00',NULL,NULL,'ABID MASTER','ABD.AORTIC ANEURYSM ',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(106,'27/2018','AHAMMED KABEER','43','CHERIYAKALYAPPURATH  HOUSE\nKAVANCHERY\nMANGALAM','Grade C','M','Mangalam','11','8547404143','','2018-02-20 00:00:00',NULL,NULL,'','PSY',0,'KAVANCHERY,MARAVANTHA',''),(107,'31/2022','PATHUKUTTY','67','ARANGATHU PARAMBIL HOUSE\nKHABARSTHAN ROAD\nKAIMALASSERY\nTRIPRANGODE','Grade A','F','Thriprangode','17','9961184464','9747303097','2022-05-12 00:00:00','2022-07-05 00:00:00',NULL,'','CA Scalp',0,'KKAIMALASSERY',''),(108,'80/2019','JANAKIYAMMA','92','KARUPPAYIL HOUSE\nCHENNARA\nMANGALAM','Grade A','F','Mangalam','7','9746074774','9746074778','2019-09-19 00:00:00','2022-08-21 00:00:00',NULL,'','OSTEOPOROSIS',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(109,'22/2022','CHINNAMMU','88','VAIDYAR PARAMBIL HOUSE\nKOOTAYI  ROAD\nMANGALAM','Grade A','F','Mangalam','4','9747827409','9544475870','2022-03-29 00:00:00','2022-05-24 00:00:00',NULL,'ASIYA','OLD AGE',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU',''),(110,'12/2020','FATHIMAKKUTTY','75','RAMANALUKKAL HOUSE\nSINDICATE,MANGALAM','Grade A','F','Mangalam','6','9895100921','9847030945','2020-03-11 00:00:00',NULL,NULL,'','CVA(Rt),COPD,HTN',0,'SINDICATE,MANGALAM,KAIMALASSERY',''),(111,'5/2022','AMINAKKUTY','69','PALAKKAVALAPPIL MADAPPALLI HOUSE\nCHENNARA\nMANGALAM','Grade B','F','Mangalam','7','8592923000','9961623000','2022-01-15 00:00:00','2022-12-24 00:00:00',NULL,'','CVA',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(112,'42/2021','HAMSA','90','KANJIKKOTHU HOUSE\nCHENNARA','Grade A','M','Mangalam','7','9961996136','9048084635','2021-09-12 00:00:00','2022-05-17 00:00:00',NULL,'SAFIYA','CVA',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(113,'66/2021','HANEEFA','53','VAKKAYIL PARAMBIL HOUSE\nMARAVANDA,KAVANCHERY','Grade A','M','PURATHUR','5','9745453176','8593985677','2021-11-18 00:00:00',NULL,NULL,'SADATH','DIABETIC FOOT ABSESS,HTN,T2 DM',0,'KAVANCHERY,MARAVANTHA',''),(114,'21/2019','VISWAS','32','NAIKKARA HOUSE\nPERUNTHIRUTHI\nMANGALAM','Grade A','M','Mangalam','14','8943462695','8943085360','2019-03-12 00:00:00',NULL,NULL,'SAFIYA','MR,DM',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(115,'73/2015','LAKSHMI','55','MAKKAYATHU HOUSE\nPERUNTHIRUTHI\nCHENNARA','Grade B','F','Mangalam','14','9544822794','9946091251','2015-10-13 00:00:00',NULL,NULL,'','PSY,HTN',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(116,'9/2021','ALI','84','THANDASSERY HOUSE\nCHENNARA\nMANGALAM','Grade A','M','Mangalam','7','9605740228','9961173136','2021-03-30 00:00:00','2022-05-16 00:00:00',NULL,'SAFIYA','CVA(Lt)',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(117,'63/2017','THITHEEMU','63','KAKKIDI THUPPATHU\nVALAMARUTHUR','Grade B','F','Mangalam','10','8606285513','','2017-05-09 00:00:00',NULL,NULL,'','CAD,HTN',0,'VAYALIPADAM,VALAMARUTHOOR',''),(118,'1/2022','AMINAKKUTTY','79','THEKKARODATHU HOUSE\nVAYALIPPADAM\nMANGALAM','Grade B','F','Mangalam','6','8086083162','7736981616','2022-01-02 00:00:00','2022-09-18 00:00:00',NULL,'','L3 VERTIBRAL TB SPONDYLODISCITIS',0,'VAYALIPADAM,VALAMARUTHOOR',''),(119,'75/2019','KHADER HAJI','75','POOTHERY HOUSE\nN.O.C PADI\nMANGALAM','Grade B','M','Mangalam','13','9496670011','8943719571','2019-08-26 00:00:00',NULL,NULL,'','HTN,DM,PARKINSON\'S',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(120,'100/2018','MOIDHEEN','64','PARAMBATTU VALAPPIL\nPULLOONI\nMANGALAM','Grade B','M','Mangalam','2','9539721167','','2018-11-22 00:00:00',NULL,NULL,'','CAD,HTN',0,'PULLOONI',''),(121,'57/2021','KAUSALYA','50','VALIL HOUSE\nPAYYAPADAM,PUNNAMANA','Grade A','F','Mangalam','6','9746750633','9895850583','2021-10-30 00:00:00',NULL,NULL,'FOUSIYA','CA BREAST(Lt),HTN ,DM',0,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY',''),(122,'35/2021','ZAKARIYA','28','KAKKIDI PARAMBATHU HOUSE\nKURUMBADI','Grade B','M','Mangalam','12','9744083084','9847259091','2021-08-12 00:00:00',NULL,NULL,'','PSY',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(123,'10/2021','JANARDHANAN','58','MANGUZHIYIL HOUSE\nANNASSERY\nMANGALAM','Grade B','M','Mangalam','3','9656218983','9746481024','2021-03-31 00:00:00',NULL,NULL,'FOUSIYA','CVA',0,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY',''),(124,'74/2015','BABY','55','THANDALATH HOUSE\nANNASSERY\nMANGALAM','Grade B','F','Mangalam','2','9847597734','','2015-07-17 00:00:00',NULL,NULL,'','CA BREAST',0,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY',''),(125,'76/2020','SULAIKHA','62','THEYYAMBATIL\n(THIRUNAVAYA KALATHIL)\nANNASSERY','Grade B','F','Mangalam','3','9645787460','9497116053','2020-11-27 00:00:00',NULL,NULL,'FOUSIYA','CA RECTUM',0,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY',''),(126,'23/2022','KUNJIMOL','87','ANNASSERY HOUSE\nANNASSERY\nMANGALAM','Grade B','F','Mangalam','3','04942566320','9446466320','2022-03-31 00:00:00','2022-07-12 00:00:00',NULL,'FOUSIYA','COPD,DEMENTIA',0,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY',''),(127,'87/2016','CHANDRASEKARAN','55','KOONATHIL HOUSE\nTHALOOKKARA','Grade A','M','Mangalam','2','9747546120','','2016-08-30 00:00:00','2023-02-13 00:00:00',NULL,'','CVA,HTN,DM',0,'THALOOKKARA',''),(128,'99/2018','BEEVIKKUTTY','62','PARAMBATU VALAPPIL HOUSE\nPULLOONI','Grade A','F','Mangalam','2','','','2018-11-22 00:00:00',NULL,NULL,'','HTN,DM',0,'PULLOONI',''),(129,'86/2019','KHASIM','68','KARATTU KADAVATHU PATTAYIL HOUSE\nANNASSERY','Grade B','M','Mangalam','3','9846678879','','2019-10-29 00:00:00',NULL,NULL,'FOUSIYA','BPH,CKD,DKD,HTN,DM',0,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY',''),(130,'31/2021','SAITHALIKUTTY','65','VALAPPIL HOUSE\nPUNNAMANA\nMANGALAM','Grade B','M','Mangalam','6','9846203959','9539920959','2021-07-30 00:00:00',NULL,NULL,'','CVA,HTN',0,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY',''),(131,'38/2021','AMINAKKUTTY','75','PALLIPPARAMBIL HOUSE\nKUTTAMMAKKAL','Grade B','F','Thriprangode','17','8139092919','8129860032','2021-08-24 00:00:00',NULL,NULL,'','CKD',0,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY',''),(132,'95/2018','KUNHIMOIDEEN KUTTY','63','KALLERIKKATTIL HOUSE\nPUNNAMANA\nMANGALAM','Grade B','M','Mangalam','6','9961808184','','2018-11-13 00:00:00',NULL,NULL,'FOUSIYA','CVA(Lt)',0,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY',''),(133,'90/2018','LAKSHMI','72','PATTATHUR HOUSE\nPULLOONI','Grade B','F','Mangalam','2','9526045168','','2018-10-30 00:00:00',NULL,NULL,'','HTN',0,'PULLOONI',''),(134,'15/2022','NAFEESA','80','KAVUNGAL HOUSE\nANNASSERY\nMANGALAM','Grade B','F','Mangalam','3','9846065340','','2022-03-08 00:00:00','2022-12-18 00:00:00',NULL,'','CVA,DM',0,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY',''),(135,'34/2022','FATHIMA','74','PULIKKAPARAMBIL(H) \nMUTTANNOOR \nPURATHUR','Grade A','F','PURATHUR','','8592941647','6235194822','2022-06-02 00:00:00',NULL,NULL,'','PSY,CA',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI','1'),(136,'32/2022','ACHUTHAN','83','CHEMBAYIL HOUSE\nTRANSFORMER\nMANGALAM','Grade B','M','MANGALAM','3','9846755451','9846551584','2022-05-21 00:00:00','2022-06-04 00:00:00',NULL,'','DM,CKD,DKD,ACUTE PULMONARY EDEMA,CLD,HTN',0,'PAZHAYAPOST OFFICE',''),(137,'33/2022','PATHUMMU','76','KALOOORVALAPPIL HOUSE\nKAVANCHERY','Grade A','F','Mangalam','','9847654001,9','994729','2022-05-27 00:00:00','2022-06-11 00:00:00',NULL,'','OLD AGE,HTN,SVD,VCI,HYPONATREMIA',0,'KAVANCHERY,MARAVANTHA',''),(138,'35/2022','SAIDALAVI','82','KUNNATHIL HOUSE\nN.O.C.PADI\nMANGALAM','Grade A','M','MANGALAM','13','8943469936','8943114964','2022-06-07 00:00:00','2022-07-20 00:00:00',NULL,'','HTN(5Yrs),CAD,CVA(Rt),CVA(Lt 2Yrs).',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(140,'36/2022','PATHUNNY','80','VAKKAYIL PARAMBIL HOUSE\nVAYALIPPADAM\nMANGALAM','','F','MANGALAM','8','9656534924','9526520862','2022-06-08 00:00:00','2022-07-29 00:00:00',NULL,'YAHUTTY','HTN(2Yrs),CVA(Rt),UL',0,'KAVANCHERY,MARAVANTHA',''),(141,'37/2000','AMINA','60','VALKANDI HOUSE \nVALTHARAPPADAM\nARAKKALAPARAMBU','Grade A','F','MANGALAM','5','9745585234','8943660107','2022-06-10 00:00:00','2022-07-07 00:00:00',NULL,'','DM,HTN,PSY',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU',''),(142,'38/2022','SHOUKATH ALI','82','KIZHAKKE PEEDIYEKKAL HOUSE\nCHENNARA\nMANGALAM','Grade B','M','MANGALAM','5','9446769942','8304911344','2022-06-11 00:00:00','2022-06-13 00:00:00',NULL,'MAJEED','CAD,HTN,DM,CA',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(143,'39/2022','SARADA','75','MUTHIYERI HOUSE\nPERUNTHIRUTHI\nMANGALAM','Grade B','F','MANGALAM','14','9048609420','9846201800','2022-06-15 00:00:00',NULL,NULL,'','CVA(Rt),CAD,HTN,',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(144,'40/2022','ABDUL KADER','75','KADAVUKARAKATH HOUSE\nPERUNTHIRUTHI\nMANGALAM','Grade A','M','MANGALAM','13','9995198328','9746312310','2022-06-15 00:00:00','2022-06-16 00:00:00',NULL,'','HTN,CAD',0,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI',''),(145,'41/2022','RAHEENA','43','PALAKKAVALAPPIL KINATTINGAL\nMANGALAM WEST','Grade A','F','MANGALAM','5','7510392270','9895592270','2022-06-19 00:00:00','2022-10-04 00:00:00',NULL,'','CKD,HTN,CAD',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU',''),(146,'42/2022','gireesan','40','veettil valappil house, \nVayalippadam,\nMangalam','Grade B','M','Mangalam','8','9846 17 79 97','9446 88 22 35','2022-06-24 00:00:00',NULL,NULL,'','Peri anal Absaces, Hemorrhoidectomy',0,'VAYALIPADAM,VALAMARUTHOOR',''),(147,'43/2022','Kadheeja ','90','vanibha peediyekkal house,\nThottiyilangadi','Grade A','F','Mangalam','4','8086 32 97 62','9961 56 89 96','2022-06-27 00:00:00',NULL,NULL,'Aasya','COPD, OLD AGE',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU',''),(148,'44/2022','Ali','80','Kariyamkatt kavil (kalikkatt),\nKaimalasseri,Kuttammakkal','Grade A','M','Thriprangode','','9645 58 00 09','8304 06 4009','2022-06-27 00:00:00',NULL,NULL,'Shimla','OLD AGE, PRESSURE SORE',0,'SINDICATE,MANGALAM,KAIMALASSERY',''),(149,'90/2019','Nafeesa','64','Kulangara veettil house, \nThottiyilangadi','Grade A','F','Mangalam','4','9562 03 15 81','7008 29 31 50','2019-11-25 00:00:00','2022-06-29 00:00:00',NULL,'','CVA',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI, ARICHAL TEMPLE',''),(150,'45/2022','Abdurahiman','108','Kallivalappil house,\nThalookkara','Grade A','M','Mangalam','','8089 62 34 43','9567 68 19 60','2022-07-02 00:00:00','2022-07-06 00:00:00',NULL,'','Bed ridden ,Old age',0,'Thalookkara',''),(151,'46/2022','Unniyappu','63','Kizhakke purakkal house,\nKaimalasseri','Grade A','M','Thriprangode','17','9745 08 88 42','9048 94 74 52','2022-07-11 00:00:00','2022-07-14 00:00:00',NULL,'Sreenitha','CA Lung',0,'kaimalasseri, khabarsthan road',''),(152,'47/2022','Appunni ','80','Poozhikkunnath house,\nHarijan colony ,Peral','Grade A','M','Mangalam','8','9656 02 30 55','8943 99 98 66','2022-07-14 00:00:00','2022-07-25 00:00:00',NULL,'SADATH','metabolic enalopathy',0,'Harijan colony, near  Peral Temple',''),(153,'49/2022','Beevathu','90','Kunnathil house,\nIllathappadi','Grade A','F','Mangalam','12','7510 11 16 53','9946 34 46 07','2022-07-19 00:00:00','2022-08-07 00:00:00',NULL,'','Old age problems',0,'illathappadi valamaruthur road',''),(154,'48/2022','Kadheeja','89','Ramanalukkal house, Mangalam','Grade A','F','Mangalam','3','9946 96 43 49 ','9995 64 06 03','2022-07-19 00:00:00','2022-07-25 00:00:00',NULL,'Rajeena ','Dm, HTN,CAD,CKD',0,'MANGALAM, KURUKKOTTY KULAM',''),(155,'50/2022','Fathima ','70','Kannamkadavath,\nmuttanoor po,\nCherupunna.','Grade B','F','Mangalam','12','9946 76 88 65','8086 18 06 78','2022-07-21 00:00:00','2023-02-10 00:00:00',NULL,'Safiya','Hypokalemia, Hyponatrenia,odema, COPD',0,'near Cherupunna temple',''),(156,'51/2022','Mambi ','70','Ramanalukkal padikkal,\nChennara post,\nHarijan colony','Grade B','M','Mangalam','6','9562 30 37 43','9847 88 78 38','2022-07-22 00:00:00',NULL,NULL,'','Non healing clcer over medial',0,'back side of Karuna',''),(157,'47/2018','chandran','46','Puravalappil house,\nMangalam post, \nAnnasseri,Thalookkara','Grade C','M','Mangalam','2','9846 52 32 40 ','','2018-05-21 00:00:00','2022-07-17 00:00:00',NULL,'nil','CVA',0,'Annaseri, Thalookkara',''),(158,'52/2022','Fathimma                            ','65','Kaippadath house,\nKavancheri, Valamaruthur','','F','Mangalam','10','8156 94 17 83 ','0494 2080783','2022-07-22 00:00:00',NULL,NULL,'SADATH','DM, HTN,CAD,',0,'Valamaruthur , Dam road ',''),(159,'53/2022','Thithikkutty','97','KIZHAKKE PEEDIYEKKAL HOUSE,\npAZHAYA POST OFFICE','Grade A','F','Mangalam','4','9847 36 43 73','9747 73 83 89 ','2022-07-23 00:00:00','2022-07-28 00:00:00',NULL,'Majeed VM',' DM',0,'pazhaya post office-board school road',''),(160,'54/2022','FATHIMMA','70','Thurayattil house,\nThalookkara','Grade B','F','Mangalam','2','7356 07 88 28','9895 15 72 83','2022-07-23 00:00:00','2022-10-23 00:00:00',NULL,'Isahaq','DM,HTN',0,'Thalookkara-near Badarul huda madrasa',''),(161,'55/2022','Hafsath ','87','Musliyare veettil house,\nChennara.','Grade B','F','Mangalam','7','9846 09 84 87 ','7356 56 64 85 ','2022-07-24 00:00:00',NULL,'2022-10-05 00:00:00','Yoosaf','HTN, CPD',0,'Karuna- Chennara road, Near Ashkar mash',''),(162,'56/2022','Kadheeja','85','Vakkalath house,\nvalamaruthur','Grade A','F','Mangalam','9','9074 91 0867','9061 99 44 28','2022-07-25 00:00:00',NULL,NULL,'shamsudheen','',0,'Valamaruthur -Ambadi- Niskarapalli road',''),(163,'57/2022','Moitheen','65','Panniyath house,\nKavancheri.','Grade A','M','Mangalam','11','9037 47 89 39','9656 56 98 90','2022-07-27 00:00:00',NULL,NULL,'SADATH','DM,CAD',0,'Valamaruthur- Panapadi road- near Niskarappalli',''),(164,'58/2022','ayisha','75','chericham veettil kalathil   house   \nthottiyilangadi','Grade B','F','Mangalam','4','7560936321','9744530493','2022-07-28 00:00:00',NULL,NULL,'asya','parkin sonisum',0,'thottiyilangadi rashanshop-maramill',''),(165,'59/2022','mariyakkutty','82','valappil  [house]\ntransformer,mangalam','Grade B','F','Mangalam','3','9656030531','04942567147','2022-07-28 00:00:00',NULL,NULL,'rajeena','CAD,HTN,PSY',0,'transformer,watertang-oposit road',''),(166,'61/2022','SAINUDHEEN','46','COOLIPARAMBIL(HOUSE)            KAVANCHERY (PO)\nVALAMARUTHOOR','Grade C','M','Mangalam','10','9562655807','9947576472','2022-07-31 00:00:00',NULL,NULL,'SADATH','CKD     DIALYSIS',0,'VAYALIPADAM,VALAMARUTHOOR','2'),(167,'62/2022','RAMANI','72','VEETTILVALAPPIL(HOUSE)\nMANGALAM (PO)\nTHOTTIYILANGADI','Grade B','F','Mangalam','4','9446885461','8129017553','2022-08-01 00:00:00',NULL,NULL,'BAPPUTTY','CKD-DKD; PSY,ANEMIA',0,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU','2'),(168,'63/2022','LEELA','78','KALLERI(HOUSE)\nMANGALAM(PO\n)MANGALAM','Grade B','F','MANGALAM','3','9946553136','9946681881','2022-08-04 00:00:00',NULL,NULL,'RAJEENA BASHEER','STROKE',0,'PAZHAYAPOST OFFICE','2'),(169,'60/2022','Parvathi ','85','Thachillath house,\nChennara, Perinthiruthi','Grade A','F','Mangalam','14','6238 81 79 16 ','9400 86 83 80','2022-07-30 00:00:00','2022-09-11 00:00:00',NULL,'Kadheeja','Old age problems',0,'Chennara- chennara Kadav- Cheriya Palam',''),(170,'64/2022','Ishaq','66','Kanjikkoth house, Mangalam Koottayi road, Kakku mash school','Grade B','M','Mangalam','DM,CAD','9447 82 78 70 ','8848 73 90 90 ','2022-08-07 00:00:00',NULL,NULL,'Ishaq','',0,'Mangalam- Koottayi road, ',''),(171,'65/2022','Janaki','85','Padunnavalappil house,\n chennara, Perinthiruthi','Grade A','F','Mangalam','14','9048 63 888 2','8593 08 02 14','2022-08-09 00:00:00',NULL,NULL,'Kadheeja salim','DM, HTN, CAD',0,'CHENNARA TEMPLE ROAD, THEKKE KADAV',''),(172,'16/2018','Sulaikha','40','Madappatt, Thottiyilangadi','Grade C','F','Mangalam','4','9995 71 32 99','','2018-02-10 00:00:00',NULL,'2022-08-10 00:00:00','','CVA',0,'thottiyilangadi mosque-Temple',''),(173,'66/2022','Neeli','66','Ramanalukkal Padikkal,\nsyndicate','Grade B','F','Mangalam','6','9746 26 85 88','9544 48 8585','2022-08-12 00:00:00',NULL,NULL,'Abid ','HTN',0,'SYNDICATE',''),(174,'34/2015','Fathima','65','Thazhathe peediyekkal,\nKaimalasseri','Grade D','F','Thriprangode','17','8943 20 90 95','','2015-06-21 00:00:00',NULL,NULL,'','CKD',0,'SINDICATE,MANGALAM,KAIMALASSERY',''),(175,'67/2022','Vasantha','42','Padunnavalappil,\nChennara, \nPerinthiruthi','Grade A','F','DM,','14','9048 63 8882','9567 82 60 97','2022-08-14 00:00:00',NULL,NULL,'KADEEJA SALIM','DM, HTN, CKD',0,'CHENNARA- TEMPLE ROAD-  THEKKE KADAV',''),(176,'68/2022','Kalikkutty','77','Areekkara, Chennara post,\nPerinthiruthi','Grade A','F','Mangalam','14','9846 57 25 52','9497 63 27 14','2022-08-16 00:00:00',NULL,NULL,'kadheeja Salim','HTN, CVA',0,'Perinthiruthi- near vailikulangara temple- Areekkara Rajan',''),(177,'69/2022','Rasiya','74','Thandalam valappil Kuttantharayil,\nMangalam post,\nTransformer','Grade A','F','Mangalam','3','9526 055 945','9745 16 12 68','2022-08-17 00:00:00','2022-08-29 00:00:00',NULL,'RAFI','DM, HTN ,CKD',0,'PAZHAYAPOST OFFICE- NEAR TRANSFORMER',''),(178,'70/2022','Bava a/s Muhammed kutty','78','Palakkavalappil Kinattingal,\nChennara','Grade A','M','Mangalam','7','9995 64 63 48','9744 40 13 26','2022-08-18 00:00:00',NULL,NULL,'','HTN',0,'Chennara rice mill road- Alans Quarters',''),(179,'71/2022','Pareekkutty','72','Palakkavalappil Vattapparambil house,\nChennara','Grade A','M','Mangalam','7','9846 255 455','9207 899 062 ','2022-08-19 00:00:00','2022-08-20 00:00:00',NULL,'YOOSAF','DM, HTN, CAD',0,'KARUNA-CHENNARA ROAD- KULAM -NISTAR HOUSE',''),(180,'72/2022','Kadheeja','64','Puthanpurayil house, Chennara, harijan colony','Grade B','F','Mangalam','8','9544 55 06 16','8129 96 63 76','2022-08-27 00:00:00',NULL,'2022-10-05 00:00:00','yoosaf','',0,'infront of Karuna office',''),(181,'73/2022','Kunjimayumma','80','Kunjoosan marakkarakath, Payyappadam, Mangalam','Grade B','F','Mangalam','3','9645 79 89 84','9539 39 26 75','2022-08-27 00:00:00',NULL,NULL,'Smitha','HTN,CAD',0,'Karuna- Payyapadam- Saithalikkty house',''),(182,'74/2022','Beerankutty','87','Peroolil house, Mangalam','Grade A','M','Mangalam','6','9544 134 782','9995 41 47 81','2022-08-28 00:00:00','2022-09-03 00:00:00',NULL,'SHAMSUDHEEN A','DM,HTN,CAD',0,'Karuna- Mangalam-Purathur road-near Dr; Ibrahim',''),(183,'75/2022','Kunjimol','80','Cheramveettil house,\nMuttanoor,','Grade A','F','Purathoor','2','7025 52 18 22','9847 2192 53','2022-08-29 00:00:00','2022-10-01 00:00:00',NULL,'Udayan Purathur','DM,HTN,CAD',0,'KARUNA- PURATHUR ROAD -ASUPATHRIPPADI- NEAR PALAMPADI',''),(184,'77/2022','Aboobakkar ','78','Alungal , Mangalam','Grade A','M','Mangalam','7','9995 89 57 75','9048 07 59 19','2022-08-30 00:00:00',NULL,NULL,'SHAMSUDHEEN ','HTN',0,'near Dr: Ibrahim ,Mangalam',''),(185,'76/2022','Leela','64','Thrikkanasseri house, Mangalam,Pulluni,\nKarattukadav','Grade A','F','Mangalam','2','','','2022-08-30 00:00:00',NULL,NULL,'','Thyroid',0,'Pulluni- karattukadav- near Hotel Sivan',''),(186,'78/2022','Moitheenkutty','85','Nandhanil ,Mangalam,\nThottiyilangadi.','Grade A','M','Mangalam','4','9400 566 568','9995 20 21 88','2022-09-02 00:00:00','2022-09-29 00:00:00',NULL,'asya','HTN',0,'Near Thottiyilangadi mosque',''),(187,'79/2022','Narayani','67','Munayath, Chennara post,\nPerinthiruthi','Grade A','F','Mangalam','14','9995 38 73 88','9946 73 69 60','2022-09-06 00:00:00','2022-09-18 00:00:00',NULL,'Kadeeja ','diffuse ceretral and cerebellar atrophy',0,'perumthiruthi thookkupalam road.',''),(188,'80/2022','Kunjimarakkar','61','Arangath Parambil house ,\nMangalam Punnamana','Grade B','M','Mangalam','6','9847 77 28 00','9567 20 39 68','2022-09-12 00:00:00',NULL,NULL,'Noufal','Prostatomegali psy',0,'Mangalam-Punnamana Kuttammakkal Road',''),(189,'81/2022','Seenath','51','Kanjikkoth house,\nmangalam post,\nMangalam','Grade B','F','Mangalam','5','8113 78 19 14 ','7559 88 64 69','2022-09-15 00:00:00',NULL,NULL,'SHAMSUDHEEN ','psy, non healing ulcer right foot ',0,'mangalam- koottayi road- first left road',''),(190,'82/2022','Kari','67','Chamaparambil house\nChennara','Grade A','M','Mangalam','8','9846 50 68 02','9946 82 63 11','2022-09-18 00:00:00','2022-09-24 00:00:00',NULL,'','DM, COPD',0,'',''),(191,'83/2022','Thankamani','56','Thottiyil house, \nValamaruthur,Kavancheri','Grade B','F','Mangalam','10','7909 22 36 25','9656 80 83 69','2022-09-20 00:00:00',NULL,NULL,'SADATH','DM,HTN,CAD',0,'OPPOSIT OF AMBADI STOP',''),(192,'84/2022','Saithalikkutty','67','Kanjikkoth, Chennara','Grade B','M','Mangalam','7','9656 38 80 70','94 000 80 70','2022-09-24 00:00:00',NULL,NULL,'SHAMSUDHEEN ','DM,HTN,CAD',0,'cHENNARA- RICE MILL ROAD SMALL BRIDGE INFRONT OF ALANS VILLA',''),(193,'85/2022','Chandran','66','Mannath house, Pulluni, Karattukadav Road','Grade A','M','Mangalam','2','9895 75 81 74 ','7558 93 43 96','2022-09-25 00:00:00',NULL,NULL,'','DM,CAD',0,'Pulluni-Karattukadav road',''),(194,'86/2022','Neeli','75','Mannoopadath, Mangalam,Pulluni','Grade A','F','Mangalam','2','6238 55 2122','9526 12 12 11','2022-09-27 00:00:00',NULL,NULL,'','HTN,OLD CVA',0,'BACK OF PULLUNI TEMPLE, NEAR TOWER',''),(195,'87/2022','Beepathu','85','Erinjikkatt, Thriprangod,\nKaimalasseri','Grade A','F','Thriprangode','16','75 88 01 91 13','9645 01 91 13','2022-09-28 00:00:00',NULL,NULL,'','DM',0,'',''),(196,'88/2022','Kunjimarakkar','71','Muyyalath Valappil ,Muttanoor(po)\nKurumbadi','Grade A','M','Mangalam','12','7558 93 43 99','9895 94 66 86 ','2022-10-04 00:00:00','2022-11-11 00:00:00',NULL,'','CAD',0,'Near Kurumbadi supermarket',''),(197,'89/2022','Kousalya','64','Manayath valappil,\nKavancheri po, Valamaruthur.','Grade A','F','Mangalam','10','9061 97 27 93','9544 57 13 15 ','2022-10-05 00:00:00','2022-12-17 00:00:00',NULL,'','AML m2, RLL',0,'Kavancheri- Thathamkulam arabi palli road',''),(198,'90/2022','Beemakkutty','62','Chirayil house , Mangalam post,\nKoottayi kadav road','Grade A','F','Mangalam','4','8606 59 67 25 ','9061 49 88 10','2022-10-06 00:00:00',NULL,NULL,'','CA Breast',0,'Mangalam-Koottayi kadav Road',''),(199,'91/2022','Abdul khadar','69','Kizhakke Thaivalappil house, Mangalam P.O\nThalookkara','Grade A','M','Mangalam','2','9633 751 741','9947 40 43 25','2022-10-09 00:00:00','2022-12-17 00:00:00',NULL,'','CA Lung, CAD',0,'Annasseri- Thalookkara road, Opposit road of AKG centre',''),(200,'92/2022','Saradha','66','Thattarakkal house, Chennara','Grade B','F','Mangalam','8','9497 76 20 28','9746 26 97 83','2022-10-16 00:00:00',NULL,NULL,'','DM,HTN',0,'Karuna- chennara road, near Nisthar\'s house',''),(201,'93/2022','Sarojini','96','Renuka house,\nPulluni','Grade A','F','Mangalam','2','9847 211 465','8606 66 40 95','2022-10-18 00:00:00','2022-12-12 00:00:00',NULL,'FOUSIYA','HTN,CAD',0,'Near Pullunikkav Temple',''),(202,'94/2022','Saithalikkutty','00','Menothil house,\nMangalam','Grade B','M','Mangalam','3','6235 04004 ','7909 1717 44','2022-10-21 00:00:00',NULL,NULL,'Asiya','DM, CAD, CKD',0,'Pazhaya post office- sivakshethram road',''),(203,'95/2022','Kadheeja ','61','Kanjikkoth house,\nChennara','Grade B','F','Mangalam','7','88 93 01 11 11','9745 05 27 27','2022-10-23 00:00:00','2023-01-06 00:00:00',NULL,'SADATH','DM, HTN ',0,'Chennara- Colony road (Amathod)',''),(204,'96/2022','saritha','38','kalleri (house)chennara,  moulana college','Grade B','F','Mangalam','8','9562081749','9961794346','2022-10-29 00:00:00',NULL,NULL,'nil','adenocacinoma,  sigmoidcolon,&endometriod  carcinoma stage 3 rd_b.seizure disorder &depression',0,'near moulana college','4'),(205,'97/2022','Kadheejakkutty','95','Cherammal house,\nCherupunna','Grade A','F','Mangalam','12','9946 42 3060 ','9995 28 48 48 ','2022-10-31 00:00:00','2022-11-06 00:00:00',NULL,'Safiya','HTN,CAD',0,'Illathappadi- Madrasa hall road',''),(206,'98/2022','Raghavan ','80','Nayakkara house, \nPerinthiruthi','Grade A','M','Mangalam','5','9847 48 98 79','9745 52 10 66','2022-11-02 00:00:00','2022-11-15 00:00:00',NULL,'','HTN, CAD',0,'Chennara-Perinthiruthi-Thekke kadav Road',''),(207,'99/2022','Fathimmu','93','Kalathil Parambil house,\nVailippadam','Grade A','F','Mangalam','6','9745 83 54 66','9745 83 48 11','2022-11-03 00:00:00',NULL,NULL,'','DM, HTN, CAD',0,'Near Vayalippadam smasanam',''),(208,'100/2022','Pankajakshi','74','Thondiyil house,\nchennara','Grade A','F','Mangalam','13 ','9947 67 40 12','9656 63 0892','2022-11-04 00:00:00','2022-12-27 00:00:00',NULL,'SAFIYA','HTN,CVA(L)',0,'CHENNARA- PARUTHIPPALAM- YATHEEM KHANA ROAD',''),(209,'101/2022','Aleema','95','Kolappatt house, Payyapadam , Mangalam','Grade A','F','Mangalam','3','8156 93 93 12 ','7025 3010 56','2022-11-04 00:00:00',NULL,NULL,'FOUSIYA','HTN,CAD, POST COVID',0,'Payyapadam ,near volundiyar fousiya',''),(210,'102/2022','Avvaumma','70','Pathummaparambil house,\nKavancheri','Grade A','F','Mangalam','11','9562 75 42 69','7994 05 4269','2022-11-16 00:00:00','2022-11-26 00:00:00',NULL,'SADATH','',0,'Kavancheri- Opposit kanal road -Thangal road ',''),(211,'103/2022','Entheenkutty','70','Chelachan veettil Kalathethil,\nKurumbadi','Grade B','M','Mangalam','12','6238 34 23 92','7594 99 22 88','2022-11-17 00:00:00',NULL,NULL,'SON OF PATIENT ','DM, HTN, CAD',0,'KURUMBADI ',''),(212,'104/2022','Saradha','73','Melepura, Pulluni, Mangalam','Grade B','F','Mangalam','2','9741 13 44 96','8088 99 75 12','2022-11-22 00:00:00',NULL,NULL,'','HTN, CKD',0,'PULLUNI- KARATTUKADAV ROAD, OPPOSIT CHERIYA PALLI',''),(213,'105/2022','Hajara','48','Ponnamkundil House,\nMangalam, Chennara','Grade B','F','Mangalam','7','7034 89 57 30','7510 72 22 58','2022-11-23 00:00:00',NULL,NULL,'Majeed, Musthafa','',0,'Chennara_ Kulappadam road',''),(214,'106/2022','Babu','47','Chathangatt house, Valamaruthur,Kavancheri','Grade B','M','Mangalam','10','9846 00 90 65','8606 40 70 87','2022-12-12 00:00:00',NULL,NULL,'','DM, CA PANCREAS',0,'VALAMARUTHUR- DAM ROAD-NEAR WARD MEMBER ARIFA',''),(215,'107/2022','Shiju','40','Kannethayil, Thottiyilangadi, Mangalam','','M','Mangalam','4','9961 12 44 17','','2022-12-12 00:00:00',NULL,NULL,'','Quarter plegea, spinal code injury',0,'Thiruthummal road , before cheriya paalam',''),(216,'108/2022','Amina','85','Kanjikkoth house,\nMangalam','Grade B','F','Mangalam','7','8547 33 70 78','7034 17 07 81','2022-12-13 00:00:00',NULL,NULL,'','DM, HTN, CAD, COPD, MILD MR, FRACTURE- RIGHT SIDE',0,'MANGALAM- KALLU SHOP ROAD- NEAR TRANSFORMER',''),(217,'109/2022','Surendran ','48','Chambayil house,\nValamaruthur,\nKavancheri','Grade A','M','Mangalam','10','9745 830 966','9747 830 966','2022-12-14 00:00:00',NULL,NULL,'','Miotonic Distrophy',0,'VALAMARUTHUR, BEFORE DAM ROAD- CONCRETE ROAD RIGHT',''),(218,'110/2022','Vasudevan namboothiri','72','Nariparambu mana, Kavancheri','Grade B','M','Mangalam','9','9946 75 82 36','8593 09 87 59','2022-12-17 00:00:00',NULL,NULL,'','DM,HTN, PROSTATOMEGALI',0,'PANAPADI ROAD SOUTH SIDE OF SREEDURGA TEMPLE',''),(219,'111/2022','Muhammedkutty ','72','Kacheri kalichath, Arakkalaparamb, Mangalam','Grade B','M','Mangalam','5','9645 53 13 44','9847 73 19 80','2022-12-17 00:00:00',NULL,NULL,'','DM,HTN',0,'ARAKKALAPARAMB PALLI ROAD',''),(220,'112/2022','Damodaran','84','Theratty house, Pulluni,\nMangalam','Grade B','M','Mangalam','2','9497 02 9009','9995 98 3072','2022-12-20 00:00:00',NULL,NULL,'','',0,'backside of Pulluni temple Kolony road',''),(221,'113/2022','Kunjayisu','55','Kulangara veettil house,\nArakkalaparamb','Grade B','F','Mangalam','7','9995 17 74 13','9995 17 63 48','2022-12-21 00:00:00','2023-01-08 00:00:00',NULL,'ISAHAQ','RHD, MI, AKG, FVR,CKD',0,'MANGALAM-ARAKKALAPARAMB',''),(222,'114/2022','Lisi','40','Kalathil parambil house, Kavancheri','Grade B','F','Mangalam','10','9846 64 63 08','9562 49 4019','2022-12-24 00:00:00',NULL,NULL,'','DM, CAD',0,'END OF VALAMARUTHUR DAM ROAD',''),(223,'115/2022','Nithinkumar','29','Kakkasseri house, Valamaruthur','Grade A','M','Mangalam','9','9633 23 14 91','','2022-12-28 00:00:00',NULL,NULL,'SADATH','seizere disorder',0,'VALAMARUTHOOR ANGADI- DURGA TEMPLE ROAD',''),(224,'1/2023','Velayudhan','67','Makketh house,\nChennara, Perinthiruthi','Grade A','M','Mangalam','14','9544 82 27 94','9946 09 12 51','2023-01-01 00:00:00',NULL,NULL,'','CAD, HTN',0,'PERINTHIRUTHI- THEKKE KADAV- THOOKKUPALAM ROAD',''),(225,'2/2023','Raman','75','Vadakke chalakkal , Pulluni','Grade B','M','Mangalam','2','9539 38 37 05','','2023-01-04 00:00:00',NULL,NULL,'','CAD',0,'KARUNA- PULLUNI-PULLUNIKKAV',''),(226,'3/2023','PUSHPA','54','NAYAKKARA, PERINTHIRUTHI, MANGALAM','Grade B','F','Mangalam','5','9846 01 2412','9567 94 6741','2023-01-17 00:00:00',NULL,NULL,'','CA PANCREAS',0,'',''),(227,'4/2023','NARAYANAN','62','THATTARAKKAL, HARIJAN KOLANY,\nCHENNARA','Grade A','M','Mangalam','8','9846 350 770','7558 93 46 50','2023-01-20 00:00:00','2023-02-08 00:00:00',NULL,'','HTN,CA LUNG SPINAL METS,COPD',0,'KARUNA- HARIJAN KOLANY- WATER TANK',''),(228,'5/2023','YAHUTTY','63','VALIYA PEEDIYEKKAL HOUSE,\nMUTTANOOR','Grade A','M','Purathoor','3','8891 32 35 91','8113 00 3991','2023-01-26 00:00:00',NULL,NULL,'','CA THYROID WITH WODEL METS',0,'ASUPATRIPPADI-BANK ROAD-NEAR KC BAVA HOUSE',''),(229,'6/2023','PRASANNA','57','PATHAYAPURAKKAL HOUSE,\nCHENNARA','Grade A','F','Mangalam','7','9048 96 06 09','9544 49 26 83','2023-01-28 00:00:00',NULL,NULL,'','DM, HTN, DIABETIC WOUND',0,'CHENNARA SCHOOL- BEFORE PARUTHIPPALAM-QUARTERS',''),(230,'7/2023','alikkutty','72','CHERACHAMVEETTIL PUTHANVEETTIL HOUSE\nMANGALAM, KOOTTAYI ROAD','Grade B','M','Mangalam','4','9747  364604','9048 22 58 34','2023-02-01 00:00:00',NULL,NULL,'ASIYA','DM, CAD, CERVICAL COMPRESSIVE MYELOPATHY',0,'KOOTTAYI KADAV- MADRASA HALL ROAD-NEAR KHABARSTAN',''),(231,'8/2023','AMMUTTY','92','PADUNNAPPATT HOUSE,\nCHENNARA','Grade B','F','Mangalam','8','9895 44 57 46','','2023-02-02 00:00:00',NULL,NULL,'','HTN',0,'NEAR PARUTHIPPALAM ,CHENNARA',''),(232,'9/2023','FATHIMA','70','PUZHAVAKKATH HOUSE, PAYYAPADAM','Grade A','F','Mangalam','3','8129 35 24 40','','2023-02-05 00:00:00',NULL,NULL,'FOUSIYA','CA,DM, HTN',0,'KARUNA- PAYYAPADAM KUNJIMUHAMMAD',''),(233,'10/2023','AYYOOB','49','CHOLAKKAL HOUSE,\nMUTTANOOR,\nCHERUPUNNA','','M','Mangalam','12','9946 34 44 17','9947 57 11 27','2023-02-07 00:00:00',NULL,NULL,'','DM,CLD',0,'NOC PADI ANGADI- LEFT SIDE ROAD',''),(234,'11/2023','KADHEEJA','78','THANDASERI, CHENNARA','','F','Mangalam','13','9895 415 090 ','9446 61 26 13 ','2023-02-10 00:00:00',NULL,NULL,'','HTN,CAD',0,'PARUTHIPPALAM-PERINTHIRUTHI ROAD','');
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rehabilitation`
--

DROP TABLE IF EXISTS `rehabilitation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rehabilitation` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Pno` varchar(45) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `Quantity` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rehabilitation`
--

LOCK TABLES `rehabilitation` WRITE;
/*!40000 ALTER TABLE `rehabilitation` DISABLE KEYS */;
/*!40000 ALTER TABLE `rehabilitation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `route`
--

DROP TABLE IF EXISTS `route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `route`
--

LOCK TABLES `route` WRITE;
/*!40000 ALTER TABLE `route` DISABLE KEYS */;
INSERT INTO `route` VALUES (2,'PUNNAMANA-KUTTAMMAKKAL -ANNASSERY'),(3,'VAYALIPADAM,VALAMARUTHOOR'),(4,'KAVANCHERY,MARAVANTHA'),(5,'KOOTAI KADAVU,THIRUTHUMMAL,THOTTIYILANGADI,ARAKKALAPARAMBU'),(6,'CHENNARA,N.O.C PADI,HC,PERUNTHIRUTHI,KURUMBADI'),(7,'PAZHAYAPOST OFFICE'),(8,'SINDICATE,MANGALAM,KAIMALASSERY');
/*!40000 ALTER TABLE `route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usertype`
--

DROP TABLE IF EXISTS `usertype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usertype` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `usertype` varchar(45) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usertype`
--

LOCK TABLES `usertype` WRITE;
/*!40000 ALTER TABLE `usertype` DISABLE KEYS */;
INSERT INTO `usertype` VALUES (1,'Admin'),(2,'Accounts'),(3,'Medicines'),(4,'Patients');
/*!40000 ALTER TABLE `usertype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volunteer`
--

DROP TABLE IF EXISTS `volunteer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volunteer` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `Phone` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volunteer`
--

LOCK TABLES `volunteer` WRITE;
/*!40000 ALTER TABLE `volunteer` DISABLE KEYS */;
INSERT INTO `volunteer` VALUES (2,'FOUSIYA','PUNNAMANA','9747090405'),(3,'SADATH','KAVANCHERY','9446770031'),(4,'YAHUTTY','MANGALAM','9846206036'),(5,'SHAMSUDHEEN A','MANGALAM','8086616215');
/*!40000 ALTER TABLE `volunteer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'palcareplus'
--
/*!50003 DROP PROCEDURE IF EXISTS `log_msg` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `log_msg`(IN in_msg VARCHAR(255))
BEGIN
 insert into log values(in_msg);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddAccountLedger` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddAccountLedger`(
IN p_in_txndate datetime,
IN p_in_desc varchar(200),
IN p_in_type varchar(45),
IN p_in_amount DECIMAL(10,2),
IN p_in_txntype varchar(45),
IN p_in_name varchar(200),
IN p_in_isReceipt tinyint,
IN p_in_paymentMode varchar(45),
IN p_in_bankMode varchar(45),
IN p_in_bankName varchar(200),
IN p_in_txnNo varchar(100),
IN p_in_chNo varchar(45),
IN p_in_chdate datetime,
IN p_in_chBank varchar(200),
IN p_in_chAmount DECIMAL(10,2),
OUT p_out int
)
BEGIN
	
    Declare p_receiptNo int;
    
	IF extract(year from p_in_txndate) = 1 THEN
		SET p_in_txndate = NULL;
	END IF;
	
	IF extract(year from p_in_chdate) = 1 THEN
		SET p_in_chdate = NULL;
	END IF;
	
    IF p_in_bankMode = "Cheque" THEN
		SET p_in_chAmount = p_in_amount;
        SET p_in_amount = 0;
	END IF;
    
    IF p_in_isReceipt = 1 THEN
		IF p_in_txntype = "Income" THEN
			update center set incomereceiptno = incomereceiptno + 1 where id = 1; 
			select incomereceiptno into p_receiptNo from center  where id = 1; 
        ELSE
			update center set expensereceiptno = expensereceiptno + 1 where id = 1; 
			select expensereceiptno into p_receiptNo from center  where id = 1;
        END IF;
	END IF;
    
	INSERT INTO `account`
		(
		`txndate`,
		`desc`,
		`type`,
		`amount`,
		`txntype`,
		`name`,
		`receiptNo`,
		`isReceipt`,
		`paymentMode`,
		`bankMode`,
		`bankName`,
		`txnNo`,
		`chNo`,
		`chdate`,
		`chBank`,
		`chAmount`)
		VALUES
		(
        p_in_txndate,
        p_in_desc,
		p_in_type,
        p_in_amount,
        p_in_txntype,
        p_in_name,
        p_receiptNo,
        p_in_isReceipt,
        p_in_paymentMode,
        p_in_bankMode,
        p_in_bankName,
        p_in_txnNo,
        p_in_chNo,
        p_in_chdate,
        p_in_chBank,
        p_in_chAmount
        );
        
        set p_out =  LAST_INSERT_ID();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddAsset` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddAsset`(
IN p_in_name varchar(200),
IN p_in_quantity int,
IN p_in_cost DECIMAL(10,2)
)
BEGIN
	declare p_ano varchar(10);
    
    IF NOT EXISTS (SELECT 1 FROM `asset` where name = p_in_name) THEN
    	select concat('A',ifnull(max(id),0) +1) into p_ano from `asset`;
        
      	INSERT INTO `asset`
		(`ano`,	`name`,	quantity, cost)
		VALUES (p_ano,p_in_name,p_in_quantity, p_in_cost );
	ELSE
		UPDATE `asset`
		SET
		`quantity` = p_in_quantity,
		`cost` = p_in_cost
		WHERE `name` = p_in_name;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddBank` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddBank`(
IN p_in_name varchar(200)
)
BEGIN
	INSERT INTO `bank`
	(`Name`)
	VALUES
	(p_in_name );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddCE` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddCE`(
IN p_in_txndate datetime,
IN p_in_source varchar(45),
IN p_in_bankName varchar(200),
IN p_in_amount DECIMAL(10,2)
)
BEGIN
	
    IF p_in_source = "Cash" THEN
		INSERT INTO `account`
		(
		`txndate`,
		`desc`,
		`type`,
		`amount`,
		`txntype`,
		`name`,
		`isReceipt`,
		`paymentMode`,
		`bankMode`,
		`bankName`,
        `chAmount`
		)
		VALUES
		(
        p_in_txndate,
        "Contra Entry - Cash", -- p_in_desc
		"Contra Entry", -- p_in_type
        p_in_amount * -1,
        "Expense", --  p_in_txntype
        "", -- p_in_name
        0, -- p_in_isReceipt
        "Cash", -- p_in_paymentMode
        "", -- p_in_bankMode
        "", -- p_in_bankName
        0 --  `chAmount`
        );
        
        INSERT INTO `account`
		(
		`txndate`,
		`desc`,
		`type`,
		`amount`,
		`txntype`,
		`name`,
		`isReceipt`,
		`paymentMode`,
		`bankMode`,
		`bankName`,
		`chAmount`
		)
		VALUES
		(
        p_in_txndate,
        "Contra Entry - Bank", -- p_in_desc
		"Contra Entry", -- p_in_type
        p_in_amount,
        "Income", --  p_in_txntype
        "", -- p_in_name
        0, -- p_in_isReceipt
        "Bank", -- p_in_paymentMode
        "Transfer", -- p_in_bankMode
        p_in_bankName,
        0 --  `chAmount`
        );
	ELSE
		INSERT INTO `account`
		(
		`txndate`,
		`desc`,
		`type`,
		`amount`,
		`txntype`,
		`name`,
		`isReceipt`,
		`paymentMode`,
		`bankMode`,
		`bankName`,
        `chAmount`
		)
		VALUES
		(
        p_in_txndate,
        "Contra Entry - Bank", -- p_in_desc
		"Contra Entry", -- p_in_type
        p_in_amount * -1,
        "Expense", --  p_in_txntype
        "", -- p_in_name
        0, -- p_in_isReceipt
        "Bank", -- p_in_paymentMode
        "Transfer", -- p_in_bankMode
        p_in_bankName,
        0 --  `chAmount`
        );
        
        INSERT INTO `account`
		(
		`txndate`,
		`desc`,
		`type`,
		`amount`,
		`txntype`,
		`name`,
		`isReceipt`,
		`paymentMode`,
		`bankMode`,
		`bankName`,
        `chAmount`
		)
		VALUES
		(
        p_in_txndate,
        "Contra Entry - Cash", -- p_in_desc
		"Contra Entry", -- p_in_type
        p_in_amount,
        "Income", --  p_in_txntype
        "", -- p_in_name
        0, -- p_in_isReceipt
        "Cash", -- p_in_paymentMode
        "", -- p_in_bankMode
        "", -- p_in_bankName
        0 --  `chAmount`
        );
	END IF;
    	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddDiagnosis` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddDiagnosis`(
IN p_in_name varchar(100)
)
BEGIN
	INSERT INTO `diagnosis`
	(`Name`)
	VALUES
	(p_in_name );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddEquipment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddEquipment`(
IN p_in_name varchar(200),
IN p_in_name_lower varchar(200),
IN p_in_stock int,
IN p_in_inuse int,
IN p_in_damage int
)
BEGIN
	declare p_eno varchar(10);
    
    IF NOT EXISTS (SELECT 1 FROM `equipment` where name_lower = p_in_name_lower) THEN
    	select concat('E',ifnull(max(id),0) +1) into p_eno from `equipment`;
      	INSERT INTO `equipment`
		(`eno`,	`name`,	`name_lower`, stock, damage, inuse)
		VALUES (p_eno,p_in_name,p_in_name_lower,p_in_stock, p_in_damage, p_in_inuse );
	ELSE
		UPDATE `equipment`
		SET
		`stock` = p_in_stock,
		`damage` = p_in_damage,
		`inuse` = p_in_inuse
		WHERE `name_lower` = p_in_name_lower;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddExpenseType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddExpenseType`(
IN p_in_expensetype varchar(100)
)
BEGIN
	INSERT INTO `expensetype`
	(`ExpenseType`)
	VALUES
	(p_in_expensetype );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddHomeCarePlan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddHomeCarePlan`(
IN p_in_pno varchar(45),
IN p_in_name varchar(200),
IN p_in_type varchar(45),
IN p_in_date datetime
)
BEGIN

	IF extract(year from p_in_date) = 1 THEN
		SET p_in_date = NULL;
	END IF;

	INSERT INTO `homecareplan`
	(`Pno`,
	`Date`,
	`Type`,
    `PatientName`)
	VALUES
	(p_in_pno,
    p_in_date,
    p_in_type,
    p_in_name
    );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddIncomeType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddIncomeType`(
IN p_in_incometype varchar(100)
)
BEGIN
	INSERT INTO `incometype`
	(`IncomeType`)
	VALUES
	(p_in_incometype );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddMedicine` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddMedicine`(
IN p_in_txndate datetime,
IN p_in_name varchar(200),
IN p_in_name_lower varchar(200),
IN p_in_stock_main int,
IN p_in_purchase_invdate datetime,
IN p_in_purchase_invno varchar(45),
IN p_in_purchase_batchno varchar(45),
IN p_in_purchase_expdate datetime,
IN p_in_purchase_mfgdate datetime,
IN p_in_purchase_rate decimal(10,2),
IN p_in_purchase_dealer varchar(200),
IN p_in_purchase_mainStock int
)
BEGIN
	declare p_mno varchar(10);
    declare p_m_id int;
    
    IF NOT EXISTS (SELECT 1 FROM `medicine` where NameLower = p_in_name_lower) THEN
    	
        select concat('M',ifnull(max(id),0) +1) into p_mno from `medicine`;
        
    	IF extract(year from p_in_purchase_invdate) = 1 THEN
			SET p_in_purchase_invdate = NULL;
		END IF;
		
		IF extract(year from p_in_purchase_expdate) = 1 THEN
			SET p_in_purchase_expdate = NULL;
		END IF;
		
		IF extract(year from p_in_purchase_mfgdate) = 1 THEN
			SET p_in_purchase_mfgdate = NULL;
		END IF;

		INSERT INTO `medicine`
		(`Mno`,	`Name`,	`NameLower`)
		VALUES (p_mno,p_in_name,p_in_name_lower);

		set p_m_id =  LAST_INSERT_ID();
         
        INSERT INTO `medicinestock`
		(`MedicineId`,`Main`,`Sub`,	`A_kit`,`B_kit`)
		VALUES (p_m_id, p_in_stock_main, 0, 0, 0);
         
        INSERT INTO `medicinepurchase`
		(
		`MedicineId`,
		`invdate`,
		`invno`,
		`batchno`,
		`expdate`,
		`mfgdate`,
		`rate`,
		`dealer`,
		`mainStock`,
		`subStock`,
		`return`)
		VALUES
		(
		p_m_id,
		p_in_purchase_invdate,
		p_in_purchase_invno,
		p_in_purchase_batchno,
		p_in_purchase_expdate,
		p_in_purchase_mfgdate,
		p_in_purchase_rate,
		p_in_purchase_dealer,
		p_in_purchase_mainStock,
		0,
		0);
 		
        CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_mno, 
		p_in_name,
		'Add', -- txnType
		'To main stock', -- desc
		0, -- openingMain
        0, -- openingSub
        0, -- openingAKit
        0, -- openingBKit
		p_in_stock_main, -- qty
		p_in_stock_main, -- closingMain
		0, -- closingSub
        0, -- closingAKit
        0, -- closingBKit
        '', -- pno
        '' -- patientName
        );
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddMedicineHistory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddMedicineHistory`(
IN p_in_m_id int,
IN p_in_txnDate datetime,
IN p_in_mno varchar(45),
IN p_in_medName varchar(200),
IN p_in_txnType varchar(45),
IN p_in_desc varchar(45),
IN p_in_openingMain int,
IN p_in_openingSub int,
IN p_in_openingAKit int,
IN p_in_openingBKit int,
IN p_in_qty int,
IN p_in_closingMain int,
IN p_in_closingSub int,
IN p_in_closingAKit int,
IN p_in_closingBKit int,
IN p_in_pno varchar(45),
IN p_in_patientName  varchar(200)
)
BEGIN
	
    INSERT INTO `medicinehistory`
	(
	`MedicineId`,
	`txnDate`,
	`mno`,
	`medName`,
	`txnType`,
	`desc`,
	`openingMain`,
	`openingSub`,
	`openingAKit`,
	`openingBKit`,
	`qty`,
	`closingMain`,
	`closingSub`,
	`closingAKit`,
	`closingBKit`,
	`pno`,
	`patientName`)
	VALUES
	(
	p_in_m_id,
	p_in_txnDate,
	p_in_mno,
	p_in_medName,
	p_in_txnType,
	p_in_desc,
	p_in_openingMain,
	p_in_openingSub,
	p_in_openingAKit,
	p_in_openingBKit,
	p_in_qty,
	p_in_closingMain,
	p_in_closingSub,
	p_in_closingAKit,
	p_in_closingBKit,
	p_in_pno,
	p_in_patientName);

    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddPanjayath` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddPanjayath`(
IN p_in_name varchar(100)
)
BEGIN
	INSERT INTO `panjayath`
	(`Name`)
	VALUES
	(p_in_name );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddPatient` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddPatient`(
IN p_in_pno varchar(45),
IN p_in_name varchar(200),
IN p_in_age varchar(45),
IN p_in_address varchar(255),
IN p_in_grade varchar(45),
IN p_in_gender varchar(45),
IN p_in_panjayath varchar(100),
IN p_in_wardno varchar(45),
IN p_in_phone1 varchar(45),
IN p_in_phone2 varchar(45),
IN p_in_regdate datetime,
IN p_in_expdate datetime,
IN p_in_dropdate datetime,
IN p_in_volunteer varchar(100),
IN p_in_diagnosis varchar(100),
IN p_in_temp tinyint,
IN p_in_route varchar(100),
IN p_in_homecareplan varchar(45),
OUT p_out varchar(10)
)
BEGIN
	
    IF EXISTS (SELECT 1 FROM patient where PNo = p_in_pno) THEN
    	SET p_out = "1";
    ELSE
    	IF extract(year from p_in_regdate) = 1 THEN
			SET p_in_regdate = NULL;
		END IF;
		
		IF extract(year from p_in_expdate) = 1 THEN
			SET p_in_expdate = NULL;
		END IF;
		
		IF extract(year from p_in_dropdate) = 1 THEN
			SET p_in_dropdate = NULL;
		END IF;

		INSERT INTO `patient`
		(
		`PNo`,
		`Name`,
		`Age`,
		`Address`,
		`Grade`,
		`Gender`,
		`Panjayath`,
		`WardNo`,
		`Phone1`,
		`Phone2`,
		`RegDate`,
		`ExpDate`,
		`DropDate`,
		`Volunteer`,
		`Diagnosis`,
		`Temp`,
		`Route`,
		`HomeCarePlan`)
		VALUES
		(
		p_in_pno,
		p_in_name,
		p_in_age,
		p_in_address,
		p_in_grade,
		p_in_gender,
		p_in_panjayath,
		p_in_wardno,
		p_in_phone1,
		p_in_phone2,
		p_in_regdate,
		p_in_expdate,
		p_in_dropdate,
		p_in_volunteer,
		p_in_diagnosis,
		p_in_temp,
		p_in_route,
		p_in_homecareplan
		);
        
        SET p_out = "0";
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddRehabilitation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddRehabilitation`(
IN p_in_pno varchar(45),
IN p_in_desc varchar(200),
IN p_in_qty int,
IN p_in_date datetime
)
BEGIN

	IF extract(year from p_in_date) = 1 THEN
		SET p_in_date = NULL;
	END IF;

	INSERT INTO `rehabilitation`
	(`Pno`,
	`Date`,
	`Description`,
    `Quantity`)
	VALUES
	(p_in_pno,
    p_in_date,
    p_in_desc,
    p_in_qty
    );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddRoute` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddRoute`(
IN p_in_name varchar(100)
)
BEGIN
	INSERT INTO `route`
	(`Name`)
	VALUES
	(p_in_name );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddVolunteer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddVolunteer`(
IN p_in_name varchar(100),
IN p_in_location varchar(100),
IN p_in_phone varchar(45)
)
BEGIN
	INSERT INTO `volunteer`
	(`Name`,
	`Location`,
	`Phone`)
	VALUES
	(p_in_name,
    p_in_location,
    p_in_phone
    );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_DisposeEquipment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_DisposeEquipment`(
IN p_in_txndate datetime,
IN p_in_id int,
IN p_in_desc varchar(200),
IN p_in_eno varchar(45),
IN p_in_qty int,
IN p_in_name varchar(200),
OUT p_out int
)
BEGIN
	
    Declare p_receiptNo int;
    
	IF extract(year from p_in_txndate) = 1 THEN
		SET p_in_txndate = NULL;
	END IF;
	
	IF EXISTS (SELECT 1 FROM `equipment` where Id = p_in_id) THEN
      	INSERT INTO `equipmentdispose`
			(
			`EquipmentId`,
			`Eno`,
			`Name`,
			`Desc`,
			`Qty`,
			`TxnDate`)
			VALUES
			(
			p_in_id,
			p_in_eno,
			p_in_name,
			p_in_desc,
			p_in_qty,
			p_in_txndate);
         
        set p_out =  LAST_INSERT_ID();
        
		UPDATE `equipment`
		SET
		damage = (damage - p_in_qty)
		WHERE Id = p_in_id;
	END IF;
       
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetAccountLedger` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetAccountLedger`(
IN p_in_fromdate datetime,
IN p_in_todate datetime
)
BEGIN

SELECT 
	`account`.`Id`,
    `account`.`txndate`,
    `account`.`desc`,
    `account`.`type`,
    `account`.`amount`,
    `account`.`txntype`,
    `account`.`name`,
    `account`.`receiptNo`,
    `account`.`isReceipt`,
    `account`.`paymentMode`,
    `account`.`bankMode`,
    `account`.`bankName`,
    `account`.`txnNo`,
    `account`.`chNo`,
    `account`.`chdate`,
    `account`.`chBank`,
    `account`.`chAmount`
FROM `account`
WHERE 
	(`account`.`txntype` = 'Income' OR `account`.`txntype` = 'Expense') AND
    `account`.`amount` != 0 AND
    `account`.`txndate` >= p_in_fromdate AND
    `account`.`txndate` <= p_in_todate
;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetAccountReceipt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetAccountReceipt`(
IN p_in_id varchar(2000)
)
BEGIN

SELECT 
	`account`.`Id`,
    `account`.`txndate`,
    `account`.`desc`,
    `account`.`type`,
    `account`.`amount`,
    `account`.`txntype`,
    `account`.`name`,
    `account`.`receiptNo`,
    `account`.`isReceipt`,
    `account`.`paymentMode`,
    `account`.`bankMode`,
    `account`.`bankName`,
    `account`.`txnNo`,
    `account`.`chNo`,
    `account`.`chdate`,
    `account`.`chBank`,
    `account`.`chAmount`
FROM `account`
WHERE FIND_IN_SET(Id, p_in_id)
	and isReceipt = 1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetAssets` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetAssets`()
BEGIN
	
   SELECT `asset`.`Id`,
		`asset`.`ano`,
		`asset`.`name`,
		`asset`.`quantity`,
		`asset`.`cost`
	FROM `asset`
    ORDER BY `asset`.`name`;    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetBankList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetBankList`()
BEGIN
	select Id, Name,IsCash from bank order by Name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetCenterDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetCenterDetails`()
BEGIN
SELECT `center`.`Id` AS _id,
    `center`.`Name`,
    `center`.`Address`,
    `center`.`Desc`,
    `center`.`Location`,
    `center`.`Phone`,
    `center`.`RegNo`,
    `center`.`AddressMal`,
     `center`.`DescMal`,
    `center`.`LocationMal`,
    `center`.`NameMal`,
    `center`.`IncomeReceiptNo`,
    `center`.`ExpenseReceiptNo`,
    `center`.`MedExpiryDays`,
    `center`.`MedThresholdCount`,
    `center`.`ValidTill`,
    `center`.`TodayAPI`
FROM `center`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetChequeReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetChequeReport`(
IN p_in_status varchar(20)
)
BEGIN

	IF p_in_status = 'All' THEN
		SELECT 
			Id,txndate,`desc`,`type`,amount,txntype,`name`,receiptNo,isReceipt,paymentMode,bankMode,
			bankName,txnNo,chNo,chdate,chBank,chAmount
		FROM `account`
		WHERE 
			bankMode = "Cheque";
    ELSEIF p_in_status = 'Pending' THEN
		SELECT 
			Id,txndate,`desc`,`type`,amount,txntype,`name`,receiptNo,isReceipt,paymentMode,bankMode,
			bankName,txnNo,chNo,chdate,chBank,chAmount
		FROM `account`
		WHERE 
			bankMode = "Cheque" AND
            amount = 0;
    ELSEIF p_in_status = 'Cleared' THEN
		SELECT 
			Id,txndate,`desc`,`type`,amount,txntype,`name`,receiptNo,isReceipt,paymentMode,bankMode,
			bankName,txnNo,chNo,chdate,chBank,chAmount
		FROM `account`
		WHERE 
			bankMode = "Cheque" AND
            amount != 0;
    END IF;

	

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetCheques` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetCheques`()
BEGIN
SELECT 
	`account`.`Id`,
    `account`.`txndate`,
    `account`.`desc`,
    `account`.`type`,
    `account`.`amount`,
    `account`.`txntype`,
    `account`.`name`,
    `account`.`receiptNo`,
    `account`.`isReceipt`,
    `account`.`paymentMode`,
    `account`.`bankMode`,
    `account`.`bankName`,
    `account`.`txnNo`,
    `account`.`chNo`,
    `account`.`chdate`,
    `account`.`chBank`,
    `account`.`chAmount`
FROM `account`
WHERE 
    `account`.`amount` = 0 AND
    `account`.`bankMode` = 'Cheque'
;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetDashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetDashboard`()
BEGIN

	select sum(Main) Main, Sum(Sub) Sub, Sum(A_kit) A_Kit, Sum(B_kit) B_Kit
	from medicinestock;
    
    select Grade, Count(Id) total from patient group by Grade;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetDiagnosisList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetDiagnosisList`()
BEGIN
	select Id, Name from diagnosis order by Name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetDisposeReceipt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetDisposeReceipt`(
IN p_in_id varchar(2000)
)
BEGIN

	SELECT
		`equipmentdispose`.`EquipmentId`,
		`equipmentdispose`.`Eno`,
		`equipmentdispose`.`Name`,
		`equipmentdispose`.`Desc`,
		`equipmentdispose`.`Qty`,
		`equipmentdispose`.`TxnDate`
	FROM `equipmentdispose`
    WHERE FIND_IN_SET(Id, p_in_id);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetEquipmentDisposeReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetEquipmentDisposeReport`(
IN p_in_fromDate datetime,
IN p_in_toDate datetime
)
BEGIN

	SELECT 
		`equipmentdispose`.`Id`,
		`equipmentdispose`.`EquipmentId`,
		`equipmentdispose`.`Eno`,
		`equipmentdispose`.`Name`,
		`equipmentdispose`.`Desc`,
		`equipmentdispose`.`Qty`,
		`equipmentdispose`.`TxnDate`
	FROM `equipmentdispose`
    WHERE
		TxnDate >= p_in_fromDate AND
        TxnDate <= p_in_toDate;		   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetEquipmentReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetEquipmentReport`(
IN p_in_eno varchar(45)
)
BEGIN

	IF p_in_eno = '' THEN
		select
			t.Id,
			t.patientname,
			t.qty,
			t.outdate,
			t.indate,
            t.pno,
			e.name,
            ifnull(t.deposit,0) deposit,
            ifnull(t.rent,0) rent
		from 
		equipmenttracker t
		inner join equipment e on t.equipmentid = e.id
        order by e.name;
		
    ELSE
		select
			t.Id,
			t.patientname,
			t.qty,
			t.outdate,
			t.indate,
            t.pno,
			e.name,
            ifnull(t.deposit,0) deposit,
            ifnull(t.rent,0) rent
		from 
		equipmenttracker t
		inner join equipment e on t.equipmentid = e.id
		where e.eno = p_in_eno
		order by e.name;
         
    END IF;
		   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetEquipments` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetEquipments`()
BEGIN
	
   SELECT `equipment`.`Id`,
		`equipment`.`eno`,
		`equipment`.`name`,
		`equipment`.`name_lower`,
		`equipment`.`stock`,
		`equipment`.`damage`,
		`equipment`.`inuse`
	FROM `equipment`
    ORDER BY `equipment`.`name`;    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetEquipmentTracker` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetEquipmentTracker`(
IN p_in_eno varchar(45)
)
BEGIN

	select
		t.Id,
		t.patientname,
        t.qty,
        t.outdate,
        t.indate,
        ifnull(t.deposit,0) deposit
    from 
	equipmenttracker t
	inner join equipment e on t.equipmentid = e.id
	where e.eno = p_in_eno
    order by t.outdate;
		   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetExpenseTypeList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetExpenseTypeList`()
BEGIN
	select Id, ExpenseType from expensetype order by ExpenseType;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetHomeCarePlan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetHomeCarePlan`(
IN p_in_fromdate datetime,
IN p_in_todate datetime
)
BEGIN

	SELECT `homecareplan`.`Id`,
		`homecareplan`.`Pno`,
		`homecareplan`.`Date`,
		`homecareplan`.`Type`,
		`homecareplan`.`PatientName`
	FROM `homecareplan`
    where `homecareplan`.`Date` >= p_in_fromdate and
		`homecareplan`.`Date` <= p_in_todate
	order by `homecareplan`.`Date`
    ;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetHomeCarePlanList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetHomeCarePlanList`(
IN p_in_pno varchar(45)
)
BEGIN
	SELECT 
    `Id`,
    `Date`,
    `Type`,
    `PatientName`
FROM `homecareplan`
where Pno = p_in_pno
order by `Date`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetIncomeTypeList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetIncomeTypeList`()
BEGIN
	select Id, IncomeType from incometype order by IncomeType;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetLoginDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetLoginDetails`(
IN p_in_UserName varchar(45)
)
BEGIN
 select 
	l.password,
    u.usertype
from login l
inner join usertype u on l.userTypeId = u.id
where l.username = p_in_UserName;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetMedicineHistory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetMedicineHistory`(
IN p_in_mno varchar(50),
IN p_in_fromDate datetime,
IN p_in_toDate datetime
)
BEGIN

	SELECT 
		`medicinehistory`.`Id`,
		`medicinehistory`.`MedicineId`,
		`medicinehistory`.`txnDate`,
		`medicinehistory`.`mno`,
		`medicinehistory`.`medName`,
		`medicinehistory`.`txnType`,
		`medicinehistory`.`desc`,
		`medicinehistory`.`openingMain`,
		`medicinehistory`.`openingSub`,
		`medicinehistory`.`openingAKit`,
		`medicinehistory`.`openingBKit`,
		`medicinehistory`.`qty`,
		`medicinehistory`.`closingMain`,
		`medicinehistory`.`closingSub`,
		`medicinehistory`.`closingAKit`,
		`medicinehistory`.`closingBKit`,
		`medicinehistory`.`pno`,
		`medicinehistory`.`patientName`
	FROM `medicinehistory`
    WHERE
		mno = p_in_mno AND
        txnDate >= p_in_fromDate AND
        txnDate <= p_in_toDate;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetMedicinePatientHistory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetMedicinePatientHistory`(
IN p_in_pno varchar(20)
)
BEGIN
	
    select 
		txnDate,
        medName,
        qty
	from medicinehistory
	WHERE pno = p_in_pno
    order by txnDate;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetMedicinePurchaseDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetMedicinePurchaseDetails`(
IN p_in_mno varchar(20)
)
BEGIN

	select p.`Id`,
		p.`MedicineId`,
		p.`invdate`,
		p.`invno`,
		p.`batchno`,
		p.`expdate`,
		p.`mfgdate`,
		p.`rate`,
		p.`dealer`,
		p.`mainStock`,
		p.`subStock`,
		p.`return`
	from medicinepurchase p
	inner join medicine m on p.MedicineId = m.Id
	where m.Mno = p_in_mno;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetMedicines` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetMedicines`()
BEGIN
	
    select 
		m.id,
		m.mno,
		m.name,
		st.main,
		st.sub,
		st.A_kit,
		st.B_kit 
	from medicine m
	inner join medicinestock st on m.id = st.MedicineId
    order by m.name;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetMedicineStock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetMedicineStock`(
IN p_in_mno varchar(20)
)
BEGIN
	
    select 
		st.main,
		st.sub,
		st.A_kit,
		st.B_kit 
	from medicine m
	inner join medicinestock st on m.id = st.MedicineId
   WHERE m.Mno = p_in_mno;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetMissingHomeCarePatientList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetMissingHomeCarePatientList`(
IN p_in_fromDate datetime,
IN p_in_toDate datetime
)
BEGIN

	select 
	p.`Id`,p.`PNo`,p.`Name`,p.`Age`,p.`Address`,p.`Grade`,p.`Gender`,p.`Panjayath`,p.`WardNo`,
    p.`Phone1`,p.`Phone2`,p.`RegDate`,p.`ExpDate`,p.`DropDate`,p.`Volunteer`,p.`Diagnosis`,
    p.`Temp`,p.`Route`,p.`HomeCarePlan`
	from patient p
    left join homecareplan hc on 
		p.Pno = hc.Pno and 
        hc.`Date` >= p_in_fromDate AND
		hc.`Date` <= p_in_toDate
	where p.ExpDate is null and p.DropDate is null and p.Temp = 0 and hc.Pno is null
	Order by p.`Name`;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetOP` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetOP`(
IN p_in_pno varchar(50)
)
BEGIN

	Select op.`History`, op.Medicine, op.Remarks
	from op op
    inner join patient p on op.PatientId = p.id
	where p.PNo = p_in_pno;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetPanjayathList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetPanjayathList`()
BEGIN
	select Id, Name from panjayath order by Name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetPatientDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetPatientDetails`(
IN p_in_pno varchar(20)
)
BEGIN

	select 
	`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
	`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
	from patient
	where Pno = p_in_pno;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetPatientList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetPatientList`(
IN p_in_status varchar(20)
)
BEGIN

	IF p_in_status = 'Active' THEN
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
        where ExpDate is null and DropDate is null and Temp = 0
        Order by `Name`;
	ELSEIF p_in_status = 'Expired' THEN
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
        where ExpDate is not null
        Order by `Name`;
    ELSEIF p_in_status = 'Temp' THEN
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
         where Temp = 1
         Order by `Name`;
    ELSEIF p_in_status = 'Dropout' THEN 
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
        where DropDate is not null
        Order by `Name`;
    ELSEIF p_in_status = 'ActiveWithTemp' THEN 
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
        where ExpDate is null and DropDate is null
        Order by `Name`;
	ELSEIF p_in_status = 'All' THEN 
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
        Order by `Name`;
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetRehabilitation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetRehabilitation`(
IN p_in_pno varchar(45)
)
BEGIN
	SELECT 
    `Id`,
    `Date`,
    `Description`,
    `Quantity`
FROM `rehabilitation`
where Pno = p_in_pno
order by `Date`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetReportExpiry` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetReportExpiry`(
IN p_in_fromDate datetime,
IN p_in_toDate datetime
)
BEGIN

	SELECT 
		m.Id, m.Name, m.Mno, p.expdate, p.mainStock, p. subStock  
	from medicinepurchase p
	inner join medicine m on p.MedicineId = m.id
    WHERE
		p.expdate >= p_in_fromDate AND
        p.expdate <= p_in_toDate AND
        (p.mainStock > 0 OR p.subStock > 0) AND
        p.`return` = 0
    ORDER BY p.expdate;    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetReportExpiryCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetReportExpiryCount`(
IN p_in_fromDate datetime,
IN p_in_toDate datetime
)
BEGIN

	SELECT 
		Count(Id) as medCount
	FROM medicinepurchase
    WHERE
		expdate >= p_in_fromDate AND
        expdate <= p_in_toDate AND
        (mainStock > 0 OR subStock > 0) AND
        `return` = 0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetReportReceipts` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetReportReceipts`(
IN p_in_fromdate datetime,
IN p_in_todate datetime
)
BEGIN

SELECT 
	`account`.`Id`,
    `account`.`txndate`,
    `account`.`desc`,
    `account`.`type`,
    `account`.`amount`,
    `account`.`txntype`,
    `account`.`name`,
    `account`.`receiptNo`,
    `account`.`isReceipt`,
    `account`.`paymentMode`,
    `account`.`bankMode`,
    `account`.`bankName`,
    `account`.`txnNo`,
    `account`.`chNo`,
    `account`.`chdate`,
    `account`.`chBank`,
    `account`.`chAmount`
FROM `account`
WHERE 
	(`account`.`txntype` = 'Income' OR `account`.`txntype` = 'Expense') AND
    `account`.`isReceipt` = 1 AND
    `account`.`txndate` >= p_in_fromdate AND
    `account`.`txndate` <= p_in_todate
;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetReportThreshold` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetReportThreshold`(
IN p_in_thresholdCount int
)
BEGIN

	select m.Name, m.Mno, s.Main
	from medicinestock s
	inner join medicine m on s.MedicineId = m.id
    where s.Main > 0 AND s.Main <= p_in_thresholdCount
    order by m.Name;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetReportThresholdCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetReportThresholdCount`(
IN p_in_thresholdCount int
)
BEGIN

	SELECT 
		Count(Id) as medCount
	FROM medicinepurchase
    WHERE
		mainStock > 0 AND 
        mainStock <= p_in_thresholdCount AND
        `return` = 0;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetRouteList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetRouteList`()
BEGIN
	select Id, Name from route order by Name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetVolunteerList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetVolunteerList`()
BEGIN
	select Id, Name, Location, Phone from volunteer order by Name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_MedicineInbound` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_MedicineInbound`(
IN p_in_txndate datetime,
IN p_in_mno varchar(45),
IN p_in_purchase_invdate datetime,
IN p_in_purchase_invno varchar(45),
IN p_in_purchase_batchno varchar(45),
IN p_in_purchase_expdate datetime,
IN p_in_purchase_mfgdate datetime,
IN p_in_purchase_rate decimal(10,2),
IN p_in_purchase_dealer varchar(200),
IN p_in_qty int
)
BEGIN

    Declare p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id INT;
    Declare p_med_name varchar(200);
    
    IF EXISTS (SELECT 1 FROM `medicine` where Mno = p_in_mno) THEN
    	
		select 
			s.Main, s.Sub, s.A_kit, s.B_kit, s.MedicineId, m.Name 
			into p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_med_name
		from medicinestock s
		inner join medicine m on s.MedicineId = m.Id
		where m.Mno = p_in_mno;
        
        IF extract(year from p_in_purchase_invdate) = 1 THEN
			SET p_in_purchase_invdate = NULL;
		END IF;
		
		IF extract(year from p_in_purchase_expdate) = 1 THEN
			SET p_in_purchase_expdate = NULL;
		END IF;
		
		IF extract(year from p_in_purchase_mfgdate) = 1 THEN
			SET p_in_purchase_mfgdate = NULL;
		END IF;

        update medicinestock 
		set Main = (Main + p_in_qty)
		where MedicineId = p_m_id;
         
        INSERT INTO `medicinepurchase`
		(
		`MedicineId`,
		`invdate`,
		`invno`,
		`batchno`,
		`expdate`,
		`mfgdate`,
		`rate`,
		`dealer`,
		`mainStock`,
		`subStock`,
		`return`)
		VALUES
		(
		p_m_id,
		p_in_purchase_invdate,
		p_in_purchase_invno,
		p_in_purchase_batchno,
		p_in_purchase_expdate,
		p_in_purchase_mfgdate,
		p_in_purchase_rate,
		p_in_purchase_dealer,
		p_in_qty,
		0,
		0);
 		
        CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_in_mno, 
		p_med_name,
		'Inbound', -- txnType
		'To main stock', -- desc
		p_openMain, -- openingMain
        p_openSub, -- openingSub
        p_openAKit, -- openingAKit
        p_openBKit, -- openingBKit
		p_in_qty, -- qty
		(p_openMain + p_in_qty), -- closingMain
		p_openSub, -- closingSub
        p_openAKit, -- closingAKit
        p_openBKit, -- closingBKit
        '', -- pno
        '' -- patientName
        );
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_MedicineReturn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_MedicineReturn`(
IN p_in_txndate datetime,
IN p_in_mno varchar(45),
IN p_in_mainRet int,
IN p_in_mainStock int,
IN p_in_subRet int,
IN p_in_subStock int,
IN p_in_purId int
)
BEGIN

    Declare p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id INT;
    Declare p_med_name varchar(200);
    
    IF EXISTS (SELECT 1 FROM `medicine` where Mno = p_in_mno) THEN
    	
        select 
			s.Main, s.Sub, s.A_kit, s.B_kit, s.MedicineId, m.Name 
			into p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_med_name
		from medicinestock s
		inner join medicine m on s.MedicineId = m.Id
		where m.Mno = p_in_mno;
        
        update medicinestock 
			set Main = (Main - p_in_mainRet),
			Sub = (Sub - p_in_subRet)
		where MedicineId = p_m_id;
        
        update medicinepurchase
			set mainStock =  (mainStock - p_in_mainRet),
            subStock =  (subStock - p_in_subRet)
		where Id = p_in_purId;
        
        INSERT INTO `medicinepurchase`
		(
		`MedicineId`,
		`invdate`,
		`invno`,
		`batchno`,
		`expdate`,
		`mfgdate`,
		`rate`,
		`dealer`,
		`mainStock`,
		`subStock`,
		`return`)
		VALUES
		(
		p_m_id,
		p_in_txndate,
		'',
		'',
		p_in_txndate,
		null,
		0,
		'',
		(p_in_mainRet + p_in_subRet),
		0,
		1);
        
        CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_in_mno, 
		p_med_name,
		'Return', -- txnType
		'Return stock', -- desc
		p_openMain, -- openingMain
        p_openSub, -- openingSub
        p_openAKit, -- openingAKit
        p_openBKit, -- openingBKit
		(p_in_mainRet + p_in_subRet), -- qty
		(p_openMain - p_in_mainRet), -- closingMain
		(p_openSub - p_in_subRet), -- closingSub
        p_openAKit, -- closingAKit
        p_openBKit, -- closingBKit
        '', -- pno
        '' -- patientName
        );
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_MedicineTransfer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_MedicineTransfer`(
IN p_in_txndate datetime,
IN p_in_mno varchar(45),
IN p_in_qty int,
IN p_in_source varchar(50),
IN p_in_transferto varchar(50)
)
BEGIN

    Declare p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_purId, p_purMainStock, p_qty INT;
    Declare p_med_name varchar(200);
    DEClARE curPurch 
		CURSOR FOR 
			select 
			p.Id, p.mainStock 
		from 
			medicinepurchase p
			inner join medicine m on p.MedicineId = m.Id
		where 
			m.Mno = p_in_mno
			and p.mainStock > 0
			and p.expdate is not null
            and `return` = 0
		order by p.expdate;
    
    IF EXISTS (SELECT 1 FROM `medicine` where Mno = p_in_mno) THEN
    	
        SET p_qty = p_in_qty;
        
		select 
			s.Main, s.Sub, s.A_kit, s.B_kit, s.MedicineId, m.Name 
			into p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_med_name
		from medicinestock s
		inner join medicine m on s.MedicineId = m.Id
		where m.Mno = p_in_mno;
        
        update medicinestock 
		set Main = (Main - p_in_qty),
        Sub = (Sub + p_in_qty)
		where MedicineId = p_m_id;

        OPEN curPurch;
        
        transferLoop: LOOP
			FETCH curPurch INTO p_purId, p_purMainStock;
                        
            IF p_purMainStock <= p_qty THEN
				update medicinepurchase
				set 
					subStock = (subStock + mainStock),
					mainStock = 0
				where Id = p_purId;
                SET p_qty = p_qty - p_purMainStock;
            ELSE
				update medicinepurchase
				set 
					subStock = (subStock + p_qty),
					mainStock = (mainStock - p_qty)
				where Id = p_purId;
                SET p_qty = 0;
            END IF;

			IF p_qty = 0 THEN
				LEAVE transferLoop;
			END IF;
        END LOOP transferLoop;
        CLOSE curPurch;

        CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_in_mno, 
		p_med_name,
		'Transfer', -- txnType
		'Main to Sub', -- desc
		p_openMain, -- openingMain
        p_openSub, -- openingSub
        p_openAKit, -- openingAKit
        p_openBKit, -- openingBKit
		p_in_qty, -- qty
		(p_openMain - p_in_qty), -- closingMain
		(p_openSub + p_in_qty), -- closingSub
        p_openAKit, -- closingAKit
        p_openBKit, -- closingBKit
        '', -- pno
        '' -- patientName
        );
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_MedicineTransferKitStock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_MedicineTransferKitStock`(
IN p_in_txndate datetime,
IN p_in_mno varchar(45),
IN p_in_qty int,
IN p_in_stocktype varchar(50),
IN p_in_pno varchar(50),
IN p_in_patientname varchar(200)
)
BEGIN

    Declare p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, 
		p_purId, p_purSubStock, p_closeAKit, p_closeBKit INT;
    Declare p_med_name varchar(200);
        
    IF EXISTS (SELECT 1 FROM `medicine` where Mno = p_in_mno) THEN
        
		select 
			s.Main, s.Sub, s.A_kit, s.B_kit, s.MedicineId, m.Name 
			into p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_med_name
		from medicinestock s
		inner join medicine m on s.MedicineId = m.Id
		where m.Mno = p_in_mno;
        
        IF p_in_stocktype = "A Kit" THEN
			update medicinestock 
			set A_kit = (A_kit - p_in_qty)
			where MedicineId = p_m_id;
            
            SET p_closeAKit = p_openAKit - p_in_qty;
            SET p_closeBKit = p_openBKit;
            
        ELSE
			update medicinestock 
			set B_kit = (B_kit - p_in_qty)
			where MedicineId = p_m_id;
            
            SET p_closeAKit = p_openAKit;
            SET p_closeBKit = p_openBKit - p_in_qty;
            
        END IF;
        
        CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_in_mno, 
		p_med_name,
		'Transfer', -- txnType
		CONCAT(p_in_stocktype, ' to OP'), -- desc
		p_openMain, -- openingMain
        p_openSub, -- openingSub
        p_openAKit, -- openingAKit
        p_openBKit, -- openingBKit
		p_in_qty, -- qty
		p_openMain, -- closingMain
		p_openSub, -- closingSub
        p_closeAKit, -- closingAKit
        p_closeBKit, -- closingBKit
        p_in_pno, -- pno
        p_in_patientname -- patientName
        );
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_MedicineTransferSubStock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_MedicineTransferSubStock`(
IN p_in_txndate datetime,
IN p_in_mno varchar(45),
IN p_in_qty int,
IN p_in_source varchar(50),
IN p_in_transferto varchar(50),
IN p_in_pno varchar(50),
IN p_in_patientname varchar(200)
)
BEGIN

    Declare p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, 
		p_purId, p_purSubStock, p_qty ,p_closeAKit, p_closeBKit INT;
    Declare p_med_name varchar(200);
    DEClARE curPurch 
		CURSOR FOR 
			select 
			p.Id, p.subStock 
		from 
			medicinepurchase p
			inner join medicine m on p.MedicineId = m.Id
		where 
			m.Mno = p_in_mno
			and p.subStock > 0
			and p.expdate is not null
            and `return` = 0
		order by p.expdate;
    
    IF EXISTS (SELECT 1 FROM `medicine` where Mno = p_in_mno) THEN
    	
        SET p_qty = p_in_qty;
        
		select 
			s.Main, s.Sub, s.A_kit, s.B_kit, s.MedicineId, m.Name 
			into p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_med_name
		from medicinestock s
		inner join medicine m on s.MedicineId = m.Id
		where m.Mno = p_in_mno;
        
        update medicinestock 
		set Sub = (Sub - p_in_qty)
		where MedicineId = p_m_id;
        
        IF p_in_transferto = "A Kit" THEN
			update medicinestock 
			set A_kit = (A_kit + p_in_qty)
			where MedicineId = p_m_id;
            
            SET p_closeAKit = p_openAKit + p_in_qty;
            SET p_closeBKit = p_openBKit;
            
        ELSEIF p_in_transferto = "B Kit" THEN
			update medicinestock 
			set B_kit = (B_kit + p_in_qty)
			where MedicineId = p_m_id;
            
            SET p_closeAKit = p_openAKit;
            SET p_closeBKit = p_openBKit + p_in_qty;
            
        ELSE
			SET p_closeAKit = p_openAKit;
			SET p_closeBKit = p_openBKit;
        END IF;
        
        OPEN curPurch;
        
        transferLoop: LOOP
			FETCH curPurch INTO p_purId, p_purSubStock;
                       
            IF p_purSubStock <= p_qty THEN
				update medicinepurchase
				set 
					subStock = 0
				where Id = p_purId;
                SET p_qty = p_qty - p_purSubStock;
            ELSE
				update medicinepurchase
				set 
					subStock = (subStock - p_qty)
				where Id = p_purId;
                SET p_qty = 0;
            END IF;
            
            IF p_qty = 0 THEN
				LEAVE transferLoop;
			END IF;
        
        END LOOP transferLoop;
        CLOSE curPurch;
        
        CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_in_mno, 
		p_med_name,
		'Transfer', -- txnType
		CONCAT('Sub to ', p_in_transferto), -- desc
		p_openMain, -- openingMain
        p_openSub, -- openingSub
        p_openAKit, -- openingAKit
        p_openBKit, -- openingBKit
		p_in_qty, -- qty
		(p_openMain), -- closingMain
		(p_openSub - p_in_qty), -- closingSub
        p_closeAKit, -- closingAKit
        p_closeBKit, -- closingBKit
        p_in_pno, -- pno
        p_in_patientname -- patientName
        );
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ProcessCheque` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_ProcessCheque`(
IN p_in_txndate datetime,
IN p_in_id int
)
BEGIN

	declare p_amount DECIMAL(10,2);
	select chAmount into p_amount from `account` where `Id` = p_in_id;

	UPDATE `account`
	SET
	`txndate` = p_in_txndate,
	`amount` = p_amount
	WHERE `Id` = p_in_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReportAccountDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_ReportAccountDetails`(
IN p_in_fromdate datetime,
IN p_in_todate datetime,
IN p_in_txntype varchar(20)
)
BEGIN

SELECT 
    `account`.`type`,
    `account`.`txntype`,
    sum(`account`.`amount`) amt
FROM `account`
WHERE 
	`account`.`txndate` >= p_in_fromdate AND 
    `account`.`txndate` <= p_in_todate AND 
    `account`.`amount` != 0 AND
    `account`.`txntype` = p_in_txntype AND
    `account`.`type` != 'Contra Entry'
GROUP BY
	 `account`.`type`, `account`.`txntype`
ORDER BY `account`.`type`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReportDaybookBalance` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_ReportDaybookBalance`(
IN p_in_fromdate datetime
)
BEGIN

select bankname, sum(amount) amt from account
where txndate < p_in_fromdate
group by bankname;

select bankname, sum(amount) amt from account
where txndate <= p_in_fromdate
group by bankname;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReportDaybookLedger` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_ReportDaybookLedger`(
IN p_in_fromdate datetime
)
BEGIN

SELECT `account`.`Id`,
    `account`.`type`,
    `account`.`amount`,
    `account`.`txntype`,
    `account`.`bankName`,
    `account`.`name`
FROM `account`
WHERE `account`.`txndate` = p_in_fromdate
	AND `account`.`amount` != 0
ORDER BY `account`.`type`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReportIncomeTypeDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_ReportIncomeTypeDetails`(
IN p_in_fromdate datetime,
IN p_in_todate datetime,
IN p_in_type varchar(100),
IN p_in_txtType varchar(20)
)
BEGIN

SELECT 
	`account`.`id`,
    `account`.`txndate`,
    `account`.`amount`,
	`account`.`desc`,
	`account`.`type`,
	`account`.`paymentMode`
FROM `account`
WHERE 
	`account`.`txndate` >= p_in_fromdate AND 
    `account`.`txndate` <= p_in_todate AND 
    `account`.`amount` != 0 AND
    `account`.`txntype` = p_in_txtType AND
    `account`.`type` = p_in_type
ORDER BY `account`.`txndate`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReportMonthlyBalance` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_ReportMonthlyBalance`(
IN p_in_fromdate datetime,
IN p_in_todate datetime
)
BEGIN

select bankname, sum(amount) amt from account
where txndate < p_in_fromdate
group by bankname;

select bankname, sum(amount) amt from account
where txndate <= p_in_todate
group by bankname;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReturnEquipment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_ReturnEquipment`(
IN p_in_indate datetime,
IN p_in_eno varchar(45),
IN p_in_qty int,
IN p_in_id int,
IN p_in_rent decimal(10,2)
)
BEGIN
	
	IF EXISTS (SELECT 1 FROM `equipment` where eno = p_in_eno) THEN
   
		UPDATE `equipment`
		SET
		stock = (stock + p_in_qty),
		inuse = (inuse - p_in_qty)
		WHERE eno = p_in_eno;
    
		UPDATE `equipmenttracker`
        SET indate = p_in_indate,
        rent = p_in_rent
		WHERE Id = p_in_id;
        
	END IF;
       
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_SaveOP` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_SaveOP`(
IN p_in_pno varchar(50),
IN p_in_history LONGBLOB,
IN p_in_medicine LONGBLOB,
IN p_in_remarks LONGBLOB
)
BEGIN

	declare p_id int;
	SELECT Id into p_id FROM patient where PNo = p_in_pno; 

	IF EXISTS (SELECT 1 FROM op where PatientId = p_id) THEN	
		UPDATE OP
			SET `History` = p_in_history,
            Medicine = p_in_medicine,
            Remarks = p_in_remarks
        WHERE PatientId = p_id;
     ELSE
		INSERT INTO op
		(PatientId, `History`, Medicine, Remarks)
		VALUES
		(p_id, p_in_history, p_in_medicine, p_in_remarks);
     END IF;
	

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_TransferEquipment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_TransferEquipment`(
IN p_in_outdate datetime,
IN p_in_eno varchar(45),
IN p_in_qty int,
IN p_in_pno varchar(45),
IN p_in_patientname varchar(200),
IN p_in_deposit decimal(10,2)
)
BEGIN
	
    Declare p_e_id int;
	
	IF EXISTS (SELECT 1 FROM `equipment` where eno = p_in_eno) THEN
    
		select Id into p_e_id from equipment where eno = p_in_eno;
    
		UPDATE `equipment`
		SET
		stock = (stock - p_in_qty),
		inuse = (inuse + p_in_qty)
		WHERE Id = p_e_id;
    
		INSERT INTO `equipmenttracker`
		(
		`EquipmentId`,
		`patientname`,
		`pno`,
		`qty`,
		`outdate`,
		`indate`,
        deposit)
		VALUES
		(
		p_e_id,
		p_in_patientname,
		p_in_pno,
		p_in_qty,
		p_in_outdate,
		null,
        p_in_deposit);
        
	END IF;
       
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateAccountLedger` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateAccountLedger`(
IN p_in_id int,
IN p_in_desc varchar(200),
IN p_in_type varchar(45),
IN p_in_amount DECIMAL(10,2),
IN p_in_name varchar(200),
IN p_in_isReceipt tinyint,
IN p_in_paymentMode varchar(45),
IN p_in_bankMode varchar(45),
IN p_in_bankName varchar(200),
IN p_in_txnNo varchar(100),
IN p_in_chNo varchar(45),
IN p_in_chdate datetime,
IN p_in_txndate datetime,
IN p_in_chBank varchar(200)
)
BEGIN
	
    Declare p_receiptNo int;
    declare p_chAmount DECIMAL(10,2);
    declare p_txntype varchar(45);

	IF extract(year from p_in_chdate) = 1 THEN
		SET p_in_chdate = NULL;
	END IF;
	
    IF p_in_bankMode = "Cheque" THEN
		SET p_chAmount = p_in_amount;
        SET p_in_amount = 0;
	ELSE
		SET p_chAmount = 0;
	END IF;
    
    select txntype into p_txntype from `account` where id = p_in_id; 
       
    IF p_in_isReceipt = 1 THEN
		IF p_txntype = "Income" THEN
			update center set incomereceiptno = incomereceiptno + 1 where id = 1; 
			select incomereceiptno into p_receiptNo from center  where id = 1; 
        ELSE
			update center set expensereceiptno = expensereceiptno + 1 where id = 1; 
			select expensereceiptno into p_receiptNo from center  where id = 1;
        END IF;
	ELSE
		SET p_receiptNo = NULL;
	END IF;
    
	UPDATE `account`
	SET
	`desc` = p_in_desc,
	`type` = p_in_type,
	`amount` = p_in_amount,
	`name` = p_in_name,
	`receiptNo` = p_receiptNo,
	`isReceipt` = p_in_isReceipt,
	`paymentMode` = p_in_paymentMode,
	`bankMode` = p_in_bankMode,
	`bankName` = p_in_bankName,
	`txnNo` = p_in_txnNo,
	`chNo` = p_in_chNo,
	`chdate` = p_in_chdate,
	`chBank` = p_in_chBank,
	`chAmount` = p_chAmount,
    `txndate` = p_in_txndate
	WHERE `Id` = p_in_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateAsset` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateAsset`(
IN p_in_id int,
IN p_in_name varchar(200),
IN p_in_quantity int,
IN p_in_cost decimal(10,2)
)
BEGIN

	UPDATE `asset`
	SET
    `name` = p_in_name,
	`quantity` = p_in_quantity,
	`cost` = p_in_cost
	WHERE `Id` = p_in_id;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateBank` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateBank`(
IN p_in_id INT,
IN p_in_name varchar(200)
)
BEGIN
	UPDATE `bank`
	SET
	`Name` = p_in_name
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateCenter` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateCenter`(
IN p_in_name varchar(255),
IN p_in_address varchar(255),
IN p_in_desc varchar(255),
IN p_in_location varchar(255),
IN p_in_phone varchar(45),
IN p_in_regno varchar(45),
IN p_in_addressMal nvarchar(255),
IN p_in_locationMal nvarchar(255),
IN p_in_nameMal nvarchar(255),
IN p_in_medExpiryDays int,
IN p_in_medThresholdCount int,
IN p_in_descMal nvarchar(255)
)
BEGIN
	UPDATE center
	SET
	`Name` = p_in_name,
	`Address` = p_in_address,
	`Desc` = p_in_desc,
	`Location` = p_in_location,
	`Phone` = p_in_phone,
	`RegNo` = p_in_regno,
	`AddressMal` = p_in_addressMal,
	`LocationMal` =p_in_locationMal,
	`NameMal` =p_in_nameMal,
	`MedExpiryDays` = p_in_medExpiryDays,
	`MedThresholdCount` =p_in_medThresholdCount,
	`DescMal` = p_in_descMal;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateDiagnosis` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateDiagnosis`(
IN p_in_id INT,
IN p_in_name varchar(100)
)
BEGIN
	UPDATE `diagnosis`
	SET
	`Name` = p_in_name
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateEquipment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateEquipment`(
IN p_in_id int,
IN p_in_name varchar(200),
IN p_in_name_lower varchar(200),
IN p_in_stock int,
IN p_in_inuse int,
IN p_in_damage int
)
BEGIN

	UPDATE `equipment`
	SET
    `name` = p_in_name,
    `name_lower` = p_in_name_lower,
	`stock` = p_in_stock,
	`damage` = p_in_damage,
	`inuse` = p_in_inuse
	WHERE `Id` = p_in_id;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateExpenseType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateExpenseType`(
IN p_in_id INT,
IN p_in_expensetype varchar(100)
)
BEGIN
	UPDATE `expensetype`
	SET
	`ExpenseType` = p_in_expensetype
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateHomeCarePlan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateHomeCarePlan`(
IN p_in_id int,
IN p_in_type varchar(45),
IN p_in_date datetime
)
BEGIN
	UPDATE `homecareplan`
	SET
	`Type` = p_in_type,
	`Date` = p_in_date
	WHERE `Id` = p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateIncomeType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateIncomeType`(
IN p_in_id INT,
IN p_in_incometype varchar(100)
)
BEGIN
	UPDATE `incometype`
	SET
	`IncomeType` = p_in_incometype
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateMedicine` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateMedicine`(
IN p_in_id INT,
IN p_in_name varchar(200),
IN p_in_name_lower varchar(200)
)
BEGIN
	UPDATE `medicine`
	SET
	`Name` = p_in_name,
    `NameLower` = p_in_name_lower
	WHERE `Id` = p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateMedicineStock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateMedicineStock`(
IN p_in_purid INT,
IN p_in_mno varchar(20),
IN p_in_mainDiff int,
IN p_in_mainNew int,
IN p_in_subDiff int,
IN p_in_subNew int,
IN p_in_txndate datetime
)
BEGIN
	
    Declare p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id INT;
    Declare p_med_name varchar(200);
    
    select 
		s.Main, s.Sub, s.A_kit, s.B_kit, s.MedicineId, m.Name 
        into p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_med_name
    from medicinestock s
    inner join medicine m on s.MedicineId = m.Id
    where m.Mno = p_in_mno;
    
    update medicinestock 
    set Main = (Main - p_in_mainDiff),
    Sub = (Sub - p_in_subDiff)
    where MedicineId = p_m_id;
    
    update medicinepurchase
    set mainStock = p_in_mainNew,
		subStock = p_in_subNew
    where id = p_in_purid;

	 CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_in_mno, 
		p_med_name,
		'Edit', -- txnType
		'Edit stock', -- desc
		p_openMain, -- openingMain
        p_openSub, -- openingSub
        p_openAKit, -- openingAKit
        p_openBKit, -- openingBKit
		0, -- qty
		(p_openMain - p_in_mainDiff), -- closingMain
		(p_openSub - p_in_subDiff), -- closingSub
        p_openAKit, -- closingAKit
        p_openBKit, -- closingBKit
        '', -- pno
        '' -- patientName
        );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdatePanjayath` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdatePanjayath`(
IN p_in_id INT,
IN p_in_name varchar(100)
)
BEGIN
	UPDATE `panjayath`
	SET
	`Name` = p_in_name
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdatePassword` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdatePassword`(
IN p_in_UserName varchar(45),
IN p_in_password varchar(255)
)
BEGIN
 update login
 set password = p_in_password
 where username = p_in_UserName;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdatePatient` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdatePatient`(
IN p_in_id int,
IN p_in_name varchar(200),
IN p_in_age varchar(45),
IN p_in_address varchar(255),
IN p_in_grade varchar(45),
IN p_in_gender varchar(45),
IN p_in_panjayath varchar(100),
IN p_in_wardno varchar(45),
IN p_in_phone1 varchar(45),
IN p_in_phone2 varchar(45),
IN p_in_regdate datetime,
IN p_in_expdate datetime,
IN p_in_dropdate datetime,
IN p_in_volunteer varchar(100),
IN p_in_diagnosis varchar(100),
IN p_in_temp tinyint,
IN p_in_route varchar(100),
IN p_in_homecareplan varchar(45)

)
BEGIN
	UPDATE `patient`
	SET
	`Name` = p_in_name,
	`Age` = p_in_age,
	`Address` = p_in_address,
	`Grade` = p_in_grade,
	`Gender` = p_in_gender,
	`Panjayath` = p_in_panjayath,
	`WardNo` = p_in_wardno,
	`Phone1` = p_in_phone1,
	`Phone2` = p_in_phone2,
	`RegDate` = p_in_regdate,
	`ExpDate` = p_in_expdate,
	`DropDate` = p_in_dropdate,
	`Volunteer` = p_in_volunteer,
	`Diagnosis` = p_in_diagnosis,
	`Temp` = p_in_temp,
	`Route` = p_in_route,
	`HomeCarePlan` = p_in_homecareplan
	WHERE `Id` = p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateRehabilitation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateRehabilitation`(
IN p_in_id int,
IN p_in_desc varchar(200),
IN p_in_qty int
)
BEGIN
	UPDATE `rehabilitation`
	SET
	`Description` = p_in_desc,
	`Quantity` = p_in_qty
	WHERE `Id` = p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateRoute` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateRoute`(
IN p_in_id INT,
IN p_in_name varchar(100)
)
BEGIN
	UPDATE `route`
	SET
	`Name` = p_in_name
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateToday` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateToday`(
IN p_in_date varchar(255)
)
BEGIN

	UPDATE center SET `TodayAPI` = p_in_date;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateVolunteer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateVolunteer`(
IN p_in_id INT,
IN p_in_name varchar(100),
IN p_in_location varchar(100),
IN p_in_phone varchar(45)
)
BEGIN
	UPDATE `volunteer`
	SET
	`Name` = p_in_name,
	`Location` = p_in_location,
	`Phone` = p_in_phone
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-14 19:26:15
