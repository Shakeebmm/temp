const express = require("express");
const routes = express.Router();
const logger = require("../utils/logger/logger").getLoggerInstance();
let Login = require("./login.model");
const crypto = require("../utils/crypto").getCrytoHelperInstance();

routes.route("/validate").post(function(req, res) {
  logger.log("info", "login -> Validate");

  try {
    Login.findOne({ username: req.body.username }, function(err, user) {
      if (!user) {
        res.status(204).send("Data not found");
      } else {
        console.log(crypto.encryptField("a"));

        if (req.body.password === crypto.decryptField(user.pwd)) {
          res.status(200).send("Success");
        } else {
          res.status(204).send("Data not found");
        }
      }
    });
  } catch (err) {
    logger.log("error", "login -> Validate : " + err);
    res.status(400).send("Error");
  }
});

module.exports = routes;
