const express = require("express");
var Promise = require("promise");
const routes = express.Router();
const logger = require("../utils/logger/logger").getLoggerInstance();
let Panjayath = require("./panjayath.model");

// Defined store route
routes.route("/add").post(function(req, res) {
  logger.log("info", "Panjayath -> add");
  try {
    let panjayath = new Panjayath(req.body);
    panjayath.save().then(res.status(200).send("Success"));
  } catch (err) {
    logger.log("error", "Panjayath -> add : " + err);
    res.status(400).send("Error");
  }
});

// Defined get data(index or listing) route
routes.route("/").get(function(req, res) {
  logger.log("info", "Panjayath -> get");
  try {
    Panjayath.find(function(err, panjayaths) {
      if (err) {
        console.log(err);
      } else {
        res.status(200).json(panjayaths);
      }
    });
  } catch (err) {
    logger.log("error", "Panjayath -> get : " + err);
    res.status(400).send("Error");
  }
});

routes.route("/getNames").get(function(req, res) {
  logger.log("info", "Panjayath -> getNames");
  try {
    Panjayath.find({}, { _id: 0, name: 1 }, function(err, data) {
      if (err) {
        console.log(err);
      } else {
        res.status(200).json(data);
      }
    });
  } catch (err) {
    res.status(400).send("Error");
  }
});

// Defined edit route
routes.route("/edit/:id").get(function(req, res) {
  logger.log("info", "Panjayath -> edit");
  let id = req.params.id;
  Panjayath.findById(id, function(err, panjayath) {
    res.status(200).json(panjayath);
  });
});

//  Defined update route
routes.route("/update/:id").post(function(req, res) {
  logger.log("info", "Panjayath -> update");
  try {
    Panjayath.findById(req.params.id, function(err, panjayath) {
      if (!panjayath) res.status(404).send("Data not found");
      else {
        panjayath.name = req.body.name;

        panjayath.save().then(panjayath => {
          res.status(200).json("Update complete");
        });
        // .catch(err => {
        //   res.status(400).send("Unable to update the database");
        // });
      }
    });
  } catch (err) {
    logger.log("error", "Panjayath -> update : " + err);
    res.status(400).send("Error");
  }
});

// Defined delete | remove | destroy route
routes.route("/delete/:id").get(function(req, res) {
  Panjayath.findOneAndDelete({ _id: req.params.id }, function(err, panjayath) {
    if (err) res.json(err);
    else res.json("Successfully removed");
  });
});

module.exports = routes;
