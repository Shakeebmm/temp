const express = require("express");
var Promise = require("promise");
const routes = express.Router();
const logger = require("../utils/logger/logger").getLoggerInstance();
let IncomeType = require("./incomeType.model");

// Defined store route
routes.route("/add").post(function(req, res) {
  logger.log("info", "IncomeType -> add");
  try {
    let incomeType = new IncomeType(req.body);
    incomeType.save().then(res.status(200).send("Success"));
  } catch (err) {
    logger.log("error", "IncomeType -> add : " + err);
    res.status(400).send("Error");
  }
});

// Defined get data(index or listing) route
routes.route("/").get(function(req, res) {
  logger.log("info", "IncomeType -> get");
  IncomeType.find(function(err, incomeTypes) {
    if (err) {
      console.log(err);
    } else {
      res.status(200).json(incomeTypes);
    }
  });
});

routes.route("/getIncomeTypes").get(function(req, res) {
  logger.log("info", "IncomeType -> getIncomeTypes");
  try {
    IncomeType.find({}, { _id: 0, incomeType: 1 }, function(err, data) {
      if (err) {
        console.log(err);
      } else {
        res.status(200).json(data);
      }
    });
  } catch (err) {
    logger.log("error", "IncomeType -> getIncomeTypes : " + err);
    res.status(400).send("Error");
  }
});

// Defined edit route
routes.route("/edit/:id").get(function(req, res) {
  logger.log("info", "IncomeType -> edit");
  let id = req.params.id;
  IncomeType.findById(id, function(err, incomeType) {
    res.status(200).json(incomeType);
  });
});

//  Defined update route
routes.route("/update/:id").post(function(req, res) {
  logger.log("info", "IncomeType -> update");
  try {
    IncomeType.findById(req.params.id, function(err, incomeType) {
      if (!incomeType) res.status(404).send("Data not found");
      else {
        incomeType.incomeType = req.body.incomeType;

        incomeType.save().then(incomeType => {
          res.status(200).json("Update complete");
        });
        // .catch(err => {
        //   res.status(400).send("Unable to update the database");
        // });
      }
    });
  } catch (err) {
    logger.log("error", "IncomeType -> update : " + err);
    res.status(400).send("Error");
  }
});

// Defined delete | remove | destroy route
routes.route("/delete/:id").get(function(req, res) {
  IncomeType.findOneAndDelete({ _id: req.params.id }, function(
    err,
    incomeType
  ) {
    if (err) res.json(err);
    else res.json("Successfully removed");
  });
});

module.exports = routes;
