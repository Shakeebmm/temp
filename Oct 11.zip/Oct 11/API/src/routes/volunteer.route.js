const express = require("express");
var Promise = require("promise");
const routes = express.Router();
const logger = require("../utils/logger/logger").getLoggerInstance();
let Volunteer = require("../database/schemas/volunteer.model");

function getVno() {
  logger.log("info", "Volunteer -> getVno");
  return new Promise(function(resolve, reject) {
    // Do async job
    Volunteer.countDocuments(function(err, cnt) {
      var newCnt = ++cnt;
      resolve("V" + newCnt);
    });
  });
}

// Defined store route
routes.route("/add").post(function(req, res, next) {
  logger.log("info", "Volunteer -> add");
  try {
    let volunteer = new Volunteer(req.body);
    var getVnoPromise = getVno();
    getVnoPromise.then(function(res) {
      volunteer.vno = res;
      volunteer.save().then(res.status(200).send("Success"));
    });
  } catch (err) {
    next(new Error(err));
  }
});

// Defined get data(index or listing) route
routes.route("/").get(function(req, res, next) {
  logger.log("info", "Volunteer -> get");
  try {
    Volunteer.find(function(err, volunteeres) {
      if (err) {
        next(new Error(err));
      } else {
        res.status(200).json(volunteeres);
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

// Defined get data(index or listing) route
routes.route("/getNames").get(function(req, res, next) {
  logger.log("info", "Volunteer -> getNames");
  try {
    Volunteer.find({}, { _id: 0, name: 1 }, function(err, volunteeres) {
      if (err) {
        next(new Error(err));
      } else {
        res.status(200).json(volunteeres);
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

// // Get list count
// routes.route("/count").get(function(req, res) {
//   Volunteer.countDocuments(function(err, cnt) {
//     if (err) {
//       console.log(err);
//     } else {
//       res.json(cnt + 1);
//     }
//   });
// });

// Defined edit route
routes.route("/edit/:id").get(function(req, res) {
  logger.log("info", "Volunteer -> edit");
  let id = req.params.id;
  Volunteer.findById(id, function(err, volunteer) {
    res.json(volunteer);
  });
});

//  Defined update route
routes.route("/update/:id").post(function(req, res, next) {
  logger.log("info", "Volunteer -> update");
  try {
    Volunteer.findById(req.params.id, function(err, volunteer) {
      if (!volunteer) res.status(404).send("Data not found");
      else {
        volunteer.name = req.body.name;
        volunteer.location = req.body.location;
        volunteer.phone = req.body.phone;

        volunteer.save().then(volunteer => {
          res.status(200).json("Update complete");
        });
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

// Defined delete | remove | destroy route
routes.route("/delete/:id").get(function(req, res) {
  Volunteer.findOneAndDelete({ _id: req.params.id }, function(err, volunteer) {
    if (err) res.json(err);
    else res.json("Successfully removed");
  });
});

module.exports = routes;
