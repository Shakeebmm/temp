const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let Diagnosis = new Schema(
  {
    name: {
      type: String
    }
  },
  {
    collection: "diagnosis"
  }
);

module.exports = mongoose.model("diagnosis", Diagnosis);
