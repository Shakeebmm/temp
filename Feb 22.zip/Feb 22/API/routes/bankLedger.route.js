const express = require("express");
const routes = express.Router();
let Ledger = require("../database/schemas/bankLedger.model");
const moment = require("moment-timezone");

routes.post("*/bankLedger/add", function(req, res, next) {
  try {
    let ledger = new Ledger(req.body);
    if (ledger.txnDate != null && ledger.txnDate != "") {
      ledger.txnDate = moment(ledger.txnDate).format("YYYY-MM-DD");
    }

    ledger.save().then(res.status(200).send("Success"));
  } catch (err) {
    next(new Error(err));
  }
});

routes.get("*/bankLedger/:bno", function(req, res, next) {
  Ledger.find({ bno: req.params.bno }, function(err, ledger) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(ledger);
    }
  });
});

routes.get("*/bankLedger/getBalance/:bno", function(req, res, next) {
  Ledger.aggregate(
    [
      {
        $match: {
          bno: {
            $eq: req.params.bno
          }
        }
      },
      {
        $group: {
          _id: null,
          balance: { $sum: "$amount" }
        }
      }
    ],
    function(err, result) {
      if (err) {
        next(new Error(err));
      } else {
        res.json(result);
      }
    }
  );
});

routes.post("*/bankLedger/update/:id", function(req, res, next) {
  try {
    Ledger.findById(req.params.id, function(err, ledger) {
      if (!ledger) res.status(404).send("Data not found");
      else {
        ledger.txnType = req.body.txnType;
        ledger.amount = req.body.amount;
        ledger.save().then(medicine => {
          res.status(200).json("Update completed");
        });
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

module.exports = routes;
