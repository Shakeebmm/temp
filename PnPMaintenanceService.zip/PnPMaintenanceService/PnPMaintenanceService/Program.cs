﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.IO;
using System.Configuration;
using System.ServiceProcess;

namespace PnPMaintenanceService
{
    class Program
    {
        static void Main(string[] args)
        {
            log4net.Config.XmlConfigurator.Configure();

            //ServiceBase[] ServicesToRun;
            //ServicesToRun = new ServiceBase[] 
            //{ 
            //    new PnPMaintService()
            //};
            //ServiceBase.Run(ServicesToRun);



            Scheduler obj = new Scheduler();
            obj.Process();

        }

    }
}
