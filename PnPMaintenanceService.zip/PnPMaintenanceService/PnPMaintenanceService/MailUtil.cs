﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;
using System.Net;
using System.Configuration;

namespace PnPMaintenanceService
{
    public static class MailUtil
    {
        public static string SendMail(string strTo, string strFrom, string strSubject, string strBody, List<string> lstAttachments, bool blnIsHTML = false, string strCC = "")
        {
            string strReturn = "";
            try
            {
                string strSMTPServer = ConfigurationManager.AppSettings["SMTPServer"];
                int port = Convert.ToInt32(ConfigurationManager.AppSettings["SMTPPort"]);
                string strUsername = ConfigurationManager.AppSettings["SMTPUserName"];
                string strPassword = ConfigurationManager.AppSettings["SMTPPassword"];

                MailMessage mailMessage = new MailMessage();

                mailMessage.To.Add(strTo);
                if (strCC != "")
                    mailMessage.CC.Add(strCC);
                mailMessage.From = new MailAddress(strFrom);
                mailMessage.Subject = strSubject;
                mailMessage.Body = strBody;
                mailMessage.IsBodyHtml = blnIsHTML;

                foreach (string strFile in lstAttachments)
                {
                    Attachment att = new Attachment(strFile);
                    mailMessage.Attachments.Add(att);
                }

                SmtpClient smtp = new SmtpClient(strSMTPServer, port);
                smtp.EnableSsl = true;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new NetworkCredential(strUsername, strPassword);

                smtp.Send(mailMessage);
                mailMessage.Dispose();
                smtp.Dispose();
            }
            catch (Exception ex)
            {
                strReturn = ex.Message;
            }
            return strReturn;
        }
    }
}
