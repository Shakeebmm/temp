﻿using System.ComponentModel;
using System.ServiceProcess;
using System.Configuration.Install;


namespace PnPMaintenanceService
{
    [RunInstaller(true)]
    public partial class PnPMaintServiceInstaller : Installer
    {
        public PnPMaintServiceInstaller()
        {
            InitializeComponent();

            ServiceProcessInstaller serviceProcessInstaller = new ServiceProcessInstaller();
            ServiceInstaller serviceInstaller = new ServiceInstaller();

            this.Installers.Add(GetServiceProcessInstaller());
            this.Installers.Add(GetServiceInstaller());
        }

        private ServiceInstaller GetServiceInstaller()
        {
            ServiceInstaller installer = new ServiceInstaller();
            installer.ServiceName = "PnP Maintenance Service";
            installer.StartType = ServiceStartMode.Automatic;
            return installer;
        }

        private ServiceProcessInstaller GetServiceProcessInstaller()
        {
            ServiceProcessInstaller installer = new ServiceProcessInstaller();
            installer.Account = ServiceAccount.LocalSystem;
            return installer;
        }
    }
}
