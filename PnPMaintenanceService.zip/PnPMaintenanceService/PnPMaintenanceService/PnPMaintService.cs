﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.ServiceProcess;
using System.Configuration;
using System.Reflection;

namespace PnPMaintenanceService
{
    partial class PnPMaintService : ServiceBase
    {
        Scheduler _objScheduler;

        public PnPMaintService()
        {
            System.Diagnostics.EventLog.WriteEntry("PnPMaintService", "1", EventLogEntryType.Information);
            InitializeComponent();
            SetTimerInterval();
        }

        private void SetTimerInterval()
        {
            Assembly service = Assembly.GetAssembly(typeof(PnPMaintServiceInstaller));
            Configuration config = ConfigurationManager.OpenExeConfiguration(service.Location);

            double tmrInterval = 1;
            if (config.AppSettings.Settings["ProcessInterval"] != null)
            {
                tmrInterval = Convert.ToDouble(config.AppSettings.Settings["ProcessInterval"].Value);
            }
            tmrProcess.Interval = tmrInterval * 1000 * 60;
            tmrProcess.Enabled = false;
        }

        protected override void OnStart(string[] args)
        {
            System.Diagnostics.EventLog.WriteEntry("PnPMaintService", "Service started", EventLogEntryType.Information);
            BackgroundWorker bw = new BackgroundWorker();
            bw.DoWork += new DoWorkEventHandler(bw_DoWork);
            bw.RunWorkerAsync();
        }

        void bw_DoWork(object sender, DoWorkEventArgs e)
        {
            System.Diagnostics.EventLog.WriteEntry("PnPMaintService", "DoWork()", EventLogEntryType.Information);

            _objScheduler = new Scheduler();
            _objScheduler.Process();

            tmrProcess.Enabled = true;
        }

        private void tmrProcess_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            System.Diagnostics.EventLog.WriteEntry("PnPMaintService", "tmrProcess_Elapsed", EventLogEntryType.Information);

            tmrProcess.Enabled = false;
            _objScheduler.Process();
            tmrProcess.Enabled = true;
        }

        protected override void OnStop()
        {
            _objScheduler = null;
            tmrProcess.Enabled = false;
        }
    }
}
