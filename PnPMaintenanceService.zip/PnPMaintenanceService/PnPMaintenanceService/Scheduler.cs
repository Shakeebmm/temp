﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.IO;
using System.Configuration;
using log4net;
using System.Reflection;

namespace PnPMaintenanceService
{
    public class Scheduler
    {
        private static readonly ILog Log = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
       
        public void Process()
        {
            Log.Debug("Starting");
           

            //MongoDBBackup();
            ReportErrorLog();
        }

        private void MongoDBBackup()
        {
            string filePath = TakeDBBackup();
            SendDBBackupMail(filePath);
            CleanupDBBackup();
        }

        private void ReportErrorLog()
        {
            string logPath = CheckLog();
            SendLogMail(logPath);
            CleanupLog();
        }

        private void CleanupDBBackup()
        {
            Directory.GetFiles(ConfigurationManager.AppSettings["DBBackupFolder"])
          .Select(f => new FileInfo(f))
          .OrderByDescending(f => f.CreationTime)
          .Skip(Convert.ToInt32(ConfigurationManager.AppSettings["DBSkipDays"]))
          .ToList()
          .ForEach(f => f.Delete());
        }

        private void CleanupLog()
        {
            Directory.GetFiles(ConfigurationManager.AppSettings["LogFolder"])
          .Select(f => new FileInfo(f))
          .OrderByDescending(f => f.CreationTime)
          .Skip(Convert.ToInt32(ConfigurationManager.AppSettings["LogSkipDays"]))
          .ToList()
          .ForEach(f => f.Delete());
        }

        private void SendDBBackupMail(string filePath)
        {
            if (File.Exists(filePath))
            {
                string strMailid = ConfigurationManager.AppSettings["EmailAddress"];
                // send mail
                string strRet = MailUtil.SendMail(strMailid, strMailid, "DB Backup - " + DateTime.Today.ToString("dd-MM-yyyy"), "", new List<string>() { filePath });

                if (string.IsNullOrEmpty(strRet))
                    File.Move(filePath, filePath + ".done");// rename file
            }
        }

        private void SendLogMail(string filePath)
        {
            if (File.Exists(filePath))
            {
                string strMailid = ConfigurationManager.AppSettings["EmailAddress"];
                // send mail
                string strRet = MailUtil.SendMail("shakeebmm@gmail.com", strMailid, "Error log - " + DateTime.Today.ToString("dd-MM-yyyy"), "", new List<string>() { filePath });

                if (string.IsNullOrEmpty(strRet))
                    File.Move(filePath, filePath + ".done");
            }
        }


        private string TakeDBBackup()
        {
            string filePath = ConfigurationManager.AppSettings["BackupFolder"] + "PnP_" + DateTime.Today.ToString("dd-MM-yyyy") + ".gz";
            if (!File.Exists(filePath) && !File.Exists(filePath + ".done"))
            {
                Process p = new Process();
                ProcessStartInfo startInfo = new ProcessStartInfo();
                startInfo.FileName = "cmd.exe";
                startInfo.Arguments = @"/C """ + ConfigurationManager.AppSettings["MongoDumpPath"] + @""" -h " + ConfigurationManager.AppSettings["Host"] + " -d PnP -u pnpadmin -p p@ssw0rD --gzip --archive=" + filePath;
                p.StartInfo = startInfo;
                p.StartInfo.UseShellExecute = false;
                p.StartInfo.CreateNoWindow = true;
                p.Start();
                p.WaitForExit();
            }
            return filePath;
        }

        private string CheckLog()
        {
            string strReturn = string.Empty;
            string logPath = ConfigurationManager.AppSettings["LogFolder"] + "logs-" + DateTime.Today.AddDays(-1).ToString("yyyy_MM_dd") + ".log";
            if (File.Exists(logPath))//&& !File.Exists(logPath + ".done"))
            {
                string log = File.ReadAllText(logPath);
                if (log.Contains("error"))
                {
                    strReturn = logPath;
                }
                else
                {
                    File.Move(logPath, logPath + ".done");
                }
            }

            return strReturn;
        }
    }
}
