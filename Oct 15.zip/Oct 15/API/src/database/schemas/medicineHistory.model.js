const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let MedicineHistory = new Schema(
  {
    id: {
      type: Number
    },
    mno: {
      type: String
    },
    name: {
      type: String
    },
    qty: {
      type: Number
    },
    stock: {
      type: Number
    },
    source: {
      type: String //Add, Edit, Outbound
    },
    transferto: {
      type: String //A Kit, B Kit, OP
    },
    updatedon: {
      type: Date
    },
    stocktype: {
      type: String
    }
  },
  {
    collection: "medicineHistory"
  }
);

module.exports = mongoose.model("medicineHistory", MedicineHistory);
