const express = require("express");
const routes = express.Router();
const logger = require("../utils/logger/logger").getLoggerInstance();
let Login = require("../database/schemas/login.model");
const crypto = require("../utils/crypto").getCrytoHelperInstance();

routes.route("/validate").post(function(req, res, next) {
  logger.log("info", "login -> Validate");

  try {
    Login.findOne({ username: req.body.username }, function(err, user) {
      if (!user) {
        res.status(204).send("Data not found");
      } else {
        if (req.body.password === crypto.decryptField(user.pwd)) {
          res.status(200).send("Success");
        } else {
          res.status(204).send("Data not found");
        }
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

module.exports = routes;
