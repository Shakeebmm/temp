const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let Center = new Schema(
  {
    name: {
      type: String
    },
    desc: {
      type: String
    },
    location: {
      type: String
    },
    regno: {
      type: String
    },
    address: {
      type: String
    },
    phone: {
      type: String
    }
  },
  {
    collection: "centerDetails"
  }
);

module.exports = mongoose.model("centerDetails", Center);
