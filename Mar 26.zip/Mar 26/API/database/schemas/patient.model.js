const mongoose = require("mongoose");
const Schema = mongoose.Schema;

// Define collection and schema for Business
let Patient = new Schema(
  {
    pno: {
      type: String
    },
    name: {
      type: String
    },
    age: {
      type: String
    },
    address: {
      type: String
    },
    grade: {
      type: String
    },
    gender: {
      type: String
    },
    panjayath: {
      type: String
    },
    wardno: {
      type: String
    },
    phone1: {
      type: String
    },
    phone2: {
      type: String
    },
    regdate: {
      type: Date
    },
    expdate: {
      type: Date
    },
    dropdate: {
      type: Date
    },
    volunteer: {
      type: String
    },
    diagnosis: {
      type: String
    },
    temp: {
      type: Boolean
    }
  },
  {
    collection: "patient"
  }
);

module.exports = mongoose.model("Patient", Patient);
