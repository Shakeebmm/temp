const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let EquipmentDispose = new Schema(
  {
    eno: { type: String },
    name: { type: String },
    desc: { type: String },
    qty: { type: Number },
    txnDate: { type: Date }
  },
  {
    collection: "equipmentDispose"
  }
);

module.exports = mongoose.model("equipmentDispose", EquipmentDispose);
