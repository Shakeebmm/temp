const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let Medicine = new Schema(
  {
    mno: {
      type: String
    },
    name: {
      type: String
    },
    name_lower: {
      type: String
    },
    stock: {
      main: {
        type: Number
      },
      sub: {
        type: Number
      },
      a_kit: {
        type: Number
      },
      b_kit: {
        type: Number
      }
    },
    purchase: [
      {
        invdate: {
          type: Date
        },
        invno: {
          type: String
        },
        batchno: {
          type: String
        },
        expdate: {
          type: Date
        },
        rate: {
          type: Number
        },
        dealer: {
          type: String
        }
      }
    ]
  },
  {
    collection: "medicine"
  }
);

module.exports = mongoose.model("medicine", Medicine);
