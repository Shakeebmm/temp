const express = require("express");
var Promise = require("promise");
const routes = express.Router();
const logger = require("../utils/logger/logger").getLoggerInstance();
const moment = require("moment-timezone");

let Patient = require("./patient.model");

function getPno() {
  return new Promise(function(resolve, reject) {
    // Do async job
    Patient.countDocuments(function(err, cnt) {
      var newCnt = ++cnt;
      resolve("P" + newCnt);
    });
  });
}

function getFormattedDate(date) {
  var arr = date.split(" ");
  return arr[2] + "-" + arr[1] + "-" + arr[3];
}

// Defined store route
routes.route("/add").post(function(req, res) {
  try {
    logger.log("info", "Patient -> add");

    let patient = new Patient(req.body);

    //const date = moment(patient.regdate).format("YYYY-MM-DD");
    //console.log(date);
    if (patient.regdate != null && patient.regdate != "") {
      // var dd = new Date(patient.regdate);
      // dd = new Date(dd.getUTCFullYear(), dd.getUTCMonth(), dd.getUTCDate() + 2);
      patient.regdate = moment(patient.regdate)
        .tz("Asia/Calcutta")
        .format("YYYY-MM-DD");
    }
    //console.log(patient.regdate);

    if (patient.expdate != null && patient.expdate != "") {
      // var ddexp = new Date(patient.expdate);
      // ddexp = new Date(
      //   ddexp.getUTCFullYear(),
      //   ddexp.getUTCMonth(),
      //   ddexp.getUTCDate() + 2
      // );
      patient.expdate = moment(patient.expdate)
        .tz("Asia/Calcutta")
        .format("YYYY-MM-DD");
    }

    patient.save().then(res.status(200).send("Success"));

    // var getPnoPromise = getPno();
    // getPnoPromise.then(function(res) {
    //   patient.pno = res;
    //   patient.save();
    // });
  } catch (err) {
    res.status(400).send("Error");
  }
});

// Defined get data(index or listing) route
routes.route("/").get(function(req, res) {
  logger.log("info", "Patient -> get");

  try {
    Patient.find(function(err, patients) {
      if (err) {
        console.log(err);
      } else {
        res.status(200).json(patients);
      }
    });
  } catch (err) {
    logger.log("error", "Patient -> get : " + err);
    res.status(400).send("Error");
  }
});

// Defined get data(index or listing) route
routes.route("/getNames").get(function(req, res) {
  logger.log("info", "Patient -> getNames");
  try {
    Patient.find({}, { _id: 0, name: 1, pno: 1 }, function(err, patients) {
      if (err) {
        console.log(err);
      } else {
        res.status(200).json(patients);
      }
    });
  } catch (err) {
    res.status(400).send("Error");
  }
});

// // Get list count
// routes.route("/count").get(function(req, res) {
//   Patient.countDocuments(function(err, cnt) {
//     if (err) {
//       console.log(err);
//     } else {
//       res.json(cnt + 1);
//     }
//   });
// });

// Defined edit route
routes.route("/edit/:id").get(function(req, res) {
  logger.log("info", "Patient -> edit");
  let id = req.params.id;
  Patient.findById(id, function(err, Patient) {
    res.status(200).json(Patient);
  });
});

//  Defined update route
routes.route("/update/:id").post(function(req, res) {
  logger.log("info", "Patient -> update");
  try {
    Patient.findById(req.params.id, function(err, Patient) {
      if (!Patient) res.status(404).send("Data not found");
      else {
        console.log(req.body.regdate);
        //Patient.pno = req.body.pno;
        Patient.name = req.body.name;
        Patient.age = req.body.age;
        Patient.address = req.body.address;
        Patient.grade = req.body.grade;
        Patient.gender = req.body.gender;
        Patient.panjayath = req.body.panjayath;
        Patient.wardno = req.body.wardno;
        Patient.phone1 = req.body.phone1;
        Patient.phone2 = req.body.phone2;
        Patient.volunteer = req.body.volunteer;
        Patient.diagnosis = req.body.diagnosis;

        // let dayIncrReg = 2;
        // let dayIncrExp = 2;
        // if (Patient.regdate == null) dayIncrReg = 2;
        // if (Patient.expdate == null) dayIncrExp = 2;

        if (
          req.body.regdate != null &&
          req.body.regdate != "" &&
          req.body.regdate != "1970-01-01T00:00:00.000Z"
        ) {
          // var dd = new Date(req.body.regdate);
          // dd = new Date(
          //   dd.getUTCFullYear(),
          //   dd.getUTCMonth(),
          //   dd.getUTCDate() + dayIncrReg
          // );
          Patient.regdate = moment(req.body.regdate)
            .tz("Asia/Calcutta")
            .format("YYYY-MM-DD");
        }

        if (
          req.body.expdate != null &&
          req.body.expdate != "" &&
          req.body.expdate != "1970-01-01T00:00:00.000Z"
        ) {
          // var dd = new Date(req.body.expdate);
          // dd = new Date(
          //   dd.getUTCFullYear(),
          //   dd.getUTCMonth(),
          //   dd.getUTCDate() + dayIncrExp
          // );
          Patient.expdate = moment(req.body.expdate)
            .tz("Asia/Calcutta")
            .format("YYYY-MM-DD");
        }

        Patient.save().then(res.status(200).json("Update complete"));
        // .catch(err => {
        //   res.status(400).send("Unable to update the database");
        // });
      }
    });
  } catch (err) {
    res.status(400).send("Error");
  }
});

// Defined delete | remove | destroy route
routes.route("/delete/:id").get(function(req, res) {
  Patient.findOneAndDelete({ _id: req.params.id }, function(err, Patient) {
    if (err) res.json(err);
    else res.json("Successfully removed");
  });
});

routes.route("/detailsReport").post(function(req, res) {
  logger.log("info", "Patient -> detailsReport");

  var fromDate = new Date(
    moment(req.body.fromDate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD")
  );
  // fromDate = new Date(
  //   fromDate.getUTCFullYear(),
  //   fromDate.getUTCMonth(),
  //   fromDate.getUTCDate() + 2
  // );

  var toDate = new Date(
    moment(req.body.toDate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD")
  );
  // toDate = new Date(
  //   toDate.getUTCFullYear(),
  //   toDate.getUTCMonth(),
  //   toDate.getUTCDate() + 2
  // );

  try {
    Patient.aggregate(
      [
        {
          $match: {
            regdate: {
              $gte: fromDate,
              $lte: toDate
            }
          }
        }
      ],
      function(err, result) {
        if (err) {
          next(err);
        } else {
          res.status(200).json(result);
        }
      }
    );
  } catch (err) {
    logger.log("error", "Patient -> detailsReport : " + err);
    res.status(400).send("Error");
  }
});

module.exports = routes;
