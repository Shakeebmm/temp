const express = require("express");
const routes = express.Router();
const logger = require("../utils/logger/logger").getLoggerInstance();
let Medicine = require("../database/schemas/medicine.model");
let MedicineHistory = require("../database/schemas/medicineHistory.model");
let Transfer = require("../database/schemas/medicineTransfer.model");
let OP = require("../database/schemas/medicineOP.model");
const moment = require("moment-timezone");

function getMno() {
  logger.log("info", "Medicine -> getMno");
  return new Promise(function(resolve, reject) {
    Medicine.countDocuments(function(err, cnt) {
      var newCnt = ++cnt;
      resolve("M" + newCnt);
    });
  });
}

function getHistoryId() {
  logger.log("info", "Medicine -> getHistoryId");
  return new Promise(function(resolve, reject) {
    MedicineHistory.countDocuments(function(err, cnt) {
      resolve(++cnt);
    });
  });
}

function saveHistory(his) {
  logger.log("info", "Medicine -> saveHistory");
  //Save history
  let history = new MedicineHistory();
  var getHistoryPromise = getHistoryId();
  getHistoryPromise.then(function(resid) {
    history.id = resid;
    history.mno = his.mno;
    history.qty = his.qty;
    history.stock = his.stock;
    history.source = his.source;
    history.transferto = his.transferto;
    history.stocktype = his.stocktype;
    history.updatedon = new Date();
    history.name = his.name;
    history.save();
  });
}

// Defined store route
routes.route("/add").post(function(req, res, next) {
  logger.log("info", "Medicine -> add");
  try {
    let medicineParam = new Medicine(req.body);

    Medicine.findOne({ name_lower: medicineParam.name.toLowerCase() }, function(
      err,
      medicine
    ) {
      if (!medicine) {
        // Add new medicine
        var getMnoPromise = getMno();
        getMnoPromise.then(function(res) {
          medicineParam.mno = res;
          medicineParam.name_lower = medicineParam.name.toLowerCase();

          medicineParam.purchase[0].invdate =
            medicineParam.purchase[0].invdate !== null
              ? moment(medicineParam.purchase[0].invdate)
                  .tz("Asia/Calcutta")
                  .format("YYYY-MM-DD")
              : null;

          medicineParam.purchase[0].expdate =
            medicineParam.purchase[0].expdate !== null
              ? moment(medicineParam.purchase[0].expdate)
                  .tz("Asia/Calcutta")
                  .format("YYYY-MM-DD")
              : null;

          medicineParam.purchase[0].mfgdate =
            medicineParam.purchase[0].mfgdate !== null
              ? moment(medicineParam.purchase[0].mfgdate)
                  .tz("Asia/Calcutta")
                  .format("YYYY-MM-DD")
              : null;

          medicineParam.save();

          //Save history
          const his = {
            mno: medicineParam.mno,
            qty: medicineParam.stock.main,
            stock: medicineParam.stock.main,
            source: "Add",
            transferto: "",
            stocktype: "Main Stock",
            name: medicineParam.name
          };
          saveHistory(his);
        });
      } else {
        // Update medicine
        medicine.stock.main =
          parseInt(medicine.stock.main) + parseInt(req.body.stock.main);
        medicine.save().then(medicine => {
          //Save history
          const his = {
            mno: medicine.mno,
            qty: req.body.stock.main,
            stock: medicine.stock.main,
            source: "Edit",
            transferto: "",
            stocktype: "Main Stock",
            name: medicine.name
          };
          saveHistory(his);
        });
      }
    });
    res.status(200).json("Medicine added");
  } catch (err) {
    next(new Error(err));
  }
});

// Defined get data(index or listing) route
routes.route("/").get(function(req, res, next) {
  logger.log("info", "Medicine -> get");
  Medicine.find({}, null, { sort: { name: 1 } }, function(err, medicines) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(medicines);
    }
  });
});

// Defined edit route
routes.route("/edit/:id").get(function(req, res) {
  logger.log("info", "Medicine -> edit");
  let id = req.params.id;
  Medicine.findById(id, function(err, medicine) {
    res.status(200).json(medicine);
  });
});

//  Defined update route
routes.route("/update/:id").post(function(req, res, next) {
  logger.log("info", "Medicine -> update");
  try {
    Medicine.findById(req.params.id, function(err, medicine) {
      if (!medicine) res.status(404).send("Data not found");
      else {
        medicine.name = req.body.name;
        medicine.name_lower = medicine.name.toLowerCase();
        medicine.stock.main = req.body.stock.main;
        medicine.stock.sub = req.body.stock.sub;
        medicine.stock.a_kit = req.body.stock.a_kit;
        medicine.stock.b_kit = req.body.stock.b_kit;

        medicine.save().then(medicine => {
          res.status(200).json("Update completed");
        });
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

// Defined delete | remove | destroy route
routes.route("/delete/:id").get(function(req, res) {
  Medicine.findOneAndDelete({ _id: req.params.id }, function(err, medicine) {
    if (err) res.json(err);
    else res.json("Successfully removed");
  });
});

routes.route("/getNames").get(function(req, res, next) {
  logger.log("info", "Medicine -> getNames");
  Medicine.find({}, { _id: 0, mno: 1, name: 1 }, function(err, medicines) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(medicines);
    }
  });
});

routes.route("/getStock/:mno").get(function(req, res, next) {
  logger.log("info", "Medicine -> getStock");
  Medicine.findOne({ mno: req.params.mno }, { _id: 0, stock: 1 }, function(
    err,
    stock
  ) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(stock);
    }
  });
});

routes.route("/getPurchaseDetails/:mno").get(function(req, res, next) {
  logger.log("info", "Medicine -> getPurchaseDetails");
  Medicine.findOne({ mno: req.params.mno }, {}, function(err, med) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(med);
    }
  });
});

// Transfer main stock
routes.route("/transfer").post(function(req, res, next) {
  logger.log("info", "Medicine -> transfer");
  try {
    if (req.body.stocktype === "Sub Stock") {
      saveTransferSubStock(req, res);
    } else {
      saveTransfer(req, res);
    }
    res.status(200).json("Medicine Transferred");
  } catch (err) {
    next(new Error(err));
  }
});

function saveTransfer(req, res) {
  logger.log("info", "Medicine -> saveTransfer");
  Medicine.findOne({ mno: req.body.mno }, function(err, medicine) {
    if (!medicine) res.status(404).send("Data not found");
    else {
      medicine.stock.main =
        parseInt(medicine.stock.main) - parseInt(req.body.qty);
      medicine.stock.sub =
        parseInt(medicine.stock.sub) + parseInt(req.body.qty);
      medicine.save().then(medicine => {
        //Save history - Main
        const hisMain = {
          mno: medicine.mno,
          qty: req.body.qty,
          stock: medicine.stock.main,
          source: req.body.source,
          transferto: req.body.transferto,
          stocktype: req.body.stocktype,
          name: medicine.name
        };
        saveHistory(hisMain);

        //Save history - Sub
        const hisSub = {
          mno: medicine.mno,
          qty: req.body.qty,
          stock: medicine.stock.sub,
          source: "Transfer In",
          transferto: "",
          stocktype: req.body.transferto,
          name: medicine.name
        };
        saveHistory(hisSub);
      });
    }
  });
}

function saveTransferSubStock(req, res) {
  logger.log("info", "Medicine -> saveTransferSubStock");
  Medicine.findOne({ mno: req.body.mno }, function(err, medicine) {
    if (!medicine) res.status(404).send("Data not found");
    else {
      medicine.stock.sub =
        parseInt(medicine.stock.sub) - parseInt(req.body.qty);

      let kitStock = 0,
        mno = "",
        name = "";

      if (req.body.transferto === "A Kit") {
        medicine.stock.a_kit =
          (isNaN(parseInt(medicine.stock.a_kit))
            ? 0
            : parseInt(medicine.stock.a_kit)) + parseInt(req.body.qty);
        kitStock = medicine.stock.a_kit;
      } else if (req.body.transferto === "B Kit") {
        medicine.stock.b_kit =
          (isNaN(parseInt(medicine.stock.b_kit))
            ? 0
            : parseInt(medicine.stock.b_kit)) + parseInt(req.body.qty);
        kitStock = medicine.stock.b_kit;
      }

      mno = medicine.mno;
      name = medicine.name;

      medicine.save().then(medicine => {
        //Save history - Sub
        const hisMain = {
          mno: medicine.mno,
          qty: req.body.qty,
          stock: medicine.stock.sub,
          source: req.body.source,
          transferto: req.body.transferto,
          stocktype: req.body.stocktype,
          name: medicine.name
        };
        saveHistory(hisMain);

        if (req.body.transferto !== "OP") {
          const hisSub = {
            mno: mno,
            qty: req.body.qty,
            stock: kitStock,
            source: "Transfer In",
            transferto: "",
            stocktype: req.body.transferto,
            name: name
          };
          saveHistory(hisSub);
        }
      });
    }
  });
}

function saveTransferKitStock(req, res) {
  logger.log("info", "Medicine -> saveTransferKitStock");
  Medicine.findOne({ mno: req.body.mno }, function(err, medicine) {
    if (!medicine) res.status(404).send("Data not found");
    else {
      let kitStock = 0;
      if (req.body.stocktype === "A Kit") {
        medicine.stock.a_kit =
          parseInt(medicine.stock.a_kit) - parseInt(req.body.qty);
        kitStock = medicine.stock.a_kit;
      } else {
        medicine.stock.b_kit =
          parseInt(medicine.stock.b_kit) - parseInt(req.body.qty);
        kitStock = medicine.stock.b_kit;
      }

      mno = medicine.mno;
      name = medicine.name;

      medicine.save().then(medicine => {
        //Save history
        const hisMain = {
          mno: medicine.mno,
          qty: req.body.qty,
          stock: kitStock,
          source: req.body.source,
          transferto: "OP",
          stocktype: req.body.stocktype,
          name: medicine.name
        };
        saveHistory(hisMain);
      });
    }
  });
}

// Transfer OP
routes.route("/transferOP").post(function(req, res, next) {
  logger.log("info", "Medicine -> transferOP");
  try {
    saveTransferSubStock(req);

    let patDet = req.body.patient.split("] ");
    let pno = patDet[0].replace("[", "");
    let pname = patDet[1];

    // save OP history
    let op = new OP();
    op.mno = req.body.mno;
    op.medicinename = req.body.medicinename;
    op.qty = req.body.qty;
    op.pno = pno;
    op.patientname = pname;
    op.updatedon = new Date();

    op.save();
    res.status(200).json("Medicine Transferred");
  } catch (err) {
    next(new Error(err));
  }
});

// Transfer Kit
routes.route("/transferKit").post(function(req, res, next) {
  logger.log("info", "Medicine -> transferKit");
  try {
    saveTransferKitStock(req);

    let patDet = req.body.patient.split("] ");
    let pno = patDet[0].replace("[", "");
    let pname = patDet[1];

    // save OP history
    let op = new OP();
    op.mno = req.body.mno;
    op.medicinename = req.body.medicinename;
    op.qty = req.body.qty;
    op.pno = pno;
    op.patientname = pname;
    op.updatedon = new Date();

    op.save();
    res.status(200).json("Medicine Transferred");
  } catch (err) {
    next(new Error(err));
  }
});

// Inbound main stock
routes.route("/inbound").post(function(req, res, next) {
  logger.log("info", "Medicine -> inbound");
  try {
    Medicine.findOne({ mno: req.body.mno }, function(err, medicine) {
      if (!medicine) res.status(404).send("Data not found");
      else {
        medicine.stock.main =
          parseInt(medicine.stock.main) + parseInt(req.body.qty);

        const objPur = {
          expdate: req.body.purchase.expdate,
          mfgdate: req.body.purchase.mfgdate,
          rate: req.body.purchase.rate,
          dealer: req.body.purchase.dealer,
          invdate: req.body.purchase.invdate,
          invno: req.body.purchase.invno,
          batchno: req.body.purchase.batchno,
          qty: req.body.purchase.qty
        };

        objPur.invdate = moment(objPur.invdate)
          .tz("Asia/Calcutta")
          .format("YYYY-MM-DD");

        objPur.expdate = moment(objPur.expdate)
          .tz("Asia/Calcutta")
          .format("YYYY-MM-DD");

        objPur.mfgdate = moment(objPur.mfgdate)
          .tz("Asia/Calcutta")
          .format("YYYY-MM-DD");

        medicine.purchase.push(objPur);

        medicine.save().then(medicine => {
          //Save history - Main
          const hisMain = {
            mno: medicine.mno,
            qty: req.body.qty,
            stock: medicine.stock.main,
            source: "Inbound",
            transferto: "",
            stocktype: "Main Stock",
            name: medicine.name
          };

          saveHistory(hisMain);
        });
      }
    });

    res.status(200).json("Medicine Added");
  } catch (err) {
    next(new Error(err));
  }
});

routes.route("/return").post(function(req, res, next) {
  logger.log("info", "Medicine -> return");
  try {
    Medicine.findOne({ mno: req.body.mno }, function(err, medicine) {
      if (!medicine) res.status(404).send("Data not found");
      else {
        medicine.stock.main =
          parseInt(medicine.stock.main) - parseInt(req.body.qty);

        const objPur = {
          expdate: null,
          mfgdate: null,
          rate: 0,
          dealer: "",
          invdate: req.body.purchase.invdate,
          invno: "",
          batchno: "",
          qty: req.body.purchase.qty,
          return: 1
        };

        objPur.invdate = moment(objPur.invdate).format("YYYY-MM-DD");
        medicine.purchase.push(objPur);

        medicine.save().then(medicine => {
          //Save history
          const hisMain = {
            mno: medicine.mno,
            qty: req.body.qty,
            stock: medicine.stock.main,
            source: "Return",
            transferto: "",
            stocktype: "Main Stock",
            name: medicine.name
          };

          saveHistory(hisMain);
        });
      }
    });

    res.status(200).json("Medicine Returned");
  } catch (err) {
    next(new Error(err));
  }
});

module.exports = routes;
