const express = require("express");
var Promise = require("promise");
const routes = express.Router();
const logger = require("../utils/logger/logger").getLoggerInstance();
let Bank = require("../database/schemas/bank.model");

function getBno() {
  logger.log("info", "Bank -> getBno");
  return new Promise(function(resolve, reject) {
    // Do async job
    Bank.countDocuments(function(err, cnt) {
      var newCnt = ++cnt;
      resolve("B" + newCnt);
    });
  });
}

// Defined store route
routes.route("/add").post(function(req, res, next) {
  logger.log("info", "Bank -> add");
  try {
    let bank = new Bank(req.body);
    var getBnoPromise = getBno();
    getBnoPromise.then(function(res) {
      bank.bno = res;
      bank.save();
    });
    res.status(200).send("Success");
  } catch (err) {
    next(new Error(err));
  }
});

// Defined get data(index or listing) route
routes.route("/").get(function(req, res, next) {
  logger.log("info", "Bank -> get");
  Bank.find(function(err, banks) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(banks);
    }
  });
});

routes.route("/getBanks").get(function(req, res, next) {
  logger.log("info", "Bank -> getBanks");
  try {
    Bank.find(function(err, data) {
      if (err) {
        next(new Error(err));
      } else {
        res.status(200).json(data);
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

// Defined edit route
routes.route("/edit/:id").get(function(req, res) {
  logger.log("info", "Bank -> edit");
  let id = req.params.id;
  Bank.findById(id, function(err, bank) {
    res.status(200).json(bank);
  });
});

//  Defined update route
routes.route("/update/:id").post(function(req, res, next) {
  logger.log("info", "Bank -> update");
  try {
    Bank.findById(req.params.id, function(err, bank) {
      if (!bank) res.status(404).send("Data not found");
      else {
        bank.name = req.body.name;

        bank.save().then(bank => {
          res.status(200).json("Update complete");
        });
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

// Defined delete | remove | destroy route
routes.route("/delete/:id").get(function(req, res) {
  Bank.findOneAndDelete({ _id: req.params.id }, function(err, incomeType) {
    if (err) res.json(err);
    else res.json("Successfully removed");
  });
});

module.exports = routes;
