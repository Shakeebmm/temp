-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: olive
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `txndate` datetime DEFAULT NULL,
  `desc` varchar(200) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `txntype` varchar(45) DEFAULT NULL,
  `paymentMode` varchar(45) DEFAULT NULL,
  `PatientId` int DEFAULT NULL,
  `PaymentId` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=1441 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (1,'2021-10-31 00:00:00','Opening Balance','Opening Balance',11000.00,'Income','Cash',NULL,NULL),(3,'2021-12-31 00:00:00','','Medicine',150.00,'Income','Cash',1,NULL),(4,'2021-12-31 00:00:00','','Consultation',100.00,'Income','Cash',1,NULL),(5,'2021-11-13 00:00:00','','Medicine',150.00,'Income','Cash',4,5),(6,'2021-11-13 00:00:00','','Consultation',100.00,'Income','Cash',4,5),(7,'2021-11-13 00:00:00','','Medicine',150.00,'Income','Cash',5,6),(8,'2021-11-13 00:00:00','','Consultation',100.00,'Income','Cash',5,6),(9,'2021-11-13 00:00:00','','Medicine',150.00,'Income','Cash',6,7),(10,'2021-11-13 00:00:00','','Consultation',100.00,'Income','Cash',6,7),(11,'2021-12-04 00:00:00','','Medicine',150.00,'Income','Bank',6,8),(12,'2021-12-04 00:00:00','','Consultation',100.00,'Income','Bank',6,8),(13,'2021-11-13 00:00:00','','Medicine',200.00,'Income','Cash',7,9),(14,'2021-11-13 00:00:00','','Consultation',100.00,'Income','Cash',7,9),(15,'2021-11-13 00:00:00','','Medicine',150.00,'Income','Cash',8,10),(16,'2021-11-13 00:00:00','','Consultation',100.00,'Income','Cash',8,10),(17,'2021-12-01 00:00:00','','Medicine',150.00,'Income','Cash',8,11),(18,'2021-12-01 00:00:00','','Consultation',100.00,'Income','Cash',8,11),(19,'2021-11-13 00:00:00','','Medicine',200.00,'Income','Cash',9,12),(20,'2021-11-13 00:00:00','','Consultation',100.00,'Income','Cash',9,12),(21,'2021-12-06 00:00:00','','Medicine',200.00,'Income','Bank',9,13),(22,'2021-12-06 00:00:00','','Consultation',100.00,'Income','Bank',9,13),(28,'2021-11-26 00:00:00','','Medicine',150.00,'Income','Cash',5,17),(29,'2021-11-26 00:00:00','','Consultation',100.00,'Income','Cash',5,17),(30,'2022-01-03 00:00:00','','Medicine',150.00,'Income','Bank',6,18),(31,'2022-01-03 00:00:00','','Consultation',100.00,'Income','Bank',6,18),(40,'2021-12-06 00:00:00','','Medicine',150.00,'Income','Cash',10,24),(41,'2021-12-06 00:00:00','','Consultation',100.00,'Income','Cash',10,24),(35,'2021-11-15 00:00:00','','Medicine',100.00,'Income','Cash',10,21),(36,'2021-11-15 00:00:00','','Consultation',100.00,'Income','Cash',10,21),(37,'2021-11-20 00:00:00','','Medicine',100.00,'Income','Cash',10,22),(38,'2021-12-17 00:00:00','','Medicine',100.00,'Income','Cash',10,23),(39,'2021-12-17 00:00:00','','Consultation',100.00,'Income','Cash',10,23),(49,'2021-11-15 00:00:00','','Medicine',150.00,'Income','Cash',11,29),(48,'2021-11-15 00:00:00','','Consultation',100.00,'Income','Cash',10,28),(47,'2021-11-15 00:00:00','','Medicine',150.00,'Income','Cash',10,28),(46,'2021-12-27 00:00:00','','Medicine',50.00,'Income','Cash',10,27),(50,'2021-11-15 00:00:00','','Consultation',100.00,'Income','Cash',11,29),(51,'2021-11-16 00:00:00','','Medicine',250.00,'Income','Cash',12,30),(52,'2021-11-16 00:00:00','','Consultation',100.00,'Income','Cash',12,30),(53,'2021-11-16 00:00:00','','Medicine',150.00,'Income','Cash',13,31),(54,'2021-11-16 00:00:00','','Consultation',100.00,'Income','Cash',13,31),(55,'2021-11-16 00:00:00','','Medicine',150.00,'Income','Cash',14,32),(56,'2021-11-16 00:00:00','','Consultation',100.00,'Income','Cash',14,32),(57,'2021-12-01 00:00:00','','Medicine',200.00,'Income','Cash',14,33),(58,'2021-12-01 00:00:00','','Consultation',100.00,'Income','Cash',14,33),(59,'2021-12-21 00:00:00','','Medicine',50.00,'Income','Cash',14,34),(60,'2021-12-21 00:00:00','','Consultation',100.00,'Income','Cash',14,34),(61,'2021-12-23 00:00:00','','Medicine',240.00,'Income','Cash',14,35),(62,'2021-11-18 00:00:00','','Medicine',150.00,'Income','Cash',15,36),(63,'2021-11-18 00:00:00','','Consultation',100.00,'Income','Cash',15,36),(64,'2022-01-03 00:00:00','','Medicine',150.00,'Income','Cash',15,37),(65,'2022-01-03 00:00:00','','Consultation',100.00,'Income','Cash',15,37),(66,'2021-11-18 00:00:00','','Medicine',350.00,'Income','Cash',16,38),(67,'2021-11-18 00:00:00','','Consultation',100.00,'Income','Cash',16,38),(68,'2021-11-18 00:00:00','','Medicine',100.00,'Income','Cash',17,39),(69,'2021-11-18 00:00:00','','Consultation',100.00,'Income','Cash',17,39),(70,'2021-11-18 00:00:00','','Medicine',150.00,'Income','Cash',18,40),(71,'2021-11-18 00:00:00','','Consultation',100.00,'Income','Cash',18,40),(72,'2021-11-23 00:00:00','','Medicine',100.00,'Income','Cash',18,41),(73,'2021-11-19 00:00:00','','Medicine',150.00,'Income','Cash',19,42),(74,'2021-11-19 00:00:00','','Consultation',100.00,'Income','Cash',19,42),(75,'2022-01-03 00:00:00','','Medicine',150.00,'Income','Cash',19,43),(76,'2022-01-03 00:00:00','','Consultation',100.00,'Income','Cash',19,43),(77,'2021-11-19 00:00:00','','Medicine',100.00,'Income','Cash',21,44),(78,'2021-11-19 00:00:00','','Consultation',100.00,'Income','Cash',21,44),(79,'2021-11-19 00:00:00','','Medicine',150.00,'Income','Cash',22,45),(80,'2021-11-19 00:00:00','','Consultation',100.00,'Income','Cash',22,45),(81,'2021-11-22 00:00:00','','Medicine',250.00,'Income','Cash',23,46),(82,'2021-11-22 00:00:00','','Consultation',100.00,'Income','Cash',23,46),(83,'2021-11-22 00:00:00','','Medicine',150.00,'Income','Cash',24,47),(84,'2021-11-22 00:00:00','','Consultation',100.00,'Income','Cash',24,47),(88,'2021-11-22 00:00:00','','Consultation',100.00,'Income','Cash',25,49),(87,'2021-11-22 00:00:00','','Medicine',250.00,'Income','Cash',25,49),(89,'2021-11-24 00:00:00','','Medicine',150.00,'Income','Cash',27,50),(90,'2021-11-24 00:00:00','','Consultation',100.00,'Income','Cash',27,50),(91,'2021-11-20 00:00:00','','Medicine',250.00,'Income','Cash',27,51),(92,'2021-11-20 00:00:00','','Consultation',100.00,'Income','Cash',27,51),(93,'2021-11-24 00:00:00','','Medicine',150.00,'Income','Cash',26,52),(94,'2021-11-24 00:00:00','','Consultation',100.00,'Income','Cash',26,52),(95,'2022-01-17 00:00:00','','Medicine',150.00,'Income','Cash',19,53),(96,'2022-01-17 00:00:00','','Consultation',100.00,'Income','Cash',19,53),(97,'2021-11-26 00:00:00','','Medicine',210.00,'Income','Cash',29,54),(98,'2021-11-26 00:00:00','','Consultation',100.00,'Income','Cash',29,54),(99,'2021-11-26 00:00:00','','Medicine',190.00,'Income','Cash',30,55),(100,'2021-11-26 00:00:00','','Consultation',100.00,'Income','Cash',30,55),(101,'2021-11-26 00:00:00','','Medicine',150.00,'Income','Cash',31,56),(102,'2021-11-26 00:00:00','','Consultation',100.00,'Income','Cash',31,56),(103,'2021-11-27 00:00:00','','Medicine',150.00,'Income','Cash',33,58),(104,'2021-11-27 00:00:00','','Consultation',100.00,'Income','Cash',33,58),(105,'2021-11-27 00:00:00','','Medicine',150.00,'Income','Cash',34,59),(106,'2021-11-27 00:00:00','','Consultation',100.00,'Income','Cash',34,59),(107,'2021-12-03 00:00:00','','Medicine',150.00,'Income','Cash',34,60),(108,'2021-12-03 00:00:00','','Consultation',100.00,'Income','Cash',34,60),(109,'2021-11-27 00:00:00','','Medicine',100.00,'Income','Cash',35,61),(110,'2021-11-27 00:00:00','','Consultation',100.00,'Income','Cash',35,61),(111,'2021-12-03 00:00:00','','Medicine',210.00,'Income','Cash',35,62),(112,'2021-12-03 00:00:00','','Consultation',100.00,'Income','Cash',35,62),(113,'2021-12-01 00:00:00','','Medicine',150.00,'Income','Cash',37,63),(114,'2021-12-01 00:00:00','','Consultation',100.00,'Income','Cash',37,63),(115,'2021-12-14 00:00:00','','Medicine',150.00,'Income','Cash',37,64),(116,'2021-12-14 00:00:00','','Consultation',100.00,'Income','Cash',37,64),(117,'2021-12-01 00:00:00','','Medicine',200.00,'Income','Cash',38,65),(118,'2021-12-01 00:00:00','','Consultation',100.00,'Income','Cash',38,65),(119,'2021-12-04 00:00:00','','Medicine',150.00,'Income','Cash',39,66),(120,'2021-12-04 00:00:00','','Consultation',100.00,'Income','Cash',39,66),(121,'2021-12-08 00:00:00','','Medicine',150.00,'Income','Cash',40,67),(122,'2021-12-08 00:00:00','','Consultation',100.00,'Income','Cash',40,67),(123,'2021-12-11 00:00:00','','Medicine',50.00,'Income','Cash',40,69),(124,'2021-12-11 00:00:00','','Consultation',100.00,'Income','Cash',40,69),(125,'2021-12-09 00:00:00','','Medicine',150.00,'Income','Cash',41,70),(126,'2021-12-09 00:00:00','','Consultation',100.00,'Income','Cash',41,70),(127,'2021-12-10 00:00:00','','Medicine',150.00,'Income','Cash',42,71),(128,'2021-12-10 00:00:00','','Consultation',100.00,'Income','Cash',42,71),(129,'2021-12-10 00:00:00','','Medicine',150.00,'Income','Cash',43,72),(130,'2021-12-10 00:00:00','','Consultation',100.00,'Income','Cash',43,72),(131,'2021-12-10 00:00:00','','Medicine',150.00,'Income','Cash',44,73),(132,'2021-12-10 00:00:00','','Consultation',100.00,'Income','Cash',44,73),(133,'2021-12-13 00:00:00','','Medicine',150.00,'Income','Cash',45,74),(134,'2021-12-13 00:00:00','','Consultation',100.00,'Income','Cash',45,74),(135,'2021-12-13 00:00:00','','Medicine',150.00,'Income','Cash',46,75),(136,'2021-12-13 00:00:00','','Consultation',100.00,'Income','Cash',46,75),(137,'2022-01-06 00:00:00','','Medicine',150.00,'Income','Cash',46,76),(138,'2022-01-06 00:00:00','','Consultation',100.00,'Income','Cash',46,76),(139,'2021-12-14 00:00:00','','Medicine',120.00,'Income','Cash',47,77),(140,'2021-12-14 00:00:00','','Consultation',100.00,'Income','Cash',47,77),(141,'2021-12-31 00:00:00','','Medicine',120.00,'Income','Cash',47,78),(142,'2021-12-31 00:00:00','','Consultation',100.00,'Income','Cash',47,78),(143,'2021-12-17 00:00:00','','Medicine',100.00,'Income','Cash',48,79),(144,'2021-12-17 00:00:00','','Consultation',100.00,'Income','Cash',48,79),(145,'2021-12-21 00:00:00','','Medicine',60.00,'Income','Cash',48,80),(146,'2021-12-18 00:00:00','','Medicine',120.00,'Income','Cash',49,81),(147,'2021-12-18 00:00:00','','Consultation',100.00,'Income','Cash',49,81),(148,'2022-01-13 00:00:00','','Medicine',150.00,'Income','Cash',49,82),(149,'2022-01-13 00:00:00','','Consultation',100.00,'Income','Cash',49,82),(150,'2021-12-18 00:00:00','','Medicine',150.00,'Income','Cash',50,83),(151,'2021-12-18 00:00:00','','Consultation',100.00,'Income','Cash',50,83),(152,'2021-12-30 00:00:00','','Medicine',100.00,'Income','Cash',50,84),(153,'2021-12-30 00:00:00','','Consultation',100.00,'Income','Cash',50,84),(154,'2021-12-24 00:00:00','','Medicine',150.00,'Income','Cash',51,85),(155,'2021-12-24 00:00:00','','Consultation',100.00,'Income','Cash',51,85),(156,'2021-12-24 00:00:00','','Medicine',100.00,'Income','Cash',52,86),(157,'2021-12-24 00:00:00','','Consultation',100.00,'Income','Cash',52,86),(158,'2021-12-30 00:00:00','','Medicine',200.00,'Income','Bank',55,89),(159,'2021-12-30 00:00:00','','Consultation',100.00,'Income','Bank',55,89),(160,'2021-12-29 00:00:00','','Medicine',100.00,'Income','Cash',56,90),(161,'2021-12-29 00:00:00','','Consultation',100.00,'Income','Cash',56,90),(162,'2022-01-03 00:00:00','','Medicine',150.00,'Income','Cash',57,91),(163,'2022-01-03 00:00:00','','Consultation',100.00,'Income','Cash',57,91),(164,'2022-01-17 00:00:00','','Medicine',50.00,'Income','Cash',57,92),(165,'2022-01-04 00:00:00','','Medicine',100.00,'Income','Cash',58,93),(166,'2022-01-04 00:00:00','','Consultation',100.00,'Income','Cash',58,93),(167,'2022-01-05 00:00:00','','Medicine',120.00,'Income','Cash',60,95),(168,'2022-01-05 00:00:00','','Consultation',100.00,'Income','Cash',60,95),(169,'2022-01-06 00:00:00','','Medicine',130.00,'Income','Cash',61,96),(170,'2022-01-06 00:00:00','','Consultation',100.00,'Income','Cash',61,96),(171,'2022-01-29 00:00:00','','Medicine',100.00,'Income','Cash',61,97),(172,'2022-01-29 00:00:00','','Consultation',100.00,'Income','Cash',61,97),(173,'2022-01-06 00:00:00','','Medicine',150.00,'Income','Cash',62,98),(174,'2022-01-06 00:00:00','','Consultation',100.00,'Income','Cash',62,98),(175,'2022-01-11 00:00:00','','Medicine',200.00,'Income','Bank',63,99),(176,'2022-01-11 00:00:00','','Consultation',100.00,'Income','Bank',63,99),(177,'2022-01-10 00:00:00','','Medicine',120.00,'Income','Cash',64,100),(178,'2022-01-10 00:00:00','','Consultation',100.00,'Income','Cash',64,100),(179,'2022-01-10 00:00:00','','Medicine',120.00,'Income','Cash',65,101),(180,'2022-01-10 00:00:00','','Consultation',100.00,'Income','Cash',65,101),(181,'2022-01-10 00:00:00','','Medicine',250.00,'Income','Cash',66,102),(182,'2022-01-10 00:00:00','','Consultation',100.00,'Income','Cash',66,102),(183,'2022-01-26 00:00:00','','Medicine',360.00,'Income','Cash',66,103),(184,'2022-01-11 00:00:00','','Medicine',150.00,'Income','Cash',67,104),(185,'2022-01-11 00:00:00','','Consultation',100.00,'Income','Cash',67,104),(186,'2022-01-11 00:00:00','','Medicine',100.00,'Income','Bank',68,105),(187,'2022-01-11 00:00:00','','Consultation',100.00,'Income','Bank',68,105),(188,'2022-01-12 00:00:00','','Medicine',100.00,'Income','Cash',69,106),(189,'2022-01-13 00:00:00','','Medicine',150.00,'Income','Cash',70,107),(190,'2022-01-13 00:00:00','','Consultation',100.00,'Income','Cash',70,107),(191,'2022-01-21 00:00:00','','Medicine',150.00,'Income','Cash',70,108),(192,'2022-01-21 00:00:00','','Consultation',100.00,'Income','Cash',70,108),(193,'2022-01-14 00:00:00','','Medicine',100.00,'Income','Cash',71,109),(194,'2022-01-14 00:00:00','','Consultation',100.00,'Income','Cash',71,109),(195,'2022-01-14 00:00:00','','Medicine',150.00,'Income','Cash',72,110),(196,'2022-01-14 00:00:00','','Consultation',100.00,'Income','Cash',72,110),(197,'2022-01-14 00:00:00','','Medicine',150.00,'Income','Cash',73,111),(198,'2022-01-14 00:00:00','','Consultation',100.00,'Income','Cash',73,111),(199,'2022-01-14 00:00:00','','Medicine',150.00,'Income','Cash',73,112),(200,'2022-01-14 00:00:00','','Consultation',100.00,'Income','Cash',73,112),(201,'2022-01-21 00:00:00','','Medicine',150.00,'Income','Cash',74,113),(202,'2022-01-21 00:00:00','','Consultation',100.00,'Income','Cash',74,113),(203,'2022-01-22 00:00:00','','Medicine',150.00,'Income','Cash',75,114),(204,'2022-01-22 00:00:00','','Consultation',100.00,'Income','Cash',75,114),(205,'2022-01-22 00:00:00','','Medicine',120.00,'Income','Cash',76,115),(206,'2022-01-22 00:00:00','','Consultation',100.00,'Income','Cash',76,115),(207,'2022-01-24 00:00:00','','Medicine',120.00,'Income','Cash',77,116),(208,'2022-01-24 00:00:00','','Consultation',100.00,'Income','Cash',77,116),(209,'2022-01-26 00:00:00','','Medicine',150.00,'Income','Cash',78,117),(210,'2022-01-26 00:00:00','','Consultation',100.00,'Income','Cash',78,117),(211,'2022-01-29 00:00:00','','Medicine',100.00,'Income','Cash',80,118),(212,'2022-01-29 00:00:00','','Consultation',100.00,'Income','Cash',80,118),(213,'2022-01-31 00:00:00','','Medicine',100.00,'Income','Cash',81,119),(214,'2022-01-31 00:00:00','','Consultation',50.00,'Income','Cash',81,119),(215,'2022-01-22 00:00:00','','Medicine',100.00,'Income','Cash',82,120),(216,'2022-02-01 00:00:00','','Medicine',120.00,'Income','Cash',83,121),(217,'2022-02-01 00:00:00','','Consultation',100.00,'Income','Cash',83,121),(218,'2022-02-01 00:00:00','','Medicine',150.00,'Income','Cash',70,122),(219,'2022-02-01 00:00:00','','Consultation',100.00,'Income','Cash',70,122),(220,'2022-02-01 00:00:00','','Medicine',130.00,'Income','Cash',46,123),(221,'2022-02-01 00:00:00','','Consultation',100.00,'Income','Cash',46,123),(222,'2022-01-31 00:00:00','Expense adjust','Expense adjust',-34330.00,'Expense','Cash',NULL,NULL),(223,'2022-02-02 00:00:00','A2180 ADINAN','Medicine',0.00,'Income','Cash',NULL,NULL),(224,'2022-02-02 00:00:00','','Medicine',50.00,'Income','Cash',80,125),(225,'2021-11-15 00:00:00','','Medicine',100.00,'Income','Cash',84,126),(226,'2021-11-15 00:00:00','','Consultation',100.00,'Income','Cash',84,126),(227,'2021-11-20 00:00:00','','Medicine',100.00,'Income','Cash',84,127),(228,'2021-12-06 00:00:00','','Medicine',150.00,'Income','Cash',84,128),(229,'2021-12-06 00:00:00','','Consultation',100.00,'Income','Cash',84,128),(230,'2021-12-17 00:00:00','','Medicine',100.00,'Income','Cash',84,129),(231,'2021-12-17 00:00:00','','Consultation',100.00,'Income','Cash',84,129),(232,'2022-01-21 00:00:00','','Medicine',150.00,'Income','Cash',84,131),(233,'2022-01-21 00:00:00','','Consultation',100.00,'Income','Cash',84,131),(234,'2021-12-27 00:00:00','','Medicine',50.00,'Income','Cash',84,132),(235,'2022-02-03 00:00:00','','Medicine',150.00,'Income','Cash',84,133),(236,'2022-02-03 00:00:00','','Consultation',100.00,'Income','Cash',84,133),(237,'2022-02-03 00:00:00','A2190 - ABDUL HANAN','Medicine',150.00,'Income','Cash',85,134),(238,'2022-02-03 00:00:00','','Consultation',100.00,'Income','Cash',85,134),(239,'2022-02-03 00:00:00','Medicine','Medicine - Aspire',0.00,'Expense','Bank',NULL,NULL),(240,'2022-01-31 00:00:00','Expense adjust','Expense adjust',-2000.00,'Expense','Cash',NULL,NULL),(241,'2022-02-04 00:00:00','','Medicine',100.00,'Income','Cash',87,136),(242,'2022-02-04 00:00:00','','Consultation',100.00,'Income','Cash',87,136),(243,'2022-02-04 00:00:00','','Medicine',150.00,'Income','Cash',86,137),(244,'2022-02-04 00:00:00','','Consultation',100.00,'Income','Cash',86,137),(245,'2022-02-03 00:00:00','ASPIRE HOMOEOS','Medicine - Aspire',-1232.00,'Expense','Bank',NULL,NULL),(246,'2022-02-05 00:00:00','','Medicine',300.00,'Income','Bank',79,138),(247,'2022-02-05 00:00:00','','Consultation',100.00,'Income','Bank',79,138),(248,'2022-02-04 00:00:00','','Medicine',120.00,'Income','Bank',14,139),(249,'2022-02-04 00:00:00','','Consultation',100.00,'Income','Bank',14,139),(250,'2022-02-05 00:00:00','BLUE PLAST BOTTLES','Bottles - Blue Plast',-542.00,'Expense','Bank',NULL,NULL),(251,'2022-02-08 00:00:00','','Medicine',150.00,'Income','Cash',88,140),(252,'2022-02-08 00:00:00','','Consultation',100.00,'Income','Cash',88,140),(253,'2022-02-08 00:00:00','','Medicine',100.00,'Income','Cash',80,141),(254,'2022-02-08 00:00:00','','Consultation',100.00,'Income','Cash',80,141),(255,'2022-02-10 00:00:00','Feb bill','Electricity Bill',-789.00,'Expense','Bank',NULL,NULL),(256,'2022-02-10 00:00:00','','Medicine',150.00,'Income','Cash',59,142),(257,'2022-02-10 00:00:00','','Consultation',100.00,'Income','Cash',59,142),(258,'2022-01-04 00:00:00','','Medicine',150.00,'Income','Cash',59,143),(259,'2022-01-04 00:00:00','','Consultation',100.00,'Income','Cash',59,143),(260,'2022-02-11 00:00:00','','Medicine',150.00,'Income','Cash',67,144),(261,'2022-02-11 00:00:00','','Consultation',100.00,'Income','Cash',67,144),(262,'2022-01-28 00:00:00','','Medicine',120.00,'Income','Cash',19,145),(263,'2022-01-28 00:00:00','','Consultation',100.00,'Income','Cash',19,145),(264,'2022-02-10 00:00:00','','Medicine',150.00,'Income','Cash',19,146),(265,'2022-02-10 00:00:00','','Consultation',100.00,'Income','Cash',19,146),(266,'2022-02-10 00:00:00','','Medicine',170.00,'Income','Cash',89,147),(267,'2022-02-10 00:00:00','','Consultation',100.00,'Income','Cash',89,147),(268,'2022-02-10 00:00:00','','Medicine',100.00,'Income','Cash',90,148),(269,'2022-02-10 00:00:00','','Consultation',100.00,'Income','Cash',90,148),(270,'2022-02-11 00:00:00','','Medicine',50.00,'Income','Cash',67,149),(271,'2022-02-12 00:00:00','','Medicine',150.00,'Income','Cash',91,150),(272,'2022-02-12 00:00:00','','Consultation',100.00,'Income','Cash',91,150),(273,'2022-02-12 00:00:00','','Medicine',120.00,'Income','Cash',92,151),(274,'2022-02-12 00:00:00','','Consultation',100.00,'Income','Cash',92,151),(275,'2022-02-12 00:00:00','','Medicine',210.00,'Income','Cash',93,152),(276,'2022-02-12 00:00:00','','Consultation',100.00,'Income','Cash',93,152),(277,'2022-02-12 00:00:00','','Medicine',120.00,'Income','Cash',83,153),(278,'2022-02-12 00:00:00','','Consultation',100.00,'Income','Cash',83,153),(279,'2022-02-12 00:00:00','','Medicine',150.00,'Income','Cash',86,154),(280,'2022-02-12 00:00:00','','Consultation',100.00,'Income','Cash',86,154),(281,'2022-02-14 00:00:00','','Medicine',200.00,'Income','Cash',49,155),(282,'2022-02-14 00:00:00','','Consultation',100.00,'Income','Cash',49,155),(283,'2022-02-16 00:00:00','','Medicine',120.00,'Income','Cash',94,156),(284,'2022-02-16 00:00:00','','Consultation',100.00,'Income','Cash',94,156),(285,'2022-02-16 00:00:00','','Medicine',130.00,'Income','Bank',95,157),(286,'2022-02-16 00:00:00','','Consultation',100.00,'Income','Bank',95,157),(287,'2022-02-16 00:00:00','','Medicine',120.00,'Income','Cash',96,158),(288,'2022-02-16 00:00:00','','Consultation',100.00,'Income','Cash',96,158),(289,'2022-02-06 00:00:00','test','test',0.00,'Expense','Cash',NULL,NULL),(290,'2022-02-18 00:00:00','','Medicine',150.00,'Income','Cash',97,159),(291,'2022-02-18 00:00:00','','Consultation',100.00,'Income','Cash',97,159),(292,'2022-02-17 00:00:00','Medicine','Medicine - Aspire',-397.00,'Expense','Bank',NULL,NULL),(293,'2022-02-18 00:00:00','','Medicine',100.00,'Income','Cash',67,160),(294,'2022-02-18 00:00:00','','Consultation',100.00,'Income','Cash',67,160),(295,'2022-02-18 00:00:00','A2170 - AYISHA','Medicine',180.00,'Income','Cash',70,161),(296,'2022-02-18 00:00:00','A2170 - AYISHA','Consultation',100.00,'Income','Cash',70,161),(297,'2022-02-19 00:00:00','','Medicine',150.00,'Income','Cash',50,162),(298,'2022-02-19 00:00:00','','Consultation',100.00,'Income','Cash',50,162),(299,'2022-02-21 00:00:00','','Medicine',150.00,'Income','Cash',27,163),(300,'2022-02-21 00:00:00','','Consultation',100.00,'Income','Cash',27,163),(301,'2022-02-21 00:00:00','','Medicine',120.00,'Income','Cash',80,164),(302,'2022-02-21 00:00:00','','Consultation',100.00,'Income','Cash',80,164),(303,'2022-02-22 00:00:00','','Medicine',150.00,'Income','Cash',98,165),(304,'2022-02-22 00:00:00','','Consultation',100.00,'Income','Cash',98,165),(305,'2022-02-21 00:00:00','','Medicine',150.00,'Income','Cash',85,166),(306,'2022-02-21 00:00:00','','Consultation',100.00,'Income','Cash',85,166),(307,'2022-02-22 00:00:00','','Medicine',180.00,'Income','Cash',99,167),(308,'2022-02-22 00:00:00','','Consultation',100.00,'Income','Cash',99,167),(309,'2022-02-23 00:00:00','','Medicine',180.00,'Income','Cash',100,168),(310,'2022-02-23 00:00:00','','Consultation',100.00,'Income','Cash',100,168),(311,'2022-02-23 00:00:00','','Medicine',150.00,'Income','Cash',88,169),(312,'2022-02-23 00:00:00','','Consultation',100.00,'Income','Cash',88,169),(313,'2022-02-24 00:00:00','','Medicine',150.00,'Income','Cash',84,170),(314,'2022-02-24 00:00:00','','Consultation',100.00,'Income','Cash',84,170),(315,'2022-02-24 00:00:00','','Medicine',120.00,'Income','Cash',91,171),(316,'2022-02-24 00:00:00','','Consultation',100.00,'Income','Cash',91,171),(317,'2022-02-24 00:00:00','','Medicine',120.00,'Income','Cash',101,172),(318,'2022-02-24 00:00:00','','Consultation',100.00,'Income','Cash',101,172),(319,'2022-02-24 00:00:00','Medicine','Medicine - Aspire',-673.00,'Expense','Bank',NULL,NULL),(320,'2022-02-26 00:00:00','','Medicine',100.00,'Income','Cash',102,173),(321,'2022-02-26 00:00:00','','Consultation',100.00,'Income','Cash',102,173),(322,'2022-02-26 00:00:00','','Medicine',120.00,'Income','Cash',67,174),(323,'2022-02-26 00:00:00','','Consultation',100.00,'Income','Cash',67,174),(324,'2022-02-26 00:00:00','','Medicine',50.00,'Income','Cash',86,175),(325,'2022-02-27 00:00:00','100 - Test Patient','Medicine',0.00,'Income','Cash',3,176),(326,'2022-02-27 00:00:00','100 - Test Patient','Consultation',0.00,'Income','Cash',3,176),(327,'2022-02-28 00:00:00','Medicine','Medicine',100.00,'Income','Cash',NULL,NULL),(328,'2022-02-28 00:00:00','Rent - Feb','Rent',-8000.00,'Expense','Cash',NULL,NULL),(336,'2022-02-28 00:00:00','','Medicine',70.00,'Income','Cash',27,181),(330,'2022-02-28 00:00:00','','Medicine',150.00,'Income','Cash',34,178),(331,'2022-02-28 00:00:00','','Consultation',100.00,'Income','Cash',34,178),(332,'2022-02-28 00:00:00','','Medicine',150.00,'Income','Cash',35,179),(333,'2022-02-28 00:00:00','','Consultation',100.00,'Income','Cash',35,179),(334,'2022-02-28 00:00:00','','Medicine',160.00,'Income','Cash',89,180),(335,'2022-02-28 00:00:00','','Consultation',100.00,'Income','Cash',89,180),(337,'2022-03-01 00:00:00','MEDICINE MARCH','Medicine - Ayush',-517.00,'Expense','Bank',NULL,NULL),(338,'2022-03-01 00:00:00','','Medicine',70.00,'Income','Cash',50,182),(339,'2022-03-01 00:00:00','','Consultation',100.00,'Income','Cash',50,182),(340,'2022-02-28 00:00:00','Income adjust - Feb','Income Adjust',523.00,'Income','Cash',NULL,NULL),(341,'2022-03-01 00:00:00','','Medicine',120.00,'Income','Cash',99,183),(342,'2022-03-01 00:00:00','','Medicine',150.00,'Income','Cash',103,184),(343,'2022-03-01 00:00:00','','Consultation',100.00,'Income','Cash',103,184),(344,'2022-01-22 00:00:00','','Medicine',380.00,'Income','Cash',35,186),(345,'2022-01-22 00:00:00','','Consultation',100.00,'Income','Cash',35,186),(346,'2022-03-02 00:00:00','','Medicine',290.00,'Income','Cash',35,187),(347,'2022-03-03 00:00:00','','Medicine',120.00,'Income','Cash',86,188),(348,'2022-03-03 00:00:00','','Consultation',100.00,'Income','Cash',86,188),(349,'2022-03-04 00:00:00','','Medicine',100.00,'Income','Cash',105,189),(350,'2022-03-04 00:00:00','','Consultation',100.00,'Income','Cash',105,189),(351,'2022-03-07 00:00:00','','Medicine',50.00,'Income','Cash',107,190),(352,'2022-03-07 00:00:00','','Consultation',100.00,'Income','Cash',107,190),(353,'2022-03-07 00:00:00','','Medicine',50.00,'Income','Cash',106,191),(354,'2022-03-07 00:00:00','','Consultation',100.00,'Income','Cash',106,191),(355,'2022-03-07 00:00:00','','Medicine',60.00,'Income','Cash',100,192),(356,'2022-03-07 00:00:00','','Medicine',210.00,'Income','Cash',27,193),(357,'2022-03-07 00:00:00','','Consultation',100.00,'Income','Cash',27,193),(358,'2022-03-08 00:00:00','','Medicine',70.00,'Income','Cash',104,194),(359,'2022-03-08 00:00:00','','Consultation',200.00,'Income','Cash',104,194),(360,'2022-03-07 00:00:00','','Medicine',150.00,'Income','Cash',70,195),(361,'2022-03-07 00:00:00','','Consultation',100.00,'Income','Cash',70,195),(362,'2022-03-07 00:00:00','','Medicine',150.00,'Income','Cash',109,196),(363,'2022-03-07 00:00:00','','Consultation',100.00,'Income','Cash',109,196),(364,'2022-03-05 00:00:00','','Medicine',200.00,'Income','Cash',74,197),(365,'2022-03-05 00:00:00','','Consultation',100.00,'Income','Cash',74,197),(366,'2022-03-08 00:00:00','','Medicine',80.00,'Income','Cash',110,198),(367,'2022-03-08 00:00:00','','Consultation',100.00,'Income','Cash',110,198),(368,'2022-03-08 00:00:00','','Medicine',270.00,'Income','Cash',103,199),(369,'2022-03-08 00:00:00','','Consultation',100.00,'Income','Cash',103,199),(370,'2022-03-08 00:00:00','','Medicine',40.00,'Income','Cash',67,200),(371,'2022-03-08 00:00:00','','Medicine',100.00,'Income','Cash',102,201),(372,'2022-03-08 00:00:00','','Consultation',100.00,'Income','Cash',102,201),(373,'2022-03-09 00:00:00','','Medicine',100.00,'Income','Cash',91,202),(374,'2022-03-09 00:00:00','','Consultation',100.00,'Income','Cash',91,202),(378,'2022-03-09 00:00:00','','Consultation',300.00,'Income','Bank',63,204),(377,'2022-03-09 00:00:00','','Medicine',960.00,'Income','Bank',63,204),(379,'2022-03-09 00:00:00','','Medicine',60.00,'Income','Cash',111,205),(380,'2022-03-09 00:00:00','','Medicine',60.00,'Income','Cash',110,206),(381,'2022-03-09 00:00:00','','Medicine',180.00,'Income','Cash',108,207),(382,'2022-03-09 00:00:00','','Consultation',100.00,'Income','Cash',108,207),(383,'2022-03-09 00:00:00','','Medicine',120.00,'Income','Cash',50,208),(384,'2022-03-10 00:00:00','Medicine','Medicine - Aspire',-1448.00,'Expense','Bank',NULL,NULL),(385,'2022-03-05 00:00:00','Paste','Product',90.00,'Income','Cash',NULL,NULL),(386,'2022-03-05 00:00:00','','Medicine',100.00,'Income','Bank',14,209),(387,'2022-03-05 00:00:00','','Consultation',100.00,'Income','Bank',14,209),(388,'2022-03-08 00:00:00','Mathrubhumi magazine','Other',-340.00,'Expense','Bank',NULL,NULL),(389,'2022-03-12 00:00:00','','Medicine',100.00,'Income','Cash',67,210),(390,'2022-03-12 00:00:00','','Consultation',100.00,'Income','Cash',67,210),(391,'2022-03-11 00:00:00','','Medicine',250.00,'Income','Cash',110,211),(392,'2022-03-11 00:00:00','','Consultation',100.00,'Income','Cash',110,211),(393,'2022-03-11 00:00:00','','Medicine',30.00,'Income','Cash',108,212),(394,'2022-03-11 00:00:00','MEDICINE','OUTSIDE PRESCRIPTION',0.00,'Expense','Cash',NULL,NULL),(395,'2022-03-11 00:00:00','Outside Prescription','Medicine',120.00,'Income','Cash',NULL,NULL),(396,'2022-03-14 00:00:00','','Medicine',70.00,'Income','Cash',100,213),(397,'2022-03-14 00:00:00','','Medicine',150.00,'Income','Cash',112,214),(398,'2022-03-14 00:00:00','','Consultation',100.00,'Income','Cash',112,214),(399,'2022-03-14 00:00:00','HAIR GEL','Medicine',170.00,'Income','Bank',NULL,NULL),(400,'2022-03-14 00:00:00','','Medicine',120.00,'Income','Cash',113,215),(401,'2022-03-14 00:00:00','','Consultation',100.00,'Income','Cash',113,215),(402,'2022-03-14 00:00:00','','Medicine',150.00,'Income','Cash',35,216),(403,'2022-03-14 00:00:00','','Consultation',100.00,'Income','Cash',35,216),(404,'2022-03-14 00:00:00','','Medicine',120.00,'Income','Cash',34,217),(405,'2022-03-14 00:00:00','','Consultation',100.00,'Income','Cash',34,217),(406,'2022-03-14 00:00:00','','Medicine',120.00,'Income','Cash',80,218),(407,'2022-03-14 00:00:00','','Consultation',100.00,'Income','Cash',80,218),(408,'2022-03-15 00:00:00','','Medicine',120.00,'Income','Cash',49,219),(409,'2022-03-15 00:00:00','','Consultation',100.00,'Income','Cash',49,219),(410,'2022-03-15 00:00:00','','Medicine',50.00,'Income','Cash',114,220),(411,'2022-03-15 00:00:00','','Consultation',100.00,'Income','Cash',114,220),(412,'2022-03-15 00:00:00','','Medicine',120.00,'Income','Cash',115,221),(413,'2022-03-15 00:00:00','','Consultation',100.00,'Income','Cash',115,221),(414,'2022-03-16 00:00:00','','Medicine',100.00,'Income','Cash',117,222),(415,'2022-03-16 00:00:00','','Consultation',100.00,'Income','Cash',117,222),(416,'2022-03-16 00:00:00','','Medicine',150.00,'Income','Cash',118,223),(417,'2022-03-16 00:00:00','','Consultation',100.00,'Income','Cash',118,223),(418,'2022-03-15 00:00:00','','Medicine',50.00,'Income','Cash',116,224),(419,'2022-03-15 00:00:00','','Consultation',100.00,'Income','Cash',116,224),(431,'2022-03-15 00:00:00','','Medicine',60.00,'Income','Cash',50,232),(421,'2022-03-14 00:00:00','','Consultation',1.00,'Income','Cash',104,226),(422,'2022-03-17 00:00:00','','Medicine',120.00,'Income','Cash',119,227),(423,'2022-03-17 00:00:00','','Consultation',100.00,'Income','Cash',119,227),(424,'2022-03-17 00:00:00','','Medicine',50.00,'Income','Cash',96,228),(425,'2022-03-17 00:00:00','','Consultation',100.00,'Income','Cash',96,228),(426,'2022-03-17 00:00:00','','Medicine',50.00,'Income','Cash',94,229),(427,'2022-03-17 00:00:00','','Consultation',50.00,'Income','Cash',94,229),(428,'2022-03-18 00:00:00','','Medicine',120.00,'Income','Cash',108,230),(429,'2022-03-18 00:00:00','','Consultation',100.00,'Income','Cash',108,230),(505,'2022-03-22 00:00:00','','Medicine',120.00,'Income','Cash',83,271),(432,'2022-03-19 00:00:00','','Medicine',100.00,'Income','Cash',120,233),(433,'2022-03-19 00:00:00','','Consultation',100.00,'Income','Cash',120,233),(434,'2022-03-19 00:00:00','','Medicine',50.00,'Income','Cash',116,234),(435,'2022-03-19 00:00:00','','Medicine',210.00,'Income','Cash',19,235),(436,'2022-03-19 00:00:00','','Consultation',100.00,'Income','Cash',19,235),(437,'2022-03-19 00:00:00','','Medicine',170.00,'Income','Cash',89,236),(438,'2022-03-19 00:00:00','','Consultation',100.00,'Income','Cash',89,236),(439,'2022-03-19 00:00:00','SARCREAM','Medicine',60.00,'Income','Cash',NULL,NULL),(440,'2022-03-21 00:00:00','PASTE','Medicine',90.00,'Income','Cash',NULL,NULL),(441,'2022-03-22 00:00:00','','Medicine',150.00,'Income','Cash',102,237),(442,'2022-03-22 00:00:00','','Consultation',100.00,'Income','Cash',102,237),(443,'2022-03-22 00:00:00','','Medicine',100.00,'Income','Cash',67,238),(444,'2022-03-22 00:00:00','','Consultation',100.00,'Income','Cash',67,238),(445,'2022-03-22 00:00:00','','Medicine',150.00,'Income','Cash',121,239),(446,'2022-03-22 00:00:00','','Consultation',100.00,'Income','Cash',121,239),(447,'2022-03-23 00:00:00','','Medicine',100.00,'Income','Cash',122,240),(448,'2022-03-23 00:00:00','','Consultation',100.00,'Income','Cash',122,240),(449,'2022-03-23 00:00:00','','Medicine',100.00,'Income','Cash',123,241),(450,'2022-03-23 00:00:00','','Consultation',100.00,'Income','Cash',123,241),(451,'2022-03-23 00:00:00','','Medicine',150.00,'Income','Cash',112,242),(452,'2022-03-23 00:00:00','','Consultation',100.00,'Income','Cash',112,242),(453,'2022-03-23 00:00:00','','Medicine',120.00,'Income','Cash',70,243),(454,'2022-03-23 00:00:00','','Consultation',100.00,'Income','Cash',70,243),(455,'2022-03-24 00:00:00','','Medicine',80.00,'Income','Cash',120,244),(456,'2022-01-18 00:00:00','','Medicine',120.00,'Income','Cash',18,245),(457,'2022-01-18 00:00:00','','Consultation',100.00,'Income','Cash',18,245),(458,'2022-03-24 00:00:00','','Medicine',50.00,'Income','Cash',18,246),(459,'2022-03-24 00:00:00','','Consultation',100.00,'Income','Cash',18,246),(460,'2022-03-24 00:00:00','CHRYSORBINUM','Medicine',70.00,'Income','Cash',NULL,NULL),(461,'2022-03-24 00:00:00','MEDICINE','Medicine - Aspire',-687.00,'Expense','Bank',NULL,NULL),(462,'2022-03-25 00:00:00','HAIR GEL','Medicine',170.00,'Income','Cash',NULL,NULL),(463,'2022-03-26 00:00:00','DILUTION','Medicine',100.00,'Income','Cash',NULL,NULL),(464,'2022-03-26 00:00:00','ARNICA OIL','Medicine',350.00,'Income','Cash',NULL,NULL),(465,'2022-03-26 00:00:00','ARNICA SHAMPOO','Medicine',120.00,'Income','Cash',NULL,NULL),(483,'2022-03-25 00:00:00','','Consultation',100.00,'Income','Cash',124,256),(482,'2022-03-25 00:00:00','','Medicine',150.00,'Income','Cash',124,256),(471,'2022-03-25 00:00:00','','Consultation',100.00,'Income','Cash',50,249),(470,'2022-03-25 00:00:00','','Medicine',120.00,'Income','Cash',50,249),(472,'2022-03-25 00:00:00','','Medicine',130.00,'Income','Cash',105,251),(473,'2022-03-25 00:00:00','','Consultation',100.00,'Income','Cash',105,251),(474,'2022-03-25 00:00:00','','Medicine',120.00,'Income','Cash',65,252),(475,'2022-03-25 00:00:00','','Consultation',100.00,'Income','Cash',65,252),(476,'2022-03-25 00:00:00','','Medicine',120.00,'Income','Cash',31,253),(477,'2022-03-25 00:00:00','','Consultation',80.00,'Income','Cash',31,253),(478,'2022-03-26 00:00:00','','Medicine',150.00,'Income','Cash',109,254),(479,'2022-03-26 00:00:00','','Consultation',100.00,'Income','Cash',109,254),(480,'2022-03-26 00:00:00','','Medicine',80.00,'Income','Cash',117,255),(481,'2022-03-26 00:00:00','','Consultation',100.00,'Income','Cash',117,255),(484,'2022-03-30 00:00:00','','Medicine',120.00,'Income','Cash',117,257),(485,'2022-03-30 00:00:00','','Medicine',150.00,'Income','Cash',67,258),(501,'2022-03-30 00:00:00','','Consultation',100.00,'Income','Cash',125,267),(500,'2022-03-30 00:00:00','','Medicine',50.00,'Income','Cash',125,267),(499,'2022-03-30 00:00:00','','Consultation',100.00,'Income','Cash',114,266),(498,'2022-03-30 00:00:00','','Medicine',80.00,'Income','Cash',114,266),(490,'2022-03-30 00:00:00','','Medicine',100.00,'Income','Cash',115,261),(491,'2022-03-30 00:00:00','','Consultation',100.00,'Income','Cash',115,261),(492,'2022-03-30 00:00:00','','Medicine',100.00,'Income','Cash',126,262),(493,'2022-03-30 00:00:00','','Consultation',100.00,'Income','Cash',126,262),(494,'2022-03-30 00:00:00','','Medicine',120.00,'Income','Cash',15,263),(495,'2022-03-30 00:00:00','','Consultation',100.00,'Income','Cash',15,263),(496,'2022-03-30 00:00:00','','Medicine',150.00,'Income','Cash',121,264),(497,'2022-03-30 00:00:00','','Medicine',150.00,'Income','Cash',102,265),(502,'2022-03-31 00:00:00','','Medicine',140.00,'Income','Cash',127,268),(503,'2022-03-31 00:00:00','','Consultation',100.00,'Income','Cash',127,268),(506,'2022-03-22 00:00:00','','Consultation',100.00,'Income','Cash',83,271),(507,'2022-03-25 00:00:00','','Medicine',60.00,'Income','Cash',49,272),(508,'2022-03-31 00:00:00','MEDICINE','Medicine - Aspire',-903.00,'Expense','Bank',NULL,NULL),(509,'2022-03-31 00:00:00','Rent - March','Rent',-8000.00,'Expense','Cash',NULL,NULL),(510,'2022-03-16 00:00:00','','Medicine',60.00,'Income','Cash',27,273),(511,'2022-03-31 00:00:00','Income adjust','Income Adjust',59.00,'Income','Cash',NULL,NULL),(512,'2022-03-31 00:00:00','Savings - March','Savings',-5495.00,'Expense','Cash',NULL,NULL),(513,'2022-04-01 00:00:00','','Medicine',170.00,'Income','Cash',35,274),(514,'2022-04-01 00:00:00','','Consultation',100.00,'Income','Cash',35,274),(515,'2022-04-01 00:00:00','','Medicine',50.00,'Income','Cash',112,275),(516,'2022-04-01 00:00:00','','Medicine',50.00,'Income','Cash',128,276),(517,'2022-04-01 00:00:00','','Consultation',100.00,'Income','Cash',128,276),(518,'2022-04-02 00:00:00','','Medicine',80.00,'Income','Cash',97,277),(519,'2022-04-02 00:00:00','','Consultation',100.00,'Income','Cash',97,277),(520,'2022-04-02 00:00:00','BOTTLES','Bottles - Blue Plast',-146.00,'Expense','Bank',NULL,NULL),(521,'2022-04-02 00:00:00','SYRUP','Product',60.00,'Income','Cash',NULL,NULL),(522,'2022-04-02 00:00:00','','Medicine',250.00,'Income','Cash',129,278),(523,'2022-04-02 00:00:00','','Consultation',100.00,'Income','Cash',129,278),(524,'2022-04-04 00:00:00','','Medicine',100.00,'Income','Cash',80,279),(525,'2022-04-04 00:00:00','','Consultation',100.00,'Income','Cash',80,279),(526,'2022-04-04 00:00:00','','Medicine',100.00,'Income','Cash',104,280),(527,'2022-04-05 00:00:00','','Medicine',150.00,'Income','Cash',130,281),(528,'2022-04-05 00:00:00','','Consultation',100.00,'Income','Cash',130,281),(529,'2022-04-05 00:00:00','','Medicine',100.00,'Income','Bank',6,282),(530,'2022-04-05 00:00:00','','Consultation',100.00,'Income','Bank',6,282),(531,'2022-04-06 00:00:00','MAJEED - GOAT RID WORM','Product',60.00,'Income','Cash',NULL,NULL),(532,'2022-04-07 00:00:00','','Medicine',120.00,'Income','Cash',131,283),(533,'2022-04-07 00:00:00','','Consultation',100.00,'Income','Cash',131,283),(534,'2022-04-06 00:00:00','','Medicine',150.00,'Income','Cash',86,284),(535,'2022-04-06 00:00:00','','Consultation',100.00,'Income','Cash',86,284),(539,'2022-04-07 00:00:00','','Medicine',120.00,'Income','Cash',102,287),(538,'2022-04-07 00:00:00','','Medicine',120.00,'Income','Cash',50,286),(540,'2022-04-07 00:00:00','CURRENT BILL - Apr','Electricity Bill',-776.00,'Expense','Bank',NULL,NULL),(541,'2022-04-07 00:00:00','MEDICINE (798.00)','Medicine - Aspire',-1.00,'Expense','Bank',NULL,NULL),(542,'2022-04-09 00:00:00','','Medicine',120.00,'Income','Bank',132,288),(543,'2022-04-09 00:00:00','','Consultation',100.00,'Income','Bank',132,288),(544,'2022-04-12 00:00:00','','Medicine',120.00,'Income','Cash',114,289),(545,'2022-04-12 00:00:00','','Consultation',100.00,'Income','Cash',114,289),(546,'2022-04-12 00:00:00','','Medicine',60.00,'Income','Cash',116,290),(547,'2022-04-12 00:00:00','','Consultation',100.00,'Income','Cash',116,290),(548,'2022-04-12 00:00:00','','Medicine',100.00,'Income','Cash',80,291),(549,'2022-04-11 00:00:00','Majeed - Shampoo','Product',300.00,'Income','Bank',NULL,NULL),(550,'2022-04-14 00:00:00','','Medicine',170.00,'Income','Cash',109,292),(551,'2022-04-14 00:00:00','','Consultation',100.00,'Income','Cash',109,292),(552,'2022-04-14 00:00:00','','Medicine',120.00,'Income','Cash',134,293),(553,'2022-04-14 00:00:00','','Consultation',100.00,'Income','Cash',134,293),(554,'2022-04-14 00:00:00','','Medicine',100.00,'Income','Cash',135,294),(555,'2022-04-14 00:00:00','','Consultation',100.00,'Income','Cash',135,294),(556,'2022-04-14 00:00:00','','Medicine',80.00,'Income','Cash',136,295),(557,'2022-04-14 00:00:00','','Consultation',100.00,'Income','Cash',136,295),(558,'2022-04-14 00:00:00','','Medicine',50.00,'Income','Cash',133,296),(559,'2022-04-14 00:00:00','','Consultation',100.00,'Income','Cash',133,296),(560,'2022-04-18 00:00:00','BORO ALLEN  CREAM','Medicine',50.00,'Income','Bank',NULL,NULL),(561,'2022-04-19 00:00:00','BORO ALLEN CREAM','Medicine',55.00,'Income','Cash',NULL,NULL),(562,'2022-04-18 00:00:00','','Medicine',150.00,'Income','Bank',137,297),(563,'2022-04-18 00:00:00','','Consultation',100.00,'Income','Bank',137,297),(564,'2022-04-16 00:00:00','','Medicine',120.00,'Income','Cash',102,298),(565,'2022-04-16 00:00:00','','Consultation',100.00,'Income','Cash',102,298),(571,'2022-04-16 00:00:00','','Consultation',100.00,'Income','Cash',67,301),(570,'2022-04-16 00:00:00','','Medicine',200.00,'Income','Cash',67,301),(568,'2022-04-16 00:00:00','','Medicine',120.00,'Income','Cash',138,300),(569,'2022-04-16 00:00:00','','Consultation',100.00,'Income','Cash',138,300),(572,'2022-04-16 00:00:00','','Medicine',20.00,'Income','Cash',136,302),(573,'2022-04-18 00:00:00','','Medicine',60.00,'Income','Cash',136,303),(574,'2022-04-19 00:00:00','','Medicine',150.00,'Income','Cash',84,304),(575,'2022-04-19 00:00:00','','Consultation',100.00,'Income','Cash',84,304),(579,'2022-04-15 00:00:00','','Consultation',100.00,'Income','Cash',129,306),(578,'2022-04-15 00:00:00','','Medicine',50.00,'Income','Cash',129,306),(580,'2022-04-19 00:00:00','','Medicine',100.00,'Income','Cash',139,307),(581,'2022-04-19 00:00:00','','Consultation',100.00,'Income','Cash',139,307),(582,'2022-04-20 00:00:00','','Medicine',100.00,'Income','Cash',140,308),(583,'2022-04-20 00:00:00','','Consultation',100.00,'Income','Cash',140,308),(584,'2022-04-20 00:00:00','PROSTANUM','Medicine',260.00,'Income','Cash',NULL,NULL),(585,'2022-04-22 00:00:00','CINALMIX','Medicine',60.00,'Income','Cash',NULL,NULL),(586,'2022-04-21 00:00:00','MEDICINE (4273.00)','Medicine - Aspire',-1.00,'Expense','Bank',NULL,NULL),(587,'2022-04-20 00:00:00','','Medicine',180.00,'Income','Cash',35,309),(588,'2022-04-20 00:00:00','','Consultation',100.00,'Income','Cash',35,309),(598,'2022-04-22 00:00:00','','Consultation',100.00,'Income','Cash',143,314),(597,'2022-04-22 00:00:00','','Medicine',50.00,'Income','Cash',143,314),(596,'2022-04-22 00:00:00','','Consultation',100.00,'Income','Cash',49,313),(595,'2022-04-22 00:00:00','','Medicine',50.00,'Income','Cash',49,313),(593,'2022-04-22 00:00:00','','Medicine',150.00,'Income','Cash',50,312),(594,'2022-04-22 00:00:00','','Consultation',100.00,'Income','Cash',50,312),(599,'2022-04-22 00:00:00','','Medicine',30.00,'Income','Cash',139,315),(600,'2022-04-23 00:00:00','','Medicine',100.00,'Income','Cash',144,316),(601,'2022-04-23 00:00:00','','Consultation',100.00,'Income','Cash',144,316),(602,'2022-04-23 00:00:00','','Medicine',60.00,'Income','Cash',140,317),(603,'2022-04-27 00:00:00','','Medicine',60.00,'Income','Cash',140,318),(604,'2022-04-23 00:00:00','','Medicine',130.00,'Income','Cash',105,319),(605,'2022-04-23 00:00:00','','Consultation',100.00,'Income','Cash',105,319),(606,'2022-04-25 00:00:00','','Medicine',50.00,'Income','Cash',86,320),(607,'2022-04-27 00:00:00','','Medicine',120.00,'Income','Cash',130,321),(608,'2022-04-27 00:00:00','','Consultation',100.00,'Income','Cash',130,321),(609,'2022-04-29 00:00:00','','Medicine',120.00,'Income','Cash',145,322),(610,'2022-04-29 00:00:00','','Consultation',100.00,'Income','Cash',145,322),(611,'2022-04-29 00:00:00','MEDICINE','RID WORM',165.00,'Income','Bank',NULL,NULL),(612,'2022-04-30 00:00:00','OIL','B AND T',320.00,'Income','Bank',NULL,NULL),(613,'2022-04-28 00:00:00','Medicine (1633.00)','Medicine - Aspire',-1.00,'Expense','Bank',NULL,NULL),(614,'2022-04-30 00:00:00','','Medicine',250.00,'Income','Cash',129,323),(615,'2022-04-30 00:00:00','','Consultation',100.00,'Income','Cash',129,323),(616,'2022-04-13 00:00:00','Boronip','Product',90.00,'Income','Cash',NULL,NULL),(618,'2022-04-20 00:00:00','','Medicine',120.00,'Income','Cash',34,325),(619,'2022-04-20 00:00:00','','Consultation',100.00,'Income','Cash',34,325),(620,'2022-04-21 00:00:00','','Medicine',100.00,'Income','Cash',141,326),(621,'2022-04-21 00:00:00','','Consultation',50.00,'Income','Cash',141,326),(622,'2022-04-21 00:00:00','','Medicine',100.00,'Income','Cash',142,327),(623,'2022-04-21 00:00:00','','Consultation',50.00,'Income','Cash',142,327),(624,'2022-04-30 00:00:00','April Rent','Rent',-8000.00,'Expense','Cash',NULL,NULL),(625,'2022-04-30 00:00:00','Savings - April','Savings',-1315.00,'Expense','Cash',NULL,NULL),(626,'2022-05-09 00:00:00','','Medicine',150.00,'Income','Cash',146,328),(627,'2022-05-09 00:00:00','','Consultation',100.00,'Income','Cash',146,328),(628,'2022-05-02 00:00:00','','Medicine',120.00,'Income','Cash',86,329),(629,'2022-05-02 00:00:00','','Consultation',100.00,'Income','Cash',86,329),(630,'2022-05-02 00:00:00','','Medicine',50.00,'Income','Cash',50,330),(631,'2022-05-02 00:00:00','','Consultation',100.00,'Income','Cash',50,330),(632,'2022-05-09 00:00:00','','Medicine',170.00,'Income','Cash',147,331),(633,'2022-05-09 00:00:00','','Consultation',100.00,'Income','Cash',147,331),(634,'2022-05-09 00:00:00','','Medicine',200.00,'Income','Cash',140,332),(635,'2022-05-09 00:00:00','','Consultation',100.00,'Income','Cash',140,332),(636,'2022-05-09 00:00:00','','Medicine',120.00,'Income','Cash',144,333),(637,'2022-05-09 00:00:00','','Consultation',100.00,'Income','Cash',144,333),(638,'2022-05-09 00:00:00','','Medicine',220.00,'Income','Cash',35,334),(639,'2022-05-09 00:00:00','','Consultation',100.00,'Income','Cash',35,334),(640,'2022-05-10 00:00:00','','Medicine',150.00,'Income','Cash',148,335),(641,'2022-05-10 00:00:00','','Consultation',100.00,'Income','Cash',148,335),(642,'2022-05-10 00:00:00','','Medicine',300.00,'Income','Cash',84,336),(643,'2022-05-10 00:00:00','','Consultation',100.00,'Income','Cash',84,336),(644,'2022-05-10 00:00:00','','Medicine',50.00,'Income','Cash',102,337),(645,'2022-05-10 00:00:00','','Medicine',150.00,'Income','Cash',67,338),(646,'2022-05-10 00:00:00','','Consultation',100.00,'Income','Cash',67,338),(647,'2022-05-12 00:00:00','','Medicine',50.00,'Income','Cash',141,339),(648,'2022-05-12 00:00:00','','Consultation',100.00,'Income','Cash',141,339),(649,'2022-05-12 00:00:00','','Medicine',50.00,'Income','Cash',142,340),(650,'2022-05-12 00:00:00','','Consultation',100.00,'Income','Cash',142,340),(651,'2022-05-11 00:00:00','','Medicine',30.00,'Income','Cash',67,341),(652,'2022-05-11 00:00:00','','Medicine',300.00,'Income','Bank',149,342),(653,'2022-05-11 00:00:00','','Consultation',100.00,'Income','Bank',149,342),(654,'2022-05-12 00:00:00','','Medicine',120.00,'Income','Cash',150,343),(655,'2022-05-12 00:00:00','','Consultation',100.00,'Income','Cash',150,343),(656,'2022-05-13 00:00:00','','Medicine',120.00,'Income','Cash',151,344),(657,'2022-05-13 00:00:00','','Consultation',100.00,'Income','Cash',151,344),(658,'2022-05-13 00:00:00','','Medicine',150.00,'Income','Cash',121,345),(659,'2022-05-13 00:00:00','','Consultation',100.00,'Income','Cash',121,345),(660,'2022-05-13 00:00:00','100 - Test Patient','Consultation',0.00,'Income','Cash',3,346),(661,'2022-05-13 00:00:00','','Medicine',30.00,'Income','Cash',146,347),(663,'2022-05-14 00:00:00','','Medicine',400.00,'Income','Cash',66,349),(664,'2022-05-14 00:00:00','','Consultation',200.00,'Income','Cash',66,349),(665,'2022-05-13 00:00:00','','Medicine',200.00,'Income','Cash',152,350),(666,'2022-05-13 00:00:00','','Consultation',100.00,'Income','Cash',152,350),(667,'2022-05-14 00:00:00','','Medicine',220.00,'Income','Cash',153,351),(668,'2022-05-14 00:00:00','','Consultation',100.00,'Income','Cash',153,351),(669,'2022-05-14 00:00:00','','Medicine',100.00,'Income','Cash',112,352),(670,'2022-05-14 00:00:00','','Consultation',100.00,'Income','Cash',112,352),(671,'2022-05-16 00:00:00','','Medicine',150.00,'Income','Cash',155,353),(672,'2022-05-16 00:00:00','','Consultation',100.00,'Income','Cash',155,353),(673,'2022-05-16 00:00:00','','Medicine',150.00,'Income','Cash',156,354),(674,'2022-05-16 00:00:00','','Consultation',100.00,'Income','Cash',156,354),(675,'2022-05-12 00:00:00','MEDICINE','Medicine - Aspire',-1804.00,'Expense','Bank',NULL,NULL),(679,'2022-05-17 00:00:00','','Consultation',100.00,'Income','Cash',157,356),(678,'2022-05-17 00:00:00','','Medicine',100.00,'Income','Cash',157,356),(680,'2022-05-17 00:00:00','','Medicine',150.00,'Income','Cash',50,357),(681,'2022-05-17 00:00:00','','Consultation',100.00,'Income','Cash',50,357),(682,'2022-05-17 00:00:00','','Medicine',150.00,'Income','Cash',105,358),(683,'2022-05-17 00:00:00','','Consultation',100.00,'Income','Cash',105,358),(684,'2022-05-17 00:00:00','MEDICINE','ARNICA SHAMPOO',120.00,'Income','Cash',NULL,NULL),(685,'2022-05-17 00:00:00','','Medicine',150.00,'Income','Cash',47,359),(686,'2022-05-17 00:00:00','','Consultation',100.00,'Income','Cash',47,359),(687,'2022-05-17 00:00:00','','Medicine',50.00,'Income','Cash',49,360),(688,'2022-05-17 00:00:00','','Consultation',100.00,'Income','Cash',49,360),(689,'2022-05-17 00:00:00','','Consultation',100.00,'Income','Cash',134,361),(690,'2022-05-17 00:00:00','','Medicine',120.00,'Income','Cash',158,362),(691,'2022-05-17 00:00:00','','Consultation',100.00,'Income','Cash',158,362),(692,'2022-05-18 00:00:00','','Medicine',150.00,'Income','Cash',130,363),(693,'2022-05-18 00:00:00','','Consultation',100.00,'Income','Cash',130,363),(697,'2022-05-18 00:00:00','','Consultation',100.00,'Income','Cash',145,365),(696,'2022-05-18 00:00:00','','Medicine',120.00,'Income','Cash',145,365),(698,'2022-05-19 00:00:00','','Medicine',80.00,'Income','Cash',159,366),(699,'2022-05-19 00:00:00','','Consultation',100.00,'Income','Cash',159,366),(700,'2022-05-19 00:00:00','','Medicine',100.00,'Income','Cash',41,367),(701,'2022-05-19 00:00:00','','Consultation',100.00,'Income','Cash',41,367),(702,'2022-05-19 00:00:00','','Medicine',110.00,'Income','Cash',67,368),(703,'2022-05-19 00:00:00','','Medicine',200.00,'Income','Cash',160,369),(704,'2022-05-19 00:00:00','','Consultation',100.00,'Income','Cash',160,369),(705,'2022-05-19 00:00:00','MEDICINE','SARCREAM',60.00,'Income','Cash',NULL,NULL),(706,'2022-05-20 00:00:00','','Medicine',150.00,'Income','Cash',144,370),(707,'2022-05-20 00:00:00','','Consultation',100.00,'Income','Cash',144,370),(716,'2022-05-20 00:00:00','','Consultation',100.00,'Income','Cash',163,375),(715,'2022-05-20 00:00:00','','Medicine',100.00,'Income','Cash',163,375),(710,'2022-05-20 00:00:00','','Medicine',100.00,'Income','Cash',162,372),(711,'2022-05-20 00:00:00','','Consultation',100.00,'Income','Cash',162,372),(712,'2022-05-20 00:00:00','','Medicine',60.00,'Income','Cash',112,373),(713,'2022-05-20 00:00:00','','Medicine',400.00,'Income','Cash',140,374),(714,'2022-05-20 00:00:00','','Consultation',100.00,'Income','Cash',140,374),(717,'2022-05-23 00:00:00','','Medicine',100.00,'Income','Cash',67,376),(718,'2022-05-23 00:00:00','','Medicine',80.00,'Income','Cash',50,377),(719,'2022-05-23 00:00:00','','Medicine',120.00,'Income','Cash',150,378),(720,'2022-05-23 00:00:00','','Consultation',100.00,'Income','Cash',150,378),(721,'2022-05-24 00:00:00','','Medicine',120.00,'Income','Cash',164,379),(722,'2022-05-24 00:00:00','','Consultation',100.00,'Income','Cash',164,379),(723,'2022-05-24 00:00:00','','Medicine',100.00,'Income','Cash',165,380),(724,'2022-05-24 00:00:00','','Consultation',100.00,'Income','Cash',165,380),(725,'2022-05-24 00:00:00','','Medicine',100.00,'Income','Cash',166,381),(726,'2022-05-24 00:00:00','','Consultation',100.00,'Income','Cash',166,381),(727,'2022-05-24 00:00:00','','Medicine',80.00,'Income','Cash',167,382),(728,'2022-05-24 00:00:00','','Consultation',100.00,'Income','Cash',167,382),(729,'2022-05-25 00:00:00','','Medicine',180.00,'Income','Cash',168,383),(730,'2022-05-25 00:00:00','','Consultation',100.00,'Income','Cash',168,383),(731,'2022-05-26 00:00:00','','Medicine',100.00,'Income','Cash',151,384),(732,'2022-05-26 00:00:00','','Consultation',100.00,'Income','Cash',151,384),(733,'2022-05-26 00:00:00','MEDICINE','Medicine - Aspire',-500.00,'Expense','Bank',NULL,NULL),(734,'2022-05-26 00:00:00','','Medicine',300.00,'Income','Cash',135,385),(735,'2022-05-26 00:00:00','','Consultation',100.00,'Income','Cash',135,385),(736,'2022-05-26 00:00:00','','Medicine',100.00,'Income','Cash',94,386),(737,'2022-05-26 00:00:00','','Consultation',100.00,'Income','Cash',94,386),(738,'2022-05-26 00:00:00','','Medicine',80.00,'Income','Cash',96,387),(739,'2022-05-26 00:00:00','','Consultation',100.00,'Income','Cash',96,387),(740,'2022-05-27 00:00:00','','Medicine',150.00,'Income','Cash',169,388),(741,'2022-05-27 00:00:00','','Consultation',100.00,'Income','Cash',169,388),(742,'2022-05-27 00:00:00','','Medicine',80.00,'Income','Cash',171,389),(743,'2022-05-27 00:00:00','','Consultation',100.00,'Income','Cash',171,389),(744,'2022-05-27 00:00:00','','Medicine',150.00,'Income','Cash',86,390),(745,'2022-05-27 00:00:00','','Consultation',100.00,'Income','Cash',86,390),(746,'2022-05-27 00:00:00','','Medicine',220.00,'Income','Cash',35,391),(747,'2022-05-27 00:00:00','','Consultation',100.00,'Income','Cash',35,391),(748,'2022-05-02 00:00:00','Medicine','Product',200.00,'Income','Cash',NULL,NULL),(749,'2022-05-28 00:00:00','','Medicine',100.00,'Income','Cash',172,392),(750,'2022-05-28 00:00:00','','Consultation',100.00,'Income','Cash',172,392),(751,'2022-05-28 00:00:00','','Medicine',100.00,'Income','Cash',173,393),(752,'2022-05-28 00:00:00','','Consultation',100.00,'Income','Cash',173,393),(753,'2022-05-30 00:00:00','','Medicine',100.00,'Income','Cash',159,394),(754,'2022-05-30 00:00:00','','Consultation',100.00,'Income','Cash',159,394),(755,'2022-05-30 00:00:00','MEDICINE','SARCREAM',120.00,'Income','Cash',NULL,NULL),(756,'2022-05-30 00:00:00','','Medicine',170.00,'Income','Cash',40,395),(757,'2022-05-30 00:00:00','','Consultation',100.00,'Income','Cash',40,395),(758,'2022-05-30 00:00:00','','Medicine',120.00,'Income','Cash',174,396),(759,'2022-05-30 00:00:00','','Consultation',100.00,'Income','Cash',174,396),(760,'2022-05-30 00:00:00','','Medicine',30.00,'Income','Cash',167,397),(761,'2022-05-31 00:00:00','','Medicine',120.00,'Income','Cash',175,398),(762,'2022-05-31 00:00:00','','Consultation',100.00,'Income','Cash',175,398),(763,'2022-05-31 00:00:00','','Medicine',100.00,'Income','Cash',67,399),(764,'2022-05-31 00:00:00','','Consultation',100.00,'Income','Cash',67,399),(771,'2022-05-31 00:00:00','','Medicine',100.00,'Income','Cash',176,403),(772,'2022-05-31 00:00:00','','Consultation',100.00,'Income','Cash',176,403),(773,'2022-06-01 00:00:00','','Medicine',100.00,'Income','Cash',177,404),(769,'2022-05-31 00:00:00','','Medicine',120.00,'Income','Cash',135,402),(770,'2022-05-31 00:00:00','','Consultation',100.00,'Income','Cash',135,402),(774,'2022-06-01 00:00:00','','Consultation',100.00,'Income','Cash',177,404),(775,'2022-06-01 00:00:00','','Medicine',100.00,'Income','Cash',178,405),(776,'2022-06-01 00:00:00','','Consultation',100.00,'Income','Cash',178,405),(777,'2022-06-02 00:00:00','','Medicine',120.00,'Income','Cash',179,406),(778,'2022-06-02 00:00:00','','Consultation',100.00,'Income','Cash',179,406),(779,'2022-05-31 00:00:00','Adjust','Income Adjust',740.00,'Income','Cash',NULL,NULL),(780,'2022-05-31 00:00:00','May Rent','Rent',-8000.00,'Expense','Cash',NULL,NULL),(781,'2022-05-31 00:00:00','May Savings','Savings',-6296.00,'Expense','Cash',NULL,NULL),(782,'2022-06-04 00:00:00','','Medicine',300.00,'Income','Cash',180,407),(783,'2022-06-04 00:00:00','','Consultation',100.00,'Income','Cash',180,407),(784,'2022-06-04 00:00:00','','Medicine',120.00,'Income','Cash',181,408),(785,'2022-06-04 00:00:00','','Consultation',100.00,'Income','Cash',181,408),(786,'2022-06-06 00:00:00','','Medicine',100.00,'Income','Cash',50,409),(787,'2022-06-06 00:00:00','','Consultation',100.00,'Income','Cash',50,409),(788,'2022-06-06 00:00:00','','Medicine',100.00,'Income','Cash',49,410),(789,'2022-06-06 00:00:00','','Consultation',100.00,'Income','Cash',49,410),(790,'2022-06-06 00:00:00','','Medicine',100.00,'Income','Cash',160,411),(791,'2022-06-06 00:00:00','','Consultation',100.00,'Income','Cash',160,411),(792,'2022-06-07 00:00:00','','Medicine',120.00,'Income','Cash',183,412),(793,'2022-06-07 00:00:00','','Consultation',100.00,'Income','Cash',183,412),(794,'2022-06-07 00:00:00','','Medicine',120.00,'Income','Cash',182,413),(795,'2022-06-07 00:00:00','','Consultation',100.00,'Income','Cash',182,413),(796,'2022-06-07 00:00:00','MEDICINE','PROSTANUM DROPS',260.00,'Income','Cash',NULL,NULL),(800,'2022-06-07 00:00:00','','Consultation',100.00,'Income','Bank',149,415),(799,'2022-06-07 00:00:00','','Medicine',300.00,'Income','Bank',149,415),(801,'2022-06-07 00:00:00','','Medicine',180.00,'Income','Cash',168,416),(802,'2022-06-07 00:00:00','','Consultation',100.00,'Income','Cash',168,416),(803,'2022-06-08 00:00:00','','Medicine',100.00,'Income','Cash',184,417),(804,'2022-06-08 00:00:00','','Consultation',100.00,'Income','Cash',184,417),(805,'2022-06-08 00:00:00','','Medicine',100.00,'Income','Cash',185,418),(806,'2022-06-08 00:00:00','','Consultation',100.00,'Income','Cash',185,418),(807,'2022-06-08 00:00:00','','Medicine',120.00,'Income','Cash',102,419),(808,'2022-06-08 00:00:00','','Consultation',100.00,'Income','Cash',102,419),(809,'2022-06-08 00:00:00','','Medicine',120.00,'Income','Cash',67,420),(810,'2022-06-08 00:00:00','','Consultation',100.00,'Income','Cash',67,420),(811,'2022-06-09 00:00:00','','Medicine',120.00,'Income','Cash',151,421),(812,'2022-06-09 00:00:00','','Consultation',100.00,'Income','Cash',151,421),(813,'2022-06-09 00:00:00','','Medicine',50.00,'Income','Cash',185,422),(814,'2022-06-09 00:00:00','','Medicine',150.00,'Income','Cash',150,423),(815,'2022-06-09 00:00:00','','Consultation',100.00,'Income','Cash',150,423),(816,'2022-06-10 00:00:00','','Medicine',130.00,'Income','Cash',169,424),(817,'2022-06-10 00:00:00','','Consultation',100.00,'Income','Cash',169,424),(818,'2022-06-10 00:00:00','','Medicine',220.00,'Income','Cash',186,425),(819,'2022-06-10 00:00:00','','Consultation',100.00,'Income','Cash',186,425),(828,'2022-06-10 00:00:00','','Medicine',50.00,'Income','Bank',27,430),(825,'2022-06-10 00:00:00','','Consultation',100.00,'Income','Bank',18,428),(824,'2022-06-10 00:00:00','','Medicine',50.00,'Income','Bank',18,428),(829,'2022-06-10 00:00:00','','Consultation',100.00,'Income','Bank',27,430),(830,'2022-06-10 00:00:00','','Medicine',120.00,'Income','Cash',187,431),(831,'2022-06-10 00:00:00','','Consultation',100.00,'Income','Cash',187,431),(832,'2022-06-10 00:00:00','','Medicine',50.00,'Income','Cash',188,432),(833,'2022-06-10 00:00:00','','Consultation',100.00,'Income','Cash',188,432),(834,'2022-06-10 00:00:00','MEDICINE','Medicine - Aspire',-3086.00,'Expense','Bank',NULL,NULL),(835,'2022-06-11 00:00:00','','Medicine',100.00,'Income','Cash',189,433),(836,'2022-06-11 00:00:00','','Consultation',100.00,'Income','Cash',189,433),(837,'2022-06-11 00:00:00','','Medicine',100.00,'Income','Cash',190,434),(838,'2022-06-11 00:00:00','','Consultation',100.00,'Income','Cash',190,434),(839,'2022-06-11 00:00:00','','Medicine',150.00,'Income','Cash',191,435),(840,'2022-06-11 00:00:00','','Consultation',100.00,'Income','Cash',191,435),(841,'2022-06-11 00:00:00','','Medicine',250.00,'Income','Cash',153,436),(842,'2022-06-11 00:00:00','','Consultation',100.00,'Income','Cash',153,436),(843,'2022-06-11 00:00:00','','Medicine',80.00,'Income','Cash',192,437),(844,'2022-06-11 00:00:00','','Consultation',100.00,'Income','Cash',192,437),(845,'2022-06-11 00:00:00','','Medicine',100.00,'Income','Cash',193,438),(846,'2022-06-11 00:00:00','','Consultation',100.00,'Income','Cash',193,438),(847,'2022-06-11 00:00:00','','Medicine',80.00,'Income','Cash',143,439),(848,'2022-06-11 00:00:00','','Consultation',100.00,'Income','Cash',143,439),(863,'2022-06-13 00:00:00','','Consultation',100.00,'Income','Cash',195,447),(862,'2022-06-13 00:00:00','','Medicine',100.00,'Income','Cash',195,447),(851,'2022-06-11 00:00:00','','Medicine',150.00,'Income','Cash',50,441),(852,'2022-06-11 00:00:00','','Medicine',100.00,'Income','Cash',194,442),(853,'2022-06-11 00:00:00','','Consultation',100.00,'Income','Cash',194,442),(854,'2022-06-11 00:00:00','','Medicine',100.00,'Income','Cash',166,443),(855,'2022-06-11 00:00:00','','Consultation',100.00,'Income','Cash',166,443),(864,'2022-06-13 00:00:00','MEDICINE','ARNICA HAIR OIL',130.00,'Income','Cash',NULL,NULL),(858,'2022-06-11 00:00:00','','Medicine',100.00,'Income','Cash',177,445),(859,'2022-06-11 00:00:00','','Consultation',100.00,'Income','Cash',177,445),(860,'2022-06-11 00:00:00','','Medicine',60.00,'Income','Cash',133,446),(861,'2022-06-11 00:00:00','','Consultation',100.00,'Income','Cash',133,446),(865,'2022-06-13 00:00:00','MEDICINE','ARNICA SHAMPOO ALLEN',120.00,'Income','Cash',NULL,NULL),(866,'2022-06-13 00:00:00','','Medicine',150.00,'Income','Cash',117,448),(867,'2022-06-13 00:00:00','','Consultation',100.00,'Income','Cash',117,448),(868,'2022-06-13 00:00:00','MEDICINE','HAIR GRO GEL 3',510.00,'Income','Cash',NULL,NULL),(869,'2022-06-13 00:00:00','','Medicine',100.00,'Income','Cash',114,449),(870,'2022-06-13 00:00:00','','Consultation',100.00,'Income','Cash',114,449),(871,'2022-06-14 00:00:00','','Medicine',30.00,'Income','Cash',189,450),(872,'2022-06-14 00:00:00','MEDICINE','THUJA 1M ',120.00,'Income','Cash',NULL,NULL),(873,'2022-06-14 00:00:00','','Medicine',230.00,'Income','Cash',174,451),(874,'2022-06-14 00:00:00','','Consultation',100.00,'Income','Cash',174,451),(875,'2022-06-14 00:00:00','BOTTLES','Bottles - Blue Plast',-1005.00,'Expense','Bank',NULL,NULL),(876,'2022-06-15 00:00:00','','Medicine',100.00,'Income','Cash',192,452),(877,'2022-06-15 00:00:00','','Medicine',100.00,'Income','Cash',163,453),(878,'2022-06-15 00:00:00','','Consultation',100.00,'Income','Cash',163,453),(879,'2022-06-15 00:00:00','','Medicine',100.00,'Income','Cash',196,454),(880,'2022-06-15 00:00:00','','Consultation',100.00,'Income','Cash',196,454),(881,'2022-06-16 00:00:00','','Medicine',100.00,'Income','Cash',65,455),(882,'2022-06-16 00:00:00','','Consultation',100.00,'Income','Cash',65,455),(883,'2022-06-16 00:00:00','','Medicine',120.00,'Income','Cash',121,456),(884,'2022-06-16 00:00:00','','Consultation',100.00,'Income','Cash',121,456),(885,'2022-06-16 00:00:00','','Medicine',120.00,'Income','Cash',168,457),(886,'2022-06-16 00:00:00','','Medicine',250.00,'Income','Bank',154,458),(887,'2022-06-16 00:00:00','','Consultation',100.00,'Income','Bank',154,458),(888,'2022-06-17 00:00:00','','Medicine',80.00,'Income','Cash',117,459),(889,'2022-06-17 00:00:00','','Medicine',400.00,'Income',NULL,160,460),(890,'2022-06-17 00:00:00','','Consultation',100.00,'Income',NULL,160,460),(891,'2022-06-17 00:00:00','','Medicine',100.00,'Income','Cash',166,461),(892,'2022-06-18 00:00:00','','Medicine',150.00,'Income','Cash',197,462),(893,'2022-06-18 00:00:00','','Consultation',100.00,'Income','Cash',197,462),(894,'2022-06-18 00:00:00','','Medicine',50.00,'Income','Cash',198,463),(895,'2022-06-18 00:00:00','','Consultation',100.00,'Income','Cash',198,463),(896,'2022-06-18 00:00:00','','Medicine',300.00,'Income','Cash',40,465),(897,'2022-06-18 00:00:00','','Consultation',100.00,'Income','Cash',40,465),(898,'2022-06-18 00:00:00','','Medicine',100.00,'Income','Cash',146,466),(899,'2022-06-18 00:00:00','','Consultation',100.00,'Income','Cash',146,466),(900,'2022-06-18 00:00:00','','Medicine',50.00,'Income','Cash',121,467),(901,'2022-06-18 00:00:00','','Medicine',50.00,'Income','Cash',192,468),(902,'2022-06-20 00:00:00','','Medicine',250.00,'Income','Cash',192,469),(907,'2022-06-20 00:00:00','','Consultation',100.00,'Income','Bank',199,472),(906,'2022-06-20 00:00:00','','Medicine',100.00,'Income','Bank',199,472),(905,'2022-06-20 00:00:00','','Medicine',80.00,'Income','Cash',50,471),(908,'2022-06-20 00:00:00','','Medicine',100.00,'Income','Cash',187,473),(909,'2022-06-21 00:00:00','','Medicine',100.00,'Income','Cash',176,474),(910,'2022-06-21 00:00:00','','Consultation',100.00,'Income','Cash',176,474),(911,'2022-06-21 00:00:00','','Medicine',170.00,'Income','Cash',147,475),(912,'2022-06-21 00:00:00','','Consultation',100.00,'Income','Cash',147,475),(916,'2022-06-21 00:00:00','','Consultation',100.00,'Income','Cash',200,477),(915,'2022-06-21 00:00:00','','Medicine',150.00,'Income','Cash',200,477),(917,'2022-06-21 00:00:00','','Medicine',100.00,'Income','Cash',201,478),(918,'2022-06-21 00:00:00','','Consultation',100.00,'Income','Cash',201,478),(919,'2022-06-21 00:00:00','','Medicine',260.00,'Income','Cash',185,479),(920,'2022-06-21 00:00:00','','Consultation',100.00,'Income','Cash',185,479),(921,'2022-06-21 00:00:00','','Medicine',150.00,'Income','Cash',202,480),(922,'2022-06-21 00:00:00','','Consultation',100.00,'Income','Cash',202,480),(923,'2022-06-21 00:00:00','','Medicine',50.00,'Income','Cash',203,481),(924,'2022-06-21 00:00:00','','Consultation',100.00,'Income','Cash',203,481),(925,'2022-06-21 00:00:00','','Medicine',50.00,'Income','Cash',204,482),(926,'2022-06-21 00:00:00','','Consultation',100.00,'Income','Cash',204,482),(930,'2022-06-21 00:00:00','','Consultation',100.00,'Income','Cash',205,484),(929,'2022-06-21 00:00:00','','Medicine',150.00,'Income','Cash',205,484),(931,'2022-06-22 00:00:00','','Medicine',130.00,'Income','Cash',169,485),(932,'2022-06-22 00:00:00','','Consultation',100.00,'Income','Cash',169,485),(933,'2022-06-22 00:00:00','','Medicine',200.00,'Income','Cash',206,486),(934,'2022-06-22 00:00:00','','Consultation',100.00,'Income','Cash',206,486),(935,'2022-06-22 00:00:00','','Medicine',100.00,'Income','Bank',199,487),(936,'2022-06-22 00:00:00','','Consultation',100.00,'Income','Bank',199,487),(937,'2022-06-23 00:00:00','','Medicine',150.00,'Income','Cash',144,488),(938,'2022-06-23 00:00:00','','Consultation',100.00,'Income','Cash',144,488),(939,'2022-06-23 00:00:00','','Medicine',200.00,'Income','Cash',175,489),(940,'2022-06-23 00:00:00','','Consultation',100.00,'Income','Cash',175,489),(941,'2022-06-23 00:00:00','','Medicine',60.00,'Income','Cash',50,490),(942,'2022-06-23 00:00:00','','Medicine',80.00,'Income','Cash',94,491),(943,'2022-06-23 00:00:00','','Consultation',100.00,'Income','Cash',94,491),(944,'2022-06-23 00:00:00','','Medicine',100.00,'Income','Cash',119,492),(945,'2022-06-23 00:00:00','','Consultation',100.00,'Income','Cash',119,492),(946,'2022-06-23 00:00:00','','Medicine',150.00,'Income','Cash',207,493),(947,'2022-06-23 00:00:00','','Consultation',100.00,'Income','Cash',207,493),(948,'2022-06-23 00:00:00','','Medicine',100.00,'Income','Cash',208,494),(949,'2022-06-23 00:00:00','','Consultation',100.00,'Income','Cash',208,494),(952,'2022-06-18 00:00:00','Medicine','Medicine - Aspire',-890.00,'Expense','Bank',NULL,NULL),(953,'2022-06-23 00:00:00','Medicine','Medicine - Aspire',-530.00,'Expense','Bank',NULL,NULL),(954,'2022-06-24 00:00:00','medicine','arnica hair oil',130.00,'Income','Cash',NULL,NULL),(955,'2022-06-24 00:00:00','medicine','wheezal shampoo',100.00,'Income','Cash',NULL,NULL),(956,'2022-06-24 00:00:00','','Medicine',40.00,'Income','Bank',199,496),(957,'2022-06-25 00:00:00','','Medicine',80.00,'Income','Bank',209,497),(958,'2022-06-25 00:00:00','','Consultation',100.00,'Income','Bank',209,497),(959,'2022-06-25 00:00:00','','Medicine',120.00,'Income','Bank',210,498),(960,'2022-06-25 00:00:00','','Consultation',100.00,'Income','Bank',210,498),(961,'2022-06-25 00:00:00','','Medicine',75.00,'Income','Bank',199,499),(962,'2022-06-25 00:00:00','','Medicine',100.00,'Income','Cash',177,500),(963,'2022-06-25 00:00:00','','Consultation',100.00,'Income','Cash',177,500),(964,'2022-06-25 00:00:00','','Medicine',120.00,'Income','Cash',117,501),(965,'2022-06-25 00:00:00','','Consultation',100.00,'Income','Cash',117,501),(966,'2022-06-25 00:00:00','','Medicine',150.00,'Income','Cash',50,502),(967,'2022-06-25 00:00:00','','Medicine',150.00,'Income','Cash',61,503),(968,'2022-06-25 00:00:00','','Consultation',100.00,'Income','Cash',61,503),(969,'2022-06-25 00:00:00','','Medicine',100.00,'Income','Cash',211,504),(970,'2022-06-25 00:00:00','','Consultation',100.00,'Income','Cash',211,504),(971,'2022-06-26 00:00:00','','Medicine',100.00,'Income','Bank',212,505),(972,'2022-06-26 00:00:00','','Consultation',100.00,'Income','Bank',212,505),(973,'2022-06-27 00:00:00','','Medicine',130.00,'Income','Cash',164,506),(974,'2022-06-27 00:00:00','','Consultation',100.00,'Income','Cash',164,506),(975,'2022-06-27 00:00:00','','Medicine',70.00,'Income','Cash',213,507),(976,'2022-06-27 00:00:00','','Consultation',100.00,'Income','Cash',213,507),(977,'2022-06-27 00:00:00','','Medicine',80.00,'Income','Bank',199,508),(978,'2022-06-28 00:00:00','','Medicine',100.00,'Income','Cash',198,509),(979,'2022-06-28 00:00:00','','Consultation',100.00,'Income','Cash',198,509),(980,'2022-06-28 00:00:00','','Medicine',150.00,'Income','Cash',191,510),(981,'2022-06-28 00:00:00','','Consultation',100.00,'Income','Cash',191,510),(982,'2022-06-28 00:00:00','','Medicine',200.00,'Income','Cash',153,511),(983,'2022-06-28 00:00:00','','Consultation',100.00,'Income','Cash',153,511),(984,'2022-06-27 00:00:00','','Medicine',120.00,'Income','Cash',65,512),(986,'2022-06-27 00:00:00','','Medicine',200.00,'Income','Cash',146,514),(987,'2022-06-27 00:00:00','','Consultation',300.00,'Income','Cash',146,514),(988,'2022-06-30 00:00:00','','Medicine',120.00,'Income','Cash',45,515),(989,'2022-06-30 00:00:00','','Consultation',100.00,'Income','Cash',45,515),(990,'2022-01-26 00:00:00','','Medicine',150.00,'Income','Cash',45,516),(991,'2022-01-26 00:00:00','','Consultation',100.00,'Income','Cash',45,516),(992,'2022-07-01 00:00:00','medicine','arnica hair oil',110.00,'Income','Cash',NULL,NULL),(993,'2022-07-01 00:00:00','medicine','Medicine - Aspire',-2923.00,'Expense','Bank',NULL,NULL),(994,'2022-07-01 00:00:00','','Medicine',150.00,'Income','Cash',97,517),(995,'2022-07-01 00:00:00','','Consultation',100.00,'Income','Cash',97,517),(996,'2022-06-30 00:00:00','June rent','Rent',-8000.00,'Expense','Cash',NULL,NULL),(997,'2022-06-30 00:00:00','Adjust','Income Adjust',750.00,'Income','Cash',NULL,NULL),(998,'2022-06-30 00:00:00','June Savings','Savings',-9484.00,'Expense','Cash',NULL,NULL),(999,'2022-07-02 00:00:00','','Medicine',200.00,'Income','Cash',67,518),(1000,'2022-07-02 00:00:00','','Consultation',100.00,'Income','Cash',67,518),(1001,'2022-07-02 00:00:00','','Medicine',200.00,'Income','Cash',151,519),(1002,'2022-07-02 00:00:00','','Consultation',100.00,'Income','Cash',151,519),(1003,'2022-07-02 00:00:00','','Medicine',100.00,'Income','Cash',214,520),(1004,'2022-07-02 00:00:00','','Consultation',100.00,'Income','Cash',214,520),(1005,'2022-07-02 00:00:00','','Medicine',110.00,'Income','Cash',67,521),(1006,'2022-07-02 00:00:00','','Medicine',100.00,'Income','Cash',177,522),(1007,'2022-07-02 00:00:00','','Medicine',100.00,'Income','Cash',102,523),(1008,'2022-07-02 00:00:00','','Consultation',100.00,'Income','Cash',102,523),(1009,'2022-07-02 00:00:00','','Medicine',150.00,'Income','Cash',168,524),(1010,'2022-07-02 00:00:00','','Consultation',100.00,'Income','Cash',168,524),(1011,'2022-07-02 00:00:00','','Medicine',180.00,'Income','Cash',150,525),(1012,'2022-07-02 00:00:00','','Consultation',100.00,'Income','Cash',150,525),(1013,'2022-07-02 00:00:00','','Medicine',100.00,'Income','Cash',215,526),(1014,'2022-07-02 00:00:00','','Consultation',100.00,'Income','Cash',215,526),(1015,'2022-07-02 00:00:00','','Medicine',100.00,'Income','Bank',139,527),(1016,'2022-07-02 00:00:00','','Consultation',100.00,'Income','Bank',139,527),(1017,'2022-07-04 00:00:00','','Medicine',80.00,'Income','Bank',216,528),(1018,'2022-07-04 00:00:00','','Consultation',100.00,'Income','Bank',216,528),(1019,'2022-07-04 00:00:00','','Medicine',200.00,'Income','Cash',197,529),(1020,'2022-07-04 00:00:00','','Consultation',100.00,'Income','Cash',197,529),(1021,'2022-07-04 00:00:00','','Medicine',50.00,'Income','Cash',201,530),(1022,'2022-07-04 00:00:00','','Consultation',100.00,'Income','Cash',201,530),(1023,'2022-07-05 00:00:00','','Medicine',100.00,'Income','Cash',217,531),(1024,'2022-07-05 00:00:00','A2285 - FARZANA','Medicine',150.00,'Income','Cash',187,532),(1025,'2022-07-05 00:00:00','','Medicine',100.00,'Income','Cash',15,533),(1026,'2022-07-05 00:00:00','','Consultation',100.00,'Income','Cash',15,533),(1027,'2022-07-05 00:00:00','','Medicine',100.00,'Income','Cash',19,534),(1028,'2022-07-05 00:00:00','','Consultation',100.00,'Income','Cash',19,534),(1029,'2022-07-06 00:00:00','','Medicine',150.00,'Income','Cash',160,535),(1030,'2022-07-06 00:00:00','','Consultation',100.00,'Income','Cash',160,535),(1031,'2022-07-06 00:00:00','','Medicine',100.00,'Income','Cash',219,536),(1032,'2022-07-06 00:00:00','','Consultation',100.00,'Income','Cash',219,536),(1033,'2022-07-06 00:00:00','','Medicine',210.00,'Income','Cash',130,537),(1034,'2022-07-06 00:00:00','','Consultation',100.00,'Income','Cash',130,537),(1035,'2022-07-06 00:00:00','','Medicine',100.00,'Income','Cash',133,538),(1036,'2022-07-06 00:00:00','','Consultation',100.00,'Income','Cash',133,538),(1043,'2022-07-06 00:00:00','','Consultation',100.00,'Income','Cash',220,542),(1039,'2022-07-06 00:00:00','','Medicine',30.00,'Income','Bank',216,540),(1042,'2022-07-06 00:00:00','','Medicine',250.00,'Income','Cash',220,542),(1044,'2022-07-06 00:00:00','','Medicine',100.00,'Income','Cash',222,543),(1045,'2022-07-06 00:00:00','','Consultation',100.00,'Income','Cash',222,543),(1046,'2022-07-06 00:00:00','','Medicine',100.00,'Income','Cash',221,544),(1047,'2022-07-06 00:00:00','','Consultation',100.00,'Income','Cash',221,544),(1048,'2022-07-06 00:00:00','','Medicine',180.00,'Income','Cash',221,545),(1049,'2022-07-06 00:00:00','','Medicine',120.00,'Income','Bank',199,546),(1265,'2022-07-30 00:00:00','Expense Adjust','Expense Adjust',-475.00,'Expense','Cash',NULL,NULL),(1052,'2022-07-07 00:00:00','','Medicine',100.00,'Income','Cash',184,548),(1053,'2022-07-07 00:00:00','','Consultation',100.00,'Income','Cash',184,548),(1054,'2022-07-07 00:00:00','','Medicine',40.00,'Income','Cash',186,549),(1055,'2022-07-07 00:00:00','','Medicine',150.00,'Income','Cash',48,550),(1056,'2022-07-07 00:00:00','','Consultation',100.00,'Income','Cash',48,550),(1060,'2022-07-08 00:00:00','','Consultation',100.00,'Income','Cash',223,552),(1059,'2022-07-08 00:00:00','','Medicine',100.00,'Income','Cash',223,552),(1061,'2022-07-08 00:00:00','A2103 - SHARAFU','Medicine',100.00,'Income','Bank',6,553),(1062,'2022-07-08 00:00:00','A2103 - SHARAFU','Consultation',100.00,'Income','Bank',6,553),(1063,'2022-07-08 00:00:00','','Medicine',50.00,'Income','Cash',130,554),(1064,'2022-07-08 00:00:00','','Medicine',150.00,'Income','Cash',224,555),(1065,'2022-07-08 00:00:00','','Consultation',100.00,'Income','Cash',224,555),(1066,'2022-07-08 00:00:00','','Medicine',100.00,'Income','Cash',129,556),(1067,'2022-07-08 00:00:00','','Consultation',100.00,'Income','Cash',129,556),(1068,'2022-07-08 00:00:00','','Medicine',100.00,'Income','Cash',96,557),(1069,'2022-07-08 00:00:00','','Consultation',100.00,'Income','Cash',96,557),(1070,'2022-07-09 00:00:00','','Medicine',100.00,'Income','Bank',154,558),(1071,'2022-07-09 00:00:00','','Consultation',100.00,'Income','Bank',154,558),(1072,'2022-07-09 00:00:00','','Medicine',250.00,'Income','Bank',149,559),(1073,'2022-07-09 00:00:00','','Consultation',100.00,'Income','Bank',149,559),(1074,'2022-07-08 00:00:00','sticker','others',-400.00,'Expense','Cash',NULL,NULL),(1075,'2022-07-09 00:00:00','medicines','Medicine - Aspire',-420.00,'Expense','Bank',NULL,NULL),(1076,'2022-07-09 00:00:00','','Medicine',130.00,'Income','Cash',67,560),(1077,'2022-07-12 00:00:00','','Medicine',150.00,'Income','Cash',225,561),(1078,'2022-07-12 00:00:00','','Consultation',100.00,'Income','Cash',225,561),(1101,'2022-07-13 00:00:00','','Consultation',100.00,'Income','Cash',232,575),(1100,'2022-07-13 00:00:00','','Medicine',100.00,'Income','Cash',232,575),(1081,'2022-07-12 00:00:00','','Medicine',250.00,'Income','Cash',226,563),(1082,'2022-07-12 00:00:00','','Consultation',100.00,'Income','Cash',226,563),(1083,'2022-07-12 00:00:00','','Medicine',150.00,'Income','Cash',227,564),(1084,'2022-07-12 00:00:00','','Consultation',100.00,'Income','Cash',227,564),(1085,'2022-07-12 00:00:00','','Medicine',150.00,'Income','Cash',186,565),(1086,'2022-07-12 00:00:00','','Medicine',220.00,'Income','Cash',230,566),(1087,'2022-07-12 00:00:00','','Consultation',100.00,'Income','Cash',230,566),(1088,'2022-07-12 00:00:00','','Medicine',300.00,'Income','Cash',229,567),(1089,'2022-07-12 00:00:00','','Consultation',100.00,'Income','Cash',229,567),(1090,'2022-07-12 00:00:00','','Medicine',190.00,'Income','Cash',133,568),(1099,'2022-07-12 00:00:00','','Medicine',70.00,'Income','Cash',187,574),(1092,'2022-07-12 00:00:00','','Medicine',100.00,'Income','Cash',215,570),(1093,'2022-07-12 00:00:00','','Consultation',100.00,'Income','Cash',215,570),(1102,'2022-07-13 00:00:00','','Medicine',120.00,'Income','Cash',233,576),(1096,'2022-07-12 00:00:00','','Medicine',100.00,'Income','Cash',134,572),(1097,'2022-07-12 00:00:00','','Consultation',100.00,'Income','Cash',134,572),(1242,'2022-07-29 00:00:00','medicines','Medicine - Aspire',-1380.00,'Expense','Bank',NULL,NULL),(1103,'2022-07-13 00:00:00','','Consultation',100.00,'Income','Cash',233,576),(1104,'2022-07-13 00:00:00','','Medicine',200.00,'Income','Cash',234,577),(1105,'2022-07-13 00:00:00','','Consultation',100.00,'Income','Cash',234,577),(1106,'2022-07-13 00:00:00','','Medicine',100.00,'Income','Cash',235,578),(1107,'2022-07-13 00:00:00','','Consultation',100.00,'Income','Cash',235,578),(1108,'2022-07-14 00:00:00','','Medicine',130.00,'Income','Cash',64,579),(1109,'2022-07-14 00:00:00','','Consultation',100.00,'Income','Cash',64,579),(1110,'2022-07-14 00:00:00','','Medicine',100.00,'Income','Cash',65,580),(1111,'2022-07-14 00:00:00','','Consultation',100.00,'Income','Cash',65,580),(1112,'2022-07-14 00:00:00','','Medicine',100.00,'Income','Cash',105,581),(1113,'2022-07-14 00:00:00','','Consultation',100.00,'Income','Cash',105,581),(1114,'2022-07-14 00:00:00','','Medicine',100.00,'Income','Cash',194,582),(1115,'2022-07-14 00:00:00','','Consultation',100.00,'Income','Cash',194,582),(1116,'2022-07-14 00:00:00','','Medicine',150.00,'Income','Cash',237,583),(1117,'2022-07-14 00:00:00','','Consultation',100.00,'Income','Cash',237,583),(1118,'2022-07-14 00:00:00','','Medicine',150.00,'Income','Cash',236,584),(1119,'2022-07-14 00:00:00','','Consultation',100.00,'Income','Cash',236,584),(1120,'2022-07-15 00:00:00','','Medicine',180.00,'Income','Cash',168,585),(1121,'2022-07-15 00:00:00','','Consultation',100.00,'Income','Cash',168,585),(1125,'2022-07-15 00:00:00','','Consultation',100.00,'Income','Cash',186,587),(1124,'2022-07-15 00:00:00','','Medicine',80.00,'Income','Cash',186,587),(1126,'2022-07-16 00:00:00','','Medicine',120.00,'Income','Cash',238,588),(1127,'2022-07-16 00:00:00','','Consultation',100.00,'Income','Cash',238,588),(1128,'2022-07-16 00:00:00','','Medicine',100.00,'Income','Cash',133,589),(1129,'2022-07-16 00:00:00','','Medicine',200.00,'Income','Cash',218,590),(1130,'2022-07-05 00:00:00','','Medicine',50.00,'Income','Cash',218,591),(1131,'2022-07-05 00:00:00','','Consultation',100.00,'Income','Cash',218,591),(1132,'2022-07-18 00:00:00','','Medicine',100.00,'Income','Cash',239,592),(1133,'2022-07-18 00:00:00','','Consultation',100.00,'Income','Cash',239,592),(1134,'2022-07-18 00:00:00','','Medicine',100.00,'Income','Bank',240,593),(1135,'2022-07-18 00:00:00','','Consultation',100.00,'Income','Bank',240,593),(1136,'2022-07-18 00:00:00','','Medicine',100.00,'Income','Bank',216,594),(1137,'2022-07-30 00:00:00','July Rent','Rent',-8000.00,'Expense','Cash',NULL,NULL),(1138,'2022-07-19 00:00:00','','Medicine',100.00,'Income','Cash',122,595),(1139,'2022-07-19 00:00:00','','Consultation',100.00,'Income','Cash',122,595),(1140,'2022-07-19 00:00:00','','Medicine',120.00,'Income','Cash',112,596),(1141,'2022-07-19 00:00:00','','Consultation',100.00,'Income','Cash',112,596),(1142,'2022-07-19 00:00:00','','Medicine',200.00,'Income','Cash',225,597),(1143,'2022-07-20 00:00:00','','Medicine',120.00,'Income','Cash',229,598),(1144,'2022-07-20 00:00:00','MEDICINE','SARCREAM MUBEENA PATIENT',60.00,'Income','Cash',NULL,NULL),(1145,'2022-07-20 00:00:00','','Medicine',120.00,'Income','Bank',241,599),(1146,'2022-07-20 00:00:00','','Consultation',100.00,'Income','Bank',241,599),(1147,'2022-07-20 00:00:00','','Medicine',100.00,'Income','Bank',199,600),(1148,'2022-07-20 00:00:00','','Consultation',100.00,'Income','Bank',199,600),(1149,'2022-07-20 00:00:00','','Medicine',120.00,'Income','Cash',195,601),(1150,'2022-07-20 00:00:00','','Consultation',100.00,'Income','Cash',195,601),(1151,'2022-07-04 00:00:00','','Medicine',180.00,'Income','Cash',40,602),(1163,'2022-07-21 00:00:00','','Medicine',150.00,'Income','Cash',175,610),(1162,'2022-07-21 00:00:00','','Medicine',1.00,'Income','Cash',29,609),(1154,'2022-07-21 00:00:00','','Medicine',130.00,'Income','Cash',242,604),(1155,'2022-07-21 00:00:00','','Consultation',100.00,'Income','Cash',242,604),(1156,'2022-07-21 00:00:00','','Medicine',1.00,'Income','Cash',199,605),(1157,'2022-07-21 00:00:00','','Medicine',150.00,'Income','Cash',243,606),(1158,'2022-07-21 00:00:00','','Consultation',100.00,'Income','Cash',243,606),(1159,'2022-07-21 00:00:00','','Medicine',120.00,'Income','Cash',117,607),(1160,'2022-07-21 00:00:00','','Consultation',100.00,'Income','Cash',117,607),(1161,'2022-07-21 00:00:00','','Consultation',140.00,'Income','Cash',146,608),(1164,'2022-07-21 00:00:00','','Consultation',100.00,'Income','Cash',175,610),(1165,'2022-07-21 00:00:00','','Medicine',100.00,'Income','Cash',187,611),(1166,'2022-07-21 00:00:00','','Consultation',100.00,'Income','Cash',187,611),(1170,'2022-07-21 00:00:00','','Consultation',100.00,'Income','Cash',187,613),(1169,'2022-07-21 00:00:00','','Medicine',100.00,'Income','Cash',187,613),(1171,'2022-07-22 00:00:00','','Medicine',100.00,'Income','Cash',244,614),(1172,'2022-07-22 00:00:00','','Consultation',100.00,'Income','Cash',244,614),(1173,'2022-07-22 00:00:00','','Medicine',200.00,'Income','Cash',245,615),(1174,'2022-07-22 00:00:00','','Consultation',100.00,'Income','Cash',245,615),(1175,'2022-07-22 00:00:00','','Medicine',100.00,'Income','Cash',133,616),(1176,'2022-07-22 00:00:00','','Consultation',100.00,'Income','Cash',133,616),(1177,'2022-07-22 00:00:00','','Medicine',100.00,'Income','Bank',199,617),(1178,'2022-07-22 00:00:00','MEDICINE','CHRYSORBINUM',60.00,'Income','Cash',NULL,NULL),(1179,'2022-07-22 00:00:00','MEDICINE','Medicine - Aspire',-1827.00,'Expense','Bank',NULL,NULL),(1180,'2022-07-23 00:00:00','','Medicine',100.00,'Income','Cash',102,618),(1181,'2022-07-23 00:00:00','','Consultation',100.00,'Income','Cash',102,618),(1187,'2022-07-23 00:00:00','','Consultation',100.00,'Income','Cash',97,621),(1186,'2022-07-23 00:00:00','','Medicine',120.00,'Income','Cash',97,621),(1184,'2022-07-23 00:00:00','','Medicine',200.00,'Income','Cash',67,620),(1185,'2022-07-23 00:00:00','','Consultation',100.00,'Income','Cash',67,620),(1188,'2022-07-16 00:00:00','','Medicine',200.00,'Income','Cash',134,622),(1189,'2022-07-16 00:00:00','','Consultation',100.00,'Income','Cash',134,622),(1190,'2022-07-23 00:00:00','','Medicine',200.00,'Income','Cash',134,623),(1191,'2022-07-23 00:00:00','','Consultation',100.00,'Income','Cash',134,623),(1192,'2022-07-25 00:00:00','','Medicine',100.00,'Income','Cash',246,624),(1193,'2022-07-25 00:00:00','','Consultation',100.00,'Income','Cash',246,624),(1194,'2022-07-25 00:00:00','','Medicine',100.00,'Income','Cash',217,625),(1195,'2022-07-25 00:00:00','','Consultation',100.00,'Income','Cash',217,625),(1196,'2022-07-26 00:00:00','','Medicine',1.00,'Income','Cash',247,626),(1197,'2022-07-26 00:00:00','','Medicine',100.00,'Income','Cash',186,627),(1198,'2022-07-19 00:00:00','','Medicine',120.00,'Income','Cash',248,628),(1199,'2022-07-19 00:00:00','','Consultation',100.00,'Income','Cash',248,628),(1202,'2022-07-26 00:00:00','','Medicine',100.00,'Income','Cash',112,631),(1201,'2022-07-26 00:00:00','','Medicine',120.00,'Income','Cash',122,630),(1203,'2022-07-27 00:00:00','','Medicine',200.00,'Income','Cash',197,632),(1204,'2022-07-27 00:00:00','','Consultation',100.00,'Income','Cash',197,632),(1205,'2022-07-27 00:00:00','','Medicine',280.00,'Income','Cash',168,633),(1206,'2022-07-27 00:00:00','','Medicine',100.00,'Income','Cash',249,634),(1207,'2022-07-27 00:00:00','','Consultation',100.00,'Income','Cash',249,634),(1208,'2022-07-27 00:00:00','','Medicine',120.00,'Income','Cash',250,635),(1209,'2022-07-27 00:00:00','','Consultation',100.00,'Income','Cash',250,635),(1210,'2022-07-27 00:00:00','','Medicine',150.00,'Income','Cash',251,636),(1211,'2022-07-27 00:00:00','','Consultation',100.00,'Income','Cash',251,636),(1212,'2022-07-28 00:00:00','','Medicine',60.00,'Income','Cash',97,637),(1238,'2022-07-28 00:00:00','','Consultation',100.00,'Income','Bank',149,650),(1231,'2022-07-28 00:00:00','','Medicine',100.00,'Income','Cash',141,647),(1232,'2022-07-28 00:00:00','','Consultation',100.00,'Income','Cash',141,647),(1217,'2022-07-28 00:00:00','','Medicine',100.00,'Income','Cash',142,640),(1218,'2022-07-28 00:00:00','','Consultation',100.00,'Income','Cash',142,640),(1219,'2022-07-28 00:00:00','','Medicine',100.00,'Income','Cash',231,641),(1220,'2022-07-28 00:00:00','','Consultation',100.00,'Income','Cash',231,641),(1221,'2022-07-12 00:00:00','','Medicine',150.00,'Income','Cash',228,642),(1222,'2022-07-12 00:00:00','','Consultation',100.00,'Income','Cash',228,642),(1223,'2022-07-28 00:00:00','','Medicine',120.00,'Income','Cash',228,643),(1224,'2022-07-28 00:00:00','','Consultation',100.00,'Income','Cash',228,643),(1225,'2022-07-28 00:00:00','','Medicine',150.00,'Income','Cash',160,644),(1226,'2022-07-28 00:00:00','','Consultation',100.00,'Income','Cash',160,644),(1227,'2022-07-28 00:00:00','','Medicine',130.00,'Income','Cash',227,645),(1228,'2022-07-28 00:00:00','','Consultation',100.00,'Income','Cash',227,645),(1229,'2022-07-28 00:00:00','','Medicine',100.00,'Income','Cash',252,646),(1230,'2022-07-28 00:00:00','','Consultation',100.00,'Income','Cash',252,646),(1237,'2022-07-28 00:00:00','','Medicine',70.00,'Income','Bank',149,650),(1240,'2022-07-28 00:00:00','','Consultation',100.00,'Income','Bank',154,651),(1239,'2022-07-28 00:00:00','','Medicine',100.00,'Income','Bank',154,651),(1241,'2022-07-28 00:00:00','Fever kit - Ihsan & Irfan','Medicine',480.00,'Income','Bank',NULL,NULL),(1243,'2022-07-29 00:00:00','','Medicine',70.00,'Income','Cash',251,652),(1244,'2022-07-29 00:00:00','','Medicine',100.00,'Income','Cash',254,653),(1245,'2022-07-29 00:00:00','','Consultation',100.00,'Income','Cash',254,653),(1246,'2022-07-29 00:00:00','','Medicine',100.00,'Income','Cash',253,654),(1247,'2022-07-29 00:00:00','','Consultation',100.00,'Income','Cash',253,654),(1248,'2022-07-29 00:00:00','','Medicine',100.00,'Income','Cash',255,655),(1249,'2022-07-29 00:00:00','','Consultation',100.00,'Income','Cash',255,655),(1258,'2022-07-30 00:00:00','','Medicine',150.00,'Income','Cash',61,661),(1257,'2022-07-30 00:00:00','','Consultation',100.00,'Income','Bank',199,660),(1252,'2022-07-30 00:00:00','','Medicine',220.00,'Income','Bank',240,657),(1256,'2022-07-30 00:00:00','','Medicine',20.00,'Income','Bank',199,660),(1254,'2022-07-30 00:00:00','','Medicine',150.00,'Income','Cash',117,659),(1255,'2022-07-30 00:00:00','','Consultation',100.00,'Income','Cash',117,659),(1259,'2022-07-30 00:00:00','','Consultation',100.00,'Income','Cash',61,661),(1260,'2022-07-30 00:00:00','','Medicine',100.00,'Income','Cash',133,662),(1261,'2022-07-30 00:00:00','','Medicine',1.00,'Income','Cash',254,663),(1262,'2022-07-30 00:00:00','','Medicine',1.00,'Income','Cash',253,664),(1263,'2022-07-30 00:00:00','Cleaning','Cleaning',-100.00,'Expense','Cash',NULL,NULL),(1264,'2022-07-30 00:00:00','Income Adjust','Income Adjust',0.00,'Income','Cash',NULL,NULL),(1266,'2022-07-30 00:00:00','July Savings','Savings',-10580.00,'Expense','Cash',NULL,NULL),(1267,'2022-08-01 00:00:00','medicine','mufeeda',-400.00,'Expense','Bank',NULL,NULL),(1268,'2022-08-01 00:00:00','','Medicine',150.00,'Income','Cash',256,665),(1269,'2022-08-01 00:00:00','','Consultation',100.00,'Income','Cash',256,665),(1270,'2022-08-01 00:00:00','','Medicine',150.00,'Income','Cash',257,666),(1271,'2022-08-01 00:00:00','','Consultation',100.00,'Income','Cash',257,666),(1272,'2022-08-02 00:00:00','','Medicine',100.00,'Income','Cash',258,667),(1273,'2022-08-02 00:00:00','','Consultation',100.00,'Income','Cash',258,667),(1274,'2022-08-03 00:00:00','','Medicine',200.00,'Income','Bank',97,668),(1275,'2022-08-03 00:00:00','','Consultation',100.00,'Income','Bank',97,668),(1276,'2022-08-03 00:00:00','','Medicine',80.00,'Income','Bank',216,669),(1277,'2022-08-03 00:00:00','','Consultation',100.00,'Income','Bank',216,669),(1278,'2022-08-05 00:00:00','medicine','Medicine - Aspire',-723.00,'Expense','Bank',NULL,NULL),(1281,'2022-08-05 00:00:00','','Medicine',150.00,'Income','Cash',243,672),(1280,'2022-08-05 00:00:00','','Medicine',160.00,'Income','Cash',67,671),(1282,'2022-08-05 00:00:00','','Consultation',100.00,'Income','Cash',243,672),(1286,'2022-08-13 00:00:00','','Consultation',100.00,'Income','Cash',186,674),(1285,'2022-08-13 00:00:00','','Medicine',180.00,'Income','Cash',186,674),(1287,'2022-08-13 00:00:00','','Medicine',130.00,'Income','Cash',259,675),(1288,'2022-08-13 00:00:00','','Consultation',100.00,'Income','Cash',259,675),(1289,'2022-08-13 00:00:00','','Medicine',200.00,'Income','Cash',168,676),(1290,'2022-08-13 00:00:00','','Consultation',100.00,'Income','Cash',168,676),(1291,'2022-08-13 00:00:00','','Medicine',100.00,'Income','Cash',260,677),(1292,'2022-08-13 00:00:00','','Consultation',100.00,'Income','Cash',260,677),(1293,'2022-08-13 00:00:00','','Medicine',150.00,'Income','Bank',199,678),(1294,'2022-08-13 00:00:00','','Consultation',100.00,'Income','Bank',199,678),(1299,'2022-08-15 00:00:00','','Consultation',100.00,'Income','Cash',257,680),(1298,'2022-08-15 00:00:00','','Medicine',150.00,'Income','Cash',257,680),(1297,'2022-08-13 00:00:00','MEDICINE','SARCREAM',60.00,'Income','Bank',NULL,NULL),(1300,'2022-08-15 00:00:00','','Medicine',150.00,'Income','Cash',139,681),(1301,'2022-08-15 00:00:00','','Consultation',50.00,'Income','Cash',139,681),(1302,'2022-08-15 00:00:00','','Medicine',100.00,'Income','Cash',261,682),(1303,'2022-08-15 00:00:00','','Consultation',100.00,'Income','Cash',261,682),(1304,'2022-08-15 00:00:00','BOTTLES','Bottles - Blue Plast',-409.00,'Expense','Bank',NULL,NULL),(1305,'2022-08-12 00:00:00','CURRENT','Electricity Bill',-991.00,'Expense','Bank',NULL,NULL),(1306,'2022-08-11 00:00:00','MEDICINE','Medicine - Aspire',-406.00,'Expense','Bank',NULL,NULL),(1307,'2022-08-16 00:00:00','','Medicine',120.00,'Income','Cash',262,683),(1308,'2022-08-16 00:00:00','','Consultation',100.00,'Income','Cash',262,683),(1309,'2022-08-16 00:00:00','','Medicine',200.00,'Income','Cash',175,684),(1310,'2022-08-16 00:00:00','','Consultation',100.00,'Income','Cash',175,684),(1311,'2022-08-16 00:00:00','','Medicine',100.00,'Income','Cash',213,685),(1312,'2022-08-16 00:00:00','','Consultation',100.00,'Income','Cash',213,685),(1313,'2022-08-17 00:00:00','','Medicine',120.00,'Income','Cash',192,686),(1314,'2022-08-17 00:00:00','','Consultation',100.00,'Income','Cash',192,686),(1315,'2022-08-17 00:00:00','','Medicine',120.00,'Income','Cash',263,687),(1316,'2022-08-17 00:00:00','','Consultation',100.00,'Income','Cash',263,687),(1317,'2022-08-17 00:00:00','','Medicine',120.00,'Income','Cash',192,688),(1318,'2022-08-17 00:00:00','','Consultation',100.00,'Income','Cash',192,688),(1319,'2022-08-18 00:00:00','','Medicine',240.00,'Income','Cash',264,689),(1320,'2022-08-18 00:00:00','','Consultation',200.00,'Income','Cash',264,689),(1321,'2022-08-18 00:00:00','','Medicine',120.00,'Income','Cash',262,690),(1322,'2022-08-18 00:00:00','','Medicine',130.00,'Income','Cash',238,691),(1323,'2022-08-18 00:00:00','','Consultation',100.00,'Income','Cash',238,691),(1324,'2022-08-18 00:00:00','','Medicine',120.00,'Income','Bank',198,692),(1325,'2022-08-18 00:00:00','','Consultation',100.00,'Income','Bank',198,692),(1326,'2022-08-18 00:00:00','','Medicine',130.00,'Income','Cash',169,693),(1327,'2022-08-18 00:00:00','','Consultation',100.00,'Income','Cash',169,693),(1333,'2022-08-18 00:00:00','','Consultation',100.00,'Income','Cash',253,696),(1332,'2022-08-18 00:00:00','','Medicine',120.00,'Income','Cash',253,696),(1330,'2022-08-18 00:00:00','','Medicine',150.00,'Income','Cash',256,695),(1331,'2022-08-18 00:00:00','','Consultation',100.00,'Income','Cash',256,695),(1334,'2022-08-18 00:00:00','','Medicine',100.00,'Income','Cash',266,697),(1335,'2022-08-18 00:00:00','','Consultation',100.00,'Income','Cash',266,697),(1336,'2022-08-18 00:00:00','','Medicine',400.00,'Income','Bank',265,698),(1337,'2022-08-18 00:00:00','','Consultation',100.00,'Income','Bank',265,698),(1338,'2022-08-18 00:00:00','','Medicine',400.00,'Income','Cash',265,699),(1339,'2022-08-18 00:00:00','','Consultation',100.00,'Income','Cash',265,699),(1340,'2022-08-19 00:00:00','MEDICINE','Medicine - Aspire',-619.00,'Expense','Bank',NULL,NULL),(1341,'2022-08-19 00:00:00','','Medicine',200.00,'Income','Cash',178,700),(1342,'2022-08-19 00:00:00','','Consultation',100.00,'Income','Cash',178,700),(1343,'2022-08-19 00:00:00','','Medicine',70.00,'Income','Cash',263,701),(1344,'2022-08-31 00:00:00','Aug Rent','Rent',-8000.00,'Expense','Cash',NULL,NULL),(1345,'2022-08-20 00:00:00','','Medicine',50.00,'Income','Cash',209,702),(1346,'2022-08-20 00:00:00','','Consultation',100.00,'Income','Cash',209,702),(1347,'2022-08-20 00:00:00','','Medicine',100.00,'Income','Cash',210,703),(1348,'2022-08-20 00:00:00','','Consultation',100.00,'Income','Cash',210,703),(1349,'2022-08-20 00:00:00','','Medicine',120.00,'Income','Cash',117,704),(1350,'2022-08-20 00:00:00','','Consultation',100.00,'Income','Cash',117,704),(1351,'2022-08-20 00:00:00','','Medicine',100.00,'Income','Cash',61,705),(1352,'2022-08-20 00:00:00','','Medicine',30.00,'Income','Cash',264,706),(1353,'2022-08-20 00:00:00','','Medicine',10.00,'Income','Cash',264,707),(1354,'2022-08-22 00:00:00','','Medicine',130.00,'Income','Cash',195,708),(1355,'2022-08-22 00:00:00','','Consultation',100.00,'Income','Cash',195,708),(1356,'2022-08-22 00:00:00','','Medicine',270.00,'Income','Cash',267,709),(1357,'2022-08-22 00:00:00','','Consultation',100.00,'Income','Cash',267,709),(1358,'2022-08-22 00:00:00','','Medicine',120.00,'Income','Cash',268,710),(1359,'2022-08-22 00:00:00','','Consultation',100.00,'Income','Cash',268,710),(1360,'2022-08-23 00:00:00','','Medicine',500.00,'Income','Cash',269,711),(1361,'2022-08-23 00:00:00','','Consultation',100.00,'Income','Cash',269,711),(1362,'2022-08-23 00:00:00','','Medicine',100.00,'Income','Cash',270,712),(1363,'2022-08-23 00:00:00','','Consultation',100.00,'Income','Cash',270,712),(1364,'2022-08-23 00:00:00','','Medicine',70.00,'Income','Cash',256,713),(1365,'2022-08-23 00:00:00','','Medicine',100.00,'Income','Cash',271,714),(1366,'2022-08-23 00:00:00','','Consultation',100.00,'Income','Cash',271,714),(1367,'2022-08-24 00:00:00','','Medicine',220.00,'Income','Cash',117,715),(1368,'2022-08-24 00:00:00','','Medicine',120.00,'Income','Cash',272,716),(1369,'2022-08-24 00:00:00','','Consultation',100.00,'Income','Cash',272,716),(1370,'2022-08-24 00:00:00','','Medicine',200.00,'Income','Cash',228,717),(1371,'2022-08-24 00:00:00','','Consultation',100.00,'Income','Cash',228,717),(1372,'2022-08-24 00:00:00','','Medicine',200.00,'Income','Cash',227,718),(1373,'2022-08-24 00:00:00','','Consultation',100.00,'Income','Cash',227,718),(1374,'2022-08-25 00:00:00','','Medicine',170.00,'Income','Bank',147,719),(1375,'2022-08-25 00:00:00','','Consultation',100.00,'Income','Bank',147,719),(1381,'2022-08-26 00:00:00','','Medicine',100.00,'Income',NULL,64,723),(1380,'2022-08-25 00:00:00','','Medicine',1.00,'Income','Cash',270,722),(1378,'2022-08-25 00:00:00','','Medicine',80.00,'Income','Cash',187,721),(1379,'2022-08-25 00:00:00','','Consultation',100.00,'Income','Cash',187,721),(1382,'2022-08-26 00:00:00','','Consultation',100.00,'Income',NULL,64,723),(1383,'2022-08-26 00:00:00','','Medicine',385.00,'Income','Cash',67,724),(1384,'2022-08-26 00:00:00','','Consultation',100.00,'Income','Cash',67,724),(1385,'2022-08-26 00:00:00','','Medicine',120.00,'Income','Cash',102,725),(1386,'2022-08-26 00:00:00','','Consultation',100.00,'Income','Cash',102,725),(1387,'2022-08-26 00:00:00','','Medicine',220.00,'Income','Cash',102,726),(1388,'2022-08-26 00:00:00','','Consultation',100.00,'Income','Cash',102,726),(1389,'2022-08-26 00:00:00','','Medicine',120.00,'Income','Cash',124,727),(1390,'2022-08-26 00:00:00','','Consultation',100.00,'Income','Cash',124,727),(1394,'2022-08-26 00:00:00','','Consultation',100.00,'Income','Cash',65,729),(1393,'2022-08-26 00:00:00','','Medicine',120.00,'Income','Cash',65,729),(1395,'2022-08-26 00:00:00','MEDICINE','Medicine - Aspire',-961.00,'Expense','Bank',NULL,NULL),(1396,'2022-08-27 00:00:00','','Medicine',40.00,'Income','Cash',272,730),(1397,'2022-08-27 00:00:00','','Medicine',30.00,'Income','Cash',257,731),(1398,'2022-08-27 00:00:00','','Medicine',100.00,'Income','Cash',270,732),(1399,'2022-08-27 00:00:00','','Medicine',100.00,'Income','Cash',253,733),(1400,'2022-08-27 00:00:00','','Consultation',100.00,'Income','Cash',253,733),(1401,'2022-08-27 00:00:00','','Medicine',100.00,'Income','Bank',107,734),(1402,'2022-08-27 00:00:00','','Consultation',100.00,'Income','Bank',107,734),(1406,'2022-08-29 00:00:00','','Consultation',100.00,'Income','Cash',186,736),(1405,'2022-08-29 00:00:00','','Medicine',180.00,'Income','Cash',186,736),(1407,'2022-08-29 00:00:00','','Medicine',100.00,'Income','Cash',273,737),(1408,'2022-08-29 00:00:00','','Consultation',100.00,'Income','Cash',273,737),(1409,'2022-08-29 00:00:00','','Medicine',100.00,'Income','Cash',274,738),(1410,'2022-08-29 00:00:00','','Consultation',100.00,'Income','Cash',274,738),(1411,'2022-08-22 00:00:00','','Medicine',100.00,'Income','Cash',274,739),(1412,'2022-08-22 00:00:00','','Consultation',100.00,'Income','Cash',274,739),(1413,'2022-08-29 00:00:00','','Medicine',120.00,'Income','Cash',194,740),(1414,'2022-08-29 00:00:00','','Consultation',100.00,'Income','Cash',194,740),(1415,'2022-08-29 00:00:00','','Medicine',100.00,'Income','Cash',105,741),(1416,'2022-08-29 00:00:00','','Consultation',100.00,'Income','Cash',105,741),(1417,'2022-08-29 00:00:00','','Medicine',120.00,'Income','Cash',275,742),(1418,'2022-08-29 00:00:00','','Consultation',100.00,'Income','Cash',275,742),(1419,'2022-08-29 00:00:00','','Medicine',120.00,'Income','Cash',220,743),(1420,'2022-08-29 00:00:00','','Consultation',100.00,'Income','Cash',220,743),(1421,'2022-08-29 00:00:00','','Medicine',180.00,'Income','Cash',97,744),(1422,'2022-08-29 00:00:00','','Consultation',100.00,'Income','Cash',97,744),(1423,'2022-08-29 00:00:00','','Medicine',150.00,'Income','Cash',271,745),(1424,'2022-08-29 00:00:00','','Medicine',120.00,'Income','Cash',249,749),(1425,'2022-08-29 00:00:00','','Consultation',100.00,'Income','Cash',249,749),(1426,'2022-08-30 00:00:00','','Medicine',100.00,'Income','Cash',243,750),(1427,'2022-08-30 00:00:00','','Consultation',100.00,'Income','Cash',243,750),(1428,'2022-08-30 00:00:00','','Medicine',1.00,'Income','Cash',271,751),(1429,'2022-08-30 00:00:00','','Medicine',1.00,'Income','Cash',253,752),(1430,'2022-08-30 00:00:00','','Medicine',100.00,'Income','Cash',266,753),(1431,'2022-08-31 00:00:00','','Medicine',150.00,'Income','Cash',210,754),(1432,'2022-08-31 00:00:00','','Consultation',100.00,'Income','Cash',210,754),(1433,'2022-08-31 00:00:00','','Medicine',120.00,'Income','Cash',258,755),(1434,'2022-08-31 00:00:00','','Consultation',100.00,'Income','Cash',258,755),(1435,'2022-08-31 00:00:00','','Medicine',150.00,'Income','Cash',276,756),(1436,'2022-08-31 00:00:00','','Consultation',100.00,'Income','Cash',276,756),(1437,'2022-08-31 00:00:00','','Medicine',130.00,'Income','Cash',277,757),(1438,'2022-08-31 00:00:00','','Consultation',100.00,'Income','Cash',277,757),(1439,'2022-08-31 00:00:00','Expense Adjust','Expense Adjust',-298.00,'Expense','Cash',NULL,NULL),(1440,'2022-08-31 00:00:00','Aug Savings','Savings',-5381.00,'Expense','Cash',NULL,NULL);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank`
--

DROP TABLE IF EXISTS `bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(200) DEFAULT NULL,
  `IsCash` tinyint DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank`
--

LOCK TABLES `bank` WRITE;
/*!40000 ALTER TABLE `bank` DISABLE KEYS */;
INSERT INTO `bank` VALUES (1,'Cash In Hand',1);
/*!40000 ALTER TABLE `bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `center`
--

DROP TABLE IF EXISTS `center`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `center` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Desc` varchar(255) DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `Phone` varchar(45) DEFAULT NULL,
  `RegNo` varchar(45) DEFAULT NULL,
  `AddressMal` varchar(255) DEFAULT NULL,
  `LocationMal` varchar(255) DEFAULT NULL,
  `NameMal` varchar(255) DEFAULT NULL,
  `ReceiptNo` int DEFAULT NULL,
  `MedExpiryDays` int DEFAULT NULL,
  `MedThresholdCount` int DEFAULT NULL,
  `ValidTill` varchar(255) DEFAULT NULL,
  `TodayAPI` varchar(255) DEFAULT NULL,
  `DescMal` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `center`
--

LOCK TABLES `center` WRITE;
/*!40000 ALTER TABLE `center` DISABLE KEYS */;
INSERT INTO `center` VALUES (1,'Olive','Changaramkulam','Homoeo Care','Aynichodu','8086 075 075','','ചങ്ങരംകുളം','അയനിച്ചോട്','ഒലീവ്',35,30,30,'CuHhjCUrT9WwmUSDMJ5652XBNNbxxagHgz1W7Kr+ygH01Gp3xQRheymkuQkf4mcXtUe5ziRgJboPaF6auldAhARTw5WUfPGE3p4M3JXHRFqPstAEXFwfbLgQNUWulwLR','M4WACIaCf7QEGXsI95eAQgz6+/h/bYVsRbSxw+d+UK0Ub6KpyV9tVjNRX6xaNLjXFfTeIUM6D46JZGwbFLGAn6tzmWrAxj8F+hjFqwkBnlVX+pouQn5KQvZj6/sp3TZV','ഹോമിയോ കെയർ');
/*!40000 ALTER TABLE `center` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diagnosis`
--

DROP TABLE IF EXISTS `diagnosis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diagnosis` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diagnosis`
--

LOCK TABLES `diagnosis` WRITE;
/*!40000 ALTER TABLE `diagnosis` DISABLE KEYS */;
/*!40000 ALTER TABLE `diagnosis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipment` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `eno` varchar(45) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `name_lower` varchar(200) DEFAULT NULL,
  `stock` int DEFAULT NULL,
  `damage` int DEFAULT NULL,
  `inuse` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment`
--

LOCK TABLES `equipment` WRITE;
/*!40000 ALTER TABLE `equipment` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipmentdispose`
--

DROP TABLE IF EXISTS `equipmentdispose`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipmentdispose` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `EquipmentId` int NOT NULL,
  `Eno` varchar(45) DEFAULT NULL,
  `Name` varchar(200) DEFAULT NULL,
  `Desc` varchar(200) DEFAULT NULL,
  `Qty` int DEFAULT NULL,
  `TxnDate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipmentdispose`
--

LOCK TABLES `equipmentdispose` WRITE;
/*!40000 ALTER TABLE `equipmentdispose` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipmentdispose` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipmenttracker`
--

DROP TABLE IF EXISTS `equipmenttracker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipmenttracker` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `EquipmentId` int NOT NULL,
  `patientname` varchar(200) DEFAULT NULL,
  `pno` varchar(45) DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `outdate` datetime DEFAULT NULL,
  `indate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipmenttracker`
--

LOCK TABLES `equipmenttracker` WRITE;
/*!40000 ALTER TABLE `equipmenttracker` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipmenttracker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expensetype`
--

DROP TABLE IF EXISTS `expensetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expensetype` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ExpenseType` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expensetype`
--

LOCK TABLES `expensetype` WRITE;
/*!40000 ALTER TABLE `expensetype` DISABLE KEYS */;
INSERT INTO `expensetype` VALUES (1,'Rent'),(2,'Electricity Bill'),(3,'Cleaning'),(4,'Bottles - Blue Plast'),(5,'Medicine - Janatha'),(6,'Medicine - Hearing Pharma'),(8,'Medicine - Ayush'),(9,'Medicine - Aspire'),(10,'Savings'),(11,'Donation'),(12,'Other'),(13,'Other delete'),(14,'Expense Adjust');
/*!40000 ALTER TABLE `expensetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `holiday`
--

DROP TABLE IF EXISTS `holiday`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `holiday` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `year` int NOT NULL,
  `month` int NOT NULL,
  `count` int NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `holiday`
--

LOCK TABLES `holiday` WRITE;
/*!40000 ALTER TABLE `holiday` DISABLE KEYS */;
INSERT INTO `holiday` VALUES (1,2022,2,1),(2,2022,3,2),(3,2022,5,5),(4,2022,7,1),(5,2022,8,7);
/*!40000 ALTER TABLE `holiday` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homecareplan`
--

DROP TABLE IF EXISTS `homecareplan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homecareplan` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Pno` varchar(45) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Type` varchar(45) DEFAULT NULL,
  `PatientName` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homecareplan`
--

LOCK TABLES `homecareplan` WRITE;
/*!40000 ALTER TABLE `homecareplan` DISABLE KEYS */;
/*!40000 ALTER TABLE `homecareplan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incometype`
--

DROP TABLE IF EXISTS `incometype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `incometype` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `IncomeType` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incometype`
--

LOCK TABLES `incometype` WRITE;
/*!40000 ALTER TABLE `incometype` DISABLE KEYS */;
INSERT INTO `incometype` VALUES (1,'Medicine'),(3,'Opening Balance'),(4,'Income Adjust'),(5,'Product');
/*!40000 ALTER TABLE `incometype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log` (
  `msg` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserName` varchar(45) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (1,'user','MEB5Jr+HVP8fYqe1sfJ16yLkb5zLgVqJDIQPR2f+80anqa4x/0yVd6E0BELP661CxcUr2uofJR2tzRqO9nJVLmib3wWH7maQ03EFfSqWhuf0pdYAqL5vOtkTSFnpGS1T');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicine`
--

DROP TABLE IF EXISTS `medicine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicine` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Mno` varchar(45) DEFAULT NULL,
  `Name` varchar(200) DEFAULT NULL,
  `NameLower` varchar(200) DEFAULT NULL,
  `Stock` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=279 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicine`
--

LOCK TABLES `medicine` WRITE;
/*!40000 ALTER TABLE `medicine` DISABLE KEYS */;
INSERT INTO `medicine` VALUES (1,'M1','ACID SALICYLIC - Tincture -100ml','acid salicylic - tincture -100ml',1),(2,'M2','ALFA ALFA - Tincture -100ml','alfa alfa - tincture -100ml',1),(3,'M3','ALLIUM SATIVA - Tincture -100ml','allium sativa - tincture -100ml',1),(4,'M4','ARALIA RACEMOSA - Tincture -100ml','aralia racemosa - tincture -100ml',1),(5,'M5','BADIAGA - Tincture -100ml','badiaga - tincture -100ml',1),(6,'M6','BAPTISIA - Tincture -100ml','baptisia - tincture -100ml',1),(7,'M7','BERIBERIS VUL - Tincture -100ml','beriberis vul - tincture -100ml',1),(8,'M8','BRYONIA - Tincture -100ml','bryonia - tincture -100ml',1),(9,'M9','CALENDULA - Tincture -100ml','calendula - tincture -100ml',1),(10,'M10','CARDUS M - Tincture -100ml','cardus m - tincture -100ml',1),(11,'M11','ECHINACEA - Tincture -100ml','echinacea - tincture -100ml',1),(12,'M12','EUCALYPTUS - Tincture -100ml','eucalyptus - tincture -100ml',1),(13,'M13','EUPHRASIA - Tincture -100ml','euphrasia - tincture -100ml',1),(14,'M14','GRINDELIA - Tincture -100ml','grindelia - tincture -100ml',1),(15,'M15','HYDRANGEA - Tincture -100ml','hydrangea - tincture -100ml',1),(16,'M16','HYDRASTIS - Tincture -100ml','hydrastis - tincture -100ml',1),(17,'M17','IODOFORM - Tincture -100ml','iodoform - tincture -100ml',1),(18,'M18','JABORANDI - Tincture -100ml','jaborandi - tincture -100ml',1),(19,'M19','JUSTICIA ADHATODA - Tincture -100ml','justicia adhatoda - tincture -100ml',1),(20,'M20','LEMNA MINOR - Tincture -100ml','lemna minor - tincture -100ml',1),(21,'M21','MENTHOL - Tincture -100ml','menthol - tincture -100ml',1),(22,'M22','MYRISTICA - Tincture -100ml','myristica - tincture -100ml',1),(23,'M23','OCIMUM CAN - Tincture -100ml','ocimum can - tincture -100ml',1),(24,'M24','PASSIFLORA - Tincture -100ml','passiflora - tincture -100ml',1),(25,'M25','PETROLEUM - Tincture -100ml','petroleum - tincture -100ml',1),(26,'M26','PLANTAGO - Tincture -100ml','plantago - tincture -100ml',1),(27,'M27','POTHOS - Tincture -100ml','pothos - tincture -100ml',1),(28,'M28','PULSATILLA - Tincture -100ml','pulsatilla - tincture -100ml',1),(29,'M29','RAUWOLFIA - Tincture -100ml','rauwolfia - tincture -100ml',1),(30,'M30','ROBHINIA - Tincture -100ml','robhinia - tincture -100ml',1),(31,'M31','SAMBUCUS - Tincture -100ml','sambucus - tincture -100ml',1),(32,'M32','SYZYGIUM - Tincture -100ml','syzygium - tincture -100ml',1),(33,'M33','THALAPSI BURSA - Tincture -100ml','thalapsi bursa - tincture -100ml',1),(34,'M34','THUJA - Tincture -100ml','thuja - tincture -100ml',1),(35,'M35','URTICA URENS - Tincture -100ml','urtica urens - tincture -100ml',1),(36,'M36','VERAT VIRIDE - Tincture -100ml','verat viride - tincture -100ml',1),(37,'M37','XANTHOXYLLUM - Tincture -100ml','xanthoxyllum - tincture -100ml',1),(38,'M38','ZINGIBER - Tincture -100ml','zingiber - tincture -100ml',1),(39,'M39','ARS IOD - 3x','ars iod - 3x',1),(40,'M40','BAPTISIA - 3x','baptisia - 3x',1),(41,'M41','BORAX - 3x','borax - 3x',1),(42,'M42','CHOLESTERINUM - 3x','cholesterinum - 3x',1),(43,'M43','FERRUM MET - 3x','ferrum met - 3x',1),(44,'M44','IODUM - 3x','iodum - 3x',1),(45,'M45','LECITHIN - 3x','lecithin - 3x',1),(46,'M46','MEPHITIS - 3x','mephitis - 3x',1),(47,'M47','THYROIDINUM - 3x','thyroidinum - 3x',1),(48,'M48','CALC FLUOR - 6x','calc fluor - 6x',1),(49,'M49','CALC PHOS - 6x','calc phos - 6x',1),(50,'M50','FERRUM PHOS - 6x','ferrum phos - 6x',1),(51,'M51','KALI PHOS - 6x','kali phos - 6x',1),(52,'M52','KALI MUR - 6x','kali mur - 6x',1),(53,'M53','KALI SULPH - 6x','kali sulph - 6x',1),(54,'M54','NAT MUR - 6x','nat mur - 6x',1),(55,'M55','NATRUM PHOS - 6x','natrum phos - 6x',1),(56,'M56','NAT SULPH - 6x','nat sulph - 6x',1),(57,'M57','SILICEA - 6x','silicea - 6x',1),(58,'M58','ACID FLUOR - 30C - 30ml','acid fluor - 30c - 30ml',1),(59,'M59','ACID PHOS - 30C - 30ml','acid phos - 30c - 30ml',1),(60,'M60','ACID SALICYLIC - 30C - 30ml','acid salicylic - 30c - 30ml',1),(61,'M61','ACTEA SPICATA - 30C - 30ml','actea spicata - 30c - 30ml',1),(62,'M62','AETHUSA - 30C - 30ml','aethusa - 30c - 30ml',1),(63,'M63','AGRAPHIS - 30C - 30ml','agraphis - 30c - 30ml',1),(64,'M64','ALLIUM CEPA - 30C - 30ml','allium cepa - 30c - 30ml',1),(65,'M65','ALOES - 30C - 30ml','aloes - 30c - 30ml',1),(66,'M66','ANT ARS - 30C - 30ml','ant ars - 30c - 30ml',1),(67,'M67','APIS MEL - 30C - 30ml','apis mel - 30c - 30ml',1),(68,'M68','ARG NIT - 30C - 30ml','arg nit - 30c - 30ml',1),(69,'M69','ARS ALB - 30C - 30ml','ars alb - 30c - 30ml',1),(70,'M70','ARS IOD - 30C - 30ml','ars iod - 30c - 30ml',1),(71,'M71','ARUNDO - 30C - 30ml','arundo - 30c - 30ml',1),(72,'M72','AUR MUR NAT - 30C - 30ml','aur mur nat - 30c - 30ml',1),(73,'M73','AURUM MET - 30C - 30ml','aurum met - 30c - 30ml',1),(74,'M74','AVIARE - 30C - 30ml','aviare - 30c - 30ml',1),(75,'M75','BARYTA CARB - 30C - 30ml','baryta carb - 30c - 30ml',1),(76,'M76','BELLADONNA - 30C - 30ml','belladonna - 30c - 30ml',1),(77,'M77','BELLIS PER - 30C - 30ml','bellis per - 30c - 30ml',1),(78,'M78','BRYONIA - 30C - 30ml','bryonia - 30c - 30ml',1),(79,'M79','CAMPHORA - 30C - 30ml','camphora - 30c - 30ml',1),(80,'M80','CANTHARIS - 30C - 30ml','cantharis - 30c - 30ml',1),(81,'M81','CAULOPHYLLUM - 30C - 30ml','caulophyllum - 30c - 30ml',1),(82,'M82','CAUSTICUM - 30C - 30ml','causticum - 30c - 30ml',1),(83,'M83','CINA - 30C - 30ml','cina - 30c - 30ml',1),(84,'M84','COCCULUS IND - 30C - 30ml','cocculus ind - 30c - 30ml',1),(85,'M85','COCCUS CACTI - 30C - 30ml','coccus cacti - 30c - 30ml',1),(86,'M86','COLCHICUM - 30C - 30ml','colchicum - 30c - 30ml',1),(87,'M87','COLINSONIA - 30C - 30ml','colinsonia - 30c - 30ml',1),(88,'M88','COLOCYNTH - 30C - 30ml','colocynth - 30c - 30ml',1),(89,'M89','CONIUM MAC - 30C - 30ml','conium mac - 30c - 30ml',1),(90,'M90','CROTALUS HOR - 30C - 30ml','crotalus hor - 30c - 30ml',1),(91,'M91','CROTON TIG - 30C - 30ml','croton tig - 30c - 30ml',1),(92,'M92','CUPRUM MET - 30C - 30ml','cuprum met - 30c - 30ml',1),(93,'M93','DIASCOREA - 30C - 30ml','diascorea - 30c - 30ml',1),(94,'M94','DOLICHOS - 30C - 30ml','dolichos - 30c - 30ml',1),(95,'M95','EUCALYPTUS - 30C - 30ml','eucalyptus - 30c - 30ml',1),(96,'M96','EUPATORIUM PER - 30C - 30ml','eupatorium per - 30c - 30ml',1),(97,'M97','FAGOPYRUM - 30C - 30ml','fagopyrum - 30c - 30ml',1),(98,'M98','FERRUM MET - 30C - 30ml','ferrum met - 30c - 30ml',1),(99,'M99','GELSEMIUM - 30C - 30ml','gelsemium - 30c - 30ml',1),(100,'M100','GLONINE - 30C - 30ml','glonine - 30c - 30ml',1),(101,'M101','HAMAMELLIS - 30C - 30ml','hamamellis - 30c - 30ml',1),(102,'M102','HEPAR SULPH - 30C - 30ml','hepar sulph - 30c - 30ml',1),(103,'M103','HYDRASTIS - 30C - 30ml','hydrastis - 30c - 30ml',1),(104,'M104','IODUM - 30C - 30ml','iodum - 30c - 30ml',1),(105,'M105','IPECAC - 30C - 30ml','ipecac - 30c - 30ml',1),(106,'M106','JALAPPA - 30C - 30ml','jalappa - 30c - 30ml',1),(107,'M107','LYCOPODIUM - 30C - 30ml','lycopodium - 30c - 30ml',1),(108,'M108','LYSSIN - 30C - 30ml','lyssin - 30c - 30ml',1),(109,'M109','MERC SOL - 30C - 30ml','merc sol - 30c - 30ml',1),(110,'M110','MERC COR - 30C - 30ml','merc cor - 30c - 30ml',1),(111,'M111','MUREX - 30C - 30ml','murex - 30c - 30ml',1),(112,'M112','MYRISTICA - 30C - 30ml','myristica - 30c - 30ml',1),(113,'M113','NAT CARB - 30C - 30ml','nat carb - 30c - 30ml',1),(114,'M114','NAT MUR - 30C - 30ml','nat mur - 30c - 30ml',1),(115,'M115','NAT SULPH - 30C - 30ml','nat sulph - 30c - 30ml',1),(116,'M116','NUX VOM - 30C - 30ml','nux vom - 30c - 30ml',1),(117,'M117','PAROTIDINUM - 30C - 30ml','parotidinum - 30c - 30ml',1),(118,'M118','PETROLEUM - 30C - 30ml','petroleum - 30c - 30ml',1),(119,'M119','PHOSPHORUS - 30C - 30ml','phosphorus - 30c - 30ml',1),(120,'M120','PITUITARIN - 30C - 30ml','pituitarin - 30c - 30ml',1),(121,'M121','PLATINA - 30C - 30ml','platina - 30c - 30ml',1),(122,'M122','PLUMBUM MET - 30C - 30ml','plumbum met - 30c - 30ml',1),(123,'M123','PODOPHYLLUM - 30C - 30ml','podophyllum - 30c - 30ml',1),(124,'M124','PSORINUM - 30C - 30ml','psorinum - 30c - 30ml',1),(125,'M125','PULSATILLA - 30C - 30ml','pulsatilla - 30c - 30ml',1),(126,'M126','RHUS TOX - 30C - 30ml','rhus tox - 30c - 30ml',1),(127,'M127','RUMEX - 30C - 30ml','rumex - 30c - 30ml',1),(128,'M128','RUTA - 30C - 30ml','ruta - 30c - 30ml',1),(129,'M129','SABADILLA - 30C - 30ml','sabadilla - 30c - 30ml',1),(130,'M130','SAMBUCUS - 30C - 30ml','sambucus - 30c - 30ml',1),(131,'M131','SANGUINARIA - 30C - 30ml','sanguinaria - 30c - 30ml',1),(132,'M132','SEPIA - 30C - 30ml','sepia - 30c - 30ml',1),(133,'M133','SILICEA - 30C - 30ml','silicea - 30c - 30ml',1),(134,'M134','SPONGIA - 30C - 30ml','spongia - 30c - 30ml',1),(135,'M135','SQUILLA - 30C - 30ml','squilla - 30c - 30ml',1),(136,'M136','STANNUM MET - 30C - 30ml','stannum met - 30c - 30ml',1),(137,'M137','STAPHYSAGRIA - 30C - 30ml','staphysagria - 30c - 30ml',1),(138,'M138','STRAMONIUM - 30C - 30ml','stramonium - 30c - 30ml',1),(139,'M139','SULPHUR - 30C - 30ml','sulphur - 30c - 30ml',1),(140,'M140','SYMPHYTUM - 30C - 30ml','symphytum - 30c - 30ml',1),(141,'M141','TELLUIRIUM - 30C - 30ml','telluirium - 30c - 30ml',1),(142,'M142','THUJA - 30C - 30ml','thuja - 30c - 30ml',1),(143,'M143','URTICA URENS - 30C - 30ml','urtica urens - 30c - 30ml',1),(144,'M144','WEISBADEN - 30C - 30ml','weisbaden - 30c - 30ml',1),(145,'M145','WYETHIA - 30C - 30ml','wyethia - 30c - 30ml',1),(146,'M146','XRAY - 30C - 30ml','xray - 30c - 30ml',1),(147,'M147','XANTHOXYLLUM - 30C - 30ml','xanthoxyllum - 30c - 30ml',1),(148,'M148','ZINC MET - 30C - 30ml','zinc met - 30c - 30ml',1),(149,'M149','ACONITE NAP - 200C - 30ml','aconite nap - 200c - 30ml',1),(150,'M150','ALUMINA - 200C - 30ml','alumina - 200c - 30ml',1),(151,'M151','ANT CRUD - 200C - 30ml','ant crud - 200c - 30ml',1),(152,'M152','ANT TART - 200C - 30ml','ant tart - 200c - 30ml',1),(153,'M153','APIS MEL - 200C - 30ml','apis mel - 200c - 30ml',1),(154,'M154','ARG NIT - 200C - 30ml','arg nit - 200c - 30ml',1),(155,'M155','ARNICA - 200C - 30ml','arnica - 200c - 30ml',1),(156,'M156','ARS ALB - 200C - 30ml','ars alb - 200c - 30ml',1),(157,'M157','BACILLINUM - 200C - 30ml','bacillinum - 200c - 30ml',1),(158,'M158','BELLADONNA - 200C - 30ml','belladonna - 200c - 30ml',1),(159,'M159','BRYONIA - 200C - 30ml','bryonia - 200c - 30ml',1),(160,'M160','CAL CARB - 200C - 30ml','cal carb - 200c - 30ml',1),(161,'M161','CALC PHOS - 200C - 30ml','calc phos - 200c - 30ml',1),(162,'M162','CAPSICUM - 200C - 30ml','capsicum - 200c - 30ml',1),(163,'M163','CARBO VEG - 200C - 30ml','carbo veg - 200c - 30ml',1),(164,'M164','CARCINOSIN - 200C - 30ml','carcinosin - 200c - 30ml',1),(165,'M165','CAUSTICUM - 200C - 30ml','causticum - 200c - 30ml',1),(166,'M166','CHAMOMILLA - 200C - 30ml','chamomilla - 200c - 30ml',1),(167,'M167','CHINA - 200C - 30ml','china - 200c - 30ml',1),(168,'M168','COFFEA CRUD - 200C - 30ml','coffea crud - 200c - 30ml',1),(169,'M169','COLOCYNTH - 200C - 30ml','colocynth - 200c - 30ml',1),(170,'M170','CONIUM MAC - 200C - 30ml','conium mac - 200c - 30ml',1),(171,'M171','GELSEMIUM - 200C - 30ml','gelsemium - 200c - 30ml',1),(172,'M172','GRAPHITIS - 200C - 30ml','graphitis - 200c - 30ml',1),(173,'M173','HEPAR SULPH - 200C - 30ml','hepar sulph - 200c - 30ml',1),(174,'M174','HYPERICUM - 200C - 30ml','hypericum - 200c - 30ml',1),(175,'M175','IPECAC - 200C - 30ml','ipecac - 200c - 30ml',1),(176,'M176','IRIS VER - 200C - 30ml','iris ver - 200c - 30ml',1),(177,'M177','KALI BICH - 200C - 30ml','kali bich - 200c - 30ml',1),(178,'M178','KALI CARB - 200C - 30ml','kali carb - 200c - 30ml',1),(179,'M179','KREOSOTUM - 200C - 30ml','kreosotum - 200c - 30ml',1),(180,'M180','LACHESIS - 200C - 30ml','lachesis - 200c - 30ml',1),(181,'M181','LEDUM PAL - 200C - 30ml','ledum pal - 200c - 30ml',1),(182,'M182','LYCOPODIUM - 200C - 30ml','lycopodium - 200c - 30ml',1),(183,'M183','MAG CARB - 200C - 30ml','mag carb - 200c - 30ml',1),(184,'M184','MERC SOL - 200C - 30ml','merc sol - 200c - 30ml',1),(185,'M185','NAT MUR - 200C - 30ml','nat mur - 200c - 30ml',1),(186,'M186','NAT SULPH - 200C - 30ml','nat sulph - 200c - 30ml',1),(187,'M187','NITRIC ACID - 200C - 30ml','nitric acid - 200c - 30ml',1),(188,'M188','NUX MOSCH - 200C - 30ml','nux mosch - 200c - 30ml',1),(189,'M189','NUX VOM - 200C - 30ml','nux vom - 200c - 30ml',1),(190,'M190','PHOSPHORUS - 200C - 30ml','phosphorus - 200c - 30ml',1),(191,'M191','PLATINA - 200C - 30ml','platina - 200c - 30ml',1),(192,'M192','PSORINUM - 200C - 30ml','psorinum - 200c - 30ml',1),(193,'M193','PULSATILLA - 200C - 30ml','pulsatilla - 200c - 30ml',1),(194,'M194','PYROGENUM - 200C - 30ml','pyrogenum - 200c - 30ml',1),(195,'M195','RATANIA - 200C - 30ml','ratania - 200c - 30ml',1),(196,'M196','RHUS TOX - 200C - 30ml','rhus tox - 200c - 30ml',1),(197,'M197','RUMEX - 200C - 30ml','rumex - 200c - 30ml',1),(198,'M198','SABINA - 200C - 30ml','sabina - 200c - 30ml',1),(199,'M199','STAPHYLOCOCCIN - 200C - 30ml','staphylococcin - 200c - 30ml',1),(200,'M200','SEPIA - 200C - 30ml','sepia - 200c - 30ml',1),(201,'M201','SILICEA - 200C - 30ml','silicea - 200c - 30ml',1),(202,'M202','SPIGELIA - 200C - 30ml','spigelia - 200c - 30ml',1),(203,'M203','STAPHYSAGRIA - 200C - 30ml','staphysagria - 200c - 30ml',1),(204,'M204','SULPHUR - 200C - 30ml','sulphur - 200c - 30ml',1),(205,'M205','TARENTULA HISP - 200C - 30ml','tarentula hisp - 200c - 30ml',1),(206,'M206','TUBERCULINUM - 200C - 30ml','tuberculinum - 200c - 30ml',1),(207,'M207','VERATRUM ALB - 200C - 30ml','veratrum alb - 200c - 30ml',1),(208,'M208','ALOES - 1m - 10ml','aloes - 1m - 10ml',1),(209,'M209','ALUMINA - 1m - 10ml','alumina - 1m - 10ml',1),(210,'M210','ANT CRUD - 1m - 10ml','ant crud - 1m - 10ml',1),(211,'M211','APIS MEL - 1m - 10ml','apis mel - 1m - 10ml',1),(212,'M212','ARG NIT - 1m - 10ml','arg nit - 1m - 10ml',1),(213,'M213','ARNICA - 1m - 10ml','arnica - 1m - 10ml',1),(214,'M214','ARS ALB - 1m - 10ml','ars alb - 1m - 10ml',1),(215,'M215','AURUM MET - 1m - 10ml','aurum met - 1m - 10ml',1),(216,'M216','BACILLINUM - 1m - 10ml','bacillinum - 1m - 10ml',1),(217,'M217','BELLADONNA - 1m - 10ml','belladonna - 1m - 10ml',1),(218,'M218','BRYONIA - 1m - 10ml','bryonia - 1m - 10ml',1),(219,'M219','CAL CARB - 1m - 10ml','cal carb - 1m - 10ml',1),(220,'M220','CARBO VEG - 1m - 10ml','carbo veg - 1m - 10ml',1),(221,'M221','CARCINOSIN - 1m - 10ml','carcinosin - 1m - 10ml',1),(222,'M222','CAUSTICUM - 1m - 10ml','causticum - 1m - 10ml',1),(223,'M223','CHAMOMILLA - 1m - 10ml','chamomilla - 1m - 10ml',1),(224,'M224','CHINA - 1m - 10ml','china - 1m - 10ml',1),(225,'M225','COLOCYNTH - 1m - 10ml','colocynth - 1m - 10ml',1),(226,'M226','CONIUM MAC - 1m - 10ml','conium mac - 1m - 10ml',1),(227,'M227','DROSERA - 1m - 10ml','drosera - 1m - 10ml',1),(228,'M228','GELSEMIUM - 1m - 10ml','gelsemium - 1m - 10ml',1),(229,'M229','GLONINE - 1m - 10ml','glonine - 1m - 10ml',1),(230,'M230','GRAPHITIS - 1m - 10ml','graphitis - 1m - 10ml',1),(231,'M231','HEPAR SULPH - 1m - 10ml','hepar sulph - 1m - 10ml',1),(232,'M232','IGNATIA - 1m - 10ml','ignatia - 1m - 10ml',1),(233,'M233','IPECAC - 1m - 10ml','ipecac - 1m - 10ml',1),(234,'M234','IRIS VER - 1m - 10ml','iris ver - 1m - 10ml',1),(235,'M235','KALI BICH - 1m - 10ml','kali bich - 1m - 10ml',1),(236,'M236','KALI CARB - 1m - 10ml','kali carb - 1m - 10ml',1),(237,'M237','LACHESIS - 1m - 10ml','lachesis - 1m - 10ml',1),(238,'M238','LEDUM PAL - 1m - 10ml','ledum pal - 1m - 10ml',1),(239,'M239','LEMNA MINOR - 1m - 10ml','lemna minor - 1m - 10ml',1),(240,'M240','LYCOPODIUM - 1m - 10ml','lycopodium - 1m - 10ml',1),(241,'M241','LYSSIN - 1m - 10ml','lyssin - 1m - 10ml',1),(242,'M242','MAG CARB - 1m - 10ml','mag carb - 1m - 10ml',1),(243,'M243','MEDORRHINUM - 1m - 10ml','medorrhinum - 1m - 10ml',1),(244,'M244','MERC SOL - 1m - 10ml','merc sol - 1m - 10ml',1),(245,'M245','NAT MUR - 1m - 10ml','nat mur - 1m - 10ml',1),(246,'M246','NAT SULPH - 1m - 10ml','nat sulph - 1m - 10ml',1),(247,'M247','NITRIC ACID - 1m - 10ml','nitric acid - 1m - 10ml',1),(248,'M248','NUX VOM - 1m - 10ml','nux vom - 1m - 10ml',1),(249,'M249','OPIUM - 1m - 10ml','opium - 1m - 10ml',1),(250,'M250','PHOSPHORUS - 1m - 10ml','phosphorus - 1m - 10ml',1),(251,'M251','PLATINA - 1m - 10ml','platina - 1m - 10ml',1),(252,'M252','PSORINUM - 1m - 10ml','psorinum - 1m - 10ml',1),(253,'M253','PULSATILLA - 1m - 10ml','pulsatilla - 1m - 10ml',1),(254,'M254','RHUS TOX - 1m - 10ml','rhus tox - 1m - 10ml',1),(255,'M255','SARSAPARILLA - 1m - 10ml','sarsaparilla - 1m - 10ml',1),(256,'M256','SEPIA - 1m - 10ml','sepia - 1m - 10ml',1),(257,'M257','SILICEA - 1m - 10ml','silicea - 1m - 10ml',1),(258,'M258','SPIGELIA - 1m - 10ml','spigelia - 1m - 10ml',1),(259,'M259','SULPHUR - 1m - 10ml','sulphur - 1m - 10ml',1),(260,'M260','THUJA - 1m - 10ml','thuja - 1m - 10ml',1),(261,'M261','TUBERCULINUM - 1m - 10ml','tuberculinum - 1m - 10ml',1),(262,'M262','VERATRUM ALB - 1m - 10ml','veratrum alb - 1m - 10ml',1),(263,'M263','ACID PHOS - 10m - 10ml','acid phos - 10m - 10ml',1),(264,'M264','ANT TART - 10m - 10ml','ant tart - 10m - 10ml',1),(265,'M265','DULCAMARA - 10m - 10ml','dulcamara - 10m - 10ml',1),(266,'M266','MEDORRHINUM - 10m - 10ml','medorrhinum - 10m - 10ml',1),(267,'M267','NUX VOM - 10m - 10ml','nux vom - 10m - 10ml',1),(268,'M268','PHOSPHORUS - 10m - 10ml','phosphorus - 10m - 10ml',1),(269,'M269','PSORINUM - 10m - 10ml','psorinum - 10m - 10ml',1),(270,'M270','SEPIA - 10m - 10ml','sepia - 10m - 10ml',1),(271,'M271','STAPHYSAGRIA - 10m - 10ml','staphysagria - 10m - 10ml',1),(272,'M272','SULPHUR - 10m - 10ml','sulphur - 10m - 10ml',1),(273,'M273','SYPHILLINUM - 10m - 10ml','syphillinum - 10m - 10ml',1),(274,'M274','TUBERCULINUM - 10m - 10ml','tuberculinum - 10m - 10ml',1),(275,'M275','Test medicine','test medicine',3),(276,'M276','Cephalandra Tincture','cephalandra tincture',1),(277,'M277','OCUIMUM SAN Tincture - 100 ml','ocuimum san tincture - 100 ml',1),(278,'M278','Test med 2','test med 2',1);
/*!40000 ALTER TABLE `medicine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicinehistory`
--

DROP TABLE IF EXISTS `medicinehistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicinehistory` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `MedicineId` int DEFAULT NULL,
  `txnDate` datetime DEFAULT NULL,
  `mno` varchar(45) DEFAULT NULL,
  `medName` varchar(200) DEFAULT NULL,
  `txnType` varchar(45) DEFAULT NULL,
  `desc` varchar(45) DEFAULT NULL,
  `openingMain` int DEFAULT NULL,
  `openingSub` int DEFAULT NULL,
  `openingAKit` int DEFAULT NULL,
  `openingBKit` int DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `closingMain` int DEFAULT NULL,
  `closingSub` int DEFAULT NULL,
  `closingAKit` int DEFAULT NULL,
  `closingBKit` int DEFAULT NULL,
  `pno` varchar(45) DEFAULT NULL,
  `patientName` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicinehistory`
--

LOCK TABLES `medicinehistory` WRITE;
/*!40000 ALTER TABLE `medicinehistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `medicinehistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicinepurchase`
--

DROP TABLE IF EXISTS `medicinepurchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicinepurchase` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `MedicineId` int NOT NULL,
  `invdate` datetime DEFAULT NULL,
  `invno` varchar(45) DEFAULT NULL,
  `batchno` varchar(45) DEFAULT NULL,
  `expdate` datetime NOT NULL,
  `mfgdate` datetime DEFAULT NULL,
  `rate` decimal(10,2) DEFAULT NULL,
  `dealer` varchar(100) DEFAULT NULL,
  `mainStock` int DEFAULT NULL,
  `subStock` int DEFAULT NULL,
  `return` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicinepurchase`
--

LOCK TABLES `medicinepurchase` WRITE;
/*!40000 ALTER TABLE `medicinepurchase` DISABLE KEYS */;
/*!40000 ALTER TABLE `medicinepurchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicinestock`
--

DROP TABLE IF EXISTS `medicinestock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicinestock` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `MedicineId` int NOT NULL,
  `Main` int DEFAULT NULL,
  `Sub` int DEFAULT NULL,
  `A_kit` int DEFAULT NULL,
  `B_kit` int DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `medicinestock_medicine_idx` (`MedicineId`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicinestock`
--

LOCK TABLES `medicinestock` WRITE;
/*!40000 ALTER TABLE `medicinestock` DISABLE KEYS */;
INSERT INTO `medicinestock` VALUES (1,1,66,0,0,0);
/*!40000 ALTER TABLE `medicinestock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `op`
--

DROP TABLE IF EXISTS `op`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `op` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `PatientId` int DEFAULT NULL,
  `History` longblob,
  `Medicine` longblob,
  `NextOPDate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=274 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `op`
--

LOCK TABLES `op` WRITE;
/*!40000 ALTER TABLE `op` DISABLE KEYS */;
INSERT INTO `op` VALUES (1,1,_binary '<p>ALLERGY</p><p>SNEEZING</p><p>ITCHING IN EYES</p><p>SNEEZING INCREASES ASTHMA COMES</p>',_binary '<p>1)ARS ALB 10m i dose hs</p><p>2)ARS ALB 10M 4 DOSES (SOS)</p><p>3)SABADILLA 30 4BD - 2DRM PILLS</p><p>4)ARALIA +POTHOS Q - 10 DROPS TDS - 20 ML</p><p><br></p>','2022-01-14 00:00:00'),(2,2,_binary '<p>COUGH SINCE YESTERDAY</p><p>AFTER DUST INHALATION</p><p>DIFFICULT EXPECTORATION</p><p>TAKING HOMEO MEDICINES REGULARLY FOR ALLERGIC ISSUES</p><p>COUGH INCREASES CAUSES ASTHMA</p><p>SLIGHT THROAT INFECTION AFTER TAKING COLD WATER</p><p>&lt;AFTER TAKING COILD WATER</p><p>ALLERGIC COUGH WITH</p><p><br></p><p>SLIGHT DISTURNANCE IN INHALATION</p>',_binary '<p>31/12/21</p><ol><li>POTHOS + ARALIA TINCTURE 15 DROPS TDS</li><li>RUMEX 200 4 TDS</li><li>SULPH PSOR - 200 - 4 DOSE WEEKLY ONCE</li></ol>','0001-01-01 00:00:00'),(3,3,_binary '<ol><li>H1</li><li>h2</li><li>h3</li></ol>',_binary '<ol><li>M1</li><li>m2</li><li>M3</li></ol>','2022-08-01 00:00:00'),(212,216,_binary '<p>4/7/22</p><p>H/O HOSPITAL ADMISSION DUE TO BREATHING DIFFICULTY</p><p>NOSE BLOCK</p><p>COLD</p><p>COUGH AT TIMES WITH EXPECTORATION</p><p>RATTLING</p><p>BOWELS - REGULAR</p><p>6/7/22</p><p>RATTLING BETTER TODAY</p><p>18/7/22</p><p>COUGH SINCE YESTERDAY, HAD CLEARED COMPLETELY</p><p>RUNNING NOSE WITH THICK NASAL DISCHARGE</p><p>VOMITING SHOWING TENDENCY TO VOMIT AFTER COUGH</p><p>CRYING IN BETWEEN FEEDING</p><p>3/7/22</p><p>CRADLE CAP</p><p>ON HEAD</p><p>IERUPTIONS IN NECK</p><p>/ECZEMA TENDENCY</p>',_binary '<p>4/7/22</p><ol><li>IPECAC 30 - 2 DRM PILLS ALTERNATE</li><li>PULS 200 - 2 DRM PILLS</li></ol><p>6/7/22</p><ol><li>CONTINUE</li><li>IPECAC 30 - 2 DRM PILLS - 3 TDS</li><li>PULS 200 - 1 DRM TABLETS - 1 TDS...REVIEW ON THURSDAY IF RATTLING PERSISTS</li></ol><p>18/7/22</p><ol><li>NASAL DROPS</li><li>PULS 200 - 2 DRM PILLS ALTERNATE WITH</li><li>IPECAC 3X - 2 DRM PILLS</li></ol><p>3/7/22</p><ol><li>PSORINUM 200 - 1 DOSE STAT</li><li>KS 6X - 1/2 OUNCE - 2 TDS</li></ol>','2022-07-06 00:00:00'),(4,4,_binary '<p>13/11/21</p><p>NASAL OBSTRUCTION AT NIGHT</p><ol><li>OFFENSSIVE NASAL DISCHARGE</li><li>THICK DISCHARGE FROM NOSE</li><li>C/O URIC ACID,CHOLESTROL,THYROID,HYPERTENSION</li><li>&lt;FANNING</li></ol>',_binary '<ol><li>PULS 1M - 3PILLS 2 HRLY</li><li>KALI BICH - 3 PILLS 2 HRLY</li><li>EUCALYPTUS TINCTURE - 10 GTT  TDS  </li></ol>','0001-01-01 00:00:00'),(5,5,_binary '<p>13/11/21</p><p>MOLLUSCUM CONTAGIOSUM</p><p>LOSS OF APETITE, LESS FOOD INTAKE</p><p>26/11/21</p><p>ONE MOLLUSCUM FELL OFF</p><p>NO OTHER ISSSUES</p><p><br></p>',_binary '<ol><li>13/11/21</li><li>SILICEA 1M 4 TDS</li><li>CALC CARB 30 - 4TDS</li></ol><p>26/11/21</p><p>REPEAT FIRST PRESCRIPTIN QID INSTEAD OF TDS</p>','0001-01-01 00:00:00'),(6,6,_binary '<p>13/11/21</p><ol><li>POST NASAL DRIPPING</li><li>DIFFICULT EXPECTORATION</li></ol><p>4/12/21</p><ol><li>REDUCED.</li></ol><p><br></p><p>3/1/22</p><p>WAS FEELING BETTER WHILE TAKING MEDICINES.</p><p>REQUIRES MEDICINE NOW.</p><p><br></p><p>5/4/22</p><p>REQUIRES MEDICINE FOR THROAT PAIN</p><p>8/7/22</p><p>NEEDS DROPS</p><p>FEELS LIKE FEVERISH</p>',_binary '<p>13/11/21</p><ol><li>EUCALYPTUS Q - 10 DROPS TDS</li><li>PULS 1M -4QDS -B/F</li><li>KALI BICH 200 - 4 QDS</li></ol><p>4/12/21</p><ol><li>EUCALYPTUS Q - 20ML -10 DROPS TDS</li><li>SILICEA 200 - BD</li><li>KALI BICH 1M - 2 DOSE</li><li>B24 - 2 BD</li></ol><p><br></p><p>3/1/22</p><ol><li>EUCALYPTUS Q - 20ML - 10 DROPS TDS</li><li>KALI BICH 200 - 2 DRM - 4 TDS</li><li>SILICEA 6X - 1/2 OUNCE - 2 TDS</li></ol><p>5/4/22</p><ol><li>PHYTOLACCA + BELL Q - 10ML- 15TDS</li><li>BELL 200 2 DRM</li><li>MERC SOL 200 2 DRM- 3PILLS 2HRLY ALT</li></ol><p>8/7/22</p><ol><li>BAPT+EUCALYPTUS Q - 10ML</li><li>BRY 200 - 2 DRM PILLS</li></ol>','2022-02-05 00:00:00'),(7,7,_binary '<p>PAIN KNEE JOINTS</p><p>&lt;FIRST MOTION</p><p>&gt;CONTINUED MOTION , REST</p>',_binary '<p>13/11/21</p><ol><li>BRYOINA TINCTURE - 10 DROPS TDS</li><li>RUBOR GEL</li><li>ARNICA 200 - 4TDS</li><li>CALC PHOS 6X - 4 BD</li></ol>','0001-01-01 00:00:00'),(8,8,_binary '<p>13/11/21</p><p>MOLLUSCUM CONTAGIOSUM</p><p>SINCE 4 MONTHS</p><p>1/12/21</p><p>FEW ARE GETTING FALLEN</p><p><br></p>',_binary '<p>13/11/21</p><ol><li>SILICEA 1M - 4 TDS </li><li>CALC CARB 30 - 4 TDS</li></ol><p>1/12/21</p><ol><li>REPEAT ABOVE</li><li>ACID SALICYLIC 5ML APPLY EXTERNALLY</li></ol>','2022-01-17 00:00:00'),(9,9,_binary '<p>13/11/21</p><p>C/O THICK PHLEGM IN THROAT</p><p>VERY DIFFICULT TASTE NOT ABLE TO SWALLOW</p><p>H/O TB AT CHILDHOOD</p><p>ALLERGIC AT CHILDHOOD</p><p>DOESNT WISH TO TAKE FOOD AT TIMES</p><p>TAKEN TREATMENT FOR INFERTILITY FOR THICK SEMEN</p><p><br></p><p>6/12/21</p><p>BETTER FOR  PHLEGM COMING UP</p><p>CONTINOUS TALKING CAUSES FATIGUE</p><p><br></p>',_binary '<p>13/11/21</p><p><br></p><ol><li>SULPH 1M - 1 DOSE</li><li>ARS IOD 3X - 2 BD</li><li>SAMBUCUS Q - 10 DROPS</li></ol><p><br></p><p><br></p><ul><li>6/12/21</li></ul><ol><li>SULPH 1M - 1 DOSE</li><li>ARS IOD 3X - 2 BD</li><li>EUCALYPTUS Q - 10 DROPS TDS</li></ol>','0001-01-01 00:00:00'),(10,10,_binary '<p>15/11/21</p><p>HEEL PAIN</p><p>&lt;MORNING</p><p>&lt;MOTION</p><p>&lt;CHANGE OF POSITION</p><p>&gt;HOT APPLICATION</p><p>URIC ACID NORMAL - AS SAID BY PATIENT</p><p>MENSES- REGULAR</p><p>WEIGHT GAIN RECENTLY</p><p>APPETITE - GOOD,</p><p>BOWELS - REGULAR</p><p><br></p><p>20/11/21- PAIN RELIEF</p><p><br></p><p><br></p><p>6/12/21 - CHANGE OF POSITION CAUSES PAIN</p><p><br></p><p>17/12/21- PAIN REDUCED VERY MUCH</p><p><br></p><p>27/12/21 - REQUIRES BIG TABLET  WHICH GOT OVER</p><p><br></p><p><br></p>',_binary '<p>15/11/21</p><p><br></p><ol><li>RHUS TOX 1M - -4 QID</li><li>MEDO 1M - 2 DOSE</li><li>CALC PHOS 6X - 3 TDS</li></ol><p><br></p><p>20/11/21</p><ol><li>CALC PHOS 6X - 30ML BOTTLE</li><li>RHUS TOX 1M - 3 DRM PILLS</li></ol><p>6/12/21</p><ol><li>CALC PHOS 200 - 3 DRM - 4 TDS</li><li>PULS 10M - 2 DOSE [6/12/21, 20/12/21]</li><li>B4 - 3 DRM - 3 BD</li></ol><p><br></p><p>17/12/21</p><ol><li>PULS 10M - 2 DOSE</li><li>CALC PHOS 200 - 2 DRM - 4 TDS</li><li>B4 - 3 DRM - 3 BD</li><li>MEDO 10M - 1 DOSE {28/12/21}</li></ol><p><br></p><p>27/12/21</p><ol><li>B24 - 3TDS</li></ol><p><br></p>','2022-01-10 00:00:00'),(11,11,_binary '<p>15/11/21</p><p> </p><p>RUNNING NOSE</p><p>FEVER @ 4PM</p><p>COUGH</p><p><br></p>',_binary '<p>15/11/21</p><ol><li>BAPTISIA 3X - 10 DROPS 2 HRLY</li><li>EUCALYPTUS Q - 10 DROPS TDS</li><li>BRY 200 3 PILLS 2 HRLY</li><li>BELL 1M - 2 DOSES - SOS</li></ol>','0001-01-01 00:00:00'),(12,12,_binary '<p>16/11/21</p><p>PALPITATION</p><p>NAUSEA &lt;BLOATED ABDOMEN</p><p>&lt;EMPTY STOMACH</p><p>VERTIGO &lt; CHANGE OF POSITION</p><p>ITCHING &lt; DRY SKIN</p><p>MIND</p><p>&lt; AILMENTS FROM SAD NEWS/ BAD NEWS</p><p>CANNOT BREATH THEN</p><p><br></p><p>TOTAL CHOLESTROL ; 228 MG/DL</p><p>RBS ; 113MG/DL</p><p>VLDL ; &lt;28MG/DL</p><p><br></p><p><br></p>',_binary '<p>16/11/21</p><ol><li>ZINGIBER Q - 10 DROPS TDS A/F</li><li>NAT PHOS 6X - 3 TAB TDS</li><li>CONIUM M 1M - 4 TDS A/F</li><li>PULS 10M - 2 DOSE WEEKLY ONCE</li></ol>','0001-01-01 00:00:00'),(13,13,_binary '<p>16/11/21</p><p>HAD FEVER WITH THROAT PAIN ONE WEEK BACK.</p><p>TAKEN ALLOPATHIC TREATMENT.</p><p>DIFFICULTY IN PASSING MOTION .A/F ALLOPATHY MEDICINES.</p><p>SENSATION TO PASS PRESENT,BUT DOESNT PASS.</p><p>C/O GASTRITIS</p><p>INTRMITTANT FEVER NOWADAYS.FEVER MORNING AND NIGHT</p><p>O/E TONSILLS ENLARGED</p><p>A/F AFTER TAKING COLD FOOD</p><p>BOWELS----- QBSENT SINCE 3 DAYS</p><p><br></p>',_binary '<p>16/11/21</p><ol><li>NUX VOM 200 - 1 DOSE</li><li>HYDRASTIS TINCTURE -10 DRPS TDD 200 - 1DISE A/F</li><li>BELL 200 4 TDS</li><li>PYROGEN 200 - 1DOSE IF FEVER</li></ol>','0001-01-01 00:00:00'),(14,14,_binary '<p>16/11/21</p><p>H/O VERTIGO</p><p>&lt;ASCENDING</p><p>&gt;SLEEP</p><p>O/E ANEMIA</p><p>BURNING ABDOMEN</p><p><br></p><p>PALPITATION</p><p>BP; 140/100MM OF HG</p><p>BOWELS ; IRREGULAR,CONSTIPATED BEFORE</p><p><br></p><p>27/11/21</p><p>VERTIGO ; SLIGHTLY PERSISTING</p><p>RELIEVED A LITTLE</p><p>PALPITATION REDUCED</p><p>ADVISED RBS,HB,TSH</p><p><br></p><p>1/12/21</p><p>HB ; 11.2GM/DL</p><p>RBS ; 248MG/DL &lt;140MG/DL</p><p>TSH ; 1.45</p><p>-TIRED ;</p><p>SLEEP ; NOT REFRESHING</p><p>PALPITATION</p><p>SUDDEN DEATH OF UNCLE; AFTER COVID</p><p>BP ; VARIATION ,SUDDEN BP</p><p>HEEL PAIN</p><p><br></p><p>21/12/21</p><p>HEADACHE SINCE 3 DAYS</p><p>RIGHT SIDED NUMBNESS WITH</p><p>DIFFICULTY IN LIFTING HANDS</p><p>DIFFICULT DOING HOUSE HOLD WORKS</p><p>MENSES;</p><p>2 CSECTIONS</p><p>CYCLES NORMAL</p><p>HEADACHE BOTH SIDES</p><p>NO RELIEF AFTER SLEEP</p><p>HEADACHE WITH NAUSEA</p><p>NOT VOMITING</p><p>PAIN C/O BACKACHE ? DISC PROLAPSE</p><p>FAMILY HISTORY OF DIABETES</p><p><br></p><p>ADVICED; LIPID PROFILE,CREATININE,FBS,PPBS,C PEPTIDE</p><p><br></p><p>22/12</p><p>C PEPTIDE ; 780---259-1728</p><p>HBA1C- 9.2</p><p>FBS - 191M &lt;100MG/DL</p><p>PPBS - 266MG/DL &lt;140MG/DL</p><p>S.CREATININE- 0.6---0.5--1.5</p><p>MEAN PLASMA GLUCOSE - 217</p><p>TOTAL CHOLESTROL - 178 MG /DL</p><p><br></p><p><br></p><p><br></p>',_binary '<p>16/11/21</p><ol><li>FERR PLUS CAPSULES 10 TAB HS 10 DAYS</li><li>NAT MUR 200 SINGLE DOSE</li><li>NAT MUR 6X 3 TDS A/F</li><li>CONIUM  4 TDS</li></ol><p><br></p><p>1/12/21</p><ol><li>ACID PHOS 200 4 TDS</li><li>NAT MUR 10M 2 DOSE 2 WEEKLY</li><li>B24 - 2 BD</li><li>SYZYGIUM Q - 10 DROPS BD</li></ol><p><br></p><p>21/12/21</p><ol><li>NAT MUR 6X - 2 DRM 3 TDS - 5 DAYS</li><li>IPECAC 200 3 PILLS 2 HRLY</li></ol><p><br></p><p>23/12/21</p><ol><li>SYPH 10 M- 1 DOSE HS</li><li>MEDO 1M - WEEKLY  ONCE - 4 DOSE</li><li>AEGLE FOLIA Q - 10 DROPS TDS</li><li>NAT MUR 6X - 4 TDS - 2 OUNCE</li></ol><p><br></p>','2022-01-21 00:00:00'),(15,15,_binary '<p>18/11/21</p><p>SENSATION OF PHLEGM IN THROAT</p><p>C/O STOMACH UPSET AT NIGHT</p><p>FEVER 2 DAYS BACK AFTER OUTING</p><p><br></p><p>3/1/22</p><p>BOILS ON AXILLA</p><p>SLIGHT DRY COUGH</p><p>RUNNING NOSE</p><p>HAD ICECREAM YESTERDAY</p><p>30/3/22</p><p>COUGH STARTED AFTER TAKING COLD MILK SHAKE</p><p>NO WHEEZING</p><p>THROAT PAIN</p><p>COLD AND COUHG PHLEGM YELLOWISH</p><p>&lt;TALKING</p><p>THIRSTY -++</p><p>APETITE - REDUCED</p><p>THERMALS - HOT</p><p>PERSPIRATION</p><p>HALITOSIS+</p><p>BOWELS - REGULAR</p><p>SALT DESIRES</p><p>MIND = SENTIMENTAL ,CRIES EASILY</p><p>5/7/22</p><p>THROAT PAIN</p><p>&lt; AFTER ICE CREAMS</p><p>COUGH WHILE TALKING</p><p>LOSS OF VOICE</p>',_binary '<p>18/11/21</p><ol><li>EUCALYPTUS Q - 10 DROPS TDS</li><li>SIL 6X - 3 TDS</li><li>PILS 200 2 DOSE BD</li></ol><p><br></p><p>3/1/22</p><ol><li>SIL 200 - 4 TDS</li><li>HEP SULPH 200 - 4 TDS</li><li>ARALIA Q - 10ML - 10 TDS</li></ol><p>30/3/22</p><ol><li>GRINDELIA Q - 10ML - 10 DROPS TDS</li><li>HEP SULPH 200 - 4 QID</li><li>PULS 200 - 4 TDS</li></ol><p>5/7/22</p><ol><li>HEPSULPH 200 -2 DRM PILLS - 4 QID</li><li>PHYTOLACCA + BELL Q - 10ML - 10 QID</li></ol>','0001-01-01 00:00:00'),(16,16,_binary '<p>18/11/21</p><p>HAIRFALL SINCE 1 MONTH</p><p>APETITE REDUCED</p><p>BOWELS - REGULAR</p><p>THIRST - REDUCED</p><p>SLEEP - REDUCED</p><p>PERSPIRATION; INCREASED</p><p>PLAYFULL</p><p>BIRTH WEIGHT ; 3.2KG</p><p>NORMAL DELIVERY</p><p>MOTHER HAD GESTATIONAL DIABETES</p><p>DELAYED WALKING @ 1.5 YRS...OTHERS ON TIME</p><p>H/O LEG PAIN DIAGNOSED AS VIT DEFICIENCY</p><p><br></p><p><br></p><p><br></p><p><br></p>',_binary '<p>18/11/21</p><ol><li>CALC PHOS 6 X - 2 TDS</li><li>ACID PHOS 200- 3 TDS</li><li>ARNICA HAIR OIL</li><li>ARNICA SHAMPOO</li></ol>','0001-01-01 00:00:00'),(17,17,_binary '<p>18/11/21</p><p>HAIRFALL SINCE ONE YEAR</p><p>MENSES IRREGULAR AT TIMES</p><p>LMP ; 3/11/21</p><p>SEVERE BLEEDING, LASTS 9 DAYS</p><p>LEUCORRHOEA SINCE SOME DAYS</p><p>BOWELS REGULAR</p><p>DESIRES CHOCOLATE</p><p>PERSPIRATION - OFFENSIVE FULL BODY</p><p>SLEEP GOOD</p><p>APETITE REDUCED</p><p><br></p><p>MIND---ANXIETY,</p><p>TENSION EASILY</p><p>DOESNT SHARE</p><p>HUSBAND ABROAD</p>',_binary '<p>18/11/21</p><ol><li>THUJA 30 - 2 DOSES</li><li>ACID FLUOR 30 - 3 TDS</li><li>WEISBADEN 30 - 4 TDS</li></ol>','0001-01-01 00:00:00'),(18,18,_binary '<p>18/11/21</p><p>FEVER SINCE MORNING</p><p>NO ISSUES IN FEEDING</p><p>NOT PLAYFUL</p><p>VOMITED 4 TIMES SINCE MORNING</p><p>HAD SEVERE FEVER @ MORNING</p><p><br></p><p>23/11/21</p><p>COUGH AND COLD</p><p>COUGH &lt; NIGHT</p><p>DRY TYPR COUGH AT NIGHT</p><p>BOWELS N URINE NORMAL</p><p>BT WT ; 3KG</p><p>NOW WEIGHT ; 6.4KG</p><p><br></p><p>18/ 1/22</p><p>FEVER SINCE MORNING</p><p>NO OTHER ISSUES</p><p>19/3/22</p><p>FEVER REDUCED DAY TIME INCREASING BY EVENING</p><p>ACTIVE SLIGHTLY ONLY</p><p>IF FEVER PERSISTS CHECH FOR TC DC ESR CBC URINE R/E</p><p><br></p><p>24/3/22</p><p>SLIGHT FEVER WITH COUGH AT MORNING</p><p>10/6/22</p><p>SLIGHT FEVER SINCE  MORNING </p><p>NO COLD OR SLIGHT COUGH ONLY</p><p><br></p>',_binary '<p>18/11/21</p><ol><li>ARS ALB 30 3 PILLS 2 HRLY</li><li>BAPT 3 X - 3 DROPS / 2 HRLY</li><li>BELL 1 M - 2 DOSES</li></ol><p>23/11/21</p><ol><li>PULS 200 IN KS 6X -2 TDS</li><li>PULS 10M - 1 DOSE AT NIGHT</li><li>SANGUNARIA C 200 3PILLS TDS</li></ol><p>18/1/22</p><ol><li>BELL 200 3 PILLS 2 HRLY</li><li>BAPT 3X - 10ML - 4 DROPS 2 HRLY</li><li>BELL - 1M - 2 DOSES SOS</li></ol><p>19/1/22</p><ol><li>BELL 1M - 4 DOSES</li><li>BRY 200 - 3 PILLS 2 HRLY</li><li>PYROGEN 200 - 2 DOSE BD</li></ol><p>24/3/22</p><ol><li>BELL 200 - 1 DRM PILLS</li><li>RHUSTOX 200 - 1 DRM PILLS</li><li>GIVE BAPT DROPS AND BELL 1M SOS IF HIGH FEVER</li></ol><p>10/6/22</p><ol><li>BRY 200 - 1 DRM PILLS</li><li>BAPT 3X - 5ML - 3 DROPS 2 HRLY</li><li>BELL1M - SOS - THEY HAVE</li></ol>','2022-06-17 00:00:00'),(19,19,_binary '<p>19/11/21</p><p>ALLERGY</p><p>SNEEZING CONTINOUSLY</p><p>&lt;DUST, HEAD BATH</p><p>&gt;SLEEPS AFTER</p><p>AFTER CONTONOUS SNEEZING WATERING NOSE STARTS</p><p>NO FAMILY HISTORY OF ALLERGY</p><p>REGULAR MENSES</p><p><br></p><p>3/1/21</p><p>SNEEZING &lt;TED AFTER TRAVELING TO COLD PLACE</p><p>WAS ON INHALERS</p><p>&lt;CLIMBING STAIRS REQUIRES INHALERS, ASTHMA ASCENDING WHEN</p><p>SNEEZING ONLY WHEN DUST IS INHALED</p><p>17/1/22</p><p>WAS BETTER FOR ALMOST 2 WEEK</p><p>SUDDENLY HAD BREATHING DISTRESS YESTERDAY AND TOOK INHALER.</p><p>DIDNT TAKE INHALER BEFORE THAT</p><p><br></p><p>SUDDENLY FELT LIKE THE NEED FOR INHALER</p><p>28/1/22</p><p>SENSATION OF PHLEGM IN THROAT</p><p>SNEEZING NOT PRESENT IN LAST 2 WEEKS NO SNEEZING</p><p>WHEEZING NOT SEEN IN LAST 10 DAYS</p><p>BREATHLESSNESS &lt;ASCENDING &lt;TALKING AND WALKING</p><p>NOT BREATHING EASILY</p><p><br></p><p>10/2/22.FEELING BETTER BY 90%</p><p>NEEDS MEDICINE FOR HAIRFALL</p><p>19/3/22</p><p>RELIEF FOR ALL SYMPTOMS</p><p>DANDRUFF ON HEAD WITH ITCHING</p><p>5/7/22</p><p>HAD WHEEZING DIFFICULTY LAST WEEK FROM NATIVE ONLY ONE DAY...FINE AFTER THAT</p><p>WEAKNESS AT EVENING</p><p>WHILE SITTING QUIET FEELS SLEEPY ALWAYS</p><p><br></p>',_binary '<p>19/11/21</p><ol><li>ARS ALB 10M - 1 DOSE</li><li>SABADILLA 4 BD</li><li>B24 - 3 TDS</li><li>ARS ALB 10M 3 DOSES (SOS)</li></ol><p><br></p><p>3/1/21</p><ol><li>TUB 10 M - 1 DOSE</li><li>ARS ALB 10M - 3 DOSE (SOS SNEEZING)</li><li>SABADILLA 30 2 DRM - 4 TDS</li><li>POTHOS Q - 20ML - 10 DROPS TDS</li></ol><p>17/1/22</p><ol><li>IODOFORM 3X - 14 TABLETS</li><li>SABADILLA 30 - 2DRM -4TDS</li><li>ARS ALB 10M - 1 DOSE TO TAKE ON 3.2.22</li><li>POTHOS Q - 20ML- 10 DROPS QID</li><li>LYSSIN 30 - 1 DOSE TONIGHT</li></ol><p>28/1/22</p><ol><li>POTHOS Q 20ML - 1O DROPS TDS</li><li>IODOFORM 3X {SOS} THEY HAVE</li><li>SABADILLA 30 4 TDS</li><li>KALIBICH 6X3DRM -3BD</li><li>TAKE ARSALB 10M - 1 DOSE ON 3/2/22</li></ol><p>10/2/22</p><ol><li>ARNICA HAIR OIL</li><li>BT 4 - 1 TAB AT NIGHT - 1/2 OUNCE BOTTLE</li></ol><p>5/7/22</p><ol><li>ARS ALB 10M - 1 DOSE</li><li>SABADILLA 30 - 2 DRM PILLS - 4 BD</li><li>POTHOS 10ML - 10 BD</li></ol><p><br></p>','2022-02-02 00:00:00'),(20,20,_binary '<p>19/11/21</p><p>SLIGHT RATTLING WITH NASAL CONGESTION</p><p>RESTLESS +++</p><p>C/O VIT DEFICIENCY</p><p>LOSS OF APETITE</p><p>PASSES MOTION IMMEDIATELY</p><p>MILE STONES TIMELY</p><p>BOWELS ; MOTION FREQUENTLY</p><p><br></p><p>26/11/21</p><p>FEVER AT TIMES</p><p>SLIGHTLY IRRITABLE</p><p>INTERMITTANT</p><p>TEMP ; 98.2</p><p><br></p>',_binary '<p>19/11/21</p><ol><li>CALC PHOS 6X - 2 TDS</li><li>PULS 200 - 3 TDS</li><li>CALC PHOS 10M - 1 DOSE</li></ol><p>26/11/1/21</p><ol><li>PULS 200 2 PILLS 2 HRLY</li><li>BAPTISIA 3X - 3 DROPS 2 HRLY</li><li>EUCALYPTUS Q</li><li>BELL 1M - 2 DOSES (SOS)</li></ol>','0001-01-01 00:00:00'),(21,21,_binary '<p>19/11/21</p><p>SPARIN ANKLE..PAINFUL</p><p>ANEMIC</p><p>HYPOTENSION</p><p><br></p><p>22/11/21</p><p>NO RELIEF FOR PAIN</p>',_binary '<p>19/11/21</p><ol><li>RHUS TOX 1M - 2 DOSES</li><li>ARNICA 200 - 3 PILLS 2 HRLY</li><li>RHUSBTOX OINTMENT</li></ol><p><br></p><p>22/11/21</p><p>1.BRY Q - 5ML- 10 TDS - 2 DAYS</p><p><br></p>','0001-01-01 00:00:00'),(22,22,_binary '<p>19/11/21</p><p>FEVER SINE MORNING</p><p>COUGH</p>',_binary '<p>19/11/21</p><ol><li>BAPT 3X - 10 DROPS</li></ol><p>        2.RHUSTOX 30 3 PILLS 2 HRLY</p><p>       3.RHUS TOX 1 M - 2 DOSES</p>','0001-01-01 00:00:00'),(23,23,_binary '<p>22/11/21</p><p>PAIN IN KNEE JOINTS</p><p>&lt;NIGHT</p><p>&lt;MORNING WAKING ON</p><p>OSTEOARTHRITIS SUGGESTED OPERATION</p><p>SURGERY DONE FOR THYROID</p><p>F/H OF SAME COMPLAINT</p><p>TAKING MEDICINE FOR CHOLESTROL</p><p>&gt;SLIGHT MOVEMENT</p>',_binary '<p>22/11/21</p><ol><li>BRY Q - 10 DROPS TDS</li><li>RHUS TOX 1M - 4 TDS</li><li>SYPH 10M - 1 DOSE STAT</li><li>CALC FLUOR 6X - 3TDS</li></ol><p><br></p><p>RX PLAN ; CAUST 10M ONE DOSE MONTHLY AS WATER DOSE</p><p>BRY 200 BD</p>','0001-01-01 00:00:00'),(24,24,_binary '<p>22/11/21</p><p>HEEL PAIN SINCE ONE MONTH</p><p>&lt;MORNING</p><p>&gt;AFTER SLIGHT WALKING</p><p>H/O BREAST REMOVED AFTER CA</p><p>BP; 150/90</p><p>DESIRES ACIDS AND PICKLES</p><p><br></p>',_binary '<p>22/11/21</p><ol><li>PULS 10M - 1 DOSE</li><li>CALC PHOS 200 - 4 TDS</li><li>B24 2TDS</li></ol>','0001-01-01 00:00:00'),(25,25,_binary '<p>22/11/21</p><p>RATTLING COUGH EVERYTIME</p><p>ESP &lt;WINTER</p><p>DESIRES NON VEG</p><p>PERSPIRES A LOT</p><p>FEAR OF DEATH</p><p>COUHG NIGHT &lt;12 AM</p><p>PHLEGM - WHITE</p><p>AT TIME YELLOWISH</p><p>O/E </p><p>TONSILS ENLARGED</p><p>NOSE - TURBINATES SWOLLEN</p><p>?POLYP</p>',_binary '<p>22/11/21</p><ol><li>NAT SULPH 6X 3 TDS</li><li>GRINDELIA Q - 10 DROPS TDS</li><li>PULS 10M - 1 DOSE STAT</li></ol><p><br></p>','0001-01-01 00:00:00'),(26,27,_binary '<p>24/11/21</p><p>ALLERGY</p><p>SNEEZING</p><p>COUGH DRY</p><p>&lt;DUST</p><p>&lt;MORNING</p><p>NO OTHER ISSUES</p><p>?SLIGHT ACANTHOSIS NIGRICANS</p><p>30/12/21</p><p>&lt;ALLERGY DECREASED WHILE TAKING MEDICINE</p><p>GASTRIC ISSUES DURING WEEKLY ONCE</p><p>CAUSES GIDDINESS</p><p>&lt;NIGHT</p><p>ALL ISSUES STARTED DURING PREGNANCY</p><p>MENSES; DELAYED BY 1 WEEK FROM 3 MONTHS</p><p>BOWELS ; REGULAR</p><p>THIRST ; ++</p><p>PERSPIRATION ; ++FACE AND HEAD</p><p>SLEEP ; GOOD</p><p><br></p><p>21/2/22</p><p>LAST MONTH SNEEZING WAS SEVERE AS BEFORE IN SPITE OF TAKING MEDICINE</p><p>SNEEZING&lt; MORNING NOT MUCH AT NIGHT NOW</p><p><br></p><p>28/2/22</p><p>NO RELIEF FOR SNEEZING NOW</p><p>STRETCH TEST +VE,,TENIA?</p><p>SNEEZING &lt;MORNING</p><p>7/3/22</p><p>ITCHING AND SNEEZING REDUCED</p><p>HAD SEVERE ITCHING AT NIGHT</p><p>SNEEZING REDUCED VERY MUCH</p><p>15/3/22</p><p>ITCHING REDUCED INITIALLTY AND NOW SPREADING SND INCREASED ITCHING</p><p>SPREADING TO OTHER HAND</p><p>10/6/22</p><p>SKIN COMPLAINTS ALL BETTER NOW</p><p>SNEEZING ALSO BETTER</p><p>GASTRIC ISSUES SINCE 1 WEEK</p><p>HUNGRY EVEN AFTER FOOD, BOWELS REGULAR</p>',_binary '<p>24/11/21</p><ol><li>ARS ALB 10M - 1 DOSE</li><li>ARS ALB 10 M - 3DOSES (SOS)</li><li>SABADILLA 30 - 4 BD</li><li>B24 - 2 TDS</li></ol><p><br></p><p>20/11/21</p><ol><li>TUB 10M- 1 DOSE</li><li>SABADILLA 30 - 2 DRM PILLS</li><li>B24 - 1/2 OUNCE - 2TDS - 30ML BOTTLE</li><li>ARS ALB 10M - 3 DOSES (SOS)</li><li>ZINGIBER Q -10 DROPS TDS AFTER FOOD</li></ol><p>21/2/22</p><ol><li>ARS ALB 10M - 1 DOSE NEXT MONDAY 28/2</li><li>ARS ALB 10 M - 3DOSES (SOS)</li><li>SABADILLA 30 - 4 BD</li><li>POTHOS Q - 10ML - 15 TDS</li><li>TUBERCULINUM 10M - 1 DOSE TONIGHT</li></ol><p>28/2/22</p><ol><li>BACILLINUM 10M - 1 DOSE</li><li>TEUCREUM 200 - 2 DRAM PILLS - 4 TDS</li><li>CHRYSORBINUM OINTMENT</li></ol><p><br></p><p>7/3/22</p><ol><li>CHRYSORBINUM OINTMENT</li><li>TEUCREUM 200 - 4 QID</li><li>CALENDULA SOAP</li><li>BACILLINUM 10 M - 2 DOSE WEEKLY</li><li>ALLIUM CEPA 30 2 DRM PILLS SOS</li></ol><p>15/3/22</p><ol><li>SEPIA 30 4 TDS</li><li>TEUCREUM 200 - 4 QID</li></ol><p>10/6/22</p><ol><li>ZINGIBER Q - 10ML 10 TDS AFTER FOOD</li></ol>','2022-03-07 00:00:00'),(27,26,_binary '<p>24/11/21</p><p>FEVER SINCE YESTERDAY NIGHT</p><p>THROAT PAIN</p><p>&lt;AFTER DRENCHING IN RAIN</p><p>H/O TONSILLITIS</p><p>SEVERE HEADACHE</p><p>CONTINOUS VOMITING YESTERDAY NIGHT</p><p>WATERING RUNNING NOSE</p><p>FEVER - 99.6</p><p>SHIVERING AT NIGHT</p><p>BODY PAIN+++</p>',_binary '<p>24/11/21</p><ol><li>BAPT 3X - 20ML - 10 DROPS 2 HRLY</li><li>RHUS TOX 1M - 1 DOSE NOW</li><li>EUPTORIUM 200 IN FP 6X</li><li>BELL - 1M - 2 DOSE(SOS FEVER)</li></ol>','0001-01-01 00:00:00'),(28,29,_binary '<p>26/11/21</p><p>LOSS OF APETITE</p><p>DOESNT EAT PROPERLY</p><p>SNORRING AT NIGHT</p><p>BOWELS REGULAR</p><p>20/7/22</p><p>TONSILS ENLARGED</p><p>COUGH AT TIMES</p>',_binary '<p>26/11/21</p><ol><li>LYCO 0/3 - 3 DOSE - WEEKLY ONCE</li><li>CARICA PAPAYA Q - 5 DROPS TDS</li><li>CALC PHOS 6X - 2 TDS</li><li>ALFA ALAFA SYRUP - 1TSP BEFORE MEALS</li></ol><p>21/7/22</p><ol><li>HEP SULPH 200 - 2 DRM PILLS</li><li>PULS 200 - 2 DRM PILLS</li><li>GRINDELIA Q - 200ML - 10 TDS..<span style=\"color: rgb(230, 0, 0);\">PAYMENT ADDED WITH RENZA</span></li></ol>','0001-01-01 00:00:00'),(29,30,_binary '<p>26/11/21</p><p>FUNGAL ERUPTIONS ON BACK OF THIGH</p><p>DRY SIKN</p><p>COMPLAINTS SINCE 4-5 MONTHS</p><p>LOSS OF APETITE AFTER ONLINE CLASSES</p><p>BOWELS - REGULAR</p>',_binary '<p>26/11/21</p><ol><li>SEPIA 10M - 4 DOSE - WEEKLY ONCE</li><li>CHRYSORBINUM OINTMENT</li><li>KALI MUR 6X - 2 TDS -3 DRM BOTTLE</li></ol>','0001-01-01 00:00:00'),(30,31,_binary '<p>26/11/21</p><p>NOSE BLOCKED COMPLETELT</p><p>VERY DIFFICULT TO BREATHE</p><p>NO COUGH</p><p>25/3/22</p><p>DRY COUGH SINCE SOME DAYS</p><p>SINCE YESTERDAY SOME PRICKING TYPR OF COUGH</p><p>DYSPNEA</p><p>H/O HOSPITAL ADMISSION AFTER PNEUMONIA AT CHILDHOOD</p><p>O/E TONGUE CLEAN</p><p>THROAT TONSILS PAINFUL BOTH SIDES</p><p>SLIGHTLY CONGESTED</p><p>HAD TAKEN COOLD DRINKS FROM FRIDGE</p><p><br></p>',_binary '<p>26/11/21</p><ol><li>SAMBUCUS 1 DRM PILS</li><li>PULS 200 - 2 DRM PILLS</li></ol><p>25/3/22</p><ol><li>BAPT 3X+PHYTOLACCA Q - 10ML</li><li>IPECAC 30 - 2 DRM PILLS</li><li>BRY 200 - 2 DOSE BD</li></ol>','0001-01-01 00:00:00'),(31,32,_binary '<p>27/11/21S</p><p>TINNITIS SINCE 10 YEARS</p><p>HAD TAKEN HOMEO TREATMENT FOR 10YR WITHOUT RELIEF</p><p>GASTRITIS &lt;OILY FOOD</p><p>&lt;SOME FOOR CAUSES ERUCTATIONS</p><p>BOWELS - REGULAR</p><p>THIRST - NORMAL</p><p>MIND - SUSPICIOUS </p><p>MISERY</p><p>PHYSIQUE - INCREASED HAIR GROWTH ON BODY HAIR ON EARS</p><p>HYPOTENSION - ALWAYS</p>',_binary '<p>27/11/21</p><ol><li>ROBINIA Q - 10 DROPS TDS</li><li>NUX VOM - 3- 4 TDS</li><li>SYPHILINNUM 10M - 1 DOSE</li></ol>','0001-01-01 00:00:00'),(32,33,_binary '<p>27/11/21</p><p>STEEL WORKER</p><p>HEADACHE SINCE MORNING</p><p>HAD COLD FEW DAYS BACK</p>',_binary '<p>27/11/21</p><ol><li>SANGUNARIA Q - 10 DROPS 2 HRLY</li><li>SIL 1M + KALI BICH 1M</li></ol>','0001-01-01 00:00:00'),(33,34,_binary '<p>27/11/21</p><p>INJURY ABOVE EYE</p><p>TAKING MEDICINE FOR BP CHOLESTROL</p><p>PAIN IN HANDS AFTER STROKE, AT RIGHT HAND</p><p>VARICOSE VEINS PAINFUL</p><p>3/12/21</p><p>THYROID INITIALLY ON THYRONORM 100MG</p><p>BP</p><p>STROKE</p><p>ALL SINCE 4 YEARS</p><p><br></p><p>28/2/22</p><p>POST COVID ISSUES</p><p>WEAKNESS AFTER COVID SLEEPS MORE</p><p>BODY PAIN PERSISTING</p><p>APETITE GOOD</p><p>14/3/22</p><p>WEAKNESS REDUCED</p><p>PAIN IN RIGHT SHOULDER</p><p>RADIATING TO BACK</p><p>&lt;LIFTING HAND ABOVE HEAD CAUSES PAIN</p><p>20/4/22</p><p>PAIN SLIGHTLY REDUCED WHILE TAKING MEDICINE</p><p>NOW PAIN STARTED WHEN MEDICINE GOT OVER</p>',_binary '<p>27/11/21</p><ol><li>RUTA 1M - 2 DOSE BD</li><li>ARNICA 200 2 PILLS 2HRLY</li></ol><p>3/12/21</p><ol><li>CAUSTICUM 10M - 1 DOSE IN HALF GLASS WATER 2 HRLY</li><li>KALI PHOS 6X - 3 TDS - 3 DRM TABLETS</li><li>BRY 200 - 4 BD</li></ol><p>28/2/22</p><ol><li>RHUS TOX 1M - 2 DOSES BD</li><li>ACID PHOS 200 - 1/2 OUNCE TAB - 3 TAB TDS</li><li>EUPATORIUM Q - 20ML - 15TDS</li></ol><p>14/3/22</p><ol><li>CAUSTICUM 10M - 2 DOSES WEEKLY ONCE</li><li>BRY 200 - 2DRM PILLS - 4TDS</li><li>ARNICA 200 - 2 DRM PILLS - 4 TDS</li></ol><p>20/4/22</p><ol><li>CAUSTICUM 10M - 2 DOSES WEEKLY ONCE</li><li>BRY 200 - 2DRM PILLS - 4TDS</li><li>ARNICA 200 - 2 DRM PILLS - 4 TDS</li></ol><p><br></p>','2022-03-10 00:00:00'),(34,35,_binary '<p>27/11/21</p><p>SKIN COMPLAINTS SINCE MANY YEARS</p><p>DRY SKIN SCALY WITH ITCHING</p><p>DRY ECZEMA WATERY DISCHARGE</p><p>=PROSTATE ENLARGEMENT , ON PROSTANUM SINCE 2 YEARS</p><p>ASYMPTOMATIC</p><p>= FATTY LIVER</p><p>=DIABETIC , ON INSULIN THERAPY SINCE 30 YEARS</p><p>=HYPERTENSION , IN EYES ?GLUCOMA ON AYURVEDIC TREATNENT FOR SAME ?DIBETIC RETINOPATHY</p><p>=DIZZINESS .POSITIONAL VERTIGO STANDING ON ONE LEG CAUSES VERTIGO</p><p>3/12/21</p><p>AS PER USG GRADE 1 ENLARGEMENT OF PROSTATE</p><p>=GRADE 2 FATTY INFILTERATION OF LIVER</p><p>= DEEP CRACKS WITH MOIST ON LEGS</p><p>ITCHING ON HEAD LEGS</p><p>22.1.22-----REQUIRES PROSTNUM ASSISTANT CAME TO COLLECT</p><p>28/2/22</p><p>DIABETES NOT CONTROLLED BY INSULIN INTAKE,,STOPPED METFORMIN TABLETS FOR DIABETES</p><p>NEEDS MEDICINE FOR DIABETES</p><p>NEEDS PROSTANUM</p><p><br></p><p><br></p><p>22/1/22....REQUIRES PROSTANUM DROPS</p><p>28/2/22-----REQUIRES MEDICINE FOR PROSTATE AND DIABETES</p><p>C/0 ERECTILE DYSFUNCTION</p><p><br></p><p>14/3/22</p><p>REQUIRES MEDICINE FOR DIABETES...NOT FELT MUCH CHANGE WITH LAST MEDICINE</p><p><br></p><p>1/4/22</p><p>REQUIRES MEDICINE DIABETES..SEEN SLIGHT REDUCTION IN SUGAR LEVEL SINCE 2 DAYS</p><p>20/4/22</p><p>DIABETES GETTING CONTROLLED</p><p>9/5/22</p><p>DIABETES CONTROLLED</p><p>27/5/22</p><p>NEEDS ALL MEDICINE</p>',_binary '<p>27/11/21</p><ol><li>PL ONE DOSE AT NIGHT</li><li>KALI MUR 6X 3 TAB TDS</li></ol><p>3/12/21</p><ol><li>PETROLEUM 30 1 DOSE</li><li>PL 1 DRM PILS 4 BD</li><li>KALI MUR 6X 3 TDS</li><li>ECHINACEA Q - 20ML- 10 TDS</li><li>BORO ALLEN OINTMENT FOR EA</li></ol><p>22/1/22</p><ol><li>SABAL SERR Q - 20ML - 10 DROPS BD</li><li>PULS 200 - BD - 1/2 OUNCE BOTTLE</li><li>PROSTANUM DROPS - 2 BOTTLE</li></ol><p><br></p><p>28/2/22</p><ol><li>SABAL SERR Q - 20ML - 10 DROPS BD</li><li>SYZYGIUM Q - 20ML - 15 DROPS TDS AFTER FOOD</li><li>PANCREATIN 6C - 10ML - 3DROPS TDS BEFORE FOOD</li><li>SYPH 10M - 1 DOSE</li><li>NAT SULPH 6X - 3 TDS - 1/2 OUNCE</li></ol><p>2/3/22-----PROSTUM DROPS 2</p><p><br></p><p>14/3/22</p><ol><li>SABAL SERR Q - 20ML - 10 DROPS BD</li><li>CEPHALANDRA Q - 20ML - 15GTT TDS</li><li>NAT PHOS 6X - 1/2 OUNCE 3 TDS</li></ol><p><br></p><p>1/4/22</p><ol><li>SABAL SERR Q - 20ML - 10 DROPS BD</li><li>CEPHALANDRA Q - 20ML - 15GTT TDS</li><li>NAT PHOS 6X - 1/2 OUNCE 3 TDS</li><li>PANCREATIN 6C - 10ML - 3DROPS TDS BEFORE FOOD</li></ol><p>20/4/22</p><ol><li>SABAL SERR Q - 20ML - 10 DROPS BD</li><li>CEPHALANDRA Q - 20ML - 15GTT TDS</li><li>NAT PHOS 6X - 1/2 OUNCE 3 TDS</li><li>PANCREATIN 6C - 10ML - 3DROPS TDS BEFORE FOOD</li></ol><p>9/5/22</p><ol><li>SABAL SERR Q - 20ML - 10 DROPS BD</li><li>CEPHALANDRA Q - 20ML - 15GTT TDS</li><li>NAT PHOS 6X - 1/2 OUNCE 3 TDS</li><li>PANCREATIN 6C - 10ML - 3DROPS TDS BEFORE FOOD</li></ol><p>27/5/22</p><ol><li>SABAL SERR Q - 20ML - 10 DROPS BD</li><li>CEPHALASNDRA Q - 20ML - 15GTT TDS</li><li>NAT PHOS 6X - 1/2 OUNCE 3 TDS</li></ol><p><br></p><p><br></p>','2022-05-23 00:00:00'),(35,37,_binary '<p>1/12/21</p><p>ITCHING RASHES ON LEG SINCE ONE MONTH</p><p>WAS ON ALLOPATHIC TREATMENT.NOW STOPED AND THEN STATED AGAIN</p><p>RT LEG OSTEOATHRITIS OF KNEE</p><p>FBS ; 121mg ldl</p><p>PPBS ; 135mgldl</p><p>total cholestrol -264 mgldl</p><p>triglycerides ; 119mg/dl</p><p>HDL ; 51 mg/dl</p><p>LDL;189 mg/dl</p><p>VLDL ; 23 MG/DL</p><p>URIC ACID ;7.7mg/dl</p><p>TSH ;0.084 mg/dl</p><p>wt - 83kg</p><p>BMI- 39.5</p><p>BOWELS- REGULAR</p><p>THIRST - N</p><p>THERMAL ; HOT</p><p>SLEEP; GOOD</p><p><br></p><p>MENOPAUSE ; 1 YEAR BACK</p><p>C.SECTION ;1</p><p>NORMAL DELIVERY ; VBAC REST -2</p><p><br></p><p>14/12/21</p><p>RING WORM INFESTATIONS</p><p>ITCHING PRESESNT</p><p>ADV THYROID PROFILE WITH URIC ACID AFTER 2 WEEKS</p><p>AVOID FOOD CONTAINING VIT C </p><p>DRINK PLENTY OF WATER</p><p>HIGH PROTIEN CONTENT FOOD SHOULDNT BE TAKEN</p>',_binary '<p>1/12/21</p><ol><li>URTICA URENS Q - 10 DROPS TDS</li><li>NAT MUR 200 - 4 BD</li><li>PITUITARY 30 - 4 BD</li></ol><p>14/12/21</p><ol><li>SEPIA 200 - 2 DOSE WEEKLY</li><li>ACID BENZ 30 - 2 DRM </li><li>ACTEA SPICATA 30 - 4 PILLS TDS</li><li>URTICA URENS Q - 15 GTT TDS</li><li>CHRYSORBINUM OINTMENT</li></ol>','0001-01-01 00:00:00'),(36,38,'','','0001-01-01 00:00:00'),(37,39,_binary '<p>4/12/21</p><p>RIGHT SIDED WHEEZING</p><p>H/O FEED ASPIRATED</p><p>WARMTH ON HEAD</p><p>O/E COUGH WITH EXPECTORATION SLIGHTLY</p>',_binary '<p>4/12/21</p><ol><li>BRY 200 1 DOSE- WA\\TER DOSE</li><li>GRINDELIA Q 5 TDS IF SEVERE 2 HRLY</li></ol><p><br></p><p>5/12/21</p><ol><li>BRY 200 2 DRM PILLS 2 HRLY</li><li>NS 6X - 2 DRM- 1 TAB QID</li><li><br></li></ol>','0001-01-01 00:00:00'),(38,40,_binary '<p>8/12/21</p><p>COLD AND COUGH SINCE MANY DAYS</p><p>RIGHT SIDED BLOCKED</p><p>RIGHT SIDED THROAT PAINFUL</p><p>PHLEGM GREENISH IN COLOR</p><p>COUGH ALWAYS</p><p>PRICKING IN THROAT</p><p>O/E TONSILS ENLARGED ON BOTH SIDES</p><p>DRY</p><p>THIRST ; N</p><p><br></p><p>9/12/21</p><p>GOT FEVER NEED MEDICINE</p><p>11/12/21</p><p>FEVER SLIGHTLY REDUCED</p><p>COUHG DRY CONTINOUS</p><p>30/5/22</p><p>REGULAR MENSES</p><p>AMENORRHOEA SINCE 4- 5 MONTHS</p><p>HISTORY OF URIC ACID</p><p>SENSATION OF MENSES GETTING MENSES</p><p>LEUCOORHOEA SLIGHTLY PRESENT</p><p>13/6/22</p><p>GOT MENSES TODAY</p><p>18/7/22</p><p>NEEDS MEDICINE TO CORRECT MENSES</p>',_binary '<p>8/12/21</p><ol><li>NAT SULPH 1M - 1 DOSE NOW</li><li>TULSI VASAKA - 1 SPOON TDS</li><li>PULS 200 - IN KS 6X 2 TAB 2 HRLY</li><li>BELL 200 - 2 DRM PILLS 2 HRLY</li><li>ECHINACEA Q - 10 DROPS 2 HRLY</li></ol><p>9/12/21</p><ol><li>BELL 1M - 6 DOSES BD (SOS FEVER)</li><li>VERAT VIRIDE Q - 10 DROPS</li><li>BAPT 3X- 10 DROPS 2 HRLY</li></ol><p>18/</p><p>11/12/21</p><ol><li>ARS IOD 6X - 4 BD 2 WEEKS</li><li>PHOS 30 - 2DRM PILLS</li><li>ARALIA R Q - 10 DROPS QID</li><li>PYROGEN 200 - 1 DOSE</li></ol><p>30/5/22</p><ol><li>PULS 10M - 2 DOSE WEEKLY ONCE</li><li>ASOKA Q - 30ML - 15 TDS</li><li>FERR PLUS - 15 TABLETS -HS 1</li></ol><p>13/6/22</p><p>CONTINUE ASOKA Q AS 10 DROPS BD INFORM WHEN ,MENSES GETS OVER</p><p>18/6/22</p><ol><li>ASOKA Q - 30ML - 10 BD</li><li>ERYTROFIL SYRUP - 1 -10ML BD</li><li>PULS 200 4 BD - 2 DRM PILLS</li></ol><p>SYRUP GIVEN</p>','2022-05-30 00:00:00'),(39,41,_binary '<p>9/12/21</p><p>ITCHING ERUPTIONS</p><p>FEAR OF DOG</p><p>&lt;NIGHT</p><p>OOZING OF WATERING</p><p>SCAB FORMING WITH</p><p><br></p><p>19/5/22</p><p>FEVER WITH VOMITING</p><p>VOMITED MANY TIMES SINCE MORNING</p><p>VOMITS AS IT IS TAKEN</p>',_binary '<p>9/12/21</p><ol><li>MERC SOL 1M - 1 DOSE AT NIGHT</li><li>PL - 1 DRM - 4 BD</li><li>B24 - 2 DRM - 3 BD</li></ol><p>19/5/22</p><ol><li>ARS ALB 200 - 1 DOSE</li><li>ARS ALB 200 - 2 DRAM PILLS - 3 PILLS 2 HRLY</li><li>BAPTISIS 3X - 10ML - 8 DROPS 2 HRLY</li></ol>','2022-05-23 00:00:00'),(40,42,_binary '<p>10/12/21</p><p>LARGE PEDUNCULATED SKIN TAGS ON AXILLA</p><p>AROUND THE NECK ALSO WITH SLIGHT ITCHING</p><p>FUNGAL INFECTIONS WITH</p><p><br></p>',_binary '<p>10/12/21</p><ol><li>BACILLINUM 10M - 1 DOSE</li><li>SILICEA 6X - 2 TDS</li><li>THUJA 30 - 1BD</li><li>ACID SALICYLIC Q - 5ML - TO APPLY EXTERNALLY</li></ol>','0001-01-01 00:00:00'),(41,43,_binary '<p>10/12/21</p><p>HAEEMORRHOIDS SINCE 1 WEEK</p><p>PAINFULL SLIGHT SWELLING NOW</p><p>DIABETIC SINCE 11 YEARS</p><p>CONSTIPATION</p><p>&lt; GASTRITIS</p><p>&lt;AFTER PASSING STOOLS</p><p>DESIRES ; FISH BEEF</p><p>THIRST ; ++</p><p>BURNING</p><p>ACIDITY </p><p>HEART BURN &lt; COCONUT</p><p>CRACK IN THE MIDDLE OF TONGUE</p>',_binary '<p>10/12/21</p><ol><li>Y LAX - 2 TABLETS AT NIGHT</li><li>NUX VOM 30 - 4 QID</li><li>RATANHIA 30 IN NP 6X 4 TDS</li><li>NUX VOM 10M - 1 DOSE</li></ol>','0001-01-01 00:00:00'),(42,44,_binary '<p>10/11/21</p><p>WHIT PATCH ON FACE</p><p>WHITE FLAKES ON HEAD</p><p>ON THYRONORM 75 MG</p><p>HYPOTHYROIDISM BY BIRTH ITSEF</p><p>ABSENCE OF THYROID GLAND BY BIRTH</p><p>H/O PNEUMOTHORAX</p><p><br></p>',_binary '<p>10/12/21</p><ol><li>BACILLINUM 10M - 1 DOSE</li><li>NM 6X - 4 BD [2 3 DRM BOTTLES]</li></ol><p>  1, 4-0-0</p><p>2,0-0-4</p>','0001-01-01 00:00:00'),(43,45,_binary '<p>13/12/21</p><ol><li>COUGH SINCE 1 WEEK</li><li>COUGH WITH PHLEGM</li><li>NOSE BLOCKED &lt;MORNING &lt;NIGHT</li><li>COUGH WITH EXPECTORATION YELLOW</li><li>&lt;COLD WEATHER CANNOT TOLERATE</li><li>COUGH WITH EXPECTORATION</li><li>O/E WHITE COATED TONGUE</li></ol><p>26/1/22</p><p>NOSE BLOCKED AT TIMES</p><p>SHYNESS++</p><p>?NASAL POLYP ON RIGHT SIDE</p><p>CLEAN TONGUE </p><p>30/6/22</p><p>FEVER FEW DAYS BACK</p><p>NOW WEAKNESS,</p><p>HEADAACHE IN FRONTAL PORTION &lt;NIGHT</p><p>FEVER CURED SINCE 2 DAYS</p><p>WEAKNESS WITH FEVER</p><p>DESIRES HOT WATER</p><p><br></p>',_binary '<p>13/12/21</p><ol><li>PULS 10M - 2 DOSES 2 WEEKLY NIGHT</li><li>EUCALYPTUS + GRINDELIA TINCTURE - 15 DROPS QDS</li><li>RUMEX 200 ALTERNATE WITH 4. HEP SULPH 200 2 HRLY</li></ol><p>26/1/22</p><ol><li>LEMNA MINOR Q - 20ML - 15 DROPS QID</li><li>NASAL DROPS </li><li>KALI BICH 6X - 1 TDS - 1/2 OUNCE</li><li>CALC CARB 1M - 3 DOSE WEEKLY ONCE</li></ol><p>30/6/22</p><ol><li>BAPTISIA Q - 10ML - 10TDS</li><li>BELL 200 - 4 TDS</li><li>BELL 1M - 3 DOSE</li></ol>','0001-01-01 00:00:00'),(44,46,_binary '<p>13/12/21</p><ol><li>ALLERGY</li><li>ITCHING IN EYES</li><li>SNEEZING &lt;WINTER</li><li>&lt;COLD INTAKE</li><li>SNEEZING</li><li>H/O NASAL POLYP SAID BY ENT</li><li>ALWAYS GETS COLD AND RATTLING</li></ol><p>6/1/22</p><ol><li>ITCHING IN EYES PERSISTING</li><li>SLIGHT DIFFERENCE FELT</li><li>&lt;COLD WEATHER</li><li>PHLEGM COMING UP</li><li>COUHG AT TIMES</li><li>ITCHING  IN EYES</li></ol><p>1/2/22</p><ol><li>ITCHING IN EYES STARTED WHEN EYEDROPS GOT OVER</li><li>PHLEGM STILL STICKING ON TO THROAT DIFFICULT TO COME UP</li><li>WHEN ITCHING IN EYES STARTS,PUS COMES WITH REDNESS</li><li>SNEEZING REDUCED</li><li>ITCHING IN EYES IS MAIN ISSUE</li></ol>',_binary '<p>13/12/21</p><ol><li>EUPHRASIA EYE DROPS 2 IN EACH EYES</li><li>EUPHRASIA 30 - 2 DRM PILLS - 4 PILLS QID</li><li>BELL 30 - 2 DRM - 4 PILLS QID</li><li>PSOR SULPH - 2 DOSE - WEEKLY ONCE ONE DOSE</li></ol><p>6/1/22</p><ol><li>EUPHRASIA EYE DROPS</li><li>KALI BICH 1M - 2 DOSES BD</li><li>SILICEA 6X - 1/2 OUNCE - 3 TDS</li><li>PSOR -SULPH - 1 DRM TAB - 2 TAB WEEKLY ONCE</li><li>LEMNA MINORQ - 20 ML - 10 DROPS TDS</li></ol><p>1/1/22</p><ol><li>EUPHRASIA EYE DROPS</li><li>BELL 200 -2 DRM - 4 TDS</li><li>MERC SOL 200 - 2 DRM - 3 PILLS 2 HRLY SOS</li><li>MERC SOL 200 - 1 DOSE TONIGHT</li><li>EUCALYPTUS Q - 10ML - 10 TDS</li></ol>','0001-01-01 00:00:00'),(45,47,_binary '<p>14/12/21</p><p>ALLERGY SINCE 4 -5 YEARS</p><p>&lt;DUST ALLERGY</p><p>SNEEZING KITCHING</p><p>CAUSES ASTHMA IN WINTER</p><p>H/O INHALERS</p><p>ITCHING IN NOSE</p><p>WATERY NASAL DISCHARGE</p><p>LEFT SIDED NASAL POLYP</p><p>31/12/21</p><p>COMPLAINTS RELIEVED WHILE TAKING MEDICINES</p><p>COMPLETED THE COURSE</p><p>17/5/22</p><p>HAD SEVERE FEVER WITH RATTLING 1 WEEK BACK</p><p>SLIGHT NASAL DISCHARGE WITH NASAL IRRITATION SNEEZING</p><p>RATTLING HEARD BY MOTHER</p><p>WINTER &lt;TS ALL COMPLAINTS</p>',_binary '<p>14/12/21</p><ol><li>ARS ALB 10M - 1 DOSE</li><li>SABADILLA 30 - 4 TDS</li><li>LEM NA MINOR TINCTURE - 10 DROPS BD</li><li>ARS ALB 10 - 3 DOSES ( SOS FOR SNEEZING I HALF GLASS WATER 1 HRLY 1 SPOON)</li></ol><p><br></p><p>31/12/21</p><ol><li>SABADILLA 30 - 4 TDS</li><li>LEMNA MINOR Q - 10 DROPS TDS</li><li>TUB 10 - 1 DOSE 0N 14/1/22</li></ol><p>17/5/22\\</p><ol><li>ARS ALB 10M - 1 DOSE</li><li>SABADILLA 30 - 4 TDS</li><li>LEM NA MINOR TINCTURE - 10 DROPS BD</li><li>NAT SULPH 6X - 1/2 OUNCE B- 3TDS</li></ol><p><br></p>','2022-06-01 00:00:00'),(46,48,_binary '<p>17/12/21</p><p>ITCHING ALL OVER BODY SINCE 2 WEEKS</p><p>ITCHING WITH ERUPTIONS</p><p>&gt;BATHING</p><p>H/O GASTRIC ISSEUS</p><p>BOWELS REGULAR</p><p>PERSPIRATION . ++</p><p>&gt;COLD BATHING</p><p>21/12/21</p><p>ITCHING WAS NOT PRESENT ON THENIGHT THE POWDER WAS TAKEN, BUT THEN IT STARTED AGAIN, NO RELIEF AT ALL NOW</p><p>INCREASED SINCE TWO DAYS,</p><p>7/7/22</p><p>UNABLE TO EAT FOOD ON TIME FOR 10 DAYS DUE TO STAY AT HOSPITAL</p><p>HISTORY OF ULCER</p><p>BURNING IN STOMACH</p><p>ERUCTATIONS</p><p>BURNING IN STOMACH</p><p>EVEN AFTER EATING ITS SEVERE</p><p>HAD HIGH CHOLESTROL BEFORE</p>',_binary '<p>17/12/21 EVERT HRLY</p><p><br></p><ol><li>BACILLINUM 10M 1 DOSE AT NIGHT</li><li>BOVISTA 30 - 20ML- 5 DROPS IN HALF GLASS WATER</li><li>B25 -1 TDS 1/2 OUNCE BOTTLE</li></ol><p>21/12/21</p><ol><li>FAGO 30 - 2 DRAM PILLS - 4 PILLS 2 HRLY</li><li>SULPH 0/3 - 6 DOSE 1 IN 1/2 GLASS WATER 1 SPOON WVERY HRLY</li><li>ECHINACEAE TINCTURE 10 DROPS QDS</li></ol><p>7/7/22</p><ol><li>HYDRASTIS Q -10ML - 10 TDS</li><li>NUX VOM 30 - 2DRM PILLS - 4 TDS BEFORE FOOD</li><li>NAT PHOS 6X - 1/2 OUNCE - 3TDS</li><li><br></li></ol>','0001-01-01 00:00:00'),(47,49,_binary '<p>18/12/21</p><p>CRYINYS</p><p>RUNNING NOSE SINCE 2-3 DAY</p><p>BOWELS REGULAR</p><p>NO APPETITE</p><p>DRY COUGH AT NIGHT</p><p><br></p><p>13/1/22</p><p>LOSS OF APETITE SICE 4 DAYS</p><p>BOWELS SLIGHTLY CONSTIPATED</p><p>MILESTONES ON TIME</p><p>NORMSL DELIVERY. 3,6KG</p><p><br></p><p>14/2/22</p><p>LOSS OF APETITE</p><p>DOESNT EAT ANYTHING</p><p>KEEPS ON FEEDING</p><p>15/3/22</p><p>APETITE WAS BETTER</p><p>AGAIN APETITE LOST AFTER TAKING ANTIBIOTICS FOR FEVER AND RATTLING,HAD COUGH WITH EXPECTORATION</p><p>CRAVES UNDIGESTIBLE FOOD LIKE RAW RICE, RICE FLUOR</p><p>CONSTIPATION WHEN FOOD INTAKE IS LESS</p><p>24/3/22</p><p>BLOOD WAS LESS AT BIRTH</p><p>H/O URTICARIA AFTER POLIO VACCINATION</p><p><br></p><p>22/4/22</p><p>FEELING BETTER FOR APPETITE, BOWELS REGULAR</p><p>17/5/22</p><p>FEELING BETTER WITH MEDICINES,NEED MEDICINE</p><p>6/6/22</p><p>HARD  FREQUENT STOOLS A DAY ..UNSATISFACTORY</p><p>BLACK STOOLS</p><p>THIRSTLESS</p><p>&lt; AFTER EATING PASTRIES</p><p><br></p>',_binary '<ol><li>18/12/21</li><li>NUX VOM 30 ALTERNATE WITH CHAMOMILLA 2OO</li><li>BAPTISIA 3C -X - 5ML</li></ol><ul><li>8 DROPS QDS</li></ul><p>.JUSTICIA Q + ARALIA Q 5ML - 8 DROPS QID</p><p><br></p><p>13/1/22</p><ol><li>CARCA PAPAYA Q - 20ML- 5 DROPS TDS</li><li>ALUMINA 1M - 2 DOSE WEEKLY ONCE</li><li>CP 6X - 2TDS</li></ol><p>14/2/22</p><ol><li>ALFAALFA SYRUP</li><li>LYCO 0/3 10 DOSE - EMPTY STOMACH 1</li><li>CINA 30 - 1 DRAM - 4 BD</li></ol><p>15/3/22</p><ol><li>CALC CARB 1M - 2 DOSE WEEKLY ONCE</li><li>ALFAALFA SYRUP</li><li>ALUMINA 30 - FERR MET 3X - 2 TDS</li><li>2 DRM PILLS - 4 TDS</li></ol><p>24/3/22</p><ol><li>FERR MET 3X - 2 TDS</li></ol><p>22/4/22</p><ol><li>FERR MET 3X - 2 TDS</li></ol><p>17/5/22</p><ol><li>FERR MET 3X- 1/2 OUNCE- 2 BD</li></ol><p>6/6/22</p><ol><li>FERR MET 3X- 1/2 OUNCE- 2 BD</li><li>CARICA PAPAYA Q - 10ML - 5 DROPS TDS</li></ol><p><br></p><p><br></p>','2022-05-31 00:00:00'),(48,50,_binary '<p>18/12/21</p><p>ALLERGIC ISSUES</p><p>&lt; DUST</p><p>ITCHING IN EYES</p><p>SNEEZING CAUSE ASTHMA</p><p>DRY PRICKING COUGH</p><p><br></p><p>30/12/21</p><p>SNEEZING</p><p>WAS FEELING BETTER WHILE TAKING MEDICINE .</p><p>6/6/22</p><p>WAS NOT BETTER AFTER LAST MEDICINES..TAKEN ALLOPATHIC MEDICINES FOR 1 WEEK.</p><p>DIDNT GET WHEEZING WHILE TAKING MEDICINES</p><p><br></p><p>FEVER</p><p>LEFT TONSIL ENLARGED</p><p>AFTER EATING ICE CREAM YESTERDAY</p><p>19/2/22</p><p>NEEDS MEDICINE FOR ALLERGY...[SON CAME]</p><p>1/3/22</p><p>SNEEZING SEVERE SINCE 3 DAYS</p><p>&lt;MORNING DUST</p><p>MORE SNEEZING CAUSES WHEEZING</p><p>NO WHEEZING IN WINTER FROM GULF</p><p>ITCHING IN EYES</p><p>DIDNT FEEL MUCH CHANGE WITH LAST MEDICINE</p><p>CANNOT PPLYING OIL</p><p>BEAR ANYTHING COLD ON HEAD LIKE APPLYING OIL</p><p>&lt;HEAD SWEAT ALSO CAUSES SNEEZING</p><p><br></p><p>9/3/22</p><p>RELIEF FELT ONLY FOR 2-3 DAYS</p><p>INITIAL FEW DAYS SNEEZING SEVER AND THEN GRADUALLY REDUCED NOW SEVERE SINCE 2 DAYS</p><p><br></p><p>FINISHED LAST COURSE MEDICINE ...BUT BDIDNT FEEL MUCH CHANGE FOR SNEEZING WHILE TAKING MEDICINE</p><p>SEVERE SNEEZING SINCE 3 DAYS</p><p>&lt;MORNING</p><p>MORE SNEEZING CAUSES WHEEZING</p><p>CANNOT BEAR ANY THING COLD ON HEAD CANNOT PUT OIL ON HEAD</p><p>DIDNT HAVE ANY WHEEZING ISSUES WHILE STAYING IN GULF IN WINTER</p><p>&lt;HEAD SWEATING ALSO CAUSES SNEEZING</p><p>15/3/22</p><p>SNEEZING REDUCED</p><p>WHEEZING TAKING INHALERS</p><p>WHEEZING AT 3AM - 4AM</p><p>STARTS AS COUGH SND THEN WHEEZING</p><p>24/3/22</p><p>FEELING BETTER FOR WHEEZING</p><p>STARTED AFTER HEADBATH AT EVENING - WHEEZING</p><p>7/4/22</p><p>FEELING BETTER BUT TAKES SPRAY ONCE A DAY AT NIGHT</p><p>22/4/22</p><p>MEDICINES GOT OVER, INHALER ONCE A DAY</p><p>DRY COUGH SINCE FEW DAYS &lt;NIGHT AFTER SLEEP</p><p><br></p><p>2/5/22</p><p>REQUIRES MEDICINE NO COUGH NW</p><p>17/5/22</p><p>MEDICINES FINISHED</p><p>NO ISSUES NOW</p><p>23/5/22</p><p>COUGH SINCE 2 DAYS AFTER CHANGE OF WATER BATHING</p><p>COUGH &lt; NIGHT SLEEP ATER , NOT MUCH PHLEGM</p><p>NEEDS MEDICINE FOR COUGH</p><p><br></p><p>6/6/22</p><p>WHEEZING AND SNEEZING STARTS AFTER COLD, COLD LEADS TO ASTHMA</p><p>WHEEZING BETTER WITH DROPS</p><p>WHEEZING SLIGHTLY AFTER WALKING</p><p>NO SNEEZING WHILE COUGHING AND ASTHMA</p><p>ONCE COLD STARTS LEADS TO COUGH AND CONGESTION</p><p>COUGH &lt; NIGHT DRY PRICKING COUGH , NO PHLEGM, WET COUGH AT MORNING</p><p>WAS NOT BETTER FOR COUGH AFTER LAST MEDICINES.TAKEN ALLOPATHIC MEDICINES FOR A WEEK AND GOT BETTER NOW.</p><p>11/6/22</p><p>SNEEZING AND WHEEZING VERY SEVERE SINCE 2 DAYS</p><p>COUGH &lt; NIGHT MORNING WITH EXPECTORATION</p><p>WHEEZING AT NIGHT SNEEZING MORNING SEVERE NOW</p><p>20/6/22</p><p>COUGH WITH EXPECTORATION ,</p><p>PHLEGM WITH EXPECTORATION</p><p>SCRAPING ROUGH SENSATION IN THROAT</p>',_binary '<p>18/12/21</p><ol><li>ARS ALB 10M - 1 DOSE</li><li>ARS ALB 1M 4 DOSES {SOS}</li><li>SABADILLA 30 - 2 DRM PILLS BD</li><li>ARALIA +POTHOS - 10 DROPS TDS</li></ol><p>30/12/21</p><ol><li>BELL PHYTOLACCA Q - 15 DROPS 2 HRLY</li><li>BAPT 3X 2 HRLY - 10 DROPS</li><li>HEP SULPH 30 4 PILLS 2 HRLY</li><li>ARS ALB 10 M 2 DOSE SOS</li></ol><p>19/2/22</p><ol><li>ARS ALB 10M - 1 DOSE @ 26/2/22</li><li>ARS ALB 1M 4 DOSES {SOS}</li><li>SABADILLA 30 - 2 DRM PILLS BD</li><li>ARALIA +POTHOS - 10 DROPS TDS</li><li>TUBERCULINUM 10M 1 DOSE @ 19/2/22</li></ol><p>1/3/22</p><ol><li>RHUS TOX 1M - 2 DOSES BD</li><li>RHUS TOX 30 - 2 DRAM PILLS - 4 TDS</li><li>ALLIUM CEPA 30 - 2 DRM PILLS SOS SNEEZING</li><li>NAT SULPH 6X - 3 TDS - 3 DRM TABS</li></ol><p>9/3/22</p><ol><li>RHUS TOX 1M - 2 DOSES BD</li><li>RHUS TOX 30 - 2 DRAM PILLS - 4 TDS</li><li>ALLIUM CEPA 30 - 2 DRM PILLS SOS SNEEZING</li><li>NAT SULPH 6X - 3 TDS - 3 DRM TABS</li></ol><p>15/3/22</p><ol><li>PASSIFLORA Q - 10ML - 20 DROPS AT NIGHT</li><li>KALI CARB 1M - 2 DOSE WEEKLY ONCE</li></ol><p>24/3/22</p><ol><li>THUJA 200 - 2 DRM PILLS - 4TDS</li><li>PASSIFLORA Q - 10ML - 20 DROPS NIGHT {SOS}</li><li>NAT SULP[H 6X - 1/2 OUNCE - 3 TDS</li></ol><p>7/4/22</p><ol><li>THUJA 30 - 2 DRM PILLS - 4TDS</li><li>PASSIFLORA Q - 5ML - 20 DROPS NIGHT {SOS}</li><li>NAT SULP[H 6X - 3DRM - 3 TDS</li></ol><p>22/4/22</p><ol><li>THUJA 200- 4 DOSE BD WEEKLY ONCE</li><li>PASSIFLORA Q + ARALIAQ- 20ML - 20 DROPS NIGHT {SOS}</li><li>NAT SULP[H 6X - 3DRM - 3 TDS</li><li>HYOS 30 - 2 DRAM PILLS - 4 TDS</li></ol><p>2/5/22</p><ol><li>PQ - 20ML - 15DROPS BD OR {SOS</li><li>NS ASSIFLORA 6X - 1/2 OUNCE - 3 TDS</li></ol><p>17/5/22</p><ol><li>THUJA 200- 4 DOSE BD WEEKLY ONCE</li><li>PASSIFLORA Q + ARALIAQ- 20ML - 20 DROPS NIGHT {SOS}</li><li>NAT SULP[H 6X - 3DRM - 3 TDS</li><li>HYOS 30 - 2 DRAM PILLS - 4 TDS</li></ol><p>23/5/22</p><ol><li>DROSERA 1M - 2 DRAM PILLS</li><li>GRINDELIA Q - 10ML- 15 TDS</li></ol><p>6/6/22</p><ol><li>PULS 200 - 2 DOSE = WEEKLY ONCE</li><li>ARALIA+ZINGIBER+PASSIFLORA= 10ML = 10 TDS</li><li>ARS IOD 3X - 3 DRM TABLETS -+ 1 TDS</li></ol><p>11/6/22</p><p>SENADRYL -10 DROPS - IN 10ML TDS</p><p>20/6/22</p><ol><li>BRY 3X - 2 DRM PILLS ALTERNATE 2 HRLY WITH</li><li>IPECAC 3X - 2 DRM PILLS...REPORT AFTER 3 DAYS</li></ol><p>25/6/22</p><ol><li>SENADRYL DROPS- 10 DROPS BD</li><li>BRY 1M - 2 DOSE BD</li><li>RUMEX 200 - 2 DRM PILLS- 4 TDS</li></ol>','2022-06-13 00:00:00'),(49,51,_binary '<p>24/12/21</p><p>ONE SIDED NOSE BLOCK</p><p>COUGH ALWAYS WITH GREENISH EXPECTORATION</p><p>COUGH WITH EXPECTORATION</p><p>FEVER AT NIGHT</p><p>&lt;COLD WINTER</p><p>FEVER AT EVENINGS</p><p>EARACHE ,DISCHARGE SEEN IN EARS</p><p>PIAN IN FRONTAL SINUS</p><p>HEAVINESS OF HEAD</p><p>BRONCHITIS WITH SINUSITIS</p>',_binary '<ol><li>24/12/21</li><li>KALI BICH 1M 2 DOSES BD</li><li>ANT TART 10M - 3 TDS - 1 DRM BOTTLE</li><li>GRINDELIA Q - 20ML - 10 TDS</li><li>BAPTISIA 3X - 10ML - 10 TDS</li><li>SILICEA 1M - 2 DRM 4 TDS</li><li>BELL 1M - 3 DOSE (SOS)</li></ol>','0001-01-01 00:00:00'),(50,52,_binary '<p>24/42/21</p><p>BURNING IN STOMACH</p><p>INDIGEST ION</p><p>GASTRITIA &gt; BELCHING</p><p>THIRST ; GOOD</p><p>&gt; AFTER EATING</p><p>NO HEARTBURN</p><p>&gt;MORNING</p><p>&lt;EVENING TO NIGHT</p><p>BOWELS ; REGULAR</p><p>DIABETIC</p><p>SHOULDER PAIN</p>',_binary '<p>24/12/21</p><ol><li>LYCO 0/3 - 7 DOSES OM </li><li>ZINGIBER Q - AFTER FOOD</li><li>NAT PHOS 6X 2 DRM - 3TDS AFTER FOOD</li></ol>','0001-01-01 00:00:00'),(51,53,_binary '<p>27/12/21</p><p>INTERTRIGO WITH DRY SKIN</p><p>BT WT ; 2.9 KG</p><p>BOWELS ; REGULAR</p><p>PERSPIRATION ; + HEAD</p><p>ROLLING SLIGHTLY</p><p><br></p>',_binary '<p>27/12/21</p><ol><li>ACID NIT 200 2 DOSE - BD</li><li>CALENDULA SOAP</li><li>KALI MUR 2 6X - 2 TDS</li></ol>','0001-01-01 00:00:00'),(52,54,_binary '<p>27/12/212</p><p>HEEL PAIN SINCE 10 YEARS</p><p>PAIN IN RIGHT FLANKS</p><p>RADIATING TO LEFT LEG</p><p>&lt;WALKING , BENDING</p><p>BACK PAIN &gt; REST &lt;WORK MORNING</p><p>DIABETIC</p><p>?FIBROMYALGIA</p><p><br></p>',_binary '<p>27/12/21</p><ol><li>MEDO 10 M</li><li>TABACUM 30 4 MORNING AFTERNOON</li><li>RUTA 30 - 4 EVENING NIGHT</li></ol>','0001-01-01 00:00:00'),(53,55,_binary '<p>30/12/21</p><p>REQUIRES MEDINE FOR FEVR AND RATTLING TO  CARRY ABROAD</p>',_binary '<p>30/12/21</p><ol><li>BELL 200</li><li>ANT TART 6C</li><li>PULS 200</li><li>BAPR 3X</li><li>RHUS TOX 200</li><li>RUMEX 200</li><li>BRYONIA 2000</li></ol>','0001-01-01 00:00:00'),(54,56,_binary '<p>FEVER SINCE YESTERDAY</p><p>COUGH WITH EXPECTORATION</p><p>BODY PAIN</p><p>COUGH &lt; AFTERNOON</p><p>SLIGHT THROAT INFECTION</p><p>NOSE BLOCKED</p><p><br></p>',_binary '<p>29/12/21</p><ol><li>GRINDELIA Q 10 DROPS TDS</li><li>BAPTISIA 3X - 10ML- 10DROPS 2 HRLY</li><li>BRY 200 - 2 DRM</li><li><br></li></ol>','0001-01-01 00:00:00'),(55,57,_binary '<p>3/1/22</p><p>RECURRANT UTI</p><p>URINE INFECTION SINCE  5- 6 YEARS</p><p>NO PAIN DURING URINATION</p><p>INEFFECTUAL URGING</p><p>INCOMPLETE SENSATION WAITS FOR LONG FOR COMPLETE EVACUATION WHICH CAUSES HEADACHE.</p><p>BURNING SOMETIMES</p><p>DELIVERY - 3 C.SECTIONS</p><p>LAST LSCS 3 YEARS BACK</p><p>PERIODS REGULAR</p><p>DISCHARGE - N.S</p><p>THIRST - N</p><p>URINE ROUTINR ON 1/1/22</p><p>WBC - 4-6</p><p>RBC NIL</p><p>EPITHELIAL CELLS - 10- 12</p><p>BACTERIA PRESENT</p><p><br></p><p>11/1/22</p><p>NO RELIF AT ALL UNSATISFACTORY URINE PERSISTING</p><p>&lt;NIGHT</p>',_binary '<p>3/1/22</p><p>PULS 10M - 1 DOSE</p><p>IN HALF GLASS WATER - 1SPOON EVERY HOUR</p><p>2)UVA URSI - 20ML- 10 DROPS TDS</p><p>3)PL - 2DRM- 4 TDS</p><p><br></p><p>11/1/22</p><ol><li>APIS 200</li><li>CANTHARIS 200</li><li>ALTERNATE EVERY 2 HRLY</li><li>PYROGEN 200 - 2 DRM 3 BD</li></ol>','0001-01-01 00:00:00'),(56,58,_binary '<p>4/1/22</p><p>DRY COUGH</p><p>&lt;FANNING</p><p><br></p>',_binary '<p>4/1/22</p><ol><li>BRY 200 - 2 DOSE</li><li>ARALIA Q - 15 DROPS  QID</li><li>RUMEX 200 4 TDS</li></ol>','0001-01-01 00:00:00'),(57,59,_binary '<p>4/1/22</p><p>C/O ALLERGY MORNING AND EVENING</p><p>CONTINOUS SNEEZING</p><p>REQUIRES MEDICINE FOR NOSE BLOCK</p><p>H/O MIGRAINE 1 YEAR BACK</p><p>&gt;AFTER VOMITING</p><p>&lt;LIGHT</p><p>DOESNT TALK COMES AT NIGHT</p><p>H/O RECURRANT FEVER WITH BRONCHITIS</p><p>TAKES ANTIBIOTIC FREQUENTLY</p><p>10/2/22</p><p>WAS FEELING BETTER WHILE TAKING MEDICINE</p><p>NOW STARTED AGAIN WHEN MEDICINES ARE OVER</p><p>PIAN IN IN LEFT HEEL</p>',_binary '<p>4/1/22</p><ol><li>ARS ALB 10 M - 1 DOSE</li><li>ARS ALB 10M - 4 DOSE SOS</li><li>LEMNA MINOR Q 20ML-</li><li>SABADILLA 200 2 DRM 4 TDS</li><li>LEMNA MINOR NASAL DROPS</li></ol><p>10/2/22</p><ol><li>TUBERCULINUM 10M - 1 DOSE 10/2/22 NIGHT</li><li>ARS ALB 10M - 1 DOSE - NXT THURSDAY NIGHT 18/2</li><li>SABADILLA 30 - 2 DRAM PILLS - 4 TDS</li><li>POTHOS Q - 10ML- 10 DROPS TDS</li><li>HEKLA LAVA 3X - 1 BD- 3 DRAM TABLETS</li></ol>','0001-01-01 00:00:00'),(58,60,_binary '<p>5/1/22</p><p>LEUCORRHOEA SINCE 1 YEAR</p><p>MENSES BEFORE AND AFTER</p><p>DISCHARGE JELLY OFFENSSIVE AT TIMES DARK</p><p>SLIGHT ITCHING</p><p>LEFT ILLIAC REGION PAIN RADIATES FROM BACK TO FRONT</p><p><br></p><p>MENSES REGULAR AT TIMES GETS LATE</p><p>BY 10 DAYS SLIGHTLY IRREGULAR</p><p>LMP - 15/12/21</p><p>LASTS FOR 7 DAYS</p><p>FLOW- N</p><p>DESIRES SPICEY++</p><p>THERMALS - HOT</p><p>CRACKS ON TIP OF TOES</p><p>BOTH SIDES AFFECTED ON TOES NAILS ONLY.</p><p><br></p>',_binary '<ol><li>5/1/22</li><li>KREOS 200 4 TDS - 2DRM</li><li>MYRISTICA 30 2 TDS - 1/2 OUNCE</li><li>SEPIA 1M 4 DOSE WEEKLY</li></ol>','0001-01-01 00:00:00'),(59,61,_binary '<p>6/1/22</p><p>DIFFERENT OIL APPLIED</p><p>PAIN IN MAXILLARY SINUS WITH PUFFINESS</p><p>DRY SHORT TICKLING COUGH</p><p>WATERY RUNNING NOSE WITH SNEEZING</p><p>&lt;MORNING EVENING..</p><p>&gt;AFTERNOON</p><p>&lt;COLD WEATHER</p><p><br></p><p>29/1/22</p><p>HEADACHE SINCE 3 DAYS</p><p>PAIN OCCIPUT EXTENDING TO VERTEX</p><p>&lt;HEARING STRONG SOUND</p><p>AILMENTS FROM STRONG SOUND</p><p>VERTIGO CHANGE OF POSITION</p><p>CHOLESTROL - TAKING HOMOEO MEDICINE SINCE 5-6YEARS(HOMOEO)</p><p>BACKACHE H/O FALL</p><p>LEANING FORWARD - TENDENCY TO FALL FORWARD</p><p>&lt;STANDING &gt;LYING DOWN</p><p>&gt;REST</p><p>BP; 140/90</p><p>DESIRES ; FRIED ITEMS</p><p>25/6/22</p><p>BACK PAIN SINCE MANY YRS</p><p>LIKES MIXTURE AND CHIPS</p><p>&lt;AFTER EATING</p><p>&gt;FASTING</p><p>BP - 150/100</p><p>BLOATED SENSATION IN ABDOMEN</p><p>PAIN IN ABDOMEN CAUSING DIFFICULTY IN WALKING FEELS LEGS ARE BEND</p><p>SENSITIVE TO ALLOPATHIC MEDICINE MAINLY PARACETAMOL</p><p>30/7/22</p><p>MORNING FOOD CAUSES GREAT DISTRESS</p><p>CHOLESTROL INCREASED...LAZINESS</p><p>BP - 130/90</p><p>DISTRESS IN STOMACH PERSISTING</p><p>STIFFNESS IN JOINTS IN MORNING IN LEGS ALSO</p><p>&lt; MORNING WITH SLIGHT SWELLING</p><p>SENSATION OF THREAD IN THROAT AT TIMES</p><p>16/8/22</p><p>FEVER SINCE YESTERDAY</p><p>THROAT PAIN WITH HEADACHE</p><p>RUNNING NOSE WATERY WITH</p><p>JOINT PAIN</p><p>HIGH FEVER, RIGHT SIDED MAXILLARY SINUS PAIN WITH</p><p>19/8/22</p><p>LAZY TO TAKE BATH</p><p>LAZINESS++</p><p>BACK PAIN WITH HEADDACHE</p><p>PAIN IN JOINTS</p>',_binary '<p>6/1/22</p><ol><li>KALI BICH</li><li>SILICEA 6X - IN ARS ALB 30 3TDS</li><li>ARALIA + SENEGA - 10 DROPS TDS</li></ol><p>29/1/22</p><ol><li>GELSEMIUM 200 - 2 DRM PILLS - 2 HRLY</li><li>SANGUNARIA Q - 10ML - 10 DROPS TDS</li></ol><p>25/6/22</p><ol><li>RHUS TOX - 1M - 2DOSE BD</li><li>NUX VOM 30 - 2DRM PILLS SOS ELSE - 4 TDS</li><li>HYDRASTISQ - 30ML - 10 TDS AFTER FOOD</li></ol><p>30/7/22</p><ol><li>ALLIUM SATIVA Q - 30ML - 15 DROPSTDS - BEFORE FOOD</li><li>CHOLESTRINUM 3X - 1/2 OUNCE - 3TDS</li><li>BERB VULGARIS 200 - 2DRM - 4TDS</li></ol><p>16/8/22</p><ol><li>PHTOLACCA + BELL + BAPTISIA Q- 20ML- 10 2 HRLY</li><li>RHUS TOX 200</li><li>BELL 1M - 5 DOSE BD</li><li>BRY 200 IN WHITE CAP - 2 DRM PILLS 2 HRLY</li></ol><p>19/8/22</p><ol><li>ANT TART 1M - 1/2 OUNCE TABLETS - 2 TAB 2 HRLY</li><li>PYROGEN 200 - 3DRM PILLS - 5 PILLS 4 TIMES</li><li><br></li></ol>','2022-07-25 00:00:00'),(60,62,_binary '<p>6/1/22</p><p>LLERGIC ISSUES</p><p>ITCHING IN EYES PRESENT</p><p>URTICARIA ON FACE</p><p>AFTER SNSS EEZING</p><p>&lt;ASTHMATIC AT NIGHT</p><p>DIFFICULT</p><p>THIRST WITH</p><p>H/O URTICARIA 8YRS BACK</p><p>TREATED WITH HOMOEOPATHIC MEDICINE FROM DR ANILKUMAR</p><p>H/O STROCK ON ASPIRIN TABLETS</p><p>SINCE 4 YEARS</p><p>SENSATION OF HEAVINESS OF LEGS</p><p>H/O TINNITIS</p><p>MENIERS DISEASE</p><p>VERTIGO TURNING HEAD IN ANY DIRECTION</p><p><br></p>',_binary '<p>6/1/22</p><ol><li>EUPHRASIA EYE DROPS</li><li>IODOFORM 3X - 2DRM - 13TABLETS SOS FOR BREATHLESSNESS</li><li>ARS ALB 10 M - 1 DOSE AT NIGHT</li><li>ARS ALB 10 - 3 DOSE (SOS)</li><li>POTHOS TINCTURE -10 DROPS TDS</li></ol>','0001-01-01 00:00:00'),(61,63,_binary '<p>11/1/22</p><p>HYPOTHYROIDISM</p><p>MOTHER AND SISTERS HYPOTHYROID</p><p>FATHER - DIES SUDDENLY DUE TO CARDIAC ARREST</p><p>AT AGE BELOW 60YRS</p><p>PHY GEN;</p><p>THIRST ; N</p><p>APETITE ; N</p><p>THERMALS ; HOT</p><p>HAIRFALL ++</p><p>DRYNESS++</p><p>C/O VITILIGO- TIP OF NAILS</p><p>ON LIPS</p><p>STARTED ON THIGHS SLIGHTLY EXPANDING</p><p>PATCH APPEARING AND DISAPPERING AT TIMES</p><p>TAKEN 2 STEROID INJECTIONS 3 MONTHS BACK</p><p>C/O - HEADACHE AFTER WORK LOAD OR LOSS OF SLEEP</p><p>&gt;ONLY AFTER SLEEP. COVERING HEAD</p><p>&lt;SOUND LIGHT</p><p><br></p><p><u>9/3/22</u></p><p>THYROID PROFILE ON 3/1/22 THYROID PROFILE ON 4/3/22</p><p><strong style=\"color: rgb(230, 0, 0);\">T3 =1.310 T3=1.160</strong></p><p><strong style=\"color: rgb(230, 0, 0);\">T4= 7.69 T4=6.78</strong></p><p><strong style=\"color: rgb(230, 0, 0);\">TSH= 8.010 TSH =7.910</strong></p>',_binary '<p>11/1/22</p><ol><li>SEPIA 1M - 5 DOSES</li><li>AMBRA GRESIA - 30 2 DRAM PILLS - 5 BD</li><li>NAT MUR 30 - 2 DRM PILLS - 5BD - EVENING NIGHT</li><li>35 TABLETS 4 GR BT - OM - 1</li></ol><p>9/3/22</p><p>MEDICINES FOR 3 MONTHS</p><ol><li>SEPIA 1M - 24 TABLETS - 4GR- 2 TAB EVERY SUNDAY NIGHT</li><li>AMBRA GRESIA 30 - 2DRM - 3 BOTTLES - 4 TDS</li><li>NAT MUR 6X - 1 OUNCE BOTTLES 4 IN NOS</li></ol>','0001-01-01 00:00:00'),(167,172,_binary '<p>28/5/22</p><p>OSTEOPOROSIS</p><p>&lt;PRESSURE</p><p>PAIN IN LEGS AT NIGHT WHEN LYING DOWN</p><p>SEVERE PAIN CANNOT SLEEP AT NIGHT</p><p>HYPERTENSION SINCE SOME YEARS</p><p>HIGH CHOLESTROL</p><p>DIABETIC</p><p>NEEDS MANY TEA, MORE THAN 10 TEA PER </p><p>HUSBAND DIED 24YRS BACK</p><p><br></p><p><br></p>',_binary '<p>28/5/22</p><ol><li>CAUSTICUM 10M - 2 DOSE WEEKLY ONCE</li><li>RHUS TOX 200 - 2 DRM PILLS - 4 TDS</li><li>CALC FLUOR 6X -1/2 OUNCE - 3 TDS</li></ol>','2022-06-11 00:00:00'),(62,64,_binary '<p>10/1/22</p><p>A/F NEW DIAPER</p><p>INTERTRIGO WITH DIAPER RASH</p><p>CRIES AT NIGHT</p><p>BIRTH @ EVENING</p><p>BT WT = 3.2 KG</p><p>CHILD CRIES AT NIGHT</p><p>SLEEPS ALL DAY</p><p>DOESNT SLEEP AT NIGHT</p><p>BOWELS ALTERNATE DAYS</p><p>SLIGHTLTY FED ON POWDER MILK..STARTED AS CRACKED NIPPLE AND INSUFFICIENT BREAST MILK</p><p>WT NOW= 6KG</p><p>14/7/22</p><p>COUGH AND COLD SINCE YESTERDAY</p><p>COUGH WITH EXPECTORATION</p><p>COLD WITH THICK NASAL DISCHARGE</p><p>10 MONTHS NOW</p><p>BOWELS REGULAR</p><p>APETITE GOOD</p><p>26/8/22</p><p>INDIGESTION</p><p>VOMITING SINCE YESTERDAY</p><p>TAKEN CREAM BISCUT</p><p>PASSED MOTION WITH SMELL</p><p>IRRITABLE</p><p>SLIGHT FEVERISH</p>',_binary '<p>O10/1/22</p><ol><li>ACID NIT 1M - 1DOSE</li><li>BORONIP POWDER</li><li>JALAPA 30 - 1 DRM - 2 TDS</li></ol><p>14/7/22</p><ol><li>PULS 200 - 2 DRM PILLS- QID</li><li>RUMEX 200- 2 DRM TABLETS - 1 TDS</li><li>BAPTISIA 3X - 10ML - SOS, BELL 1M - 3 DOSE SOS BRY 200 - 2 DRM PILLS</li></ol><p>26/8/22</p><ol><li>ARS ALB 200 - 2 DRM PILLS - 3 P[ILLS 2 HRLY</li><li>CHAMOMILLA -1M IN MP 6X- 2 DRM TABLETS SOS</li><li>BAPTISIA 3X - 10M - 5 DROPS TDS</li></ol>','0001-01-01 00:00:00'),(63,65,_binary '<p>10/1/22</p><p>O/E TONSILLS ENLARGED</p><p>NO COUGH</p><p>COLD WITH SLIGHT FEVERISH</p><p>25/3/22</p><p>O/E..BILATERAL TONSILS</p><p>NO COUGH SLIGHT FEVERISH</p><p>BOWELS - REGULAR</p><p>APETITE - DECREASED</p><p>DISLIKES = MILK EGG</p><p>THIRST - THIRSLESS</p><p>PERSPIRATION ++</p><p>THERMALS = CHILLY</p><p>ACTIVE CHILD</p><p>LONG EYE LASHES</p><p>LIKES TRAVELING</p><p>SENTIMENTAL CRIES FOR SILLY THINGS</p><p>H/O.. BREATLESSNESS ,PNEUMONIA SOON AFTER DELIVERY WAS ON VENTILATOR</p><p>BT WT = 3.6KG</p><p>NO OTHER HISTORY OF HOSPITAL ADMISSION</p><p>MILE STONES ON TIME</p><p>16/6/22</p><p>FEVER SINCE YESTERDAY WITH THROAT PAIN</p><p>HEADACHE,LEG PAIN</p><p>APETITE REDUCED</p><p>27/6/22</p><p>FEVER AGAIN SINCE TODAY AFTERNOON</p><p>WEAKNESS</p><p>HEADACHE,LEG PAIN</p><p>14/7/22</p><p>COUGH AFTER FEVER</p><p>COLD ALSO</p><p>REDNESS IN PHARYNX..?POLYP LIKE</p><p>DRY PRICKING PAIN</p><p>26/8/22</p>',_binary '<p>10/1/22</p><ol><li>MERC SOL 200 - 2DRM PILLS ALTERNATE 2 HRLY WITH</li><li>BELL 200</li><li>BAPTISIA 3X + PHYTOLACCA Q - 8 DROPS 2 HRLY</li></ol><p>25/3/22</p><ol><li>ARS ALB 30 = 4 TDS</li><li>MERC SOL 200 = 4 TDS</li><li>BAPT 3X+PHYTOLACCA Q - 10ML - 8 DROPS QID</li><li>BELL 1M - 3 DOSE SOS</li></ol><p>16/6/22</p><ol><li>BAPTISIA 3X + PHYTOLACCA Q +BELL- 10ML - 8 DROPS 2 HRLY</li><li>BELL 1M - 3 DOSE SOS</li><li>MERC SOL 200 - 2 DRM PILLS</li></ol><p>27/6/22</p><ol><li>BELL 200 - 2 DRM PILLS - ALTERNATE WITH</li><li>BRY 200 - 2 DRM PILLS</li><li>BELL 1M - 3 DSOE SOS</li><li>CHINA 30 - 2 DRM TABLETS - 2 TDS</li></ol><p>14/7/22</p><ol><li>HYDRASTIS 10ML - 10 TDS</li><li>PYROGEN - 2 DRM TABLETS - 3 BD -</li><li>SANG NIT30 - 2DRM PILLS - 4 TDS</li></ol><p>26/8/22</p><ol><li>BAPTISIA 3X + PHYTOLACCA Q -10ML- 8 DROPS TDS</li><li>RUMEX 200 - 2 DRM PILLS- 4 TDS</li><li>BELL 1M - 5DOSE - SOS</li></ol>','0001-01-01 00:00:00'),(64,66,_binary '<p>10/1/22</p><p>FAMILY HISTORY OF DIABETES AT VERY YOUNG AGE</p><p>ALWAYS CHECKS BLOOD SUGAR LEVEL</p><p>FATHER - STROKE</p><p>MOTHER - ASTHMATIC</p><p>OCCASSIONAL CHECKING SHOWS INCREASED BLOOD SUGAR</p><p>ADV BLOOD FOR FBS PPBS HBAIC</p><p>11/1/22</p><p>FBS - 120 MG/DL [&lt;100]</p><p>PPBS - 198 MG/DL [&lt;140]</p><p>HBA1C = 6.5%</p><p>MEAN GLUCOSE PLASMA - 139.8</p><p>ABDOMEN BLOATED AFTER HEAVY OR INCREASD FOOD INTAKE</p><p><br></p><p>26/1/22</p><p>BROTHER IN LAW CAME AND ASKED FOR SYZIGIUM TINCTURE DIDN ANY OTHER INFORMATION FROM PATIENT.</p><p>14/5/22</p><p>RBS= 6.15MMMOL/L-------4.44--7.77</p><p>HBA1C= 6.7%</p><p>CREATININE- 1</p><p>CRP= 4.64-----0---5</p><p>LIPID PANEL= 6.38....REPORTS ON 3/5/2022</p><p><br></p><p><br></p><p><br></p>',_binary '<p>10/1/22</p><ol><li>SYZIGIUM TINCTURE - 30ML- 15 DROPS BD</li><li>NAT PHOS 6X - 1 OUNCE - 2 BOTTLES - 3 TDS</li><li>MEDI 10M - 1 DOSE</li><li>LYCO 1M - 1 DRM TABLETS 2 TABLETS WEEKLY ONCE</li></ol><p>26/1/22</p><p>TAKEN SYZIGIUM Q IN BULK BY BROTHER IN LAW</p><p>SYZIGIUM 100 ML - 1 BOTTLE</p><p>30ML - 2 BOTTLES</p><p>20ML - 1 BOTTLE</p><p>14/5/22</p><ol><li>SYZIGIUM + CEPHALANDRA - 100ML - 15 DROPS BD</li><li>NAT PHOS 6X - 1OUNCE - 2 BOTTLES</li><li>LYCO 1M - 3 DRM TABLETS - 1 TABLET WEEKLY ONCE- B26</li></ol>','2022-07-09 00:00:00'),(65,67,_binary '<p>11/1/22</p><p>ALLERGY</p><p>SNEEZING ITCHING IN EYES AND THROAT</p><p>&lt;DUST</p><p>ITCHING THROAT</p><p>SUPPRESSED ALLERGY CAUSES ASTHMA</p><p>HYPERTENSION</p><p>F/H DAUGHTER ASTHMATIC</p><p>ASTHMA &lt; ASCENDING &lt;EVENING . MORNING</p><p><br></p><p>10/2/22</p><p>WAS BETTER WHILE TAKING MEDICINE</p><p>BP ; 130/86</p><p>LEFT NOSTRIL GETS CLOSED</p><p>ITCHING IN BOTH EYES</p><p>&lt;HEAD SWEATS THEN SNEEZING MORE</p><p>CONTINOUS SNEEZE</p><p>WATERING EYES AND NOSE</p><p>NO WHEEZING AT PRESENT</p><p>11/2/22----NEEDS MEDICINE FOR BP</p><p><br></p><p>18/2/22</p><p>REDUCED SLIGHTLY</p><p>BP; 130/80 MM OF HG</p><p>&lt;ON HEAD BATH SNEEZING STARTS</p><p>MOTHER = DIED AT VERY SMALL AGE, 2 SIBLINGS DIED IN INFANCY</p><p>DAUGHTER AND SON SUFFERING SAME ISSUES</p><p>PERSPIRATION - +++ ON HEAD</p><p>THIRST = +++</p><p>BOWELS = N</p><p>SLEEP = AT TIMES DECCREASED</p><p>DESIRES = NS</p><p>H/O URTICARIA</p><p>HEAD BATH AND HEAD SWEAT CAUSES AGGRAVATION ALWAYS</p><p>O/E WHEEZING HEARD ON LEFT SIDE</p><p><br></p><p>26/2/2022</p><p><br></p><p>SNEEZING REDUCED VERY MUCH</p><p>NO SNEEZING AT ALL</p><p>VERY MUCH REDUCED</p><p>WHEEZING @ MORNING ONLY</p><p>BP-130/80MM OF HG</p><p>PAIN IN CHESTBELOW BREAST</p><p>REQUIRES MEDICINE FOR BP</p><p>CONSTIPATION SINCE 6 DAYS</p><p>8/3/22</p><p>SNEEZING SEVERE SINCE YESTERDAY NIGHT,NO WHEEZING</p><p><br></p><p>12/3/22</p><p>SNEEZING REDUCED</p><p>PILLS AND DROPS OVER</p><p><br></p><p>22/3/22</p><ol><li>RELIEF FOR SYMPTOMS</li></ol><p>30/3/22</p><p>REQUIRES MEDICINE FOR PRESSURE</p><p>SNEEZING NOT GETTING CURED COMPLETELY</p><p>ALWAYS NEEDS MEDICINE UNABLE TO STOP</p><p>NO WHEEZING NOW</p><p>HAD BOIL INSIDE NOSE, NOW BROKEN AS SAID BY THEM</p><p>NOSE BLCK AT NIGHT</p><p><br></p><p>16/4/22</p><p>HEAD BATH CAUSES ALL ALLERGIC ISSUES</p><p>10/5/22</p><p>SNEEZING WITH WATERING NOSE AND EYES...SEVERE NOW..CANNOT STOP MEDICINE NOT GETTING CURE</p><p>11/5/22</p><p>NO RELIEF AT ALL AFTER MEDICINE....CONTINOUS SNEEZING UNABLE TO TOLERATE</p><p>19/5/22</p><p>NO SNEEZING NOW, BUT ASTHMA SINCE MORNING WITH COUGH AND EXPECTORATION</p><p>RATTLING IN CHEST</p><p>REQUIRES MEDICINE FOR ASTHMA</p><p>20/5/22</p><p>BP - 130/80</p><p>NO RELIEF FOR ASTHMA</p><p>PRICKING COUGH</p><p>BURNING IN THROAT AND CHEST</p><p>23/5/22</p><p>COUGH &lt;NIGHT LYING DOWN</p><p>STARTED AT 2AM</p><p>ERUCTATIONS SINCE 2 TO 3 DAYS</p><p>SENSATION OF SOMETHING ON THROAT</p><p>COUGH SEVERE ..URINATING WHILE COUGHING</p><p>ASTHMA REDUCED</p><p>&gt;HOT WATER</p><p>IMMEDIATELY AFTER MEDICINE PHLEGM COMES WITH COUGH</p><p>31/5/22</p><p>COUGH REDUCED</p><p>NO OTHER ISSUES NOW,COUGH SLIGHTLY PERSISTING .</p><p>WITH EXPECTORATION</p><p>8/6/22</p><p>ITCHING IN NOSE,HEADACHE IN LEFT SIDE, SNEEZING STARTED SINCE MORNING, STARTED SINCE 25YRS</p><p>&lt;MORNING ,SNEEZING</p><p>2/7/22</p><p>NEEDS MEDICINE FOR PRESSURE</p><p>WAS FEELING BETTER WHILE TAKING MEDICINE, STARTED GWTTING SNEEZING SINCE TODAY MORNING</p><p>140/80 MM OF HG</p><p>HAIRFALL SEVERE</p><p>8/7/22</p><p>FEELING BETTER</p><p>NEEDS SOME MEDICINE TO KEEP</p><p>23/7/22</p><p>PAIN IN KNEE JOINTS RIGHT KNEE JOINT MORE</p><p>PAIN&lt;NIGHT</p><p>SLIGHT OEDEMA WITH</p><p>SEVERE PAIN AFTER TRAVELLING ON BIKE</p><p>SLIGHT VERICOSE WITH</p><p>PAIN &lt;MOTION &gt;RESTBP - 140 /80 MM OF HG</p><p>5/8/22</p><p>NEED MEDICINE FOR COLD, NEED DROPS FOR LEG PAIN</p><p>26/8/22</p><p>PAIN IN RIGHT FOOT SINCE YESTERDAY</p><p>PAIN IN NECK</p><p>?FIBROMIALGIA, NO OEDEMA</p><p>WEAKNESS WITH PALENESS..? ANEMIA</p><p>BP - 130/80 MM OF HG</p>',_binary '<p>11/1/22</p><ol><li>ARS ALB 10M 1 DOSE</li><li>SABADILLA 30 - 4 TDS</li><li>ARS ALB 10M - 3 DOSES SOS</li><li>POTHOS Q - 15 DROPS TDS</li><li>IODOFORM 3X - 2 DRM SOS</li></ol><p>10/2/22</p><ol><li>EUPHRASIA EYE DROPS</li><li>ARS ALB 10M - 1 DOSE TONIGHT</li><li>TUBERCULINUM 10M - 1 DOSE NXT THURSDAY NIGHT</li><li>IODOFORM 3X - 2 DRM - TABLETS [ SOS]</li><li>SABADILLA 30 - 2 DRM - 4 TDS</li><li>ARS ALB 10M - 4 DOSE {SOS}</li><li>POTHOS + SENEGA Q - 20ML - 20 DROPS QID</li></ol><p>11/2/22</p><ol><li>CRATEAGUS + RAUWOLFIA 10DROPS -10ML - 10DROPS BD</li></ol><p><br></p><p>18/2/22</p><ol><li>NAT SULPH 1M - 1 DOSE ON 18/2/22</li><li>NAR SULPH 6X 3 TDS</li><li>ARS ALB 30 2 DRM PILLS 4 TDS</li><li>POTHOS +PASSIFLORA Q - 15 TDS</li></ol><p><br></p><p><br></p><p>26/2/2022</p><ol><li>CRATEGUS+RAWOLFIA Q 20ML</li><li>NAT SULPH 6X 3TAB TDS 1/2 OUNCE</li><li>ARS ALB 30- 4TDS 2DRM</li><li>POTHOS= SENEGA+ARALIA-20ML</li></ol><p><br></p><p>8/3/22</p><ol><li>HISTAMIN 30 - 3 DOSES WEEKLY ONCE</li></ol><p>12/3/22</p><ol><li>12/3/22RS ALB 30 2 DRM PILLS 4 TDS</li><li>POTHOS +PASSIFLORA Q - 15 TDS</li></ol><p>22/3/22</p><ol><li>NAT SULPH 6X 3TAB TDS 1/2 OUNCE</li><li>ARS ALB 30- 4TDS 2DRM</li><li>POTHOS= SENEGA+ARALIA-20ML</li><li>HISTAMIN 30 = 2 DOSE WEEKLY ONCE</li></ol><p>30/3/22</p><ol><li>NAT SULPH 6X 3TAB TDS 1/2 OUNCE</li><li>ARS ALB 220- 4TDS 2DRM</li><li>POTHOS+SENEGA-10ML</li><li>SULPH- PSOR 200 = 2 DOSE 2WEEKLY ONCE</li><li>CRATEGUS +RAUWOLFIA Q - 10ML - 10GTT BD</li></ol><p>16/4/22</p><ol><li>NAT SULPH 6X 3TAB TDS 1/2 OUNCE</li><li>ARS ALB 220- 4TDS 2DRM</li><li>POTHOS+SENEGA+ARALIA - 20ML - 15 TDS</li><li>THUJA 200 = 2 DOSE BD</li><li>CRATEGUS +RAUWOLFIA Q - 10ML - 10GTT BD</li></ol><p>10/5/22</p><ol><li>SILICEA 6X - 1/2 OUNCE - 3 TDS</li><li>HISTAMIN 200 - 3 DRM PILLS - 4 TDS</li><li>ALLIUM CEPA 30 IN RS - 10ML - 5 TDS</li></ol><p>11/5/22</p><ol><li>SULPHUR 1M - 1 DOSE NOW</li><li>PL - 2 DRM PILLS -3 PILLS 1/2 HRLY</li><li>CRATEGUS +RAUWOLFIA - 10 DROPS BD</li></ol><p>19/5/22</p><ol><li>NAT SULPH 1M - 1 DOSE</li><li>NAT SULPH 6X - 3 TDS -</li><li>GRINDELIA Q - 20ML - 15 TDS</li></ol><p>20/5/22</p><ol><li>RUMEX 200 - 2 DRAM PILLS - 3 PILLS 2 HOURLY</li><li>TAKE ALONG WITH GRINDELIA Q WITH THIS</li></ol><p>23/5/22</p><ol><li>DROSERA 1M - 2 DRAM PILLS - 4 QID</li><li>GRINDELIA Q - EUCALYPTUS Q 15DROPS - 20ML - 15 DROPS QID</li></ol><p>31/5/22</p><ol><li>DROSERA 1M - 2 DRAM PILLS - 4 QID</li><li>GRINDELIA Q - EUCALYPTUS Q 15DROPS - 20ML - 15 DROPS QID</li></ol><p>8/6/22</p><ol><li>PULS 1M - 3 DOSE WEEKLY ONCE</li><li>NUX VOM 30 + AMMON CARB 30 - 2 DRAM PILLS - 4 TDS</li><li>POTHOS + SABADILLA Q - 20ML - 10 TDS</li></ol><p>2/7/22</p><ol><li>PULS 1M - 3 DOSE WEEKLY ONCE</li><li>NUX VOM 30 + AMMON CARB 30 - 2 DRAM PILLS - 4 TDS</li><li>POTHOS + SABADILLA Q - 20ML - 10 TDS</li><li>CRATEGUS + POYHOS Q - 20ML</li><li>ARNICA HAIR OIL BAHOLA</li></ol><p>8/7/22</p><ol><li>PULS 1M - 3 DOSE WEEKLY ONCE</li><li>NUX VOM 30 + AMMON CARB 30 - 2 DRAM PILLS - 4 TDS</li><li>POTHOS + SABADILLA Q - 20ML - 10 TDS</li></ol><p>23/7/22</p><ol><li>PULS 1M - 3 DOSE WEEKLY ONCE</li><li>BRY 200 IN</li><li>BRY Q - 20ML - 10 TDS</li><li>CRATEGUS Q+ RAUWOLFIA Q - 20ML - 10 BD</li></ol><p>5/8/22</p><ol><li>NUX VOM 30 + AMMON CARB 30 - 3 DRAM PILLS - 4 TDS</li><li>BRY Q - 20ML - 10 TDS</li><li>BRY 200 3 DRM PILLS</li></ol><p>25/8/22</p><ol><li>ERYTROFIL SYRUP</li><li>CRATEGUS Q+ RAUWOLFIA Q + ALLIUM SATIVA Q -- 30ML - 10 TDS</li><li>PULS 1M - 3 DOSE WEEKLY ONCE</li><li>NUX VOM 30 + AMMON CARB 30 - 3 DRAM PILLS - 4 TDS</li><li>CALC PHOS 6X - 1/2 OUNCE - 3TDS</li></ol>','2022-06-22 00:00:00'),(66,68,_binary '<p>11/1/22</p><p>FEVER AT NIHGT WITH CHILLINESS</p><p>NO FEVER AT MORNING</p><p>?UTI</p>',_binary '<p>11/1/22</p><ol><li>GELS 200 4 DOSE BD</li><li>BAPTISIA 3X 10 DROPS QID</li><li>FP 6X - 2 QID</li></ol>','0001-01-01 00:00:00'),(67,69,_binary '<p>12/1/22</p><p>GASTRITIS</p><p>&gt;EMPTY STOMACH</p><p>&lt;AFTER EATING FOOD</p><p>BURNING</p><p>ERUCTATIONS</p>',_binary '<p>12/1/22</p><ol><li>NUX VOM 1M - 1 DOSE</li><li>ZINGIBER Q - 10 DROPS QID</li><li>NAT PHOS 6X - 3 DRAM- 3 QID</li></ol>','0001-01-01 00:00:00'),(68,70,_binary '<p>13/1/22</p><p>DIABETES SINCE 10 YRS</p><p>HEADACHE WITH HIFH BLOOD PRESSURE</p><p>BP 160/100</p><p>NUMBNESS OF LEFT LEG</p><p>VERTIGO SINCE YESTERDAY</p><p>ON INSULIN TREATMENT</p><p>ON HYPERTENSIVE DRUGS</p><p>ON MEDICATION FOR NUMBNESS.</p><p><br></p><p>21/1/22</p><p>H/O FEVER</p><p>COUGH &lt; DUST</p><p>&lt;AFTERNOON INCREASES BY NIGHT</p><p>SLIGHTLY FROTHY COUGH</p><p>DRIBBLING OF URINE AFTER COUGH</p><p>SLIGHT FATIGUE</p><p>BP 150/100</p><p>FEVER COUGH AFTER FEVER</p><p>RECURRANT UTI</p><p>CONSTANT DESIRE TO PASS URINE</p><p>BURNING++</p><p><br></p><p>1/2/22</p><p>COUGH GOT REDUCED</p><p>URINARY TRACT</p><p>INFECTION FROTHY INCREASED URINE AT NIGHT</p><p>SUDDEN URGE TO PASS NO DIFFICULTY IN PASSING</p><p>DIABETIC SINCE 10 YRS</p><p>EDEMA ON LEFT LEG MORE NUMBNESS ON SAME LEG</p><p>ALLERGY DUST CAUSES IMMEDIATE COUGH</p><p><br></p><p>18/2/22</p><p>NUMBNESS OF LEG SLIGHTLY REDUCED</p><p>H/O INCREASED ESR WITH LOW HB AS SAID BY PATIENT</p><p>BLACK DISCOLRATION ON LEGS STARED AFTER NUMBNESS STARTED</p><p>URINE FROTHY AT NIGHT COMPLAINT SLIGHTLY ONLY REDUCED AFTER MEDICINE INTAKE</p><p>APETITE = GOOD</p><p>THIRST -= THIRSTLESS</p><p><br></p><p>7/3/22</p><p>REQUIRES MEDICINE FOR NUMBNESS OF LEG</p><p>OEDEMA ON ANKLE REDUCED</p><p>SLIGHTLY REDUCED NUMBNESS OF HANDS</p><p>URINE ISSUES NOT THERE NOW</p><p>BP ; 130/80</p><p><br></p><p>23/3/22</p><p>REQUIRES  MEDICINE FOR NUMBNESS, SLIGHTLY REDUCED</p><p>SENSATION OF CHAPPAL ON FOOT EVEN  AFTER REMOVING IT.</p><p>PAIN IN KNEES &lt; MORNING H/O FALL IN BATHROOM</p><p>?OSTEOPOROSIS</p><p>&lt;WALIKING SOMETIME. STANDING</p><p>&gt;REST LYING DOWN....BP = 130/80</p>',_binary '<p><br></p><p>13/1/22</p><ol><li>RAUWOLFIA TINCTURE- 10 DROPS TDS</li><li>MEDO 10M 1 DOSE</li><li>NAT PHOS 6X - 3 DRAM 3 TDS</li></ol><p>21/1/22</p><ol><li>DROSERA 1 M - 2 DRM PILLS - 4 2 HRLY</li><li>NAT MUR 200 4 DOSE - BD AFTER THAT</li><li>PULS 1M - 2 DOSE</li><li>ARALIA + EUCALYPTUS Q - 15 DROPS QID</li><li>KP 6X - 1/2 OUNCE - 3 BD</li><li><br></li></ol><p>1/2/22</p><ol><li>CANTHARIS 30 - 2 DRM PILLS - 4TDS SOS URINE</li><li>KALI PHOS 6X - 1/2 OUNCE -3 TDS</li><li>OLIDAGO Q - 15 DROPS TDS - 5 ML SOS URINE</li><li>SYPH 10M - 2 DOSES WEEKLY ONCE</li></ol><p><br></p><p><br></p><p><br></p><p>18/2/22</p><ol><li>CANTHARIS 30 - 2 DRM PILLS - 4TDS SOS URINE</li><li>KALI PHOS 6X - 1/2 OUNCE -3 TDS</li><li>SOLIDAGO Q - 15 DROPS TDS - 5 ML SOS URINE</li><li>FERR PLUS CAPSULES = 16</li></ol><p>7/3/22</p><ol><li>CANTHARIS 30 - 2 DRM PILLS - 4TDS SOS URINE</li><li>KALI PHOS 6X - 1/2 OUNCE -3 TDS</li><li>SOLIDAGO Q - 15 DROPS TDS - 5 ML SOS URINE</li><li>SYPH 10M - -2DOSES WEEKLY ONCE</li></ol><p><br></p><p>23/3/22</p><ol><li>CALC CARB 200 - 3 DOSE - WEEKLY ONCE</li><li>KALI PHOS 6X - 3 TDS - 1/2 OUNCE</li><li>CANTHARIS 30 - 2 DRAM TABLETS - 1 TAB 1 HRLY</li></ol>','2022-03-04 00:00:00'),(69,71,_binary '<p>14/1/22</p><p><br></p><p>FEAR OF DISESES</p><p>ON HYPERTENSIVE DRUGS SINCE 10 YEARS</p><p>H/O INSOMNIA</p><p>ON HIGH URIC ACID SLIGHTLY SWOLLEN TOE AT MORNING WITH PAIN</p><p>FEAR OF COATED TONGUE</p><p>WHITE COATED+</p><p>SENSATION OPF THICKNESS SOMETHING ON IT</p>',_binary '<p>14/1/22</p><ol><li>ARS ALB 10M - 1 DOSE AT NIGHT</li><li>NAT MUR 6X - 3 BD - 1/2 OUNCE</li><li>ANT CRUD 200 - 4 TDS</li></ol>','0001-01-01 00:00:00'),(70,72,_binary '<p>14/1/21</p><p>ALLERGY SINCE 6 YEARS</p><p>INHALERS ON ACCORDING TO NEED</p><p>&lt;DUST ALLERGY</p><p>&lt;SMELL OF FISH FRY</p><p>STICKY PHLEGM AT TIMES OFFENSSIVE</p><p>STARTS AS WATERING EYES AND SNEEZING</p><p>O/E SLIGHT WHEEZING</p><p>RECURRANT THROAT INFLAMMATION</p><p>CONTINOUS NASAL DISCHARGE</p><p>F/H OF ALLERGY IN FAMILY</p><p>&lt;COLD</p>',_binary '<p>14/1/22</p><ol><li>ARS ALB 10 M - 1 DOSE</li><li>ARS ALB 10 - 2 DRM SOS</li><li>SABADILLA 30 - 3 DRAM TABLETS - 3 BD</li><li>POTHOS Q - 15 DROPS TDS</li><li>IODOFORM 3X 14 TABKETS SOS</li></ol>','0001-01-01 00:00:00'),(71,73,_binary '<p>14/1/22</p><p>ON HANS SINCE 8 YEARS</p><p>SINCE 2 MONTHS QUIT THE HABBIT </p><p>WITHDRAWAL SYMPTOMS</p><p>ECZEMA LIKE ON LEGS</p><p>ITCHING+</p><p>BLEEDING</p><p>SCAB FORMATION</p><p>WHITE POWDERY</p><p>&lt;FANNING</p><p>&lt;BATHING AFTER</p>',_binary '<p>14/1/22</p><ol><li>STAPH 1M - 4 DOSES - ONCE I N 5 DAYS</li><li>PLANTAGO Q - 15 TDS</li><li>KM 6X 3 TDS</li></ol>','0001-01-01 00:00:00'),(72,74,_binary '<p>21/1/ 22</p><p>FEVER SINCE DAY BEFORE YESTERDAY</p><p>WAS ON PARACETAMOL</p><p>ALWAYS DEMANDS FEED</p><p>H/O COLD INTAKE</p><p>H/O HFMD LAST MONTH</p><p>MOTHER HAD SLIGHT THROAT INFECTION</p><p><br></p><p>5/3/22</p><ol><li>WEIGHT = 7.7KG NOT GAINING MUCH</li></ol><p>BIRTH WEIGHT - 2.850</p><p>MILE STONES = DELAYED?</p><ol><li>HAD FEVER AT 3.45AM </li></ol><p>THICK YELLOW NASAL DISCHARGE</p><p>NOSE BLOCK AT NIGHT</p><p>BOWELS -= REGULAR</p><ol><li>PERSPIRATION = FULL BODY  HEAD ON WHILE CRYING\\</li></ol><p><br></p>',_binary '<p>21/2/22</p><ol><li>BRY 200 4 DOSE BD</li><li>BAPTISIA 3X + PHYTOLACCA Q  4 DROPS 2 HRLY</li><li>BELL 200 4 PILLS 2 HRLY</li></ol>','0001-01-01 00:00:00'),(73,75,_binary '<p> 22/1/22</p><p>FEVER AT NIGHT YESTERDAY</p><p>PAIN JOINT</p><p>DRY COUGH WITH</p><p>COUGH AFTERNOON STARTED</p><p>WITH SLIGHT EXPEXCTORATION</p><p>HEADACHE FRONTAL HEADACHE WITH</p><p>PIAN IN JOINTS</p><p><br></p><p>BP; 148/90 MM OF HG</p><p>USE TO TAKE HOMEO MEDICINES FOR BP</p><p>NOW FORGOT TO TAKE IT WHILE COMING TO DAUGHERS HOUSE HERE</p>',_binary '<p>22/1/22</p><ol><li>RAUWOLFIA Q - 10 DROPS BD</li><li>BRY 200 ALTERNATE 2 HRLY WITH</li><li>PHOS 30</li><li>EUPATORIUKM 30 + BELL 3X 2 HRLY</li><li>BELL 1M 4 DOSES</li></ol>','0001-01-01 00:00:00'),(74,76,_binary '<p>22/1/22</p><p>COUHG AND COLD SINCE 5 DAYS</p><p>RUNNING NOSE SNEEZING WITH</p>',_binary '<p>22/1/22</p><ol><li>ARS ALB 30 2 DRM PILLS 2 BOTTLE</li><li>EUCALYPTUS + JUSTICIA Q - 20ML - 10 DROPS TDS ELDER- 8 DROPS TDS CHILD</li><li>BRY 200 BD - 6 DOSE</li></ol>','0001-01-01 00:00:00'),(75,77,_binary '<p>24/1/22</p><p>ITCHING ERUPTION ON TOES WITH DEEP CRACKS</p><p>ITCHING WITH DRYNESS &lt;DUST FROM</p><p>WATERYERUPTIONS BRAEK ON EASILY WHILE SCRATCHING</p><p>C/O ALLERGY INCREASE SNEEZING ON AND OFF CONTINOUS &lt;DUST , STRONG ODOUR</p><p>&lt;TOUCH ON NOSE</p><p>ON CITRIZINE TAKING SPRAY 2 TIMES</p><p>ITCHING ERUPTION PAINFULL</p><p>STARTING OF NASAL POLYP AS SAID BY DOCTOR</p><p>PHY GEN</p><p>SWEAT ; FACE AXILLA OFFENSSIVE</p><p>BOWELS REGULAR</p><p>SLEEP NORMAL</p><p>DESIRES ; SOUR SALTED</p><p>THERMALS = HOT </p><p>MENSES REGULAR</p>',_binary '<p>24/1/22</p><ol><li>MERC SIL 1M - 2 DOSES WEEKLY ONCE</li><li>KALI MUR 6X 3 TDS</li><li>B26 - 1 HS</li></ol>','0001-01-01 00:00:00'),(76,78,_binary '<p>26/1/22</p><p>FEVER 2 DAYS BACK</p><p>COUGH LYING DOWN</p><p>COUGH WITH EXPECTORATIONI</p><p>HAD COLD NOW REDUCED</p><p>O/E SLIGHT WHEEZING HEARD ON RIGHT SIDE</p><p>CONGESTED FEELING ON CHEST</p><p>O/E TONGUE WITH IMPRINT OF TEETH</p><p>SLIGHTLY COATED WITH</p><p><br></p>',_binary '<p>24/1/22</p><ol><li>DROSERA 30 2 DRM PILLS EVENING AND NIGHT</li><li>GLYCERRHIZA GLABRA - 10ML - 15 DROPS QID</li><li>ANT TART 10M - 1/2 UNCE 3 TDS</li></ol>','0001-01-01 00:00:00'),(77,79,_binary '<p>28/1/22</p><p>BROWNISH DISCOLOURATION ON NAPE OF NECK  WITH ITCHING AT TIMES</p><p>= HISTORY OF ECZEMA IN CHILDHOOD</p><p>=DANDRUFF</p><p>=MENSES IS 1 WEEK BEFORE LMP USUALLY</p><p>DISCHARGE = BROWNISH SINCE 1WEEK</p><p>DRY SKIN ALWAYS NEED CREAM</p><p>SLEEP = DIFFICULT TO GET SLEEP DUE TO TOO MUCH THINKING</p><p>THIRST = MORE AT EVENING AND NIGHT</p><p>H/O = UTERINE POLYPS REMOVED SURGICALLY</p><p>DESIRES = SPICY FOOD</p><p>THERMALS = &lt; COLD</p><p>ITCHING ON LEGS DRY SKIN WITH</p>',_binary '<p>28/1/22</p><ol><li>SEPIA 4 DOSES WEEKLY ONCE</li><li>NAT MUR 6X = 3 TDS</li><li>B24 = 1 AT MORNING</li></ol>','0001-01-01 00:00:00'),(78,80,_binary '<p>29/1/22</p><p>BLACK ERUPTIONS ITCHING ON EXTRIMITIES UPPER AND LOWER SINCE 2 WEEKS</p><p>HAD SIMILAR ISSUES 1 YEAR BACK TOK SOME ALLOPATHIC TREATMENT</p><p>H/O PRICKING WITH THORN WHILE PLAYING AND SIMILAR EREUPTIONS COMPALINTS INITIALLY STARTED AFTER THIS INCIDENT</p><p>&lt;ITCHING &lt;NIGHT</p><p>PUS FILLED WITH</p><p>PRICKING TYPE OF PAIN</p><p>BLEEDING SPOTS</p><p>ERUPTIONS BLACKISH VESICLES</p><p>2/2/22</p><p>ERUPTIONS ARE PAINFUL ++</p><p>REDNESS++</p><p>PUS FILLED</p><p><br></p><p>8/2/22</p><p>PUS REDUCED</p><p>PAIN REDUCED</p><p>BLEEDING EASILY,ERUPTIONS SOME PINK SOME REDDISH SEEMS TO BE HEELING</p><p>21/2/22...RASHES ARE HEALING</p><p>REQUIRES MRDICINE WHILE MOTHER VISITING HIM IN HOSTEL</p><p>14/3/22</p><p>ITCHING SMALL ERUPTIONS ON ELBOW...NO PAIN NO DISCHARGE</p><p>ERUPTIONS LEAVING BLACK MARKS</p><p>THIRSTLESS</p><p><br></p><p>4/4/22</p><p>SEVERE ITCHING SINCE 3 DAYS</p><p>ERUPTIONS ON ARM MORE SINCE 3 DAYS</p><p>WAS BETTER AFTERVLAST MEDICINE</p><p>DOUBTFUL OF SCABIES IN HOSTEL...2 STUDENTS IN HOSTEL HAS ITCHING ERUPTIONS</p><p><br></p><p>12/4/22</p><p>ITCHING REDUCED </p><p>ERUPTIONS ON NECK NEW</p>',_binary '<p>29/1/22</p><ol><li>THUJA 1M - 1DOSE FOLLOWED BY</li><li>ARS ALB 200 - 4 DOSE BD</li><li>ECHINACEA Q - 10ML - 10 TDS</li></ol><p>2/2/22</p><ol><li>SILICEA 6X - 2 DRM - 3 TDS</li><li>HEP SULPH 1M - 2 DOSES -BD</li><li>BELL 200 - 2 DRAM PILLS [SOS] FOR THROAT PAIN</li></ol><p>8/2/22</p><ol><li>ECHINACEA Q - 10ML - 15TDS</li><li>SILICEA 6X -1/2 OUNCE - 3TDS</li><li>MERC SOL 1M- 4 DOSE - BD 2 DOSE TONIGHT N MORNING</li></ol><p>2 DOSE PHONE ON NEXT TUESDAY 15/2</p><p>21/2/22</p><ol><li>ECHINACEA Q - 10ML - 15TDS</li><li>SILICEA 6X -3DRAM - 3TDS</li></ol><p>14/3/22</p><ol><li>ANT CRUD 1M - 1 DOSE TONIGHT</li><li>ECHINACEA Q - 20ML - 10 TDS</li><li>PL 24 - 4 QID</li></ol><p><br></p><p>4/4/22</p><ol><li>ANT CRUD 1M - 1 DOSE TONIGHT</li><li>ECHINACEA Q - 20ML - 10 TDS</li><li>KALI MUR 6X - 1/2 OUNCE - 3 TDS</li></ol><p>12/4/22</p><ol><li>ECHINACEA Q - 30ML - 10 TDS</li><li>KALI MUR 6X - 1/2 OUNCE - 3 TDS THEY HAVE IT</li><li>MYRISTICA 30 - 2 DRM PILLS 4 TDS</li></ol>','2022-02-15 00:00:00'),(79,81,_binary '<p>31/1/ 22</p><p>/SPONDILITIS???</p><p>HUSABAND CAME WITH XRAY</p><p>PAIN IN NECK SINCE 2 WEEKS</p><p>&lt;TURNING TO LEFT SIDE</p><p>&gt;MORNING AFTER SOMETIME</p><p>TAKING AYURVEDIC MEDICINE FOR DIABETES</p>',_binary '<p>31/1/22</p><ol><li>NUX VOM 1M - 2 DOSE WEEKLY ONCE</li><li>RUTA 30 - 2 DRAM PILLS</li><li>MAG PHOS 6 X - 1/2 OUNCE -3 BD</li></ol>','0001-01-01 00:00:00'),(80,82,_binary '<p>22/1/22</p><p>DABETES SINCE 7 YRS</p><p>ACCIDENT = H/O INJURY ON FOREHEAD</p><p>WAS HOSPITALISED DIAGNOSED DIABETES AFTER IT</p><p>HEADACHE</p><p>WEAKNESS AT TIMES</p><p>MUNCIPALITY WORKER BEFORE</p><p>WAKES ONCE FROM SLEEP</p><p>BROTHER DIABETIC</p><p>FBS - 135MG/DL</p><p>PPBS - 240MG/DL</p>',_binary '<p>22/1/22</p><ol><li>SYZIGIUM 10ML- 15 DROPS BD</li><li>NAT PHOS 6X - 3 TDS</li><li>ACID PHOS 200 - 2 DRAM PILLS</li></ol>','0001-01-01 00:00:00'),(81,83,_binary '<p>1/2/22</p><p>ALLERGY</p><p>SNEEZING &lt;EVENING NIGHT</p><p>ITCHING EYES THROAT EARS</p><p>O/E SLIGHT SWELLING PRESENT IN EARS</p><p>SNEEZING MAINLY</p><p>12/2/22</p><p>COUGH &lt; NIGHT</p><p>COUGH WITH SNEEZING STARTED 4 DAYS BACK</p><p>USE TO GET COUGH ALSO WHILE SNEEZING</p><p>NOT FELT MUCH RELIEF WITH MEDICINE</p><p><br></p><p>22/3/22</p><p>FEELING SLIGHT RELIEF WHILE TAKING MEDICINE</p><p>COMPLAINTS APPEARING WHEN MEDICINES GOT OVER SINCEV A WEEK</p><p>FAMILY HISTORY OF ALLERGY- FATHER</p>',_binary '<p>1/2/22</p><ol><li>ARS ALB 10 M - 1 DOSE</li><li>ARS ALB 10 M - 3 DOSE SOS</li><li>SABADILLA 30 - 2 DRAM PILLS - 4 TDS</li><li>POTHOS Q - 10 DROPS TDS</li></ol><p>12/2/22</p><ol><li>ARS ALB 1M - 2 DRM PILLS - 4 TDS - SOS HRLY</li><li>ARALIA + POTHOS Q - 10ML - 10 TDS</li><li>KALI BICH 6X - 2 TDS - 1/2 OUNCE</li><li>SULP- PSOR 200 - 3 DOSE WEEKLY ONCE</li></ol><p><br></p><p>22/3/22</p><ol><li>        ARS ALB 1M - 2 DRM PILLS - 4 TDS - SOS HRLY</li><li>ARALIA + POTHOS Q - 10ML - 10 TDS</li><li>KALI BICH 6X - 2 TDS - 1/2 OUNCE</li><li>SULP- PSOR 200 - 3 DOSE WEEKLY ONCE</li></ol><p><br></p><ol><li><br></li></ol>','0001-01-01 00:00:00'),(82,84,_binary '<p>15/11/21</p><p>HEEL PAIN</p><p>&lt;MORNING&lt;MOTION &lt;CHANGE OF POSITION</p><p>CHECKED URIC ACID BUT SEEMS TO BE NORMAL</p><p>NO OTHER HEALTH ISSUES</p><p>CHOLESTROL = HIGH</p><p>MENSES = REGULAR</p><p>BOWELS = REGULAR</p><p>APETITE = GOOD</p><p>TAKES PROPERLY AT AFTERNOON</p><p>20/11/21</p><p>PAIN SLIGHTLT BETTER</p><p>6/12/21</p><p>PAIN REDUCED</p><p>17/12/21</p><p>PAIN REDUCED VERY MUCH</p><p>21/1/22</p><p>COUGH HIGH SOUND FEVER AFTER</p><p>COUGH WITH EXPECTORATION</p><p>&lt;MORNING AND NIGHT</p><p>COUHG WITH EASY EXPECTORATION</p><p>HAD FEVER 2-3 DAYS BACK</p><p>3/2/22</p><p>COUGH WITH EXPECTORATION &lt;MORNING SLIGHTLY PRESENT</p><p>HAD SLIGHT INJURY ON RIGHT HEEL</p><p>VERICOSE VEIN STARTED IN FIRST PREGNANCY</p><p>SWELLING +++ ON LEFT LEG</p><p><br></p><p>24/2/22</p><p>PAIN REDUCED BUT SLIGHTLY INCREASED SINCE 2 DAYS</p><p>RT HEEL WHICH WAS MORE PAINFUL BEFORE REDUCED NOW, PAIN FOE LEFT HEEL AND LEG MORE NOW</p><p>VARICOSE VEIN ISSUES MORE LEFT LEG NOW....PAIN UPWARDS TO THIGHS FOR LEFT LEG</p><p>PAIN &lt; NIGHT WHILE LYING DOWN</p><p>WORK LOAD MORE AT HOME NOW</p><p><br></p><p>19/4/22</p><p>PAIN REDUCED VERY MUCH ,NOW STARTED AGAIN WHEN MEDICINE NOT TAKEN FOR A MONTH</p><p>LEFT HEEL HAD MORE PAIN NOW PAIN IN RIGHT HEEL</p><p><br></p><p>9/5/22</p><p>PAIN REDUCED NO PAIN NOW</p><p>PAIN ONLY WHILE PRESSING</p><p>REQUIRES MEDICINE FOR A MONTH TO CARRY ABROAD</p><p><br></p>',_binary '<p>15/11/21</p><ol><li>RHUS TOX 1M - 4 QID</li><li>MEDO 1M 2 DOSE</li><li>CALC PHOS 6X - 3 TDS</li></ol><p>20/11/21</p><ol><li>CALC PHOS 6X - 30ML BOTTLE</li><li>RHUS TOX 1M - 3 DRM PILLS</li></ol><p>6/12/21</p><ol><li>PULS 10M - 2 DOSE 6/12/21,20/12/21</li><li>CALC PHOS 200 - 2 DRM - 4 TDS</li><li>BT 1 GR - 3 DRM - 3 BD</li></ol><p>17/12/21</p><ol><li>PULS 10M - 2 DOSE 21/12/21, 4/1/22</li><li>CALC PHOS 200 - 4 TDS - 2 DRM</li><li>B4 - 3 DRM - 3 BD</li><li>MEDO 10M - 1 DOSE 28/12/21</li></ol><p>27/12/21</p><p>BT 1GR - 3 TDS</p><p><br></p><p>21/1/22</p><ol><li>PULS 10M - 2 DOSE 21/1/22 4/2/22</li><li>DROSERA 1M 2 DRM ALTERNATE 2 HRLY WITH</li><li>BRY 200 2 DRM</li><li>ARALIA +EUCALYPTUS Q - 10ML - 15 DROPS QID</li><li>CP 6X - 3 BD</li></ol><p>3/2/22</p><ol><li>MEDO 10M - 1 DOSE 3/2/22</li><li>PULS 10M - 2 DOSE 10/2/22 24/2/22</li><li>GRINDELIA Q - 10ML - 10 DROPS TDS</li></ol><p>4.CALC FLUOR 6X - 3 TDS - 1/2 OUNCE</p><p>5.PULS 200 - 4 TDS - 2 DRM</p><p><br></p><p>24/2/22</p><ol><li>PULS 1M 4 DOSES - 2 DOSES BD WEEKLY</li><li>HAMAMELIS Q - 20ML - 15 TDS</li><li>ACID FLUOR 30- 2 DRM PILLS - 4 TDS</li><li>CALC FLUOR 6X- 1/2 OUNCE - 3TDS</li></ol><p>19/4/22</p><ol><li>PULS 10M 3 DOSES - DOSE WEEKLY</li><li>CALC FLUOR 6X- 1/2 OUNCE - 3TDS</li><li>ZINC MET 30 - 2 DRM PILLS - 4 TDS</li><li>MEDO 10M - 1 DOSE - TONIGHT</li></ol><p>9/5/22</p><ol><li>PULS 10M 2 DRAM TABLETS - 2TABLET WEEKLY</li><li>CALC FLUOR 6X- 1 OUNCE - 2BD</li><li>ZINC MET 30 - 3 DRM PILLS - 4 TDS</li></ol><p><br></p>','2022-06-10 00:00:00'),(83,85,_binary '<p>3/2/22</p><p>ERUPTIONS ON BACK SINCE MANY YEARS</p><p>SMALL ERUPTIONS BLACKISH NO ITCHING ONLY ON BACK</p><p>HAIRFALL SINCE MANY YEARS</p><p>WEAKNESS WITH BREATHLESSNESS PALPITATION</p><p>HAD COVID 2-3 TIMES</p><p>WEAKNESS AFTER THAT</p><p>SLIGHT EXERTION CAUSES BREATHLESSNESS WEAKNESS</p><p>WEAKNESS DURING INTERCOURSE</p><p>22/2/22</p><p>WAS NOT AWARE OF WEAKNESS AS HE WAS TRAVELLING LAST DAYS</p><p>LEFT HANDED PERSON FORCEFULY MADE TO WRITE WITH RIGHT HAND</p><p>ALWAYS SPEAKS ABOUT MATERIALISTIC WEALTH</p><p>SENSATION OF LOSS OF BLOOD IN HANDS..FEELS THERE IS NO CIRCULATION</p><p>DISAPPOINTMENT IN PROFESSION</p><p><br></p><p><br></p>',_binary '<p>3/2/22</p><ol><li>ACID PHOS 30 - 2 DRAM - 4 PILLS QID</li><li>AVENA SATIVA Q - 10 DROPS BD</li><li>NAT MUR 6X - 3 TABLETS 3 TIMES</li></ol><p>21/2/22</p><ol><li>ACID PHOS 30 - 2 DRAM - 4 PILLS QID</li><li>AVENA SATIVA Q - 10 DROPS BD</li><li>NAT MUR 6X - 3 TABLETS 3 TIMES</li></ol><p><br></p>','2022-02-18 00:00:00'),(84,86,_binary '<p>4/2/22</p><p>MIGRAINE SINCE 3- 4 YEARS</p><p>TAKEN ALLOPATHIC AYURVEDIC MEDICINE WITHOUT RELIEF</p><p>PAIN ON BOTH SIDES OF FOREHEAD</p><p>NO SPECIFIC REASON FOR HEADACHE</p><p>MAY START AFTER LOSS OF SLEEP, AFTER BEING IN SUN</p><p>MIGRIANE BEFORE MENSES</p><p>TWITCHING OF EYES FOR TWO DAYS BEFORE HEADACHE STARTS...THEN PAIN STARTS ON THAT PARTICULAR SIDE OF EYES THAT WAS TWITCHING</p><p>HYPOTHYROIDISM SINCE 14 YRS ON THYRONORM 50 MG..HAD INCREASE ANTI TPO LAST TIME WHEN CHECKED.</p><p>HEADACHE NOW ON RIGHT SIDE &lt;SOUND LIGHT</p><p>MENSES REGULAR, HAD DELIVERED TWINS 14 YRS BACK C.SECTION...OTHER CHILD WAS NORMAL DELIVERY</p><p><br></p><p>WORKS IN A SHOP..SLIGHT MENTAL STRESS PRESENT</p><p>SLEEP WAS DISTURBED LAST MONTH HAD TAKEN TABLETS FOR A MONTH.</p><p>USUALLY CONSTIPATED DESIRE TO PASS PRESENT BUT INCOMPLETE.</p><p>12/2/22</p><p>RELIEF FOR PAIN</p><p>NO HEADACHE AFTER MEDICINE</p><p>NEEDS MEDICINE AS IT GOT OVER</p><p><br></p><p>26/2/2022</p><p>ALWAYS GETS HEADACHE PRIOR TO</p><p>MENSENS - MENSENS STOPS THEM</p><p>STARTS HEADACHE - 5/2/2022 - LMP</p><p>REQUIRES DROPS ONLY - OTHER</p><p>MEDICINES IN HAND</p><p><br></p><p>3/3/22 6/4/22</p><p>HEADACHE DAY BEFORE YESTERDAY,BUT NOT AS STRONG AS BEFORE TSH = 1.57</p><p>LMP 5/2/22 T4 = 8.53</p><p>ANTI TPO +VE - 105.2 T3=1.02 HEADACHE NOT THAT SEVER AS BEFORE,GETS SLIGHT HEADAHE</p><p>T3 -0.855 WHICH GOES OF WITH MEDICINE</p><p>T4= 6.40</p><p>TSH = 4.98 HEADACHE LITTLE MOR BEFORE MENSES WAS BIT STRONG AT THAT TIME</p><p>&gt;TIGHT BANDAGE USE TO VOMIT....BUT DIDNT VOMIT THIS TIME GOT MARRIED AT VERY YOUNG AGE, REMARRIED AFTER DIVORCE AFTER</p><p><br></p><p>25/4/22</p><p>REQUIRES SOS MEDICINE</p><p>2/5/22</p><p>HAD SEVERE HEADACHE BEFORE MENSES THIS TIME AS BEFORE</p><p>27/5/22</p><p>HEADACHE ONE DAY ON MENSES DATE</p><p>NOT SO FREQUENT AS BEFORE</p>',_binary '<p>4/2/22</p><ol><li>SANGUINARIA Q - 10ML - 15 DROPS 2 HRLY</li><li>IRIS VER 200 - 2DRAM - 4 PIULLS 2 HRLY</li><li>BRY 200 - 4 PILLS QID</li><li>NAT MUR 10M - 1 DOSE TONIGHT</li></ol><p>12/2/22</p><ol><li>SANGUINARIA Q - 10ML - 10 TD</li><li>IRIS VER 200 - 2DRAM - 4 PIULLS 2 HRLY</li><li>BRY 200 - 4 PILLS TDS SOS</li><li>B24 - 1 AT NIGHT</li></ol><p><br></p><p>26/2/2022</p><ol><li>SANGUINARIA - 10ML 10DROPS TDS</li></ol><p>3/3/22</p><ol><li>TUB 10M - 1 DOSE TONIGHT</li><li>BT 4- 1 AT NIGHT</li><li>BRY 200 2 DRM PILLS SOS 3 2 HRLY</li><li>IRIS VER 200 = 2 DRM PILLS 4 TDS</li><li>SANGUINARIA Q= THEY HAVE IT</li></ol><p>6/4/22</p><ol><li>SANGUINARIA Q - 10ML - 15 DROPS 2 HRLY</li><li>IRIS VER 200 - 2DRAM - 4 PIULLS 2 HRLY</li><li>B24 1/2 OUNCE - 1 AT NIGHT</li><li>NAT MUR 10M - 1 DOSE TONIGHT</li></ol><p><br></p><p>25/4/22</p><ol><li>BRY 200 - 3 DRM PILLS</li></ol><p>2/5/22</p><ol><li>TUB 10M - 1 DOSE AT NIGHT 2/5/22</li><li>NAT MUR 10M - 1 DOSE AT 9/5/22</li><li>NAT MUR 6X - 1/2 OUNCE - 3 TDS + IRIS VERS 200</li><li>SANGUINARIA Q + GELS 200 - 30ML</li></ol><p>27/5/22</p><ol><li>SANGUINARIA Q - 20ML - 15 TDS</li><li>NAT MUR 6X +IRIS 200 - 1/2 OUNCE - 3TDS</li><li>SEPIA 200 - 2 DOSE WEEKLY ONCE</li><li>BRYONIA 200 - 2 DRM PILLS - SOS</li></ol>','2022-06-10 00:00:00'),(85,87,_binary '<p>4/2/22</p><p>FEVER SINCE YESTERDAY</p><p>FEVER WITH CHILLINESS. BODY ACHE</p><p>WITH THROAT PAIN NO COUGHT AT PRESENT</p><p>HEADACHE+++</p><p>SLIGHT CONGESTION IN THROAT</p><p>H/O HEARTBURN BEFORE  ALSO &lt;AFTER EATING, </p>',_binary '<p>4/2/22</p><ol><li>EUPATORIUM Q + BAPT 3X = 15 DROPS 2 HRLY</li><li>BELL 200 - 4 QID</li><li>GELS 200 = 4 PILLS 2HRLY</li><li>BELL 1M = 3 DOSES =- SOS </li></ol>','0001-01-01 00:00:00'),(86,88,_binary '<p>8/2/22</p><p>KNEE JOINT PAINFUL</p><p>&lt;FIRST MOTION</p><p>&gt;CONTINUED MOTION</p><p>THIRST ; DRINKS FREQUENTLY</p><p>PAIN SINCE 2 WEEKS</p><p>HAD SIMILAR ISSUES 2 WEEKS BACK</p><p>TAKEN AYURVEDIC TREATMENT 6 MONTHS AND THEN REDUCED</p><p>NORMAL DELIVERY- 22 YRS MALE CHILD , 7YRS GIRL</p><p>MENSES REGULAR</p><p>23/2/22</p><p>DIDNOT FEEL ANY CHANGE WHILE TAKING MEDICINE PAIN IS SAME AS BEFORE</p><p>SWELLING ON RT KNEE SLIGHTLY REDUCED</p><p>LEFT KNEE PAIN SLIGHTLY REDUCED</p>',_binary '<p>8/2/22</p><ol><li>BRY Q - 10ML - 10 TDS</li><li>CALC FLUOR - 6X - 3 TDS</li><li>CAUSTICUM 10M - 2 DOSE WEEKLY</li></ol><p>23/2/22</p><ol><li>NAT MUR 10M - 1 DOSE</li><li>BRYONIA 200 2 DRM PILLS </li><li>HEKLA LAVA 3X - 1 BD</li><li>BRY Q - 10ML - 15 TDS</li></ol>','2022-02-23 00:00:00'),(87,89,_binary '<p>10/2/22</p><p>WARTS ON HANDS..FINGERS ESPECIALLY</p><p>SKIN TAGS WITH ITCHING IN NECK</p><p>DARK DISCOLORATION AROUND EYES</p><p>MENSES REGULAR</p><p>DELIVERY ; 9YRS BOY C-SECTION - LOW LYING PLACENTA</p><p>PERSPIRATION - ++ SLIGHT OFFENSSIVE</p><p>DESIRES - SPICY + SALT+ NONVEG</p><p>28/2/22</p><p>WARTS ABOUT TO COME OUT</p><p>DARK CIRCLE AROUND EYES REDUCED</p><p>19/3/22</p><p>WARTS LITTLE MORE TO COME OUT</p>',_binary '<p>10/2/22</p><ol><li>SAR CREAM</li><li>CAUSTICUM 1M - 2 DRM PILLS - MORNING N NIGHT</li><li>THUJA 30 2 DRM PILLS - AFTERNOON N EVENING</li><li>SALICYLIC ACID Q - TO APPLY AT NIGHT</li></ol><p>28/2/22</p><ol><li>CAUSTICUM 1M - 2 DRM PILLS - MORNING N NIGHT</li><li>THUJA 30 2 DRM PILLS - AFTERNOON N EVENING</li><li>THUJA Q - TO APPLY AT NIGHT</li><li>BOROALLEN CREAM</li></ol><p>19/3/22</p><ol><li>SAR CREAM</li><li>CAUSTICUM 1M - 2 DRM PILLS - 4 QID</li><li>ANT CRUD 200 - 2 DRM - 4 QID</li></ol>','2001-01-01 00:00:00'),(88,90,_binary '<p>10/2/22</p><p>PAIN IN LEFT SHOULDER JOINT AND HAND</p><p>&lt;MORNING WAKING WHILE</p><p>H/O FALL ON OUTSTRETCHED HAND,DONE SURGERY FOR SAME HAND AND STEEL IMPLANTED</p><p>SLIGHT NUMBNESS WITH</p><p>TAKING THYROID MEDICINES</p><p>3 C-SECTIONS</p><p><br></p><p><br></p>',_binary '<p>10/2/22</p><ol><li>ARNICA 1M - 2 DOSE </li><li>FOLLOWED BY RHUS TOX 10M - 1 DOSE</li><li>SANGUINARIA C 200 - 4 TDS</li><li>CALC PHOS 6X - 1/2 OUNCE 3 TDS</li></ol>','2022-02-22 00:00:00'),(89,91,_binary '<p>12/2/22</p><p>ALLERGY SINCE MANY YEARS</p><p>SNEEZING CONTINOUS &lt; MORNING STRONG ODOR LIKE FISH FRY</p><p>&lt;COLD WEATHER MORNING</p><p>ITCHING IN THROAT EYES REDNESS</p><p>H/O NASAL POLYP</p><p>MOTHER; DIED AT VERY YOUNG AGE</p><p><br></p><p>23/2/22</p><p>SNEEZING AND COLD PERSISTING</p><p>RELIEF FELT ONLY FOR 2 DAYS AFTER MEDICINE INTAKE</p><p>PEELING OF SKIN FROM HAND WITH ITCHING AND PERSPIRATION IN HAND</p><p>CONTINOUS RUNNING NOSE</p><p>SNEEZING</p><p>9/3/22 </p><p>HEADACHE WITH SNEEZING..FATHER CAME  FOR  MEDICINE AS PER HIM NOT FELT MUCH RELIEF</p>',_binary '<p>12/2/22</p><ol><li>ARS ALB 10 M - 1DOSE AT NIGHT</li><li>ARS ALB 10M - 3 DOSES SOS</li><li>SABADILLA 30 2 DRM - 4 TDS</li><li>NASAL DROPS LEMNA +NUX 30</li><li>LEMNA MINOR +9 DROPS POTHOS Q - 10 TDS</li></ol><p>24/2/22</p><ol><li>LYSSIN 30 2 DOSES= WEEKLY ONCE</li><li>POTHOS Q - 20ML - 15 TDS</li><li>AMM CARB 30 - 2 DRM PILLS 4 TDS</li><li>ALLIUM CEPA 30 - 2 DRM PILLS - 4 TDS</li></ol><p>9/3/22</p><ol><li>PSORINUM 200 - 2 DOSE WEEKLY ONCE</li><li>SILICEA 6X - 1/2 OUNCE - 3 TDS</li><li>ALLIUM CEPA 30 - 2 DRM PILLS - SOS 1 HRLY - 4 TDS</li></ol>','2022-03-23 00:00:00'),(90,92,_binary '<p>12/2/22</p><p>SINUSITIS</p><p>&lt;BENDING</p><p>COUGH  AFTER TAKING COILD WATER ONLY</p><p>NOSE BLOCK</p><p>SLEEP; INCREASED - FEELS SLEEPY FATIGUE</p><p><br></p>',_binary '<p>12/2/22</p><ol><li>KALI BICH 1M - 2 DOSES</li><li>SILICEA 6X - 3 TDS - 1/2 OUNCE</li><li>PULS 200 - 2 DRM - 4 QID</li></ol>','0001-01-01 00:00:00'),(91,93,_binary '<p>12/2/22</p><p>ALLERGY SINCE 1 YEAR</p><p>SNEEZING &lt; FANNING DUST NIGHT SNEEZE TILL ASLPEEP MORNING WAKING AFTER</p><p>MENARCHE - 6-7 MONTHS BACK ONLY</p><p>FLOW LASTS FOR 11 DAYS</p><p>FLOW SEVERE FOR FIRST  DAYS</p><p>MENSES REGULAR ON DATE</p><p>C/O RASHES ON CHEEKS AND FOREHEAD AFTER APPLYING OIL ON HEAD</p><p>PERSPIRATION SLIGHTLY OFFENSSIVE</p><p>THIRST ; THIRSTLESS</p><p>DESIRES ; FRIED FOOD NON VEG SPICY FOODS</p><p>HEADACHE NOW A DAYS AFTER TAKING POORI [DEEP FRIED? AATTA?]</p><p>O/E SLIGHT ENLARGEMENT IN NOSTRILS</p>',_binary '<p>12/2/22</p><ol><li>ARS ALB 10 - 1 DOSE</li><li>ARS ALB 10M - 3 DOSE- SOS</li><li>SABADILLA 30 - 2 DRM - 4TDS</li><li>LEMNA MINOR +POTHOS Q - 10ML- 10TDS</li><li>NASAL DROPS</li><li>SARCREAM</li></ol>','2022-02-26 00:00:00'),(92,94,_binary '<p>16/2/22</p><p>COUGH WITH EXPECTORATION</p><p>COLD,NOSE OBSTRUCTED</p><p>NO FEVER</p><p>17/3/22</p><p>COUGH WITH EXPECTORATION</p><p>NASAL DISCHARGE NO FEVER</p><p>25/5/22</p><p>FEVERISH SINCE YESTERDAY</p><p>COLD SINCE LONG TIME</p><p>NO COUGH</p><p>PASSED MOTION 5 TIMES SINCE MORNING</p><p>VOMITED TWICE</p><p>28/5/22</p><p>CHILD IRRITABLE CRYING WITH, NOSE BLOCK</p><p>&gt;CARRYING STOPS CRYING</p><p>NOSE BLOCK AT NIGHTDIFFICULT BREATHING</p><p>23/6/22</p><p>LAST TIME FEVER REDUCED</p><p>COUGH ,&lt;AT NIGHT</p><p>WITH EXPECTORATION</p><p>WATERY NASAL DISCHARGE</p><p>IRRITABILITY &gt;AFTER CARRYING</p>',_binary '<p>16/2/22</p><ol><li>BRY 200 2 DRM PILLS- 3 QID</li><li>ANT TART 10M - 2 DRM PILLS - 3 QID</li><li>BAPTISIA 3X - 5 DROPS 2 HRLY SOS FEVER</li></ol><p>17/3/22</p><ol><li>ANT TART 6C - 2 DRM TABS- 1 TDS</li><li>PULS 200- 2 DRM PILLS - 3TDS</li></ol><p>26/5/22</p><ol><li>BAPTISIA 3X - 5ML - 5 DROPS 2 HRLY OR 4 TIMES</li><li>ARS ALB 200 - 2 DRM PILLS - 2 PILLS 2 HRLY</li><li>BELL 1M - 3DOSE SOS</li></ol><p>28/5/22</p><ol><li>ARNICA 200 - 2 DRAM PILLS - 3 PILLS ALTERNATE WITH ARS ALB</li><li>CHAMOMILLA 200 - 6 DOSE - 1 DOSE BD</li></ol><p>23/6/22</p><ol><li>IPECAC 3X - IN 2 DRAM PILLS - 3TDS- </li><li>ANT TART 6C - 2 DRM PILLS -3 TDS</li></ol><p><br></p>','2022-02-24 00:00:00'),(93,95,_binary '<p>16/2/22</p><p>MENORRHAGIA REDUCED</p><p>INCREASED FLATULENCE VER DIFFICULT NOW</p><p><br></p>',_binary '<p>16/2/22</p><ol><li>SULPH 10M - 1 DOSE ON 20/2/22</li><li>ALETRIS FARINOSA Q -20ML- 10 DROPS NIGHT ONLY</li><li>BT 4 - 1 AT MORNING ONLY</li></ol>','2022-03-16 00:00:00'),(94,96,_binary '<p>16/2/22</p><p>HAD FEVER 2 DAYS BACK</p><p>COUGH WITH EXPECTORATION</p><p>SLIGHTLY ONLY</p><p>NASAL DISCHARGE NOT MUCH THICK</p><p><br></p><p>17/3/22</p><p>COUGH WITH EXPECTORATION</p><p>NASAL DISCHARGE THICK</p><p>26/5/22</p><p>THICK NASAL DISCHARGE</p><p>8/7/22</p><p>FEVER SINCE YESTERDAY WITH BLISTERS</p><p>DRY COUGH WITH FEVER</p><p>NASAL DISCHARGE WATERY</p>',_binary '<p>16/2/22</p><ol><li>ANT TART 10M - 2 DRM PILLS 4 QID</li><li>PHOS 30 - 2 DRAM PILLS - 4 QID</li><li>GRINDELIA Q - 5 ML - 6 DROPS TDS</li></ol><p>17/3/22</p><ol><li>PULS 200 = 2 DRM PILLS 4 TDS</li><li>ANT TART 6C - 2 DRM TABLETS= 1 TAB TDS</li></ol><p>26/5/22</p><ol><li>PULS 200 - 2 DRAM PILLS - 4 TDS</li><li>SAMBUCUS 30 - 2 DRM PILLS - 4 TDS</li></ol><p>8/7/22</p><ol><li>MERC SOL 1M - BD</li><li>BELL 200 ALTERNATE WITH </li><li>RHUS TOX 200</li><li>BELL 1M 3 DOSE SOS</li></ol>','2022-02-24 00:00:00'),(95,97,_binary '<p>18/2/22</p><p>DRYNESS IN MOUTH</p><p>ALWAYS FEELS LIKE SWALLOWING SALIVA</p><p>DRYNESS ++ IN MOUTH</p><p>BURNING IN THROAT</p><p>&lt;STRONG ODOUR &lt;FISH FRY CAUSES DRY</p><p>DRY COUGH</p><p>NO SNEEZING</p><p>PAIN IN CALF MUSCLES&lt; NIGHT</p><p>MENOPAUSE 10YRS BACK @ 49</p><p><br></p><p>2/4/22</p><p>DRY COUGH SINCE YESTERDAY</p><p>BURNING ON TONGUE</p><p>BURNING IN THROAT</p><p>&lt;SPICY FOOD</p><p>DRY COUGH AT NIGHT</p><p>&lt;FAN</p><p>PRICKING IN THROAT</p><p>ITCHING IN THROAT</p><p>PAIN IN THROAT</p><p>TONSILLECTOMY DONE YEARS BACK</p><p>1/7/22</p><p>BURNING ERUCTATIONS</p><p>PHARYNGITIS</p><p>PAIN IN STOMACH, HISTORY OF GASTRIC ULCER</p><p>DRYNESS OF MOUTH</p><p>BOWELS CONSTIPATED SINCE SOME DAYS</p><p>ALLERGIC TO MOSQUITO BITE</p><p>FASTIDIOUS++</p><p>MENOPAUSE 9YRS BACK</p><p>23/7/22</p><p>HEADACHE SINCE SOME DAYS</p><p>PAIN IN RIGHT SHOULDER</p><p>NO COLD</p><p>THROAT PAINFUL WITH BURNING</p><p>DRYNESS OF MOUTH</p><p>USUALLY GETS LEFT SIDED HEADACHE</p><p>NOW PAIN IN WHOLE FRONTAL SIDE</p><p>?SINUSITIS</p><p>28/7/22</p><p>ERUCTATIONS ALWAYS</p><p>WAKES FROM SLEEP AFTER</p><p>&gt;MORNING &lt;EATING AFTER</p><p>BURNING AFTER EATING FOOD</p><p>&gt;EMPTY STOMACH</p><p>BURNING IN THROAT, SHORT DRY COUGH WITH LITTLE EXPECTORATION</p><p>LEFT SIDED HEADACHE WITH PAIN IN MAXILLARY SINUS</p><p>AILMENTS AFTER COVID INFECTION</p><p>COUGH &lt; DAY TIME, TALKING, ALWAYS BLIND ERUCTATIONS</p><p>APETITE DECREASED</p><p>3/8/22</p><p>TONGUE SCALY PRICKING TYPE</p><p>ERUPTIONS INSIDE MOUTH</p><p>BURNING INSIDE MOUTH &lt; SPICY FOOD</p><p>WATER INTAKE TO INCREASE</p><p>BOWELS NOT THAT REGULAR</p><p>THERMALS - HOT PT</p><p>29/8/22</p><p>SWELLING AT BACK OF KNEE</p><p>PAIN SEVERE &lt; NIGHT  LYIND DOWN</p><p>GASTRIC ISSUES SINCE MORNING</p><p>BP - 130/90 MM </p><p><br></p><p><br></p><p><br></p>',_binary '<p>18/2/22</p><ol><li>HYDRASTIS Q 15 DROPS TDS</li><li>CALC PHOS 6X 3 TDS</li><li>NUX MOSCH 200 4 TDS</li></ol><p>2/4/22</p><ol><li>HYOS 30 - 3 DRM TAB- 3TDS</li><li>ARALIA RACEMOSA Q - 5ML - 10 TDS</li></ol><p>1/7/22</p><ol><li>HYDRASTIS Q 15 DROPS TDS - 20ML</li><li>CALC PHOS 6X 3 TDS - 1/2 OUNCE</li><li>CARCINOSIN 200 - 2 DOSE WEEKLY ONCE</li><li>NUX MOS 200 - 2 DRM PILLS - 4 TDS</li></ol><p>23/7/22</p><ol><li>SILICEA 1M - 2 DOSE</li><li>KALI BICH 6X 2 TDS</li><li>BAPTISIA +HYDRASTIS Q - 10ML - 10 QID</li><li>FP 6X +BELL 1M SOS - 4 QID</li></ol><p>28/7/22</p><ol><li>NUX VOM 30 - 2 DRM PILLS - 3 2 HRLY</li><li>BRY 200 - 2 DRM - 4 QID</li></ol><p>3/8/22</p><ol><li>MERC SOL- 1M - BD - 6 DOSE WEEKLY ONCE</li><li>HYDRASTIS Q - 20ML- 10 TDS</li><li>NAT PHOS 6X - 1/2 OUNCE - 3 TDS</li></ol><p>29/8/22</p><ol><li>ZINGIBER Q - 20ML - 10 DROPS TDS</li><li>RHUS TOX 1M IN CALC FLUOR 6X - 1/2 OUNCE 3 TDS</li><li>ZINC MET 30 - 3 DRM PILLS - 4 QID</li></ol><p><br></p>','2022-07-16 00:00:00'),(96,98,_binary '<p>22/2/22</p><p>SLIGHT FEVERISH YESTERDAY</p><p>COUGH SLIGHTLY MORNING ANS NIGHT DAY BEFORE YESTERDAY</p><p>SLEPT IN AC LAST 2 DAYS</p><p>SLIGHT RATTLING IN CHEST WHILE FEEDING</p><p>STARTED SEMI SOLID FOOD SINCE LAST FEW DAYS</p><p>BOWELS = REGULAR</p><p>PERSPIRATION ON HEAD = +</p>',NULL,'0001-01-01 00:00:00'),(97,99,_binary '<p>22/2/22</p><p>ECZEMA SINCE 20 YRS</p><p>STARTS AS PUS FILLED ERUPTIONS</p><p>ITCHING+++</p><p>SWELLING++</p><p>BLEEDING+</p><p>DISCHARGE ++ STICKY</p><p>PAINFUL+++</p><p>MARRIED 3 KIDS</p><p>WIFE WANTS DIVORCE,STRESSULL AND ANXIOUS BECAUSE OF THAT</p><p>H/O SAME COMPLAINT IN FATHER</p><p>ITCHING &gt;BATHING AFTER</p><p>BURNING++</p><p>ITCHING STARTS EVENING INCREASES TILL SLEEP</p><p>SLIGHT THICK WHITE SCAB</p><p>THIRST +++</p><p>1/3/22</p><p>ITCHING SEVERE SINCE 2 DAYS</p><p>OEDEMA WAS MORE YESTERDAY REDUCED SLIGHTLY TODAY BUT PAINFUL</p><p>URINE BREAKS IN BETWEEN</p>',_binary '<p>22/2/22</p><ol><li>ECHINACEA Q 20ML- 15 TDS</li><li>KALI MUR 6X - </li><li>CALENDULA SOAP</li><li>MERC SOL 1M - 1 DOSE TONIGHT 22/2</li></ol><p>1/3/22</p><ol><li>CALENDULA SOAP</li><li>CALENDULA Q= EXTERNAL </li><li>ACID NIT 1M - 2 DOSE BD</li></ol>','2022-03-09 00:00:00'),(98,100,_binary '<p>23/2/22</p><p>URTICARIA SINCE 10YRS</p><p>&lt;SWEATING AFTER BEING IN SUN</p><p>&gt;COLD , BATHING AFTER</p><p>PERSPIRATION +++ FULL BODY</p><p>&lt;CHANGE OF SEASON FROM COLD TO HOT</p><p><br></p><p>7/3/22</p><p>URTICARIA PERSISTING</p><p>NO RELIEF</p><p>HAS ISSUES WHILE CHANGE OF SEASON</p><p>&lt;HOT SEASON</p><p>&gt;NIGHT EVENING BATHING</p><p>WHEN SEVERE ITCHING IN EYES</p><p><br></p><p>14/3/22</p><p>SLIGHT DIFFERENCE ONLY FELT FOR 3 DAYS</p><p>PERSPIRATION VERY SEVERE FOR FULL BODY</p><p>TAKES BATH 3 4 TIMES A DAY</p><p>&gt;BATHING</p><p><br></p>',_binary '<p>23/2/22</p><ol><li>NAT MUR 10M - 1 DOSE</li><li>APIS 200 - 2 DRAM - 4 QID</li><li>URTICA URENS Q - 10ML - 15 TDS</li><li>URTICA URENS Q -30ML - EXT APPLICATION</li></ol><p>7/3/22</p><ol><li>BACILLINUM 10M - 1 DOSE TONIGHT</li><li>BOVISTA 30C - 5ML- 5 DROPS IN HALF GLASS WATER- 1 SPOON HOURLY</li></ol><p><br></p><p>14/3/22</p><ol><li>APIS 1 M - 4 DOSE- 1 OM ALTERNATE DAYS NIGHT</li><li>NAT CARB 30 - 3 DRM PILLS - 4 QID</li></ol>','2022-03-04 00:00:00'),(99,101,_binary '<p>214/2/22</p><p>TINEA ALBA ON FACE ONLY</p><p>SINCE 1 YEAR..TAKEN HOMOEO TREATMENT 2 YRS BACK AND COMPLAINT REDUCED</p><p>NOW STARTED AGAIN</p>',_binary '<p>24/2/22</p><ol><li>SAR CREAM</li><li>BACILLINUM 10M - 2 DOSES WEEKLY ONCE</li><li>TELLURIUM 30 - 2 DRAM PILLS - 4 TDS</li></ol>','2022-03-12 00:00:00'),(100,102,_binary '<p>26/2/2022</p><p><br></p><p>H/O - MI - ANGIPLASTY DONE</p><p>FACING ASPIRIN MEDICINES</p><p>H/O - BP</p><p>CONSTENT DESIRE TO PASS URINE</p><p>PASSES URINE FREQUENTLY 2-3 TIMES IN 1HR</p><p>H/O - COUGH WITH EXPECTORATION</p><p>&lt;EARLY MORNING 3AM WHEN WAKES FOR FISH, FISH MERCHANT</p><p>PERSPIRATION ++ ON FACE</p><p><br></p><p>8/3/22</p><p>COMPLAINTS SLIGHTLY REDUCED</p><p>SUDDEN URGE TO PASS REDUCED</p><p>PHLEGM VERY DIFFICULT TO COME UP- VERY THICK YELLOW -</p><p>RESPIRATORY ISSUES &lt; 3AM - 4 AM</p><p>22/3/22</p><p>COUGH SINCE FEW DAYS</p><p>WAS VERY MUCH BETTER, COUGH STARTED AFTER GRAVELING IN HOT SUN TO CHAVAKKAD ON BIKE FOR HOSPITAL VISIT</p><p>\\COUGH &lt;LYING DOWN AT NIGHT</p><p>PAIN IN TOES AND FINGERS URIC ACID IS SLIGHYLY HIGH</p><p>LOCATION OF PAIN CHANGES</p><p><br></p><p>30/3/22</p><p>90% OF COUGH AT NIGHT</p><p>COUGH IMMEDIATELY AFTER LYING DOWN</p><p>PHLEGM VERY DIFFICULT TO COME UP COUGH UNTIL IT COMES UP</p><p>H/O SMOKING,,NOT NOW</p><p><br></p><p>7/4/22</p><p>FEELING BETTER FOR COUGH</p><p>URINE N GOUT PAIN ALMOST SAME</p><p>PAIN WANDERING FROM ONE JOINT TO OTHER</p><p><br></p><p>16/4/22</p><p>BLOOD TEST ON 16/3 PPBS - 173</p><p>CHOLESTROL = 157.1</p><p>S.CREATININE - 0.92</p><p>S.URIC ACID = 6.2</p><p>PAIN FOR SMALL JOINTS REDUCED</p><p>URINE DIFFICULT TO HOLD SEVERE BEFOR NOW NOT SO URGE TO PASS</p><p>BUT URINE ISSUES SLIGHTLY PERSSISTING</p><p><br></p><p>9/5/22</p><p>REQUIRES COUGH MEDICINE</p><p>8/6/22</p><p>BURNING IN STOMACH AFTER TAKING JACK FRUIT IN EMPTY STOMACH</p><p>PHLEGM COMING IN THROAT LIKE BEFORE</p><p>23/7/22</p><p>FEELING BETTER FOR WHEEZING</p><p>NEEDS TABLETS DROPS THEY HAVE</p><p>BP - 160/80 MM OF HG</p><p>26/8/22</p><p>NEEDS MEDICINE FOR COUGH, RATTLING,</p>',_binary '<p>26/2/22</p><ol><li>KALI CARB 1M (1 DOSE)</li><li>EQUISETUM 200 4 TDS 2DM</li><li>HYDRANGEA 20ML 15 TDS</li></ol><p><br></p><p>8/3/22</p><ol><li>NUX VOM 1M - 2 DOSE WEEKLY</li><li>HYDRANGEA Q - 20ML - 15TDS</li><li>EQUISETUM 200 - 2 DRM - 4 TDS</li></ol><p>22/3/22</p><ol><li>RHUS TOX 1M - 2DOSE</li><li>KALI BICH 6X +DROSERA 1M - 2TDS</li><li>YERBA SANTA Q - 10ML- 15GTT TDS</li><li>OCIMUM CAN Q - 10ML - 10TDS</li></ol><p>30/3/22</p><ol><li>DROSERA 1M - 10ML TAB 3 TDS</li><li>GRINDELIA Q - 10ML- 15GTT TDS</li><li>OCIMUM CAN Q - 10ML - BDTDS</li></ol><p>7/4/22</p><ol><li>GRINDELIA Q 1OML - 15 GTT SOS</li><li>URTICA URENS Q - 10ML- 15 TDS</li><li>ACID BENZ 30 - 2 - DRM PILLS - 4 TDS</li></ol><p>16/4/22</p><ol><li>NUX VOM 1M - 2 DOSE</li><li>URTICA URENS Q - 20ML- 10BD</li><li>ACID BENZ - 30 - 3DRM - 4 TDS</li></ol><p>10/5/22</p><ol><li>GRINDELIA Q 2OML - 15 GTT SOS</li></ol><p>8/6/22</p><ol><li>GRINDELIA Q - 20ML - 10 TDS</li><li>NUX VOM 3O - 2 DRM PILLS - 3 5 TIMES</li><li>KALI BICH 6X - 3 DRM TABLETS - 2 BD</li></ol><p>23/7/22</p><ol><li>KALI BICH 6X - 3 DRM TABLES - 2 BD</li><li>NUX VOM 30 - 2 DRM PILLS - 5 TDS</li></ol><p>26/8/22</p><ol><li>GRINDELIA Q - 20ML - 10 TDS</li><li>KALI BICH 6X - 3 DRM TABLES - 2 BD</li></ol><p>NEEDS MEDICINE FOR HAIRFALL FOR DAUGHTER</p><ol><li>WEIBADEN 30 + KALI SULPH 6X 1/2 OUNCE - 3 TDS</li><li>ACID PHOS 200 - 3 DRM PILLS 4 TDS</li><li>ARNICA HAIROIL</li></ol>','2022-05-24 00:00:00'),(101,103,_binary '<p>1/3/22</p><p>COUGH WITH EXP;ECTORATION</p><p>NOSE BLOCKED AT TIME</p><p>SNEEZING &lt; MORNING</p><p>H/O ADMISSION AFTER PHLEGM IN CHEST</p><p>O/E TONGUE CLEAN</p><p>CHEST = NS</p><p>8/3/22</p><p>STAYING IN GULF SINCE 9 YRS</p><p>UTI - 20-25 PUS CELLS</p><p>SERUM URIC ACID - 8.7MG/DL</p><p>SNEEZING AND COUGH REDUCED</p><p>HAD DANDRUFF</p><p>PERSPIRATION ++ HAND AND FOOT</p>',_binary '<p>1/3/22</p><ol><li>KALI BICH 6X - 4 TDS 1/2 OUNCE</li><li>GRINDELIA Q - 20ML 15TDS</li><li>RHUS TOX 200 - 1 DOSE</li></ol><p>8/3/22</p><ol><li>OCIMUM CAN Q - 20ML - 15 DROPS TDS</li><li>BERB VULGARIS 30 - 2 DRM PILLS \\</li></ol><p>HAIR GROW GEL </p>','2022-03-15 00:00:00'),(102,104,_binary '<p>2/3/22</p><p>ALLERGIC COUGH SINCE MANY YEARS</p><p>H/O ALLERGY IN FAMILY</p><p>H/O FEVER 1 MONTH BACK</p><p>COUGH NOW STARTED AFTER FEVER</p><p>DRY KIND COUGH &lt; NIGHT AFTER LYING</p><p>STARTED DURING DAY TIME NOW</p><p>COUGH CONTINUES TO WHEEZING NOW</p><p>DRY SHORT COUGH FOR 3 TIMES</p><p>O/E CHEST WHEEZING BOTH SIDES</p><p>TONGUE CLEAN</p><p>H/O ALLERGIC COUGH</p><p>DRY COUGH WITHOUT EXPECTORATION, WITH ITCHING IN THROAT.</p><p>7/3/22</p><p>COUHG WITH EXPECTORATION SLIGHT ONLY</p><p>2-3 COUGHS AND WHEEZING STARTS</p><p>&lt; NIGHT LYING DOWN AFTER</p><p>14/3/22</p><p>ITCHING IN SIDES OF THROAT BEFORE COUGH STARTS</p><p>COUGH END IN WHEEZING</p><p>NO PHLEGM NOW</p><p>4/4/22</p><p>SEVERE COUGH NOW ALSO...NO RELIEF AFTER MEDICINE</p><p>DRY COUGH &lt;NIGHT..CONTINOUS COUGH LEADS TO WHEEZING</p><p>&lt;AFTER HEAD SWEATS</p><p>COUGH STARTED AFTER FEVER AND COLD LONG BACK</p>',_binary '<p>2/3/22</p><ol><li>NAT SULPH 1M - 1 DOSE</li><li>BRY 200 - 2 DRAM PILLS - 4 QID</li><li>DROSERA 1M - 2 DRAM PILLS - 4 QID</li></ol><p>7/3/22</p><ol><li>GRINDELIA TINCTURE - 20ML</li><li>PHOS 30 - 2 DRM PILLS - 4 QID</li><li>LYSSIN 30 - 1 DOSE</li></ol><p>14/3/22</p><ol><li>RUMEX 200 - 2 DRM PILLS - 4 QID</li></ol><p>4/2/22</p><ol><li>ARALIA Q - 10ML - 15 GTT TDS</li><li>HYOS 30 - 2 DRM PILLS - 4 TDS</li><li>SANG NIT - 30 - 2DRM PILLS - 4 TDS</li></ol>','2022-03-15 00:00:00'),(103,105,_binary '<p>4/3/22</p><p>ALLERGY SINCE MANY YEARS</p><p>WAS TATKING HOMEO TREATMENT FROM ALPHA CARE FOR LAST ONE YEAR</p><p>COMPLAINTS REDUCED AND NOW STARTED AGAIN O STOPPING MEDICINES</p><p>H/O ECZEMA ---TAKEN 7YRS LOCAL TREATMENT</p><p>H/O ASTHMA</p><p>SNEEZING CONTINOUSLY</p><p>&lt;MORNING , NIGHT AFTER SLEEPING FOR A WHILE</p><p>NOSE BLOCK</p><p>REDDISH PHLEGM</p><p>INCREASED PERSPIRATION---SAME ISSUE FOR ELDER BROTHER ALSO.....FATHER VERY STRICT</p><p>THIRSTLESS</p><p>DESIRES COVERING AT NIGHT INCUDING HEAD</p><p>DESIRES COLD DRINK ICE</p><p><br></p><p>25/3/22</p><p>SNEEZING REDUCED WHILE TAKING MEDICINE</p><p>HAVING SEVERE WEAKNESS WITH DROPS</p><p>ITCHING IN EYES PRESENT WHILE TAKING MEDICINE ALSO</p><p>23/4/22</p><p>NOSE BLOCK AT NIGHT</p><p>SNEEZING REDUCED</p><p>ITCHING IN EYES PRESENT</p><p>ERUPTIONS IN EYES</p><p>PERSPIRATION AND ALL OTHER DISCHARGES ARE STILL HIGHLY OFFENSSIVE</p><p>17/5/22</p><p>SENSATION OF PHLEGM IN THROAT</p><p>ITCHING IN EYES AND AND SNEEZING ONCE MEDICINE GOT OVER</p><p>NOSE BLOCK AT NIGHT</p><p>&lt;EARLY MORNING WHEN WAKING UP</p><p>11/6/22</p><p>SNEEZING REDUCED</p><p>PHLEGM STILL COMING UP</p><p>VERY TIRED SLEEPY ALWAYS</p><p>ASKED TO CHECK BLOOD</p><p>14/7/22</p><p>ITCHING IN EYES</p><p>NOSE BLOCK WITH PHLEGM COMING UP...GREENISH IN COLOUR\'</p><p>29/8/22</p><p>COMPALINTS PERSISTING AS SAME </p><p>&lt; MORNING , BATHING</p><p>ITCHING IN EYES THROAT,</p><p>HAD FEVER WITH THROAT PAIN AND COUGH</p><p>DRY COUGH WITH</p>',_binary '<p>4/3/22</p><ol><li>ACID NIT 1M - 2 DOSE BD</li><li>ARALIA +POTHOS+SENEGA Q - 20ML - 10 SDROPS TDS</li><li>ARS ALB 30 - 2 DRM - 4 QID</li></ol><p>25/3/22</p><ol><li>EUPHRASIA EYE DROPS</li><li>ARS ALB 30 - 4 TDS</li><li>SULPH - PSOR 200 - 3 DOSE WEEKLY ONCE</li><li>NAT SULPH 6X - 1/2 OUNCE - 2TDS</li></ol><p>23/4/22</p><ol><li>EUPHRASIA EYE DROPS</li><li>ARS ALB 30 - 4 TDS</li><li>SULPH - PSOR 200 - 3 DOSE WEEKLY ONCE</li><li>PULS200 - 4TDS</li></ol><p>17/5/22</p><ol><li>KALI BICH 6X - 1/2 OUNCE - 2 TDS</li><li>AR ALB - 30 - 2 DRM PILLS - 4 TDS</li><li>SULPH 200 - 3 DOSE - WEEKLY ONCE</li><li>EUPHRASIA EYE DROPS</li></ol><p>14/7/22</p><ol><li>PULS 200 - 2DRM PILLS 4 TDS</li><li>SILICEA 1M 3 DOSE WEEKLY ONCE</li><li>KALI BICH 6X - 1/2 OUNCE - 2 TDS</li></ol><p>29/8/22</p><ol><li>PHYTOLACCA Q + BELL Q  - 10ML - 10 DROPS QID</li><li>BELL 200 - 2 DRM PILLS ALTERNATE WITH</li><li>RHUS TOX - 200 - 2 DRM PILLS</li><li>BELL 1M - 4 DOSE SOS</li></ol>','2022-06-01 00:00:00'),(104,106,_binary '<p>7/3/22</p><p>RUNNING NOSE AND COUGH SLIGHTLY</p><p>FEVER &lt;NIGHT AFTER GETTING TO BED</p><p>TONGUE SLIGHTLY COATED</p><p><br></p>',_binary '<p>7/3/22</p><ol><li>BAPTISIA 3X- 4 DROPS TDS</li><li>BRY 200 - 2 DRM PILLS 4 TDS</li><li>ANT TART 6C - 2 DRM PILLS 4 TDS</li><li>BELL 1M - 4 DOSES</li></ol>','0001-01-01 00:00:00'),(105,107,_binary '<p>7/3/22</p><p>THICK NASAL DISCHARGE</p><p>SINCE 2 DAYS</p><p>SLIGHT FEVERISH</p><p>27/8/22</p><p>FEVER SINCE 2 DAYS </p><p>NOW RATTLING WITH INCREASED RWSPIRATORY RATE</p><p>VOMITED 4-5 TIMES SINCE AFYERNOON</p><p>DROWSY?</p><p><br></p><p><br></p><p><br></p>',_binary '<p>7/3/22</p><ol><li>PULS 200 - 2 DRM PILLS - 3PILLS QID</li><li>BAPTISIA 3X - 5ML - 3 DROPS QID</li></ol><p>27/8/22</p><ol><li>PHOS 30 - 2 DRM PILLS- 3 PILLS ALTERNATE WITH</li><li>VERAT VIRIDE 200 - 2 DRM PILLS 3 PILLS 2 HRLY</li><li>BELL 1M - 5 DOSE SOS</li><li>NAT SULPH 6X - 3 DRM TABLETS - 2 QID</li></ol><p><br></p>','0001-01-01 00:00:00'),(106,108,_binary '<p>7/3/22</p><p>C/O ALLERGIC ASTHMA SINCE 13 YRS</p><p>USING INHALER WHENEVER THERE IS WHEEZING</p><p>&lt; DUST WINTER STRONG ODOR</p><p>RECURRANT THROAT INFECTION</p><p>ITCHING IN EYES, THROAT</p><p>GP2L2 - C-SECTION</p><p>MENSES - REGULAR FLOW NS</p><p>PHY GEN;</p><p>OEDEMA ON ANKLE - SINCE- 6MONTHS</p><p>PAIN FROM BACK TO ANKLE - BOTH SIDES</p><p>SLEEP - GOOD</p><p>THERMALS - HOT ++</p><p>PERSPIRATION - NS</p><p>THIRST - NS</p><p>APPETITE- NS</p><p>NEED TO PASS BOWELS IMMEDIATELY AFTER MEALS</p><p>O/E THROAT SLIGHTLY SWELLING WITH</p><p>ADV BLOOD TSH ,T3, T4 ANTI TPO ESR ABSOLUTE EOSINOPHIL COUNT</p><p>BP = 110/80</p><p>9/3/22</p><p>BIOCHEMICAL VALUES ARE NORMAL</p><p>H/O PILES TREATMENT FROM GOVT HOMOEO CURED NOW</p><p>EASILY BLEEDING WARTS ONE ON FINGER NO PAIN</p><p>BROWN SPOTS ON FACE</p><p><br></p><p>11/3/22</p><p>WHEEZING MEDICINE GOT OVER</p><p><br></p><p>18/3/22</p><p>NO RELIEF AT ALL FOR WHEEZING</p><p>DAILY USING INHALER</p><p>CHILLY PATIENT NEEDS COVERING AT NIGHT</p>',_binary '<p>9/3/22</p><ol><li>LYSSIN 30 - 2 DOSE WEEKLY ONCE</li><li>BROMIUM 30 - 2 DRM PILLS - 4 TDS</li><li>POTHOS Q -10 ML - 15 GTT TDS</li><li>SARCREAM</li></ol><p>11/3/22</p><ol><li>SILICEA 6X - 1/2 OUNCE- 2 QID SOS 2 HRLY WITH POTHOS Q</li></ol><p>17/3/22</p><ol><li>ARS ALB 10M = 3 DRM TABLETS- 1 TAB HRLY</li><li>SULPH- PSOR 200 - TABLETS IN 10ML - 1 TAB HRLY</li><li>POTHOS+ ARALIA Q- 10 DROPS HRLY SOS</li></ol>','2022-03-24 00:00:00'),(107,109,_binary '<p>7/3/22</p><p>PAIN IN ANKLE JOINT</p><p>DIFFICULT FOR SUJOOD</p><p>PAIN SLIGHTLY IN WRIST</p><p>SERUM URIC ACID 7.3MG/DL</p><p>RBS - 119.0</p><p><br></p><p>26/3/22</p><p>HEAT WHILE TOUCHING</p><p>PAIN WAS BETTER WITH MEDICINE</p><p>PAIN STARTED WHEN MEDICINE GOT OVER</p><p>ASCENDING TYPE GOUT</p><p><br></p><p>13/4/22</p><p>&lt;FASTING</p><ul><li>NO ISSUES DURING THIS FASTING</li><li>FEELING BETTER FOR PAIN FOR 50%</li></ul><p>         BP-110/80 mm OF HG</p>',_binary '<p>7/3/22</p><ol><li>LEDUM PAL 200 2 DRAM PILLS 4 TDS</li><li>URTICA URENS Q - 20ML - 15 DROPS TDS</li><li>COLCHICUM 30 - 1/2 OUNCE - 3 TDS</li></ol><p>26/3/22</p><ol><li>LEDUM PAL 200 2 DRAM PILLS 4 TDS</li><li>URTICA URENS Q - 20ML - 15 DROPS TDS</li><li>COLCHICUM 30 - 1/2 OUNCE - 3 TDS</li></ol><p><br></p><p>14/4/22</p><ol><li>LEDUM PAL,200- 2drm</li><li>UTRICA URENS Q ,20 ml - 15 DROPS TDS</li><li>COLCHICUM 30C 3TAB-3TDS  1/2 OUNCE</li><li>LYCO. 1M 2 DOSE BD</li></ol>','2022-04-28 00:00:00'),(108,110,_binary '<p>8/3/22</p><p>SEVERE FEVER AT NIGHT</p><p>VERTIGO H/O LOW BP</p><p>SEVERE BODY ACHE AND</p><p>BACKPAIN...PAIN AS IF FROM INNER BONE</p><p>MICTURITION = NS</p><p>HEADACHE SEVERE</p><p>H/O CHIKENPOX 2 WEEKS BACK IN CHILD</p><p>9/3/22</p><p>ERUPTIONS STARTED</p><p>11/3/22</p><p>REQUIES MEDICINE FOR CP FOR 2 KIDS</p>',_binary '<p>8/3/22</p><ol><li>RHUS TOX 200 = 2 DRM PILLS</li><li>EUPATORIUM + BAPT TINCTURE 20ML - 15 DROPS 2 HRLY</li><li>BELL 1M - 2 DOSES - SOS</li></ol><p>9/3/22</p><ol><li>EUPHRASIA EYE DROPS</li><li>BRY 30 2 DRM PILLS 2 HRLY WITH RT200</li></ol><p>13/3/22</p><ol><li>RHUS TOX 200 = 2 DRM PILLS</li><li>EUPATORIUM + BAPT TINCTURE 20ML - 15 DROPS 2 HRLY</li><li>BELL 1M - 2 DOSES - SOS</li></ol><p>3 PACK OF ABOVE</p>','0001-01-01 00:00:00'),(109,111,_binary '<p>9/3/22</p><p><br></p><p>C/O DR CHANDRABHANU</p>',_binary '<p>9/3/22</p><ol><li>EUPHRASIA 30 1 DRM PILLS</li><li>ARS ALB 30 1 DRM PILLS</li></ol>','0001-01-01 00:00:00'),(110,112,_binary '<p>14/3/22</p><p>INSOMNIA 2 MONTHS BACK STARTED</p><p>DIFFICULT TO GET SLEEP</p><p>&lt;EARLY MORNING</p><p>AILMENTS AFTER HURT AFTER SOME HARSH WORDS</p><p>H/O BLOOD PRESSURE DIABETES</p><p>VERTIGO SINCE 1 MONTH</p><p>CANNOT WAKE UP OR STAND FALLS SUDDENLY</p><p>PAIN ON LEFT SIDE OF HEAD</p><p>VERTIGO WHILE CLOSING EYES ALSO</p><p>APETITE - REDUCED SOMETIMES</p><p>PERSPIRES WHEN SUGAR DECREASES</p><p>PPBS IS SLIGHTLY HIGH AS PER PATIENT</p><p>BOWELS - REGULAR</p><p>AT TIMES THIRSTY</p><p>BP - 130/70</p><p><br></p><p>23/3/22</p><p>INSOMNIA FEELING BETTER</p><p>SENSATION OF CURRENT IN HEAD</p><p>NUMBNESS IN HEAD DONE CT SCAN</p><p>HISTORY OF FALL OF SOME KAZHUNG LEAF ON HEAD AND HAD VERTIGO</p><p>H/0 HOSPITAL ADMISSION AFTER SHOOTING BP AND SUGAR</p><p><br></p><p>1/4/22</p><p>BP ; 130/80 MM OF HG</p><p>FEELING BETTER,NEEDS MEDICINE WHICH IS OVER</p><p><br></p><p>14/5/22</p><p>NAUSEATING, WITH HEADACHE AND VERTIGO SINCE YESTERDAY</p><p>HAD SIMILAR ISSSUES WHEN BP WAS HIGH</p><p>170/100 = BP</p><p>GIVEN ACONITE1M - 1 DOSE CHECKED BP AFTER HALF AN HOUR= 170/90</p><p>20/5/22</p><p>BP = 180/90</p><p>19/7/22</p><p>COUGH AFTER FEVER</p><p>DIFFICULT PHLEGM WITH</p><p>DOESNT COME UP EASILY , SENSATION OF PHLEGM MOVING INSIDE A PIPE</p><p>NAUSEATING COUGH</p><p>NO RELIEF AFTER MANY MEDICINE</p><p>CHEST XRAY WITH RATTLING SAID BY PATIENT</p><p>&lt;NIGHT MORE COUGH &lt; LYING DOWN</p><p>HIGH SOUND COUGH</p><p>PAIN IN BACK UPPER ALWAYS PRESENT, DURING FEVER PRESENT, EVEN AFTER FEVER PRESENT</p><p>DISC PROLAPSE, OSTEOPOROSIS ALSO</p><p>26/7/22</p><p>COUGH PERSITING PHLEGM NOT SO COMING EASILY</p><p>ITCHING IN GENITALS WITH</p><p>COUGH WITH URINE SPURTING AT TIMES</p><p>NOT MUCH CHANGE AFTER MEDICINE</p><p>DIFFICULT SENSATION IN CHEST</p>',_binary '<p>14/3/22</p><ol><li>PASSIFLORA Q - 20ML - 50 DROPS AT NIGHT</li><li>CONIUM 1M - 2 DRM PILLS - 5 QID</li><li>ARNICA 200 - 2 DOSE BD</li><li>KALI PHOS 6X - 1/2 OUNCE 3TDS</li></ol><p><br></p><p>23/3/22</p><ol><li>ASSIFLORA Q - 20ML - 50 DROPS AT NIGHT</li><li>CONIUM 1M - 2 DRM PILLS - 5 QID</li><li>ARNICA 200 - 3 DOSE WEEKLY ONCE</li><li>KALI PHOS 6X - 1/2 OUNCE 3TDS</li></ol><p>1/4/22</p><ol><li>CONIUM 1M - 3 DRAM TABLETS - 2 TDS</li></ol><p>14/5/22</p><ol><li>RAUWOLFIA Q - 10ML- 15 DROPS TDS</li><li>CONIUM 1M - 1/2 OUNCE TABS - 1 TAB HRLY</li></ol><p>20/5/2</p><ol><li>ARNICA 200 - 6 DOSE - BD - 3 DAYS</li></ol><p>19/7/22</p><ol><li>1PECAC 3X - 3 DRM TABLETS - 1 TABLET 1 HRLY</li><li>DROSERA 1M - 3 DRM TBLTS - 1 3 TDS</li><li>ERIODECTON + EUCALYPTUS Q - 20ML - 10 2 HRLY</li></ol><p>26/7/22</p><ol><li>PULMOLIN - 20ML - 20 TDS</li><li>INFULENZINUM 200 - 2 DRM PILLS - 4VTDS</li></ol><p><br></p><p><br></p><p><br></p>','2022-03-28 00:00:00'),(111,113,_binary '<p>14/3/22</p><p>PAIN IN SHOULDER JOINT LEFT SIDE</p><p>&lt;LIFTING</p><p>&lt;AFTER WAKING FROM SITTING POSITION</p><p>LEFT SIDED DIFFICULT TO GET  SLEEP</p><p>WEIGHT GAIN AFTER TAKING MEDICINE FOR RING WORM INFESTATION</p><p>HIGH CHOLESTROL</p><p>SLEEP DIFFICULT TO GET</p>',_binary '<p>14/3/22</p><ol><li>RHUS TOX 1M- 1 DOSE</li><li>KALI PHOS 6X - 3 TDS</li><li>SANG C - 200 - 2 DRM 4TDS</li></ol>','2022-03-28 00:00:00'),(112,114,_binary '<p>15/3/22</p><p>PAIN IN RIGHT ELBOW JOINT</p><p>&lt;LIFTING WEIGHT</p><p>PAIN ONLY WHILE LIFTING SOME WEIGHT</p><p>STARTED SINCE 4-5 MONTHS</p><p>TAKEN ALLOPATHIC TREATMENT</p><p><br></p><p>30/3/22</p><p>SLIGHT RELIEF FELT FOR JOINT PAIN</p><p>NOW HEADACHE LEFT SIDED</p><p>&lt;AFTER SLEEP AND WAKE UP AT MORNING</p><p>TENDENCY TO VOMIT</p><p>H/O SEVER COLD AND PAIN IN EAR WITH BLOOD STREAKED PHLEGM</p><p>12/4/22</p><p>REQUIRES MEDICINE FOR ELBOW JOINT PAIN LEFT</p><p>13/6/22</p><p>HEADACHE  ON SIDES SINCE 2- 3 DAYS</p><p>SNEEZING  WATERY NOSE </p><p>SLIGHT COUGH ONLY NOW</p><p>O/E THROAT RED</p>',_binary '<p>15/3/22</p><ol><li>RHUS TOX 30 2 DRAM PILLS - 4 QID</li><li>KALI BICH 1M - 2 DOSE WEEKLY ONCE</li></ol><p>30/3/22</p><ol><li>SPIGELIA 200 3 DRAM - 2 TAB QID</li><li>KALI BICH 6X + SILICEA 200 - 1/2 OUNCE - 3 TAB 3 TIMES</li></ol><p>12/4/22</p><p><br></p><p>1.RHUS TOX 30 2 DRAM PILLS - 4 QID</p><p>2.KALI BICH 6X - 1/2 OUNCE - 2 BD</p><p>13/6/22</p><ol><li>BELL 1M - 3 DOSES</li><li>BELL 200- 2 DRM PILLS - 4 QID</li><li>BAPTISIA + BELL Q - 10ML - 10 TDS</li></ol><p><br></p>','2022-03-31 00:00:00'),(113,115,_binary '<p>15/3/22</p><p>ALLERGIC COUGH SINCE CHILDHOOD</p><p>STARTS AS COUGH THEN RUNNING NOSE</p><p>SNEEZING&lt; AFTER WAKING &lt;AFTER BATHING</p><p>ITCHING IN THROAT</p><p>PERSPIRATION ON HEAD AT TIMES----- OFFENSSIVE</p><p>PEELING OF SKIN FROM HAND</p><p>WHITE SPOTS ON FOREHEAD</p><p>BOWELS-- NS</p><p>THERMALS CHILLY</p><p>&lt; WINTER. COLD FOOD , ICE CREAM</p><p>DRY COUGH NOW</p><p><br></p><p>MIND - STUBBORN</p><p>GETS ANGRY EASILY ,,LOVE FOR PET ANIMALS</p><p>CONTRADICTION CANNOT BEAR</p><p>WEAKNESS OF MEMORY</p><p>WRITING DIFFICULTY WITH</p><p>H/O RECURRANT COUGH AND FEVER</p><p><br></p><p>30/3/22</p><p>FEELING BETTER WHILE TAKING MEDICINE</p>',_binary '<p>15/3/22</p><ol><li>TUBERCULINUM 1M - 2 DOSE WEEKLY ONCE</li><li>ARALIA Q 10ML- 10 DROPS TDS</li><li>SILI 6X 1/2 OUNCE - 3 TDS</li></ol><p>30/3/22</p><p><br></p><ol><li>TUBERCULINUM 1M - 2 DOSE WEEKLY ONCE</li><li>ARALIA Q 10ML- 10 DROPS TDS</li><li>SILI 6X 1/2 OUNCE - 3 TDS</li></ol>','2022-03-30 00:00:00'),(114,117,_binary '<p>16/3/22</p><p>PAIN IN THROAT SINCE YESTERDAY</p><p>H/O VOICE STRAINED</p><p>FEVER WITH PERSPIRATION AT NIGHT</p><p>HEAVINESS OF HEAD</p><p>PAIN IN LOW BACK AND LOWER ABDOMEN.....?UTI</p><p>LMP ; 1/3/22</p><p>O/E PHARYNX RED++</p><p>PALPATED= PAINFUL</p><p><br></p><p>26/3/22</p><p>ALLERGIC TO ALLOPATHIC MEDICINES STARTED AT COLLEGE DAYS</p><p>H/O ALLERGY PAIN STARTED AFTER VOICE STRAIN IN THROAT</p><p>RUNNING NOSE WATERY AT DAY TIME BLOCKED AT NIGHT</p><p>CONTINOUS SNEEZING WITH FRONTAL HEADACHE MAXILLARY SINUS++</p><p>SENSATION OF VERTIGO AFTER READING SEEING PHONE</p><p>O/E PHARYNX REDNESS REDUCED SLIGHT PAIN ON PALPATION</p><p>&lt;VOICE STRAIN</p><p><br></p><p>30/3/22</p><p>COUGH WITH EXPECTORATION DIFFICULT TO COME UP</p><p>EAR BLOCKED</p><p>DYSMENORRHOEA-USUALLY ON FIRST DAY</p><p>NOW PERSISTING ON SECOND DAY ALSO</p><p>BACK PAIN,DIFFICULT TO STAND</p><p>SHIVERING FEELIN FOR LEGS,,CANNOT WITHSTAND PAIN</p><p>BLEEDING HEAVY FLOW SINCE 2 DAYS</p><p>13/6/22</p><p>THROAT REDNESS++</p><p>THIRSTLESS</p><p>FEVER SINCE 2 DAYS</p><p>COUGH WITH EXPECTORATION WITH URINATION INVOLUNTARY</p><p>BODY PAIN SEVERE</p><p>CLEAN TONGUE</p><p>HISTORY OF ENDOMETRIOSIS,FIBROID SMALL ..MENSES REGULAR HISTORY OF SEVERE BLEEDINGH FOR 3 DAYS</p><p>MARRIED SINCE 7 MONTHS</p><p>17/6/22</p><p>FEVER REDUCED ,</p><p>COUGH WITH EXPECTORATION PERSISTING</p><p>GREENISH COLOUR PHLEGM WITH</p><p>25/6/22</p><p>SCAR MARKS AFTER PIMPLES ON FACE</p><p>SINCE 2 -3 YRS</p><p>29/6/22</p><p>PALE++</p><p>ANEMIC</p><p>WEAKNESS</p><p>PAIN IN LEFT ARM EXTENDING TONECK AND BACK</p><p>PALPITATION+</p><p>DRYNESS OF MOUTH</p><p>BP - 110/80</p><p>21/7/22</p><p>NOSE BLOCK WITH SNEEZING</p><p>NOSE BLOCK WITH ALTERNATE NOSTRILS</p><p>WATERY NASAL DISCHARGE</p><p>30/7/22</p><p>THERMALS- CHILLY &lt; IN RAINY WEATHER</p><p>HB- 12.2</p><p>HAD GIIDINESS YESTERDAY AT SHOOL</p><p>SENSATION OF EAR BLOCK</p><p>HEARING LOSS SLIGHTLY WITH EAR BLOCK</p><p>19/8/22</p><p>FEVER SINCE YESTERDAY</p><p>SEVERE PAIN BACK OF EYES</p><p>PAIN IN THROAT , BACK PAIN</p><p>NO TASTE WITH BITTER TASTE IN MOUTH</p><p>SORENESS OF MUSCLES</p><p>24/8/22</p><p>PAIN  IN LEFT SIDE OF FACE AND HEAD </p><p>IRRITATING COUGH WITH EXPECTORATION GREENISH PHLEGM</p><p>WEAKNESS</p><p>BACK PAIN AT NIGHT </p><p>?SINUSISTIS</p><p>ESR HIGH- 50MM OF HOUR</p><p>CARBONATED WATER, MAIDA ALLERGY..... </p><p><br></p><p><br></p><p><br></p>',_binary '<p>/16/3/22</p><ol><li>HYDRASTIS Q 10ML - 10TDS</li><li>BELL 200 - 2DRM - 4 TDS</li><li>MERC SOL 30 - 2DRM - 1 TAB 2 HRLY</li><li>BELL 1M - 2 DOSES</li></ol><p>26/3/22</p><ol><li>KALI BICH 1M - 2 DOSES BD</li><li>SILICEA 200 2 DRAM PILLS 4 QID</li><li>ARS ALB 30 2 DRM PILLS 4 QID</li></ol><p>30/3/22</p><ol><li>GRINDELIA Q - 10ML - 15 QID</li><li>BELL 200 IN KALI BICH 6X</li><li>PULS 200 3 PILLS 2 HRLY</li></ol><p>13/6/22</p><ol><li>IPECAC 3X- 5ML - 10 TDS</li><li>CAUSTICUM200 - 2 DRM PILLS 4 2 HRLY</li><li>BELLQ +BAPTISIA Q +PHYTOLACCA Q- 20ML- 10 DROPS TDS</li><li>BELL 1M - 4 DOSE SOS - HEADACHE OR HIGH FEVER</li></ol><p>17/6/22</p><ol><li>GRINDELIA Q - 10ML - 10 DROPS QID</li><li>SANG NIT 200 - 2 DRM PILLS - 4 QID</li></ol><p>25/6/22</p><ol><li>SAR CREAM</li><li>SIL 6X - 1/2 OUNCE - 3 TBD</li></ol><p>29/6/22</p><ol><li>RHUS TOX - 1M - 2 DOSE FOLLOWED BY RHUS TOX 200 2 DRM PILLS 4 PILLS 2 HRLY</li><li>FERR PLUS CAPSULES - 7 CAPSULES AT NIGHT ONE</li></ol><p>21/7/22</p><ol><li>BRY 200 - 2DRM PILLS</li><li>BAPTISIA 3X - 20ML - 10 TDS</li><li>BELL 1M - IN FP 6X - 2DRM</li><li>BELL 200 - 2 DRM PILLS</li></ol><p>30/7/22</p><ol><li>MULLIEN OIL 1</li><li>CHINA 30 - 2 DRM PILLS 4 TDS</li><li>AVEVNA SATIVA - 20ML - 10 TDS</li></ol><p>19/8/22</p><ol><li>ARNICA 1M -3 DRM PILLS - 5 PILLS 1 HRLY</li><li>PHYTOLACCA BELL BAPTISIA 20MLN - 10 DRPS 1 HRLY</li><li>BELL 1M IN FP 6X - 1/2 OUNCE - 3 TAB 1 HRLY</li></ol><p>24/8/22</p><ol><li>SANGUINARIA NITRICUM 30 - KALI BICH 6X 1/2 OUNCE - 3 TDS</li><li>HYDRASTIS Q- 10ML - 10 TDS</li><li>SPIGELIA 1M - 7 DOSE BD</li><li>STOBAL COUGH SYRUP </li></ol>','2022-06-17 00:00:00'),(115,118,_binary '<p>16/3/22</p><p>HAEMMORHOIDS SINCE 10YRS</p><p>DELIVERY AFTER DIFFICULT</p><p>TREATMENT SINCE 3 YEARS -HOMOEO</p><p>NO BLEEDING</p><p>PAINFUL SLIGHTLY</p><p>PROTRUSION ++</p><p>CONSTIPATION - TAKES LONG TIME TO PASS MOTION</p><p>TAKEN HOMOEO TREATMENT</p><p>NOT TAKEN SINCE 4 MONTHS</p><p>WHEN HYDRATED NO ISSUES</p><p>NORMAL DELIVERY ONE CHILD</p><p><br></p>',_binary '<p>16/3/22</p><ol><li>NUX VOM 10M - 1 DOSE AT NIGHT</li><li>NUX VOM -30 - 2 DRAM PILLS 4 TDS</li><li>RATANHIA 200 - 2 XDRM PILLS 4TDS</li><li>Y-LAX - 17 TABBLETS 1/2 OUNCE BOTTLE</li></ol>','0001-01-01 00:00:00'),(116,116,_binary '<p>15/3/22</p><p>FEVER WITH RATTLING COUGH FREQUENTLY\\ MONTHLY ONCE</p><p>THICK NASAL DISCHARGE</p><p>COUGH SINCE 2-3 WEEKS COUGH AT TIMES WITH RATTLING</p><p>OPEN FONTANNEL- HEAD SWEATS EASILY</p><p>BOWELS REGULAR BUT CONSTIPATED</p><p>PERSPIRATION ON HEAD</p><p>DELIVERY BY C-SECTION BABY SWALLOWED MECONIUM</p><p>MILESTONES ON TIME</p><p>BABY WAS CONCIEVED AFTER 10YRS</p><p>H/O FEBRILE FITS TWICE BEFORE</p><p><br></p><p>19/3/22</p><p>COUGH VERY CONTINOUSLY</p><p>EXPECTORATION DIFFICULT TO COME UP</p><p>NASAL FLARING</p><p>INDRAWING CHEST WALLS</p><p>FREQUENTLY BREATHING</p><p>H/O WHEEZING AND NEBULIZATION</p><p><br></p><p>12/4/22</p><p>REQUIRES MEDICINE TO IMPROVE IMMUNITY</p>',_binary '<p>15/3/22</p><ol><li>PULS 200 2DRM PILLS - 4TDS</li><li>ANT TART 6C - 2 DRM PILLS 4 QID</li><li>OCIMUM SANCT -Q 5ML - 5 DROPS TDS</li></ol><p>19/3/22</p><ol><li>ANT TART 10M- 1 DOSE NOW</li><li>ANT TART 10M - 1 DRAM TABLET- 2 QID</li><li>GRINDELIA Q - 4 DROPS 2 HRLY</li></ol><p>12/4/22</p><ol><li>TUBERCULINUM 1M - 2 DOSE WEEKLY ONCE</li><li>ARS IOD 3X - 1 BD - 3DRM TABS</li></ol>','0001-01-01 00:00:00'),(117,119,_binary '<p>17/3/2</p><p>FEVER FEW DAYS BACK AND REDUCED</p><p>TODAY FEVER AT EVENING</p><p>COUGH SINCE 4-5 DAYS</p><p>WITH EXPECTORATION SINCE SOME DAYS</p><p>O/E WHEEZING HEARD ON BOTH SIDES</p><p>TONGUE CLEAN</p><p>VOMITED PHLEGM YESTERDAY</p><p>23/6/22</p><p>COUGH SINCE 2 DAYS ONLY</p><p>COUGH WITH EXPECTORATION</p><p>SLIGHT FEVER WITH</p><p>COLD SINCE 1 WEEK</p><p>WATERY NASAL DISCHARGE</p><p><br></p>',_binary '<p>17/3/22</p><ol><li>BELL 1M 2 DOSES</li><li>VER VIRID + BAPT 3X - 5 DROPS 2 HRLY</li></ol><p>3.PULS 200 2 DRM PILLS - 2 HRLY</p><p>23/6/22</p><ol><li>BAPTISIA 3X - 5ML - SOS 8 DROPS</li><li>BELL 1M - 4 DOSE SOS</li><li>IPECAC 3X IN 2 DRM PILLS - 4 QID</li><li>ANT TART 6C - 2 DRM PILLS - 4 QID</li></ol><p><br></p>','0001-01-01 00:00:00'),(118,120,_binary '<p>19/3/22</p><p>ITCHING RASHES ON FACE N HAND SINCE 2 DAYS</p><p>&lt;SUNLIGHT?&lt;SWEATING AFYER</p><p>PRICKLYHEAT TYPE</p><p><br></p><p>24/3/22</p><p>ERUPTIONS GONE,EXTREMELY DRY SKIN ON FACE WITH ITCHING</p><p>&lt;EXPOSURE TO SUN</p><p>WHITE POWDERS ON FACE</p>',_binary '<p>19/3/22</p><ol><li>ARNICA 200 - 2 DRM PILLS 4QID</li><li>APIS 1M - 2 DRAM TAB - 3TDS</li><li>SYZIGUIM Q -10ML- 10GTT TDS</li></ol><p>24/3/22</p><ol><li>SAR CREAM = 1</li><li>KALI MUR 6X - 2DRM  3TDS</li><li>TO TAKE APIS 1M - HS ONLY</li></ol>','2022-03-29 00:00:00'),(119,121,_binary '<p>22/3/22</p><p>ALLERGY WITH SNEEZING</p><p>STRONG FAMILY HISTORY OF ALLERGY FROM BOTH PARENTAL SIDES</p><p>SNEEZING &lt; MORNING, NIGHT</p><p>WATERY RUNNING NOSE</p><p>WHEEZING</p><p>SWEATS VERY MUCH</p><p>MAPPED TONGUE</p><p>WHEN SNEEZING REDUCES ITCHING ERUPTIONS APPEAR ON BODY</p><p>O/E WHEEZING HEARD ON BOTH SIDES</p><p>MIND =</p><p>THREATENS OF SUCIDAL ATTEMPT</p><p>VERY RESTLESS</p><p>DIFFICULT IN LEARNING</p><p>OPENS AND WORKS ANY THING</p><p>30/3/22</p><p>FEELING BETTER USED SPRAY ONLY ONCE</p><p>13/5/22</p><p>HAD SEVERE SNEEZING YESTERDAY,HAD NOT USED INHALER AFTER THIS MEDICINES</p><p>LEARNING DISABILITY WITH DIFFICULT CONCENTRATION</p><p>16/6/22</p><p>COLD AND SNEEZING SINCE 2- 3 DAYS</p><p>COUGH &lt;NIGHT DRY TYPE USUALLY THIS TYPE OF COUGH LEADS TO WHEEZING</p><p>ON EXAMINATION PAIN IN THROAT</p><p>18/6/22</p><p>WHEEZING SINCE MORNING WITH DRY COUGH</p><p>NO FEVER SINCE YESTERDAY</p><p>WATERY NASAL DISCHARGE WITH</p><p>HEADACHE WITH ALLERGY BACK OF HEAD</p><p>BURNING IN THROAT WITH COUGH</p><p><br></p><p><br></p><p><br></p>',_binary '<p>22/3/22</p><ol><li>ARS ALB 10M - 1 DOSE</li><li>NAT SULPH 6X - 1/2 OUNC 3 TDS</li><li>ARS ALB 30 2 DRM PILLS - 4 TDS</li><li>PASSIFLORA Q - 10ML- 10 GTT SOS FOR WHEEZING</li></ol><p>30/3/22</p><ol><li>ARS ALB 30 2 DRM PILLS - 4 TDS</li><li>PASSIFLORA Q - 10ML- 10 GTT SOS FOR WHEEZING</li><li>NAT SULPH 6X - 1/2 OUNCE - 3 TDS</li></ol><p>13/5/22</p><ol><li>ARS ALB 30 2 DRM PILLS - 4 TDS</li><li>PASSIFLORA Q - 10ML- 10 GTT SOS FOR WHEEZING</li><li>NAT SULPH 6X - 1/2 OUNCE - 3 TDS</li><li>NAT SULPH 1M - 1 DOSE TONIGHT</li></ol><p>16/6/22</p><ol><li>BRY 200 - 2 DRM PILLS - 2 HRLY</li><li>BAPTISIA Q +PHYTOLACCA Q +BELL Q - 10ML - 10 DROPS 2 HRLY</li><li>BEL 1M - 3 DOSE SOS</li><li>DULCAMARA 200 - 1 DRM TABLETS - 2 TDS</li></ol><p>18/622</p><ol><li>ARS ALB 3X - 2 DRM PILLS - 2HRLYALTERNATE WITH</li><li>IPECAC 3X - 2 DRM PILLS - 2 HRLY</li></ol>','2022-05-28 00:00:00'),(120,122,_binary '<p>23/3/22</p><p>HEADACHE ALL OVER FACE</p><p>HAD VOMITING WITH PREVIOUS ATTACK OF HEADACHE</p><p>SLIGHT HEAVINESS OF HEAD WITH ?SINUSITIS</p><p>LEFT SIDED HEADACHE NUMBNESS AND PAIN OF LEFT SIDE</p><p>19/7/22</p><p>COUGH AFTER FEVER</p><p>VOMITS AFTER COUGH</p><p>ALWAYS PRESENT</p><p>COUGH WITH EXPECTORATION</p><p>26/7/22</p><p>COUGH SLIGHTLY PERSISTING BUTV RELIEF FELT</p>',_binary '<p>23/33/22</p><ol><li>SPILGELIA 1M- 2 DRM PILLS - 5QID</li><li>BELL 200 IN KALI BICH 6X- 2 TDS</li></ol><p>19/7/22</p><ol><li>GRINDELIA + EUCALYPTUSVQ -10ML - 10 QID</li><li>COCCUS CACTI 30 - 2DRM PILLS - 4 2 HRLY</li></ol><p>27/7/22</p><ol><li>SPIGELIA 1M - 2 DRM PILLS</li><li>GRINDELIA + EUCALYPTUSVQ -10ML - 10 QID</li><li>COCCUS CACTI 30 - 2DRM PILLS - 4 2 HRLY</li></ol>','0001-01-01 00:00:00'),(121,123,_binary '<p>23/3/22</p><ol><li>WOUND FORMATION SMALL INTIALLY SMALL INSIDE MOUTH NOW SIZE NINCREASED</li><li>UNABLE TO EAT FOOD DUE TO PAIN AND BURNING</li><li>LYMPH NODES BNOT PALPABLE</li><li>APETITE= POOR ALWAYS</li><li>WEIGHT = 20.5 KG</li><li>CHEST WALL PROTRUDED</li><li>BOWELS REGULAR</li><li>PERSPIRATION THIRST = NS</li></ol>',_binary '<p>23/3/22</p><ol><li>MERC SOL 1M - 2 DOSE BD</li><li>ACID NITRICUM - 200 - 2DRM - 4 TDS</li><li>HYDRASTIS Q AS MOUTH WASH -5ML - 15 DROPS IN 3 SPOON WATER</li></ol>','0001-01-01 00:00:00'),(122,124,_binary '<p>26/3/22</p><p>C/O HYPERGLYCEMIA</p><p>HYPOTHYROPIDISM ..TSH CHECHED AFTER SECONDARY INFERTILITY</p><p>DIABETES</p><p>-WEAKNESS</p><p>-GASTRIC ISSUES</p><p>-HEART BURN</p><p>&lt;PULSES= SOUR BELCHING WITH</p><p>THIRSTY = DRYNESS OF MOUTH</p><p>PALPITATION++</p><p>BOWELS REGULAR</p><p>APETITE -+++</p><p>SLEEP - GOOD</p><p>PERSPIRATION+++</p><p>MENSES REGULAR NOW LACTATING AMENORRHEA</p><p>26/8/22</p><p>PAIN IN RIGHT HEEL</p><p>&lt;MORNING, NO SWELLING</p><p>WEIGHT - 70.7</p>',_binary '<p>25/3/22</p><ol><li>ACID PHOS 200 - 2 DRM - 4 TDS</li><li>NAT PHOS 6X - 3 TDS BEFORE FOOD</li><li>CEPHALANDRA Q -10ML - 15 TDS</li></ol><p>26/8/22</p><ol><li>PULS 10M - 2WEEKS ONCE</li><li>ZINCUM MET 30 IN CF 6X 1/2 OUNCE - 3 TDS</li><li>URTICA URENS - 10ML - 10 TDS</li></ol>','2022-04-09 00:00:00'),(123,125,_binary '<p>30/3/22</p><p>COUGH SINCE 4 DAYS</p><p>NO FEVER , NOSE BLOCKED</p><p>COUGH WITH EXPECTORATION</p><p>DIFFICULT TO SLEEP,,WAKES FROM SLEEP DUE TO COUGH</p>',_binary '<p>30/3/22</p><ol><li>GRINDELIA Q - 10ML - 20 DROPS QID</li><li>HEP SULPH 200 - 3 TAB 4 TIMES</li><li>DROSERA 30 - 2 DRM - 4QID </li></ol>','0001-01-01 00:00:00'),(124,126,_binary '<p>30/3/22</p><p>COUGH SINCE SOME DAYS</p><p>DESIRES COLD DRINKS</p><p>COUGH WITH EXPECTORATION</p><p>H/0 WHEEZING </p><p>&lt;COLD FOOD, EARLY MORNING, NIGHT</p><p>ITCHING IN THROAT</p><p>NOSE BLOCK AT NIGHT</p><p>SWEATS A LOT ON HEAD WHEN HAIR IS MORE</p>',_binary '<p>30/3/22</p><ol><li>GRINDELIA Q - 10ML - 8 DROPS QID</li><li>HEP SULPH 200 - 4 TDS</li><li>SULPH - PSOR 200 - 2 DOSE WEEKLY ONCE</li></ol>','2022-04-14 00:00:00'),(125,127,_binary '<p>31/3/22</p><p>FATIGUE, WEAKNESS. SLEEPY ALWAYS</p><p>H/O LOW HB, HIGH CHOLESTROL,</p><p>HB WAS 8 AS PER PATIENT</p><p>UTERINE FIBROID</p><p>LMP ; 21/3/22-    21/2/22..ON SAME DATES</p><p>PERIODS LASTS FOR 13 DAYS, FLOW REGULAR WITH CLOTS</p><p>USG DONE 3 MONTHS BACK</p><p>TAKEN MEDICINE FOR LESS THAN A MONTH WHICH WAS ADVICED FOR 3 MONTHS</p><p>FIBROID INCREASING IN SIZE</p><p>FREQUENT UTI</p><p>BURNING PAINFUL MICTURITION COSTANT DESIRE TO PASS, INCOMPLETE SENSATION</p><p>3 NORMAL DELIVERIES</p>',_binary '<p>31/3/22</p><ol><li>FERR PLUS CAPSULES 8 HS </li><li>CANTHARIS 30 - 2 DRAM PILLS - 3PILLS 2 HRLY</li><li>ACID PHOS 200 - 3 DRM TABLETS - 2 QID</li></ol>','2022-04-08 00:00:00'),(126,128,_binary '<p>1/4/22</p><p>NOSE BLOCKED AT NIGHT</p><p>SLIGHT COUGH WITH EXPECTORATION</p><p>O/E THROAT SLIGHTLY ENLARGED</p><p>= PERSPIRATION = HEAD++</p><p>THERMALS = HOT</p><p>THIRST= THIRSTLESS</p><p>BOWELS = REGULAR</p><p><br></p>',_binary '<p>1/4/22</p><ol><li>PULS 200 2 DRM TABLETS - 2 QID</li><li>IPECAC 30 - 2 QID</li></ol>','0001-01-01 00:00:00'),(127,129,_binary '<p>2/4/22</p><p>MIGRAINE SINCE 20 YEARS</p><p>TAKING TREATMENT FROM SIRAJ DOCTOR</p><p>HEADACHE&lt; AFTER EXPOSURE TO SUN,</p><p>&gt;SLIGHT RELIEF AFTER VOMITING</p><p>SLEEP NOW DISTURBED DUE TO HEAT</p><p>EMPTY STOMACH CAUSES HEADACHE</p><p>HEADACHE USUALLY STARTS AFTER GASTRIC UPSET</p><p>SNEEZING ALLERGIC ISSUES ALSO&lt;DUST,CLOSED ROOM. AC</p><p>&gt;OPEN AIR</p><p>15/4/22</p><p>SINUSITIS</p><p>MIGRAINE ISSUES REDUCED ;;</p><p>30/4/22</p><p>COMPLAINTS REDUCED...REQUIRES MEDICINES AS IT GOT OVER</p><p>8/7/22</p><p>HEADACHE SINCE YESTERDAY</p><p>CANNOT BEAR SMOKE FROM STOVE....CAUSING HEADACHE ITCHING IN EYES</p><p>160/90 MM OF HG</p><p>MENOPAUSE - 50YRS</p><p>BP RISED FIRST TIME AFTER SEEING DAUGHTERS DELIVERY</p>',_binary '<p>2/4/22</p><ol><li>NAT MUR 10M - 1 DOSE</li><li>IRIS VERS 200 - 3 QID - 1 OUNCE BOTTLE</li><li>BRY 200 - 2 DRAM 2BOTTLES - SOS</li><li>SANG CANA Q - 20ML - 15 GTT QID</li></ol><p>15/4/22</p><ol><li>Kali bich 6x + bell 200- 2 tds - 1 ounce</li><li>sang c + bell Q - 20ML - 15 TDS</li><li>TUB 10M - 1 DOSE AT NIGHT</li></ol><p>30/4/22</p><ol><li>Kali bich 6x + bell 200- 2 tds - 1 ounce</li><li>sang c + bell Q - 20ML - 15 TDS</li><li>NAT MUR 10M - 1 DOSE- 1/5/22</li><li>BRY 200 - 3 DRAM - SOS</li></ol><p>8/7/22</p><ol><li>ARNICA 1M - 2DOSE WEEKLY ONCE [ BP RISE AFTER MENTAL SHOCK}</li><li>GLYCERRHIA GLABRA 10ML - 10 BD</li><li>BT 4- 1 BD - 3 DRM BOTTLE</li></ol>','2022-05-14 00:00:00'),(128,131,_binary '<p>7/4/22 </p><p>C/O STOMACH PAIN IN LEFT UPPER QUADRANT</p><p>PAIN STARTED AFTER FASTING FOR 2 DAYS</p><p>NO FEVER TENDENCY TO VOMIT, NAUSEA++ BUT NOT VOMITED</p><p>LMP ; 26/3/22</p><p>H/O IRREGULAR MENSES</p><p>DYSMENORRHOEA</p><p>FLOW FOR 9-10DAYS </p><p>SEVERE FOR ALL THESE DAYS</p><p>USE TO GET SAME GASTRIC ISSUES DURING RAMADAN</p>',_binary '<p>7/4/22</p><ol><li>LYCO 200 - 3 DOSE - 3 DAYS</li><li>NAT PHPOS 6X - 1/2 OUNCE - 3 TDS</li><li>ROBINIA Q - 10ML - 15 TDS</li></ol>','0001-01-01 00:00:00'),(143,145,_binary '<p>29/4/22 LOSS OF SMELL AND TASTE</p><p>3 CHILDREN=@24yrs girl</p><p>@21yrs DISALBED CHILD</p><p>@8MONTHS C-SECTION</p><p>GOT COVID DURING LAST TRIMESTER- FULL TERM BABY- WAS WEAK DUE TO COVID - DONE C-SECTION</p><p>GOT COVID AT PREGNANCY</p><p>PALPITATION,ALWAYS HAS DIFFICULTY</p><p>FEELS PHLEGM IN CHEST</p><p><br></p><p>18/5/22</p><p>NO DIFFERENCE TO TASTE OR SMELL</p><p>STILL PERSISTING ANOSMIA AND LOSS OF TASTE</p><p>LEUCORRHOEA WATERY AFTER MENSES </p><p>PERSISTS FOR A WEEK</p><p>PAIN IN LOWER ABDOMEN WHEN LEUCORRHOEA GETS OVER</p><p><br></p>',_binary '<p>29/4/22</p><ol><li>KALI BICH 30 -2 DRM PILLS 4 TDS</li><li>SILICEA 6X - 1/2 OUNCE - 3 TDS</li><li>PULS 10M - 1 DOSE WATER DOSE</li></ol><p>18/5/22</p><ol><li>PULS 1M - 2 DOSE BD</li><li>SIL 1M - 2 DOSE BD</li><li>KALI BICH 6X - 2 TDS - 1/2 OUNCE</li><li>EUCALYPTUS Q - 10ML- 10 TDS</li></ol>','2022-05-27 00:00:00'),(129,130,_binary '<p>5/4/22</p><p>MUSCLE CRAMP ALWAYS</p><p>H/O HYSTERECTOMY AT 20 YRS AGE DUE TO PPH AFTER NORMAL DELIVERY</p><p>ASTHMA SINCE MANY YEARS WAS TREATED WITH HOMOEOPATHY AND WAS BETTER SINCE 2 YEARS</p><p>NOW ASTHMA ISSUES SINCE 2WEEKS ONLY</p><p>&lt;LYING DOWN, AC</p><p>DESIRES FRUIT</p><p>&lt;AFTERNOON</p><p>URINE BURNING SLIGHTLY</p><p>WITH PAIN IN LOWER ABDOMEN</p><p>UTI]</p><p>UTERINE PROLAPSE ++ SINCE 5 YEARS ADVICED SURGERY</p><p>ALLERGIC TO MANY ITEMS,SHELLFISH, ALLPOATHIC MEDICINES ETS</p><p><br></p><p>27/4/22</p><p>EARCHE SINCE 1WEEK</p><p>FEELING BETTER FOR OTHER ISSUES</p><p>EAR WAX? PAIN &lt;NIGHT</p><p>18/5/22</p><p>GASTRITIS</p><p>BLOATED SENSATION NAUSEATING NO VOMITING</p><p>SOUR ERUCTATIONS</p><p>PAIN IN LOWER ABDOMEN</p><p>ASTHMA ALWAYS IN COLD WEATHER</p><p>6/7/22</p><p>HEADACHE SINCE 2 DAYS</p><p>?SINUSITIS</p><p>COUGH WITH EXPECTORATION</p><p>TAKEN MILK</p><p>COUGH ALWAYS</p><p>TONGUE COATED</p><p>DOENT LIKE EGG,CHICKEN, BIG FISH,VOMITS WHEN TAKEN AVERSION TO THESE</p><p>8/7/22</p><p>STARTED COUGH DRY TYPE</p>',_binary '<p>5/4/22</p><ol><li>IODOFORM 3X - 2 DRAM TABLETS</li><li>PASSIFLORA Q - 10ML - 15 TDS</li><li>THUJA 30 - 1/2 OUNCE - 3 QID</li><li>CANTHARIS 30- 2 DRM PILLS- 4 QID</li></ol><p>27/4/22</p><ol><li>EAR DROPS</li><li>PULS 200 - 2 DRM PILLS 4 QID</li><li>MERC SOL 1M - 2 DOSE</li></ol><p>18/5/22</p><ol><li>IODOFORM 3X - 2 DRAM TABLETS</li><li>PASSIFLORA Q - 10ML - 15 TD</li><li>THUJA 30 - 1/2 OINCE - 3 TDS</li><li>NUX VOM 30 - 2 DRAM PILLS- 3 PILLS 1 HOURLY</li></ol><p>6/7/22</p><ol><li>GRINDELIA Q - 10ML - 15 TDS</li><li>IODOFROM 3X - 2 DRM TABLETS SOS</li><li>ARS ALB 3X - 4 PILLS 2 HRLY</li><li>KALI BICH 6X - 1/2 OUNCE - 2 TDS</li></ol><p>RUBOR GEL; FOR EA</p><p>8/7/22</p><ol><li>BRY 1M - 2 DOSE FOLLOWED BY</li><li>BRY 3X - 2 DRM PILLS</li></ol>','2022-06-01 00:00:00'),(130,132,_binary '<p>-COLD AND COUGH WITH EXPECTORATION</p><p>-NASAL DISCHARGE - THICK PHLEGM WITH</p><p>-NOSE BLOCK WAS THERE</p><p>-O/E : CHEST CLEAR</p><p> TOUNGE POSTERIOSLY COATED</p><p>BOWELS REGULAR</p><p>APETITE : GOOD</p>',_binary '<ol><li>PULS - 2 DRM 3 QID</li><li>GRINDELIA Q - 10ml  8 DROPS QID</li></ol>','2022-04-16 00:00:00'),(131,134,_binary '<p>14/4/22</p><p>SWOLLEN AXILLARY LYMPH NODES, PAINFUL AT TIMES</p><p>DONE USG 20 DAYS BACK, NO ISSUES AS PER PATIENT</p><p>C/O; OVARIAN CYST? CERVICAL CYSTS? NO REPORTS IN HAND</p><p>PAIN DURING INTERCOURSE</p><p>MOTHER HYSTERECTOMY AT VERY YOUNG AGE DUE T PPH</p><p>MENSES ; LMP ; 24/3/3/22</p><p>APPEARS 7 DAYS PRIOR TO DATE</p><p>REGULAR FLOW</p><p>MARRIED SINCE 8 YEARS</p><p>2 CHILDREN NORMAL DELIVERY</p><p><br></p><p>17/5/22</p><p>VERY ANXIUOS ABOUT HEALTH, HAD COME TO SHOW A SMALL INVERTION ON BACK</p><p>12/77/22</p><p>THROAT PAIN SINCE SOME DAYS</p><p>HAD SLIGHT FEVER</p><p>23/7/22</p><p>HAIRFALL SINCE 1 YEAR</p><p>VISIBLE AFTER COVID</p><p>MENSES - REGULAR</p><p>BREAKAGE OF HAIR</p><p>NO HAIR GROWTH AFTER CUTTING</p><p>DANDRUFF WITH ITCHING</p><p>PALPITATION SEVERE DURING FEVER , ANXIETY , TIRED FEELING WITH</p><p>ANXIETY AFTER SENDING KIDS TO SCHOOL, CANNOT SIT ALONE</p>',_binary '<p>14/4/22</p><ol><li>SCROFULARIA NODOSA Q - 20ML - 15TDS</li><li>THUJA 200 3 DOSE WEEKLY ONCE</li><li>BARYTA CARB 30 - 4 QID 2 DRM PILLS</li></ol><p>12/7/22</p><ol><li>BELL + PHYTOLACCA Q - 10ML - 15 QID</li><li>BELL 1M - 4 DOSE SOS</li><li>BELL 200 ALTERNATE WITH 2 HRLY</li><li>RHUS TOX 200</li></ol><p>23/7/22</p><ol><li>ARNICA SHAMPOO</li><li>KALI SULPH 6X - 1/2 OUNCE - 3 TDS</li><li>ACID PHOS 200 - 2 DRM PILLS 4TDS</li></ol>','2022-08-06 00:00:00'),(132,135,_binary '<p>14/4/22</p><p>AXILLARY LYMPH NODES SWOLLEN SINCE 2 YEARS</p><p>PAINFUL AT TIME</p><p>SAME COMPLAINT WITH MOTHER ALSO</p><p>RATTLING AND RUNNING NOSE AT TIMES NOT SO FREQUENTLY</p><p>NORMAL BIRTH</p><p>BOWELS REGULAR</p><p>PERSPIRATION ; FACE NOSE++</p><p>THIRST ; ++</p><p>RESTLESS CANNOT SIT QUIET</p><p>31/5/22</p><p>DIARRHOEA SINCE 4 DAYS, UNDIGESTED FOOD PARTICLES</p><p>PAIN IN STOMACH</p><p>NAUSEATING</p><p>IMMEDIATELY AFTER EATING FOOD</p><p><br></p><p>STUBBORN</p><p>WANTS TO GO TO FATHER ABROAD</p><p>EARS INCREASED WAX IMPACTED</p><p>26/5/22</p><p>INCREASED HAIRFALL SINCE</p><p>DANDRUFF WITH</p><p>BROWN HAIR</p><p>SINCE ONE YEAR</p><p>EASILY COMING OUT</p>',_binary '<p>14/4/22</p><ol><li>SILICEA 1M - 3 DOSE- WEEKLY ONCE</li><li>B24 - 1/2 OUNCE - 1 BD</li></ol><p>26/5/22</p><ol><li>ARNICA HAIR OIL</li><li>ARNICA SHAMPOO</li><li>ACID PHOS 200 - 3 PILLS TDS</li></ol><p>31/5/22</p><ol><li>ARS ALB 200 - 2DRM PILLS- </li><li>NUX VOM 30 - 2 DRM PILLS</li><li>ALTERNATE 2 HRLY</li></ol>','2022-06-15 00:00:00'),(133,136,_binary '<p>14/4/22</p><p>COUGH SINCE 3 DAYS</p><p>WITH EXPECTORATION MORE AT NIGHT</p><p>THICK YELLOW NASAL DISCHARGE WITH</p><p>NO HISTORY OF PNEUMONIA OR HOSPITAL ADMISSION</p><p>SLIGHT RATTLING HAD BEEN SEEN BEFOR ALSO</p><p>BOWELS CONSTIPATED DOESNT PASS DAILY</p><p>PERSPIRATION= ++</p><p>H/O FEVR AT NIGHT SOME DAYS, DOESNT SEE ANY FEVER IN MORNING</p><p>FREQUENT RESPIRATORY INFECTIONS</p><p>TONGUE = CLEAN</p><p>16/4/22</p><p>FEELING  BETTER FOR CONGESTION</p><p>COUGH DRY NOW</p><p>18/4/22</p><p>MEDICINE PILLS GOT DISPLACED</p>',_binary '<p>14/4/22</p><ol><li>PULS 200 2 DRAM PILLS - 4 QID</li><li>IPECAC 30 - 2 DRAM PILLS - 4 QID</li></ol><p>16/4/22</p><ol><li>ARALIA TINCTURE- 5ML - 5 TDS</li></ol><p>18/4/22</p><ol><li>PULS 200 2 DRAM PILLS - 4 QID</li><li>IPECAC 30 - 2 DRAM PILLS - 4 QID</li></ol><p><br></p>','0001-01-01 00:00:00'),(134,133,_binary '<p>14/4/22</p><p>RATTLING SINCE 2 DAYS</p><p>NOSE BLOCKED AND DIFFICULT FEEDING SOMETIMES</p><p>SLIGHT FEVERISH WARM BODY</p><p>NORMAL BIRTH</p><p>BIRTH WEIGHT ; 3.550KG</p><p>PASS BOWELS DAILY MANY TIMES</p><p>CRIES AT NIGHT AT 12PM</p><p>VOMITS FEED AS IT IS, VOMITS THROUGH NOSE ALSO</p><p>11/6/22</p><p>NOSE BLOCK</p><p>COLD SINCE 2 DAYS</p><p>6/7/22</p><p>FEVER SINCE MORNING</p><p>WAKES UP WITH BODY HEAT</p><p>HEAT ON HEAD++..OTHER BODY PARTS COLD</p><p>ON EXAMINATION PAIN IN THROAT FELT</p><p>12/7/22</p><p>COUGH AFTER FEVER</p><p>CHANGE IN SOUND ON CRYING</p><p>DRY COUGH ON AFTER WAKING FROM SLEEP</p><p>THROAT PAIN FELT BY MOTHER</p><p>16/7/22</p><p>COUGH WITH EXPECTORATION NOW</p><p>RATTLING SOUND WITH</p><p>TONGUE CLEAN\'</p><p>22/7/22</p><p>COUGH WITH EXPECTORATION SLIGHTLY PRESENT</p><p>CRACK IN NAPE OF NECK PRESENT NOW</p><p>30/7/22</p><p>SLIGHT COUGH PERSISTING AT TIMES</p><p>WHEN WEATHER IS COLD</p><p>ITCHING LIKE IN EYES NOSE EARS</p>',_binary '<p>14/4/22</p><ol><li>FERR PHOS 6X - 1 DRM TABS - 1 TDS</li><li>SAMBUCUS 30 - 1 DRM PILLS - 2 QID</li></ol><p>11/6/22</p><ol><li>SAMBUCUS 30 - 1 DRM PILLS - 2TDS</li><li>PULS 200 - 1 DRM PILLS - 2 TDS</li></ol><p>6/7/22</p><ol><li>ARNICA 200 - 1 DOSE NOW</li><li>BRY 200 - 2 DRM PILLS ALTERNATE 2 HRLY WITH BELL 200</li><li>BELL 1M - 3 DOSE</li></ol><p><br></p><ol><li>BELL 200 2 DRM PILLS</li></ol><p>12/7/22</p><ol><li>PYROGEN 200 - 2 DRM PILLS - 4 BD</li><li>NASAL DROPS</li><li>BRY 1M - 2DOSE FOLLOWED BY</li><li>BRY 200 - 2 DRM PILLS - 4TDS</li><li>BORONIP</li></ol><p>16/7/22</p><ol><li>PULS 200 - 2 DRM 3PILLS ALTERNATE WITH</li><li>IPECAC 3X - 2 DRM PILLS 2 HRLY</li></ol><p>22/7/22</p><ol><li>HEP SULPH 200 - 2 DRM PILLS -</li><li>IPECAC 3X - 2 DRM PILLS</li><li>ACID NITRICUM 1M - 2 DOSE BD</li></ol><p>30/7/22</p><ol><li>TUBERCULINUM 1M - 1 DOSE HS</li><li>RUMEX 200 - 2 DRM PILLS 4 TDS</li><li>HEP SULPH 200 - 4 TDS 2 DRM PILLS</li></ol>','2022-06-18 00:00:00'),(135,137,_binary '<p>18/4/22</p><p>HAEMORRHOIDS SINCE 9 YRS,STARTED AFTER FIRST DELIVERY</p><p>PAIN WITH ENLARGEMENT AND BLEEDING AFTER STRAINING FOR STOOLS </p><p>BURNING ++ ITCHING+</p><p>CONSTIPATED AT TIMES BUT NOT DAILY CONSTIPATION CAUSES PAIN BLEEDING ETC</p><p>DESIRE TO PASS PRESENT</p><p>ITCHING IN VAGINA WITH SLIGHT WHITE DISCHARGE TAKEN ALLOPATHIC TREATMENT</p><p>HEAT BODY BUT THERMALS CHILLY</p><p>PERSPIRATION THIRST = NS</p><p>2 NORMAL DELIVERIES, 9YR AND 5 YR OLD CHILDREN</p><p>MENSES REGULAR</p><p><br></p>',_binary '<p>18/4/22</p><ol><li>ACID NIT 1M 4 DOSE BD WEEKLY ONCE ONLY</li><li>NUX VOM 30 - 2 DRM - 4 TDS</li><li>HAMAMELIS TINCTURE - 20ML - 15 TDS</li><li>Y LAX - 17TABS IN 1/2 OUNCE BOTTLE- 2 HS</li><li>BORO ALLEN CREAM</li></ol>','2022-05-03 00:00:00'),(136,138,_binary '<p>16/4/22</p><p>COUGH SINCE 3 MONTHS</p><p>ALLERGIC ISSUES SINCE MANY YEARS</p><p>COUGH WITH EXPECTORATION</p><p>&lt;NIGHT SLEEP WAKES FROM SLEEP DUE TO COUGH</p><p>SINUSITIS, THROAT PAIN</p><p>NOSE BLOCK AT NIGHT</p><p>SNEEZING &lt;MORNING</p><p>HYPERTROPHIED NASAL TURBINATES</p>',_binary '<p>16/4/22</p><ol><li>GRINDELIA Q - 20ML - 15 TDS</li><li>PULS 200 - 2 DRM - 4 TDS</li><li>KALI BICH 6X - 3 TDS</li></ol>','2022-05-03 00:00:00'),(137,139,_binary '<p>19/4/22</p><p>COUGH SINCE 2 DAYS</p><p>COUGH WITH EXPECTORATION</p><p>FEVER TODAY MORNING</p><p>NOSE BLOCK</p><p>TONSILLS ENLARGED RIGHT SIDE</p><p><br></p><p>22/4/22</p><p>FEVER REDUCED COUGH WITH EXPECTORATION PRESENT NOW</p><p>2/7/22</p><p>COLD SINCE 2-3 DAYS</p><p>COUGH SINCE TODAY DRY PRICKING COUGH</p><p>HISTORY OF COLD JUICE</p><p>THROAT INFECTION</p><p>15/8/22</p><p>COUGH AND COLD SINCE 2 DAYS </p><p>COUGH WITH EXPECTORATION</p><p>NOSE BLOCKED </p><p><br></p>',_binary '<p>19/4/22</p><ol><li>BELL + PHTOLACCA 10ML - 8 DROPS 2HRLY</li><li>BELL 200 2 DRM PILLS - 4 PILLS ALT 2 HRLY</li><li>MERC SOL 200 2 HRLY - ALT</li><li>BELL 1M - 3 DOSES SOS</li></ol><p>22/4/22</p><ol><li>CONTINUE ABOVE TDS</li><li>GRINDELIA Q - 10ML - 8 DROPS TDS</li></ol><p>2/7/22</p><ol><li>BELL + PHTOLACCA 10ML - 8 DROPS 2HRLY</li><li>BELL 200 2 DRM PILLS - 4 PILLS ALT 2 HRLY</li><li>HEPAR SULPH 200 HRLY - ALT</li><li>BELL 1M - 3 DOSES SOS</li></ol><p>15/8/22</p><ol><li>HEP SULPH 200 - 2 DRAM PILLS</li><li>EUCALYPTUS Q + OCIMUM SANCT Q - 20ML - </li><li>TUBERCULINUM 1M - 3 DOSE</li><li>PULS 200 - 2 DRM PILLS - 4 QID</li></ol>','0001-01-01 00:00:00'),(138,140,_binary '<p>20/4/22</p><p>HYPERTENSION SINCE 3 YRS</p><p>NOT TAKING ANY MEDICINES NOT FEELING ANY SYMPTOMS</p><p>PALPITATION ON ANY EXERTION</p><p>SLEEP ; GOOD</p><p>TAKES TENSION EASILY</p><p>NO HABBITS AS SUCH</p><p>BP ; 170/140</p><p>NO FAMILY HISTORY OF HYPERTENSION COUSINS TAKING ANTIHYPERTENSIVES</p><p><br></p><p>23/4/22 150/100BP</p><p><br></p><p>27/4/22</p><p>140/100</p><p>9/5/22</p><p>FBS= 201[60- 110]</p><p>PPBS= 258 [70-140]</p><p>CHOLESTROL - 183 &lt;200</p><p>HDL -42</p><p>TRIGLYCERIDES- 145-[60- 165]</p><p>THIRST INCREASES AT NIGHT</p><p>URINATION INCREASES AT NIGHT WAKES 2-3 TIMES AT NIGHT</p><p>BP= 150/110</p><p>HEADACHE IN CHILDHOOD</p><p>VERTIGO ON EXPOSURE TO SUN</p><p>SLIGHT PROSTRATION WITH PALPITATION ON WHILE DOING SOME WORK</p><p>ANXIETY++</p><p>20/5/22</p><p>bp = 160/110 mm</p><p>NO OTHER HEALTH ISSUES</p>',_binary '<ol><li>20/4/22</li><li>RAUWOLFIA Q - 20ML - 20 TDS</li><li>CONIUM MAC 200 - 6 DOSE BD</li></ol><p><br></p><p>23/4/22</p><ol><li>CONIUM 200 - 1/2OUNCE - 4TDS</li><li>ACONITE 1M - 1 DOSE</li></ol><p>27/4/22</p><ol><li>RAUWOLFIA + CRATEGUS Q - 30ML - 20TDS</li></ol><p>9/5/22</p><ol><li>NUX VOM 1M - 2 DOSE WEEKLY ONCE</li><li>CEPHALANDRA Q - 20ML -10 TDS</li><li>RAUWOLFIA+CRATEGUS+PASSIFLORA - 30ML - 20TDS AFTER FOOD</li><li>NATRUM PHOS 6X - +CONIUM 200 - 1 OUNCE - 3 TD</li><li>CEPHALANDRA Q</li></ol><p>20/5/22</p><ol><li>NAT PHOS 6X - 1/2 OUNCE - 3 TDS</li><li>CONIUM MAC 200 - 1/2 OUNCE - 4 TDS</li><li>CEPHALANDRA Q - 30ML - 15TDS</li><li>ALLIUM SAT Q - 30ML - 15 TDS</li></ol>','2022-05-23 00:00:00'),(139,143,_binary '<p>22/4/22</p><p>WHITE DISCOLORATION ON FACE</p><p>LOSS OF APPETITE</p><p>BOWELS - CONSTIPATED</p><p>11/6/22</p><p>WHITE DISCOLORATION PERSISTING ON FACE INCREASED NOW.</p><p>CONSTIPATED NOT DAILY</p>',_binary '<p>22/4/22</p><ol><li>BACILLINUM 10M - 1 DOSE</li><li>CALC PHOS 6 X- 3 BD 1/2 OUNCE</li></ol><p>11/6/22</p><ol><li>BACILLINUM 1M - 4 DOSE </li><li>SEPIA 30 - 2 DRM PILLS - 4 TDS</li></ol><p><br></p>','2022-05-20 00:00:00'),(140,141,_binary '<p>21/4/22</p><p>FEVER SINCE TODAY MORNING</p><p>HIGH FEVER AT NOON</p><p>HAD RUNNING NOSE</p><p>NO COUGH OR COLD</p><p><br></p><p>12/5/22</p><p>FEVER SINCE 2-3 DAYS ,INTERMITTANT FEVER</p><p>COUGH SINCE 2 DAYS</p><p>RUNNING NOSE, COUGH WITH EXPECTORATION</p><p>COUGH &lt;NIGHT</p><p>APETITE POOR</p><p>BOWELS REGULAR</p><p>25/7/22</p><p>FEVER SINCE 3 DAYS</p><p>HAD COUGH AND COLD SINCE SOME DAYS</p>',_binary '<p>21/4/22</p><ol><li>BAPT 3X - 5ML - 6 DROPS 2 HRLY</li><li>BRY 200 2 DRM PILLS - 3 PILLS 2 HRLY</li><li>BELL 1M - 3 DOSE -SOS</li></ol><p>12/5/22</p><ol><li>PULS 200 - 1 DRM PILLS - 3 QID</li><li>IPECAC 30 - 1 DRM PILLS - 3 QID</li></ol><p>28/7/22</p><ol><li>BRY 200 - 2 DRM PILLS</li><li>BELL 1M - IN FP 6X - 2 DRM</li><li>BAP 3X - 5ML - 6 DROPS 2 HRLY</li></ol>','2022-05-19 00:00:00'),(141,142,_binary '<p>21/4/22</p><p>ITCHING IN EYES</p><p>SNEEZING CONTINOUSLY NO WHEEZING OR ASTHMA &lt;DUST</p><p>12/5/22</p><p>ALLERGIC SYMPTOMS RELIEVED WITH MEDICINES</p><p>FEVER SINCE 3 DAYS</p><p>COUGH SINCE 2 DAYS WITH EXPECTORATION &lt;NIGHT</p><p>RECURRANT MOUTH ULCERS</p><p>THERMALS - HOT PATIENT</p><p>PERSPIRATION - NS</p><p>28/7/22</p><p>NOSE BLOCK WITH HEADACHE SINCE YESTERDAY</p><p>HEADACHE IN FRONTAL AND MAXILLARY SINUS</p><p>FEVER SINCE 3 DAYS SWALLOWING CAUSES PRICKING PAIN</p>',_binary '<p>21/4/22</p><ol><li>POTHOS 10ML - 15 TDS</li><li>ARS ALB 30 - 2 DRM PILLS - 4TDS</li><li>BROMIUM 30 - 5 DOSE - EVERY THURSDAY AND MONDAY 1 DOSE</li></ol><p>12/5/22</p><ol><li>GRINDELIA Q - 20ML -15 TDS</li><li>PULS 200 - 2 DRAM PILLS - 4 QID</li><li>ARS IOD 3X - 3 DRAM - 2 BD</li></ol><p>28/7/22</p><ol><li>NASAL DROPS</li><li>PULS 200 - 2 DRM PILLS</li><li>PHYTOLACCA + BELL Q = BAPTISIAQ - 10ML</li><li>BELL 1M - IN FP 6X -SOS FEVER</li></ol>','2022-05-06 00:00:00'),(142,144,_binary '<p>23/4/22</p><p>HEADACHE SINCE 2-3 YRS</p><p>RIGHT SIDED HEADACHE</p><p>NAUSEATING DOESNT VOMIT &lt;LIGHT SOUND</p><p>&gt;TIGHT BANDAGE,SLEEP AFTER</p><p>27/4/22</p><p>PAIN SHIFTED FROM RIGHT TO LEFT AFTER TAKING MEDICINES,NO PAIN IN RIGHT SIDE NOW</p><p>HAD RUNNING NOSE</p><p>9/5/22</p><p>PAIN REDUCED</p><p>&lt;SOUNDS, EXPOSURE TO SUN , SOUND IN CROWD</p><p>MENSES REGULAR CYCLES AND FLOW</p><p>AVERAGE IN STUDIES</p><p>PERSPIRATION +ON FACE</p><p>THERMALS HOTSLEEP AMELIORATES HEADACHE</p><p>20/5/22</p><p>NO HEADACHE SINCE LAST 10 DAYS</p><p>NO OTHER HEALTH ISSUES</p><p>23/6/22</p><p>HEADACHE SINCE 2 DAYS</p><p>TAKES TENSION EASILY</p>',_binary '<p>23/4/22</p><ol><li>NAT MUR 10M - 1 DOSE</li><li>SANGUINARIA TINCTURE - 10ML - 15TDS</li><li>IRIS VERS 200 - 2 DRM - 4TDS</li><li>BRY 200 2 DRM PILLS SOS</li></ol><p><br></p><p>27/4/22</p><ol><li>TUB 10M - 1 DOSE</li></ol><p>9/5/22</p><ol><li>SANGUINARIA TINCTURE - 20ML - 15TDS</li><li>IRIS VERS 200 - 2 DRM - 4TDS</li><li>BRY 200 2 DRM PILLS SOS</li></ol><p>20/5/22</p><ol><li>NAT MUR 10M - 1 DOSE</li><li>IRIS VERS 200 - 2 DRM PILLS - 4 BD</li><li>SANGUINARIA Q - 20ML - 10 DROPS BD</li></ol><p>23/6/22</p><ol><li>TUB 10M - 1 DOSE STAT - 23/6/22</li><li>IRIS VERS 200 - 2 DRM PILLS - 4 BD</li><li>SANGUINARIA Q - 20ML - 10 DROPS BD</li><li>BRY 200 - 2 DRM PILLS SOS</li><li>NAT MUR 10M 1/7/22</li></ol>','2022-05-23 00:00:00'),(144,146,_binary '<p>9/5/22</p><p>IMPETIGO SINCE 2 WEEKS AROUND CHEEEKS AND ON NOSE</p><p>HAD FEVER WITH RASHES</p><p>ERUPTIONS ARE RED WITH DISCHARGES</p><p>13/5/22</p><p>ERUPTIONS HEALING SCAB FORMED</p><p>18/6/22</p><p>FEVER SINCE YESTERDAY</p><p>THROAT REDNESS</p><p>21/6/22</p><p>FEVER NOT REDUCING</p><p>COUGH AT NIGHT WITH EXPECTORATION</p><p>FEVER - 100.8</p><p>27/6/22</p><p>FEVER AGAIN SINCE YESTERDAY</p><p>URINE PUS CELLS - 2-3 IN NUMBER</p><p>CBC NORMAL</p><p>20/7/22</p><p>FEVER SINCE YESTERDAY</p><p>COUGH WITH EXPECTORATION</p><p>?THROAT PAIN</p><p>NOT ABLE TO EAXAMINE</p><p>COUGH WITH EXPECTORATION ,NASAL DISCHARGE THICK</p>',_binary '<p>9/5/22</p><ol><li>ACID NIT 1M - 2 DOSE - 1 NOW 1 TO KEEP</li><li>ECHINACEA TINCTURE - 10ML - 8 TDS</li><li>STAPHYLOCOCCIN 200 - 2 DRM PILLS - 3 TDS</li><li>BT 24 - 1 1 HRLY</li></ol><p>13/5/22</p><ol><li>GIVE ACID NIT 1M 1 DOSE TONIGHT</li><li>CALENDULA TINCTURE - 10ML EXTERNALLY</li><li>CONTINUE REST OF MEDICINES</li></ol><p>16/7/22</p><p><br></p><ol><li>BELL 1M - 4 DOSES</li><li>BAPTISIA +PHYTOLACCA + BELL Q - 10ML - 8 DROPS 2 HRLY</li><li>BRY 200 - 2 DRM PILLS - 2 HRLY</li></ol><p>21/6/22</p><ol><li>PYROGEN 2 DRAM TABLETS - 2 TDS + 7 DAYS</li><li>PULS 200 2 DRM PILLS - 4 QID</li><li>BELL 1M - 4 DOSE AS SOS</li><li>GRINDELIA Q - 10ML - 8 TDS SOS COUGH AFTER FEVER....NTPD</li></ol><p>27/6/22</p><ol><li>PYROGEN 2 DRAM TABLETS - 2 TDS</li><li>BELL 200 - 2 DRAM PILLS - 4 PILLS 2HRLY ALTERNATE WITH</li><li>BRY 200 - 2 DRM PILLS - 4 PILLS 2 HRLY</li><li>BAPTISIA 3X - 10ML - 10 QID</li><li>BELL 1M - 4 DOSE SOS---<span style=\"color: rgb(230, 0, 0);\">-PAID 500..BALANCE 320 TO GIVE BACK</span></li></ol><p><span style=\"color: rgb(230, 0, 0);\">20/7/22</span></p><ol><li><span style=\"color: rgb(230, 0, 0);\">PHYTOLACCA + BELL Q + BAPTISIA Q - 20ML - 8 DROPS 2 HRLY</span></li><li><span style=\"color: rgb(230, 0, 0);\">BELL 1M SOS</span></li><li><span style=\"color: rgb(230, 0, 0);\">PYROGEN 200 - 2 DRM PILLS - 4 TDS</span></li><li>BRY 200 - 2 DRM PILLS - 2 HRLY</li></ol>','2022-05-13 00:00:00'),(145,147,_binary '<p>9/5/22</p><p>RENAL CALCULI SINCE 4 YREARS</p><p>AS PER USG RIGHT PELVI URETERIC CALCULUS WITH MILD HYDRONEPHROSIS</p><p>PAIN IN RIGHT LUMBAR REGION</p><p>LEFT SIDE NO ISSUES</p><p>PAIN &lt; EARLY MORNING RIGHT LUMBAR REGION</p><p>21/6/22</p><p>PAIN REDUCED NOT AS FREQUENTLY AS BEFORE NOW</p><p>DESIRES SPICY FOOD</p><p>TAKES 4 CIGARETTES</p><p>25/6/22</p><p>PAIN STARTED SINCE FEW DAYS</p><p>MEDICINE GOT FINISHED</p><p>NO PAIN WHILE TAKING MEDICINE</p>',_binary '<p>9/5/22</p><ol><li>NUX VOM 10M - 1 DOSE</li><li>HYDRANGEA Q- 30ML - 10 DROPS QID</li><li>MP 6X+ BEL 200+ ACONITE 200 = SOS</li></ol><p>21/6/22</p><ol><li>HYDRANGEA Q- 30ML - 10 DROPS - TDS</li><li>NUX VOM 10M - 1 DOSE KEEP IN HAND AND TAKE WHEN SEVERE PAIN</li><li>MP 6X +BELL 200 + ACONITE 200 - 1/2 OUNCE</li></ol><p>25/8/22</p><ol><li>SARSAPARILLA 1M - 6DOSE,,,EVERY FRIDAY AND TUESDAY</li><li>NUX VOM 10 M - 1 DOSE TONIGHT (THURDAY)</li><li>HYDRANGEA Q+ BERBERIS VULGARIS Q+ CANTHARIS 10 DROPS Q - 30ML - 15TDS</li></ol>','2022-05-17 00:00:00'),(146,148,_binary '<p>9/5/22</p><p>LIPOMA ALL OVER BODY</p><p>INCREASING IN SIZE AND NUMBER</p><p>NOT ITCHING OR PAINFUL</p><p>PRESENT ONLY ON UPPER LIMB</p><p>TAKEN HOMOEOPATHIC MEDICINE FOR MONTH FROM NATIVE</p>',_binary '<p>9/5/22</p><ol><li>MEDO 1M - 4 DOSE WEEKLY ONCE</li><li>THUJA 200 - 2 DRAM PILLS - 5 QID</li><li>CALC FLUOR 6X - 1 OUNCE - 3 QID</li></ol>','2022-06-10 00:00:00'),(147,149,_binary '<p>2/4/22</p><p>ALLERGIC RHINITIS</p><p>&lt;MORNING&lt;COLD WEATHER</p><p>CONTINOUS SNEEZING LEZDS TO COLD</p><p><br></p><p>9/5/22</p><p>NO RELIEF WITH MEDICINES</p><p>SNEEZING WORSE IN COOL AIR</p><p>3/6/22</p><p>SLIGHT RELIEF FELT FOR SNEEZING..SOME DAYS SNEEZING SEVERE</p><p>5/7/22</p><p>NOT SO SNEEZING AS BEFORE, BUT SOME DAYS ONLY</p><p>RELIEF IS THERE</p><p>25/7/22</p><p>RELIEF FOR SNEEZING, PRESENT ONLY ON SOME DAYS</p><p>BLEEDING AND DRYNESS INSIDE NOSE</p>',_binary '<p>2/4/22</p><ol><li>ARS ALB 10M - 1 DOSE</li><li>SABADILLA 30 - 2 DRAM PILLS- 4 TDS</li><li>ARS ALB 30 - 1/2 OUNCE - 2 TAB 1 HRLY</li></ol><p>9/5/22</p><ol><li>TUBERCULINUM 1M - 4 DOSE WEEKLY ONCE</li><li>SILICEA 6X - 1 OUNCE - 3 TDS</li><li>PI- 3 DRAM PILLS - 5 TDS</li><li>ALLIUM CEPA 30 - 2 DRM PILLS - 4 PILLS HRLY AS SOS</li></ol><p>3/6/22</p><ol><li>TUB 1M - 4 DOSE WEEKLY ONCE</li><li>SILICEA 6X - 1 OUNCE - 3 TDS</li><li>POTHOS + SABADILLA TINCTURE - 20ML - 10 TDS</li></ol><p>5/7/22</p><ol><li>TUB 1M - 4 DOSE WEEKLY ONCE</li><li>SILICEA 6X - 1 OUNCE - 3 TDS</li><li>POTHOS + SABADILLA TINCTURE - 30ML - 10 TDS</li></ol><p>25/7/22</p><ol><li>SANGUINARIA N - 3 DRM PILLS- 4 TDS</li><li>THUJA 200 - 2DOSE - 2 WEEKLY ONCE</li></ol>','2022-07-03 00:00:00'),(148,150,_binary '<p>12/5/22</p><p>BLOATED SENSATION IN STOMACH</p><p>BURNING IN STOMACH &lt; EATING AFTER</p><p>HAD BLACK STOOLS LONG BACK</p><p>DESIRES AND EATS LOTS OF SPICY FOOD AND FISH DAILY</p><p>23/5/22</p><p>BOWELS - NOT CLEAR BUT NOT COMPLETE SENSATION</p><p>SLEEP - SATISFACTORY</p><p>WEAKNESS SOME DAYS</p><p>COMPLAINTS RELIEVED SOME DAYS SOME DAYS COMPLAINTS PERSISTS</p><p>150/100= BP</p><p>9/6/22</p><p>BURNING IN STOMACH RELIEVED</p><p>BP 130/100</p><p>PAIN IN NAPE OF NECK ,</p><p>2/7/22</p><p>BP - 140/90 mm</p><p>BOWELS NOT SO CLEAR</p><p>NEEDS GASTRIC BURNING TO GET CURED</p>',_binary '<p><br></p><p>12/5/22</p><ol><li>NAT PHOS 6X - 1/2 OUNCE- 3 TDS</li><li>HYDRASTIS Q - 10ML - 10TDS</li><li>NUX VOM - 1M - 2 DOSE - WEEKLY ONCE MORNING EMPTY STOMACH</li></ol><p><br></p><p>23/5/22</p><ol><li>NAT PHOS 6X - 1/2 OUNCE- 3 TDS</li><li>HYDRASTIS Q +ZINGIBER 15 DROPS- 10ML - 10TDS</li><li>NUX VOM - 1M - 2 DOSE - WEEKLY ONCE MORNING EMPTY STOMACH</li></ol><p>9/6/22</p><ol><li>CONIUM 200 - 1/2 OUNCE TABLETS - 3 TDS</li><li>NUX VOM 200 - 2 DRAM PILLS - 4 BD</li><li>CRATEGUS Q + RAUWOLFIA Q 10ML - 10 DROPS BD</li><li>ARS ALB 200 - 2 DOSE - 2 BD</li></ol><p>2/7/22</p><ol><li>CRATEGUS Q+ RAUWOLFIA Q- 10ML - 10 DROPS BD</li><li>NUX VOW 200 - 2 DRM PILLS - 4 TDS</li><li>NAT PHOS 6X - 1/2 OUNCE - 3 TDS - GASTRIC ISSUES TO GET CLEARED</li></ol>','2022-05-24 00:00:00'),(149,151,_binary '<p>13/5/22</p><p>MENOPAUSE AT 46YRS</p><p>SENSITIVTE TO MOSQUITO BITE ITCHING FOR LONG TIME WITHOUT ERUPTIONS</p><p>SNEEZING &lt;MORNING WAKING UP</p><p><strong>NO SNEEZING WHILE LYIIND DOWN</strong></p><p>SNEEZING VERY SEVERE INVOLUNTARY URINATION</p><p>SNEEZING LEADS TO WHEEZING</p><p>USING INHALER FOR WHEEZING</p><p><strong>RECURRANT MOUTH ULCERS</strong></p><p>GASTRITIS BLOATED ABDOMEN</p><p>HIGH CHOLESTROL TAKING MEDICINE FOR THE SAME</p><p>GASTRIC ISSUES STARTS MORNING ITSLEF AFTER EATING</p><p>FAMILY HISTORY OF HIGH BP,CHOLESTROL AND DIABETES</p><p>BOWELS = REGULAR</p><p>THIRST = NS</p><p>PERPIRATION=+</p><p>DESIRES SPICY FOOD</p><p>NORMAL DELIVERY = 3</p><p>THYROIDECTOMY DONE 10YRS BACK ? GOITER</p><p>ON THYRONORM 75MG</p><p>26/5/22</p><p>WAS BETTER INITIALLY AFTER TAKING MEDICINES</p><p>NOW STARTED GETTING SINCE 2 DAYS</p><p>MOUTH FULL OF ULCERS NOW</p><p>USE TO GET MOUTH ULCER BEFORE MENSES</p><p>HEART BURN SEVERE IMMEDIATELY AFTER TAKING MEDICINE NOT IN EMPTY STOMACH</p><p>HEART BURN IF ANY WORK DONE BENDING</p><p><u>&lt;BENDING AFTER</u></p><p>C/O DISC OSTEOPOROSIS</p><p>SEVERE BACK PAIN</p><p><u>SOUR ERUCTATIONS WITH SOUR YELLOW</u> ERUCTATIONS</p><p>C/O <u>HAEMORRHOIDS </u>WITH SEVERE BLEEDING AFTER TAKING ONE PIECE OF CHICKEN OR EGG.</p><p>PAIN IN RECTUM DURING EGG INTAKE</p><p>H/O HAEMORRHOIDS IN KIDS ALSO</p><p>9/6/22</p><p>FEELING BETTER ALMOST</p><p>2/7/22</p><p>HEARTBURN AT TIMES &lt;EATING STEAMED FOOD</p><p>HIGH CHOLESTROL WITH GASTRIC ISSUES,</p><p>IN GROWING TOE NAIL WITH PAIN </p><p><br></p><p><br></p>',_binary '<p>13/5/22</p><ol><li>NAT PHOS 6X - 1/2 OUNCE - 3 TDS</li><li>HYDRASTIS Q - 10ML - 10 TDS</li><li>MERC SOL - 1M - 2 DOSES- BD</li></ol><p>26/5/22</p><ol><li>CARCINOSIN 200 - 1 DOSE</li><li>SL - 1 DOSE NEXT WEEK</li><li>NUX VOM 30 - 2 DRM PILLS - 4 TDS BEFORE FOOD</li><li>ROBINIA Q - 10ML- 15 TDS</li></ol><p>9/6/22</p><ol><li>CARCINOSIN - 200 - 1 DOSE ONLY - {SOS} IF MOUTH ULCER COMES</li><li>SL - 1 DOSE</li><li>ROBONIA - 10ML - 10 BD</li><li>NUX VOM 30 - 2 DRM PILLS - 4 BD BEFORE FOOD</li></ol><p>2/7/22</p><ol><li>HYDRASTIS Q - 20ML -{HIGH CHOLESTROL WITH GASTRIC DISTURBANCE}</li><li>CARCINOSIN -</li><li>MYRISTICA Q - 20ML -EXTERNALLY</li></ol>','2022-06-25 00:00:00'),(150,152,_binary '<p>10/3/22</p><p>BP = 160/100</p><p>UNSATISFACTORY URINATION, FREQUENT DESIRE TO PASS URINE</p><p><br></p><p>13/5/22</p><p>BP= 130/80</p><p>DIABETES</p><p>INCREASED CHOLESTROL</p><p>ITCHING AT ANUS</p><p>4/6/22</p><p>REQUIRES MEDICINE FOR DIABETES</p><p>29/8/22</p><p>BLOOD SUGAR, CHOLESRTROL NORMAL</p><p><span style=\"color: rgb(230, 0, 0);\">ESR - 59</span></p><p><span style=\"color: rgb(230, 0, 0);\">HB - 10.0GM /DL</span></p><p><span style=\"color: rgb(230, 0, 0);\">WEAKNESS,</span>MUSCLES ARE WEAK AS PER ORTHO</p>',_binary '<p>10/3/22</p><ol><li>RAUWILFIA Q = 20ML = 10 DROPS BD</li><li>SARSAPARILLA 2 DRM PILLS</li><li>THUJA 1M - 1 DOSE</li></ol><p>13/5/22</p><ol><li>RAUWOLFIA Q = 30ML = 15 DROPS BD</li><li>BT - 1/2 OUNCE - 3 BD</li><li>ALLIUM SATIVA Q - 30ML - 15 DROPS BD</li><li>SULPHUR 1M -N1 DOSE AT NIGHT</li><li>CINA 30 2 DRAM TABLETS - 2 BD</li></ol><p>4/6/22</p><ol><li>CEPHALANDRA + SYZIGIUM Q- 30ML - 10TDS</li></ol><p>27/6/22</p><ol><li>RAUWOLFIA +CRATEGUS Q - 30ML - 15 DROPS BD - AFTER FOOD</li><li>CEPHALANDRA +GYMNEMA Q - 30ML -15 DROPS BD BEFORE FOOD</li></ol><p>29/8/22</p><ol><li>RAUWOLFIA +CRATEGUS Q +ALLIUM SAT Q - 30ML - 15 DROPS BD - AFTER FOOD</li><li>CEPHALANDRA +GYMNEMA Q - 30ML -15 DROPS BD BEFORE FOOD</li><li>ACID PHOS 200 - URANIUM NITRICUM 3X - 1/2 OUNCE - 3 BD</li><li>FERRUM PLUS CAPSLES 10 - 1 HS</li></ol>','0001-01-01 00:00:00'),(151,153,_binary '<p>14/5/22</p><p>ALLERGY SINCE 1 YEAR</p><p>TAKEN HOMOEO TREATMENT FOR A MONTH OR TWO AND HAD RELIEF</p><p>SNEEZING &lt; MORNING</p><p>ALL WEATHER</p><p>ITCHING IN EYES</p><p>ITCHING ON NOSE LEADS TO SNEEZING</p><p>NO WHEEZING</p><p>MENSES REGULAR</p><p>HISTORY OF WHEEZING IN FAMILY</p><p>11/6/22</p><p>ITCHING IN EYES PERSISTING</p><p>LMP -5TH APRIL</p><p>AMENORRHOEA SINCE 2 MONTHS</p><p>SNEEZING REDUCED NOT COMPLETELY CURED, SOME DAYS SNEEZING PERSISTING</p><p>BROWN DISCOLORATION ON CHIN WITH ITCHING</p><p>AVERSION TO MILK</p><p>PERSPIRATION - NS</p><p>THIRST - THIRSTLESS</p><p>&lt;DUST SNEEZING</p><p>28/6/22</p><p>FAINTS ON PRICKING WITH INJECTION</p><p>AMENORRHOEA PERSISTING</p><p>HAD FEVER, NOSE BLOCK WITH</p><p>BLACK MARK BELOW LIPS STARTED APPEARING</p><p>ALLERGIC CIMPLAINTS SLIGHTLY PERSISTING....BUT REDUCED</p><p>BACK PAIN SINCE 3- 4DAYS</p><p><br></p>',_binary '<p>14/5/22</p><ol><li>SULPHUR 1M - 2 DOSE - 2 WEEKLY ONCE</li><li>AMM CARB - 30 - 3DRAM PILLS- 5 TDS</li><li>ARS IOD 3X - 1 OUNCE TABLET - 1 TAB TDS</li></ol><p>11/6/22</p><ol><li>AMM CARB 30 +NUX VOM 30 - 3 DRM PILLS</li><li>PULS 1M - 2 DOSE WEEKLY ONCE</li><li>FERR PLUS CAPSULES -7 PER DAY 1</li><li>ASOKA DROPS + PULS Q - 10ML - 10 DROPS TDS</li></ol><p>28/6/22</p><ol><li>PULS 10M - 1 DOSE STAT ON 28/6/22</li><li>ASOKA + PULS Q - 30ML- 15 DROPSTDS</li><li>AMMCARB30+ NUX VOM 30 - 3DRM PILLS- 4 TDS</li><li>PULS 200 - 3 DOSE WEEKLY ONCE..NEXT TUESDAY ONWARDS</li></ol>','2022-06-25 00:00:00'),(152,154,_binary '<p>14/5/22</p><p>BLEEDING ON PRICKING NOSE</p><p>NO COLD OR COUGH</p><p>ONLY IN RIGHT SIDE</p><p>NO COLD</p><p>13/6/22</p><p>AGAIN SAME ISSUES WHEN COLD CAME</p><p>6/7/22</p><p>BLEEDING SCABS IN NOSTRILS NOT THERE NOW</p><p>COLD WITH WHITE DISCHRAGE PERSISTING</p><p>25/7/22</p><p>MEDICINE GOT DISPLACED</p><p>COLD WITH THICK NASAL DISCHARGE AND DRYNESS IN NOSE</p><p>COUGH NOT SOS SEVERE</p><p>REQUIRES FEVER MEDICINE</p>',_binary '<p>14/5/22</p><ol><li>ACID NIT 1M - 2 DOSE BD</li><li>BT - 3 DRAM TABLETS- 1 BD</li></ol><p>13/6/22</p><ol><li>ACID NIT 1M - 2 DOSE BD</li><li>BT + SAMBUCUS 30- 1 OUNCE TABLETS- 2 TDS</li></ol><p>6/7/22</p><ol><li>ACID NIT 1M - 2 DOSES BD AS SOS FOR BLEDING SCABS</li><li>DULCAMARA 200 - 3 DRM PILLS</li><li>PULSATILLA 200 - 3 DRM PILLS -BOTH 4 TDS</li></ol><p>25/7/22</p><ol><li>BELL 1M IN FP 6X - 3DRM TABLETS</li><li>GRINDELIA Q - 30ML -</li><li>BRY 200 - 3 DRM PILLS</li><li>BAPTISIA Q - 30ML</li></ol><p>FEVER KIT AS ABOVE</p><ol><li>PULS 200 - 3 DRM PILLS</li><li>DULCAMARA - 200 - 3 DRM PILLS</li></ol>','0001-01-01 00:00:00'),(153,155,_binary '<p>16/5/22</p><p>WHITE SPOTS ON FACE</p><p>STARTED SPREADING ON TO HANDS</p>',_binary '<p>16/5/22</p><ol><li>BACILLINUM 1M - 1 DOSE</li><li>TELLURIUM 30 - 2 DRAM PILLS</li><li>B26 - 3 DRAM - 20 TABLETS- 1 AT NIGHT</li></ol>','2022-05-31 00:00:00'),(154,156,_binary '<p>16/5/22</p><p>ITCHING ERUPTIONS ON HANDS SINCE ONE MONTH</p><p>ON LEFT HAND</p><p>NOT ON RIGHT HAND</p><p>?SOAP ALLERGY</p><p>LEUCORRHOEA ALWAYS WATERY WHITE OR YELLOW AT TIMES BUT NO SMELL OR ITCHING</p><p>H/O PEELING OF SKIN FROM HANDS AT CHILDHOOD</p>',_binary '<p>16/5/22</p><ol><li>SEPIA 200 - 4 DOSE WEEKLY ONCE</li><li>KALI MUR 6X - 1 OUNCE - 3 TDS</li><li>PL- 2 DRM PILLS 4 TDS</li></ol>','2022-06-11 00:00:00'),(155,157,_binary '<p>17/5/22</p><p>VOMITING ..4 TIMES</p><p>WEIGHT = 22KG</p><p>NO FEVER</p><p><br></p>',_binary '<p>17/5/22</p><ol><li>BAPTISIA Q +ZINGIBER Q - 10ML - 10 TDS</li><li>ARS ALB 200 - 2 DRAM PILLS</li><li>ARS ALB 200 - 1 DOSE NOW</li></ol>','2022-05-21 00:00:00'),(156,158,_binary '<p>17/5/22</p><p>VOMITING SINCE MORNING</p><p>NO FEVER NOW</p><p>WATERY NASAL DISCHARGE</p><p>RATTLING AT NIGHT</p><p>HISTORY OF SEVERE FEVER ONE WEEK BACK COUGH GIVEN ALLOPATHY MEDICINES</p><p>NORMAL BIRTH</p><p>NO OTHER HEALTH ISSUES</p><p>WATERING FROM MOUTH</p>',_binary '<p>17/5/22</p><ol><li>ARS ALB 200 - 2 DRAM PILLS</li><li>NATRUM SULPH 6X- 3DRAM - 2 TDS</li><li>BAPTISIA 3X+ ZINGIBER 30 - 5ML</li></ol>','2022-05-24 00:00:00'),(157,159,_binary '<p>18/5/22</p><p>RASHES ON EAR AND NAPE OF NECK</p><p>ALLERGIC TO SUN LIGHT</p><p>ITCHING</p><p>ONLY ON EXPOSURE TO SUNLIGHT</p><p><br></p><p>NO OTHER ISSUES</p><p>30/5/22</p><p>REDUCED RASHES</p><p><br></p><p><br></p>',_binary '<p>18/5/22</p><ol><li>IGNATIA 1M - 2 DOSES</li><li>NAT CARB 30 - 2 DRAM PILLS - 4 TDS</li></ol><p>30/5/22</p><ol><li>NAT CARB 30 - 3DRAM PILLS - 4 TDS</li><li>IGNATIA 1M - 2 DOSES - AFTER 1 WEEK</li></ol>','2022-05-30 00:00:00'),(158,160,_binary '<p>19/5/22</p><p>RECURRANT COUGH AND COLD</p><p>&lt; COLD WEATHER</p><p>ALWAYS GET COUGH AND COLD</p><p>STARTS AS THROAT PAIN</p><p>SENSATION OF PHLEGM IN THROAT</p><p>DRY COUGH WITH</p><p>LEADS TO COUGH</p><p>NOW COUGH SINCE 3 DAYS</p><p>MORNING WET COUGH EVENING DRY COUGH</p><p>6/5/22</p><p>COUGH PERSISTING SLIGHTLY AT MORNING</p><p>SHORT DRY PRICKING COUGH AT TIMES SINCE 2-3 DAYS</p><p>TAKEN ICE CREAM ONCE</p><p>COUGH STARTED AFTER APPLYING OIL IN HAIR</p><p>WITH PHLEGM AT MORNING,</p><p>17/6/22</p><p>DONE ENDOSCOPY FROM AN ENT</p><p>COUGH REDUCED</p><p>ALLERGIC COUGH &lt;MORNING</p><p>PHLEGM COIMING UP FROM THROAT</p><p>NAUSEATING DOESNT VOMIT</p><p>6/7/22</p><p>NO COUGH AT PRESENT</p><p>PHLEGM DISTURBING IN NOSE ONLY AT ROOT OF NOSE</p><p>HAD FEVER FEW DAYS BACK</p><p>28/7/22</p><p>SLIGHT CLEARING OF THROAT AT MORNING</p><p>SLIGHT COUGH WITH COLD</p><p>O/E CHEST CLEAR</p><p>DISLIKES - EGG,MILK</p><p>PERSPIRATION - NS</p><p>THIRST - NS</p>',_binary '<p>KJ18/5/22</p><p>COURSE 1</p><ol><li>IPECAC 30 - 2 DRAM PILLS - 4 QID</li><li>KALI BICH 6X - 1/2 OUNCE - 2 TDS</li></ol><p>COURSE 2 FOR IMMUNITY</p><ol><li>TUBERCULINUM 1M - 4 DOSE - WEEKLY ONCE</li><li>ARS IOD 3X - 1/2 OUNCE - 2 TDS</li></ol><p>6/6/22</p><ol><li>HEPAR SULPH 200 - 3 DRAM PILLS - 4 QID</li><li>IPECAC 3X - 10ML - 8 QID</li></ol><p>FOR COUGH</p><p>17/6/22</p><ol><li>KALI BICH 6X - 1 OUNCE - 2 TDS</li><li>EUCALYPTUS Q - 30ML - 10 TDS</li><li>PULS 200 - 4 DOSE WEEKLY ONCE</li></ol><p>FOR COUGH</p><p>IPECAC 3X - 10ML - 10 TDS</p><p>HEP SULPH 200 - 2 DRM PILLS - 4 TDS</p><p>6/7/22</p><ol><li>CONTINUE EUCALYPTUS Q - 10 BD</li><li>PULS 200 - 4 DOSE WEEKLY</li><li>KALI BICH 6X - 1OUNCE - 2 BD</li></ol><p>FOR COUGH</p><p>1PECAC - 3X - 10ML SOS</p><p>HEP SULPH 200 - 2 DRM PILLS SOS</p><p>28/7/22</p><ol><li>EUCALYPTUS Q - 20ML - 10 TDS</li><li>HEP SULPH 200 - 2 DRM PILLS</li><li>PULS 200 - 3 DOSE WEEKLY ONCE</li><li>IPECAC 3X - 10ML SOS</li></ol>','2022-06-02 00:00:00'),(159,162,_binary '<p>20/5/22</p><p>WARTS ON EYELIDS SINCE 3 YEARS</p><p>NOT PAINFUL OR ITCHING</p><p>MOLLUSCUM LIKE</p>',_binary '<p>20/5/22</p><ol><li>CAUSTICUM 200 - 2 DRAM PILLS - 4 TDS</li><li>BT 26- 1 OUNCE - 3 BD</li></ol>','0001-01-01 00:00:00'),(160,163,_binary '<p>20/5/22</p><p>RHAGADES</p><p>CRACKS ON HEELS</p><p>SINCE MANY YEARS</p><p>&lt;IN COLD WEATHER</p><p>15/6/22</p><p>COMPLAINTS REDUCED</p><p>MEDICINE GOT OVER</p><p>SLIGHT DEVIATION TO RIGHT WHILE WALKING</p><p>?FIBROMYALGIA</p><p><br></p>',_binary '<p>20/5/22</p><ol><li>SARASAPARILLA 1M - 2 DOSE</li><li>PETROLEUM 30 - 2 DRM PILLS - 4 TDS</li><li>BT 1/2 OUNCE - 1 TDS</li></ol><p>15/6/22</p><ol><li>PETROLEUM 30 - 2 DRM PILLS - 4 BD</li><li>RHUS TOX 200 IN MAG PHOS - 1/2 OUNCE - 3 TDS AS SOS</li></ol>','2022-06-03 00:00:00'),(161,165,_binary '<p>24/5/22</p><p>NUMBNESS UNDER FOOT SINCE 1 YEAR FOR BOTH LEGS</p><p>DIABETIC SINCE 4-5 YRS</p><p>LOSS OF SENSATION FOR LEGS</p><p>PHYSICAL</p><p>APETITE - GOOD</p><p>THIRST - GOOD</p><p>SLEEP - NS</p><p>PERSPIRATION - NS</p><p>DOESNT LIKE FANNING</p><p>TAKING OMI TABLETS DAILY FOR HEART BURN  SINCE ONE YEAR</p><p>VERY DIFFICULT IF NOT TAKEN</p><p>MUSCLE CRAMPS ON LEG AT NIGHT</p><p>TRIGGER FINGER ON LEFT HAND</p>',_binary '<p>24/5/22</p><ol><li>KALI PHOS 6X - 1/2 OUNCE - 3 TDS</li><li>SYPHILINUM 1M - 1 DOSE AT BEDTIME</li><li>LEDUM PAL 200 - 2 DRM PILLS  - 4 TDS</li></ol>','2022-06-07 00:00:00'),(162,166,_binary '<p>24/5/22</p><p>PAIN IN RIGHT SIDE OF LOWE ABDOMEN SINCE 5- 6 DAYS</p><p>NO SWELLING</p><p>GASTRITIS AFTER TAKING FOOD TODAY</p><p>BOWELS - REGULAR</p><ol><li>THIRST - GOOD</li></ol><p>11/6/22</p><p>COLD SINCE 3 DAYS</p><p>COUGH AT TIMES</p><p>YELLOW PHLEGH WITH</p><p>17/6/22</p><p>FEVER SINCE MORNING</p><p>TIRED</p><p>PHLEGM WITH COUGH IN SHORT DURATION</p><p><br></p>',_binary '<p>24/5/22</p><ol><li>RHUS TOX 1M - 2 DRAM PILLS - 4 TDS</li><li>MAG PHOS 6X - 2 DRM TABLETS - 3 TDS</li></ol><p>11/6/22</p><ol><li>EUCALYPTUS - 10ML - 10 TDS</li><li>PULSATILLA 200 - 2 DRM PILLS - 4 TDS</li></ol><p>17/6/22</p><ol><li>BAPTISIA 3X +PHYTOLACCA + BELL Q- 10ML -10 DROPS 2 HRLY</li><li>BRYONIA 200 - 2 DRM PILLS</li><li>BELL 1M - 3 DOSE SOS</li></ol>','2022-05-31 00:00:00'),(163,167,_binary '<p>24/5/22</p><p>TINEA CRURI ON BACK NOW SPREADING ON TO CHEST</p><p>HISTORY OF SAME IN BROTHER , GOT REDUCED WITH EXTERNAL APPLICATIONS</p><p>NOT GETTING REDUCED WITH ITVTO THIS BABY</p><p>HISTORY OF 2 ADMISSIONS WITH CHEST CONGESTION AND FEVER</p><p>POOR IMMUNITY WITH RECURRANT CHEST CONGESTIONS, NEEDS MEDICINE</p><p>NO HISTORY OF ALLERGY IN FAMILY</p><p>30/5/22</p><p>LEFT SIDED RONCHI HEARD</p><p>PHLEGM IN CHEST</p><p>RATTLING IN CHEST</p><p>COUGH &lt; SLEEP DURING</p><p>DESIRES HOT FOOD</p><p>1/6/22</p><p>RATTLING PRESENT IN CHEST</p><p>CHILD ACTIVE, SLEEP GOOD, PLAYFUL</p>',_binary '<p>24/5/22</p><ol><li>BACILLINUM 1M - 2 DOSE ON EVERY TUESDAY NIGHTS</li><li>SEPIA 30 - 2 DRAM PILLS - 3 TDS</li></ol><p>30/5/22</p><ol><li>ANT TART 30 - 1 DRM PILLS</li><li>IPECAC 30 - 1 DRM PILLS</li></ol><p>ALTERNATE EVERY 2 HRLY</p><p>?KALI SULPH</p><p>1/6/22..CONTINUE SAME</p><p><br></p>','2022-06-07 00:00:00'),(164,168,_binary '<p>25/5/22</p><p>RENAL CALCULI RIGHT SIDE SINCE MANY YEARS</p><p>RIGHT SIDED PAIN VERY MUCH SINCE 4 -5 DAYS</p><p>VOMITING SENSATION WITH VERTIGO</p><p>HYPERTENSION</p><p>THYROID SINCE MANY YEARS</p><p>THRIST - LESS</p><p>PAIN AT THE END OF URINATION AT BACK RIGHT SIDED</p><p>NAUSEATING WITH PAIN</p><p>7/6/22</p><p>PAIN NOT AS SEVERE AS BEFORE</p><p>BUT HAD PAIN 3 TIMES IN LAST 2 WEEKS</p><p>CONSTIPATION, HARD STOOLS UNSATISAFACTORY</p><p>16/6/22</p><p>PAIN IN ABDOMEN SINCE SOME DAYS</p><p>GASTRIC ISSSUES</p><p>DROPS GOT OVER</p><p>2/7/22</p><p>MIND - SUSPICIOUS</p><p>FREQUENTLY ASKS ABOUT IF STONE GETS CURED OR NOT</p><p>PAIN PERSISTING IN RIGHT ABDOMEN</p><p>MENOPAUSE - 8 YRS BACK</p><p>2 - ONE BOY AND ONE GIRL, NORMAL DELIVERY</p><p>15/7/22</p><p>PAIN RELIEF FELT SINCE SOME DAYS</p><p>27/7/22</p><p>PAIN STARTED AGAIN SINCE 1 WEEK</p><p>&lt;BENDING</p><p>BOWELS CONSTIPATION</p><p>NEEDS MEDICINE FOR GASTRITIS</p><p>NEERIRAKKAM, WITH &lt;BACK PAIN</p><p>FEAR TO TAKE MEDICINE ESP ALLOPATHIC TABLETS, FEARS ABOUT KIDNEY DISEASE</p><p>13/8/22</p><p>FEELING BETTER FOR CONSTIPATION</p><p>WHEN MEDICINES GOT OVER PAIN STARTED</p><p><br></p><p><br></p>',_binary '<p>25/5/22</p><ol><li>CLAERSTONE - 20ML- 15 DROPS TDS</li><li>LYCOPODIUM 200 - 1/2 OUNCE TABS - 2 TDS</li><li>BELL 1M - 2 DRAM SOS - 3 PILLS 1 HRLY</li></ol><p>7/6/22</p><ol><li>Y LAX - 1 AT NIGHT</li><li>CLEARSTONE + OCIMUM CAN Q - 20M - 15 TDS</li><li>LYCOPODIUM 200 - 1/2 OUNCE TAB - 2 TDS</li><li>BELL 1M - 2 DRAM PILLS - 4 SOS HRLY</li></ol><p>16/6/22</p><ol><li>NUX VOM 30 - 2 DRM PILLS</li><li>OCIMUM CAN Q + CLEARSTONE = 30ML - 15 TDS</li></ol><p>2/7/22</p><ol><li>LYCO 1M - 3 DOSE WEEKLY ONCE ON SATURDAYS</li><li>THUJA 30- 1/2 OUNCE - 3 TDS</li><li>HYDRANGEA Q- 20ML - 10 TDS</li></ol><p>15/7/22</p><ol><li>LYCO 1M - 3 DOSE - WEEKLY ONCE</li><li>OCIMUM CAN - 20ML - 15 TDS</li><li>THUJA 30 - 1/2 OUNCE -3 TDS</li></ol><p>27/7/22</p><ol><li>NUX V - 3O - 2 DRM PILLS - 4 QID</li><li>Y LAX - 10 TABLETS</li><li>BELL 1M - - 2DRM PILLS- 4 SOS</li><li>LYCO 1M - 12 DRM TABLETS - 2 TABLETS IN 5 DAYS IF SEVERE</li><li>CLEAR STONE - 20ML - 10 TDS</li><li>OCIMUMCAN - 30ML - 15 QID</li></ol><p>13/8/22</p><ol><li>BERBERIS VULGARIS Q- 20ML </li><li>CLEARSTONE - 20ML</li><li>LYCOPODIUM 1M - 3 DOSE WEEKLY ONCE</li><li>NUX VOM 30 - 2 DRM PILLS</li><li>BELL 1M - 2 DRM PILLS -SOS</li></ol>','2022-06-22 00:00:00'),(165,169,_binary '<p>27/5/22</p><p>ASTHMA SINCE 18 YEARS</p><p>TAKEN ALLOPATHIC TREATMENT FOE A YEAR AND GOT REDUCED NOW STARTED AGAIN</p><p>SNEEZING &lt;MORNING 4AM WAKING ON WITH SNEEZING</p><p>NO ITCHING</p><p>CONTINOUS SNEEZING</p><p>FAMILY HISTORY OF ASTHMA IN FATHER AND SISTERS</p><p>MENSES REGULAR</p><p>4 CHIDREN , STARTED DURING FIRST PREGNANCY</p><p>ASTHMA WAS ONLY DURING PREGNANCY</p><p>HISTORY OF APPENDIX OPERATION</p><p>ASTHMA EARLY MORNING MORE</p><p>&lt; WINTER</p><p>NOSE BLOCK WITH WATERY NASAL DISCHARGE</p><p>HURRIED WORK CAUSES DIFFICULT</p><p>SNEEZING &lt;TENSION DURING</p><p>10/6/22</p><p>ASTHMA SLIGHTLY BETTER DIDNT USE INHALER</p><p>SNEEZING PERSISTING AS SAME</p><p>PHLEGM COMING UP EASILY NOW NO SMELL WHITE IN COLOUR</p><p>SNEEZING MORE AT NIGHT</p><p>FEELING BETTER WITH MEDICINES</p><p>22/6/22</p><p>FEELING BETTER WHILE TAKING MEDICINE</p><p>ONE DAY HAD SEVERE WHEEZING, WOKE UP FROM SLEEP WITH SNEEZING</p><p>MORE DURING WINTER AND RAINY SEASON</p><p>WHEEZING NOT SO SEVERE DURING SUMMER</p><p>18/8/22</p><p>HAD SNEEZING SINCE 2 DAYS </p><p>NOSE BLOCKED SENSATION</p><p>&lt;WAKING ON MAORNING</p><p><br></p><p><br></p>',_binary '<p>27/5/22</p><ol><li>NAT SULPH 1M DOSE</li><li>PASSIFLPORA Q - 20ML - 15 TDS</li><li>ARS ALB 200 - 2DRM- 4 TDS</li><li>B26 - 1 OUNCE - 1 TDS</li></ol><p>10/6/22</p><ol><li>NAT SULPH 1M - 2 DOSE -</li><li>PASSIFLORA + GRINDELIA Q - 20ML - 15 TDS</li><li>ARS ALB 200 - 2 DRM PILLS - 4 TDS</li></ol><p>22/6/22</p><ol><li>THUJA 1M - 1 DOSE - ON 8/7/22 NIGHT</li><li>PASSIFLORA + GRINDELIA Q - 20ML - 10 TDS</li><li>ARS ALB 200 - 2 DRM PILLS - 4 TDS</li></ol><p>18/8/22</p><ol><li>ARS ALB 200 - 2 DRM PILLS</li><li>POTHOS + SABADILLA Q - 20ML - 10 TDS</li><li>PULS 200 - 3 DOSE WEEKLY ONCE</li></ol><p><br></p>','2022-06-24 00:00:00'),(166,171,_binary '<p>27/5/22</p><p>THROAT PAIN WITH ITCHING AFTER COLD INTAKE DRINKS AND ICE CREAM</p><p>SNEEZING</p><p>WATERY NASAL DISCHARGE</p><p><br></p>',_binary '<p>27/5/22</p><ol><li>BELL 200 - 2 DRM PILLS - 4 TDS</li><li>HEP SULPH 200 IN 10ML TABLETS - 1 TDS</li></ol>','2022-06-10 00:00:00'),(168,173,_binary '<p>28/5/22</p><p>PAIN AND TINGLING IN HANDS</p><p>?CTS</p><p>TAKEN ALLOPATHIC MEDICINE FOR 3 MONTHS</p><p>NO OTHER HEALTH ISSUES</p><p>ONE CHILD - NORMAL DELIVERY</p><p><br></p><p><br></p>',_binary '<p>28/5/22</p><ol><li>MEDO 1M - 1 DOSE</li><li>RUTA 30 - 3 DRM TABLETS - 2 TDS</li><li>ACTEA SPICATA 30 - 2 DRM PILLS- 4 TDS</li></ol><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p>','2022-06-11 00:00:00'),(169,174,_binary '<p>30/5/22</p><p>SNEEZING SINCE MANY YYEARS</p><p>ITCHING IN EYES</p><p>ONLY IN RIGHT EYES</p><p>SNEEZING STRONG ODOUR</p><p>REGULAR</p><p>MARRIED SINCE - 3YRS</p><p>ONE CHILD 2.5YRS - C SECTION - BREECH PRESENTATTION</p><p>REGULAR VIT B COMPLEX INTAKE --DUE TO RECURRANT APHTHOUS</p><p>BOWELS - REGULAR</p><p>THYROID NORMAL AFTER CHECKING</p><p>SENSATION OF THROAT OBSTRUCTED</p><p>CONSTANT CLEARING OF THROAT</p><p>MENSES REGULAR</p><p>BLEEDING NS</p><p>14/6/22</p><p>COUGH AT NIGHT</p><p>SNEEZING &lt;NIGHT,</p><p>ITCHING IN THROAT</p><p>SLIGHT RELIEF ONLY FELT WITH MEDICINE</p>',_binary '<p>30/5/22</p><ol><li>PHOS 200 - 2 DOSE WEEKLY ONCE</li><li>ARS ALB 30 - 2 DRM PILLS - 4 TDS</li><li>BT 26 - 1 BD</li></ol><p>14/6/22</p><ol><li>CARCINOSIN 200 - 3 DOSE - 2 WEEKLY ONCE{ RECURRANT APHTHOUS, MOSQUITO BITE ALLERGY}</li><li>POTHOS +ARALIA + SABADILLA Q - 30ML - 10TDS</li><li>SILICEA 6X - 1OUNCE - 3 TDS</li></ol>','2022-07-13 00:00:00'),(170,175,_binary '<p>31/5/22</p><p>VITILIGO SINCE 8 YEARS</p><p>HAD TAKEN ALLOPATHIC AND HOMOEO MEDICINES FOR IT</p><p>HISTORY OF HIGH CHOLESTROL</p><p>NO MAJOR HEALTH ISSUES</p><p>BAKERY BUSINESS</p><p>3 CHILDREN</p><p>THERMALS- CHILLY PATIENT</p><p>BATHS IN HOT WATER</p><p>SLEEP = GOOD</p><p>DESIRES CHICKEN</p><p>SINCE SOME DAYS PHLEGM COMES UP</p><p>23/6/22</p><p>PERSISTING AS SAME</p><p>COMPLAINTS INCREASING SINCE 6 MONTHS</p><p>21/7/22</p><p>MIND - ANXIETY EASILY ABOUT FAMILY</p><p>DOESNT SHARE WITH ANYONE</p><p>COUGH &lt; EVENING &lt; MORNING</p><p>COUGH WITH EXPECTORATION</p><p>THERMALS - CHILLT PATIENT&lt; DURING WINTER</p><p>HAD TAKEN TREATMENT FOR VITILIGO BEFORE HOMOEOPATHY HAD CURED</p><p>HISTORY OF SAME IN FAMILY BUT CURED FOR DAUGHTER</p><p>16/8/22</p><p>MORNING AND AFTERNOON COUGH PERSISTING</p><p>VITILIGO PERSISTING AS SAME</p><p><br></p>',_binary '<p>31/5/22</p><ol><li>SL - 1- 1 DOSE</li><li>BT 24- 2 TDS</li><li>BT 26 - 1 OD</li></ol><p>23/6/22</p><ol><li>ARS SULPH FLAV - 1 OUNCE - 2 AT NIGHT</li><li>NAT MUR 10M - 1 DOSE STAT</li><li>NAT MUR 6X - 1 OUNCE - 4 TDS</li></ol><p>21/7/22</p><ol><li>ARS SULPH FLAV - 1 OUNCE - 2 AT NIGHT</li><li>SYPHILINUM 10M - 2 DOSE 2 WEEKLY ONCE</li><li>ACID NITRICUM 200 - 1/2 OUNCE - 3 TDS</li><li>EUCALYPTUS + BLATTA Q FEW DROPS - 10ML - 10BD</li></ol><p>16/8/22</p><ol><li>ARS SULPH FLAV - 1 OUNCE - 2 TDS</li><li>SYPHILINUM 1M - 4 DOSE WEEKLY ONCE</li><li><br></li></ol>','2022-06-14 00:00:00'),(171,176,_binary '<p>31/5/22</p><p>FEVER SINCE 3 DAYS</p><p>WEAKNESS</p><p>COLD SINCE 4-5 DAYS</p><p>MORE AT NIGHT</p><p>NO OTHER ISSUES</p><p>21/6/22</p><p>COUGH SINCE SOME DAYS</p><p>WITH SLATTLING RATTLING &lt;NIGHT</p><p>O/E </p><p>SLIGHT SWELLING OF TONSIL</p><p>CHEST CLEAR</p><p>PERSPIRATION - +</p><p>TONGUE = COATED WHITE</p><p>BOWELS - REGULAR</p><p>NEEDS MEDICINE FOR RATTLING AND SLIGHT COUGH</p><p><br></p><p><br></p>',_binary '<p>31/5/22</p><ol><li>BELL 1M - 3 DOSES - SOS</li></ol><p>21/6/22</p><ol><li>ANT TART 6C - 2DRM PILLS- 4 TDS</li><li>EUCALYPTUS Q+ GRINDELIA Q- 10ML - 8 DROPS TDS</li></ol><p><br></p>','0001-01-01 00:00:00'),(172,177,_binary '<p>1/6/22</p><p>THROAT PAIN SINCE MORNING</p><p>ALWAYS GET THROAT PAIN ON TAKING COLD FOOD</p><p>NO HEADACHE OR BODY PAIN</p><p>HISTORY OF ALLERGY &lt;DUST ,</p><p>ALWAYS SNEEZING</p><p>11/6/22</p><p>COUGH &lt; MORNING WITHOUT EXPECTORATION</p><p>NASAL DISCHARGE THICK YELLOW AND WHITE AT TIMES</p><p>NO SNEEZING NOW</p><p>25/6/22</p><p>FEVER SINCE YESTERDAY NIGHT</p><p>INTERMITTANT TYPE</p><p>HAD ICE CREAM</p><p>2/7/22</p><p>SEVERE THICK NASAL DISCHARGE , </p><p>SNEEZING REDUCED</p><p>&lt;NIGHT &lt; MORNING</p>',_binary '<p>1/6/22</p><ol><li>BAPT+PHYTOLLACA+ BELL Q- 10ML</li><li>MERC SOL 200 - 2 DRAM PILLS</li><li>BELL 200 - 2 DRM PILLS</li></ol><p>11/6/22</p><ol><li>PULS 200 - 2DRM PILLS - 4 TDS</li><li>ARALIA Q+ ZINGIBER Q - 10ML -10 TDS</li></ol><p>25/6/22</p><ol><li>BAPT+PHYTOLACCA +BELL Q - 10ML - 10 TDS</li><li>BRY 200 - 2 DRM PILLS</li><li>BELL 1M 3 DOSE - SOS</li></ol><p>2/7/22</p><ol><li>PULS 200 - 3 DRM PILLS - 4 TDS</li><li>KALI BICH 6X - 1/2 OUNCE - 1 BD</li></ol>','2022-06-25 00:00:00'),(173,178,_binary '<p>1/6/22</p><p>BURNING MICTURITION</p><p>FREQUENT TENDENCY TO PASS</p><p>PCOD</p><p>19/8/22</p><p>C/O FISSURE WITH CONSTIPATION</p><p>CONSTIPATION</p><p>BURNING +++</p><p>CONSTIPATION BEFORE ALSO</p><p>NO DESIRE TO PASS DAILY</p><p>PASS ONCE IN 3 DAYS</p>',_binary '<p>1/6/22</p><ol><li>PULS 10M - 1 DOSE</li><li>CANTHARIS 200 - 2 DRM PILLS - 3PILLS ALTERNATE WITH</li><li>APIS 200 - 2 DRM PILLS</li><li>PYROGEN 200 - 1 DRM TABLETS - 2 TDS</li></ol><p>18/8/22</p><ol><li>PEONIA Q - 20ML-10 TDS</li><li>ACID NITRICUM - 1M - 2 DOSE</li><li>YLAX - 14 TABLETS - 2 AT NIGHT</li><li>CALC FLUOR 6X + RATANHIA 200 - 20ML BOTTLE - 3 TDS</li></ol>','2022-06-15 00:00:00'),(174,179,_binary '<p>2/6/22</p><p>HAD FEVER WHILE TRAVELING FROM ABROAD</p><p>NASAL DISCHARGE THICK AND WATERY AT TIMES</p><p><br></p><p><br></p>',_binary '<p>2/6/22</p><ol><li>PULSATILLA 200 - 2 DRM PILLS</li><li>SAMBUCUS 30 - 2 DRAM PILLS</li><li>CINA 30 - B26 - 2DRM TABLETS 1 AT NIGHT</li></ol>','2022-06-16 00:00:00'),(175,180,_binary '<p>4/6/22</p><p>AFTER RELOCATING TO MINI OOTY FOR HIGHER STUDIES NOT FEELING WELL</p><p>&lt;HILL STATION COLD WEATHER</p><p>PHLEGM COMES UP EASILY IN MOUTH</p><p>COUGH AT TIMES ONLY NOT ALWAYS</p><p>WHEN SEVERE FELT SOME BREATHING DISTRESS</p><p>WAS USING INHALERS AT THAT TIME, DOESNT WANT TO USE IT REGULARLY</p><p>DESIRES PLAYING FOOTBALL GOES FOR TOURNAMENT</p><p><br></p><p><br></p>',_binary '<p>4/6/22</p><ol><li>EUCLYPTUS Q - 30ML - 10 TDS</li><li>SILICEA 6X - 1 OUNCE - 3 TDS</li><li>PULSATILLA 200 - 4 DOSE WEEKLY ONCE</li></ol>','2022-06-18 00:00:00'),(176,181,_binary '<p>4/6/22</p><p>CHIKEN POX</p><p><br></p>',_binary '<p>4/6/22</p><ol><li>RHUS TOX 200 - 3 DRM PILLS</li><li>KALI MUR 6X - 1/2 OUNCE - 3 TDS</li><li>BELL 1M - 2DOSE -SOS</li><li>BAPTISIA Q+ EUPATORIUM Q = 10ML</li></ol>','2022-06-11 00:00:00'),(177,182,_binary '<p>7/6/22</p><p>PAIN IN KNEES</p><p>PAIN IN NAPE OF NECK</p><p>GASTRIC ISSSUES</p><p>HEADACHE AROUND HEAD</p><p>&lt;SOUND,LIGHT</p><p>GASTRIC ISSUES &lt;EMPTY STOMACH</p><p>ALLOPATHIC MEDICINE CAUSES SHIVERING</p><p>MENSES- ABOUT MENARCHE</p><p>SLIGHT SHOW DURING RAMZAN</p><p>COMPLAINTS OF DANDRUFF WHITE SCALES &lt; DURING OIL APPLICATION</p>',_binary '<p>7/6/22</p><ol><li>BRYONIA -Q - 10ML - 10 TDS</li><li>KALI MUR 6X - 1/2 OUNCE - 2 BD</li><li>BRY 1M - 2 DOSE WEEKLY ONCE 1</li></ol>','2022-06-21 00:00:00'),(178,183,_binary '<p>7/6/22</p><p>PAIN IN KNEE JOINTS, RIGHT KNEE</p><p>LIGAMENT TEAR</p><p>NO OTHER HEALTH ISSUES</p>',_binary '<p>7/6/22</p><ol><li>CALC FLUOR 6X+ ARG MET 30 - 1 OUNCE BOTTLE - 3 TDS</li><li>RHUS TOX 1M - 2 DRAM PILLS - 4 TDS</li></ol>','2022-06-21 00:00:00'),(179,184,_binary '<p>8/6/22</p><p>PAIN IN THROAT DOUBTFUL</p><p>FEVER SINCE YESTERDAY NIGHT</p><p>SUDDENLY YESTERDAY HIGH FEVER</p><p>THIRSTY</p><p>PRETERM BIRTH BEFORE 8TH MONTH</p><p>BIRTH WEIGHT = APPROX 2KG</p><p>7/7/22</p><p>FEVERISH,</p><p>COUGH SINCE 3 DAYS, &lt;AT NIGHT AND MORNING</p><p>COUGH WITH EXPECTORATION</p><p>SAYS PAIN IN ABDOMEN NEEDS TO PASS MOTION SOME TIMES</p>',_binary '<p>8/6/22</p><ol><li>BELL 200 2DRAM PILLS</li><li>MERC SOL 30 - 2DRAM PILLS</li><li>PHTOLACCA +BELL Q+ BAPTISIA Q- 10ML- 2 HRLY 6 DROPS</li><li>BELL 1M SOS 4 DOSES</li></ol><p>7/7/22</p><ol><li>HEP SULPH 200 - 2 DRM PILLS</li><li>GRINDELIA Q - 10ML - 10 TDS</li><li>PULSATILLA 200 - 2 DRM PILLS</li></ol>','2022-06-15 00:00:00'),(180,185,_binary '<p>8/6/22</p><p>RECURRANT FEVER WITH RESPIRATORY TRACT INFECTION</p><p>SLIGHT COLD</p><p>NO ASTHMA</p><p>MILE STONES ON TIME NOT DELYAED</p><p>9/6/22</p><p>FEVER SINCE AFTER NOON</p><p>THROAT REDNESS + CONGESTION</p><p>21/6/22</p><p>NEEDS MEDICINE FOR IMMUNITY</p><p>BOWELS - REGULAR</p><p>PERSPIRATION - NS</p><p>DESIRES - FISH NONVEG</p><p>THERMALS - HOT PATIENT</p><p>STUBBORN</p>',_binary '<p>8/6/22</p><ol><li>DULCAMARA 200 - 2 DRAM PILLS - 4 TDS</li><li>ARS IOD 3X - 3 RM TABLETS - 1 TDS</li></ol><p>9/6/22</p><ol><li>BELL 200 - 2 DRM PILLS</li><li>BAPT +BELL + PHYTOLACCA Q - 10ML</li><li>BELL 1M - 4 DOSES- SOS</li><li>PYROGEN 200 1 DRM TABLETS - 1 BD 3 DAYS</li></ol><p>21/6/22</p><ol><li>TUBERCULINUM 1M - 4 DOSE - 2 WEEKLY ONCE FOR BOTH THE CHILD</li><li>IMMUNOVIT SYRUP 5ML BD - FOR BOTH</li><li>IMMUNOVIT SYRUP</li></ol>','2022-06-15 00:00:00'),(181,186,_binary '<p>10/6/22</p><p>MARRIED SINCE 7 YRS</p><p>TAKEN TREATMENT FOR 6 MONTHS FOR INFERTILITY</p><p>MENARCHE - 15 YEARS</p><p>TAKEN TREATMENT FOR GETTING FIRST MENSES</p><p>IRREGULAR CYCLES</p><p>LONG LASTING CYCLES...LASTING FOR AROUND 20 DAYS</p><p>LMP - 16- 5- 22</p><p>PAIN IN ABDOMEN</p><p>BOWELS - REGULAR</p><p>THIRST - LESS</p><p>PERSPIRATION - LESS</p><p>SLEEP - LESS VERY LATE AT NIGHT 12PM</p><p>23/6/22</p><p><span style=\"color: rgb(230, 0, 0);\">MENSES STILL DUE...16/6/22---DATE ON</span></p><p>7/7/22</p><p>MENSES STILL DUE</p><p>MISSED PILLS...WAS NOT REGULAR IN TAKING MEDICINE</p><p>12/7/22</p><p>PERIODS - 11/7/22</p><p>15/7/22</p><p>NEEDS MEDICINE TO CONTINUE</p><p>26/7/22</p><p>NEED PILLS AND BIG TABLETS,,FATHER CAME TO COLLECT</p><p>13/8/22</p><p>LMP - 11/7/22</p><p>NOT GOT STILL</p><p>19/8/22---GOT PERIODS 19/8/22</p><p>29/8/22</p><p>PERIODS LATE BY 8 DAYS</p><p>PERIODS REGULAR BEFORE ALSO WHILE NOT TAKING ANT MEDICINES</p><p>LASTING FOR ,ANY DAYS IS ISSUE NOW</p><p>ALWAYS DOUBTFUL ABOUT TAKING MEDICINE</p><p>FLOW WAS LITTLE MORE FOR FIRST 3 DAYS THIS MONTH</p><p>FEVER WITH THROAT PAIN SINCE 3 DAYS</p><p>NOSE BLOCK SINCE 3 DAYS</p><p>SLIGHT IRRITATION IN THROAT</p><p>HAD DYSMENORRHOEA THIS TIME DURING PERIODS</p><p><br></p><p><br></p><p><br></p>',_binary '<p>10/6/22</p><ol><li>APIS 200 - 2 DRM PILLS - 4 TDS</li><li>OVA TOSTA 3X - 1/2 OUNCE- 3 AT NIGHT</li><li>ASOKA Q - 10ML -10 TDS</li><li>MEDO 10M - 3 DOSE - BD</li></ol><p>23/6/22</p><ol><li>APIS <span style=\"color: rgb(230, 0, 0);\">30 </span>- 2 DRM PILLS - 4 TDS</li><li>OVA TOSTA 3X - 1/2 OUNCE- 3 AT NIGHT</li><li>ASOKA Q - 20ML -10 TDS</li><li>PULS 10M - 3 DOSE BD------3/7/22 MORNING-1NIGHT -1,4/7/22 -MORNING -1</li></ol><p>7/7/22</p><p>APIS 30 - 2DRM PILLS - 4 TDS</p><p>CONTINUE OTHER AS IT ,12/7/22</p><ol><li>1FERRUM PLUS CAPSULES - 10 TABLETS</li><li>CONTINUE ASOKA Q - MORNING ONLY</li><li>OTHERS AS SAME</li></ol><p>15/7/22</p><ol><li>APIS 30 - 2 DRM PILLS - 4 TDS</li><li>B26 - 3 DRM - 1AT NIGHT</li></ol><p>26/7/22</p><ol><li>APIS 30 - 3 DRM PILLS</li><li>B26+ PULS 30 - 1/2 OUNCE - 1 AT NIGHT</li></ol><p>13/8/22</p><ol><li>PULS 10M - 3 DOSE - ON SUNDAYS</li><li>ASOKA Q + PULS Q - 20ML - 10TDS</li><li>APIS 30 - 3 DRM PILLS - 4 TDS</li><li>CARCINOSIN 1M - 1 DOSE SATURDAY NIGHT</li></ol><p>29/8/22</p><ol><li>APIS 30 - 3 DRM PILLS - 4 TDS</li><li>OVA TOSTA 3X - 1/2 OUNCE - 3 AT NIGHT</li><li>ASOKA Q + PULS Q - 20ML - 10 TDS</li><li><br></li></ol>','2022-06-24 00:00:00'),(182,187,_binary '<p>10/6/22</p><p>MOLLUSCUM SINCE 1 YEAR, LOOKS LIKE BLOOD INSIDE</p><p>NO ITCHING</p><p>DISCHARGING NOW</p><p>NOT PAINFUL</p><p>MENSES - REGULAR</p><p>APETITE - GOOD</p><p>DESIRES - PICKLE</p><p>20/6/22</p><p>ITCHING OF MOLLUSCUM RED IN COLOUR</p><p><br></p><p>SINCE 2 DAYS</p><p>5/7/22</p><p>MOLLUSCUM PERSISTING</p><p>WITH BLEEDING</p><p>BURNING ON TOUCHING WATER+</p><p>12/7/22</p><p>PAINFUL NOW MOLLUSCUM</p><p>BLEEDING WITH</p><p>21/7/22</p><p>ERUPTIONS REDUCED IN SIZE</p><p>NO ITCHING OR PAIN NOW</p><p>25/7/22</p><p>COMPLETELY CURED</p><p><br></p>',_binary '<p>10/6/22</p><ol><li>ACID NITRICUM 1M - 2 DOSES BD</li><li>GLYZZERHIA GLABRA WITH HONEY ON FACE -EXTERNALLY</li><li>THUJA 30 - 2 DRM PILLS - 4 TDS</li></ol><p>20/6/22</p><ol><li>THUJA 30 - 2 DRM PILLS- 4 TDS</li><li>SILICEA 1M - 2 DOSE -BD</li><li>BORO ALLEN</li></ol><p>5/7/22</p><ol><li>ACID NITRICUM 1M - 2 DOSE - BD</li><li>SILICEA 30- 2 DRM- 4 TDS</li><li>CALC CARB 200 - 1/2 OUNCE - 3 TDS</li></ol><p>12/7/22</p><ol><li>ACID NITRICUM 1M - 2 DOSE BD</li><li>SILICES 30 - 3PILLS 2 HRLY</li><li>CALC CARB 200 - 3TDS</li></ol><p>21/7/22</p><ol><li>ACID NITRICUM 1M - 2 DOSE</li><li>SILICEA 30 - 2 DRM - 4 QID</li><li>CALC CARB 200 - 4 QID</li></ol><p>25/8/22</p><ol><li>THUJA 1M - 1 DOSE</li></ol><p><br></p><p><br></p><p><br></p>','2022-07-18 00:00:00'),(183,188,_binary '<p>10/6/22</p><p>FEVER SINCE YESTERDAY</p><p>HAD DRENCHED IN RAIN FULL BODY PAIN THROAT PAIN </p><p>O/E THROAT INFECTION WITH WHITE SPOTS</p>',_binary '<p>10/6/22</p><ol><li>RHUS TOX 1M - 1 DOSE</li><li>RHUS TOX 200 2 DRM PILLLS - 4 TDS</li><li>BELLQ + PHYTOLACCA Q - 10ML - 10 DROPS 2 HRLY</li></ol>','2022-06-18 00:00:00'),(184,189,_binary '<p>11/6/22</p><p>PAIN IN RIGHT UPPER QUADRANT SINCE SOME DAYS</p><p>HAD FEVER WITH VOMITING AND THEN LOOSE STOOLS</p><p>NOW TIREDNESS , WEAKNESS,PASSED TWICW YESTERDAY</p><p>GASTRIC DERRANGEMENT</p><p>SENSATION OF FEVERISH</p><p>NO VOMITING</p><p>GAS ISSUES, WITH PAIN PERSISTING</p><p>14/6/22</p><p>FEVERISH SINCE SOME DAYS </p><p>TASTELESS</p><p>HISTORY OF ISSUES WITH SPINAL CORD</p><p>THROAT REDNESS WITH PAIN </p><p><br></p>',_binary '<p>11/6/22</p><ol><li>ARS ALB 200 - 1 DOSE</li><li>ARS ALB 200 - 2 DRM PILLS - 4 TDS</li><li>BAPTISIA + ZINGIBER Q - 10ML - 10 TDS AFTER FOOD</li></ol><p>14/6/22</p><p>REPEAT ABOVE COURSE 2 HRLY </p><p>BELL 200 IN FERRUM PHOS </p><p><br></p><p><br></p>','2022-06-20 00:00:00'),(185,190,_binary '<p>11/6/22</p><p>FEVER SINCE YESTERDAY</p><p>DESIRES HOT WATER</p><p>HAD HEADACHE</p><p>NO LOOSE STOOLS OR VOMITTING</p><p>HEAVINESS OF HEAD</p><p><br></p>',_binary '<p>11/6/22</p><ol><li>BRYONIA 200 - 2DRM PILLS</li><li>BAPTISIA Q- 10ML</li><li>BELL 1M - 4 DOSES SOS</li></ol>','2022-06-16 00:00:00'),(186,191,_binary '<p>11/6/22</p><p>CERVICAL SPONDILITIS SINCE 1 YEAR</p><p>PAIN IN HEELS IN RIGHT SIDE</p><p>MENOPAUSE SINCE 7 MONTHS</p><p>OVARIAN CYST</p><p>&lt;OIL BATH</p><p>LOOKS PALE</p><p>LACK OF SLEEP</p><p>BP -150/90</p><p>28/6/22</p><p>HEEL PAIN MORE SINCE SOME DAYS</p><p>BITTER TASTE IN MOUTH AFTER WAKING UP IN MORNING</p><p>H/0 RENAL CALCULI SURGERY DONE 5 MONTH BACK..ATVRIGHT SIDE</p><p>GASTRITIS....BLOATED SENSATION AFTER EATING FOOD..HEART BURN AT TIMES</p><p>MENOPAUSAL FLUSHES..PALPITATION</p><p>WORKS AS PHYSIOTHERAPIST</p><p>3 CHILDREN - ELDER CHILD DEGREE,2 BOYS 1</p><p>TENSION</p><p>ANXIETY ON GETTING DISEASES AS SHE NEEDS TO TAKE CARE OF ELDER PEOPLE</p><p>NEEDS MEDICINE FOR CHOLESTROL</p><p>DESIRES SUGAR..BP   ------140/90...</p><p><br></p><p><br></p>',_binary '<p>11/6/22</p><ol><li>CAUSTICUM 1M - 2 DOSE</li><li>KALI PHOS 6X - 1/2 OUNCE - 3 TDS + CONIUM 200</li><li>ALLIUM SATIVA Q - 10ML - 10 TDS</li></ol><p>28/6/22</p><ol><li>PULS 10M - 2  DOSE 2 WEEKLY ONCE - 28/6,----12/7/22</li><li>CALC FLUOR - 1/2 OUNCE -3 TDS</li><li>HYDRASTIS Q - 20ML - 10 TDS{CHOLESTROL+GASTRIC ISSUES}</li></ol><p><br></p>','2022-06-25 00:00:00'),(187,192,_binary '<p>11/6/22</p><p>ERUPTIONS WITH ITCHING ON BACK SINCE 4 DAYS</p><p>SLIGHT FEVERISH</p><p>RUNNING NOSE WITH</p><p>COUGH TODAY ONLY</p><p>15/6/22</p><p>FEVER REDUCED</p><p>ITCHING PERSAISTING</p><p>BUT RASHES REDUCED</p><p>18 /6/22</p><p>NO COUGH ,NASAL DISCHARGE YELLOWISH FROM NOSE</p><p>FEVER SINCE DAY BEFORE YESTERDAY</p><p>20/6/22</p><p>DELIVERY .NORMAL</p><p>BIRTH WEIGHT - 2.95KG</p><p>NO HEALTH ISSUES</p><p>SKIN ALLERGY STARTED AT 8 MONTHS...RED RASHES</p><p>PHYSICALS</p><p>DEISRES - HALF BOILED EGG</p><p>MILK - DESIRES, SALTY SOUR FOOD</p><p>AVERSION - SPICY FOOD</p><p>BOWELS - REGULAR DAILY ONCE,AT TIMES CONSTIPATED</p><p>THIRSTLESS</p><p>PERSPIRATION - NS</p><p>THERMALS - HOT</p><p>DESIRES UNDIGESTED FOOD PARTICLES</p><p>MIND</p><p>17/8/22</p><p>COUGH SINCE YESTERDAY</p><p>HAD COLD SINCE SOME DAYS</p><p>NOSE BLOCK WITH EYES WINFLAMMATION</p><p>DRY COUGH WITH</p>',_binary '<p>11/6/22</p><ol><li>PULSATILLA 30 - 2 DRM TABLETS - 2 TDS</li><li>BAPTISIA 3X - 5ML - 5 DROPS - 3 TIMES</li><li>APIS 30 - 1 DRM PILLS - 4 TDS</li><li>PULS 200 - 1 DOSE NOW</li></ol><p>18/6/22</p><ol><li>FAGOPYRUM 30 - 2 DRM PILLS - 3 PILLS 2 HRLY</li><li>PULS 200 - IN KM 6X?</li></ol><p>18/6/22</p><ol><li>PYROGEN 200 - 2 DRM TABLETS - 2 TDS</li><li>BELL 1M - 3 DOSES</li><li>BAPTISIA 3X - 5M - 5 XDROPS 2 HRLY</li></ol><p>20/6/22</p><ol><li>ERYTROFIL SYRUP - 5ML - BD</li><li>CALC CARB 200 - 2 WEEKLY ONCE</li><li>B26 - 1 AT NIGHT - 1 OUNCE TABLETS</li></ol><p>17/8/22</p><p>PULS 1M - 2 DOSE FOLLOWED BY</p><p>BRY 200 2 DRM PILLS 4 PILLS 2 HRLY</p><p>ARALIA +JUSTICIA+ZINGIBER Q - 10ML- 8 DROPS QID</p>','2022-06-14 00:00:00'),(188,193,_binary '<p>11/6/22</p><p>BURNING ERUCTATIONS</p><p>GASTRIC ISSUES</p>',_binary '<p>11/6/22</p><ol><li>NAT PHOS 6X - 3DRM TABLETS -3 TDS</li><li>NUX VOM 30 - 2 DRM PILLS - 4 TDS</li></ol>','2022-08-08 00:00:00'),(189,194,_binary '<p>11/6/22</p><p>HIGHLY OFFENSSIVE SWEAT</p><p>VERY STRICT PARENT SCARED OF FATHER</p><p>BOWELS REGULAR</p><p>SCARED INCIDENT AT CHILDHOOD</p><p>AT CHILDHOOD INCREASED STUBBORN HAUGHTY</p><p>14/7/22</p><p>OFFENSSIVENESS STILL PRESENT</p><p>PERSPIRATION REDUCED NOW</p><p>29/8/22</p><p>PERSPIRATION STILL PERSISTING NO  CHANGE NOW SAME AS BEFORE</p><p><br></p>',_binary '<p>11/6/22</p><ol><li>SILICEA 10M - 1 DOSE</li><li>B26 - 1 OUNCE - 1 BD</li></ol><p>14/7/22</p><ol><li>PSORINUM1 M - 1 DOSE</li><li>B26 - 1OUNCE - 1 BD</li></ol><p>29/8/22</p><ol><li>STAPHYSAGRIA  1M - 2 DOSE BD</li><li>SILICEA 6X - 1 OUNCE 3 TDS</li><li>B26 - 1 AT NIGHT</li></ol>','2022-08-08 00:00:00'),(190,195,_binary '<p>13/6/22</p><p>FEVER SINCE YESTERDAY</p><p>VOMITTED TWICE SINCE MORNING</p><p>HAD COUGH FEW DAYS BACK</p><p>DESIRES FRIED EGG</p><p>NO APETITE FOR ANY KIND OF FOOD</p><p>20/7/22</p><p>FEVER FEW DAYS BACK AT NIGHT</p><p>NOSE BLOCK</p><p>PAIN IN RIGHT EAR</p><p>COUGH SINCE TODAY</p><p>O/E LEFT NASAL POLYP</p><p>NO SNEEZING</p><p>COLD WITH THICK NASAL DISCHARGE</p><p>LOSS OF APETITE</p><p>DOESNT EAT ANYTHING</p><p>BOWELS - REGULAR</p><p>PERSPIRATION - NS</p><p>LONG EYELASHES WITH</p><p>WET COUGH AT TIMES</p><p>22/8/22</p><p>WEAKNESS</p><p>LOSS OF APETITE</p><p>DOESNT EAT ANY THING</p><p><br></p>',_binary '<p>13/6/22</p><ol><li>BAPTISIA 3X - 10ML</li><li>ARS ALB 200 - 2DRM - TDS</li><li>BRY 200 2 DRM PILLS - 3 2 HRLY</li><li>BELL 1M - 3 DSOE - SOS</li></ol><p>20/7/22</p><ol><li>NASAL DROPS</li><li>THUJA 1M - 2DOSES - WEEKLY ONCE</li><li>TEUCRIUM 200 - 2 DRM PILLS - 4 TDS</li><li>HEP SULPH 200 - 2 DRM PILLS</li><li>CHAMOMILLA 1M - 1 DRM PILLS - FOR PAIN</li></ol><p>22/8/22</p><ol><li>ALFALFA TONIC</li><li>CINA 30- 2 DRM TABLETS - 2 BD</li><li><br></li></ol>','0001-01-01 00:00:00'),(191,196,_binary '<p>15/6/22</p><p>FEVER SINCE  3 DAYS</p><p>COUGH SLIGHTLY WITHOUT EXPECTORATION</p>',_binary '<p>15/6/22</p><ol><li>BAPTISIA 3X +BELL Q - 10ML</li><li>BELL 1M - 3 DOSE SOS</li><li>BRYONIA 200 - 2 DRAM PILLS</li></ol>','2022-06-20 00:00:00'),(192,197,_binary '<p>18/6/22</p><p>PAIN IN SHOULDER RIGHT</p><p>BONE GROWTH ON RIGHT FOOT WITH PAIN AT TIMES</p><p>&lt;REST &gt;MOTION</p><p>NUMBNESS IN HANDS AND PAIN IN LEGS</p><p>4/7/22</p><p>PAIN REDUCED</p><p>FEELS BETTER NOW</p><p>ALLERGIC TYPE SNEEZING</p><p>ITCHING ON WRISTS AND ANLES &lt;BATHING AFTER</p><p>WARTS ON HANDS AT TIMES WITH PAIN ON HANDS SINCE 1 YEAR</p><p>27/7/22</p><p>FEELING BETTER </p><p>WARTS ALSO BETTER</p><p><br></p>',_binary '<p>18/6/22</p><ol><li>CAUSTICUM 10M - 2 DOSE WEEKLY ONCE</li><li>RHUS TOX 200 - 2DRM PILLS - 4 TDS</li><li>CALC FLUOR 6X - 1/2 OUNCE - 3 TDS</li></ol><p>DAUGHTER 2296 AYESHA</p><p>4/7/22</p><ol><li>CAUSTICUM 10M - 2 DOSE WEEKLY ONCE</li><li>RHUS TOX 200 - 2DRM PILLS - 4 TDS</li><li>CALC FLUOR 6X - 1/2 OUNCE - 3 TDS</li><li>THUJA 30 - 1/2 OUNCE - 3 BD</li><li>ACIS SALICYLIC 5ML - EA</li></ol><p>27/7/22</p><ol><li>CAUSTICUM 10M - 2 DOSE WEEKLY ONCE</li><li>RHUS TOX 200 - 2DRM PILLS - 4 TDS</li><li>CALC FLUOR 6X - 1/2 OUNCE - 3 TDS</li><li>THUJA 30 - 1/2 OUNCE - 3 BD</li><li>CONTINUE ACID SALICYLIC THEY HAVE</li></ol><p><br></p>','2022-07-02 00:00:00'),(193,198,_binary '<p>18/6/22</p><p>HAD FEVER FEW DAYS BACK</p><p>NOW RUNNING NOSE THICK DISCHARGE.</p><p>COUGH WITH EXPECTORATION</p><p>28/6/22</p><p>COUGH WITH EXPECTORATION</p><p>FEVERISH AT NIGHT</p><p>COUGH AT NIGHT</p><p>NO COLD</p><p>18/8/22</p><p>COUGH SINCE 2 DAYS </p><p>NOSE BLOCKED</p><p>DIFFICULT TO FEED</p>',_binary '<p>18/6/22</p><ol><li>PULS 200 - 2DRM PILLS 4 TDS</li><li>GRINDELIA Q - 10ML - 10 TDS</li><li>BAPTISIA 3X- 5ML - 8 TDS - FEVER</li></ol><p>28/6/22</p><ol><li>GRINDELIA Q - 10ML - 10 TDS</li><li>BAPTISIA 3X - 5ML -</li></ol><p>18/8/22</p><ol><li>BAPTISIA 3X - 5ML - 5 DROPS TDS</li><li>BRY 200 - 2DRM PILLS </li><li>SAMBUCUS 30 - 2 DRM PILLS</li><li>BELL 1M - 4 DOSE SOS</li></ol><p><br></p>','2022-06-25 00:00:00'),(194,199,_binary '<p>20/6/22</p><p>DLEIVERED 61 DAYS BACK</p><p>CRACK ON BREAST SINCE 10 DAYS</p><p>NOT TAKEN ANY MEDICINE</p><p>NO OTHER ISSUES</p><p>MEDICINENOT TAKEN</p><p>22/6/22</p><p>RECURRANT UTI SINCE MARRIAGE</p><p>ALWAYS GETS UTI, NO BURNING</p><p>FEVER YESTERDAY NIGHT</p><p>24/6/22</p><p>FEVER REDUCED</p><p>REQUIRES MEDICINE AS IT GOT CURED</p><p>25/6/22</p><p>CRACK REAPPERED</p><p>FEELS ANGRY TOWARD KIDS</p><p>INCREASING IN SIZE</p><p>REAPPEARING</p><p>DEPRESSION IN ?</p><p>BLEEDING WITH IN RIGHT SIDE</p><p>27/6/22</p><p>SLIGHT THROAT IRRITATION</p><p>NASAL DISCHARGE WITH IRRITATION IN NOSE</p><p>DRY PRICKING COUGH AT NIGHT</p><p>HAD COVID IN LAST AUGUST</p><p>6/7/22</p><p>DRY COUGH &lt; NIGHT</p><p>WHEEZE KIND PRESENT</p><p>ITCHING IN THROAT PRESNT BEFORE COUGH</p><p>&lt; NIGHT, COLD</p><p>THIS COUGH PRESENT AFTER COVID</p><p>20/7/22</p><p>FEVER SINCE YESTERDAY WITH BODY PAIN</p><p>LEG PAIN AFTER PHYSICAL WORK FROM HOME</p><p>GASTRIC ISSUES</p><p>VOMITING TENDENCY WITH</p><p>PAIN IN BODY</p><p>21/7/22</p><p>SEVERE URINE INFECTION</p><p>WITH 65 PUS CELLS, VOMITING TENDENCY</p><p>22/7/22</p><p>PEELING OF SKIN FROM TONGUE WITH SOURNESS OF TEETH</p><p>30/7/22</p><p>TENSION ALWAYS WHEN GETS SICK</p><p>FORGETFUL VERY EASILY</p><p>13/8/22</p><p>URINE INFECTION </p><p>FEVERISH,PUS CELL 45CELLS</p>',_binary '<p>20/6/22</p><ol><li>GRAPH 0/3 - 5 DOSE - 1 AT NIGHT</li><li>BELL 200 - 2 DRM PILLS - 4 TDS</li></ol><p>22/6/22</p><ol><li>PYROGEN 200 - 2DRM PILLS - 4 TDS</li><li>APIS 200 - 2DRM PILLS</li><li>CANTHARIS 200 - 2 DRM PILLS</li></ol><p>24/6/22</p><ol><li>PYROGEN 200 - 2 DRM TABLETS -3 BD</li></ol><p>25/6/22</p><ol><li>BOROALLEN</li><li>ACID NITRICUM 1M - 2DOSE</li></ol><p>27/6/22</p><ol><li>BRY 1M - 2 DOSE BD</li><li>BRY 200</li><li>BAPTISIA 3X - 10ML - 10 TDS</li></ol><p>=PYROGEN - BD - TILL 29TH</p><p>=BELL 200 -TO COMPLETE</p><p>6/7/22</p><ol><li>DROSERA Q + ARALIA Q - 10ML - 10 QID</li><li>RUMEX -200 - 2 DRM PILLS- 4 QID</li></ol><p>20/7/22</p><ol><li>PULS 200 ALTERNATE WITH</li><li>GELS 200 2 DRM PILLS</li><li>BELL 1M - 3 DOSE SOS</li><li>EUPATORIUM Q - 10ML - 10 QID</li></ol><p>21/7/22</p><ol><li>PYROGEN 200 - 2 DRM TABLETS - 1QID</li><li>APIS 30 - 2 DRM PILLS - ALTERNATE</li><li>CANTHARIS 30 2DRM PILLS</li><li>UVA URSI Q - 10ML - 10 TDS</li></ol><p>22/7/22</p><ol><li>NAT MUR 200 - 1 DOSE</li></ol><p>30/7/22</p><ol><li>NAT MUR 10M - 1 DOSE</li></ol><p>13/8/22</p><ol><li>PYROGEN 200 - 3DRM TABLETS - 3 TDS</li><li>UVA URSI Q - 20ML - 10 DROPS 2 HRLY</li><li>CANTHARIS 30 - 2 DRM PILLS</li><li>APIS 30 -2 DRM PILLS</li></ol>','2022-06-25 00:00:00'),(195,200,_binary '<p>21/6/22</p><p>RING WORM</p><p><br></p>',_binary '<p>21/6/22</p><ol><li>BACILLINUM 1OM - 4 DOSE WEEKLY ONCE</li><li>SEPIA 30 - 1/2 OUNCE - 3TDS</li><li>CHRYSORBINUM</li></ol>','0001-01-01 00:00:00'),(196,201,_binary '<p>21/6/22</p><p>FEVER SINCE MORNING</p><p>PAIN IN EYES</p><p>THIRSTLESS</p><p>4/7/22</p><p>HEADACHE </p><p>FEVER SINCE AFTERNOON</p><p>HEADACHE WITH</p><p><br></p>',_binary '<p>21/6/22</p><ol><li>BELL 200- 2 DRM PILLS</li><li>RHUSTOX 200 - 2 DRAM PILLS</li><li>BELL 1M SOS - 4 DOSE</li><li>BAPTISIA Q = 5ML - 10 DROPS TDS</li></ol><p>4/7/22</p><ol><li>BELL 200 - 2 DRM PILLS</li><li>BRY 200 - 2 DRM PILLS ALTERNATE WITH</li></ol>','0001-01-01 00:00:00'),(197,202,_binary '<p>21/6/22</p><p>ALLERGIC RHINITIS</p><p>SENSITIVE NOSE</p><p>&gt;CLOSED ROOM ,,&lt;OPEN AIR</p><p>ITCHING IN NOSE</p><p>STARTS AS ITCHING IN THROAT+++</p><p>&lt;DUST</p><p>SNEEZING VERY SEVERE</p><p>NO OTHER HEALTH</p><p>ITCHING IN TIP OF NOSE</p><p>SENSITIVE NOSE</p>',_binary '<p>21/6/22</p><ol><li>ARS ALB 30 - 2 DRM PILLS</li><li>POTHOS Q+ SABADILLA Q - 20ML - 10 TDS</li><li>PULS 200 - 2 DOSE WEEKLY ONCE</li></ol>','2022-08-08 00:00:00'),(198,203,_binary '<p>21/6/22</p><p>BROWN SPOTS ON LIPS</p><p>NO ITCHING OR SWELLING</p><p>MENSES REGULAR</p><p>CSECTION DELIVERIES 2 - NOT DIALTED</p><p>NO OTHER HEALTH ISSUES</p>',_binary '<p>21/6/22</p><ol><li>SEPIA 200 - 4 DOSE WEEKLY ONCE</li></ol><p><br></p><p><br></p>','2022-07-05 00:00:00'),(199,204,_binary '<p>21/6/22</p><p>ITCHING DANDRUFF</p><p>WHITE POWDERY</p><p>ITCHING LEADS TO BLEEDING</p><p>BLEEDING SCABS</p><p>BOWELS CONSTIPATED</p><p>USED TO PASS WEEKLY ONCE ONLY BEFORE NOW NOT MUCH CONSTIPATED</p><p>THIRSTLESS</p><p>MILK LIKES</p><p>EGG LIKES</p>',_binary '<p>21/6/22</p><ol><li>ACID NITRICUM 1M - 2 DOSE</li><li>KALI MUR 6X - 1/2 OUNCE -</li></ol>','2022-08-08 00:00:00'),(200,205,_binary '<p>21/6/22</p><p>IRREGULAR MENSES</p><p>TENSION PALPITATION</p><p>BP - 150/90</p><p>HEADACHE MIGRAINE TYPE,</p><p>WEAKNESS</p><p>BALANCE PROBLEM</p>',_binary '<p>21/6/22</p><ol><li>NAT MUR 6X - 1 OUNCE - 3TDS</li><li>IGNATIA 1M - 4 DOSE BD - WEEKLY</li><li>SANGUINARIA Q - 30ML - 10 DROPS 2 HRLY SOS</li><li>BRY 200 - 2 DRM PILLS - 4 PILLS 2 HRLY SOS HEADACHE</li></ol>','0001-01-01 00:00:00'),(201,206,_binary '<p>22/6/22</p><p>DESIRES TEA .DRINKS AROUND 10 OR TEA</p><p>THIRSTLESS</p><p>PERSPIRATION</p><p>LIKES PLAYING FOOTBALL</p><p>STRESSFUL JOB</p><p>DIABETES</p>',_binary '<p>22/6/22</p><ol><li>NUX VOM 1M - 8DOSE [BD WEEKLY ONCE FOR 4 WEEKS]</li><li>CEPHALANDRA Q - 20ML - 10 TDS A/F</li><li>NAT SULPH 6X - 1 OUNCE - 4 TAB 3 TIMES BEFORE FOOD</li></ol>','2022-08-08 00:00:00'),(202,207,_binary '<p>23/6/22</p><p>MIGRAINE SINCE 15YRS AGE</p><p>NOT WELL SINCE TAKING HOMOEO MEDICINES</p><p>NOT &gt;BY SLEEP OR VOMITING NOW</p><p>NOT GETTING RELIEF WITH ANYTHING MEDICINES NOW</p><p>NO TENSIONS NOW</p><p>DIFFICULT PHLEGM ,DOESNT COME UP EASILY</p><p>25/6/22</p><p>HAD PHONED SEVERE HEADACHE NOT ABLE TO TOLERATE WITH GASTRIC ISSUES</p>',_binary '<p>23/6/22</p><p><br></p><ol><li>NAT MUR 10M - 1 DOSE</li><li>BRYONIA - 200 - 2 DRM PILLS SOS 2 HRLY</li><li>TUBERCULINUM 10M - 1 DOSE SOS START WITH HEADACHE</li><li>KALI BICH 6X - 1/2 OUNCE - 2 TDS</li><li>SANGUINARIA Q - 20ML - 10 DROPS QID</li></ol><p>25/6/22</p><p>ALREADY TAKEN TUB 10 1 DOSE AND SANG Q AND BRY 200 2 HRLY WITHOUT RELIEF</p><ol><li>IRIS VERS 200 - 2 DRM PILLS - 4 PILLS 2 HRLY.....NTPD</li></ol>','2022-07-07 00:00:00'),(203,208,_binary '<p>23/6/22</p><p>FEVER SINCE AFTERNOON</p><p>HAD COLD AND COUGH SINCE  1 WEEK</p><p>HAD DRENCHED IN RAIN</p><p>LIKES RAIN MUD PLAYING</p><p>WEEPS EASILY DURING FEVER</p><p><br></p><p><br></p>',_binary '<p>23/6/22</p><ol><li>PULS 200 - 1 DOSE NOW</li><li>BELL 200 - 2 DRM PILLS</li><li>RHUS TOX - 200 - 2 DRM PILLS 2 HRLY</li><li>BELL 1M - 3 DOSE SOS</li></ol><p><br></p>','2022-06-30 00:00:00'),(204,209,_binary '<p>25/6/22</p><p>COUGH SINCE 2- 3DAYS</p><p>COLD SINCE 1 DAYS</p><p>CRYING ALWAYS SINCE 2 DAYS</p><p>DOUBTFUL OF UTI</p><p>?PAINFUL MICTURITION</p><p>BIRTH WEIGHT = 2.400</p><p>3 MONTHS NOW</p><p>COUGH SHORT DRY PRICKING TYPE COUGH</p><p>18/8/22</p><p>INTERTRIGO</p><p>AROUND THIGHS</p><p>BACK OF LEGS</p><p><br></p><p><br></p>',_binary '<p>25/6/22</p><ol><li>IPECAC 3X- 2 DRM PILLS - 3QID</li><li>CHAMOMILLA - 200 - 1 DRM PILLS - 3QID</li></ol><p><br></p><p>GIVE 1 AND 2 ALTERNATE EVERY 2 HRLY, REVIEW ON TUESDAY</p><p>18/8/22</p><ol><li>ACID NITRICUM 1M - 2 DOSE</li></ol><p><br></p>','2022-06-28 00:00:00'),(205,210,_binary '<p>25/6/22</p><p>C/O NASAL POLYP SINCE 7TH STANDARD LONG BACK</p><p>SNEEZING &lt;WASHING COLD DUST</p><p>SNEEZING, COUGH THEN WHEEZING</p><p>C- SECTION BABY WEIGHT WAS MORE</p><p>H/0 CRACKS ON HEEL</p><p>MIGRAINE RARELY SOME TIMES...NOT SO SEVERE NOW..ONLY ONCE</p><p>ITCHING IN SIDES OF THIGHS WITH DRY SKIN</p><p>19/8/22</p><p>VOMITTED ONCE SINCE MORNING</p><p>GASTRIC ISSUES BEFORE ALSO</p><p>AROUND UMBILICUS</p><p>ITCHING IN THIGHS PERSISTING</p><p>31/8/22</p><p>ALLERGIC COMPLAINTS SLIGHT RELIEF</p><p>PAIN IN ABDOMEN REDUCED BUT STILL COMES AT SOME TIMES</p><p><br></p>',_binary '<p>25/6/22</p><ol><li>LEMNA MINOR + POTHOSQ -20ML- 10 TDS</li><li>THUJA 200 - 2 DOSE WEEKLY ONCE</li><li>ARS ALB 3X - IN 2 DRM PILLS - 4 TDS</li></ol><p>19/8/22</p><ol><li>ZINGIBER TINCTURE 10ML - 10 TDS</li><li>NUX VOM 30 - 2 DRM PILLS</li></ol><p>31/8/22</p><ol><li>NUX VOM 1M - 2 DOSE WEEKLY ONCE</li><li>NUX VOM 30 - 2 DRM PILLS - 4 TDS</li><li>ZINGIBER Q -10ML - 10 TDS</li><li>NAT PHOS 6X - 1/2 OUNCE - 3 BD</li></ol>','2022-08-08 00:00:00'),(206,211,_binary '<p>25/6/22</p><p>FEVER SINCE 2 DAYS</p><p>COUGH SINCE 2-3 DAYS</p><p>C/O ALLERGIC COUGH</p>',_binary '<p>25/6/22</p><ol><li>BRYONIA 200 - 2DRM PILLS</li><li>BELL 200 - 2 DRM PILLS ALTERNATE 2 HRLY</li><li>BELL 1M 3 DOSE SOS</li></ol>','2022-08-08 00:00:00'),(207,212,_binary '<p>26/6/22</p><p>ERUPTIONS IN MOUTH</p><p>FEVER SINCE YESTERDAY</p><p>WEAKNESS</p><p>VIRAL FEVER,BODY PAINWITH</p><p>SLIGHT THROAT PAIN</p>',_binary '<p>26/6/22</p><ol><li>BRYONIA 200 - 2 DRM PILLS - 4 PILLS 2 HRLY</li><li>BELL 200 - 2 DRM - 4 PILLS 2 HRLY</li><li>BAPTISIA Q - 10ML</li><li>BELL 1M - 3 DOSES</li></ol>','0001-01-01 00:00:00'),(208,164,_binary '<p>24/5/22</p><p>DIFFICULTY IN ERECTION</p><p>VERY SLIGHT </p><p>UNABLE TO PERFORM AS REQUIRED</p><p>DIABETES UNDER CONTROL</p><p>THYROID PATIENT</p><p>UNDER </p><p>VITILIGO AFTER  SINCE SOME YEARS</p><p>27/6/22</p><p>FELT SLIGHT DIFFERNCE WHILE TAKING MEDICINE</p><p>GASTRIC ISSUES...AFTER EATING AT NIGHT</p><p>ERUCTATIONS</p><p>BOWELS - REGULAR</p><p>DESIRES - SWEETS</p><p><br></p><p><br></p><p><br></p>',_binary '<p>24/5/22</p><ol><li>AVENA SATIVA Q- 30ML</li></ol><p>27/6/22</p><ol><li>DAMIANA Q -20ML - 15 BD</li><li>KALI PHOS 6X - 1/2 OUNCE 3TDS</li><li>LYCO 1M - 1/2 DRM 4 TABLETS - 2 TAB WEEKLY ONCE</li></ol>','2022-07-11 00:00:00'),(209,213,_binary '<p>27/6/22</p><p>DIAPER RASH</p><p>SINCE 1 WEEK</p><p>REDNESS</p><p>16/8/22</p><p>NOSE BLOCK </p><p>EYES ARE RED WITH WAYERY NASAL DISCHARGE</p><p>SLIGHT RATTLING</p><p><br></p>',_binary '<p>27/6/22</p><ol><li>MERC SOL 200 - 2 DOSE BD</li><li>BORO ALLEN - CREAM</li></ol><p>16/8/22</p><ol><li>PULS 200 - IN 5ML - 1 DROP IN 1 SPOON WATER QID</li><li>SAMBUCUS 30 - 5 ML- 1 DROP IN 1 SPOON WATER QID</li></ol>','2022-06-27 00:00:00'),(210,214,_binary '<p>2/7/22</p><p>FEVER ONE WEEK BACK WITH COUGH WITH EXPECTORATION</p><p>NOW AGAIN FEVER SINCE YESTERDAY</p><p>COUGH WITH EXPECTORATION</p><p>O/E CHEST CLEAR</p><p>THROAT SLIGHTLY RED</p><p>&lt;MILK DISAGREES - CAUSES DIARRHOEA</p>',_binary '<p>2/7/22</p><ol><li>BRY 200 - 2 DRM PILLS</li><li>BELL 200 - 2 DRM PILLS</li><li>BAPTISIS Q - 5 ML - 6 DROPS - 4 TIMES</li><li>BELL - 1M - 3 DOSES</li></ol>','0001-01-01 00:00:00'),(211,215,_binary '<p>2/7/22</p><p>THROAT INFECTION AT LEFT SIDE</p><p>FEVERISH</p><p>PAIN AND COUGH WITH</p><p>HISTORY OF INTAKE ICE CREAM</p><p>12/7/22</p><p>FEVER SINCE YESTERDAY NIGHT</p><p>BOWELS CONSTIPATED NOW</p><p>STOMACH PAIN ..SAYS ALWAYS</p><p>NAUSEATING</p>',_binary '<p>2/7/22</p><ol><li>BELL 200</li><li>PHYTOLACCA + BELL Q - 10ML</li><li>HEPAR SULPH 200</li><li>BELL 1M -3DOSES</li></ol><p>12/7/22</p><ol><li>BRY 200 ALTERNATE WITH</li><li>BELL 200 2 DRM PILLS</li><li>BELL 1M - 4 DOSES SOS</li><li>PYRIGEN 200 - 2 DRM BILLS - 4 TDS</li></ol>','0001-01-01 00:00:00'),(213,217,_binary '<p>5/7/22</p><p>FEVER FEW DAYS BACK</p><p>COUGH</p><p>HISTORY OF HOSPITAL ADMISSION AT 2 YEARS ? LOW COUNT, RATTLING</p><p>HAD COLD SINCE 2 WEEKS</p><p>TAKEN MEDICINES BUT STARTED AGAIN</p><p>COUGH &lt; NIGHT LYING DOWN AFTER</p><p>&lt;MORNING</p><p>O/E TONGUE CLEAN</p><p>CHEST - NS</p><p>9/7/22</p><p>DRY COUGH AT NIGHT ON LYING DOWN</p><p>NOSE BBLOCK AT NIGHT</p><p>LOSS OF APETITE</p><p>25/7/22</p><p>FEVER AT NIGHT</p><p>INTERMITANT FEVER</p><p>NOSE BLOCK AT NIGHT,THICK DISCHARGE AT NIGHT</p><p>COUGH ALSO, COUGH ENDS IN VOMITING</p>',_binary '<p>5/7/22</p><ol><li>IPECAC 3X IN 2 DRM PILLS - 4 PILLS 2HRLY</li><li>GRINDELIA Q - 10ML - 10 DROPS QID</li></ol><p>9/7/22</p><ol><li>DROSERA 1M - 2DRM PILLS-</li><li>HEP SULPH - 200 2 DRM PILLS - 4 TDS</li></ol><p>25/7/22</p><ol><li>DROSERA 1M - 2DRM PILLS-</li><li>HEP SULPH - 200 2 DRM PILLS - 4 TD</li></ol><p><br></p>','0001-01-01 00:00:00'),(214,218,_binary '<p>5/7/22</p><p>FEVER ALWAYS,SINCE 5 MONTHS</p><p>WEAKNESS</p><p>NO VOMITING OR DIARRHEA</p><p>RIGHT LYMPH NODE ENLARGED</p><p>ADVICE BLOOD TESTS AND REPORT</p><p>CBC,CRP,ESR,SPUTUM CULTURE</p><p>URINE R/E,THYROID FUNCTION TESTS</p><p>16/7/22</p><p>FEVER WAS NOT THERE SINCE LAST VISIT</p><p>HEADACHE IN TEMPORAL REGION</p><p>YELLOWISH PHLEGM IN THROAT DIFFICULT TO DETACH</p><p>THROAT PAIN WITH</p><p>?SINUSITIS, ?HESADACHE DUE TO EYE STRAIN</p><p>IS HEADACHE ,</p><p>MIGRAINE ?TENCENCY TO</p><p>LOSS OF SLEEP</p>',_binary '<p>5/7/22</p><ol><li>-PYROGEN 200 - 2 DRM PILLS-</li></ol><p>16/7/22</p><ol><li>PYROGEN 200 - CONTINUEBAS 3 BD..THEY HAVE</li><li>SANGUINARIA Q - 20ML - 10 TDS</li><li>NAT MUR 10M - 1 DOSE STAT</li><li>BRY 200 - SOS 4 2 HRLY</li><li>BELL + PHYTOLACCA Q - 10M - 10 QID</li></ol>','2022-07-09 00:00:00'),(215,219,_binary '<p>6/7/22</p><p>COUGH SINCE 10 DAYS</p><p>DRY COUGH AFTER FEVER</p><p>WHEEZING AT TIMES</p><p>&lt; NIGHT</p><p>AFTER FEVER, SLIGHT</p>',_binary '<p>6/7/22</p><ol><li>INFLUENZINUM 200 - 2DRM PILLS ALTERNATE</li><li>SANG NIT 200 - 2 DRM PILLS</li><li>DROSERA 1M - 10ML - 10 TDS</li></ol>','0001-01-01 00:00:00'),(216,220,_binary '<p>6/7/22</p><p>APETITE REDUCED</p><p>SLEEP DISTURBED</p><p>MENSES- AMENORRHOEA</p><p>MENTAL TENSION CAUSES NOSE BLEEDING</p><p>FATIGUE AT TIMES</p><p>ANGER ++</p><p>GO BEHIND....</p><p>HISTORY OF MOTHER SUICIDE ....FASTIDIUO+++</p><p>POST PARTUM DEPRESSION</p><p>WENT AWAY FROM HOME-...DUE TO LOVE AFFAIR</p><p>FINANCIALLY AND CASTE WISE SHE WENT WITH A LOW CLASS PERSON</p><p>SCHEZOPHRENIA IN FAMILY</p><p>WEIGHT LOSS SINCE SINCE 6 MONTHS</p><p>45KG NOW</p><p>29/8/22</p><p> JULY 20 </p><p>AUGUST 2...</p><p>TWICE PERIODS IN LAST MONTH</p><p>GASTRIC ISSUES WITH BURNING ERUCTATIONS</p><p>NASAL BLEEDING DURING STRESS</p><p>H/0 MIGRAINE BEFORE ALSO</p><p>GASTRIC ISSUES MORE EMPTY STOMACH</p><p>BURNING IN STOMACH</p><p>LEUCORRHOEA NOW DAYS THICK DISCHARGE WHITE IN CLR</p><p>BREAST PAIN</p><p><br></p><p><br></p>',_binary '<p><br></p><p>6/7/22</p><ol><li>STAPYSAGRIA 1M - 1 DOSE</li><li>KALI PHOS - 6X - 2 AT NIGHT</li></ol><p>29/8/22</p><ol><li>NAT MUR 10M - 1 DOSE</li><li>IRIS VERS 200 - 2 DRM PILLS ALTERNATE</li><li>BRY 200 - 2 DRM PILLS</li><li>ZINGIBER 10ML - 10TDS- AFTER FOOD</li></ol>','2022-08-08 00:00:00'),(217,221,_binary '<p>6/7/22</p><p>HAD FEVER AND COUGH GIVEN ANTIBIOTICS</p><p>SEVERE SNEEZING, NOW</p><p>AT NIGHT DIFFICULT BREATHING DUE TO NASAL DROPS</p><p>WEAKNESS AFTER FEVER,</p><p>LOSS OF APETITE</p><p>BOWELS - REGULAR</p><p>THIRTLESS</p>',_binary '<p>6/7/22</p><ol><li>DULCAMARA 200 - 2 DRM PILLS Q 4 AID</li><li>NASAL DROPS</li><li>EUCALYPTUS Q - 10ML - 10 TDS</li><li>PULS 200 - 2 DRM PILLS- 4 QID</li><li>INFLUENZINUM 200 - 1 DOSE</li><li>IMMUNE SYRUP GIVEN</li></ol>','2022-08-08 00:00:00'),(218,222,_binary '<p>6/7/22</p><p>COLD WATERY NASAL DISCHARGE</p><p>COUGH AT TIMES</p><p>HISTORY OF FEVR WITH RATTLING</p><p>DONE NEBULISATION</p><p>NO HISTORY ADMISSION</p><p>BOWELS - REGULAR</p><p>DESIRES FISH</p><p>CURLY HAIR</p>',_binary '<p>6/7/22</p><ol><li>DULCAMARA - 200 - 2 DRM</li><li>PULS- 200 - 2 DRM PILLS</li></ol><p>4 TIMES 4 PLLS</p>','0001-01-01 00:00:00'),(219,223,_binary '<p>8/7/22</p><p>FEVER FEW DAYS BACK </p><p>EVENING RISE OF TEMPERATURE</p><p>APETITE GOOD</p><p>NO COLD AND COUGH NOW</p><p>SLIGHT THROAT INFECTION FELT WHILE PALPATING</p><p>IRRITATION IN THROAT</p><p>SWEATS ON HEAD</p><p>DESIRES NON VEG</p><p><br></p><p><br></p>',_binary '<p>8/7/22</p><ol><li>PYROGEN 30 - 1 DRM TABLETS</li><li>BELL 200- 4 TDS</li><li>RHUSTOX 200- 4 QID</li><li>BELL 1M - 4 DOSE</li></ol>','0001-01-01 00:00:00'),(220,224,_binary '<p>8/7/22</p><p>BURNING INDSIDE STOMACH SINCE SOME DAYS</p><p>VOMITING TENDENCY WHILE EATING</p><p>NAUSEATING</p><p>SOUR ERUCTATION</p><p>EARLY MORNING 3AM DISTRESS IN STOMACH</p><p>INDIGESESTED FOOD PARTICLES IN STOOLS</p><p>DIABETES</p><p>HEAVY MEALS CAUSING DIFFICULTY ESPECIALLY OILY</p><p><br></p><p><br></p><p><br></p><p><br></p>',_binary '<p>8/7/22</p><ol><li>NAT PHOS 6X - 1/2 OUNCE - 3 TDS</li><li>ZINGIBER Q -10ML - </li><li><br></li></ol>','0001-01-01 00:00:00'),(221,225,_binary '<p>12/7/22</p><p>FEVER 5-6 DAYS BACK</p><p>COLD WITH COUGH</p><p>COUGH WITH EXPECTORATION</p><p>NOSE BLOCKED</p><p>APETITE - GOOD</p><p>BOWELS - REGULAR</p><p>NO FEVER NOW</p><p>GIVEN 2 CRSE ANTIBIOTIC</p><p>TONGUE CLEAR</p><p>19/7/22</p><p>NOSE BLOCKED </p><p>FEVER SINCE YESTERDAY..TAKING PARACETAMOL</p><p>COUGH WITH EXPOECTORATION PERSISTING</p><p>TONGUE CLEAN</p><p><br></p><p><br></p>',_binary '<p>12/7/22</p><ol><li>ANT TART 10M - 3 DOSE- DIVIDED IN 3 SPOON WATER 3 TIMES A DAY</li><li>GRINDELIA Q - 20ML - 10 TDS</li><li>1P2CAC 3X - 3 DRM PILLS</li></ol><p>19/7/22</p><ol><li>PYROGEN 200 - 2 DRM TABLETS -2 TDS </li><li>BEL 1M - SOS - 4 DOSE</li><li>PULS 200 - 3 PILLS 2 HRLY</li></ol><p><br></p>','0001-01-01 00:00:00'),(222,226,_binary '<p>12/7/22</p><p>ALERGIC TENDENCY</p><p>COUGH AT TIMES</p><p>SNEEZING AT MORNING</p><p>RUNNING NOSE WATERY </p><p>COUGH WITH RALLTING AT TIMES</p><p><br></p>',_binary '<p>12/7/22</p><ol><li>NUX VOM+ AMMON CARB 200 -N 3 DRM PILLS</li><li>PULS 1M - DOSE WEEKLY ONCE</li><li>POTHOS + SABADILLA Q- 20ML - 10 TDS</li></ol><p><br></p>','0001-01-01 00:00:00'),(223,227,_binary '<p>12/7/22</p><p>SNEEZING MORE DUST</p><p>GASTRITIS</p><p>MOSQUITIO BITE ALLERGY</p><p>GASTRIC ISSUES</p><p>BOWELS - REGULAR</p><p>MILK - DISLIKES</p><p>VOMITING TENDENCY</p><p>28/7/22</p><p>SNEEZING SINCE SOME DAYS</p><p>NOSE BLOCK AT EVENING</p><p>NASAL OBSTRUCTION</p><p>NEEDS MEDICINE FOR 2 WEEKS</p><p>24/8/22</p><p>NEEDS MEDICINE FOR ALLERGY</p><p>WAS BETTER WITRH GIVEN MEDICINE</p>',_binary '<p>12/7/22</p><ol><li>CRACINOSIN - 200 - 3 DOSE</li><li>ARS ALB 3X 3 DRM PILLS -4 TDS</li><li>POTHOS + SABADILLA - 20 ML - 10 TDS</li></ol><p>28/7/22</p><ol><li>ARS ALB 3X 3 DRM PILLS -4 TDS</li><li>POTHOS + SABADILLA - 20 ML - 10 TDS</li></ol><p>24/8/22</p><ol><li>ARS ALB 3X 3 DRM PILLS -4 TDS</li><li>POTHOS + SABADILLA - 20 ML - 10 TDS</li><li>LYSSIN 200 - 2 DOSE</li></ol>','0001-01-01 00:00:00'),(224,228,_binary '<p>12/7/22</p><p>NEEDS MEDICINE FOR IMMUNITY</p><p>FEELS CONGESTION IN CHEST</p><p>TENDENCY TO WHEEZING</p><p>TONSILLITIS</p><p>24/8/22</p><p>NEEDS MEDICINE</p>',_binary '<p>12/7/22</p><ol><li>TUBERCULINUM 1M - 3 DOSE WEEKLY ONCE</li><li>ECHINACEA Q - 20ML - 10 TDS</li><li>B26 - 1 OUNCE - 1 BD</li></ol><p>28/7/22</p><ol><li>TUBERCULINUM 1M - 2 DOSE WEEKLY</li><li>ECHINACEA Q - 20ML - 10 TDS</li></ol><p>24/8/22</p><ol><li>TUBERCULINUM 1M - 2 DOSE WEEKLY</li><li>ECHINACEA Q - 20ML - 10 TDS</li><li>B26 - 1 OUNCE BD</li></ol>','0001-01-01 00:00:00'),(225,229,_binary '<p>12/7/22</p><p>RECURRANT FEVER</p><p>COUGH WITH EXPECTORATION</p><p>THROAT PAIN</p><p>COUGH MORE AT AFTERNOON FROM 4 PM - TILL SUNSET</p><p>HISTORY OF BALA TB</p><p>CONTIONOUS COUGH WITH</p><p>REDNESS IN THROAT WITH PAINFUL</p><p>APETITE LOW</p><p>BOWELS NOT SO REGULAR</p><p>PERSPIRATION NS</p><p>20/7/22</p><p>NO FEVER AFTER THAT</p><p>COUGH AT TIMES</p><p>NO COLD NOW</p><p>SLIGHT COUGH WITH PHLEGM PRESENT NOW</p><p>WEAKNESS</p><p>BOWELS REGULAR NOW</p>',_binary '<p>12/7/22</p><ol><li>PYROGEN 1 DRM PILLS - 4 BD</li><li>GRINDELIA Q - 20ML - 10 TDS</li><li>HEP SULPH 200 - 2DRM PILLS - 4QID</li><li>BELL 1M - 4 DOSE SOS</li><li>ERYTROFIL SYRUP</li></ol><p>20/7/22</p><ol><li>TUBERCULINUM 1M - IN 10 DAYS ONCE - 20/7, 30/7</li><li>HEP SULPH 200 - 2 DRM PILLS - 4 BD AFTER FOOD</li><li>BRY 200 2 DRM PILLS - 4 BD BEFORE FOOD</li><li>FOR 10 DAYS</li></ol>','2022-08-08 00:00:00'),(226,230,_binary '<p>12/7/22</p><p>EXTREMELY DRY SKIN</p><p>BLACKISH SPOTS</p><p>WEAK UTERUS .....HAD TAKEN STITCHES IN PREGNANCY</p><p>MENSES NOT SO REGULAR</p><p>CYCLES IN 25- 28 DAYS</p><p>BLEEDING FOR SOME DAYS</p><p>LEUCORRHOEA AT TIMES</p><p>BOWELS - REGULAR</p><p>PERSPIRATION - LESS</p><p>DESIRES SOUR SPICES</p><p><br></p><p><br></p>',_binary '<p>12/7/22</p><ol><li>SEPIA 1M - 4 DOSE WEEKLY ONCE</li><li>SARCREAM- 1</li><li>KALI MUR 6X - 1 OUNCE - 3 TDS</li></ol>','2022-08-08 00:00:00'),(227,231,_binary '<p>12/7/22</p><p>CHIKEN POX</p>',_binary '<p>12/7/22</p><p>FERR PHOS 1M - 1 DOSE NOW</p><p>EUPATORIUM + BAPTISIA Q - 20ML - 15 DROPS 2 HRLY</p><p>RHUS TOX 200 - 2 DRM PILLS 2 HRLY</p>','0001-01-01 00:00:00'),(228,232,_binary '<p>13/7/22</p><p>HAD SLIGHT FEVER FEW DAYS</p><p>BIRTH WEIGHT - 2.4 KG</p><p>THIRD CHILD OF MOTHER</p><p>NOW WEIGHT - 5KG</p><p>CRYING AT NIGHT AFTER SLEEPING</p><p>RATTLING , NOSE BLOCK,</p><p>VOMITING MILK AS IT IS AFTER FEEDING</p>',_binary '<p>N13/7/22</p><ol><li>NASAL DROPS</li><li>PULS 200 - 2 DRM PILLS - 3 TDS</li><li>SAMBUCUS 30 - 2 DRM PILLS - 3 TDS</li></ol>','0001-01-01 00:00:00'),(229,233,_binary '<p>13/7/22</p><p>COUGH AFTER FEVER </p><p>COUGH  AT NIGHT MORE</p><p>ITHCING IN THROAT STARTS WITH</p><p>COUGH WITH EXPECTORATION</p><p>SLIGHT THROAT PAIN WITH</p><p><br></p>',_binary '<p>13/7/22</p><ol><li>RUMEX 200 - 1/2 OUNCE TABLETS - 3 TDS</li><li>GRINDELIA Q - 20ML - 10 TDS</li></ol>','0001-01-01 00:00:00'),(230,234,_binary '<p>13/7/22</p><p>FEVER SINCE 1 WEEK </p><p>COLD AND COUGH WITH EXPECTORATION</p><p>RECURRANT FEVER </p><p>THICK NASAL DISCHARGE</p><p>COUGH WHICH ENDS IN VOMITTING</p><p><br></p>',_binary '<p>13/7/22</p><ol><li>PULS 200 - 2DRM PILLS </li><li>COCCUS CACTI 200 - 2 DRM PILLS</li><li>PYROGEN 200 - 1 DRM TABLETS</li><li>BELL 1M SOS</li></ol><p>FOR SISTER 1.2 YRS</p><ol><li>PULS 200 - 1 DRM PILLS - 3 PILLS QID</li><li>ANT TART 6C - 1 DRM PILLS - 3PILLS QID </li></ol>','0001-01-01 00:00:00'),(231,235,_binary '<p>13/7/22</p><p>FEVER RECURRANT TYPE</p><p>THICK NASAL DISCHARGE</p><p>COUGH WITH EXPECTORATION</p><p>FEVER  ALWAYS PRESENT</p><p>NOT GETTING RELIEF</p>',_binary '<p>13/7/22</p><ol><li>PULS 200 - 2DRM PILLS ALTERNATE WITH</li><li>BELL 200 - 2 DRM PILLS</li><li>BELL 1M - 3 DOSES</li><li>PYROGEN 200 - 2 DRM TABLETS - 3BD</li></ol>','0001-01-01 00:00:00'),(232,236,_binary '<p>14/7/22</p><p>COUGH AFTER COVID SINCE 6 MONTHS</p><p>AT TIMES COUGH WITH EXPECTORATION</p><p>AT TIMES DRY</p><p>NO ALLERGIC ISSUES</p><p>&lt;FROM COLD FOOD</p><p>O/E CHEST CLEAR</p><p>THROAT NO REDNESS</p><p>NO COLD OR NOSE BLOCK</p><p>POST COVID ISSUES</p>',_binary '<p>14/7/22</p><ol><li>ARALIA + DR0SEA + ZINGIBERQ - 20ML - 10 TDS</li><li>RUMEX 200 - 1/2 OUNCE TABLETS- 2TDS</li></ol>','2022-08-08 00:00:00'),(233,237,_binary '<p>14/7/22</p><p>FEVER ONE WEEK BACK</p><p>NO COLD</p><p>PHLEGM COMING UP AT TIMES</p><p>NO COLD OR RUNNING NOSE</p>',_binary '<p>14/7/22</p><ol><li>SILICEA 1M - 4 DOSE BD</li><li>KALI BICH 6X - 1/2 OUNCE - 3TDS</li><li>HYDRASTIS + EUCALYPTUS Q - 20ML = 10 TDS</li></ol>','2022-07-30 00:00:00'),(234,238,_binary '<p>16/7/22</p><p>ALLERGY SINCE MANY YEARS</p><p>ITCHING IN EYES</p><p>SNEEZING &lt; STRONG ODOUR</p><p>DEVIATED NASAL SEPTUM</p><p>NO WHEEZING</p><p>ITCHING IN THROAT</p><p>AFTER SNEEZING LEADS TO COUGH</p><p>DEGREE STUDENT</p><p>DYSMENORRHOEA, FIRST DAY LOWWER ABDOMEN</p><p>&gt;BENDING</p><p>ANEMIC</p><p>18/8/22</p><p>DRY COUGH AT NIGHT</p><p>NO SNEEZING NOW</p><p>&gt;HOT WATER</p><p>DRY PRICKING IN THROAT&lt; EVENING LYING DOWN</p>',_binary '<p>16/7/22</p><ol><li>PULS 1M - 2 DOSE SATURDAYS</li><li>SABADILLA + POTHOS Q - 10ML- 10 TDS</li><li>AMMON CARB + NUX VOM 30 - 2 DRM PILLS - 4 TDS</li></ol><p>18/7/22</p><ol><li>RUMEX 200 - 2 DRAM PILLS</li><li>ARALIA + DROSERA- 10ML - 10 TDS</li><li>PULS 1M - 2 DOSE WEEKLY ONCE</li></ol>','2022-08-08 00:00:00'),(235,239,_binary '<p>18/7/22</p><p>FEVER SINCE YESTERDAY</p><p>HAD FEVER ONE DAY</p><p>SAYS THROAT PAIN</p><p>LEFT TONSIL PAINFUL</p>',_binary '<p>18/7/22</p><ol><li>BELL + PHYTOLACCA Q</li><li>PYROGEN 30 - 1 DRM TABLETS</li><li>BELL 200 2DRM PILLS 4 PILLS 2 HRLY</li><li>BELL 1M - 3 DOSE SOS</li></ol>','0001-01-01 00:00:00'),(236,240,_binary '<p>18/7/22</p><p>COUGH WITH EXPECTORATION AT TIMES</p><p>NO COLD</p><p>HAD FEVER FEW DAYS BACK</p><p>30/7/22</p><p>VOMITED TWICE YESTERDAY AFTER TAKING JUICE</p><p>FEELING STOMACH PAIN</p><p>SLIGHT LOOSE STOOLS ONCE TODAY WITH STOMACH PAIN</p><p>LOSS OF APETITE AFTER GOING TO SCHOOL</p><p>DOENT EAT ANY THING NOW</p>',_binary '<p>18/7/22</p><ol><li>GRINDELIA 10M - QID</li><li>PULS 200 - 2 DRM PILLS - 4 QID</li></ol><p>30/7/22</p><ol><li>ARS ALB 30 - 4 DOSE</li><li>ALFA ALFA SYRUP -</li><li>CARICA PAPAYA - 10ML - HS</li><li>MAG PHOS 1M - 1 DRM TABLETS 1 TDS</li></ol>','0001-01-01 00:00:00'),(237,241,_binary '<p>20/7/22</p><p>HYPERLIPIDEMIA</p><p>NO OTHER HEALTH ISSUES</p><p>FATHER PASSED AWAY</p><p>PAIN IN LEFT HAND</p><p>HISTORY OF BLEEDING PILES</p><p>&lt;SPICY FOOD CAUSES BLEEDING PILES</p><p>CONSTIPATION AT TIMES</p><p>HARD BOWELS CAUSES BLEEDING</p>',_binary '<p>20/7/22</p><ol><li>ALLIUM SATIVA - 20ML - 10 DROPS TDS AFYER FOOD</li><li>NUX VOM 1M 2 DOSE WEEKLY ONCE</li><li>NUX VOM 30 - 1/2 OUNCE TABLETS - 3 TDS BEFORE FOOD</li></ol>','2022-08-08 00:00:00'),(238,242,_binary '<p>21/7/22</p><p>ALLERGY SINCE 20 YRS</p><p>STARTS AS ITCHING IN EYES, THEN SNEEZING SEVERE COLD THEN FEVER</p><p>NO WHEEZING</p><p>DIABETIC SINCE 15 YRS TAKING TABLETS</p><p>NUMBNESS IN FOOT</p><p>DESIRE TO CONTACT BUT UNABLE TO PERFORM DUE TO LACK OF ERECTION SINCE 3 MONTHS</p><p>FAMILY HISTORY OF DIABETES</p><p>APETITE - LESS</p><p>THIRSTLESS</p><p>BOWELS - CONSTIPATED</p><p>HAD WEAKNESS FIRST TIME BEFORE TESTING SUGAR LEVEL</p><p>DOING TILES WORK</p><p>3 CHILDREN - 2 MARRIED, I STUDENT</p><p>SNEEZING &lt;NIGHT LYING DOWN</p><p>&gt;HOT WEATHER</p><p>&lt;RAINY SEASON, COLD WEATHER</p><p><br></p>',_binary '<p>21/7/22</p><ol><li>THUJA 200 - 2 DOSE WEEKLY ONCE</li><li>NAT SULPH 6X - 1/2 OUNCE - 3 TDS</li><li>ALLIUM CEPA + SABADILLA Q - 20ML- 10 TDS</li></ol>','2022-08-08 00:00:00'),(239,243,_binary '<p>21/7/22</p><p>ALLERGY SINCE MANY YEARS</p><p>SNEEZING &lt; NIGHT LYING AFTER, WAKING UP MORNING</p><p>&lt; DUST</p><p>NOSE BLOCK AT NIGHT</p><p>NO WHEEZING</p><p>PERSPIRATION - NS</p><p>5/8/22</p><p>WAS FEELING BETTER WHILE TAKING MEDICINE</p><p>&lt;RAINY SEASON,?COLD WEATHER</p><p><span style=\"color: rgb(230, 0, 0);\">30/8/22</span></p><p>FEVER DAY BEFORE YESTERDAY</p><p>BODY PAIN WITH FEVER </p><p>HEADACHDE </p><p><span style=\"color: rgb(230, 0, 0);\">NAUSEATING HEADACHE ...BUT DOESNT VOMIT</span></p><p>NO HEAVINESS </p><p>PAIN IN TEMPLES BOTH SIDES</p><p>SLEEP GOOD</p><p>EA REDUCES HEADACHE</p><p>TONGUE - RED ANTERIORLY</p><p><br></p>',_binary '<p>21/7/22</p><ol><li>PULS 200 - 3 DOSE WEEKLY ONCE</li><li>SABADILLA + POTHOS Q - 20ML - 10 TDS</li><li>AMM CARB 200 - 2 DRM PILLS - 4 TDS</li></ol><p>5/8/22</p><ol><li>THUJA 1M - 1 DOSE STAT</li><li>PULS - 3 DOSE WEEKLY ONCE</li><li>SABADILLA Q + POTHOS Q- 20ML - 10TDS</li><li>AMM CARB 200 - 2 DRM PILLS</li></ol><p>30/8/22</p><ol><li>IPECAC 1M - 2 DRM PILLS - 4 PILLS 2 HRLY ALTERNATE WITH</li><li>BRY 200 - 2 DRM PILLS - 4 PILLS 2 HRLY</li></ol><p><br></p><p><br></p>','2022-08-08 00:00:00'),(240,244,_binary '<p>22/7/22</p><p>HAD FEVER SLIGHTLY WITH COUGHA ND COLD</p><p>NASAL DISCHARGE WATERY</p><p>RECTAL PROLAPSE?AFTER CONSTIPATED BOWELS WITH BLEEDING</p><p>DIFFICULT TO PASS MOTION</p><p>COLD COUGH SINCE YESTERDAY</p><p>COUGH WITH EXPECTORATION</p><p>LIKES TO PPLAY WITH WORMS {CHERATTA}</p>',_binary '<p>22/7/22</p><ol><li>PULS 200 + CALC PHOS 6X- 2 DRM TAB- 1 QID</li><li>HEP SULPH 200 - 2 DRM PILLS</li><li>FERR PHOS 6X + BELL 1M - 2 DRM TABLETS - 1 QID SOS</li></ol>','0001-01-01 00:00:00'),(241,245,_binary '<p>22/7/22</p><p>ALOPECIA AREATA SINCE 2 WEEKS</p><p>DANDRUFF ON HEAD, BLEEDING</p><p>WHITE POWDERY LEAVES BLEEDING ON SCRATCHING</p><p>COUGH WITH &lt;NIGHT AND MORNING</p><p>WITH EXPECTORATION, COLD WITH THICK NASAL DISCHARGE</p><p>PHY GEN</p><p>APPETITE = LESS</p><p>BOWELS - REGULAR AT TIMES CONSTIPATED</p><p>PERSPIRATION - WHOLE BODY ODOURLESS</p><p>LEG AND HANDS PAINFUL</p><p>THERMALS - CHILLY/</p><p>DESIRES - CHICKEN</p><p>FORGETFUL FOR STUDIES, AVERAGE</p><p>INCREASED HAIR GROWTH</p><p>STUBBORN</p><p>HAUGHTY, CRIES TILL SHE ACHIEVES WHAT SHE NEEDS</p><p>HISTORY OF FITS WHILE ANGER, TAKEN MEDICINE TILL AGE 4.6 YRS FROM 1YR</p><p>RECURRANT FEVER WITH RATTLING AND HOSPUTAL ADMISSION AT 2 YRS</p><p>LOW BIRTH WEIGHT - 1.9KG ONLY AT BIRTH, FITS ISSUES AT INFANCY ITSELF</p><p>NORMAL DELIVERY</p><p>AT 6 MONTHS OF GESTATION HYPERTENSION FOR MOTHER</p><p>RECUURANT MOUTH ULCERS</p>',_binary '<p>22/7/22</p><ol><li>BADIAGA Q +JABORANDI Q - 20ML - EXTERNAL DANDRUFF</li><li>BAR CARB 30 2 DRM PILLS 4 QID</li><li>ACID FLUOR 30 IN NATRUM SULPH 6X - 1/2 OUNCE - 3 TDS</li><li>PULMOLIN 10ML - 10 DROPS QID</li></ol><p><span style=\"background-color: rgb(230, 0, 0);\">TO GIVE</span></p><p><span style=\"color: rgb(230, 0, 0);\">SYPHILINUM 10M - 1 DOSE MONTHLY</span></p><p><span style=\"color: rgb(230, 0, 0);\">ACID FLUOR 200 - BD</span></p><p><span style=\"color: rgb(230, 0, 0);\">SILICEA 6X BD</span></p><p><span style=\"color: rgb(230, 0, 0);\">JABORANDI Q - EXTERNAL APPLICATION</span></p>','2022-08-08 00:00:00'),(242,246,_binary '<p>25/7/22</p><p>PSYCHIATRIC PATIENT UNDER TREATMENT</p><p>PAIN IN ABDOMEN</p><p>SOUR ERUTATIONS</p><p>FROTHY SALIVA IN MOUTH</p><p>SOUR ERUCTATIONS</p><p>&lt;SITTING&gt; WALKING</p><p>ALL COMPLAINTS STARTED AFTER HUSBANDS DEATH</p><p>BP = 150/80mm of hg</p>',_binary '<p>25/7/22</p><ol><li>NAT MUR 10M- 1 DOSE</li><li>Y LAX - 2AT NIGHT ....14</li><li>NAT PHOS 6X - 1/2 OUNCE 3 TDS</li></ol>','2022-08-01 00:00:00'),(243,247,_binary '<p>26/7/22</p><p>CHIKEN POX</p><p>28/7/22</p><p>SEVERE PAIN ALL OVER VERY DIFFICULT</p><p>THROAT PAIN,UNABLE TO EAT ANY THING</p>',_binary '<p>26/7/22</p><ol><li>FERR PHOS 1M - 1 DOSE</li><li>EUPATORIUM + BAPTISIA Q- 20ML</li><li>RHUS TOX 200 IN KALI MUR 6X - 1/2 OUNCE - 3 TDS</li></ol><p>28/7/22</p><p>MERC SOL 200 - 2 DOSE BD</p>','0001-01-01 00:00:00'),(244,248,_binary '<p>26/7/22</p><p>ITCHING IN PENIS SINCE 3 MONTHS</p><p>O/E WHITE FINE POWDERY</p><p>?PEELING OF SKIN INITIALLY</p>',_binary '<p>26/7/22</p><ol><li>CHRYSORBINUM OINTMENT</li><li>SEPIA 1M - 1 DRM TABLETS - 2 BD 2 WEEKLY ONCE</li><li>KALI MUR 6X - 1/2 OUNCE - 3 BD</li></ol>','2022-08-09 00:00:00'),(245,249,_binary '<p>27/7/22</p><p>MARRIED SINCE 1 YEAR</p><p>HEADACHE WITH FEVER SINCE YESTERDAY NIGHT</p><p>VOMITTED ONCE AT NIGHT AFTER THAT FEVER STARTED</p><p>HAD SLIGHT SHIVERING TENDENCY YESTERDAY NIGHT</p><p>LMP -24/7/22</p><p>29/8/22</p><p>WEAKNESS SINCE 2 WEEKS</p><p>PAIN IN JOINTS SINCE 2 WEEKS &lt; WAKING MORNING</p><p>SLEEPY </p><p>SENSATION OF PHLEGM IN THROAT </p><p>NEED TO TROUBLE TO TAKE OUT PHLEGM</p><p>HISTORY OF PCOD</p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p>',_binary '<p>27/7/22</p><ol><li>APIS 30 2DRAM PILLS ALTERNATE WITH</li><li>CANTHARIS 30 - 2 DRM PILLS</li><li>PYROGEN 200 - 2DRM TABLETS- 4 TDS</li><li>BELL 1M - IN FP 6X</li></ol><p>29/8/22</p><ol><li>KALI BICH 6X - 1/2 OUNCE - 2 TDS</li><li>SIL 1M - 2 DOSE</li><li>AVENA  SATIVA Q - 10M TDS</li></ol>','0001-01-01 00:00:00'),(246,250,_binary '<p>27/7/22</p><p>FEVER YESTERDAY NIGHT</p><p>PEELING FROM MOUTH</p><p>SLIGHT SWELLINH IN TONSILS</p>',_binary '<p>27/7/22</p><ol><li>MERC SOL 1M - 1 DOSE BD</li><li>RHUS TOX 30 - 2 DRM PILLS - 3 PILLS 2 HRLY</li><li>BELL 200 - 2 DRM PILLS 2 HRLY</li><li>BELL 1M - 1 DRM TABLETS - 1 SOS HIGH FEVER</li></ol>','0001-01-01 00:00:00'),(247,251,_binary '<p>27/7/22</p><p>BACK PAIN SINCE YESTERDAYNIGHT WITH FEVER</p><p>SLIGHT</p><p>IRREGULAR MENSES</p><p>MENSES ONCE IN 4-5 MONTHS , ONCE MENSES STARTS IT WILL BE HIGH BLEEDING WHICH LASTS FOR 7 DAYS</p><p>LMP P- MARCH</p><p>DELIVERY - AT 8 MONTHS DUE TO COVID CAUSED LOW HERAT RATE IN KIDS</p><p>H/0 PCOS SINCE MANY YEARS</p><p>BOTH SIDES</p><p>DONE INFERTILITY TREATMENT FOR 1.5 YRS AND CONCIEVED TWINS</p><p>DELIVERY IN OCTOBER</p><p>29/7/22</p><p>MENSES ON 28/7/22</p><p>SEVERE DYSMENORRHOEA</p><p>PAIN IN LOWER ABDOMEN VERY SEVERE</p><p>VOMITING AND LOOSE MOTION DURING PERIODS</p><p>BLEEDING WITH DARK BLOOD</p><p>NEEDS MEDICINE FOR DYSMENORRHOEA</p><p>FEVER IS NOT THERE NOW</p>',_binary '<p>27/7/22</p><ol><li>PULS 10M - 1 DOSE</li><li>PULS Q - 10ML</li><li>APIS 30 ALTERNATE WITH CANTHARIS30 - 2DRM PILLS</li><li>PYROGEN 200 - 5 DOSE BD</li><li>BELL 1M - 2 DRM</li></ol><p>29/7/22</p><ol><li>MAG PHOS 1M - IN 2 DRM TABLETS 2 TAB 2 HRLY</li><li>XANTHOXYLLUM Q -10ML - 10 2HRLY</li></ol>','0001-01-01 00:00:00'),(252,256,_binary '<p>1/8/22</p><p>MOUTH ULCER WITH FEVER</p><p>STARTED WITH FEVER BUT DIDNT GO WITH FEVER</p><p>INTENSE BURNING WITH</p><p>KNEE DISPLACEMENT FREQUENTLY</p><p>SEVERE COUGH WITH DIFFICULT COUGH</p><p>EXPECTORATION VERY DIFFICULT TO COME UP</p><p>HISTORY OF ASTHMA</p><p>TAKEN NEBULISATION BEFORE COMING HERE</p><p>SEVERE NOSE BLOCK</p><p>NASAL POLYP</p><p>SNEEZING ALWAYS</p><p>LEAST SMELL ALWAYS</p><p>ALLERGIC COMPLAINTS BEFORE ALSO</p><p>ARTIFICIAL TEETH SET SINCE 8 YEARS</p><p>BURNING+++ UNABLE TO EAT ANY THING</p><p><span style=\"color: rgb(230, 0, 0);\">18/8/22</span></p><p>HAD BEEN IN SUN FOR SOMETIME YESTERDAY</p><p>&lt;STRONG ODOUR</p><p>SNEEZING &lt;DUST FROM</p><p>HEAD SWEAT</p><p>BPN- 130/90</p><p>HEADACHE FRONTAL HEADACHE</p><p>DUST STORM FROM GULF USED TO CAUSE ALLERGY</p><p>NOSE BLOCKED FEELING</p><p>TEACHER, SOUND STRAINS ALWAYS</p><p>USED SPRAY FOR POLYP </p><p><br></p>',_binary '<p>1/8/22</p><ol><li>NAT MUR 200 - 10 DOSE BD</li><li>DROSERA Q+ SENEGA Q - 20ML - 10 TDS</li><li>RUMEX + KALI SULPH 6X - 3 DRM -3TDS</li></ol><p>18/8/22</p><p>1)RHUS TOX - 1M - 1 DOSE AT NIGHT</p><p>2]PHYTOLLACA + BELL Q + BAPTISIAQ - 20ML - 10TDS</p><p>3}ARS ALB 200 -2 DRM PILLS</p><p>23/8/22</p><p>POTHOS + SABADILLA Q - 20ML - 10 DROPS QID</p><p>LYSSIN 200 - 2 DOSE EVERY TUESDAY</p><p>27/8/22</p><p>NO RELIEF FOR SNEEZING GIVEN NUX + AMM CARB 30 IN 10ML FOR SNEEZING</p>','2022-08-10 00:00:00'),(248,252,_binary '<p>28/7/22</p><p>FEVER SINCE YESTERDAY</p><p>COUGH WITH EXPECTORATION</p>',_binary '<p>28/7/22</p><ol><li>BRY 200 - 2 DRM PILLS - 3PILLS 2 HRLY</li><li>BAPT 3X - 5ML - 6 DROPS 2 HRLY</li><li>BELL 1M IN FP 6X 2 DRM- 1 QID</li></ol>','0001-01-01 00:00:00'),(249,253,_binary '<p>29/7/22</p><p>FEVER FEW DAYS BACK TAKEN HOMOEO TREATMENT</p><p>HISTORY OF ECZEMA 2 YRS BACK</p><p>TREATED</p><p>STARTED AT 40 DAYS </p><p>VERY DRY SKIN</p><p>WITH ITCHING &lt; NUTS , </p><p>STARTS ON HEAD </p><p>MILK DESIRES </p><p>30/7/22</p><p>FEVER PERSISTING AS THE SAME</p><p>VERY WEAK</p><p>LYING ALWAYS</p><p>18/8/22</p><p><span style=\"color: rgb(230, 0, 0);\">WHITE DANDRUFF ON SCALP SINCE SOME DAYS</span></p><p><span style=\"color: rgb(230, 0, 0);\">&gt;OIL APPLICATION</span></p><p><span style=\"color: rgb(230, 0, 0);\">ITCHING ON SCALP</span></p><p><span style=\"color: rgb(230, 0, 0);\">ECZEMA AT BIRTH WITH SEVERE ITCHING</span></p><p><span style=\"color: rgb(230, 0, 0);\">TAKEN TREATMENT FOR 3 YEARS</span></p><p>27/8/22</p><p>ITCHING SEVERE ON HEAD</p><p>NOSE BLOCKED</p><p>30/8/22</p><p>SYMPTOMS OF ECZEMA MORE NOW WITH SEVERE ITCHING ON HEAD LEAVING BLEEDING SPOTS ON SCRATCHING</p><p>FROM HEAD NOW ITS EXTENDING TO BACK OF EARS</p><p>&gt; BATHING , OIL APPLICATION LIKES TO TAKE BATH</p><p>ACTIVE</p><p><br></p><p><br></p><p><br></p>',_binary '<p>29/7/22</p><ol><li>PYROGEN 200 - 1 DRM TABS- 1TDS</li><li>BELL 1M - 4 DOSE</li><li>APIS 30 ALTERNATE WITH CANTHARIS 30</li></ol><p>30/7/22</p><ol><li>BAPTISIA Q - 10ML -</li><li>BRY 200 - 2DRM PILLS - 2 HRLY</li><li>BELL 1M - 5 DOSE SOS,,,NTPAID</li></ol><p>18/8/22</p><ol><li>KALI MUR 6X - 1/2 OUNCE - 2 TDS</li><li>PSORINUM 200 - 1 DOSE STAT</li></ol><p>27/8/22</p><ol><li>PULSATILLA 200 - 2DRM PILLS - 4 TDS</li><li>SAMBUCUS 30 - 2DRM PILLS - </li></ol><p>30/8/22</p><ol><li>ECHINACEA Q - 10ML - 8 TDS</li></ol>','0001-01-01 00:00:00'),(250,254,_binary '<p>29/7/22</p><p>PAIN IN THROAT</p><p>HEADACHE ALL OVER</p><p>PAIN IN BACK</p><p>SHORT DRY COUGH</p><p>30/7/22</p><p>SEVERE BACK PAIN</p>',_binary '<p>29/7/22</p><ol><li>BRY 200 - 3 PILLS 2HRLY</li><li>BELLQ+PHYTOLACCA+BAPTISIA Q - 10ML - 10 QID</li><li>BELL 1M IN FP 6X - 2 QID</li></ol><p>30/7/22</p><p>ANT TART 10M - 4 DOSE BD NT PD</p>','0001-01-01 00:00:00'),(251,255,_binary '<p>29/7/22</p><p>HEADACHE SINCE MANY YEARS &lt; SUNLIGHT</p><p>LEFT SIDED HEADACHE</p><p>&gt;SLEEP</p><p>SLIGHT STRESS -HAD TAKEN LAND NEED TO GIVE MONEY</p><p>SLIGHT BALANCE ISSUES BEFORE</p><p>120/90MM OF HG</p><p>TAKES HIGHLY SPICY FOOD</p>',_binary '<p>29/7/22</p><ol><li>NAT MUR 10M - 1 DOSE AT NIGHT</li><li>BRY 200 -2 DRM PILLS SOS</li><li>IRIS VERS 200 - 2 DRM PILLS - 4 QID</li><li><br></li></ol>','2022-08-12 00:00:00'),(253,257,_binary '<p>1/8/22</p><p>HEADACHE SINCE A YEAR</p><p>&gt;VOMITING</p><p>&lt;SUN LIGHT</p><p>STARTS IN OCCCIPUT AND COMES TO ONE SIDE</p><p>INTROVERT</p><p>EASILY TAKES TENSION</p><p>BIRTH WEIGHT - 1.300KG AT BIRTH AT 8TH MONTH TWINS- ONE AMONG TWINS</p><p>15/8/22</p><p>HAD HEADACHE ONLY ONCE IN LAST 2 WEEKS</p><p>27/8/22</p><p><br></p>',_binary '<p>1/8/22</p><ol><li>NAT MUR 10M - 1 DOSE</li><li>BRY 200 - 2 DRM PILLS</li><li>IRIS VER 200 - 2DRM PILLS</li><li>SANGUINARIA Q - 10ML - 10 BD</li></ol><p>15/8/22</p><ol><li>TUBERCULINUM 1OM - 1 DOSE</li><li>IRIS VERS 200 - 2 DRM PILLS TDS</li><li>BRY 200 - 2 DRM PILLS</li><li>SANGUINARIA Q - 10ML - BD</li></ol><p>27/8/22</p><ol><li>IRIS VERS 200 - 2 DRM PILLS </li></ol>','2022-08-19 00:00:00'),(254,258,_binary '<p>2/8/22</p><p>COUGH SINCE YESTERDAY</p><p>NOSE BLOCKED SINCE 2- 3 DAYS</p><p>&lt;MORNING</p><p>DIFFICULTY IN FEEDING DUE TO NOSE BLOCK</p><p>COUGH WITH VOMITTING OF PHLEGM AT TIMES</p><p>BOWELS - REGULAR</p><p>PRETERM BIRTH DUE TO WEAK UTERUS OF MOTHER</p><p>BIRTH WEIGHT - 2 KG</p><p>NO OTHER HEALTH ISSUES</p><p>RED HANDS OF LEFT HAND AS BIRTH MARK</p><p>31/8/22</p><p>COLD WITH NASAL DISCHARGE WATERY</p><p>SNEEZING</p><p>NOSE BLOCKED WHILE FEEDING</p><p>COUGH WITH EXPECTORATION</p><p>ALL SINCE YESTERDAY</p><p>WAS BETTER WITH LAST MEDICINES, EVERYTHING GOT CLEARED</p><p>SLEEPS VERY LATE AT NIGHT 12 AM AFTER ONLY </p><p>CRIES UNTIL THEN</p><p>PERSPIRATION ++</p><p>CONSTIPATED SLIGHTLY SINCE 2 DAYS --OASSES ON ALTERNATE DAYS ONLY</p><p>SLIGHT FEVERISH AT MORNING</p><p><br></p>',_binary '<p>2/8/22</p><ol><li>SAMBUCUS 30 - 2 DRM PILLS</li><li>NASAL DROPS -</li><li>HEP SULPH 30 - 2 DRM PILLS</li></ol><p>31/8/22</p><ol><li>SAMBUCUS 30 - 2 DRM PILLS - 3 QID</li><li>HEP SULPH 30 - 2 DRM PILLS - 3 QID</li><li>BAPTISIA 3X - 5ML - 5DROPS BD SOS FEVER</li><li>BELL 1M - 14 DOSE SOS</li></ol>','0001-01-01 00:00:00'),(255,259,_binary '<p>13/8/22</p><p>BIRTH WEIGHT - 3.5KG</p><p>NORMAL DELIVERY</p><p>CONSTIPATION, PASS VERY HARD DRY PIECES AS STOOLS</p><p>ON POWDER MILK FEED GIVES TWICE OR THRCE A DAY</p><p>PASS WEEKLY ONCE</p><p>T3 - 1.26</p><p>T4- 14.13</p><p>TSH - 2.29</p>',_binary '<p>13/8/22</p><ol><li>CAUSTICUM 1M - 1 DOSE TONIGHT</li><li>OPIUM 1M - - 2 DRM TABLETS- 1 AT NIGHT</li></ol><p>MOTHER</p><ol><li>LAC DEFLORATUM 10M -11DOSE TONIGHT</li><li>PULS 30 - 5,L - 5 DROPS TDS</li></ol>','2022-08-22 00:00:00'),(256,260,_binary '<p>13/8/22</p><p>HISTORY OF FEVERAFTER COLD INTAKE</p><p>TAKEN ICE CREAM WITH THROAT PAIN</p><p>FEVER SINCE AFTERNOON</p><p>TEMP - 99.4</p>',_binary '<p>13/8/22</p><ol><li>PHTYTOLACCA +BELL+ BAPT Q - 10ML - 10 DROPS 2 HRLY</li><li>HEP SULPH 200 ALTERNATE WITH BELL 200 2 DRM PILLS</li><li>BELL 1M - 4 DOSE SOS</li></ol>','0001-01-01 00:00:00'),(257,261,_binary '<p>15/8/22</p><p>NEEDS MEDICINE FOR CONSTIPATION</p><p>IF NOT PASSED ON TIME DIFFICULT TO PASS</p><p>NEEDS TO TAKE FOOD THEN ONLY PASS </p>',_binary '<p>15/8/22</p><ol><li>YLAX - 12 Tablets</li><li>CAUSTICUM 10M - 1 DOSE</li><li>SULPH30 - 2 DRM PILLS - 4 TDS BEFORE FOOD</li></ol>','0001-01-01 00:00:00'),(258,262,_binary '<p>16/8/22</p><p>FEVER ON AND OF SINCE 2 WEEKS</p><p>COUGH WITH EXPECTORATION</p><p>FULL BODY PAIN</p><p>COUGH WITH BLOOD STREAKS</p><p>2WEEKS AND MORE</p><p>EXPECTORATION VERY THICK</p><p><br></p><p><br></p>',_binary '<p>16/8/22</p><ol><li>PYROGEN 200 - 3 TABLETS 2 HRLY - 1/2 OUNCE</li><li>BAPTISIA+ PHYTOLACCA+ BELL Q - 20ML - 10 DROPS 1 HRLY</li><li>BELL 1M - 2 DRM PILLS 2 HRLY</li></ol><p>18/8/22</p><ol><li>PYROGEN 200 - 3 TABLETS - 2HRLY</li><li>BAPTISIA+PHTOLACCA + BELL Q - 20ML - 10 DROPS - 1HRLY</li><li>BELL 1M - 2 DRM PILLS</li></ol>','0001-01-01 00:00:00'),(259,263,_binary '<p>17/8/22</p><p>FEVER SINCE 4 DAYS</p><p>COUGH SINCE 4 DAYS WITH EXPECTORATION</p><p>NOSE BLOCKED AT NIGHT</p><p>23/8/22</p><p>FEVER PERSISTING</p>',_binary '<p>17/8/22</p><ol><li>PYR0GEN 200 - 3 DRM TABLETS - 3 QID</li><li>FERR PHOS 6X + BELL 1M- 2 DRM PILLS - 4 PILLS 1 HRLY SOS</li><li>EUCALYPTUS + BAPTISIA 3X - 10ML - 8 DROPS 2 HRLY ALTERNATE WITH</li><li>IODUM 3X - 10ML - 8 DROPS 2 HRLY</li><li>PULS 1M - 2 DOSE BD STAT</li></ol><p>19/8/22</p><p>NEED MEDICINE FOR FEVER WHICH GOT OVER</p><ol><li>FERR PHOS 6X + BELL 1M- 1/2 OUNCE TABLETS- 4 PILLS 1 HRLY</li><li>PYROGEN 200 - 1/2 OUNCE TABLETS</li><li>BRY 200 - 3 DRM PILLS 2 HRLY FOR <span style=\"color: rgb(230, 0, 0);\">ALIYA</span></li></ol>','0001-01-01 00:00:00'),(260,264,_binary '<p>18/8/22</p><p>COUGH AFTER FEVER</p><p>HAD SLIGHT FEVER SINCE YESTERDAY</p><p>HAD COUGH 2 WEEKS BACK WITH WHEEZING AND ADMITTED</p><p>DRY COUGH PRICKING TYPE</p><p>NOT MUCH PHLEGM</p><p>NO COLD OR THROAT PAIN NOW</p><p>COUGH</p><p>NO WHEEZING NOW,BEFORE NO HISTORY OF ASTHMA</p><p>DRIBBLING OF URINE AFTER COUGH</p><p>BODY PAIN WITH</p><p>18/8/22</p><p>CHILD 4.5 YRS</p><p>COUGH WITH EXPECTORATION</p><p>HAD FEVER BEFORE COUGH</p><p>NOW NOSE DISCHARGE THICK YELLOWISH--12KG WEIGHT</p><ol><li>EUCALYPTUS Q + GRINDELIA Q- 10ML - 8 DROPS QID</li><li>IODUM 3X- 6 DROPS - QID</li><li>PULS 200- 2 DRM PILLS - 4 2 HRLY</li></ol><p>19/8/22</p><p>FEVER INTERMITTANT</p><p>COUGH REDUCED</p><p>NOW SEVERE SNEEZING AND COLD</p><p>WATERY NASAL DISCHARGE</p><p>BODY PAIN </p><p>COUGH AT TIMES ONLY </p><p>TIRED AND WEAKNESS PERSISTING</p><p>PAIN IN SINUS</p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p>',_binary '<p>18/8/22</p><ol><li>PYROGEN 200 - 1/2 OUNCE - 3 TAB 2 HRLY</li><li>VERBASCUM Q - 10ML - 10 QID</li><li>CONIUM MAC 200 - 3 DRM PILLS - 5 PILLS 2 HRLY</li></ol><p>19/8/22</p><ol><li>ARS ALB 200 - 3 PILLS 2 HRLY</li></ol><p><br></p>','0001-01-01 00:00:00'),(261,265,_binary '<p>18/8/22</p><p>DUST ALLERGY</p><p>NEEDS MEDICINE FOR ALLERGY</p><p>DUST CAUSES SNEEZING, CHEST INFECTION AND THEN FEVER</p><p>SEVERE ALLERGY LEADS TO ASTHMA</p><p>THROAT INFECTION ON ANY COLD INTAKE</p><p>DUST, COLD CAUSES ALL DIFFICULTIES</p><p>ALLERGY SINCE MANY YEARS</p><p>ITCHING IN THROAT, NOSE ,EYES</p><p>DRY SKIN WITH RASHES</p><p><br></p><p><br></p><p><br></p><p><br></p>',_binary '<p>18/8/22</p><p>1)POTHOS + SABADILLA- 30ML - 2 BOTTLES-</p><p>2)HISTAMIN - 3 TABLETS EVERY MONDAY EMPTY STOMACH- 2 BOTTLES</p><p>3)AMMONIUM CARB + NUXVOM 30 - 30ML PILLS - 2 BOTTLES</p><p>4)NAT SULPH 1M - 3 DRM 4 GR TABLETS - 1 EVERY FRIDAY EMPTY STOMACH</p>','0001-01-01 00:00:00'),(262,266,_binary '<p>18/8/22</p><p>VOMITTED SINCE YESTERDAY</p><p>WATERY NASAL DISCHARGE</p><p>COUGH WITH EXPECTORATION&lt; NIGHT</p><p>30/8/22</p><p>FEVER SINCE YESTERDAY</p><p>COUGH WITH EXPECTORATION , RATTLING</p><p>30/8/22</p><p>HIGH FEVER SINCE MORNING</p><p>INCREASED RESPIRATORY RATE WITH</p><p>RATTLING HEARD ON BOTH SIDES</p>',_binary '<p>18/8/22</p><ol><li>ARS ALB 200 - 2 DRM PILLS</li><li>BAPTISIA 3X - 5ML -5 DROPS QID</li><li>BELL 1M - 1 DRM TABLETS</li></ol><p>30/8/22</p><ol><li>VERAT VIRIDE 200 - 2 DRM PILLS</li><li>BAPTISIA 3X - 5ML - 5 DROPS QID</li><li>BELL 1M - 1 DRM TABLETS 2 TAB SOS</li><li>PYROGEN 200 - 3 DOSE 1 DOSE DAILY</li></ol><p><br></p>','0001-01-01 00:00:00'),(263,267,_binary '<p>22/8/22</p><p>NOSE BLOCK AFTER FEVER</p><p>SINCE 1 MONTH</p><p>NASAL POLYP ?</p><p>TONSILLS SWOLLEN</p><p>SEVERE NOSE BLOCK</p><p>NOT MATURED</p><p>DANDRUFF WHITE SCALY</p>',_binary '<p>22/8/22</p><ol><li>THUJA 1M - - 1/2 DRM TABLETS - 6 TABLETS- 2 TABLET EVERY MONDAY NIGHT</li><li>NASAL DROPS WITH LEMNA MINOR</li><li>PULS 200 - 3 DRM PILLS - 4 TDS</li><li>ARNICA HAIR OIL</li><li>LEMNA MINOR Q - 10ML - 10 DROPS BD</li></ol>','0001-01-01 00:00:00'),(264,268,_binary '<p>22/8/22</p><p>FEVER SINCE YESTERDAY</p><p>THROAT PAIN</p><p>SLIGHT COUGH WITH COLD</p><p>THIRSTLESS</p><p><br></p><p><br></p>',_binary '<p>22/8/22</p><ol><li>BAPTISIA Q+ PHYTOLACCA + BELL Q- 20 ML - 10 DROPS 3 HRLY</li><li>BELL 1M IN FERR PHOS 6X - 2 DRM TABLETS SOS</li><li>BRY 200 - 2 DRM PILLS- 4 PILLS 2 HRLY</li></ol>','0001-01-01 00:00:00'),(265,269,_binary '<p>23/8/22</p><p>NEEDS MEDICINE FOR FEVER AND CHEST CONGESTION TO TAKE TO GULF</p>',_binary '<p>23/8/22</p><ol><li>FERR PHOS + BELL 1M - 1/2 OUNCE TABLETS</li><li>ARS ALB 200 - 10ML PILLS</li><li>BAPTISIA 3X - 20ML</li><li>BRYONIA 200 - 10ML PILLS</li><li>NUX VOM 30 - 10ML PILLS</li><li>GRINDELIA Q - 20ML</li><li>ANT TART 6C - 10ML PILLS</li><li>PULS 200 - 10ML PILLS</li></ol><p><br></p>','0001-01-01 00:00:00'),(266,270,_binary '<p>23/8/22</p><p>NOSE BLOCK SINCE 2 DAYS</p><p>HAD COLD</p><p>ALWAYS NOSE OBSTRUCTED</p><p>H/O ASTHMA ALLERGIC ALTERNATES WITH ECZEMA</p><p>NO COUGH</p><p>SNEEZING NOW ALLERGIC</p><p>FEVER SINCE 2 DAYS</p><p>RECURRANT FEVER LAST WEEK WITH FEVER AND RATTLING</p><p>ALLERGIC ASTHMA ALWAYS</p><p>COUGHS WHOLE NIGHT USUALL</p><p>27/8/22</p><p>INCREASED SEVERE COUGH AT NIGHT</p><p><span style=\"color: rgb(230, 0, 0);\">LYING ON SUJOOD POSITION DUE TO BREATLESSNES</span>S</p><p>CHILD SEEMS TO BE SLIGHTLY ACTIVE TODAY...&lt; NIGHT</p>',_binary '<p>23/8/22</p><ol><li>NASAL DROPS</li><li>BAPTISIA Q+ BELLQ+ PHYTOLACCA Q- 20ML TO TAKE FROM FATHER - ISMAIL 8 DROPS</li><li>BELL 1M SOS 5 DOSE</li><li>ARS ALB 3X - 10ML - 5TDS</li></ol><p>25/8/22</p><ol><li>TAKEN ARS ALB 3X AND GIVEN IPECAC 3X IN 2 DRM PILLS 1 HRLY</li><li>IODOFORM 3X IN 2 DRM TABLETS 1 QID</li><li>ARALIA + SENEGA Q - 6 DROPS 2 HRLY</li><li>BELL 1M - DOSE</li></ol><p>27/8/22</p><ol><li>VERAT VIRIDE - 200 - 2 DRM PILLS- 3 PILLS 2 HRLY ALTERNATE WITH IPECAC 3X - 2 HRLY</li><li><span style=\"color: rgb(230, 0, 0);\">MEDO 1M - 1 DOSE NOW</span></li></ol>','0001-01-01 00:00:00'),(267,271,_binary '<p>23/8/22</p><p>FEVER 2 WEEKS BACK</p><p>NOW COUGH ALWAYS WITH EXPECTORATION</p><p>NASAL DISCHARGE WHITE THICK</p><p>HAD COUGH WITH FEVER ALSO</p><p>BOWELS - NS</p><p>APETITE - GOOD</p><p>TONGUE CLEAN</p><p>29/8/22</p><p>WHITE PHLEGM NOW</p><p>COUGH PERSISTING</p><p>RATTLING WHILE SITTING FOR A WHILE</p><p>TALKS WITH NOSE</p><p>COMPLAINTS PERSISTING AS THE SAME</p><p>PHLEGM LITTLE LOOSE NOW AFTER MEDICINE</p><p>30/8/22</p><p>FEVER AFTER COMING FROM SCHOOL SINCE EVENING</p><p><br></p><p><br></p>',_binary '<p>23/8/22</p><ol><li>TUBERCULINUM 1M - 1 DOSE</li><li>GRINDELIA Q - 10MLM- 8 DROPS QID</li><li>IPECAC 30 - 2 DRM PILLS 4 QID</li></ol><p>29/8/22</p><ol><li>GRINDELIA Q - 10ML - 8 DROPS QID</li><li>NAT SULPH 6X 1/2 OUNCE - 3 TDS</li><li>HEP SULPH 200 3 DRM PILLS - 4 TDS</li></ol><p>30/8/22</p><ol><li>PYROGEN 200 - 6 DOSE BD</li><li>BAPTISIA 3X - 10ML - 8 QID</li></ol>','0001-01-01 00:00:00'),(268,272,_binary '<p>24/8/22</p><p>RECURRANT FEVER WITH COUGH AND EXPECTORATION</p><p>COUGH WITH EXPECTORATION</p><p>HIGH FEVER 102</p><p>COUGH WITH EXPECTORATION</p><p>RECURRANT FEVER SINCE 3 WEEKS</p><p>NOW FEVER STARTED SINCE YESTERDAY NIGHT</p><p>27/8/22</p><p>COUGH PERSISTING WITH EXPECTORATION</p><p>FEVER REDUCED</p>',_binary '<p>24/8/22</p><ol><li>BELL 1M - 7 DOSE</li><li>BAPTISIA Q - 10ML -8 DROPS 2 HRLY</li><li>GELS 30 - 2 DRM PILLS- 3 PILLS 2 HRLY FELT SHIVERING UNDER FAN</li><li>PYROGEN 200 - 2 DRM TABLETS - 3TDS</li></ol><p>27/8/22</p><ol><li>IODUM 3X + GRINDELIA Q + EUCALYPTUS Q DROPS - 10ML -N8 TDS</li></ol>','0001-01-01 00:00:00'),(269,273,_binary '<p>28/8/22</p><p>FEVER SINCE MORNING</p><p>NOSE BLOCKED</p><p>NO THROAT PAIN</p><p>ALL AT HOME ARE HAVING FEVER</p><p>WATERY NASAL DISHARGE</p><p>THIRSTLESS</p><p>NO CHILLINESS</p><p>PERSPIARTION</p><p>WEAKNESS</p><p>LEG PAIN 2 DAYS BACK</p><p><br></p><p><br></p><p><br></p>',_binary '<p>28/8/22</p><ol><li>BELL 1M - 3 DOSE SOS</li><li>BRY 200 ALTERNATE WITH</li><li>RHUSTOX 200 2 DRM PILLS</li><li>BAPTISIA Q - 10M - 10 QID</li></ol>','0001-01-01 00:00:00'),(270,274,_binary '<p>29/8/22</p><p>COUGH DRY TYPE</p><p>NASAL DISCHARGE THICK</p><p>NOSE BLOCKED AT TIMES</p><p>DRY COUGH AT NIGHT AFTER FEVER</p><p>GOT RECOVERED FROM FEVER YESTERDAY ONLY</p>',_binary '<p>29/8/22</p><ol><li>HYOS 200 - 1 DOSE AT NIGHT</li><li>PULS 200 - 2 DRM PILLS - 3 QID</li><li>SIL 6X - 1 DRM TAB- 1 TDS</li></ol>','0001-01-01 00:00:00'),(271,275,_binary '<p>29/8/22</p><p>COUGH SINCE 2 WEEKS</p><p>COUGH ENDS IN VOMITTING</p><p>&lt; LYING DOWN AT NIGHT</p><p>STARTS AS DRY COUGH</p><p>HAD COLD</p><p>ALREADY GIVEN 2 WEEKS ALOPATHIC MEDICINE</p>',_binary '<p>29/8/22</p><ol><li>COCCUS CATI 30 - 3 DRM PILLS</li><li>DROSERA + ZINGIBER Q- 10ML - 8 QID</li><li>PYROGEN 200 - 3 DOSE - SOS</li></ol>','0001-01-01 00:00:00'),(272,276,_binary '<p>31/8/22</p><p>LEFT SIDED PAIN IN BACK OF THIGHS EXTENDING TO LEG</p><p>&lt;MOTION</p><p>&gt;REST </p><p><br></p><p><br></p>',_binary '<p>31/8/22</p><ol><li>ARNICA 1M  5 DOSE - 1 AT MORNING</li><li>BRY+ ARNICA Q- 20ML - 10 2 HRLY</li><li>MAGPHOS 6X + COLOCYNTH 200 - 1/2 OUNCE 3 TDS</li></ol>','0001-01-01 00:00:00'),(273,277,_binary '<p>31/8/22</p><p>WEIGHT GAIN SINCE 3 YRS </p><p>WT= 78.9</p><p>TIRED DUE TO DISTURBED SLEEP</p><p>HB- 8</p><p>PALPITATION</p><p>TIRED WEAKNESS</p><p>MENSES REGULAR</p><p>APETITE - LOW, </p><p>DRINKS - MORE TEA - DESIRES TEA- BLACK TEA</p><p>DILIKES - EGG, MILK</p><p>BOWELS - REGULAR</p><p><br></p><p><br></p><p><br></p><p><br></p><p><br></p>',_binary '<p>31/8/22</p><ol><li>FERRUM PLUS CAPSULES 10 - 1 AT NIGHT</li><li>FERRUM MET - 6X - 1/2 OUNCE - 3 TDS</li><li>ACID PHOS 200 - 2DRM PILLS -4 TDS</li></ol>','0001-01-01 00:00:00');
/*!40000 ALTER TABLE `op` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `panjayath`
--

DROP TABLE IF EXISTS `panjayath`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `panjayath` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `panjayath`
--

LOCK TABLES `panjayath` WRITE;
/*!40000 ALTER TABLE `panjayath` DISABLE KEYS */;
INSERT INTO `panjayath` VALUES (1,'panjayath 1'),(2,'panjayath 2');
/*!40000 ALTER TABLE `panjayath` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `PNo` varchar(45) DEFAULT NULL,
  `Name` varchar(200) DEFAULT NULL,
  `Age` varchar(45) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Grade` varchar(45) DEFAULT NULL,
  `Gender` varchar(45) DEFAULT NULL,
  `Panjayath` varchar(100) DEFAULT NULL,
  `WardNo` varchar(45) DEFAULT NULL,
  `Phone1` varchar(45) DEFAULT NULL,
  `Phone2` varchar(45) DEFAULT NULL,
  `RegDate` datetime DEFAULT NULL,
  `ExpDate` datetime DEFAULT NULL,
  `DropDate` datetime DEFAULT NULL,
  `Volunteer` varchar(100) DEFAULT NULL,
  `Diagnosis` varchar(100) DEFAULT NULL,
  `Temp` tinyint DEFAULT NULL,
  `Route` varchar(100) DEFAULT NULL,
  `HomeCarePlan` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `PNo_UNIQUE` (`PNo`)
) ENGINE=MyISAM AUTO_INCREMENT=278 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES (1,'D1','NUSRATH - Delete','30','',NULL,'F',NULL,NULL,'9048176915',NULL,'2021-12-18 00:00:00',NULL,NULL,NULL,NULL,1,NULL,NULL),(2,'A2155','SHAMNA','13','AYNICHOODU',NULL,'F',NULL,NULL,'9567163338',NULL,'2021-12-31 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(3,'100','Test Patient','20.6','',NULL,'M',NULL,NULL,'1234',NULL,'2021-12-31 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(4,'A2101','KADEEJA','55','AYNICHOODU',NULL,'F',NULL,NULL,'',NULL,'2021-11-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(5,'A2102','SIDRA','2','AYNICHOODU',NULL,'F',NULL,NULL,'',NULL,'2021-11-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(6,'A2103','SHARAFU','39','MOOKUTHALA',NULL,'M',NULL,NULL,'',NULL,'2021-11-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(7,'A2104','VIJAYAN','62','AYNICHOODU',NULL,'M',NULL,NULL,'',NULL,'2021-11-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(8,'A2105','MOHAMMED SHAHAAN','6','',NULL,'M',NULL,NULL,'9567973566',NULL,'2021-11-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(9,'A2106','NISHAD','31','KAANJOOR',NULL,'M',NULL,NULL,'9809388992',NULL,'2021-11-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(10,'A2107','MOHAMMED SHAMIL','11','AYNICHOODU',NULL,'M',NULL,NULL,'',NULL,'2021-11-15 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(11,'A2109 ','ALI','18','AYNICHOODU',NULL,'M',NULL,NULL,'',NULL,'2021-11-15 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(12,'A2110','AMINAKUTTY','71','',NULL,'F',NULL,NULL,'808602273',NULL,'2021-11-16 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(13,'A2111','NAJA FATHIMA','15','AYNICHOODU',NULL,'F',NULL,NULL,'9633252121',NULL,'2021-11-16 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(14,'A2112','ARIFA','34','',NULL,'F',NULL,NULL,'9633252121',NULL,'2021-11-16 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(15,'A2113','DAWNSUN','10','',NULL,'M',NULL,NULL,'9497124617',NULL,'2021-11-18 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(16,'A2114','AYESHA MEHWIN','3','',NULL,'F',NULL,NULL,'7593947657',NULL,'2021-11-18 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(17,'A2115','JISNA','23','',NULL,'F',NULL,NULL,'7593947657',NULL,'2021-11-18 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(18,'A2116 ','TANVI','1','',NULL,'F',NULL,NULL,'8589914180',NULL,'2021-11-18 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(19,'A2117','JULIE','41','',NULL,'F',NULL,NULL,'9497124617',NULL,'2021-11-19 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(20,'A2118 ','EMIN','1','',NULL,'M',NULL,NULL,'',NULL,'2021-11-19 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(21,'A2119 ','SARASS','47','',NULL,'F',NULL,NULL,'',NULL,'2021-11-19 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(22,'A2120','SABUR','23','',NULL,'M',NULL,NULL,'7010292990',NULL,'2021-11-19 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(23,'A2121','JAMEELA','48','',NULL,'F',NULL,NULL,'',NULL,'2021-11-22 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(24,'A2122','SARA','64','',NULL,'F',NULL,NULL,'',NULL,'2021-12-22 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(25,'A2123','MASTER HAADI','10','',NULL,'F',NULL,NULL,'',NULL,'2021-11-22 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(26,'A2125','ASLAM','16','',NULL,'M',NULL,NULL,'9746967493',NULL,'2021-11-24 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(27,'A2124','AISHWARYA','25','',NULL,'F',NULL,NULL,'8589914180',NULL,'2021-11-24 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(28,'A2126','SAJITHA ','34','',NULL,'F',NULL,NULL,'',NULL,'2021-12-26 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(98,'A2196','ISHAL MARIYAM','0.3','',NULL,'F',NULL,NULL,'9567757040',NULL,'2022-02-22 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(29,'A2127','RAID RAHEEM','7','',NULL,'M',NULL,NULL,'',NULL,'2021-11-26 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(30,'A2128','THANHA','7','',NULL,'F',NULL,NULL,'',NULL,'2021-11-26 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(31,'A2129','IHAAN','7','',NULL,'M',NULL,NULL,'',NULL,'2021-11-26 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(32,'A2130','RAJU','60','',NULL,'M',NULL,NULL,'9946034124',NULL,'2021-11-27 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(33,'A2131','IRSHAD','22','',NULL,NULL,NULL,NULL,'',NULL,'2021-11-27 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(34,'A2132','AYESHA','55','',NULL,'F',NULL,NULL,'9545599111',NULL,'2021-11-27 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(35,'A2133','VEERAVUNNI','65','',NULL,'M',NULL,NULL,'9745599111',NULL,'2021-11-27 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(36,'A2134','NOUSHAD','40','',NULL,'M',NULL,NULL,'',NULL,'2021-11-27 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(37,'A135','SABIRA','45','',NULL,'F',NULL,NULL,'9745444417',NULL,'2021-12-01 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(38,'A2136','KHADEEJA','32','',NULL,'M',NULL,NULL,'',NULL,'2021-12-01 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(39,'A2137','NAZAAL','7','',NULL,'M',NULL,NULL,'',NULL,'2021-12-04 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(40,'A2138','SHAHEERA','30','',NULL,'F',NULL,NULL,'9188481679',NULL,'2021-12-08 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(41,'A2139','AYISHA NIZWA','5','',NULL,'F',NULL,NULL,'7591905222',NULL,'2021-12-09 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(42,'A2140','SAKEENA','45','',NULL,'F',NULL,NULL,'7994115936',NULL,'2021-12-10 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(43,'A2141','ABDUL RASHEED','46','',NULL,'M',NULL,NULL,'9061191578',NULL,'2021-12-10 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(44,'A2142','FATHIMA SHEZA','8','',NULL,'F',NULL,NULL,'7559966635',NULL,'2021-12-10 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(45,'A2143','RASLA','18','',NULL,'F',NULL,NULL,'9846426743',NULL,'2021-12-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(46,'A2144','THASNEEM','22','',NULL,'F',NULL,NULL,'',NULL,'2021-12-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(47,'A2145','MOHAMMED NIHAD','7','',NULL,'M',NULL,NULL,'9745374171',NULL,'2021-12-14 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(48,'A 2146','RAMLA','50','',NULL,'F',NULL,NULL,'9746046198',NULL,'2021-12-17 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(49,'A2147','BABY ZAMEEL','1','',NULL,'M',NULL,NULL,'9048176915',NULL,'2021-12-18 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(50,'A2148','NUSRATH','30','',NULL,'F',NULL,NULL,'9014176915',NULL,'2021-12-18 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(51,'A2149','SIDHAN','13','',NULL,'M',NULL,NULL,'9746038421',NULL,'2021-12-24 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(52,'A2150','NAFEESA','55','',NULL,'F',NULL,NULL,'9746038421',NULL,'2022-01-24 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(53,'A2151','MOHAMMED AHYAN','1','',NULL,'M',NULL,NULL,'9846377332',NULL,'2021-12-27 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(54,'A2152','SUBAIDA','50','',NULL,'F',NULL,NULL,'9947845375',NULL,'2021-12-27 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(55,'A2153','NEHA MARYAM','8','',NULL,'F',NULL,NULL,'8111937307',NULL,'2021-12-30 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(56,'A2154','SOORAJ','30','',NULL,'M',NULL,NULL,'',NULL,'2021-12-29 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(57,'A2156','NADEERA','28','',NULL,'F',NULL,NULL,'',NULL,'2022-01-03 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(58,'A2157','ABDUL MAJEED','42','',NULL,NULL,NULL,NULL,'',NULL,'2022-01-04 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(59,'A2159','SHAHAL','11','',NULL,'M',NULL,NULL,'',NULL,'2022-01-04 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(60,'A2160','FIDHA','12','',NULL,'F',NULL,NULL,'9846825697',NULL,'2022-01-05 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(61,'A2161','SARAMMA','62','',NULL,'F',NULL,NULL,'81570179175',NULL,'2022-01-06 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(62,'2162','RABIYA','48','',NULL,'F',NULL,NULL,'9400956381',NULL,'2022-01-06 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(63,'A2163','IBRAHIM BANGALORE','31','',NULL,'M',NULL,NULL,'9740293920',NULL,'2022-01-11 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(64,'A2164','AZMIN MARYAM','0.3','',NULL,'F',NULL,NULL,'9633707433',NULL,'2022-01-10 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(65,'A2165','AQSA FATHIMA','7','',NULL,'F',NULL,NULL,'9633707433',NULL,'2022-01-10 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(66,'A2166','AYYOOB','37','',NULL,'M',NULL,NULL,'730669764',NULL,'2022-01-10 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(67,'A2167','AMINAKUTTY','55','',NULL,'F',NULL,NULL,'9995271978',NULL,'2022-01-11 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(68,'A2168','RAFEEQ DAUGHTER','3','',NULL,'F',NULL,NULL,'',NULL,'2022-01-11 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(69,'A2169','UNKNOWN','26','',NULL,'M',NULL,NULL,'',NULL,'2022-01-12 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(70,'A2170','AYISHA','60','',NULL,'F',NULL,NULL,'',NULL,'2022-01-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(71,'A2171','ABOOBACKER','66','',NULL,'M',NULL,NULL,'9846157141',NULL,'2022-01-14 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(72,'A2172','USMAN','49','',NULL,'M',NULL,NULL,'9895131683',NULL,'2022-01-14 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(73,'A2173','RAJEEV','40','',NULL,'M',NULL,NULL,'9961602040',NULL,'2022-01-14 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(74,'A2174','BABY HAWWA','1.5','',NULL,'F',NULL,NULL,'97468939319',NULL,'2022-01-21 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(75,'A2175','AMINA ','61','',NULL,'F',NULL,NULL,'',NULL,'2022-01-22 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(76,'A2176','ANSI.P.M','5.6','',NULL,'F',NULL,NULL,'',NULL,'2022-01-22 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(77,'A2177','RAIHANATH','23','',NULL,'F',NULL,NULL,'9526202557',NULL,'2022-01-24 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(78,'A2178','FAISAL','42','',NULL,'M',NULL,NULL,'8589857857',NULL,'2022-01-26 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(79,'A2179','FEBIN MUNEER','38','',NULL,'F',NULL,NULL,'7356444742',NULL,'2022-01-28 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(80,'A2180','ADINAN','11','',NULL,'M',NULL,NULL,'9846825697',NULL,'2022-01-29 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(81,'A2181','SAINABA','55','',NULL,'F',NULL,NULL,'',NULL,'2022-01-31 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(82,'A2197','JAMALUDHEEN','67','',NULL,'M',NULL,NULL,'8156874813',NULL,'2022-01-22 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(83,'A2182','MOHAMMED RAYYAN','11','',NULL,'M',NULL,NULL,'9747476960',NULL,'2022-02-01 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(84,'A2108','BUSHRA','39','',NULL,'F',NULL,NULL,'',NULL,'2021-11-15 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(85,'A2190','ABDUL HANAN','27','',NULL,'M',NULL,NULL,'8943138565',NULL,'2022-02-03 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(86,'A2185','SREENA','37','',NULL,'F',NULL,NULL,'8590849693',NULL,'2022-02-04 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(87,'A2183','ABDUL MAJEED','30','',NULL,'M',NULL,NULL,'',NULL,'2022-02-04 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(88,'A2186','SAFIYA','41','',NULL,'F',NULL,NULL,'9846404868',NULL,'2022-02-08 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(89,'A2187','DANY','33','',NULL,'F',NULL,NULL,'9074868961',NULL,'2022-02-10 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(90,'A2188','SAMEERA','39','',NULL,'F',NULL,NULL,'8921985674',NULL,'2022-02-10 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(91,'A2189','FATHIMA LIYANA','14','',NULL,'F',NULL,NULL,'9846535320',NULL,'2022-02-12 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(92,'A2191','ZAINABA','37','',NULL,'F',NULL,NULL,'9895456458',NULL,'2022-02-12 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(93,'A2192','HIBA NASRIN','11','',NULL,'F',NULL,NULL,'9895456458',NULL,'2022-02-12 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(94,'A2193','KINZA','0.5','',NULL,'F',NULL,NULL,'7356400678',NULL,'2022-02-16 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(95,'A211','NADIYA','37','',NULL,'F',NULL,NULL,'',NULL,'2021-11-28 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(96,'A2194','ADAM','3.6','',NULL,'M',NULL,NULL,'9746601079',NULL,'2022-02-16 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(97,'A2195','KADEEJA','59','',NULL,'F',NULL,NULL,'9895383858',NULL,'2022-02-18 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(99,'A2198','MOHAMMED SALEEM','39','',NULL,'M',NULL,NULL,'6382366782',NULL,'2022-02-22 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(100,'A2199','KHALID','57','',NULL,'M',NULL,NULL,'9400956381',NULL,'2022-02-23 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(101,'A2200','MOHAMMED JAZAL','13','',NULL,'M',NULL,NULL,'9567133931',NULL,'2022-02-24 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(102,'A2201','Abdu Rahman','61','',NULL,'M',NULL,NULL,'9995271978',NULL,'2022-02-26 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(103,'A2202','SHAHIUL HAMEED','29','',NULL,'M',NULL,NULL,'9539404738',NULL,'2022-03-01 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(104,'A2203','FOUSIYA','41','',NULL,'F',NULL,NULL,'98468256978',NULL,'2022-03-02 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(105,'A2204','ANSHID','12','',NULL,'M',NULL,NULL,'9048541612',NULL,'2022-03-04 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(106,'A2208','AYESHA MEHADIYA','3','',NULL,'F',NULL,NULL,'9567118883',NULL,'2022-03-07 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(107,'A2209','MOHAMMED JAZEEM','1','',NULL,'M',NULL,NULL,'9567118883',NULL,'2022-03-07 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(108,'A2206','SMITHA','38','',NULL,'F',NULL,NULL,'9745357391',NULL,'2022-03-07 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(109,'A2207','AHMED','55','',NULL,'M',NULL,NULL,'9745506050',NULL,'2022-03-07 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(110,'A2210','SALEENA','38','',NULL,'F',NULL,NULL,'9633204023',NULL,'2022-03-08 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(111,'A2211','MOHD RAYYAN','2','',NULL,'M',NULL,NULL,'',NULL,'2022-03-09 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(112,'A2212','ASIYA','60','',NULL,'F',NULL,NULL,'9645363218',NULL,'2022-03-14 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(113,'A2213','SOUDA','44','',NULL,'F',NULL,NULL,'',NULL,'2022-03-14 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(114,'A2216','FOUSIYA','30','',NULL,'F',NULL,NULL,'9061429292',NULL,'2022-03-15 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(115,'A2217','FARHAN','9','',NULL,'M',NULL,NULL,'9995524277',NULL,'2022-03-15 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(116,'A2215','FIZAN','1.4','',NULL,'M',NULL,NULL,'9061429292',NULL,'2022-03-15 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(117,'A2218','JINSU','29','',NULL,'F',NULL,NULL,'8157017975',NULL,'2022-03-16 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(118,'A2219','NADIRA','33','',NULL,'F',NULL,NULL,'9400519066',NULL,'2022-03-16 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(119,'A2220','MIZYAAN','5','',NULL,'M',NULL,NULL,'9746601079',NULL,'2022-03-17 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(120,'A2221','RUKSANA','20','',NULL,'F',NULL,NULL,'7510779478',NULL,'2022-03-19 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(121,'A2222','AFEEH SADATH','9','',NULL,'M',NULL,NULL,'',NULL,'2022-03-22 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(122,'A2223','JAMEELA','36','',NULL,'F',NULL,NULL,'',NULL,'2022-03-23 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(123,'A2224','FATHIMA FIDHA','10','',NULL,'F',NULL,NULL,'',NULL,'2022-03-23 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(124,'A2225','FARIJA','36','',NULL,'F',NULL,NULL,'96933707433',NULL,'2022-03-25 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(125,'A2227','SANWAR','25','',NULL,'M',NULL,NULL,'',NULL,'2022-03-30 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(126,'A2226','FAYAS','6','',NULL,'M',NULL,NULL,'9995524277',NULL,'2022-03-30 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(127,'A2228','SALEENA','40','',NULL,'F',NULL,NULL,'9633472998',NULL,'2022-03-30 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(128,'A2230','MOHAMMED RAYAN','3','',NULL,'M',NULL,NULL,'9048465784',NULL,'2022-04-01 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(129,'A2231','SUBAIDA','55','',NULL,'F',NULL,NULL,'9647601079',NULL,'2022-04-02 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(130,'A2232','NAFEESA','47','',NULL,'F',NULL,NULL,'9895994157',NULL,'2022-04-05 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(131,'A2233','SHEHNA','18','',NULL,'F',NULL,NULL,'',NULL,'2022-04-07 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(132,'A2234','Razaana','3.6','',NULL,'F',NULL,NULL,'',NULL,'2022-04-09 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(133,'A2238','MOHAMMED FAHEEM','0.1','',NULL,'M',NULL,NULL,'7591905222',NULL,'2022-04-14 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(134,'A2236','IRFANA','26','',NULL,'F',NULL,NULL,'7356230853',NULL,'2022-04-14 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(135,'A2235','RUBA HANOON','4.6','',NULL,'F',NULL,NULL,'7356230853',NULL,'2022-04-14 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(136,'A2237','HAYA MARYAM','2','',NULL,'F',NULL,NULL,'7591905222',NULL,'2022-04-14 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(137,'A2240','NASEELA','29','',NULL,'F',NULL,NULL,'9074841426',NULL,'2022-04-18 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(138,'A2239','HASEENA','29','',NULL,'F',NULL,NULL,'7591905222',NULL,'2022-04-16 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(139,'A2241','MEHFIL','5','',NULL,'M',NULL,NULL,'9995974991',NULL,'2022-04-19 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(140,'A2242','SALEEM','42','',NULL,'M',NULL,NULL,'9745650215',NULL,'2022-04-20 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(141,'A2243','THUHFA','1.6','',NULL,'F',NULL,NULL,'9744577206',NULL,'2022-04-21 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(142,'A2244','SHAHANA','26','',NULL,'F',NULL,NULL,'9744577206',NULL,'2022-04-21 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(143,'A2245','JASEEL','9','',NULL,'M',NULL,NULL,'9048176915',NULL,'2022-04-21 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(144,'A2246','SANA SALEEM','14','',NULL,'F',NULL,NULL,'9745650215',NULL,'2022-04-23 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(145,'A2247','SUNEERA','43','',NULL,'M',NULL,NULL,'9562123760',NULL,'2022-04-29 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(146,'A2248','RENZA','2','',NULL,'F',NULL,NULL,'7356176725',NULL,'2022-05-09 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(147,'A2249','ABDUL RAZAK','35','',NULL,'M',NULL,NULL,'9895348986',NULL,'2022-05-09 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(148,'A2250','MANZOOR','27','',NULL,'M',NULL,NULL,'7365885220',NULL,'2022-05-10 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(149,'A2229','IHSAN','12','',NULL,'M',NULL,NULL,'9846227228',NULL,'2022-04-02 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(150,'A2251','RASHEED','46','',NULL,'M',NULL,NULL,'9847792874',NULL,'2022-05-12 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(151,'A2252','SUBAIDA','48','',NULL,'F',NULL,NULL,'8111824561',NULL,'2022-05-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(152,'A2205','SAFIYA PARAVOOR','71','',NULL,'F',NULL,NULL,'',NULL,'2022-05-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(153,'A2253','MARWA','19','',NULL,'F',NULL,NULL,'7558003663',NULL,'2022-05-14 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(154,'A2254','IRFAN','6','',NULL,'M',NULL,NULL,'',NULL,'2022-05-14 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(155,'A2255','MOHAMMED SHIBILI','11','',NULL,'M',NULL,NULL,'9645317154',NULL,'2022-05-16 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(156,'A2256','SHAMEENA','40','',NULL,'F',NULL,NULL,'9846571261',NULL,'2022-05-16 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(157,'A2257','SAFWAN','9','',NULL,'M',NULL,NULL,'7591905222',NULL,'2022-05-17 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(158,'A2258','AYDIN AADAM','1','',NULL,'M',NULL,NULL,'7356650463',NULL,'2022-05-17 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(159,'A2259','NOUSHAD','32','',NULL,'M',NULL,NULL,'9645451377',NULL,'2022-05-19 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(160,'A2260','LIBA','8','',NULL,'F',NULL,NULL,'',NULL,'2022-05-19 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(162,'A2261','HASEENA','34','',NULL,'F',NULL,NULL,'8592974671',NULL,'2022-05-20 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(163,'A2262','AMINU','61','',NULL,'F',NULL,NULL,'9746240179',NULL,'2022-05-20 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(164,'A2263','IBRAHIM','50','',NULL,'M',NULL,NULL,'8156846100',NULL,'2022-05-24 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(165,'A2264','MARIYAKUTTY','63','',NULL,'F',NULL,NULL,'',NULL,'2022-05-24 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(166,'A2265','SAFIYA ','26','',NULL,'F',NULL,NULL,'9995974991',NULL,'2022-05-24 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(167,'A2266','shahala','1','',NULL,'F',NULL,NULL,'9778196877',NULL,'2022-05-24 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(168,'A2267','SHARADHA','56','',NULL,'F',NULL,NULL,'8156811629',NULL,'2022-05-25 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(169,'A2268','RASIYA','39','',NULL,'F',NULL,NULL,'9645719409',NULL,'2022-05-27 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(171,'A2270','FAHMITHA','18','',NULL,'F',NULL,NULL,'9645719409',NULL,'2022-05-27 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(172,'A2271','nabeesa','55','',NULL,'F',NULL,NULL,'',NULL,'2022-05-28 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(173,'A2272','RAHMATH','36','',NULL,'F',NULL,NULL,'8129847722',NULL,'2022-05-28 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(174,'A2269','SILJI','22','',NULL,'F',NULL,NULL,'9946551981',NULL,'2022-05-30 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(175,'A2274','ABBAS','65','',NULL,'M',NULL,NULL,'9633337777',NULL,'2022-05-31 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(176,'A2273','THAMEEM DHARI','2','',NULL,'M',NULL,NULL,'9645062955',NULL,'2022-05-31 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(177,'A2275','HAAJARA','19','',NULL,'F',NULL,NULL,'9645062955',NULL,'2022-06-01 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(178,'A2276','SREELAKSHMI','21','',NULL,'F',NULL,NULL,'7994646624',NULL,'2022-06-01 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(179,'A2277','juan','2','',NULL,'M',NULL,NULL,'8129768880',NULL,'2022-06-02 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(180,'A2278','MOHAMMED SINAN','17','',NULL,'M',NULL,NULL,'9995362131',NULL,'2022-06-04 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(181,'A2279','SAIFOON','29','',NULL,'M',NULL,NULL,'8509701965',NULL,'2022-06-04 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(182,'A2280','SUBAIDA','48','',NULL,'F',NULL,NULL,'9946261795',NULL,'2022-06-07 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(183,'A2281','AJMAL','21','',NULL,'M',NULL,NULL,'9656245988',NULL,'2022-06-07 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(184,'A2282','ayisha','3','',NULL,'F',NULL,NULL,'9895928683',NULL,'2022-06-08 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(185,'A2283','NYSHA','3','',NULL,'F',NULL,NULL,'',NULL,'2022-06-08 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(186,'A2284','JINAN','24','',NULL,'F',NULL,NULL,'9633613439',NULL,'2022-06-10 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(187,'A2285','FARZANA','18','',NULL,'F',NULL,NULL,'9895771469',NULL,'2022-06-10 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(188,'A2286','SUHAS','22','',NULL,'M',NULL,NULL,'7550803733',NULL,'2022-06-10 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(189,'A2287','FAHIM','19','',NULL,'M',NULL,NULL,'6282371760',NULL,'2022-06-11 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(190,'A2288','ALI','47','',NULL,'M',NULL,NULL,'9633252121',NULL,'2022-06-11 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(191,'A2289','KHAIRUNNISA','46','',NULL,'F',NULL,NULL,'7558003663',NULL,'2022-06-11 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(192,'A2290','ALIYA','3.6','',NULL,'F',NULL,NULL,'9846023432',NULL,'2022-06-11 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(193,'A2291','KHALEELURAHMAN','13','',NULL,'M',NULL,NULL,'9048176915',NULL,'2022-06-11 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(194,'A2292','ADINAN','17','',NULL,'M',NULL,NULL,'9048541612',NULL,'2022-06-11 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(195,'A2293','MOHAMMED RAZIK','8','',NULL,'M',NULL,NULL,'9846426743',NULL,'2022-06-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(196,'A2294','HASHIM','12','',NULL,'M',NULL,NULL,'9539257967',NULL,'2022-06-15 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(197,'A2295','NADEERA','47','',NULL,'F',NULL,NULL,'9946115230',NULL,'2022-06-18 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(198,'A2296','AYESHA {NADEERA 2295}','2.5','',NULL,'F',NULL,NULL,'',NULL,'2022-06-18 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(199,'A2297','ASIYA','30','',NULL,'F',NULL,NULL,'8589900950',NULL,'2022-06-20 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(200,'A2298','SADIQ','50','',NULL,'M',NULL,NULL,'',NULL,'2022-06-21 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(201,'A2299','FATHIMA HANNA','7','',NULL,'F',NULL,NULL,'9567123330',NULL,'2022-06-21 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(202,'A2300','ABDUL RAHEEM','43','',NULL,'M',NULL,NULL,'9544873640',NULL,'2022-06-21 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(203,'A2301','SHAMEERA','32','',NULL,'F',NULL,NULL,'9544873640',NULL,'2022-06-21 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(204,'A2302','SANA FATHIMA','8','',NULL,'F',NULL,NULL,'',NULL,'2022-06-21 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(205,'A2303','SHANIBA','45','',NULL,'F',NULL,NULL,'9539174175',NULL,'2022-06-21 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(206,'A2304','NASAR','47','',NULL,'M',NULL,NULL,'9539888886',NULL,'2022-06-22 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(207,'A2305','NAJALA','37','',NULL,'F',NULL,NULL,'7356400678',NULL,'2022-06-23 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(208,'A2306','MOHD MAZIN','3','',NULL,'M',NULL,NULL,'9846624426',NULL,'2022-06-23 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(209,'A2307','HAIZAAN ADAM','3.6','',NULL,'M',NULL,NULL,'9496515062',NULL,'2022-06-25 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(210,'A2308','THAHSINA','31','',NULL,'F',NULL,NULL,'9496515062',NULL,'2022-06-25 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(211,'A2309','MOHAMMED ISHAN','8','',NULL,'M',NULL,NULL,'9846624426',NULL,'2022-06-25 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(212,'A2310','AFSAL','35','',NULL,'M',NULL,NULL,'8547719313',NULL,'2022-06-26 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(213,'A2311','MOHAMMED','0.1','',NULL,'M',NULL,NULL,'8547159500',NULL,'2022-06-27 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(214,'A2312','MOHAMMED JAISH ','7','',NULL,'M',NULL,NULL,'8547159500',NULL,'2022-07-02 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(215,'A2313','MOHAMMED AZIM','9','',NULL,'M',NULL,NULL,'9567123330',NULL,'2022-07-02 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(216,'A2314','AYASH','0.2','',NULL,'M',NULL,NULL,'8589900950',NULL,'2022-07-04 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(217,'A2315','MOHAAMMED FOUZAN','4.5','',NULL,'M',NULL,NULL,'9895771469',NULL,'2022-07-05 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(218,'A2316','ASLAM','16','',NULL,'M',NULL,NULL,'9539257967',NULL,'2022-07-05 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(219,'A2317','SHAMEENA','33','',NULL,'F',NULL,NULL,'',NULL,'2022-07-06 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(220,'A2318','RAAKHI','28','',NULL,'F',NULL,NULL,'9539626790',NULL,'2022-07-06 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(221,'A2319','ADEEB KRISHNA','9','',NULL,'M',NULL,NULL,'9048427601',NULL,'2022-07-06 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(222,'A2320','AWANIKA','2.6','',NULL,'F',NULL,NULL,'9048427601',NULL,'2022-07-06 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(223,'A2321','EHAN','1.3','',NULL,'M',NULL,NULL,'9164025500',NULL,'2022-07-08 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(224,'A2322','ASHRAF','57','',NULL,'M',NULL,NULL,'9539991222',NULL,'2022-07-08 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(225,'A2323','nuha','5','',NULL,'F',NULL,NULL,'8593073741',NULL,'2022-07-12 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(226,'A2324','NABHAAN','14','',NULL,'M',NULL,NULL,'8593073741',NULL,'2022-07-12 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(227,'A2325','ISHAAN','9','',NULL,'M',NULL,NULL,'8113956742',NULL,'2022-07-12 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(228,'A2326','LIYA','13','',NULL,'F',NULL,NULL,'',NULL,'2022-07-12 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(229,'A2327','FATHIMA MEHRIN','8','',NULL,'F',NULL,NULL,'9745378735',NULL,'2022-07-12 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(230,'A2328','MUBEENA ','35','',NULL,'F',NULL,NULL,'9745378735',NULL,'2022-07-12 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(231,'A2329','SADDAM','27','',NULL,'M',NULL,NULL,'',NULL,'2022-07-12 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(232,'A2330','NAHYAN','0.2','PERUMBAAL',NULL,'M',NULL,NULL,'9539857857',NULL,'2022-07-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(233,'A2331','ASHRAF','46','',NULL,'M',NULL,NULL,'7045200704',NULL,'2022-07-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(234,'A2332','AMISH','2.9','',NULL,'M',NULL,NULL,'9747978889',NULL,'2022-07-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(235,'A2333','SINAN','4','',NULL,'M',NULL,NULL,'9961075322',NULL,'2022-07-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(236,'A2334','SHABNA','23','',NULL,'F',NULL,NULL,'9539435860',NULL,'2022-07-14 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(237,'A2335','SHAHEEB','21','',NULL,'M',NULL,NULL,'9544594680',NULL,'2022-07-14 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(238,'A2336','SHERRY','20','',NULL,'F',NULL,NULL,'9947183868',NULL,'2022-07-16 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(239,'A2337','NAHILA FATHIMA','9','',NULL,'F',NULL,NULL,'8129865719',NULL,'2022-07-18 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(240,'A2338','AYDA','4','',NULL,'F',NULL,NULL,'',NULL,'2022-07-18 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(241,'A2339','SALAHUDHEEN','48','',NULL,'M',NULL,NULL,'7559000790',NULL,'2022-07-20 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(242,'A2340','HAMZA','55','',NULL,'M',NULL,NULL,'9746250423',NULL,'2022-07-21 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(243,'A2341','ASHWIN','14','',NULL,'M',NULL,NULL,'7994039928',NULL,'2022-07-21 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(244,'A2342','EMIN','1.9','',NULL,'M',NULL,NULL,'8943867277',NULL,'2022-07-22 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(245,'A2343','ISHA FATHIMA','9','',NULL,'F',NULL,NULL,'9946826876',NULL,'2022-07-22 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(246,'A2344','khadeeja','85','',NULL,'F',NULL,NULL,'',NULL,'2022-07-25 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(247,'A2345','RAJU','30','',NULL,'M',NULL,NULL,'6295549143',NULL,'2022-07-26 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(248,'A2346','MOHD ZIYAN','9','',NULL,'M',NULL,NULL,'9846207189',NULL,'2022-07-26 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(249,'A2347','SAJEEHA','23','',NULL,'F',NULL,NULL,'7356860306',NULL,'2022-07-27 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(250,'A2348','MOHAMMED AYDHIN','1.5','',NULL,'M',NULL,NULL,'8593986068',NULL,'2022-07-27 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(251,'A2349','RUKSANA','23','',NULL,'M',NULL,NULL,'9809388992',NULL,'2022-07-27 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(252,'A2350','HAALA','0.10','',NULL,'F',NULL,NULL,'9809388992',NULL,'2022-07-28 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(253,'A2351','UMMUHABEEBA','5.5','',NULL,'F',NULL,NULL,'9895359465',NULL,'2022-07-29 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(254,'A2352','SAFAREENA','37','',NULL,'F',NULL,NULL,'9895359465',NULL,'2022-07-29 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(255,'A2353','THAHIR','40','',NULL,'M',NULL,NULL,'9645505215',NULL,'2022-07-29 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(256,'A2354','ISMAIL','44','',NULL,'M',NULL,NULL,'9895359465',NULL,'2022-08-01 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(257,'A2355','ATHULYA','10','',NULL,'F',NULL,NULL,'9746380177',NULL,'2022-08-01 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(258,'A2356','NYLA','0.3','',NULL,'F',NULL,NULL,'9544633491',NULL,'2022-08-02 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(259,'A2357','MINZA','0.1','',NULL,'F',NULL,NULL,'9946119706',NULL,'2022-08-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(260,'A2358','AYISHA HENA','4.6','',NULL,'F',NULL,NULL,'9496652138',NULL,'2022-08-13 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(261,'A2359','FAISAL','42','',NULL,'M',NULL,NULL,'9946093728',NULL,'2022-08-15 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(262,'A2360','RABIYA','47','',NULL,'F',NULL,NULL,'9947183868',NULL,'2022-08-16 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(263,'A2361','HANIYA','1.8','',NULL,'F',NULL,NULL,'9048851032',NULL,'2022-08-17 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(264,'A2362','RAIHANATH','24','',NULL,'F',NULL,NULL,'9877799950',NULL,'2022-08-18 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(265,'A2363','JOUWHAR','25','',NULL,'M',NULL,NULL,'971556512432',NULL,'2022-08-18 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(266,'A2364','MOHAMMED HAMBAL','0.6','',NULL,'M',NULL,NULL,'9846213383',NULL,'2022-08-18 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(267,'A2365','RAHILA','11','',NULL,'F',NULL,NULL,'9846426743',NULL,'2022-08-22 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(268,'A2366','FATHIMA MINHA','12','',NULL,'F',NULL,NULL,'9895011915',NULL,'2022-08-22 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(269,'A2367','SANA','6.6','',NULL,'F',NULL,NULL,'',NULL,'2022-08-23 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(270,'A2368','MISBAH','8','',NULL,'M',NULL,NULL,'9539416395',NULL,'2022-08-23 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(271,'A2369','FATHIMA RUMANI','4.6','',NULL,'F',NULL,NULL,'9061117395',NULL,'2022-08-23 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(272,'A2370','FATHIMA FAIHA ','6','',NULL,'F',NULL,NULL,'7034666865',NULL,'2022-08-24 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(273,'A2371','SAHLA','16','',NULL,'F',NULL,NULL,'9895359465',NULL,'2022-08-29 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(274,'A2372','AROHYA','0.10','',NULL,'F',NULL,NULL,'9539626790',NULL,'2022-08-29 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(275,'A2373','JEZA FATHIMA','5.3','',NULL,'F',NULL,NULL,'9633529096',NULL,'2022-08-29 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(276,'A2374','AYYAPPAN','44','',NULL,'M',NULL,NULL,'7034121612',NULL,'2022-08-31 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL),(277,'A2375','FARHANA','26','',NULL,'F',NULL,NULL,'9846624426',NULL,'2022-08-31 00:00:00',NULL,NULL,NULL,NULL,0,NULL,NULL);
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patientdocument`
--

DROP TABLE IF EXISTS `patientdocument`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patientdocument` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `PatientId` int NOT NULL,
  `UploadedOn` datetime DEFAULT NULL,
  `LocalFileName` varchar(500) DEFAULT NULL,
  `FileName` varchar(200) DEFAULT NULL,
  `IsDeleted` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patientdocument`
--

LOCK TABLES `patientdocument` WRITE;
/*!40000 ALTER TABLE `patientdocument` DISABLE KEYS */;
INSERT INTO `patientdocument` VALUES (1,14,'2022-01-07 00:00:00','BodyPart_346d9a68-8d02-4e7b-b0ef-d949aff6e480','WhatsApp Image 2022-01-07 at 5.54.01 PM.jpeg',0),(2,14,'2022-01-07 00:00:00','BodyPart_00a298f7-a248-4928-a4d6-6a2406a6bba9','WhatsApp Image 2022-01-07 at 5.54.02 PM.jpeg',1),(3,14,'2022-01-07 00:00:00','BodyPart_20fa3e61-d2d8-4ccb-9f59-3844e6404e8a','WhatsApp Image 2022-01-07 at 5.54.02 PM.jpeg',0),(4,66,'2022-01-31 00:00:00','BodyPart_af5b3a74-93a7-4884-856a-9546f7bee092','WhatsApp Image 2022-01-31 at 4.58.39 PM.jpeg',1),(5,66,'2022-01-31 00:00:00','BodyPart_56996297-f574-400a-a353-e258718a8ae5','WhatsApp Image 2022-01-31 at 4.58.39 PM.jpeg',1),(6,66,'2022-01-31 00:00:00','BodyPart_9bd589f0-a269-4fce-b928-aba93636a29c','WhatsApp Image 2022-01-31 at 4.58.39 PM.jpeg',1),(7,66,'2022-01-31 00:00:00','BodyPart_932dc36f-947e-4369-be1f-08f5a8400b5b','WhatsApp Image 2022-01-31 at 4.58.39 PM (1).jpeg',1),(8,66,'2022-01-31 00:00:00','BodyPart_0d529d10-2c42-4648-ac1a-714700bff8c8','WhatsApp Image 2022-01-31 at 4.58.39 PM (1).jpeg',0),(9,3,'2022-05-21 00:00:00','BodyPart_2bc7d6c2-0329-452e-9c0b-ca716777b5ba','WhatsApp Image 2022-05-21 at 6.25.26 PM.jpeg',0),(10,3,'2022-05-28 00:00:00','BodyPart_607e32b2-990b-4649-8ceb-85102726a9c4','WIN_20220502_06_40_29_Pro.jpg',0),(11,192,'2022-06-20 00:00:00','BodyPart_80e74177-c7ef-4825-afa5-5d09f7d0ad9d','WhatsApp Image 2022-06-20 at 3.36.24 PM.jpeg',0),(12,192,'2022-06-20 00:00:00','BodyPart_1cc28e36-a025-4391-867c-60c3ef70749c','WhatsApp Image 2022-06-20 at 3.36.23 PM.jpeg',0),(13,187,'2022-06-20 00:00:00','BodyPart_0cbba997-f188-407d-a97e-040600fa7a05','WhatsApp Image 2022-06-20 at 6.38.09 PM.jpeg',0),(14,187,'2022-06-20 00:00:00','BodyPart_a63f6405-c799-41a1-bdfa-ca18f337d304','WhatsApp Image 2022-06-20 at 6.39.16 PM.jpeg',0),(15,187,'2022-06-20 00:00:00','BodyPart_5642aad3-16f1-4318-92e9-dfb5d9fbd007','WhatsApp Image 2022-06-20 at 6.37.54 PM.jpeg',0),(16,206,'2022-06-22 00:00:00','BodyPart_22715c41-d749-4b23-b870-5ef24774c4df','WhatsApp Image 2022-06-22 at 4.13.18 PM.jpeg',0),(17,50,'2022-06-22 00:00:00','BodyPart_c093ef20-df06-45e9-943f-663b6f243b5e','WhatsApp Image 2022-06-21 at 8.16.35 PM.jpeg',0),(18,50,'2022-06-22 00:00:00','BodyPart_32597153-75ee-41e9-97ce-32653586961a','WhatsApp Image 2022-06-21 at 10.01.03 PM.jpeg',0),(19,50,'2022-06-22 00:00:00','BodyPart_007b3f65-780f-4791-8ee8-4d6c7e762a64','WhatsApp Image 2022-06-21 at 9.59.25 PM.jpeg',0),(20,50,'2022-06-22 00:00:00','BodyPart_abd314cd-6238-43a8-a9ac-25ebf10fed9f','WhatsApp Image 2022-06-22 at 4.13.18 PM.jpeg',1),(21,147,'2022-06-22 00:00:00','BodyPart_1073e560-e5d6-4273-8ff0-d6acba18348f','WhatsApp Image 2022-06-22 at 6.25.22 PM.jpeg',0),(22,168,'2022-06-22 00:00:00','BodyPart_ebf1e4aa-ebff-4e09-bb0b-ef5d3ff819de','WhatsApp Image 2022-06-22 at 6.26.48 PM.jpeg',0),(23,86,'2022-06-22 00:00:00','BodyPart_6c4af2c7-99d4-47d3-bf7f-20d3e6218804','WhatsApp Image 2022-06-22 at 6.30.25 PM.jpeg',0),(24,187,'2022-08-25 00:00:00','BodyPart_5b17274e-13b4-4413-b12e-2d08aa4dbf65','WhatsApp Image 2022-08-25 at 5.33.21 PM (1).jpeg',0),(25,187,'2022-08-25 00:00:00','BodyPart_9d1023a6-1f8b-4a0c-8004-afaf3cebdfcb','WhatsApp Image 2022-07-11 at 3.14.22 PM.jpeg',0),(26,187,'2022-08-25 00:00:00','BodyPart_e45116ab-39a4-4acb-9e7f-b6bb6f00e5c8','WhatsApp Image 2022-08-25 at 5.33.21 PM (1).jpeg',0),(27,152,'2022-08-29 00:00:00','BodyPart_350958e9-65d0-4a59-863a-3c656010413b','WhatsApp Image 2022-08-29 at 4.59.51 PM.jpeg',0);
/*!40000 ALTER TABLE `patientdocument` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patientpayment`
--

DROP TABLE IF EXISTS `patientpayment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patientpayment` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `PatientId` int NOT NULL,
  `TransactionDate` datetime DEFAULT NULL,
  `Consultation` decimal(10,2) DEFAULT '0.00',
  `Products` decimal(10,2) DEFAULT '0.00',
  `PrevBalance` decimal(10,2) DEFAULT '0.00',
  `Paid` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=758 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patientpayment`
--

LOCK TABLES `patientpayment` WRITE;
/*!40000 ALTER TABLE `patientpayment` DISABLE KEYS */;
INSERT INTO `patientpayment` VALUES (1,1,'2021-12-18 00:00:00',100.00,150.00,0.00,0.00),(2,1,'2021-12-31 00:00:00',0.00,200.00,250.00,0.00),(3,2,'2021-12-31 00:00:00',100.00,150.00,0.00,0.00),(4,1,'2021-12-31 00:00:00',100.00,150.00,450.00,250.00),(5,4,'2021-11-13 00:00:00',100.00,150.00,0.00,250.00),(6,5,'2021-11-13 00:00:00',100.00,150.00,0.00,250.00),(7,6,'2021-11-13 00:00:00',100.00,150.00,0.00,250.00),(8,6,'2021-12-04 00:00:00',100.00,150.00,0.00,250.00),(9,7,'2021-11-13 00:00:00',100.00,200.00,0.00,300.00),(10,8,'2021-11-13 00:00:00',100.00,150.00,0.00,250.00),(11,8,'2021-12-01 00:00:00',100.00,150.00,0.00,250.00),(12,9,'2021-11-13 00:00:00',100.00,200.00,0.00,300.00),(13,9,'2021-12-06 00:00:00',100.00,200.00,0.00,300.00),(18,6,'2022-01-03 00:00:00',100.00,150.00,0.00,250.00),(17,5,'2021-11-26 00:00:00',100.00,150.00,0.00,250.00),(24,10,'2021-12-06 00:00:00',100.00,150.00,0.00,250.00),(28,10,'2021-11-15 00:00:00',100.00,150.00,0.00,250.00),(21,10,'2021-11-15 00:00:00',100.00,100.00,0.00,200.00),(22,10,'2021-11-20 00:00:00',0.00,100.00,0.00,100.00),(23,10,'2021-12-17 00:00:00',100.00,100.00,0.00,200.00),(27,10,'2021-12-27 00:00:00',0.00,50.00,0.00,50.00),(29,11,'2021-11-15 00:00:00',100.00,150.00,0.00,250.00),(30,12,'2021-11-16 00:00:00',100.00,250.00,0.00,350.00),(31,13,'2021-11-16 00:00:00',100.00,150.00,0.00,250.00),(32,14,'2021-11-16 00:00:00',100.00,150.00,0.00,250.00),(33,14,'2021-12-01 00:00:00',100.00,200.00,0.00,300.00),(34,14,'2021-12-21 00:00:00',100.00,50.00,0.00,150.00),(35,14,'2021-12-23 00:00:00',0.00,240.00,0.00,240.00),(36,15,'2021-11-18 00:00:00',100.00,150.00,0.00,250.00),(37,15,'2022-01-03 00:00:00',100.00,150.00,0.00,250.00),(38,16,'2021-11-18 00:00:00',100.00,350.00,0.00,450.00),(39,17,'2021-11-18 00:00:00',100.00,100.00,0.00,200.00),(40,18,'2021-11-18 00:00:00',100.00,150.00,0.00,250.00),(41,18,'2021-11-23 00:00:00',0.00,100.00,0.00,100.00),(42,19,'2021-11-19 00:00:00',100.00,150.00,0.00,250.00),(43,19,'2022-01-03 00:00:00',100.00,150.00,0.00,250.00),(44,21,'2021-11-19 00:00:00',100.00,100.00,0.00,200.00),(45,22,'2021-11-19 00:00:00',100.00,150.00,0.00,250.00),(46,23,'2021-11-22 00:00:00',100.00,250.00,0.00,350.00),(47,24,'2021-11-22 00:00:00',100.00,150.00,0.00,250.00),(49,25,'2021-11-22 00:00:00',100.00,250.00,0.00,350.00),(50,27,'2021-11-24 00:00:00',100.00,150.00,0.00,250.00),(51,27,'2021-11-20 00:00:00',100.00,250.00,0.00,350.00),(52,26,'2021-11-24 00:00:00',100.00,150.00,0.00,250.00),(53,19,'2022-01-17 00:00:00',100.00,150.00,0.00,250.00),(54,29,'2021-11-26 00:00:00',100.00,210.00,0.00,310.00),(55,30,'2021-11-26 00:00:00',100.00,190.00,0.00,290.00),(56,31,'2021-11-26 00:00:00',100.00,150.00,0.00,250.00),(57,32,'2021-11-27 00:00:00',0.00,0.00,0.00,0.00),(58,33,'2021-11-27 00:00:00',100.00,150.00,0.00,250.00),(59,34,'2021-11-27 00:00:00',100.00,150.00,0.00,250.00),(60,34,'2021-12-03 00:00:00',100.00,150.00,0.00,250.00),(61,35,'2021-11-27 00:00:00',100.00,100.00,0.00,200.00),(62,35,'2021-12-03 00:00:00',100.00,210.00,0.00,310.00),(63,37,'2021-12-01 00:00:00',100.00,150.00,0.00,250.00),(64,37,'2021-12-14 00:00:00',100.00,150.00,0.00,250.00),(65,38,'2021-12-01 00:00:00',100.00,200.00,0.00,300.00),(66,39,'2021-12-04 00:00:00',100.00,150.00,0.00,250.00),(67,40,'2021-12-08 00:00:00',100.00,150.00,0.00,250.00),(68,40,'2021-12-09 00:00:00',0.00,0.00,0.00,0.00),(69,40,'2021-12-11 00:00:00',100.00,50.00,0.00,150.00),(70,41,'2021-12-09 00:00:00',100.00,150.00,0.00,250.00),(71,42,'2021-12-10 00:00:00',100.00,150.00,0.00,250.00),(72,43,'2021-12-10 00:00:00',100.00,150.00,0.00,250.00),(73,44,'2021-12-10 00:00:00',100.00,150.00,0.00,250.00),(74,45,'2021-12-13 00:00:00',100.00,150.00,0.00,250.00),(75,46,'2021-12-13 00:00:00',100.00,150.00,0.00,250.00),(76,46,'2022-01-06 00:00:00',100.00,150.00,0.00,250.00),(77,47,'2021-12-14 00:00:00',100.00,120.00,0.00,220.00),(78,47,'2021-12-31 00:00:00',100.00,120.00,0.00,220.00),(79,48,'2021-12-17 00:00:00',100.00,100.00,0.00,200.00),(80,48,'2021-12-21 00:00:00',0.00,60.00,0.00,60.00),(81,49,'2021-12-18 00:00:00',100.00,120.00,0.00,220.00),(82,49,'2022-01-13 00:00:00',100.00,150.00,0.00,250.00),(83,50,'2021-12-18 00:00:00',100.00,150.00,0.00,250.00),(84,50,'2021-12-30 00:00:00',100.00,100.00,0.00,200.00),(85,51,'2021-12-24 00:00:00',100.00,150.00,0.00,250.00),(86,52,'2021-12-24 00:00:00',100.00,100.00,0.00,200.00),(87,53,'2021-12-27 00:00:00',100.00,120.00,0.00,0.00),(88,54,'2021-12-27 00:00:00',100.00,100.00,0.00,0.00),(89,55,'2021-12-30 00:00:00',100.00,200.00,0.00,300.00),(90,56,'2021-12-29 00:00:00',100.00,100.00,0.00,200.00),(91,57,'2022-01-03 00:00:00',100.00,150.00,0.00,250.00),(92,57,'2022-01-17 00:00:00',0.00,50.00,0.00,50.00),(93,58,'2022-01-04 00:00:00',100.00,100.00,0.00,200.00),(142,59,'2022-02-10 00:00:00',100.00,150.00,0.00,250.00),(95,60,'2022-01-05 00:00:00',100.00,120.00,0.00,220.00),(96,61,'2022-01-06 00:00:00',100.00,130.00,0.00,230.00),(97,61,'2022-01-29 00:00:00',100.00,100.00,0.00,200.00),(98,62,'2022-01-06 00:00:00',100.00,150.00,0.00,250.00),(99,63,'2022-01-11 00:00:00',100.00,200.00,0.00,300.00),(100,64,'2022-01-10 00:00:00',100.00,120.00,0.00,220.00),(101,65,'2022-01-10 00:00:00',100.00,120.00,0.00,220.00),(102,66,'2022-01-10 00:00:00',100.00,250.00,0.00,350.00),(103,66,'2022-01-26 00:00:00',0.00,360.00,0.00,360.00),(104,67,'2022-01-11 00:00:00',100.00,150.00,0.00,250.00),(105,68,'2022-01-11 00:00:00',100.00,100.00,0.00,200.00),(106,69,'2022-01-12 00:00:00',0.00,100.00,0.00,100.00),(107,70,'2022-01-13 00:00:00',100.00,150.00,0.00,250.00),(108,70,'2022-01-21 00:00:00',100.00,150.00,0.00,250.00),(109,71,'2022-01-14 00:00:00',100.00,100.00,0.00,200.00),(110,72,'2022-01-14 00:00:00',100.00,150.00,0.00,250.00),(111,73,'2022-01-14 00:00:00',100.00,150.00,0.00,250.00),(112,73,'2022-01-14 00:00:00',100.00,150.00,0.00,250.00),(113,74,'2022-01-21 00:00:00',100.00,150.00,0.00,250.00),(114,75,'2022-01-22 00:00:00',100.00,150.00,0.00,250.00),(115,76,'2022-01-22 00:00:00',100.00,120.00,0.00,220.00),(116,77,'2022-01-24 00:00:00',100.00,120.00,0.00,220.00),(117,78,'2022-01-26 00:00:00',100.00,150.00,0.00,250.00),(118,80,'2022-01-29 00:00:00',100.00,100.00,0.00,200.00),(119,81,'2022-01-31 00:00:00',100.00,100.00,0.00,150.00),(120,82,'2022-01-22 00:00:00',0.00,100.00,0.00,100.00),(121,83,'2022-02-01 00:00:00',100.00,120.00,0.00,220.00),(122,70,'2022-02-01 00:00:00',100.00,150.00,0.00,250.00),(123,46,'2022-02-01 00:00:00',100.00,130.00,0.00,230.00),(125,80,'2022-02-02 00:00:00',0.00,50.00,0.00,50.00),(126,84,'2021-11-15 00:00:00',100.00,100.00,0.00,200.00),(127,84,'2021-11-20 00:00:00',0.00,100.00,0.00,100.00),(128,84,'2021-12-06 00:00:00',100.00,150.00,0.00,250.00),(129,84,'2021-12-17 00:00:00',100.00,100.00,0.00,200.00),(131,84,'2022-01-21 00:00:00',100.00,150.00,0.00,250.00),(132,84,'2021-12-27 00:00:00',0.00,50.00,0.00,50.00),(133,84,'2022-02-03 00:00:00',100.00,150.00,0.00,250.00),(134,85,'2022-02-03 00:00:00',100.00,150.00,0.00,250.00),(137,86,'2022-02-04 00:00:00',100.00,150.00,0.00,250.00),(136,87,'2022-02-04 00:00:00',100.00,100.00,0.00,200.00),(138,79,'2022-02-05 00:00:00',100.00,300.00,0.00,400.00),(139,14,'2022-02-04 00:00:00',100.00,120.00,0.00,220.00),(140,88,'2022-02-08 00:00:00',100.00,150.00,0.00,250.00),(141,80,'2022-02-08 00:00:00',100.00,100.00,0.00,200.00),(143,59,'2022-01-04 00:00:00',100.00,150.00,0.00,250.00),(144,67,'2022-02-11 00:00:00',100.00,150.00,0.00,250.00),(145,19,'2022-01-28 00:00:00',100.00,120.00,0.00,220.00),(146,19,'2022-02-10 00:00:00',100.00,150.00,0.00,250.00),(147,89,'2022-02-10 00:00:00',100.00,170.00,0.00,270.00),(148,90,'2022-02-10 00:00:00',100.00,100.00,0.00,200.00),(149,67,'2022-02-11 00:00:00',0.00,50.00,0.00,50.00),(150,91,'2022-02-12 00:00:00',100.00,150.00,0.00,250.00),(151,92,'2022-02-12 00:00:00',100.00,120.00,0.00,220.00),(152,93,'2022-02-12 00:00:00',100.00,210.00,0.00,310.00),(153,83,'2022-02-12 00:00:00',100.00,120.00,0.00,220.00),(154,86,'2022-02-12 00:00:00',100.00,150.00,0.00,250.00),(155,49,'2022-02-14 00:00:00',100.00,200.00,0.00,300.00),(156,94,'2022-02-16 00:00:00',100.00,120.00,0.00,220.00),(157,95,'2022-02-16 00:00:00',100.00,130.00,0.00,230.00),(158,96,'2022-02-16 00:00:00',100.00,120.00,0.00,220.00),(159,97,'2022-02-18 00:00:00',100.00,150.00,0.00,250.00),(160,67,'2022-02-18 00:00:00',100.00,100.00,0.00,200.00),(161,70,'2022-02-18 00:00:00',100.00,180.00,0.00,280.00),(162,50,'2022-02-19 00:00:00',100.00,150.00,0.00,250.00),(163,27,'2022-02-21 00:00:00',100.00,150.00,0.00,250.00),(164,80,'2022-02-21 00:00:00',100.00,120.00,0.00,220.00),(165,98,'2022-02-22 00:00:00',100.00,150.00,0.00,250.00),(166,85,'2022-02-21 00:00:00',100.00,150.00,0.00,250.00),(167,99,'2022-02-22 00:00:00',100.00,180.00,0.00,280.00),(168,100,'2022-02-23 00:00:00',100.00,180.00,0.00,280.00),(169,88,'2022-02-23 00:00:00',100.00,150.00,0.00,250.00),(170,84,'2022-02-24 00:00:00',100.00,150.00,0.00,250.00),(171,91,'2022-02-24 00:00:00',100.00,120.00,0.00,220.00),(172,101,'2022-02-24 00:00:00',100.00,120.00,0.00,220.00),(173,102,'2022-02-26 00:00:00',100.00,100.00,0.00,200.00),(174,67,'2022-02-26 00:00:00',100.00,120.00,0.00,220.00),(175,86,'2022-02-26 00:00:00',0.00,50.00,0.00,50.00),(186,35,'2022-01-22 00:00:00',100.00,380.00,0.00,480.00),(181,27,'2022-02-28 00:00:00',0.00,70.00,0.00,70.00),(178,34,'2022-02-28 00:00:00',100.00,150.00,0.00,250.00),(179,35,'2022-02-28 00:00:00',100.00,150.00,0.00,250.00),(180,89,'2022-02-28 00:00:00',100.00,160.00,0.00,260.00),(182,50,'2022-03-01 00:00:00',100.00,70.00,0.00,170.00),(183,99,'2022-03-01 00:00:00',0.00,120.00,0.00,120.00),(184,103,'2022-03-01 00:00:00',100.00,150.00,0.00,250.00),(185,104,'2022-03-02 00:00:00',100.00,100.00,0.00,0.00),(187,35,'2022-03-02 00:00:00',0.00,290.00,0.00,290.00),(188,86,'2022-03-03 00:00:00',100.00,120.00,0.00,220.00),(189,105,'2022-03-04 00:00:00',100.00,100.00,0.00,200.00),(190,107,'2022-03-07 00:00:00',100.00,50.00,0.00,150.00),(191,106,'2022-03-07 00:00:00',100.00,50.00,0.00,150.00),(192,100,'2022-03-07 00:00:00',0.00,60.00,0.00,60.00),(193,27,'2022-03-07 00:00:00',100.00,210.00,0.00,310.00),(194,104,'2022-03-08 00:00:00',0.00,70.00,200.00,270.00),(195,70,'2022-03-07 00:00:00',100.00,150.00,0.00,250.00),(196,109,'2022-03-07 00:00:00',100.00,150.00,0.00,250.00),(197,74,'2022-03-05 00:00:00',100.00,200.00,0.00,300.00),(198,110,'2022-03-08 00:00:00',100.00,80.00,0.00,180.00),(199,103,'2022-03-08 00:00:00',100.00,270.00,0.00,370.00),(200,67,'2022-03-08 00:00:00',0.00,40.00,0.00,40.00),(201,102,'2022-03-08 00:00:00',100.00,100.00,0.00,200.00),(202,91,'2022-03-09 00:00:00',100.00,100.00,0.00,200.00),(204,63,'2022-03-09 00:00:00',300.00,960.00,0.00,1260.00),(205,111,'2022-03-09 00:00:00',0.00,60.00,0.00,60.00),(206,110,'2022-03-09 00:00:00',0.00,60.00,0.00,60.00),(207,108,'2022-03-09 00:00:00',100.00,180.00,0.00,280.00),(208,50,'2022-03-09 00:00:00',0.00,120.00,0.00,120.00),(209,14,'2022-03-05 00:00:00',100.00,100.00,0.00,200.00),(210,67,'2022-03-12 00:00:00',100.00,100.00,0.00,200.00),(211,110,'2022-03-11 00:00:00',100.00,250.00,0.00,350.00),(212,108,'2022-03-11 00:00:00',0.00,30.00,0.00,30.00),(213,100,'2022-03-14 00:00:00',0.00,70.00,0.00,70.00),(214,112,'2022-03-14 00:00:00',100.00,150.00,0.00,250.00),(215,113,'2022-03-14 00:00:00',100.00,120.00,0.00,220.00),(216,35,'2022-03-14 00:00:00',100.00,150.00,0.00,250.00),(217,34,'2022-03-14 00:00:00',100.00,120.00,0.00,220.00),(218,80,'2022-03-14 00:00:00',100.00,120.00,0.00,220.00),(219,49,'2022-03-15 00:00:00',100.00,120.00,0.00,220.00),(220,114,'2022-03-15 00:00:00',100.00,50.00,0.00,150.00),(221,115,'2022-03-15 00:00:00',100.00,120.00,0.00,220.00),(222,117,'2022-03-16 00:00:00',100.00,100.00,0.00,200.00),(223,118,'2022-03-16 00:00:00',100.00,150.00,0.00,250.00),(224,116,'2022-03-15 00:00:00',100.00,50.00,0.00,150.00),(232,50,'2022-03-15 00:00:00',0.00,60.00,0.00,60.00),(226,104,'2022-03-14 00:00:00',1.00,0.00,0.00,1.00),(227,119,'2022-03-17 00:00:00',100.00,120.00,0.00,220.00),(228,96,'2022-03-17 00:00:00',100.00,50.00,0.00,150.00),(229,94,'2022-03-17 00:00:00',50.00,50.00,0.00,100.00),(230,108,'2022-03-18 00:00:00',100.00,120.00,0.00,220.00),(273,27,'2022-03-16 00:00:00',0.00,60.00,0.00,60.00),(233,120,'2022-03-19 00:00:00',100.00,100.00,0.00,200.00),(234,116,'2022-03-19 00:00:00',0.00,50.00,0.00,50.00),(235,19,'2022-03-19 00:00:00',100.00,210.00,0.00,310.00),(236,89,'2022-03-19 00:00:00',100.00,170.00,0.00,270.00),(237,102,'2022-03-22 00:00:00',100.00,150.00,0.00,250.00),(238,67,'2022-03-22 00:00:00',100.00,100.00,0.00,200.00),(239,121,'2022-03-22 00:00:00',100.00,150.00,0.00,250.00),(240,122,'2022-03-23 00:00:00',100.00,100.00,0.00,200.00),(241,123,'2022-03-23 00:00:00',100.00,100.00,0.00,200.00),(242,112,'2022-03-23 00:00:00',100.00,150.00,0.00,250.00),(243,70,'2022-03-23 00:00:00',100.00,120.00,0.00,220.00),(244,120,'2022-03-24 00:00:00',0.00,80.00,0.00,80.00),(245,18,'2022-01-18 00:00:00',100.00,120.00,0.00,220.00),(246,18,'2022-03-24 00:00:00',100.00,50.00,0.00,150.00),(256,124,'2022-03-25 00:00:00',100.00,150.00,0.00,250.00),(249,50,'2022-03-25 00:00:00',100.00,120.00,0.00,220.00),(272,49,'2022-03-25 00:00:00',0.00,60.00,0.00,60.00),(251,105,'2022-03-25 00:00:00',100.00,130.00,0.00,230.00),(252,65,'2022-03-25 00:00:00',100.00,120.00,0.00,220.00),(253,31,'2022-03-25 00:00:00',100.00,120.00,0.00,200.00),(254,109,'2022-03-26 00:00:00',100.00,150.00,0.00,250.00),(255,117,'2022-03-26 00:00:00',100.00,80.00,0.00,180.00),(257,117,'2022-03-30 00:00:00',0.00,120.00,0.00,120.00),(258,67,'2022-03-30 00:00:00',0.00,150.00,0.00,150.00),(267,125,'2022-03-30 00:00:00',100.00,50.00,0.00,150.00),(266,114,'2022-03-30 00:00:00',100.00,80.00,0.00,180.00),(261,115,'2022-03-30 00:00:00',100.00,100.00,0.00,200.00),(262,126,'2022-03-30 00:00:00',100.00,100.00,0.00,200.00),(263,15,'2022-03-30 00:00:00',100.00,120.00,0.00,220.00),(264,121,'2022-03-30 00:00:00',0.00,150.00,0.00,150.00),(265,102,'2022-03-30 00:00:00',0.00,150.00,0.00,150.00),(268,127,'2022-03-31 00:00:00',100.00,140.00,0.00,240.00),(271,83,'2022-03-22 00:00:00',100.00,120.00,0.00,220.00),(274,35,'2022-04-01 00:00:00',100.00,170.00,0.00,270.00),(275,112,'2022-04-01 00:00:00',0.00,50.00,0.00,50.00),(276,128,'2022-04-01 00:00:00',100.00,50.00,0.00,150.00),(277,97,'2022-04-02 00:00:00',100.00,80.00,0.00,180.00),(278,129,'2022-04-02 00:00:00',100.00,250.00,0.00,350.00),(279,80,'2022-04-04 00:00:00',100.00,100.00,0.00,200.00),(280,104,'2022-04-04 00:00:00',0.00,100.00,0.00,100.00),(281,130,'2022-04-05 00:00:00',100.00,150.00,0.00,250.00),(282,6,'2022-04-05 00:00:00',100.00,100.00,0.00,200.00),(283,131,'2022-04-07 00:00:00',100.00,120.00,0.00,220.00),(284,86,'2022-04-06 00:00:00',100.00,150.00,0.00,250.00),(286,50,'2022-04-07 00:00:00',0.00,120.00,0.00,120.00),(287,102,'2022-04-07 00:00:00',0.00,120.00,0.00,120.00),(288,132,'2022-04-09 00:00:00',100.00,120.00,0.00,220.00),(289,114,'2022-04-12 00:00:00',100.00,120.00,0.00,220.00),(290,116,'2022-04-12 00:00:00',100.00,60.00,0.00,160.00),(291,80,'2022-04-12 00:00:00',0.00,100.00,0.00,100.00),(292,109,'2022-04-14 00:00:00',100.00,170.00,0.00,270.00),(293,134,'2022-04-14 00:00:00',100.00,120.00,0.00,220.00),(294,135,'2022-04-14 00:00:00',100.00,100.00,0.00,200.00),(295,136,'2022-04-14 00:00:00',100.00,80.00,0.00,180.00),(296,133,'2022-04-14 00:00:00',100.00,50.00,0.00,150.00),(297,137,'2022-04-18 00:00:00',100.00,150.00,0.00,250.00),(298,102,'2022-04-16 00:00:00',100.00,120.00,0.00,220.00),(301,67,'2022-04-16 00:00:00',100.00,200.00,0.00,300.00),(300,138,'2022-04-16 00:00:00',100.00,120.00,0.00,220.00),(302,136,'2022-04-16 00:00:00',0.00,20.00,0.00,20.00),(303,136,'2022-04-18 00:00:00',0.00,60.00,0.00,60.00),(304,84,'2022-04-19 00:00:00',100.00,150.00,0.00,250.00),(306,129,'2022-04-15 00:00:00',100.00,50.00,0.00,150.00),(307,139,'2022-04-19 00:00:00',100.00,100.00,0.00,200.00),(308,140,'2022-04-20 00:00:00',100.00,100.00,0.00,200.00),(309,35,'2022-04-20 00:00:00',100.00,180.00,0.00,280.00),(314,143,'2022-04-22 00:00:00',100.00,50.00,0.00,150.00),(313,49,'2022-04-22 00:00:00',100.00,50.00,0.00,150.00),(312,50,'2022-04-22 00:00:00',100.00,150.00,0.00,250.00),(315,139,'2022-04-22 00:00:00',0.00,30.00,0.00,30.00),(316,144,'2022-04-23 00:00:00',100.00,100.00,0.00,200.00),(317,140,'2022-04-23 00:00:00',0.00,60.00,0.00,60.00),(318,140,'2022-04-27 00:00:00',0.00,60.00,0.00,60.00),(319,105,'2022-04-23 00:00:00',100.00,130.00,0.00,230.00),(320,86,'2022-04-25 00:00:00',0.00,50.00,0.00,50.00),(321,130,'2022-04-27 00:00:00',100.00,120.00,0.00,220.00),(322,145,'2022-04-29 00:00:00',100.00,120.00,0.00,220.00),(323,129,'2022-04-30 00:00:00',100.00,250.00,0.00,350.00),(325,34,'2022-04-20 00:00:00',100.00,120.00,0.00,220.00),(326,141,'2022-04-21 00:00:00',50.00,100.00,0.00,150.00),(327,142,'2022-04-21 00:00:00',50.00,100.00,0.00,150.00),(328,146,'2022-05-09 00:00:00',100.00,150.00,0.00,250.00),(329,86,'2022-05-02 00:00:00',100.00,120.00,0.00,220.00),(330,50,'2022-05-02 00:00:00',100.00,50.00,0.00,150.00),(331,147,'2022-05-09 00:00:00',100.00,170.00,0.00,270.00),(332,140,'2022-05-09 00:00:00',100.00,200.00,0.00,300.00),(333,144,'2022-05-09 00:00:00',100.00,120.00,0.00,220.00),(334,35,'2022-05-09 00:00:00',100.00,220.00,0.00,320.00),(335,148,'2022-05-10 00:00:00',100.00,150.00,0.00,250.00),(336,84,'2022-05-10 00:00:00',100.00,300.00,0.00,400.00),(337,102,'2022-05-10 00:00:00',0.00,50.00,0.00,50.00),(338,67,'2022-05-10 00:00:00',100.00,150.00,0.00,250.00),(339,141,'2022-05-12 00:00:00',100.00,50.00,0.00,150.00),(340,142,'2022-05-12 00:00:00',100.00,50.00,0.00,150.00),(341,67,'2022-05-11 00:00:00',0.00,30.00,0.00,30.00),(342,149,'2022-05-11 00:00:00',100.00,300.00,0.00,400.00),(343,150,'2022-05-12 00:00:00',100.00,120.00,0.00,220.00),(344,151,'2022-05-13 00:00:00',100.00,120.00,0.00,220.00),(345,121,'2022-05-13 00:00:00',100.00,150.00,0.00,250.00),(346,3,'2022-05-13 00:00:00',2.00,0.00,0.00,2.00),(347,146,'2022-05-13 00:00:00',0.00,30.00,0.00,30.00),(349,66,'2022-05-14 00:00:00',200.00,400.00,0.00,600.00),(350,152,'2022-05-13 00:00:00',100.00,200.00,0.00,300.00),(351,153,'2022-05-14 00:00:00',100.00,220.00,0.00,320.00),(352,112,'2022-05-14 00:00:00',100.00,100.00,0.00,200.00),(353,155,'2022-05-16 00:00:00',100.00,150.00,0.00,250.00),(354,156,'2022-05-16 00:00:00',100.00,150.00,0.00,250.00),(356,157,'2022-05-17 00:00:00',100.00,100.00,0.00,200.00),(357,50,'2022-05-17 00:00:00',100.00,150.00,0.00,250.00),(358,105,'2022-05-17 00:00:00',100.00,150.00,0.00,250.00),(359,47,'2022-05-17 00:00:00',100.00,150.00,0.00,250.00),(360,49,'2022-05-17 00:00:00',100.00,50.00,0.00,150.00),(361,134,'2022-05-17 00:00:00',100.00,0.00,0.00,100.00),(362,158,'2022-05-17 00:00:00',100.00,120.00,0.00,220.00),(363,130,'2022-05-18 00:00:00',100.00,150.00,0.00,250.00),(365,145,'2022-05-18 00:00:00',100.00,120.00,0.00,220.00),(366,159,'2022-05-19 00:00:00',100.00,80.00,0.00,180.00),(367,41,'2022-05-19 00:00:00',100.00,100.00,0.00,200.00),(368,67,'2022-05-19 00:00:00',0.00,110.00,0.00,110.00),(369,160,'2022-05-19 00:00:00',100.00,200.00,0.00,300.00),(370,144,'2022-05-20 00:00:00',100.00,150.00,0.00,250.00),(375,163,'2022-05-20 00:00:00',100.00,100.00,0.00,200.00),(372,162,'2022-05-20 00:00:00',100.00,100.00,0.00,200.00),(373,112,'2022-05-20 00:00:00',0.00,60.00,0.00,60.00),(374,140,'2022-05-20 00:00:00',100.00,400.00,0.00,500.00),(376,67,'2022-05-23 00:00:00',0.00,100.00,0.00,100.00),(377,50,'2022-05-23 00:00:00',0.00,80.00,0.00,80.00),(378,150,'2022-05-23 00:00:00',100.00,120.00,0.00,220.00),(379,164,'2022-05-24 00:00:00',100.00,120.00,0.00,220.00),(380,165,'2022-05-24 00:00:00',100.00,100.00,0.00,200.00),(381,166,'2022-05-24 00:00:00',100.00,100.00,0.00,200.00),(382,167,'2022-05-24 00:00:00',100.00,80.00,0.00,180.00),(383,168,'2022-05-25 00:00:00',100.00,180.00,0.00,280.00),(384,151,'2022-05-26 00:00:00',100.00,100.00,0.00,200.00),(385,135,'2022-05-26 00:00:00',100.00,300.00,0.00,400.00),(386,94,'2022-05-26 00:00:00',100.00,100.00,0.00,200.00),(387,96,'2022-05-26 00:00:00',100.00,80.00,0.00,180.00),(388,169,'2022-05-27 00:00:00',100.00,150.00,0.00,250.00),(389,171,'2022-05-27 00:00:00',100.00,80.00,0.00,180.00),(390,86,'2022-05-27 00:00:00',100.00,150.00,0.00,250.00),(391,35,'2022-05-27 00:00:00',100.00,220.00,0.00,320.00),(392,172,'2022-05-28 00:00:00',100.00,100.00,0.00,200.00),(393,173,'2022-05-28 00:00:00',100.00,100.00,0.00,200.00),(394,159,'2022-05-30 00:00:00',100.00,100.00,0.00,200.00),(395,40,'2022-05-30 00:00:00',100.00,170.00,0.00,270.00),(396,174,'2022-05-30 00:00:00',100.00,120.00,0.00,220.00),(397,167,'2022-05-30 00:00:00',0.00,30.00,0.00,30.00),(398,175,'2022-05-31 00:00:00',100.00,120.00,0.00,220.00),(399,67,'2022-05-31 00:00:00',100.00,100.00,0.00,200.00),(403,176,'2022-05-31 00:00:00',100.00,100.00,0.00,200.00),(404,177,'2022-06-01 00:00:00',100.00,100.00,0.00,200.00),(402,135,'2022-05-31 00:00:00',100.00,120.00,0.00,220.00),(405,178,'2022-06-01 00:00:00',100.00,100.00,0.00,200.00),(406,179,'2022-06-02 00:00:00',100.00,120.00,0.00,220.00),(407,180,'2022-06-04 00:00:00',100.00,300.00,0.00,400.00),(408,181,'2022-06-04 00:00:00',100.00,120.00,0.00,220.00),(409,50,'2022-06-06 00:00:00',100.00,100.00,0.00,200.00),(410,49,'2022-06-06 00:00:00',100.00,100.00,0.00,200.00),(411,160,'2022-06-06 00:00:00',100.00,100.00,0.00,200.00),(412,183,'2022-06-07 00:00:00',100.00,120.00,0.00,220.00),(413,182,'2022-06-07 00:00:00',100.00,120.00,0.00,220.00),(415,149,'2022-06-07 00:00:00',100.00,300.00,0.00,400.00),(416,168,'2022-06-07 00:00:00',100.00,180.00,0.00,280.00),(417,184,'2022-06-08 00:00:00',100.00,100.00,0.00,200.00),(418,185,'2022-06-08 00:00:00',100.00,100.00,0.00,200.00),(419,102,'2022-06-08 00:00:00',100.00,120.00,0.00,220.00),(420,67,'2022-06-08 00:00:00',100.00,120.00,0.00,220.00),(421,151,'2022-06-09 00:00:00',100.00,120.00,0.00,220.00),(422,185,'2022-06-09 00:00:00',0.00,50.00,0.00,50.00),(423,150,'2022-06-09 00:00:00',100.00,150.00,0.00,250.00),(424,169,'2022-06-10 00:00:00',100.00,130.00,0.00,230.00),(425,186,'2022-06-10 00:00:00',100.00,220.00,0.00,320.00),(430,27,'2022-06-10 00:00:00',100.00,50.00,0.00,150.00),(428,18,'2022-06-10 00:00:00',100.00,50.00,0.00,150.00),(431,187,'2022-06-10 00:00:00',100.00,120.00,0.00,220.00),(432,188,'2022-06-10 00:00:00',100.00,50.00,0.00,150.00),(433,189,'2022-06-11 00:00:00',100.00,100.00,0.00,200.00),(434,190,'2022-06-11 00:00:00',100.00,100.00,0.00,200.00),(435,191,'2022-06-11 00:00:00',100.00,150.00,0.00,250.00),(436,153,'2022-06-11 00:00:00',100.00,250.00,0.00,350.00),(437,192,'2022-06-11 00:00:00',100.00,80.00,0.00,180.00),(438,193,'2022-06-11 00:00:00',100.00,100.00,0.00,200.00),(439,143,'2022-06-11 00:00:00',100.00,80.00,0.00,180.00),(447,195,'2022-06-13 00:00:00',100.00,100.00,0.00,200.00),(441,50,'2022-06-11 00:00:00',0.00,150.00,0.00,150.00),(442,194,'2022-06-11 00:00:00',100.00,100.00,0.00,200.00),(443,166,'2022-06-11 00:00:00',100.00,100.00,0.00,200.00),(448,117,'2022-06-13 00:00:00',100.00,150.00,0.00,250.00),(445,177,'2022-06-11 00:00:00',100.00,100.00,0.00,200.00),(446,133,'2022-06-11 00:00:00',100.00,60.00,0.00,160.00),(449,114,'2022-06-13 00:00:00',100.00,100.00,0.00,200.00),(450,189,'2022-06-14 00:00:00',0.00,30.00,0.00,30.00),(451,174,'2022-06-14 00:00:00',100.00,230.00,0.00,330.00),(452,192,'2022-06-15 00:00:00',0.00,100.00,0.00,100.00),(453,163,'2022-06-15 00:00:00',100.00,100.00,0.00,200.00),(454,196,'2022-06-15 00:00:00',100.00,100.00,0.00,200.00),(455,65,'2022-06-16 00:00:00',100.00,100.00,0.00,200.00),(456,121,'2022-06-16 00:00:00',100.00,120.00,0.00,220.00),(457,168,'2022-06-16 00:00:00',0.00,120.00,0.00,120.00),(458,154,'2022-06-16 00:00:00',100.00,250.00,0.00,350.00),(459,117,'2022-06-17 00:00:00',0.00,80.00,0.00,80.00),(460,160,'2022-06-17 00:00:00',100.00,400.00,0.00,500.00),(461,166,'2022-06-17 00:00:00',0.00,100.00,0.00,100.00),(462,197,'2022-06-18 00:00:00',100.00,150.00,0.00,250.00),(463,198,'2022-06-18 00:00:00',100.00,50.00,0.00,150.00),(468,192,'2022-06-18 00:00:00',0.00,50.00,0.00,50.00),(465,40,'2022-06-18 00:00:00',100.00,300.00,0.00,400.00),(466,146,'2022-06-18 00:00:00',100.00,100.00,0.00,200.00),(467,121,'2022-06-18 00:00:00',0.00,50.00,0.00,50.00),(469,192,'2022-06-20 00:00:00',0.00,250.00,0.00,250.00),(472,199,'2022-06-20 00:00:00',100.00,100.00,0.00,200.00),(471,50,'2022-06-20 00:00:00',0.00,80.00,0.00,80.00),(473,187,'2022-06-20 00:00:00',0.00,100.00,0.00,100.00),(474,176,'2022-06-21 00:00:00',100.00,100.00,0.00,200.00),(475,147,'2022-06-21 00:00:00',100.00,170.00,0.00,270.00),(477,200,'2022-06-21 00:00:00',100.00,150.00,0.00,250.00),(478,201,'2022-06-21 00:00:00',100.00,100.00,0.00,200.00),(479,185,'2022-06-21 00:00:00',100.00,260.00,0.00,360.00),(480,202,'2022-06-21 00:00:00',100.00,150.00,0.00,250.00),(481,203,'2022-06-21 00:00:00',100.00,50.00,0.00,150.00),(482,204,'2022-06-21 00:00:00',100.00,50.00,0.00,150.00),(484,205,'2022-06-21 00:00:00',100.00,150.00,0.00,250.00),(485,169,'2022-06-22 00:00:00',100.00,130.00,0.00,230.00),(486,206,'2022-06-22 00:00:00',100.00,200.00,0.00,300.00),(487,199,'2022-06-22 00:00:00',100.00,100.00,0.00,200.00),(488,144,'2022-06-23 00:00:00',100.00,150.00,0.00,250.00),(489,175,'2022-06-23 00:00:00',100.00,200.00,0.00,300.00),(490,50,'2022-06-23 00:00:00',0.00,60.00,0.00,60.00),(491,94,'2022-06-23 00:00:00',100.00,80.00,0.00,180.00),(492,119,'2022-06-23 00:00:00',100.00,100.00,0.00,200.00),(493,207,'2022-06-23 00:00:00',100.00,150.00,0.00,250.00),(494,208,'2022-06-23 00:00:00',100.00,100.00,0.00,200.00),(496,199,'2022-06-24 00:00:00',0.00,40.00,0.00,40.00),(497,209,'2022-06-25 00:00:00',100.00,80.00,0.00,180.00),(498,210,'2022-06-25 00:00:00',100.00,120.00,0.00,220.00),(499,199,'2022-06-25 00:00:00',0.00,75.00,0.00,75.00),(500,177,'2022-06-25 00:00:00',100.00,100.00,0.00,200.00),(501,117,'2022-06-25 00:00:00',100.00,120.00,0.00,220.00),(502,50,'2022-06-25 00:00:00',0.00,150.00,0.00,150.00),(503,61,'2022-06-25 00:00:00',100.00,150.00,0.00,250.00),(504,211,'2022-06-25 00:00:00',100.00,100.00,0.00,200.00),(505,212,'2022-06-26 00:00:00',100.00,100.00,0.00,200.00),(506,164,'2022-06-27 00:00:00',100.00,130.00,0.00,230.00),(507,213,'2022-06-27 00:00:00',100.00,70.00,0.00,170.00),(508,199,'2022-06-27 00:00:00',0.00,80.00,0.00,80.00),(509,198,'2022-06-28 00:00:00',100.00,100.00,0.00,200.00),(510,191,'2022-06-28 00:00:00',100.00,150.00,0.00,250.00),(511,153,'2022-06-28 00:00:00',100.00,200.00,0.00,300.00),(512,65,'2022-06-27 00:00:00',0.00,120.00,0.00,120.00),(514,146,'2022-06-27 00:00:00',0.00,200.00,0.00,500.00),(515,45,'2022-06-30 00:00:00',100.00,120.00,0.00,220.00),(516,45,'2022-01-26 00:00:00',100.00,150.00,0.00,250.00),(517,97,'2022-07-01 00:00:00',100.00,150.00,0.00,250.00),(518,67,'2022-07-02 00:00:00',100.00,200.00,0.00,300.00),(519,151,'2022-07-02 00:00:00',100.00,200.00,0.00,300.00),(520,214,'2022-07-02 00:00:00',100.00,100.00,0.00,200.00),(521,67,'2022-07-02 00:00:00',0.00,110.00,0.00,110.00),(522,177,'2022-07-02 00:00:00',0.00,100.00,0.00,100.00),(523,102,'2022-07-02 00:00:00',100.00,100.00,0.00,200.00),(524,168,'2022-07-02 00:00:00',100.00,150.00,0.00,250.00),(525,150,'2022-07-02 00:00:00',100.00,180.00,0.00,280.00),(526,215,'2022-07-02 00:00:00',100.00,100.00,0.00,200.00),(527,139,'2022-07-02 00:00:00',100.00,100.00,0.00,200.00),(528,216,'2022-07-04 00:00:00',100.00,80.00,0.00,180.00),(529,197,'2022-07-04 00:00:00',100.00,200.00,0.00,300.00),(530,201,'2022-07-04 00:00:00',100.00,50.00,0.00,150.00),(531,217,'2022-07-05 00:00:00',0.00,100.00,0.00,100.00),(532,187,'2022-07-05 00:00:00',0.00,150.00,0.00,150.00),(533,15,'2022-07-05 00:00:00',100.00,100.00,0.00,200.00),(534,19,'2022-07-05 00:00:00',100.00,100.00,0.00,200.00),(535,160,'2022-07-06 00:00:00',100.00,150.00,0.00,250.00),(536,219,'2022-07-06 00:00:00',100.00,100.00,0.00,200.00),(537,130,'2022-07-06 00:00:00',100.00,210.00,0.00,310.00),(538,133,'2022-07-06 00:00:00',100.00,100.00,0.00,200.00),(540,216,'2022-07-06 00:00:00',0.00,30.00,0.00,30.00),(542,220,'2022-07-06 00:00:00',100.00,250.00,0.00,350.00),(543,222,'2022-07-06 00:00:00',100.00,100.00,0.00,200.00),(544,221,'2022-07-06 00:00:00',100.00,100.00,0.00,200.00),(545,221,'2022-07-06 00:00:00',0.00,180.00,0.00,180.00),(546,199,'2022-07-06 00:00:00',0.00,120.00,0.00,120.00),(665,256,'2022-08-01 00:00:00',100.00,150.00,0.00,250.00),(548,184,'2022-07-07 00:00:00',100.00,100.00,0.00,200.00),(549,186,'2022-07-07 00:00:00',0.00,40.00,0.00,40.00),(550,48,'2022-07-07 00:00:00',100.00,150.00,0.00,250.00),(552,223,'2022-07-08 00:00:00',100.00,100.00,0.00,200.00),(553,6,'2022-07-08 00:00:00',100.00,100.00,0.00,200.00),(554,130,'2022-07-08 00:00:00',0.00,50.00,0.00,50.00),(555,224,'2022-07-08 00:00:00',100.00,150.00,0.00,250.00),(556,129,'2022-07-08 00:00:00',100.00,100.00,0.00,200.00),(557,96,'2022-07-08 00:00:00',100.00,100.00,0.00,200.00),(558,154,'2022-07-09 00:00:00',100.00,100.00,0.00,200.00),(559,149,'2022-07-09 00:00:00',100.00,250.00,0.00,350.00),(560,67,'2022-07-09 00:00:00',0.00,130.00,0.00,130.00),(561,225,'2022-07-12 00:00:00',100.00,150.00,0.00,250.00),(575,232,'2022-07-13 00:00:00',100.00,100.00,0.00,200.00),(563,226,'2022-07-12 00:00:00',100.00,250.00,0.00,350.00),(564,227,'2022-07-12 00:00:00',100.00,150.00,0.00,250.00),(565,186,'2022-07-12 00:00:00',0.00,150.00,0.00,150.00),(566,230,'2022-07-12 00:00:00',100.00,220.00,0.00,320.00),(567,229,'2022-07-12 00:00:00',100.00,300.00,0.00,400.00),(568,133,'2022-07-12 00:00:00',0.00,190.00,0.00,190.00),(574,187,'2022-07-12 00:00:00',0.00,70.00,0.00,70.00),(570,215,'2022-07-12 00:00:00',100.00,100.00,0.00,200.00),(576,233,'2022-07-13 00:00:00',100.00,120.00,0.00,220.00),(572,134,'2022-07-12 00:00:00',100.00,100.00,0.00,200.00),(652,251,'2022-07-29 00:00:00',0.00,70.00,0.00,70.00),(577,234,'2022-07-13 00:00:00',100.00,200.00,0.00,300.00),(578,235,'2022-07-13 00:00:00',100.00,100.00,0.00,200.00),(579,64,'2022-07-14 00:00:00',100.00,130.00,0.00,230.00),(580,65,'2022-07-14 00:00:00',100.00,100.00,0.00,200.00),(581,105,'2022-07-14 00:00:00',100.00,100.00,0.00,200.00),(582,194,'2022-07-14 00:00:00',100.00,100.00,0.00,200.00),(583,237,'2022-07-14 00:00:00',100.00,150.00,0.00,250.00),(584,236,'2022-07-14 00:00:00',100.00,150.00,0.00,250.00),(585,168,'2022-07-15 00:00:00',100.00,180.00,0.00,280.00),(587,186,'2022-07-15 00:00:00',100.00,80.00,0.00,180.00),(588,238,'2022-07-16 00:00:00',100.00,120.00,0.00,220.00),(589,133,'2022-07-16 00:00:00',0.00,100.00,0.00,100.00),(590,218,'2022-07-16 00:00:00',0.00,200.00,0.00,200.00),(591,218,'2022-07-05 00:00:00',100.00,50.00,0.00,150.00),(592,239,'2022-07-18 00:00:00',100.00,100.00,0.00,200.00),(593,240,'2022-07-18 00:00:00',100.00,100.00,0.00,200.00),(594,216,'2022-07-18 00:00:00',0.00,100.00,0.00,100.00),(595,122,'2022-07-19 00:00:00',100.00,100.00,0.00,200.00),(596,112,'2022-07-19 00:00:00',100.00,120.00,0.00,220.00),(597,225,'2022-07-19 00:00:00',0.00,200.00,0.00,200.00),(598,229,'2022-07-20 00:00:00',0.00,120.00,0.00,120.00),(599,241,'2022-07-20 00:00:00',100.00,120.00,0.00,220.00),(600,199,'2022-07-20 00:00:00',100.00,100.00,0.00,200.00),(601,195,'2022-07-20 00:00:00',100.00,120.00,0.00,220.00),(602,40,'2022-07-04 00:00:00',0.00,180.00,0.00,180.00),(609,29,'2022-07-21 00:00:00',0.00,1.00,0.00,1.00),(604,242,'2022-07-21 00:00:00',100.00,130.00,0.00,230.00),(605,199,'2022-07-21 00:00:00',0.00,1.00,0.00,1.00),(606,243,'2022-07-21 00:00:00',100.00,150.00,0.00,250.00),(607,117,'2022-07-21 00:00:00',100.00,120.00,0.00,220.00),(608,146,'2022-07-21 00:00:00',200.00,240.00,-300.00,140.00),(610,175,'2022-07-21 00:00:00',100.00,150.00,0.00,250.00),(611,187,'2022-07-21 00:00:00',100.00,100.00,0.00,200.00),(613,187,'2022-07-21 00:00:00',100.00,100.00,0.00,200.00),(614,244,'2022-07-22 00:00:00',100.00,100.00,0.00,200.00),(615,245,'2022-07-22 00:00:00',100.00,200.00,0.00,300.00),(616,133,'2022-07-22 00:00:00',100.00,100.00,0.00,200.00),(617,199,'2022-07-22 00:00:00',0.00,100.00,0.00,100.00),(618,102,'2022-07-23 00:00:00',100.00,100.00,0.00,200.00),(621,97,'2022-07-23 00:00:00',100.00,120.00,0.00,220.00),(620,67,'2022-07-23 00:00:00',100.00,200.00,0.00,300.00),(622,134,'2022-07-16 00:00:00',100.00,200.00,0.00,300.00),(623,134,'2022-07-23 00:00:00',100.00,200.00,0.00,300.00),(624,246,'2022-07-25 00:00:00',100.00,100.00,0.00,200.00),(625,217,'2022-07-25 00:00:00',100.00,100.00,0.00,200.00),(626,247,'2022-07-26 00:00:00',0.00,1.00,0.00,1.00),(627,186,'2022-07-26 00:00:00',0.00,100.00,0.00,100.00),(628,248,'2022-07-19 00:00:00',100.00,120.00,0.00,220.00),(631,112,'2022-07-26 00:00:00',0.00,100.00,0.00,100.00),(630,122,'2022-07-26 00:00:00',0.00,120.00,0.00,120.00),(632,197,'2022-07-27 00:00:00',100.00,200.00,0.00,300.00),(633,168,'2022-07-27 00:00:00',0.00,280.00,0.00,280.00),(634,249,'2022-07-27 00:00:00',100.00,100.00,0.00,200.00),(635,250,'2022-07-27 00:00:00',100.00,120.00,0.00,220.00),(636,251,'2022-07-27 00:00:00',100.00,150.00,0.00,250.00),(637,97,'2022-07-28 00:00:00',0.00,60.00,0.00,60.00),(647,141,'2022-07-28 00:00:00',100.00,100.00,0.00,200.00),(650,149,'2022-07-28 00:00:00',100.00,70.00,0.00,170.00),(640,142,'2022-07-28 00:00:00',100.00,100.00,0.00,200.00),(641,231,'2022-07-28 00:00:00',100.00,100.00,0.00,200.00),(642,228,'2022-07-12 00:00:00',100.00,150.00,0.00,250.00),(643,228,'2022-07-28 00:00:00',100.00,120.00,0.00,220.00),(644,160,'2022-07-28 00:00:00',100.00,150.00,0.00,250.00),(645,227,'2022-07-28 00:00:00',100.00,130.00,0.00,230.00),(646,252,'2022-07-28 00:00:00',100.00,100.00,0.00,200.00),(651,154,'2022-07-28 00:00:00',100.00,100.00,0.00,200.00),(653,254,'2022-07-29 00:00:00',100.00,100.00,0.00,200.00),(654,253,'2022-07-29 00:00:00',100.00,100.00,0.00,200.00),(655,255,'2022-07-29 00:00:00',100.00,100.00,0.00,200.00),(661,61,'2022-07-30 00:00:00',100.00,150.00,0.00,250.00),(657,240,'2022-07-30 00:00:00',0.00,220.00,0.00,220.00),(660,199,'2022-07-30 00:00:00',100.00,20.00,0.00,120.00),(659,117,'2022-07-30 00:00:00',100.00,150.00,0.00,250.00),(662,133,'2022-07-30 00:00:00',0.00,100.00,0.00,100.00),(663,254,'2022-07-30 00:00:00',0.00,1.00,0.00,1.00),(664,253,'2022-07-30 00:00:00',0.00,1.00,0.00,1.00),(666,257,'2022-08-01 00:00:00',100.00,150.00,0.00,250.00),(667,258,'2022-08-02 00:00:00',100.00,100.00,0.00,200.00),(668,97,'2022-08-03 00:00:00',100.00,200.00,0.00,300.00),(669,216,'2022-08-03 00:00:00',100.00,80.00,0.00,180.00),(672,243,'2022-08-05 00:00:00',100.00,150.00,0.00,250.00),(671,67,'2022-08-05 00:00:00',0.00,160.00,0.00,160.00),(674,186,'2022-08-13 00:00:00',100.00,180.00,0.00,280.00),(675,259,'2022-08-13 00:00:00',100.00,130.00,0.00,230.00),(676,168,'2022-08-13 00:00:00',100.00,200.00,0.00,300.00),(677,260,'2022-08-13 00:00:00',100.00,100.00,0.00,200.00),(678,199,'2022-08-13 00:00:00',100.00,150.00,0.00,250.00),(680,257,'2022-08-15 00:00:00',100.00,150.00,0.00,250.00),(681,139,'2022-08-15 00:00:00',100.00,150.00,0.00,200.00),(682,261,'2022-08-15 00:00:00',100.00,100.00,0.00,200.00),(683,262,'2022-08-16 00:00:00',100.00,120.00,0.00,220.00),(684,175,'2022-08-16 00:00:00',100.00,200.00,0.00,300.00),(685,213,'2022-08-16 00:00:00',100.00,100.00,0.00,200.00),(686,192,'2022-08-17 00:00:00',100.00,120.00,0.00,220.00),(687,263,'2022-08-17 00:00:00',100.00,120.00,0.00,220.00),(688,192,'2022-08-17 00:00:00',100.00,120.00,0.00,220.00),(689,264,'2022-08-18 00:00:00',200.00,240.00,0.00,440.00),(690,262,'2022-08-18 00:00:00',0.00,120.00,0.00,120.00),(691,238,'2022-08-18 00:00:00',100.00,130.00,0.00,230.00),(692,198,'2022-08-18 00:00:00',100.00,120.00,0.00,220.00),(693,169,'2022-08-18 00:00:00',100.00,130.00,0.00,230.00),(696,253,'2022-08-18 00:00:00',100.00,120.00,0.00,220.00),(695,256,'2022-08-18 00:00:00',100.00,150.00,0.00,250.00),(697,266,'2022-08-18 00:00:00',100.00,100.00,0.00,200.00),(698,265,'2022-08-18 00:00:00',100.00,400.00,0.00,500.00),(699,265,'2022-08-18 00:00:00',100.00,400.00,0.00,500.00),(700,178,'2022-08-19 00:00:00',100.00,200.00,0.00,300.00),(701,263,'2022-08-19 00:00:00',0.00,70.00,0.00,70.00),(702,209,'2022-08-20 00:00:00',100.00,50.00,0.00,150.00),(703,210,'2022-08-20 00:00:00',100.00,100.00,0.00,200.00),(704,117,'2022-08-20 00:00:00',100.00,120.00,0.00,220.00),(705,61,'2022-08-20 00:00:00',0.00,100.00,0.00,100.00),(706,264,'2022-08-20 00:00:00',0.00,30.00,0.00,30.00),(707,264,'2022-08-20 00:00:00',0.00,10.00,0.00,10.00),(708,195,'2022-08-22 00:00:00',100.00,130.00,0.00,230.00),(709,267,'2022-08-22 00:00:00',100.00,270.00,0.00,370.00),(710,268,'2022-08-22 00:00:00',100.00,120.00,0.00,220.00),(711,269,'2022-08-23 00:00:00',100.00,500.00,0.00,600.00),(712,270,'2022-08-23 00:00:00',100.00,100.00,0.00,200.00),(713,256,'2022-08-23 00:00:00',0.00,70.00,0.00,70.00),(714,271,'2022-08-23 00:00:00',100.00,100.00,0.00,200.00),(715,117,'2022-08-24 00:00:00',0.00,220.00,0.00,220.00),(716,272,'2022-08-24 00:00:00',100.00,120.00,0.00,220.00),(717,228,'2022-08-24 00:00:00',100.00,200.00,0.00,300.00),(718,227,'2022-08-24 00:00:00',100.00,200.00,0.00,300.00),(719,147,'2022-08-25 00:00:00',100.00,170.00,0.00,270.00),(722,270,'2022-08-25 00:00:00',0.00,1.00,0.00,1.00),(721,187,'2022-08-25 00:00:00',100.00,80.00,0.00,180.00),(723,64,'2022-08-26 00:00:00',100.00,100.00,0.00,200.00),(724,67,'2022-08-26 00:00:00',100.00,385.00,0.00,485.00),(725,102,'2022-08-26 00:00:00',100.00,120.00,0.00,220.00),(726,102,'2022-08-26 00:00:00',100.00,220.00,0.00,320.00),(727,124,'2022-08-26 00:00:00',100.00,120.00,0.00,220.00),(729,65,'2022-08-26 00:00:00',100.00,120.00,0.00,220.00),(730,272,'2022-08-27 00:00:00',0.00,40.00,0.00,40.00),(731,257,'2022-08-27 00:00:00',0.00,30.00,0.00,30.00),(732,270,'2022-08-27 00:00:00',0.00,100.00,0.00,100.00),(733,253,'2022-08-27 00:00:00',100.00,100.00,0.00,200.00),(734,107,'2022-08-27 00:00:00',100.00,100.00,0.00,200.00),(736,186,'2022-08-29 00:00:00',100.00,180.00,0.00,280.00),(737,273,'2022-08-29 00:00:00',100.00,100.00,0.00,200.00),(738,274,'2022-08-29 00:00:00',100.00,100.00,0.00,200.00),(739,274,'2022-08-22 00:00:00',100.00,100.00,0.00,200.00),(740,194,'2022-08-29 00:00:00',100.00,120.00,0.00,220.00),(741,105,'2022-08-29 00:00:00',100.00,100.00,0.00,200.00),(742,275,'2022-08-29 00:00:00',100.00,120.00,0.00,220.00),(743,220,'2022-08-29 00:00:00',100.00,120.00,0.00,220.00),(744,97,'2022-08-29 00:00:00',100.00,180.00,0.00,280.00),(745,271,'2022-08-29 00:00:00',0.00,150.00,0.00,150.00),(746,152,'2022-08-29 00:00:00',100.00,300.00,0.00,0.00),(747,152,'2022-06-27 00:00:00',100.00,160.00,400.00,0.00),(748,152,'2022-06-04 00:00:00',100.00,80.00,660.00,0.00),(749,249,'2022-08-29 00:00:00',100.00,120.00,0.00,220.00),(750,243,'2022-08-30 00:00:00',100.00,100.00,0.00,200.00),(751,271,'2022-08-30 00:00:00',0.00,1.00,0.00,1.00),(752,253,'2022-08-30 00:00:00',0.00,1.00,0.00,1.00),(753,266,'2022-08-30 00:00:00',0.00,100.00,0.00,100.00),(754,210,'2022-08-31 00:00:00',100.00,150.00,0.00,250.00),(755,258,'2022-08-31 00:00:00',100.00,120.00,0.00,220.00),(756,276,'2022-08-31 00:00:00',100.00,150.00,0.00,250.00),(757,277,'2022-08-31 00:00:00',100.00,130.00,0.00,230.00);
/*!40000 ALTER TABLE `patientpayment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rehabilitation`
--

DROP TABLE IF EXISTS `rehabilitation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rehabilitation` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Pno` varchar(45) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `Quantity` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rehabilitation`
--

LOCK TABLES `rehabilitation` WRITE;
/*!40000 ALTER TABLE `rehabilitation` DISABLE KEYS */;
/*!40000 ALTER TABLE `rehabilitation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `route`
--

DROP TABLE IF EXISTS `route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `route`
--

LOCK TABLES `route` WRITE;
/*!40000 ALTER TABLE `route` DISABLE KEYS */;
/*!40000 ALTER TABLE `route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volunteer`
--

DROP TABLE IF EXISTS `volunteer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volunteer` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `Phone` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volunteer`
--

LOCK TABLES `volunteer` WRITE;
/*!40000 ALTER TABLE `volunteer` DISABLE KEYS */;
/*!40000 ALTER TABLE `volunteer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'olive'
--
/*!50003 DROP PROCEDURE IF EXISTS `log_msg` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `log_msg`(IN in_msg VARCHAR(255))
BEGIN
 insert into log values(in_msg);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddAccountLedger` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_AddAccountLedger`(
IN p_in_txndate datetime,
IN p_in_desc varchar(200),
IN p_in_type varchar(45),
IN p_in_amount DECIMAL(10,2),
IN p_in_txntype varchar(45),
IN p_in_paymentMode varchar(45),
IN p_in_pno varchar(45),
IN p_in_paymentId int,
OUT p_out int
)
BEGIN
	
    declare p_id int;
	
    SELECT Id into p_id
    FROM patient where PNo = p_in_pno; 
        
	IF extract(year from p_in_txndate) = 1 THEN
		SET p_in_txndate = NULL;
	END IF;
    	    
	INSERT INTO `account`
		(
		`txndate`,
		`desc`,
		`type`,
		`amount`,
		`txntype`,
		`paymentMode`,
        `PatientId`,
        `PaymentId`)
		VALUES
		(
        p_in_txndate,
        p_in_desc,
		p_in_type,
        p_in_amount,
        p_in_txntype,
        p_in_paymentMode,
        p_id,
        p_in_paymentId
       );
        
        set p_out =  LAST_INSERT_ID();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddBank` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_AddBank`(
IN p_in_name varchar(200)
)
BEGIN
	INSERT INTO `bank`
	(`Name`)
	VALUES
	(p_in_name );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddCE` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_AddCE`(
IN p_in_txndate datetime,
IN p_in_source varchar(45),
IN p_in_bankName varchar(200),
IN p_in_amount DECIMAL(10,2)
)
BEGIN
	
    IF p_in_source = "Cash" THEN
		INSERT INTO `account`
		(
		`txndate`,
		`desc`,
		`type`,
		`amount`,
		`txntype`,
		`name`,
		`isReceipt`,
		`paymentMode`,
		`bankMode`,
		`bankName`,
        `chAmount`
		)
		VALUES
		(
        p_in_txndate,
        "Contra Entry - Cash", -- p_in_desc
		"Contra Entry", -- p_in_type
        p_in_amount * -1,
        "Expense", --  p_in_txntype
        "", -- p_in_name
        0, -- p_in_isReceipt
        "Cash", -- p_in_paymentMode
        "", -- p_in_bankMode
        "", -- p_in_bankName
        0 --  `chAmount`
        );
        
        INSERT INTO `account`
		(
		`txndate`,
		`desc`,
		`type`,
		`amount`,
		`txntype`,
		`name`,
		`isReceipt`,
		`paymentMode`,
		`bankMode`,
		`bankName`,
		`chAmount`
		)
		VALUES
		(
        p_in_txndate,
        "Contra Entry - Bank", -- p_in_desc
		"Contra Entry", -- p_in_type
        p_in_amount,
        "Income", --  p_in_txntype
        "", -- p_in_name
        0, -- p_in_isReceipt
        "Bank", -- p_in_paymentMode
        "Transfer", -- p_in_bankMode
        p_in_bankName,
        0 --  `chAmount`
        );
	ELSE
		INSERT INTO `account`
		(
		`txndate`,
		`desc`,
		`type`,
		`amount`,
		`txntype`,
		`name`,
		`isReceipt`,
		`paymentMode`,
		`bankMode`,
		`bankName`,
        `chAmount`
		)
		VALUES
		(
        p_in_txndate,
        "Contra Entry - Bank", -- p_in_desc
		"Contra Entry", -- p_in_type
        p_in_amount * -1,
        "Expense", --  p_in_txntype
        "", -- p_in_name
        0, -- p_in_isReceipt
        "Bank", -- p_in_paymentMode
        "Transfer", -- p_in_bankMode
        p_in_bankName,
        0 --  `chAmount`
        );
        
        INSERT INTO `account`
		(
		`txndate`,
		`desc`,
		`type`,
		`amount`,
		`txntype`,
		`name`,
		`isReceipt`,
		`paymentMode`,
		`bankMode`,
		`bankName`,
        `chAmount`
		)
		VALUES
		(
        p_in_txndate,
        "Contra Entry - Cash", -- p_in_desc
		"Contra Entry", -- p_in_type
        p_in_amount,
        "Income", --  p_in_txntype
        "", -- p_in_name
        0, -- p_in_isReceipt
        "Cash", -- p_in_paymentMode
        "", -- p_in_bankMode
        "", -- p_in_bankName
        0 --  `chAmount`
        );
	END IF;
    	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddDiagnosis` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_AddDiagnosis`(
IN p_in_name varchar(100)
)
BEGIN
	INSERT INTO `diagnosis`
	(`Name`)
	VALUES
	(p_in_name );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddDocument` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_AddDocument`(
IN p_in_pno varchar(50),
IN p_in_uploadedOn datetime,
IN p_in_localFileName varchar(200),
IN p_in_fileName varchar(200)
)
BEGIN

	declare p_id int;
	SELECT Id into p_id FROM patient where PNo = p_in_pno; 

	INSERT INTO patientdocument
	(PatientId, UploadedOn, LocalFileName, FileName )
	VALUES
	(p_id, 
    p_in_uploadedOn, 
    p_in_localFileName, 
    p_in_fileName);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddEquipment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_AddEquipment`(
IN p_in_name varchar(200),
IN p_in_name_lower varchar(200),
IN p_in_stock int,
IN p_in_inuse int,
IN p_in_damage int
)
BEGIN
	declare p_eno varchar(10);
    
    IF NOT EXISTS (SELECT 1 FROM `equipment` where name_lower = p_in_name_lower) THEN
    	select concat('E',ifnull(max(id),0) +1) into p_eno from `equipment`;
      	INSERT INTO `equipment`
		(`eno`,	`name`,	`name_lower`, stock, damage, inuse)
		VALUES (p_eno,p_in_name,p_in_name_lower,p_in_stock, p_in_damage, p_in_inuse );
	ELSE
		UPDATE `equipment`
		SET
		`stock` = p_in_stock,
		`damage` = p_in_damage,
		`inuse` = p_in_inuse
		WHERE `name_lower` = p_in_name_lower;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddExpenseType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_AddExpenseType`(
IN p_in_expensetype varchar(100)
)
BEGIN
	INSERT INTO `expensetype`
	(`ExpenseType`)
	VALUES
	(p_in_expensetype );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddHoliday` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_AddHoliday`(
IN p_in_year int,
IN p_in_month int,
IN p_in_count int
)
BEGIN
	INSERT INTO `holiday`
	(`year`,
	`month`,
	`count`)
	VALUES
	(p_in_year,
    p_in_month,
    p_in_count
    );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddHomeCarePlan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_AddHomeCarePlan`(
IN p_in_pno varchar(45),
IN p_in_name varchar(200),
IN p_in_type varchar(45),
IN p_in_date datetime
)
BEGIN

	IF extract(year from p_in_date) = 1 THEN
		SET p_in_date = NULL;
	END IF;

	INSERT INTO `homecareplan`
	(`Pno`,
	`Date`,
	`Type`,
    `PatientName`)
	VALUES
	(p_in_pno,
    p_in_date,
    p_in_type,
    p_in_name
    );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddIncomeType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_AddIncomeType`(
IN p_in_incometype varchar(100)
)
BEGIN
	INSERT INTO `incometype`
	(`IncomeType`)
	VALUES
	(p_in_incometype );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddMedicine` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_AddMedicine`(
IN p_in_txndate datetime,
IN p_in_name varchar(200),
IN p_in_name_lower varchar(200),
IN p_in_stock_main int
)
BEGIN
	declare p_mno varchar(10);
    
    IF NOT EXISTS (SELECT 1 FROM `medicine` where NameLower = p_in_name_lower) THEN
    	
        select concat('M',ifnull(max(id),0) +1) into p_mno from `medicine`;
        
    	INSERT INTO `medicine`
		(`Mno`,	`Name`,	`NameLower`, Stock)
		VALUES (p_mno,p_in_name,p_in_name_lower, p_in_stock_main);
       
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddMedicineHistory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_AddMedicineHistory`(
IN p_in_m_id int,
IN p_in_txnDate datetime,
IN p_in_mno varchar(45),
IN p_in_medName varchar(200),
IN p_in_txnType varchar(45),
IN p_in_desc varchar(45),
IN p_in_openingMain int,
IN p_in_openingSub int,
IN p_in_openingAKit int,
IN p_in_openingBKit int,
IN p_in_qty int,
IN p_in_closingMain int,
IN p_in_closingSub int,
IN p_in_closingAKit int,
IN p_in_closingBKit int,
IN p_in_pno varchar(45),
IN p_in_patientName  varchar(200)
)
BEGIN
	
    INSERT INTO `medicinehistory`
	(
	`MedicineId`,
	`txnDate`,
	`mno`,
	`medName`,
	`txnType`,
	`desc`,
	`openingMain`,
	`openingSub`,
	`openingAKit`,
	`openingBKit`,
	`qty`,
	`closingMain`,
	`closingSub`,
	`closingAKit`,
	`closingBKit`,
	`pno`,
	`patientName`)
	VALUES
	(
	p_in_m_id,
	p_in_txnDate,
	p_in_mno,
	p_in_medName,
	p_in_txnType,
	p_in_desc,
	p_in_openingMain,
	p_in_openingSub,
	p_in_openingAKit,
	p_in_openingBKit,
	p_in_qty,
	p_in_closingMain,
	p_in_closingSub,
	p_in_closingAKit,
	p_in_closingBKit,
	p_in_pno,
	p_in_patientName);

    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddPanjayath` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_AddPanjayath`(
IN p_in_name varchar(100)
)
BEGIN
	INSERT INTO `panjayath`
	(`Name`)
	VALUES
	(p_in_name );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddPatient` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_AddPatient`(
IN p_in_pno varchar(45),
IN p_in_name varchar(200),
IN p_in_age varchar(45),
IN p_in_address varchar(255),
IN p_in_grade varchar(45),
IN p_in_gender varchar(45),
IN p_in_panjayath varchar(100),
IN p_in_wardno varchar(45),
IN p_in_phone1 varchar(45),
IN p_in_phone2 varchar(45),
IN p_in_regdate datetime,
IN p_in_expdate datetime,
IN p_in_dropdate datetime,
IN p_in_volunteer varchar(100),
IN p_in_diagnosis varchar(100),
IN p_in_temp tinyint,
IN p_in_route varchar(100),
IN p_in_homecareplan varchar(45),
OUT p_out varchar(10)
)
BEGIN
	
    IF EXISTS (SELECT 1 FROM patient where PNo = p_in_pno) THEN
    	SET p_out = "1";
    ELSE
    	IF extract(year from p_in_regdate) = 1 THEN
			SET p_in_regdate = NULL;
		END IF;
		
		IF extract(year from p_in_expdate) = 1 THEN
			SET p_in_expdate = NULL;
		END IF;
		
		IF extract(year from p_in_dropdate) = 1 THEN
			SET p_in_dropdate = NULL;
		END IF;

		INSERT INTO `patient`
		(
		`PNo`,
		`Name`,
		`Age`,
		`Address`,
		`Grade`,
		`Gender`,
		`Panjayath`,
		`WardNo`,
		`Phone1`,
		`Phone2`,
		`RegDate`,
		`ExpDate`,
		`DropDate`,
		`Volunteer`,
		`Diagnosis`,
		`Temp`,
		`Route`,
		`HomeCarePlan`)
		VALUES
		(
		p_in_pno,
		p_in_name,
		p_in_age,
		p_in_address,
		p_in_grade,
		p_in_gender,
		p_in_panjayath,
		p_in_wardno,
		p_in_phone1,
		p_in_phone2,
		p_in_regdate,
		p_in_expdate,
		p_in_dropdate,
		p_in_volunteer,
		p_in_diagnosis,
		p_in_temp,
		p_in_route,
		p_in_homecareplan
		);
        
        SET p_out = "0";
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddRehabilitation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_AddRehabilitation`(
IN p_in_pno varchar(45),
IN p_in_desc varchar(200),
IN p_in_qty int,
IN p_in_date datetime
)
BEGIN

	IF extract(year from p_in_date) = 1 THEN
		SET p_in_date = NULL;
	END IF;

	INSERT INTO `rehabilitation`
	(`Pno`,
	`Date`,
	`Description`,
    `Quantity`)
	VALUES
	(p_in_pno,
    p_in_date,
    p_in_desc,
    p_in_qty
    );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddRoute` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_AddRoute`(
IN p_in_name varchar(100)
)
BEGIN
	INSERT INTO `route`
	(`Name`)
	VALUES
	(p_in_name );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddVolunteer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_AddVolunteer`(
IN p_in_name varchar(100),
IN p_in_location varchar(100),
IN p_in_phone varchar(45)
)
BEGIN
	INSERT INTO `volunteer`
	(`Name`,
	`Location`,
	`Phone`)
	VALUES
	(p_in_name,
    p_in_location,
    p_in_phone
    );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_DeleteInvestigation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_DeleteInvestigation`(
IN p_in_id int
)
BEGIN

    UPDATE patientdocument set IsDeleted = 1 where Id = p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_DeletePayment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_DeletePayment`(
IN p_in_id int
)
BEGIN

    DELETE FROM patientpayment where Id = p_in_id;
    DELETE FROM account where PaymentId = p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_DisposeEquipment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_DisposeEquipment`(
IN p_in_txndate datetime,
IN p_in_id int,
IN p_in_desc varchar(200),
IN p_in_eno varchar(45),
IN p_in_qty int,
IN p_in_name varchar(200),
OUT p_out int
)
BEGIN
	
    Declare p_receiptNo int;
    
	IF extract(year from p_in_txndate) = 1 THEN
		SET p_in_txndate = NULL;
	END IF;
	
	IF EXISTS (SELECT 1 FROM `equipment` where Id = p_in_id) THEN
      	INSERT INTO `equipmentdispose`
			(
			`EquipmentId`,
			`Eno`,
			`Name`,
			`Desc`,
			`Qty`,
			`TxnDate`)
			VALUES
			(
			p_in_id,
			p_in_eno,
			p_in_name,
			p_in_desc,
			p_in_qty,
			p_in_txndate);
         
        set p_out =  LAST_INSERT_ID();
        
		UPDATE `equipment`
		SET
		damage = (damage - p_in_qty)
		WHERE Id = p_in_id;
	END IF;
       
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_DownloadInvestigation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_DownloadInvestigation`(
IN p_in_id int
)
BEGIN

    select LocalFileName, FileName 
    from patientdocument where Id = p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetAccountLedger` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetAccountLedger`(
IN p_in_fromdate datetime,
IN p_in_todate datetime
)
BEGIN

SELECT 
	a.`Id`,
    a.`txndate`,
    CASE 
		WHEN a.PatientId IS NOT NULL then CONCAT(p.PNo, ' - ',  p.Name)
        ELSE a.desc
	END as `desc`,
	a.`type`,
    a.`amount`,
    a.`txntype`,
    a.`paymentMode`
FROM `account` a
left join patient p on a.PatientId = p.id
WHERE 
	(a.`txntype` = 'Income' OR a.`txntype` = 'Expense') AND
    a.`amount` != 0 AND
    a.`txndate` >= p_in_fromdate AND
    a.`txndate` <= p_in_todate
;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetAccountReceipt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetAccountReceipt`(
IN p_in_id varchar(2000)
)
BEGIN

SELECT 
	`account`.`Id`,
    `account`.`txndate`,
    `account`.`desc`,
    `account`.`type`,
    `account`.`amount`,
    `account`.`txntype`,
    `account`.`name`,
    `account`.`receiptNo`,
    `account`.`isReceipt`,
    `account`.`paymentMode`,
    `account`.`bankMode`,
    `account`.`bankName`,
    `account`.`txnNo`,
    `account`.`chNo`,
    `account`.`chdate`,
    `account`.`chBank`,
    `account`.`chAmount`
FROM `account`
WHERE FIND_IN_SET(Id, p_in_id)
	and isReceipt = 1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetBankList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetBankList`()
BEGIN
	select Id, Name,IsCash from bank order by Name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetCenterDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetCenterDetails`()
BEGIN
SELECT `center`.`Id` AS _id,
    `center`.`Name`,
    `center`.`Address`,
    `center`.`Desc`,
    `center`.`Location`,
    `center`.`Phone`,
    `center`.`RegNo`,
    `center`.`AddressMal`,
     `center`.`DescMal`,
    `center`.`LocationMal`,
    `center`.`NameMal`,
    `center`.`ReceiptNo`,
    `center`.`MedExpiryDays`,
    `center`.`MedThresholdCount`,
    `center`.`ValidTill`,
    `center`.`TodayAPI`
FROM `center`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetChequeReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetChequeReport`(
IN p_in_status varchar(20)
)
BEGIN

	IF p_in_status = 'All' THEN
		SELECT 
			Id,txndate,`desc`,`type`,amount,txntype,`name`,receiptNo,isReceipt,paymentMode,bankMode,
			bankName,txnNo,chNo,chdate,chBank,chAmount
		FROM `account`
		WHERE 
			bankMode = "Cheque";
    ELSEIF p_in_status = 'Pending' THEN
		SELECT 
			Id,txndate,`desc`,`type`,amount,txntype,`name`,receiptNo,isReceipt,paymentMode,bankMode,
			bankName,txnNo,chNo,chdate,chBank,chAmount
		FROM `account`
		WHERE 
			bankMode = "Cheque" AND
            amount = 0;
    ELSEIF p_in_status = 'Cleared' THEN
		SELECT 
			Id,txndate,`desc`,`type`,amount,txntype,`name`,receiptNo,isReceipt,paymentMode,bankMode,
			bankName,txnNo,chNo,chdate,chBank,chAmount
		FROM `account`
		WHERE 
			bankMode = "Cheque" AND
            amount != 0;
    END IF;

	

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetCheques` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetCheques`()
BEGIN
SELECT 
	`account`.`Id`,
    `account`.`txndate`,
    `account`.`desc`,
    `account`.`type`,
    `account`.`amount`,
    `account`.`txntype`,
    `account`.`name`,
    `account`.`receiptNo`,
    `account`.`isReceipt`,
    `account`.`paymentMode`,
    `account`.`bankMode`,
    `account`.`bankName`,
    `account`.`txnNo`,
    `account`.`chNo`,
    `account`.`chdate`,
    `account`.`chBank`,
    `account`.`chAmount`
FROM `account`
WHERE 
    `account`.`amount` = 0 AND
    `account`.`bankMode` = 'Cheque'
;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetDashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetDashboard`()
BEGIN

select month(txndate) mon, year(txndate) yr, sum(amount) * -1 amount
from account
where txndate >= '2022-02-01 00:00:00'
and txntype = 'Expense'
and type != 'Savings'
group by year(txndate), month(txndate)
order by  year(txndate), month(txndate);

select month(txndate) mon, year(txndate) yr, sum(amount) amount
from account
where txndate >= '2022-02-01 00:00:00'
and txntype = 'Income'
group by year(txndate), month(txndate)
order by  year(txndate), month(txndate);

select month(txndate) mon, year(txndate) yr, sum(amount) * -1 amount
from account
where txndate >= '2022-02-01 00:00:00'
and txntype = 'Expense'
and type = 'Savings'
group by year(txndate), month(txndate)
order by  year(txndate), month(txndate);

select 
	year(x.txndate) yr,
    month(x.txndate) mon,
    ifnull(sum(NewCount),0) NewCount,
    sum(TotalCount) - ifnull(sum(NewCount),0) FollowupCount,
    sum(TotalCount) TotalCount
from 
	(
		select transactiondate txndate ,count(distinct patientid) TotalCount 
        from patientpayment
		where transactiondate >= '2022-02-01 00:00:00'
		group by transactiondate 
	) x 
	left join 
    (
		select RegDate txndate, count(id) NewCount from patient
		where RegDate >= '2022-02-01 00:00:00'
		group by RegDate
	) y 
    on x.txndate = y.txndate
    group by year(txndate), month(txndate)
	order by year(txndate), month(txndate);

	select sum(Main) Main, Sum(Sub) Sub, Sum(A_kit) A_Kit, Sum(B_kit) B_Kit
	from medicinestock;
    
    select Grade, Count(Id) total from patient group by Grade;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetDiagnosisList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetDiagnosisList`()
BEGIN
	select Id, Name from diagnosis order by Name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetDisposeReceipt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetDisposeReceipt`(
IN p_in_id varchar(2000)
)
BEGIN

	SELECT
		`equipmentdispose`.`EquipmentId`,
		`equipmentdispose`.`Eno`,
		`equipmentdispose`.`Name`,
		`equipmentdispose`.`Desc`,
		`equipmentdispose`.`Qty`,
		`equipmentdispose`.`TxnDate`
	FROM `equipmentdispose`
    WHERE FIND_IN_SET(Id, p_in_id);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetEquipmentDisposeReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetEquipmentDisposeReport`(
IN p_in_fromDate datetime,
IN p_in_toDate datetime
)
BEGIN

	SELECT 
		`equipmentdispose`.`Id`,
		`equipmentdispose`.`EquipmentId`,
		`equipmentdispose`.`Eno`,
		`equipmentdispose`.`Name`,
		`equipmentdispose`.`Desc`,
		`equipmentdispose`.`Qty`,
		`equipmentdispose`.`TxnDate`
	FROM `equipmentdispose`
    WHERE
		TxnDate >= p_in_fromDate AND
        TxnDate <= p_in_toDate;		   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetEquipmentReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetEquipmentReport`(
IN p_in_eno varchar(45)
)
BEGIN

	IF p_in_eno = '' THEN
		select
			t.Id,
			t.patientname,
			t.qty,
			t.outdate,
			t.indate,
            t.pno,
			e.name
		from 
		equipmenttracker t
		inner join equipment e on t.equipmentid = e.id
        order by e.name;
		
    ELSE
		select
			t.Id,
			t.patientname,
			t.qty,
			t.outdate,
			t.indate,
            t.pno,
			e.name
		from 
		equipmenttracker t
		inner join equipment e on t.equipmentid = e.id
		where e.eno = p_in_eno
		order by e.name;
         
    END IF;
		   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetEquipments` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetEquipments`()
BEGIN
	
   SELECT `equipment`.`Id`,
		`equipment`.`eno`,
		`equipment`.`name`,
		`equipment`.`name_lower`,
		`equipment`.`stock`,
		`equipment`.`damage`,
		`equipment`.`inuse`
	FROM `equipment`
    ORDER BY `equipment`.`name`;    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetEquipmentTracker` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetEquipmentTracker`(
IN p_in_eno varchar(45)
)
BEGIN

	select
		t.Id,
		t.patientname,
        t.qty,
        t.outdate,
        t.indate
    from 
	equipmenttracker t
	inner join equipment e on t.equipmentid = e.id
	where e.eno = p_in_eno
    order by t.outdate;
		   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetExpenseTypeList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetExpenseTypeList`()
BEGIN
	select Id, ExpenseType from expensetype order by ExpenseType;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetHolidayCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetHolidayCount`()
BEGIN
	select  id, year, month, count from holiday;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetHomeCarePlan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetHomeCarePlan`(
IN p_in_fromdate datetime,
IN p_in_todate datetime
)
BEGIN

	SELECT `homecareplan`.`Id`,
		`homecareplan`.`Pno`,
		`homecareplan`.`Date`,
		`homecareplan`.`Type`,
		`homecareplan`.`PatientName`
	FROM `homecareplan`
    where `homecareplan`.`Date` >= p_in_fromdate and
		`homecareplan`.`Date` <= p_in_todate
	order by `homecareplan`.`Date`
    ;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetHomeCarePlanList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetHomeCarePlanList`(
IN p_in_pno varchar(45)
)
BEGIN
	SELECT 
    `Id`,
    `Date`,
    `Type`,
    `PatientName`
FROM `homecareplan`
where Pno = p_in_pno
order by `Date`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetIncomeTypeList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetIncomeTypeList`()
BEGIN
	select Id, IncomeType from incometype order by IncomeType;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetInvestigation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetInvestigation`(
IN p_in_pno varchar(50)
)
BEGIN

	declare p_id int;
	SELECT Id into p_id FROM patient where PNo = p_in_pno; 
    
    select 
		Id, 
		UploadedOn,
		LocalFileName,
		FileName
		from patientdocument 
        where IsDeleted = 0 and PatientId = p_id
		order by FileName;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetLoginDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetLoginDetails`(
IN p_in_UserName varchar(45)
)
BEGIN
 select password from login where username = p_in_UserName;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetMedicineHistory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetMedicineHistory`(
IN p_in_mno varchar(50),
IN p_in_fromDate datetime,
IN p_in_toDate datetime
)
BEGIN

	SELECT 
		`medicinehistory`.`Id`,
		`medicinehistory`.`MedicineId`,
		`medicinehistory`.`txnDate`,
		`medicinehistory`.`mno`,
		`medicinehistory`.`medName`,
		`medicinehistory`.`txnType`,
		`medicinehistory`.`desc`,
		`medicinehistory`.`openingMain`,
		`medicinehistory`.`openingSub`,
		`medicinehistory`.`openingAKit`,
		`medicinehistory`.`openingBKit`,
		`medicinehistory`.`qty`,
		`medicinehistory`.`closingMain`,
		`medicinehistory`.`closingSub`,
		`medicinehistory`.`closingAKit`,
		`medicinehistory`.`closingBKit`,
		`medicinehistory`.`pno`,
		`medicinehistory`.`patientName`
	FROM `medicinehistory`
    WHERE
		mno = p_in_mno AND
        txnDate >= p_in_fromDate AND
        txnDate <= p_in_toDate;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetMedicinePatientHistory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetMedicinePatientHistory`(
IN p_in_pno varchar(20)
)
BEGIN
	
    select 
		txnDate,
        medName,
        qty
	from medicinehistory
	WHERE pno = p_in_pno
    order by txnDate;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetMedicinePurchaseDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetMedicinePurchaseDetails`(
IN p_in_mno varchar(20)
)
BEGIN

	select p.`Id`,
		p.`MedicineId`,
		p.`invdate`,
		p.`invno`,
		p.`batchno`,
		p.`expdate`,
		p.`mfgdate`,
		p.`rate`,
		p.`dealer`,
		p.`mainStock`,
		p.`subStock`,
		p.`return`
	from medicinepurchase p
	inner join medicine m on p.MedicineId = m.Id
	where m.Mno = p_in_mno;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetMedicines` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetMedicines`()
BEGIN
	
    select 
		m.id,
		m.mno,
		m.name,
		m.stock
	from medicine m
    order by m.name;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetMedicineStock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetMedicineStock`(
IN p_in_mno varchar(20)
)
BEGIN
	
    select stock from medicine 
	WHERE Mno = p_in_mno;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetOP` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetOP`(
IN p_in_pno varchar(50)
)
BEGIN

	declare p_id int;
	SELECT Id into p_id FROM patient where PNo = p_in_pno; 

	Select op.`History`, op.Medicine, op.NextOPDate
	from op op where op.PatientId = p_id;
    
    select PrevBalance + Consultation + Products - Paid as Balance
    from patientpayment where patientid = p_id
	order by id desc LIMIT 1;
    
    select 
		Id,
		TransactionDate,
		PrevBalance,
		Consultation,
		Products,
		PrevBalance + Consultation + Products as Total,
		Paid,
		PrevBalance + Consultation + Products - Paid as Balance
		from patientpayment where patientid = p_id
		order by TransactionDate desc, Id desc;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetPanjayathList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetPanjayathList`()
BEGIN
	select Id, Name from panjayath order by Name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetPatientDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetPatientDetails`(
IN p_in_pno varchar(20)
)
BEGIN

	select 
	`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
	`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
	from patient
	where Pno = p_in_pno;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetPatientList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetPatientList`(
IN p_in_status varchar(20),
IN p_in_searchText varchar(50)
)
BEGIN

	IF p_in_status = 'Active' THEN
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
        where ExpDate is null and DropDate is null and Temp = 0
        Order by `PNo`;
	ELSEIF p_in_status = 'Expired' THEN
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
        where ExpDate is not null
        Order by `PNo`;
    ELSEIF p_in_status = 'Temp' THEN
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
         where Temp = 1
         Order by `PNo`;
    ELSEIF p_in_status = 'Dropout' THEN 
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
        where DropDate is not null
        Order by `PNo`;
    ELSEIF p_in_status = 'ActiveWithTemp' THEN 
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
        where ExpDate is null and DropDate is null
        Order by `PNo`;
	ELSEIF p_in_status = 'All' THEN 
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
        Order by `PNo`;
	ELSEIF p_in_status = 'NextOP' THEN
		select 
		p.`Id`,p.`PNo`,p.`Name`,p.`Phone1`, op.NextOPDate
		from patient p
        inner join op op on p.id = op.PatientId
        where year(op.nextopdate) != 1
        Order by `PNo`;
	ELSEIF p_in_status = 'Phone' THEN
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
        where ExpDate is null and DropDate is null and Temp = 0
        and Phone1 = p_in_searchText
        Order by `PNo`;
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetRegNo` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetRegNo`()
BEGIN
 select PNo from patient order by Id desc limit 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetRehabilitation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetRehabilitation`(
IN p_in_pno varchar(45)
)
BEGIN
	SELECT 
    `Id`,
    `Date`,
    `Description`,
    `Quantity`
FROM `rehabilitation`
where Pno = p_in_pno
order by `Date`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetReportExpiry` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetReportExpiry`(
IN p_in_fromDate datetime,
IN p_in_toDate datetime
)
BEGIN

	SELECT 
		m.Id, m.Name, m.Mno, p.expdate, p.mainStock, p. subStock  
	from medicinepurchase p
	inner join medicine m on p.MedicineId = m.id
    WHERE
		p.expdate >= p_in_fromDate AND
        p.expdate <= p_in_toDate AND
        (p.mainStock > 0 OR p.subStock > 0) AND
        p.`return` = 0
    ORDER BY p.expdate;    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetReportExpiryCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetReportExpiryCount`(
IN p_in_fromDate datetime,
IN p_in_toDate datetime
)
BEGIN

	SELECT 
		Count(Id) as medCount
	FROM medicinepurchase
    WHERE
		expdate >= p_in_fromDate AND
        expdate <= p_in_toDate AND
        (mainStock > 0 OR subStock > 0) AND
        `return` = 0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetReportReceipts` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetReportReceipts`(
IN p_in_fromdate datetime,
IN p_in_todate datetime
)
BEGIN

SELECT 
	`account`.`Id`,
    `account`.`txndate`,
    `account`.`desc`,
    `account`.`type`,
    `account`.`amount`,
    `account`.`txntype`,
    `account`.`name`,
    `account`.`receiptNo`,
    `account`.`isReceipt`,
    `account`.`paymentMode`,
    `account`.`bankMode`,
    `account`.`bankName`,
    `account`.`txnNo`,
    `account`.`chNo`,
    `account`.`chdate`,
    `account`.`chBank`,
    `account`.`chAmount`
FROM `account`
WHERE 
	(`account`.`txntype` = 'Income' OR `account`.`txntype` = 'Expense') AND
    `account`.`isReceipt` = 1 AND
    `account`.`txndate` >= p_in_fromdate AND
    `account`.`txndate` <= p_in_todate
;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetReportThreshold` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetReportThreshold`(
IN p_in_thresholdCount int
)
BEGIN

	select m.Name, m.Mno, s.Main
	from medicinestock s
	inner join medicine m on s.MedicineId = m.id
    where s.Main > 0 AND s.Main <= p_in_thresholdCount
    order by m.Name;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetReportThresholdCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetReportThresholdCount`(
IN p_in_thresholdCount int
)
BEGIN

	SELECT 
		Count(Id) as medCount
	FROM medicinepurchase
    WHERE
		mainStock > 0 AND 
        mainStock <= p_in_thresholdCount AND
        `return` = 0;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetRouteList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetRouteList`()
BEGIN
	select Id, Name from route order by Name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetVolunteerList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_GetVolunteerList`()
BEGIN
	select Id, Name, Location, Phone from volunteer order by Name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_MedicineInbound` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_MedicineInbound`(
IN p_in_txndate datetime,
IN p_in_mno varchar(45),
IN p_in_qty int
)
BEGIN
    
    IF EXISTS (SELECT 1 FROM `medicine` where Mno = p_in_mno) THEN
       
        update medicine 
		set Stock = (Stock + p_in_qty)
		where Mno = p_in_mno;
                
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_MedicineReturn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_MedicineReturn`(
IN p_in_txndate datetime,
IN p_in_mno varchar(45),
IN p_in_mainRet int,
IN p_in_mainStock int,
IN p_in_subRet int,
IN p_in_subStock int,
IN p_in_purId int
)
BEGIN

    Declare p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id INT;
    Declare p_med_name varchar(200);
    
    IF EXISTS (SELECT 1 FROM `medicine` where Mno = p_in_mno) THEN
    	
        select 
			s.Main, s.Sub, s.A_kit, s.B_kit, s.MedicineId, m.Name 
			into p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_med_name
		from medicinestock s
		inner join medicine m on s.MedicineId = m.Id
		where m.Mno = p_in_mno;
        
        update medicinestock 
			set Main = (Main - p_in_mainRet),
			Sub = (Sub - p_in_subRet)
		where MedicineId = p_m_id;
        
        update medicinepurchase
			set mainStock =  (mainStock - p_in_mainRet),
            subStock =  (subStock - p_in_subRet)
		where Id = p_in_purId;
        
        INSERT INTO `medicinepurchase`
		(
		`MedicineId`,
		`invdate`,
		`invno`,
		`batchno`,
		`expdate`,
		`mfgdate`,
		`rate`,
		`dealer`,
		`mainStock`,
		`subStock`,
		`return`)
		VALUES
		(
		p_m_id,
		p_in_txndate,
		'',
		'',
		p_in_txndate,
		null,
		0,
		'',
		(p_in_mainRet + p_in_subRet),
		0,
		1);
        
        CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_in_mno, 
		p_med_name,
		'Return', -- txnType
		'Return stock', -- desc
		p_openMain, -- openingMain
        p_openSub, -- openingSub
        p_openAKit, -- openingAKit
        p_openBKit, -- openingBKit
		(p_in_mainRet + p_in_subRet), -- qty
		(p_openMain - p_in_mainRet), -- closingMain
		(p_openSub - p_in_subRet), -- closingSub
        p_openAKit, -- closingAKit
        p_openBKit, -- closingBKit
        '', -- pno
        '' -- patientName
        );
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_MedicineTransfer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_MedicineTransfer`(
IN p_in_txndate datetime,
IN p_in_mno varchar(45),
IN p_in_qty int,
IN p_in_source varchar(50),
IN p_in_transferto varchar(50)
)
BEGIN

    Declare p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_purId, p_purMainStock, p_qty INT;
    Declare p_med_name varchar(200);
    DEClARE curPurch 
		CURSOR FOR 
			select 
			p.Id, p.mainStock 
		from 
			medicinepurchase p
			inner join medicine m on p.MedicineId = m.Id
		where 
			m.Mno = p_in_mno
			and p.mainStock > 0
			and p.expdate is not null
            and `return` = 0
		order by p.expdate;
    
    IF EXISTS (SELECT 1 FROM `medicine` where Mno = p_in_mno) THEN
    	
        SET p_qty = p_in_qty;
        
		select 
			s.Main, s.Sub, s.A_kit, s.B_kit, s.MedicineId, m.Name 
			into p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_med_name
		from medicinestock s
		inner join medicine m on s.MedicineId = m.Id
		where m.Mno = p_in_mno;
        
        update medicinestock 
		set Main = (Main - p_in_qty),
        Sub = (Sub + p_in_qty)
		where MedicineId = p_m_id;

        OPEN curPurch;
        
        transferLoop: LOOP
			FETCH curPurch INTO p_purId, p_purMainStock;
                        
            IF p_purMainStock <= p_qty THEN
				update medicinepurchase
				set 
					subStock = (subStock + mainStock),
					mainStock = 0
				where Id = p_purId;
                SET p_qty = p_qty - p_purMainStock;
            ELSE
				update medicinepurchase
				set 
					subStock = (subStock + p_qty),
					mainStock = (mainStock - p_qty)
				where Id = p_purId;
                SET p_qty = 0;
            END IF;

			IF p_qty = 0 THEN
				LEAVE transferLoop;
			END IF;
        END LOOP transferLoop;
        CLOSE curPurch;

        CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_in_mno, 
		p_med_name,
		'Transfer', -- txnType
		'Main to Sub', -- desc
		p_openMain, -- openingMain
        p_openSub, -- openingSub
        p_openAKit, -- openingAKit
        p_openBKit, -- openingBKit
		p_in_qty, -- qty
		(p_openMain - p_in_qty), -- closingMain
		(p_openSub + p_in_qty), -- closingSub
        p_openAKit, -- closingAKit
        p_openBKit, -- closingBKit
        '', -- pno
        '' -- patientName
        );
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_MedicineTransferKitStock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_MedicineTransferKitStock`(
IN p_in_txndate datetime,
IN p_in_mno varchar(45),
IN p_in_qty int,
IN p_in_stocktype varchar(50),
IN p_in_pno varchar(50),
IN p_in_patientname varchar(200)
)
BEGIN

    Declare p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, 
		p_purId, p_purSubStock, p_closeAKit, p_closeBKit INT;
    Declare p_med_name varchar(200);
        
    IF EXISTS (SELECT 1 FROM `medicine` where Mno = p_in_mno) THEN
        
		select 
			s.Main, s.Sub, s.A_kit, s.B_kit, s.MedicineId, m.Name 
			into p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_med_name
		from medicinestock s
		inner join medicine m on s.MedicineId = m.Id
		where m.Mno = p_in_mno;
        
        IF p_in_stocktype = "A Kit" THEN
			update medicinestock 
			set A_kit = (A_kit - p_in_qty)
			where MedicineId = p_m_id;
            
            SET p_closeAKit = p_openAKit - p_in_qty;
            SET p_closeBKit = p_openBKit;
            
        ELSE
			update medicinestock 
			set B_kit = (B_kit - p_in_qty)
			where MedicineId = p_m_id;
            
            SET p_closeAKit = p_openAKit;
            SET p_closeBKit = p_openBKit - p_in_qty;
            
        END IF;
        
        CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_in_mno, 
		p_med_name,
		'Transfer', -- txnType
		CONCAT(p_in_stocktype, ' to OP'), -- desc
		p_openMain, -- openingMain
        p_openSub, -- openingSub
        p_openAKit, -- openingAKit
        p_openBKit, -- openingBKit
		p_in_qty, -- qty
		p_openMain, -- closingMain
		p_openSub, -- closingSub
        p_closeAKit, -- closingAKit
        p_closeBKit, -- closingBKit
        p_in_pno, -- pno
        p_in_patientname -- patientName
        );
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_MedicineTransferSubStock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_MedicineTransferSubStock`(
IN p_in_txndate datetime,
IN p_in_mno varchar(45),
IN p_in_qty int,
IN p_in_source varchar(50),
IN p_in_transferto varchar(50),
IN p_in_pno varchar(50),
IN p_in_patientname varchar(200)
)
BEGIN

    Declare p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, 
		p_purId, p_purSubStock, p_qty ,p_closeAKit, p_closeBKit INT;
    Declare p_med_name varchar(200);
    DEClARE curPurch 
		CURSOR FOR 
			select 
			p.Id, p.subStock 
		from 
			medicinepurchase p
			inner join medicine m on p.MedicineId = m.Id
		where 
			m.Mno = p_in_mno
			and p.subStock > 0
			and p.expdate is not null
            and `return` = 0
		order by p.expdate;
    
    IF EXISTS (SELECT 1 FROM `medicine` where Mno = p_in_mno) THEN
    	
        SET p_qty = p_in_qty;
        
		select 
			s.Main, s.Sub, s.A_kit, s.B_kit, s.MedicineId, m.Name 
			into p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_med_name
		from medicinestock s
		inner join medicine m on s.MedicineId = m.Id
		where m.Mno = p_in_mno;
        
        update medicinestock 
		set Sub = (Sub - p_in_qty)
		where MedicineId = p_m_id;
        
        IF p_in_transferto = "A Kit" THEN
			update medicinestock 
			set A_kit = (A_kit + p_in_qty)
			where MedicineId = p_m_id;
            
            SET p_closeAKit = p_openAKit + p_in_qty;
            SET p_closeBKit = p_openBKit;
            
        ELSEIF p_in_transferto = "B Kit" THEN
			update medicinestock 
			set B_kit = (B_kit + p_in_qty)
			where MedicineId = p_m_id;
            
            SET p_closeAKit = p_openAKit;
            SET p_closeBKit = p_openBKit + p_in_qty;
            
        ELSE
			SET p_closeAKit = p_openAKit;
			SET p_closeBKit = p_openBKit;
        END IF;
        
        OPEN curPurch;
        
        transferLoop: LOOP
			FETCH curPurch INTO p_purId, p_purSubStock;
                       
            IF p_purSubStock <= p_qty THEN
				update medicinepurchase
				set 
					subStock = 0
				where Id = p_purId;
                SET p_qty = p_qty - p_purSubStock;
            ELSE
				update medicinepurchase
				set 
					subStock = (subStock - p_qty)
				where Id = p_purId;
                SET p_qty = 0;
            END IF;
            
            IF p_qty = 0 THEN
				LEAVE transferLoop;
			END IF;
        
        END LOOP transferLoop;
        CLOSE curPurch;
        
        CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_in_mno, 
		p_med_name,
		'Transfer', -- txnType
		CONCAT('Sub to ', p_in_transferto), -- desc
		p_openMain, -- openingMain
        p_openSub, -- openingSub
        p_openAKit, -- openingAKit
        p_openBKit, -- openingBKit
		p_in_qty, -- qty
		(p_openMain), -- closingMain
		(p_openSub - p_in_qty), -- closingSub
        p_closeAKit, -- closingAKit
        p_closeBKit, -- closingBKit
        p_in_pno, -- pno
        p_in_patientname -- patientName
        );
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ProcessCheque` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_ProcessCheque`(
IN p_in_txndate datetime,
IN p_in_id int
)
BEGIN

	declare p_amount DECIMAL(10,2);
	select chAmount into p_amount from `account` where `Id` = p_in_id;

	UPDATE `account`
	SET
	`txndate` = p_in_txndate,
	`amount` = p_amount
	WHERE `Id` = p_in_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReportAccountDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_ReportAccountDetails`(
IN p_in_fromdate datetime,
IN p_in_todate datetime,
IN p_in_txntype varchar(20)
)
BEGIN

SELECT 
    `account`.`type`,
    `account`.`txntype`,
    sum(`account`.`amount`) amt
FROM `account`
WHERE 
	`account`.`txndate` >= p_in_fromdate AND 
    `account`.`txndate` <= p_in_todate AND 
    `account`.`amount` != 0 AND
    `account`.`txntype` = p_in_txntype
GROUP BY
	 `account`.`type`, `account`.`txntype`
ORDER BY `account`.`type`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReportDaybookBalance` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_ReportDaybookBalance`(
IN p_in_fromdate datetime
)
BEGIN

/*select bankname, sum(amount) amt from account
where txndate < p_in_fromdate
group by bankname;

select bankname, sum(amount) amt from account
where txndate <= p_in_fromdate
group by bankname;*/


select  sum(amount) amt from account
where txndate < p_in_fromdate
;

select  sum(amount) amt from account
where txndate <= p_in_fromdate
;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReportDaybookLedger` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_ReportDaybookLedger`(
IN p_in_fromdate datetime
)
BEGIN

SELECT `account`.`Id`,
    `account`.`type`,
    `account`.`amount`,
    `account`.`txntype`,
    `account`.`paymentmode`,
     CASE 
		WHEN `account`.PatientId IS NOT NULL then CONCAT(p.PNo, ' - ',  p.Name)
        ELSE `account`.desc
	END as `desc`
FROM `account`
left join patient p on `account`.PatientId = p.id
WHERE `account`.`txndate` = p_in_fromdate
	AND `account`.`amount` != 0
ORDER BY `account`.`desc`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReportEOM` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_ReportEOM`(
IN p_in_fromdate datetime,
IN p_in_todate datetime
)
BEGIN

-- [0] Opening balance
select ifnull(sum(amount),0) amount from account where txndate < p_in_fromdate;

-- [1] Bank Income
select ifnull(sum(amount),0) amount
from account
where txndate >= p_in_fromdate
and txndate <= p_in_todate
and paymentMode = 'Bank'
and txntype = 'Income';

-- [2] Bank Expense
select ifnull(sum(amount),0) * -1 amount
from account
where txndate >= p_in_fromdate
and txndate <= p_in_todate
and paymentMode = 'Bank'
and txntype = 'Expense';

-- [3] Income
select ifnull(sum(amount),0) amount
from account
where txndate >= p_in_fromdate
and txndate <= p_in_todate
and txntype = 'Income';

-- [4] Expense
select ifnull(sum(amount),0) * -1 amount
from account
where txndate >= p_in_fromdate
and txndate <= p_in_todate
and type != 'Savings'
and txntype = 'Expense';

-- [5] savings
select ifnull(amount,0) * -1 amount  
from account
where txndate >= p_in_fromdate
and txndate <= p_in_todate
and type = 'Savings'
and txntype = 'Expense';

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReportMonthlyBalance` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_ReportMonthlyBalance`(
IN p_in_fromdate datetime,
IN p_in_todate datetime
)
BEGIN

select ifnull(sum(amount),0) amt from account
where txndate < p_in_fromdate;

select sum(amount) amt from account
where txndate <= p_in_todate;

select txndate ,sum(Amount) TotalAmount
from account
where txndate >= p_in_fromdate
and txndate <= p_in_todate
and txntype = 'Income'
and Amount != 0
group by txndate;

select txndate ,sum(Amount) * -1 TotalAmount
from account
where txndate >= p_in_fromdate
and txndate <= p_in_todate
and txntype = 'Expense'
and type != 'Savings'
and Amount != 0
group by txndate;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReportPatientCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_ReportPatientCount`(
IN p_in_fromdate datetime,
IN p_in_todate datetime
)
BEGIN

select 
	x.txndate,
    ifnull(NewCount,0) NewCount,
    TotalCount - ifnull(NewCount,0) FollowupCount,
    TotalCount
from 
	(
		select transactiondate txndate ,count(distinct patientid) TotalCount 
        from patientpayment
		where transactiondate >= p_in_fromdate
			and transactiondate <= p_in_todate
		group by transactiondate 
	) x 
	left join 
    (
		select RegDate txndate, count(id) NewCount from patient
		where RegDate >= p_in_fromdate
		and RegDate <= p_in_todate
		group by RegDate
	) y 
    on x.txndate = y.txndate
	order by x.txndate;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReturnEquipment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_ReturnEquipment`(
IN p_in_indate datetime,
IN p_in_eno varchar(45),
IN p_in_qty int,
IN p_in_id int
)
BEGIN
	
	IF EXISTS (SELECT 1 FROM `equipment` where eno = p_in_eno) THEN
   
		UPDATE `equipment`
		SET
		stock = (stock + p_in_qty),
		inuse = (inuse - p_in_qty)
		WHERE eno = p_in_eno;
    
		UPDATE `equipmenttracker`
        SET indate = p_in_indate
		WHERE Id = p_in_id;
        
	END IF;
       
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_SaveOP` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_SaveOP`(
IN p_in_pno varchar(50),
IN p_in_history LONGBLOB,
IN p_in_medicine LONGBLOB,
IN p_in_nextOPDate datetime
)
BEGIN

	declare p_id int;
	SELECT Id into p_id FROM patient where PNo = p_in_pno; 

	IF EXISTS (SELECT 1 FROM op where PatientId = p_id) THEN	
		UPDATE op
			SET `History` = p_in_history,
            Medicine = p_in_medicine,
            NextOPDate = p_in_nextOPDate
        WHERE PatientId = p_id;
     ELSE
		INSERT INTO op
		(PatientId, `History`, Medicine, NextOPDate)
		VALUES
		(p_id, p_in_history, p_in_medicine, p_in_nextOPDate);
     END IF;
	

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_SavePayment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_SavePayment`(
IN p_in_pno varchar(50),
IN p_in_paymentDate datetime,
IN p_in_prevbalance DECIMAL(10,2),
IN p_in_consultation DECIMAL(10,2),
IN p_in_products DECIMAL(10,2),
IN p_in_paid DECIMAL(10,2),
OUT p_out int
)
BEGIN

	declare p_id int;
	SELECT Id into p_id FROM patient where PNo = p_in_pno; 

	INSERT INTO patientpayment
	(PatientId, TransactionDate, Consultation, Products, PrevBalance, Paid )
	VALUES
	(p_id, p_in_paymentDate, 
    p_in_consultation, 
    p_in_products, 
    p_in_prevbalance,
    p_in_paid);

	set p_out =  LAST_INSERT_ID();
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_TransferEquipment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_TransferEquipment`(
IN p_in_outdate datetime,
IN p_in_eno varchar(45),
IN p_in_qty int,
IN p_in_pno varchar(45),
IN p_in_patientname varchar(200)
)
BEGIN
	
    Declare p_e_id int;
	
	IF EXISTS (SELECT 1 FROM `equipment` where eno = p_in_eno) THEN
    
		select Id into p_e_id from equipment where eno = p_in_eno;
    
		UPDATE `equipment`
		SET
		stock = (stock - p_in_qty),
		inuse = (inuse + p_in_qty)
		WHERE Id = p_e_id;
    
		INSERT INTO `equipmenttracker`
		(
		`EquipmentId`,
		`patientname`,
		`pno`,
		`qty`,
		`outdate`,
		`indate`)
		VALUES
		(
		p_e_id,
		p_in_patientname,
		p_in_pno,
		p_in_qty,
		p_in_outdate,
		null);
        
	END IF;
       
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateAccountLedger` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_UpdateAccountLedger`(
IN p_in_id int,
IN p_in_desc varchar(200),
IN p_in_type varchar(45),
IN p_in_amount DECIMAL(10,2),
IN p_in_paymentMode varchar(45)
)
BEGIN
	    
	UPDATE `account`
	SET
	`desc` = p_in_desc,
	`type` = p_in_type,
	`amount` = p_in_amount,
	`paymentMode` = p_in_paymentMode
	WHERE `Id` = p_in_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateBank` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_UpdateBank`(
IN p_in_id INT,
IN p_in_name varchar(200)
)
BEGIN
	UPDATE `bank`
	SET
	`Name` = p_in_name
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateCenter` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_UpdateCenter`(
IN p_in_name varchar(255),
IN p_in_address varchar(255),
IN p_in_desc varchar(255),
IN p_in_location varchar(255),
IN p_in_phone varchar(45),
IN p_in_regno varchar(45),
IN p_in_addressMal nvarchar(255),
IN p_in_locationMal nvarchar(255),
IN p_in_nameMal nvarchar(255),
IN p_in_medExpiryDays int,
IN p_in_medThresholdCount int,
IN p_in_descMal nvarchar(255)
)
BEGIN
	UPDATE center
	SET
	`Name` = p_in_name,
	`Address` = p_in_address,
	`Desc` = p_in_desc,
	`Location` = p_in_location,
	`Phone` = p_in_phone,
	`RegNo` = p_in_regno,
	`AddressMal` = p_in_addressMal,
	`LocationMal` =p_in_locationMal,
	`NameMal` =p_in_nameMal,
	`MedExpiryDays` = p_in_medExpiryDays,
	`MedThresholdCount` =p_in_medThresholdCount,
	`DescMal` = p_in_descMal;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateDiagnosis` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_UpdateDiagnosis`(
IN p_in_id INT,
IN p_in_name varchar(100)
)
BEGIN
	UPDATE `diagnosis`
	SET
	`Name` = p_in_name
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateEquipment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_UpdateEquipment`(
IN p_in_id int,
IN p_in_name varchar(200),
IN p_in_name_lower varchar(200),
IN p_in_stock int,
IN p_in_inuse int,
IN p_in_damage int
)
BEGIN

	UPDATE `equipment`
	SET
    `name` = p_in_name,
    `name_lower` = p_in_name_lower,
	`stock` = p_in_stock,
	`damage` = p_in_damage,
	`inuse` = p_in_inuse
	WHERE `Id` = p_in_id;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateExpenseType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_UpdateExpenseType`(
IN p_in_id INT,
IN p_in_expensetype varchar(100)
)
BEGIN
	UPDATE `expensetype`
	SET
	`ExpenseType` = p_in_expensetype
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateHoliday` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_UpdateHoliday`(
IN p_in_id INT,
IN p_in_year int,
IN p_in_month int,
IN p_in_count int
)
BEGIN
	UPDATE `holiday`
	SET
	`year` = p_in_year,
	`month` = p_in_month,
	`count` = p_in_count
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateHomeCarePlan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_UpdateHomeCarePlan`(
IN p_in_id int,
IN p_in_type varchar(45),
IN p_in_date datetime
)
BEGIN
	UPDATE `homecareplan`
	SET
	`Type` = p_in_type,
	`Date` = p_in_date
	WHERE `Id` = p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateIncomeType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_UpdateIncomeType`(
IN p_in_id INT,
IN p_in_incometype varchar(100)
)
BEGIN
	UPDATE `incometype`
	SET
	`IncomeType` = p_in_incometype
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateMedicine` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_UpdateMedicine`(
IN p_in_id INT,
IN p_in_name varchar(200),
IN p_in_name_lower varchar(200),
IN p_in_qty INT
)
BEGIN
	UPDATE `medicine`
	SET
	`Name` = p_in_name,
    `NameLower` = p_in_name_lower,
    Stock = p_in_qty
	WHERE `Id` = p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateMedicineStock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_UpdateMedicineStock`(
IN p_in_purid INT,
IN p_in_mno varchar(20),
IN p_in_mainDiff int,
IN p_in_mainNew int,
IN p_in_subDiff int,
IN p_in_subNew int,
IN p_in_txndate datetime
)
BEGIN
	
    Declare p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id INT;
    Declare p_med_name varchar(200);
    
    select 
		s.Main, s.Sub, s.A_kit, s.B_kit, s.MedicineId, m.Name 
        into p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_med_name
    from medicinestock s
    inner join medicine m on s.MedicineId = m.Id
    where m.Mno = p_in_mno;
    
    update medicinestock 
    set Main = (Main - p_in_mainDiff),
    Sub = (Sub - p_in_subDiff)
    where MedicineId = p_m_id;
    
    update medicinepurchase
    set mainStock = p_in_mainNew,
		subStock = p_in_subNew
    where id = p_in_purid;

	 CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_in_mno, 
		p_med_name,
		'Edit', -- txnType
		'Edit stock', -- desc
		p_openMain, -- openingMain
        p_openSub, -- openingSub
        p_openAKit, -- openingAKit
        p_openBKit, -- openingBKit
		0, -- qty
		(p_openMain - p_in_mainDiff), -- closingMain
		(p_openSub - p_in_subDiff), -- closingSub
        p_openAKit, -- closingAKit
        p_openBKit, -- closingBKit
        '', -- pno
        '' -- patientName
        );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdatePanjayath` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_UpdatePanjayath`(
IN p_in_id INT,
IN p_in_name varchar(100)
)
BEGIN
	UPDATE `panjayath`
	SET
	`Name` = p_in_name
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdatePatient` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_UpdatePatient`(
IN p_in_id int,
IN p_in_name varchar(200),
IN p_in_age varchar(45),
IN p_in_address varchar(255),
IN p_in_grade varchar(45),
IN p_in_gender varchar(45),
IN p_in_panjayath varchar(100),
IN p_in_wardno varchar(45),
IN p_in_phone1 varchar(45),
IN p_in_phone2 varchar(45),
IN p_in_regdate datetime,
IN p_in_expdate datetime,
IN p_in_dropdate datetime,
IN p_in_volunteer varchar(100),
IN p_in_diagnosis varchar(100),
IN p_in_temp tinyint,
IN p_in_route varchar(100),
IN p_in_homecareplan varchar(45)

)
BEGIN
	UPDATE `patient`
	SET
	`Name` = p_in_name,
	`Age` = p_in_age,
	`Address` = p_in_address,
	`Grade` = p_in_grade,
	`Gender` = p_in_gender,
	`Panjayath` = p_in_panjayath,
	`WardNo` = p_in_wardno,
	`Phone1` = p_in_phone1,
	`Phone2` = p_in_phone2,
	`RegDate` = p_in_regdate,
	`ExpDate` = p_in_expdate,
	`DropDate` = p_in_dropdate,
	`Volunteer` = p_in_volunteer,
	`Diagnosis` = p_in_diagnosis,
	`Temp` = p_in_temp,
	`Route` = p_in_route,
	`HomeCarePlan` = p_in_homecareplan
	WHERE `Id` = p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateRehabilitation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_UpdateRehabilitation`(
IN p_in_id int,
IN p_in_desc varchar(200),
IN p_in_qty int
)
BEGIN
	UPDATE `rehabilitation`
	SET
	`Description` = p_in_desc,
	`Quantity` = p_in_qty
	WHERE `Id` = p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateRoute` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_UpdateRoute`(
IN p_in_id INT,
IN p_in_name varchar(100)
)
BEGIN
	UPDATE `route`
	SET
	`Name` = p_in_name
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateToday` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_UpdateToday`(
IN p_in_date varchar(255)
)
BEGIN

	UPDATE center SET `TodayAPI` = p_in_date;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateVolunteer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_UNSIGNED_SUBTRACTION' */ ;
DELIMITER ;;
CREATE DEFINER=`olive`@`%` PROCEDURE `spr_UpdateVolunteer`(
IN p_in_id INT,
IN p_in_name varchar(100),
IN p_in_location varchar(100),
IN p_in_phone varchar(45)
)
BEGIN
	UPDATE `volunteer`
	SET
	`Name` = p_in_name,
	`Location` = p_in_location,
	`Phone` = p_in_phone
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-01 15:31:58
