self.__precacheManifest = [
  {
    "revision": "b06805041a260a3db14d",
    "url": "/PalCare/static/css/main.9ac4c189.chunk.css"
  },
  {
    "revision": "b06805041a260a3db14d",
    "url": "/PalCare/static/js/main.8ea5e2e4.chunk.js"
  },
  {
    "revision": "3056d01c3b2fc1a4566e",
    "url": "/PalCare/static/js/runtime~main.435b914b.js"
  },
  {
    "revision": "fadcdcad36c49cedfa25",
    "url": "/PalCare/static/css/2.086d04f8.chunk.css"
  },
  {
    "revision": "fadcdcad36c49cedfa25",
    "url": "/PalCare/static/js/2.2f78655c.chunk.js"
  },
  {
    "revision": "f59c7c0c9ce902ad0665c9cec0ab555b",
    "url": "/PalCare/static/media/logo.f59c7c0c.png"
  },
  {
    "revision": "9bc3284c832973b6576d9969ffa3597b",
    "url": "/PalCare/static/media/Center.9bc3284c.jpeg"
  },
  {
    "revision": "19812168d411dd804760af66cc088085",
    "url": "/PalCare/static/media/primeicons.19812168.eot"
  },
  {
    "revision": "6c87b4199cb02ed5368560ad7ec744a6",
    "url": "/PalCare/static/media/primeicons.6c87b419.woff"
  },
  {
    "revision": "170c390bf17029714210dbf7f99e637a",
    "url": "/PalCare/static/media/primeicons.170c390b.ttf"
  },
  {
    "revision": "0f23e98e35f180d2fb832d3f18e7b5ba",
    "url": "/PalCare/static/media/primeicons.0f23e98e.svg"
  },
  {
    "revision": "60c866748ff15f5b347fdba64596b1b1",
    "url": "/PalCare/static/media/open-sans-v15-latin-300.60c86674.woff2"
  },
  {
    "revision": "76b56857ebbae3a5a689f213feb11af0",
    "url": "/PalCare/static/media/open-sans-v15-latin-300.76b56857.eot"
  },
  {
    "revision": "177cc92d2e8027712a8c1724abd272cd",
    "url": "/PalCare/static/media/open-sans-v15-latin-300.177cc92d.ttf"
  },
  {
    "revision": "521d17bc9f3526c690e8ada6eee55bec",
    "url": "/PalCare/static/media/open-sans-v15-latin-300.521d17bc.woff"
  },
  {
    "revision": "cffb686d7d2f4682df8342bd4d276e09",
    "url": "/PalCare/static/media/open-sans-v15-latin-regular.cffb686d.woff2"
  },
  {
    "revision": "9dce7f01715340861bdb57318e2f3fdc",
    "url": "/PalCare/static/media/open-sans-v15-latin-regular.9dce7f01.eot"
  },
  {
    "revision": "c045b73d86803686f4cd1cc3f9ceba59",
    "url": "/PalCare/static/media/open-sans-v15-latin-regular.c045b73d.ttf"
  },
  {
    "revision": "27ef0b062b2e221df16f3bbd97c2dca8",
    "url": "/PalCare/static/media/open-sans-v15-latin-300.27ef0b06.svg"
  },
  {
    "revision": "bf2d0783515b7d75c35bde69e01b3135",
    "url": "/PalCare/static/media/open-sans-v15-latin-regular.bf2d0783.woff"
  },
  {
    "revision": "7aab4c13671282c90669eb6a10357e41",
    "url": "/PalCare/static/media/open-sans-v15-latin-regular.7aab4c13.svg"
  },
  {
    "revision": "148a6749baa5f658a45183ddb5ee159f",
    "url": "/PalCare/static/media/open-sans-v15-latin-700.148a6749.eot"
  },
  {
    "revision": "623e3205570002af47fc2b88f9335d19",
    "url": "/PalCare/static/media/open-sans-v15-latin-700.623e3205.woff"
  },
  {
    "revision": "7e08cc656863d52bcb5cd34805ac605b",
    "url": "/PalCare/static/media/open-sans-v15-latin-700.7e08cc65.ttf"
  },
  {
    "revision": "d08c09f2f169f4a6edbcf8b8d1636cb4",
    "url": "/PalCare/static/media/open-sans-v15-latin-700.d08c09f2.woff2"
  },
  {
    "revision": "2e00b2635b51ba336b4b67a5d0bc03c7",
    "url": "/PalCare/static/media/open-sans-v15-latin-700.2e00b263.svg"
  },
  {
    "revision": "c7a33805ffda0d32bd2a9904c8b02750",
    "url": "/PalCare/static/media/color.c7a33805.png"
  },
  {
    "revision": "567f57385ea3dde2c9aec797d07850d2",
    "url": "/PalCare/static/media/line.567f5738.gif"
  },
  {
    "revision": "b29a888ff7f07091c7e08eb0d991e221",
    "url": "/PalCare/static/media/primeicons.b29a888f.ttf"
  },
  {
    "revision": "e01fd4133bac49cd2ea07ad6f7c45695",
    "url": "/PalCare/static/media/primeicons.e01fd413.eot"
  },
  {
    "revision": "943c3597cd33be56d53df0d1982fa8ff",
    "url": "/PalCare/static/media/primeicons.943c3597.woff"
  },
  {
    "revision": "319a2b2ccc562ca14dca448561ec4c1e",
    "url": "/PalCare/static/media/primeicons.319a2b2c.svg"
  },
  {
    "revision": "20ac1e6c0b5b9406aaadbfe52209e936",
    "url": "/PalCare/index.html"
  }
];