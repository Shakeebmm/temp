const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let MedicineHistory = new Schema(
  {
    txnDate: {
      type: Date
    },
    mno: {
      type: String
    },
    medName: {
      type: String
    },
    txnType: {
      type: String //(add/edit/return/transfer)
    },
    desc: {
      type: String
    },
    openingMain: {
      type: Number
    },
    openingSub: {
      type: Number
    },
    openingAKit: {
      type: Number
    },
    openingBKit: {
      type: Number
    },
    qty: {
      type: Number
    },
    closingMain: {
      type: Number
    },
    closingSub: {
      type: Number
    },
    closingAKit: {
      type: Number
    },
    closingBKit: {
      type: Number
    },
    pno: {
      type: String
    },
    patientName: {
      type: String
    }
  },
  {
    collection: "medicineHistory"
  }
);

module.exports = mongoose.model("medicineHistory", MedicineHistory);
