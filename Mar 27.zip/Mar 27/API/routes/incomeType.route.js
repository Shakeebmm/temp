const express = require("express");
var Promise = require("promise");
const routes = express.Router();
let IncomeType = require("../database/schemas/incomeType.model");

// Defined store route
routes.post("*/incomeType/add", function(req, res, next) {
  try {
    let incomeType = new IncomeType(req.body);
    incomeType.save().then(res.status(200).send("Success"));
  } catch (err) {
    next(new Error(err));
  }
});

// Defined get data(index or listing) route
routes.get("*/incomeType", function(req, res, next) {
  IncomeType.find(function(err, incomeTypes) {
    if (err) {
      next(new Error(err));
    } else {
      res.status(200).json(incomeTypes);
    }
  });
});

routes.get("*/incomeType/getIncomeTypes", function(req, res, next) {
  try {
    IncomeType.find({}, { _id: 0, incomeType: 1 }, function(err, data) {
      if (err) {
        next(new Error(err));
      } else {
        res.status(200).json(data);
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

// Defined edit route
routes.get("*/incomeType/edit/:id", function(req, res) {
  let id = req.params.id;
  IncomeType.findById(id, function(err, incomeType) {
    res.status(200).json(incomeType);
  });
});

//  Defined update route
routes.post("*/incomeType/update/:id", function(req, res, next) {
  try {
    IncomeType.findById(req.params.id, function(err, incomeType) {
      if (!incomeType) res.status(404).send("Data not found");
      else {
        incomeType.incomeType = req.body.incomeType;

        incomeType.save().then(incomeType => {
          res.status(200).json("Update complete");
        });
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

// Defined delete | remove | destroy route
routes.get("*/incomeType/delete/:id", function(req, res) {
  IncomeType.findOneAndDelete({ _id: req.params.id }, function(
    err,
    incomeType
  ) {
    if (err) res.json(err);
    else res.json("Successfully removed");
  });
});

module.exports = routes;
