const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const cors = require("cors");
var router = require("./src/routes/router");
require("./src/DB.js");
const logger = require("./src/utils/logger/logger").getLoggerInstance();

require("dotenv").config();

app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(router);

// error handler
app.use(function(err, req, res, next) {
  logger.log("error", `${err}`);

  res.status(500).send(
    JSON.stringify({
      status: 500,
      message: "Something went wrong.",
      detail: err.message
    })
  );
});

app.listen(process.env.PORT, function() {
  //http://localhost/node/api/patient

  console.log("Server is running on Port:", process.env.PORT);
});

//https://gist.github.com/rttomlinson/10c658ea276d3cfc1dc90b391af4c817
