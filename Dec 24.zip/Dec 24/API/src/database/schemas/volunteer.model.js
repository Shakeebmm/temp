const mongoose = require("mongoose");
const Schema = mongoose.Schema;

// Define collection and schema for Business
let Volunteer = new Schema(
  {
    vno: {
      type: String
    },
    name: {
      type: String
    },
    location: {
      type: String
    },
    phone: {
      type: String
    }
  },
  {
    collection: "volunteer"
  }
);

module.exports = mongoose.model("Volunteer", Volunteer);
