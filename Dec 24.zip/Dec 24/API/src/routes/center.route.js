const express = require("express");
const centerRoutes = express.Router();
let Center = require("../database/schemas/center.model");

// Defined edit route
centerRoutes.get("*/center/getName", function(req, res, next) {
  try {
    Center.findOne(function(err, center) {
      res.json(center.name);
    });
  } catch (err) {
    next(new Error(err));
  }
});

centerRoutes.get("*/center/edit", function(req, res, next) {
  try {
    Center.findOne(function(err, center) {
      res.json(center);
    });
  } catch (err) {
    next(new Error(err));
  }
});

//  Defined update route
centerRoutes.post("*/center/update/:id", function(req, res, next) {
  try {
    Center.findById(req.params.id, function(err, center) {
      if (!center) res.status(404).send("data is not found");
      else {
        center.name = req.body.name;
        center.desc = req.body.desc;
        center.location = req.body.location;
        center.regno = req.body.regno;
        center.address = req.body.address;
        center.phone = req.body.phone;

        center.save().then(center => {
          res.json("Update complete");
        });
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

module.exports = centerRoutes;
