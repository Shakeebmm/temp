const express = require("express");
const routes = express.Router();
let CashBalance = require("../database/schemas/cashBalance.model");
const moment = require("moment-timezone");

routes.post("*/report/monthly", function(req, res, next) {
  try {
    var report = { cash: "", openSum: 0, closeSum: 0 };

    var month = new Date(moment(req.body.month).format("YYYY-MM-DD"));
    CashBalance.findOne({ month: month }, function(err, balance) {
      if (!balance) {
        res.status(200).json("NA");
      } else {
        report.cash = balance.balance;
        var openSum = 0,
          closeSum = 0;
        balance.balance.forEach(function(obj) {
          openSum += obj.open;
          closeSum += obj.close;
        });
        report.openSum = openSum;
        report.closeSum = closeSum;
        res.status(200).json(report);
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

module.exports = routes;
