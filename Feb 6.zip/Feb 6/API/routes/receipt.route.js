const moment = require("moment-timezone");
const express = require("express");
const routes = express.Router();
let Account = require("../database/schemas/account.model");

// Defined store route
routes.post("*/receipt/add", function(req, res, next) {
  try {
    let account = new Account(req.body);

    account.txndate = moment(account.txndate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD");

    account.save().then(res.status(200).send("Success"));
  } catch (err) {
    next(new Error(err));
  }
});

routes.post("*/receipt", function(req, res, next) {
  var fromDate = new Date(
    moment(req.body.fromDate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD")
  );

  var toDate = new Date(
    moment(req.body.toDate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD")
  );

  Account.find(
    {
      $or: [{ txntype: "Voucher" }, { txntype: "Receipt" }],
      txndate: { $gte: fromDate, $lte: toDate }
    },
    function(err, accounts) {
      if (err) {
        next(new Error(err));
      } else {
        res.status(200).json(accounts);
      }
    }
  );
});

// Defined edit route
routes.get("*/receipt/edit/:id", function(req, res) {
  let id = req.params.id;
  Account.findById(id, function(err, account) {
    res.status(200).json(account);
  });
});

//  Defined update route
routes.post("*/receipt/update/:id", function(req, res, next) {
  try {
    Account.findById(req.params.id, function(err, account) {
      if (!account) res.status(404).send("Data not found");
      else {
        account.desc = req.body.desc;
        account.name = req.body.name;
        account.amount = req.body.amount;

        if (account.txntype === "Receipt") account.type = req.body.type;

        account.save().then(account => {
          res.status(200).json("Update complete");
        });
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

//https://medium.com/@paulrohan/aggregation-in-mongodb-8195c8624337
//https://docs.mongodb.com/manual/reference/operator/aggregation/group/#pipe._S_group
routes.post("*/account/summaryReport", function(req, res, next) {
  var fromDate = new Date(
    moment(req.body.fromDate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD")
  );

  var toDate = new Date(
    moment(req.body.toDate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD")
  );

  try {
    if (req.body.type === "Date") {
      Account.aggregate(
        [
          {
            $match: {
              txndate: {
                $gte: fromDate,
                $lte: toDate
              }
            }
          },
          {
            $group: {
              _id: { txntype: "$txntype", txndate: "$txndate" },
              totalAmount: { $sum: "$amount" }
            }
          },
          { $sort: { "_id.txndate": 1 } }
        ],
        function(err, result) {
          if (err) {
            next(new Error(err));
          } else {
            res.json(result);
          }
        }
      );
    } else if (req.body.type === "Month") {
      Account.aggregate(
        [
          {
            $match: {
              txndate: {
                $gte: fromDate,
                $lte: toDate
              }
            }
          },
          {
            $group: {
              _id: {
                txntype: "$txntype",
                month: { $month: "$txndate" },
                year: { $year: "$txndate" }
              },
              totalAmount: { $sum: "$amount" }
            }
          },
          { $sort: { "_id.month": 1 } }
        ],
        function(err, result) {
          if (err) {
            next(new Error(err));
          } else {
            res.json(result);
          }
        }
      );
    } else if (req.body.type === "Year") {
      Account.aggregate(
        [
          {
            $match: {
              txndate: {
                $gte: fromDate,
                $lte: toDate
              }
            }
          },
          {
            $group: {
              _id: {
                txntype: "$txntype",
                year: { $year: "$txndate" }
              },
              totalAmount: { $sum: "$amount" }
            }
          },
          { $sort: { "_id.year": 1 } }
        ],
        function(err, result) {
          if (err) {
            next(new Error(err));
          } else {
            res.status(200).json(result);
          }
        }
      );
    }
  } catch (err) {
    next(new Error(err));
  }
});

routes.post("*/account/detailsReport", function(req, res, next) {
  var report = { data: "", totalAmount: 0 };

  var fromDate = new Date(
    moment(req.body.fromDate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD")
  );

  var toDate = new Date(
    moment(req.body.toDate)
      .tz("Asia/Calcutta")
      .format("YYYY-MM-DD")
  );

  try {
    Account.aggregate(
      [
        {
          $match: {
            txndate: {
              $gte: fromDate,
              $lte: toDate
            },
            txntype: {
              $eq: req.body.txnType
            }
          }
        },
        {
          $group: {
            _id: { type: "$type", txntype: "$txntype" },
            totalAmount: { $sum: "$amount" }
          }
        },
        { $sort: { "_id.type": 1 } }
      ],
      function(err, result) {
        if (err) {
          next(new Error(err));
        } else {
          report.data = result;

          var total = 0;
          result.forEach(function(obj) {
            total += obj.totalAmount;
          });
          report.totalAmount = total;

          res.status(200).json(report);
        }
      }
    );
  } catch (err) {
    next(new Error(err));
  }
});

module.exports = routes;
