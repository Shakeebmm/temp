const express = require("express");
var Promise = require("promise");
const routes = express.Router();
let Diagnosis = require("../database/schemas/diagnosis.model");

// Defined store route
routes.post("*/diagnosis/add", function(req, res, next) {
  try {
    let diagnosis = new Diagnosis(req.body);
    diagnosis.save().then(res.status(200).send("Success"));
  } catch (err) {
    next(new Error(err));
  }
});

// Defined get data(index or listing) route
routes.get("*/diagnosis", function(req, res, next) {
  try {
    Diagnosis.find(function(err, diagnosis) {
      if (err) {
        next(new Error(err));
      } else {
        res.status(200).json(diagnosis);
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

routes.get("*/diagnosis/getNames", function(req, res, next) {
  try {
    Diagnosis.find({}, { _id: 0, name: 1 }, function(err, data) {
      if (err) {
        next(new Error(err));
      } else {
        res.status(200).json(data);
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

// Defined edit route
routes.get("*/diagnosis/edit/:id", function(req, res) {
  let id = req.params.id;
  Diagnosis.findById(id, function(err, diagnosis) {
    res.status(200).json(diagnosis);
  });
});

//  Defined update route
routes.post("*/diagnosis/update/:id", function(req, res, next) {
  try {
    Diagnosis.findById(req.params.id, function(err, diagnosis) {
      if (!diagnosis) res.status(404).send("Data not found");
      else {
        diagnosis.name = req.body.name;

        diagnosis.save().then(diagnosis => {
          res.status(200).json("Update complete");
        });
      }
    });
  } catch (err) {
    next(new Error(err));
  }
});

// Defined delete | remove | destroy route
routes.get("*/diagnosis/delete/:id", function(req, res) {
  Diagnosis.findOneAndDelete({ _id: req.params.id }, function(err, diagnosis) {
    if (err) res.json(err);
    else res.json("Successfully removed");
  });
});

module.exports = routes;
