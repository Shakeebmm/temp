self.__precacheManifest = [
  {
    "revision": "fb5e5941a2897544d147",
    "url": "/PalCare/static/css/main.6acdacad.chunk.css"
  },
  {
    "revision": "fb5e5941a2897544d147",
    "url": "/PalCare/static/js/main.ee42ad12.chunk.js"
  },
  {
    "revision": "3056d01c3b2fc1a4566e",
    "url": "/PalCare/static/js/runtime~main.435b914b.js"
  },
  {
    "revision": "8e6e575d7393b290ebb7",
    "url": "/PalCare/static/css/2.9ef999c1.chunk.css"
  },
  {
    "revision": "8e6e575d7393b290ebb7",
    "url": "/PalCare/static/js/2.14d60a3e.chunk.js"
  },
  {
    "revision": "f59c7c0c9ce902ad0665c9cec0ab555b",
    "url": "/PalCare/static/media/logo.f59c7c0c.png"
  },
  {
    "revision": "f65527a0ecc5470f0ef07bf4b9babb7a",
    "url": "/PalCare/static/media/Center.f65527a0.jpeg"
  },
  {
    "revision": "19812168d411dd804760af66cc088085",
    "url": "/PalCare/static/media/primeicons.19812168.eot"
  },
  {
    "revision": "170c390bf17029714210dbf7f99e637a",
    "url": "/PalCare/static/media/primeicons.170c390b.ttf"
  },
  {
    "revision": "6c87b4199cb02ed5368560ad7ec744a6",
    "url": "/PalCare/static/media/primeicons.6c87b419.woff"
  },
  {
    "revision": "0f23e98e35f180d2fb832d3f18e7b5ba",
    "url": "/PalCare/static/media/primeicons.0f23e98e.svg"
  },
  {
    "revision": "60c866748ff15f5b347fdba64596b1b1",
    "url": "/PalCare/static/media/open-sans-v15-latin-300.60c86674.woff2"
  },
  {
    "revision": "177cc92d2e8027712a8c1724abd272cd",
    "url": "/PalCare/static/media/open-sans-v15-latin-300.177cc92d.ttf"
  },
  {
    "revision": "27ef0b062b2e221df16f3bbd97c2dca8",
    "url": "/PalCare/static/media/open-sans-v15-latin-300.27ef0b06.svg"
  },
  {
    "revision": "cffb686d7d2f4682df8342bd4d276e09",
    "url": "/PalCare/static/media/open-sans-v15-latin-regular.cffb686d.woff2"
  },
  {
    "revision": "521d17bc9f3526c690e8ada6eee55bec",
    "url": "/PalCare/static/media/open-sans-v15-latin-300.521d17bc.woff"
  },
  {
    "revision": "76b56857ebbae3a5a689f213feb11af0",
    "url": "/PalCare/static/media/open-sans-v15-latin-300.76b56857.eot"
  },
  {
    "revision": "bf2d0783515b7d75c35bde69e01b3135",
    "url": "/PalCare/static/media/open-sans-v15-latin-regular.bf2d0783.woff"
  },
  {
    "revision": "9dce7f01715340861bdb57318e2f3fdc",
    "url": "/PalCare/static/media/open-sans-v15-latin-regular.9dce7f01.eot"
  },
  {
    "revision": "c045b73d86803686f4cd1cc3f9ceba59",
    "url": "/PalCare/static/media/open-sans-v15-latin-regular.c045b73d.ttf"
  },
  {
    "revision": "d08c09f2f169f4a6edbcf8b8d1636cb4",
    "url": "/PalCare/static/media/open-sans-v15-latin-700.d08c09f2.woff2"
  },
  {
    "revision": "148a6749baa5f658a45183ddb5ee159f",
    "url": "/PalCare/static/media/open-sans-v15-latin-700.148a6749.eot"
  },
  {
    "revision": "7aab4c13671282c90669eb6a10357e41",
    "url": "/PalCare/static/media/open-sans-v15-latin-regular.7aab4c13.svg"
  },
  {
    "revision": "623e3205570002af47fc2b88f9335d19",
    "url": "/PalCare/static/media/open-sans-v15-latin-700.623e3205.woff"
  },
  {
    "revision": "7e08cc656863d52bcb5cd34805ac605b",
    "url": "/PalCare/static/media/open-sans-v15-latin-700.7e08cc65.ttf"
  },
  {
    "revision": "2e00b2635b51ba336b4b67a5d0bc03c7",
    "url": "/PalCare/static/media/open-sans-v15-latin-700.2e00b263.svg"
  },
  {
    "revision": "c7a33805ffda0d32bd2a9904c8b02750",
    "url": "/PalCare/static/media/color.c7a33805.png"
  },
  {
    "revision": "567f57385ea3dde2c9aec797d07850d2",
    "url": "/PalCare/static/media/line.567f5738.gif"
  },
  {
    "revision": "b8eccb1059ea5faaf6d8b7d457ccfd09",
    "url": "/PalCare/static/media/primeicons.b8eccb10.eot"
  },
  {
    "revision": "38d77552b0353684a208177482d5b6ee",
    "url": "/PalCare/static/media/primeicons.38d77552.svg"
  },
  {
    "revision": "473e2a746d3c151d7dcaa626a7c84c60",
    "url": "/PalCare/static/media/primeicons.473e2a74.ttf"
  },
  {
    "revision": "71bb3d79dcf18b45ae845409e7c2ada3",
    "url": "/PalCare/static/media/primeicons.71bb3d79.woff"
  },
  {
    "revision": "0395dbc975abe07fa567c962321b3ea8",
    "url": "/PalCare/index.html"
  }
];