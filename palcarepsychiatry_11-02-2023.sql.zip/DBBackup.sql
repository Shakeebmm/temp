-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: palcarepsychiatry
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `txndate` datetime DEFAULT NULL,
  `desc` varchar(200) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `txntype` varchar(45) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `receiptNo` varchar(45) DEFAULT NULL,
  `isReceipt` tinyint DEFAULT NULL,
  `paymentMode` varchar(45) DEFAULT NULL,
  `bankMode` varchar(45) DEFAULT NULL,
  `bankName` varchar(200) DEFAULT NULL,
  `txnNo` varchar(100) DEFAULT NULL,
  `chNo` varchar(45) DEFAULT NULL,
  `chdate` datetime DEFAULT NULL,
  `chBank` varchar(200) DEFAULT NULL,
  `chAmount` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES (1,'2021-10-01 00:00:00','VOLUNTEER HOME VISIT','VEHICLE',300.00,'Income','VOLUNTEER HOME VISIT','33',1,'Cash','','','','',NULL,'',0.00),(2,'2021-10-01 00:00:00','MHAT HOME SCREENING','VEHICLE',500.00,'Income','MHAT HOME SCREENING ','34',1,'Cash','','','','',NULL,'',0.00),(3,'2021-10-01 00:00:00','PSYCHIATRY OP TEA','FOOD',135.00,'Income','PSYCHIATRY OP TEA ','35',1,'Cash','','','','',NULL,'',0.00),(4,'2021-10-01 00:00:00','PSYCHIATRY SOFTWARE','SOFTWARE',10000.00,'Income','PSYCHIATRY SOFTWARE','36',1,'Bank','Transfer','FEDERAL BANK','','',NULL,'',0.00),(5,'2021-10-01 00:00:00','MHAT HOME SCREENING','VEHICLE',450.00,'Income','MHAT HOME SCREENING','37',1,'Cash','','','','',NULL,'',0.00),(6,'2021-10-01 00:00:00','MHAT HOME VISIT','FUEL',-300.00,'Expense','MHAT HOME VISIT ','38',1,'Cash','','','','',NULL,'',0.00),(7,'2021-10-01 00:00:00','HOME SCREENING','FUEL',-500.00,'Expense','HOME SCREENING ','39',1,'Cash','','','','',NULL,'',0.00),(8,'2021-10-01 00:00:00','PSYCHIATRY OP TEA','FOOD',-135.00,'Expense','PSYCHIATRY OP TEA ','40',1,'Cash','','','','',NULL,'',0.00),(9,'2021-10-01 00:00:00','PSYCHIATRY SOFTWARE','SOFTWARE',-10000.00,'Expense','PSYCHIATRY SOFTWARE ','41',1,'Bank','Transfer','FEDERAL BANK','','',NULL,'',0.00),(10,'2021-10-01 00:00:00','PSYCHIATRY HOME SCREENING','FUEL',-450.00,'Expense','PSYCHIATRY HOME SCREENING','42',1,'Cash','','','','',NULL,'',0.00),(11,'2021-10-01 00:00:00','PSYCHIATRY OP FOOD ','FOOD',-950.00,'Expense','PSYCHIATRY OP FOOD ','43',1,'Cash','','','','',NULL,'',0.00),(12,'2021-10-01 00:00:00','PSYCHIATRY STATIONARY (BOOK)','STATIONARY',-35.00,'Expense','PSYCHIATRY STATIONARY (BOOK)','44',1,'Cash','','','','',NULL,'',0.00),(13,'2021-10-01 00:00:00','PSYCHIATRY OP, COUNCILING FEES MHAT','FEES',-10000.00,'Expense','PSYCHIATRY OP, COUNCILING FEES MHAT','45',1,'Bank','Transfer','FEDERAL BANK','','',NULL,'',0.00),(14,'2021-10-01 00:00:00','PSYCHIATRY OP TEA ','FOOD',-117.00,'Expense','PSYCHIATRY OP TEA ','46',1,'Cash','','','','',NULL,'',0.00),(15,'2021-10-08 00:00:00','PSYCHIATRY OP FOOD','FOOD',-1050.00,'Expense','PSYCHIATRY OP FOOD','47',1,'Cash','','','','',NULL,'',0.00),(16,'2021-10-08 00:00:00','PSYCHIATRY STATIONRY','STATIONRY',-164.00,'Expense','PSYCHIATRY STATIONRY','48',1,'Cash','','','','',NULL,'',0.00),(17,'2021-10-08 00:00:00','PSYCHIATRY HOME VISIT ','FEUL',-300.00,'Expense','PSYCHIATRY HOME VISIT ','49',1,'Cash','','','','',NULL,'',0.00),(18,'2021-10-08 00:00:00','PSYCHIATRY OP TEA','FOOD',-202.00,'Expense','PSYCHIATRY OP TEA','50',1,'Cash','','','','',NULL,'',0.00),(19,'2021-10-08 00:00:00','PSYCHIATRY STATIONRY','STATIONRY',-625.00,'Expense','PSYCHIATRY STATIONRY','51',1,'Cash','','','','',NULL,'',0.00),(20,'2021-10-12 00:00:00','PSYCHIATRY MHAT VOLUNTEER TRAINING TEA','FOOD',-570.00,'Expense','PSYCHIATRY MHAT VOLUNTEER TRAINING TEA','52',1,'Cash','','','','',NULL,'',0.00),(21,'2021-10-14 00:00:00','CASE SHEET PURCHASE','STATIONRY',-1200.00,'Expense','CASE SHEET PURCHASE','53',1,'Cash','','','','',NULL,'',0.00),(22,'2021-10-15 00:00:00','PSYCHIATRY OP FOOD','FOOD',-1050.00,'Expense','PSYCHIATRY OP FOOD','54',1,'Cash','','','','',NULL,'',0.00),(23,'2021-10-15 00:00:00','PSYCHIATRY PO TEA','FOOD',-300.00,'Expense','PSYCHIATRY OP TEA','55',1,'Cash','','','','',NULL,'',0.00),(24,'2021-10-15 00:00:00','MHAT HOME SCREENING FUEL','FUEL',-1000.00,'Expense','MHAT HOME SCREENING FUEL','56',1,'Cash','','','','',NULL,'',0.00),(25,'2021-10-18 00:00:00','PSYCHIATRY BYSTANDERS MEETING TEA ','FOOD',-240.00,'Expense','PSYCHIATRY BYSTANDERS MEETING TEA ','57',1,'Cash','','','','',NULL,'',0.00),(26,'2021-10-19 00:00:00','BOTTLE FOR PSYCHIATRY PATIENT FATHIMMA','STATIONRY',-70.00,'Expense','BOTTLE FOR PSYCHIATRY PATIENT FATHIMMA','58',1,'Cash','','','','',NULL,'',0.00),(27,'2021-10-22 00:00:00','PSYCHIATRY HOME SCREENING FUEL','FUEL',-300.00,'Expense','PSYCHIATRY HOME SCREENING FUEL','59',1,'Cash','','','','',NULL,'',0.00),(28,'2021-10-22 00:00:00','PSYCHIATRY OP TEA','FOOD ',-200.00,'Expense','PSYCHIATRY OP TEA ','60',1,'Cash','','','','',NULL,'',0.00),(29,'2021-10-22 00:00:00','PSYCHIATRY OP FOOD ','FOOD',-1100.00,'Expense','PSYCHIATRY OP FOOD ','61',1,'Cash','','','','',NULL,'',0.00),(30,'2021-10-25 00:00:00','PSYCHIATRY VOLUNTEER TRAINING TEA','FOOD',-320.00,'Expense','PSYCHIATRY VOLUNTEER TRAINING TEA','62',1,'Cash','','','','',NULL,'',0.00),(31,'2021-10-27 00:00:00','PSYCHIATRY PO FOOD ','FOOD ',-960.00,'Expense','PSYCHIATRY PO FOOD ','63',1,'Cash','','','','',NULL,'',0.00),(32,'2021-10-29 00:00:00','PSYCHIATRY OP TEA','FOOD',-200.00,'Expense','PSYCHIATRY OP TEA','64',1,'Cash','','','','',NULL,'',0.00),(33,'2021-10-29 00:00:00','PSYCHIATRY HOME VISIT FUEL','FUEL',-1000.00,'Expense','PSYCHIATRY HOME VISIT FUEL','65',1,'Cash','','','','',NULL,'',0.00),(34,'2021-10-30 00:00:00','PSYCHIATRY OP FOOD','FOOD',-890.00,'Expense','PSYCHIATRY OP FOOD ','66',1,'Cash','','','','',NULL,'',0.00),(35,'2021-11-01 00:00:00','MHAT SALARY','SALARY',-10000.00,'Expense','',NULL,0,'Cash','','','','',NULL,'',0.00),(36,'2021-11-05 00:00:00','PSYCHIATRY OP FOOD ','FOOD',-980.00,'Expense','',NULL,0,'Cash','','','','',NULL,'',0.00),(37,'2021-11-12 00:00:00','PSYCHIATRY OP FOOD','FOOD',-700.00,'Expense','',NULL,0,'Cash','','','','',NULL,'',0.00),(38,'2021-11-15 00:00:00','PSYCHIATRY OP TEA ','FOOD',-290.00,'Expense','',NULL,0,'Cash','','','','',NULL,'',0.00),(39,'2021-11-30 00:00:00','PSYCHIATRY DAY CARE ','PSYCHIATRY DAY CARE',-500.00,'Expense','','67',1,'Cash','','','','',NULL,'',0.00);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank`
--

DROP TABLE IF EXISTS `bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bank` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(200) DEFAULT NULL,
  `IsCash` tinyint DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bank`
--

LOCK TABLES `bank` WRITE;
/*!40000 ALTER TABLE `bank` DISABLE KEYS */;
INSERT INTO `bank` VALUES (1,'Cash In Hand',1),(4,'FEDERAL BANK',0);
/*!40000 ALTER TABLE `bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `center`
--

DROP TABLE IF EXISTS `center`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `center` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Desc` varchar(255) DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `Phone` varchar(45) DEFAULT NULL,
  `RegNo` varchar(45) DEFAULT NULL,
  `AddressMal` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `LocationMal` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `NameMal` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ReceiptNo` int DEFAULT NULL,
  `MedExpiryDays` int DEFAULT NULL,
  `MedThresholdCount` int DEFAULT NULL,
  `ValidTill` varchar(255) DEFAULT NULL,
  `TodayAPI` varchar(255) DEFAULT NULL,
  `DescMal` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `center`
--

LOCK TABLES `center` WRITE;
/*!40000 ALTER TABLE `center` DISABLE KEYS */;
INSERT INTO `center` VALUES (1,'ILA (Psychiatry)','Door # 458 A/6, Kozhikode Road, Near Kinfra Park, Kuttippuram PO, Malappuram Dt, Kerala','Foundation','Kuttippuram','04942607666','151/2014','Door # 458 A/6, Kozhikode Road, Near Kinfra Park, Kuttippuram PO, Malappuram Dt, Kerala','കുറ്റിപ്പുറം','ഇല (സൈക്യാട്രി)',67,90,90,'Vb/rmpNkzy1RKv6wSjj4oh1MRe6lCpNwVHZhuuMD6SNqx7FpYe+z3pdeQ+9q2Ml51DE8ymUSNB1dSzNq7eQRLN8im1fUcZAfzI6QN1819tlrjtPLxntFH8FFB6WPtPAU','4z4JPjCNiHvX+cktrCTwup/Rc8WHR6Zxya2LLlqIbNH/REIel38qLdmpBPPu/sMXP4RuY4u7OCo0zH1+vfEypmaQP8KtdWA/l0twgxqiKqJGmIQVarOKoAy36u4T00TB','ഫൌണ്ടേഷൻ');
/*!40000 ALTER TABLE `center` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consultanttype`
--

DROP TABLE IF EXISTS `consultanttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consultanttype` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ConsultantType` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consultanttype`
--

LOCK TABLES `consultanttype` WRITE;
/*!40000 ALTER TABLE `consultanttype` DISABLE KEYS */;
INSERT INTO `consultanttype` VALUES (1,'Doctor'),(2,'Psychiatrist'),(3,'Psychologist'),(4,'Clinician');
/*!40000 ALTER TABLE `consultanttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diagnosis`
--

DROP TABLE IF EXISTS `diagnosis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diagnosis` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diagnosis`
--

LOCK TABLES `diagnosis` WRITE;
/*!40000 ALTER TABLE `diagnosis` DISABLE KEYS */;
INSERT INTO `diagnosis` VALUES (1,'SCHIZAPHRENIA'),(2,'SCHIZOAFFECTIVE DISORDER'),(3,'SCHIZOPHORENIFORM DISORDER '),(4,'DELIRIUM'),(5,'SUBSTANCE -INDUCED PSYCHOTIC DISORDER'),(6,'PSYCHOTIC DISORDER DUE TO MEDICAL CONDITION'),(7,'PARAPHRENIA'),(8,'PERSONALITY DISORDER'),(9,'BIPOLAR AFFECTIVE DISORDER'),(10,'SEIZURE DISORDER'),(11,'MENTAL RETARDDATION'),(12,'ORGANIC PSYCHOSIS'),(13,'RECCURENT DEPRESSIVE DISORDER'),(14,'OCD '),(15,'DEMENTIA'),(16,'MENTAL RETARDATION WITH PSYCHOTIC DISORDER'),(17,'PSYCHOSIS NOS'),(18,'DELUSIONAL DISORDER'),(19,'DEPRESSION WITH PSYCHOTIC SYMPTOMS'),(20,'GENARALISED ANXIETY DISORDER'),(21,' MILD INTELLECTUAL DISABILITY'),(22,'VASCULAR DEMENTIA'),(23,'DEPRESSION'),(24,'SOMATOFORM DISORDER'),(25,'AFFECTIVE PSYCHOSIS'),(26,'SEIZURE DISORDER'),(27,'CORONARY ARTERY DISEASE'),(28,'AUTISM');
/*!40000 ALTER TABLE `diagnosis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctor` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `ConsultantTypeId` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctor`
--

LOCK TABLES `doctor` WRITE;
/*!40000 ALTER TABLE `doctor` DISABLE KEYS */;
INSERT INTO `doctor` VALUES (1,'DR FAWAZ',1),(2,'FAVAZ',1),(3,'MANOJ KUMAR',1),(4,'SONA (CLINICIAN )',4),(5,'SHUKOOR (CLINICIAN )',4),(6,'JASMIN (CLINICIANS)',4),(7,'ABDU RAOOF (CLINICIANS)',4),(8,'SURAYYA (MHW)',2),(9,'SOFIYA (MHW)',2),(10,'JAYACHANDRAN (MHW)',2),(11,'SAINUDEEN (MHW)',2),(12,'SAIKRISHNA',4),(13,'DONA',4),(14,'VISMAYA',4),(15,'REMYA REVINDRAN',4);
/*!40000 ALTER TABLE `doctor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipment` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `eno` varchar(45) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `name_lower` varchar(200) DEFAULT NULL,
  `stock` int DEFAULT NULL,
  `damage` int DEFAULT NULL,
  `inuse` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipment`
--

LOCK TABLES `equipment` WRITE;
/*!40000 ALTER TABLE `equipment` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipmentdispose`
--

DROP TABLE IF EXISTS `equipmentdispose`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipmentdispose` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `EquipmentId` int NOT NULL,
  `Eno` varchar(45) DEFAULT NULL,
  `Name` varchar(200) DEFAULT NULL,
  `Desc` varchar(200) DEFAULT NULL,
  `Qty` int DEFAULT NULL,
  `TxnDate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipmentdispose`
--

LOCK TABLES `equipmentdispose` WRITE;
/*!40000 ALTER TABLE `equipmentdispose` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipmentdispose` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipmenttracker`
--

DROP TABLE IF EXISTS `equipmenttracker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipmenttracker` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `EquipmentId` int NOT NULL,
  `patientname` varchar(200) DEFAULT NULL,
  `pno` varchar(45) DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `outdate` datetime DEFAULT NULL,
  `indate` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipmenttracker`
--

LOCK TABLES `equipmenttracker` WRITE;
/*!40000 ALTER TABLE `equipmenttracker` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipmenttracker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expensetype`
--

DROP TABLE IF EXISTS `expensetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expensetype` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `ExpenseType` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expensetype`
--

LOCK TABLES `expensetype` WRITE;
/*!40000 ALTER TABLE `expensetype` DISABLE KEYS */;
INSERT INTO `expensetype` VALUES (1,'FOOD'),(2,'MEDICEN'),(3,'REHABILITATION'),(4,'SALARY'),(5,'SOFTWARE'),(6,'STATIONARY'),(7,'VEHICLE');
/*!40000 ALTER TABLE `expensetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homecareplan`
--

DROP TABLE IF EXISTS `homecareplan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homecareplan` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Pno` varchar(45) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Type` varchar(45) DEFAULT NULL,
  `PatientName` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homecareplan`
--

LOCK TABLES `homecareplan` WRITE;
/*!40000 ALTER TABLE `homecareplan` DISABLE KEYS */;
/*!40000 ALTER TABLE `homecareplan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homevisit`
--

DROP TABLE IF EXISTS `homevisit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homevisit` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `PatientId` int NOT NULL,
  `Date` datetime DEFAULT NULL,
  `Remarks` text,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homevisit`
--

LOCK TABLES `homevisit` WRITE;
/*!40000 ALTER TABLE `homevisit` DISABLE KEYS */;
INSERT INTO `homevisit` VALUES (1,18,'2021-09-03 00:00:00',' BETTER NOW\nPT - INTRACTED WITH US\nSTABLE MOOD'),(2,25,'2021-10-01 00:00:00','TO TEST THE DRUG , MONITOR THE HOUSEHOLD AND SURROUNDINGS AND ASSESS THE SITUATION'),(3,25,'2021-10-01 00:00:00','TO TEST THE DRUG , MONITOR THE HOUSEHOLD AND SURROUNDINGS AND ASSESS THE SITUATION'),(4,76,'2021-10-01 00:00:00','TO TEST THE DRUG , MONITOR THE HOUSEHOLD AND SURROUNDINGS AND ASSESS THE SITUATION'),(5,76,'2021-10-22 00:00:00','MEDICINE NOT TAKING\nPOOR HYGIEN\nDAYIL BATH - GOOD BUT NOT BRUSHING'),(6,35,'2021-10-22 00:00:00','MEDICINE IS REGULAR \nTOOTH PAIN REPORTED \nNO OTHER ISSUES'),(7,35,'2021-10-22 00:00:00','MEDICINE IS CARRECT\nPOOR HYGIEN (POOR ACTIVITIES)\nNO BATHING & NO BRUSHING \nNO CLEANING\nPLAN- BRUSH USE & BRUSHING\n'),(8,24,'2021-10-15 00:00:00','VOLUNTEER HOME VISIT MUST NEED'),(9,151,'2022-11-01 00:00:00','HOME VISIT DONE FOR RAPPORT BUILDING'),(10,137,'2022-10-13 00:00:00','IRREGULAR IN TREATMENT '),(11,29,'2022-12-06 00:00:00','PATIENT IS VIOLENT AND NOT TAKING FOOD. TOOK FFD INJ.'),(12,35,'2022-12-06 00:00:00','VISIT FOR KNOWING CURRENT SITUATION. NOT TAKING OUR MEDICINE DUE TO PHYSICAL CONDITIONS\n'),(13,162,'2022-11-01 00:00:00','FOR OBSERVATION'),(14,23,'2022-11-08 00:00:00','HOME VISIT FOR EDUCATING ABOUT MEDICATION'),(15,137,'2022-11-08 00:00:00','EDUCATING ABOUT NEED OF MEDICATION'),(16,161,'2022-11-23 00:00:00','FOR GIVING MEDICINE'),(17,48,'2022-12-29 00:00:00','NURSING HOME CARE'),(18,37,'2022-12-29 00:00:00','NHC'),(19,146,'2022-12-13 00:00:00','DROP OUT CASE TRYING TO RESTART TREATMENT'),(20,83,'2022-12-29 00:00:00','NHC'),(21,23,'2023-01-11 00:00:00','covert medicine started'),(22,40,'2023-01-11 00:00:00','irregular in medicine');
/*!40000 ALTER TABLE `homevisit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `homevisitvolunteer`
--

DROP TABLE IF EXISTS `homevisitvolunteer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `homevisitvolunteer` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `HomeVisitId` int DEFAULT NULL,
  `VolunteerId` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `homevisitvolunteer`
--

LOCK TABLES `homevisitvolunteer` WRITE;
/*!40000 ALTER TABLE `homevisitvolunteer` DISABLE KEYS */;
INSERT INTO `homevisitvolunteer` VALUES (9,1,7),(10,1,22),(11,2,3),(12,2,23),(13,3,3),(14,3,23),(15,4,3),(16,4,23),(17,5,23),(18,5,27),(19,6,23),(20,6,27),(21,7,23),(22,7,27),(23,8,7),(24,8,24),(25,9,7),(26,9,28),(27,10,28),(28,10,29),(29,11,28),(30,11,30),(31,11,31),(32,12,28),(33,13,7),(34,13,28),(35,13,30),(36,14,19),(37,14,23),(38,14,28),(39,15,19),(40,15,23),(41,15,28),(42,16,28),(43,16,30),(44,17,34),(45,18,32),(46,19,23),(47,19,26),(48,19,28),(49,20,32),(50,21,28),(51,21,30),(52,22,28),(53,22,30);
/*!40000 ALTER TABLE `homevisitvolunteer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incometype`
--

DROP TABLE IF EXISTS `incometype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `incometype` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `IncomeType` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incometype`
--

LOCK TABLES `incometype` WRITE;
/*!40000 ALTER TABLE `incometype` DISABLE KEYS */;
INSERT INTO `incometype` VALUES (1,'SALARY'),(2,'MEDICEN'),(3,'FOOD'),(4,'STATIONARY'),(5,'VEHICLE'),(6,'REHABILITATION'),(7,'SOFTWARE');
/*!40000 ALTER TABLE `incometype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log` (
  `msg` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `UserName` varchar(45) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES (1,'user','f2R1kR9gwx2db4Qt+341020xohKL0D2UBnCotFiCbDHwsFpAYVMt25DIB5XCiFm2uz5Z7kXQ5z928+ze60cqNmFV9qdllyPxdlP7R1Y/485PEnZC+UjJl8q300QTZAKv');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicine`
--

DROP TABLE IF EXISTS `medicine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicine` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Mno` varchar(45) DEFAULT NULL,
  `Name` varchar(200) DEFAULT NULL,
  `NameLower` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicine`
--

LOCK TABLES `medicine` WRITE;
/*!40000 ALTER TABLE `medicine` DISABLE KEYS */;
INSERT INTO `medicine` VALUES (1,'M1','',''),(2,'M2','',''),(3,'M3','CLONAZEPAM TABLETS 0.25 MG','clonazepam tablets 0.25 mg'),(4,'M4','ESCITALOPRAM TABLETS 5MG','escitalopram tablets 5mg'),(5,'M5','ESCITALOPRAM TABLETS 10MG','escitalopram tablets 10mg'),(6,'M6','ESCITALOPRAM TABLETS 20MG','escitalopram tablets 20mg'),(7,'M7','MIRABEGRON EXTENDED FELEASE TABLETS 50MG','mirabegron extended felease tablets 50mg'),(8,'M8','AMISULPRIDE TABLETS 50MG','amisulpride tablets 50mg'),(9,'M9','AMISULPRIDE TABLETS 100MG','amisulpride tablets 100mg'),(10,'M10','AMISULPRIDE TABLETS 200MG','amisulpride tablets 200mg'),(11,'M11','SODIUM VALPROATE ORAL SOLUTION 200ML','sodium valproate oral solution 200ml'),(12,'M12','FLUOXETINE CAPSULES 20MG','fluoxetine capsules 20mg'),(13,'M13','GLYCOPYRROLATE TABLETS 2MG','glycopyrrolate tablets 2mg'),(14,'M14','FLUVOXAMINE TABLETS 100MG','fluvoxamine tablets 100mg'),(15,'M15','AMITRIPTYLINE TABLETS 10MG','amitriptyline tablets 10mg'),(16,'M16','',''),(17,'M17','AMITRIPTYLINE TABLETS 25MG','amitriptyline tablets 25mg'),(18,'M18','BUPROPION HCL EXTENDED RELEASE TABLETS 150MG','bupropion hcl extended release tablets 150mg'),(19,'M19','ARIPIPRAZOLE TABLETS 5MG','aripiprazole tablets 5mg'),(20,'M20','FLUOXETINE HCL CAPSULES 60MG','fluoxetine hcl capsules 60mg'),(21,'M21','FLUOXETINE HCL CAPSULES 40MG','fluoxetine hcl capsules 40mg'),(22,'M22','FLUOXETINE HCL TABLETS 20MG','fluoxetine hcl tablets 20mg'),(23,'M23','FLUOXETINE CAPSULES 10MG','fluoxetine capsules 10mg'),(24,'M24','GABAPENTIN TABLETS 100MG','gabapentin tablets 100mg'),(25,'M25','HALOPERIDOL TABLETS 5MG','haloperidol tablets 5mg'),(26,'M26','HALOPERIDOL TABLETS 10MG','haloperidol tablets 10mg'),(27,'M27','LURASIDONE HCL TABLETS 40MG','lurasidone hcl tablets 40mg'),(28,'M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','lithium carbonate extended release tablets 400mg'),(29,'M29','LITHIUM CARBONATE 300MG','lithium carbonate 300mg'),(30,'M30','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 4MG','risperidone & trihexyphenidyl hcl tablets 4mg'),(31,'M31','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 3MG','risperidone & trihexyphenidyl hcl tablets 3mg'),(32,'M32','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 2MG','risperidone & trihexyphenidyl hcl tablets 2mg'),(33,'M33','RISPERIDONE TABLETS 1MG','risperidone tablets 1mg'),(34,'M34','RISPERIDONE TABLETS 2MG','risperidone tablets 2mg'),(35,'M35','RISPERIDONE TABLETS 3MG','risperidone tablets 3mg'),(36,'M36','RISPERIDONE TABLETS 4MG','risperidone tablets 4mg'),(37,'M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','trifluoperazine hcl & trihexyphenidyl hcl tablets '),(38,'M38','SERTRALINE HCL TABLETS 100MG','sertraline hcl tablets 100mg'),(39,'M39','SERTRALINE HCL TABLETS 50MG','sertraline hcl tablets 50mg'),(40,'M40','SERTRALINE HCL TABLETS 25MG','sertraline hcl tablets 25mg'),(41,'M41','VENLAFAXINE HCL PROLONGED-RELEASE CAPSULES 37.5MG','venlafaxine hcl prolonged-release capsules 37.5mg'),(42,'M42','VENLAFAXINE EXTENDED REIEASE CAPSULES 37.5MG','venlafaxine extended reiease capsules 37.5mg'),(43,'M43','VENLAFAXINE EXTENDED RELEASE CAPSULES 75MG','venlafaxine extended release capsules 75mg'),(44,'M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','venlafaxine prolonged release tablets 150mg'),(45,'M45','TOPIRAMATE TABLETS 25MG','topiramate tablets 25mg'),(46,'M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','trihexyphenidyl hcl tablets 2mg'),(47,'M47','CLOZAPINE TABLETS 25MG','clozapine tablets 25mg'),(48,'M48','CLOZAPINE TABLETS 50MG','clozapine tablets 50mg'),(49,'M49','CLOZAPINE TABLETS 100MG','clozapine tablets 100mg'),(50,'M50','CLOZAPINE TABLETS 200MG','clozapine tablets 200mg'),(51,'M51','DONEPEZIL HCL TABLETS 5MG','donepezil hcl tablets 5mg'),(52,'M52','DONEPEZIL HCL TABLETS 10MG','donepezil hcl tablets 10mg'),(53,'M53','DOSULEPIN TABLETS 25MG','dosulepin tablets 25mg'),(54,'M54','DOSULEPIN TABLETS BP 75MG','dosulepin tablets bp 75mg'),(55,'M55','DOSULEPIN TABLETS BP 50MG','dosulepin tablets bp 50mg'),(56,'M56','CLOMIPRAMINE TABLETS 25MG','clomipramine tablets 25mg'),(57,'M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','carbamazepine extended-release tablets 400mg'),(58,'M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','carbamazepine extended-release tablets 300mg'),(59,'M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','carbamazepine extended-release tablets 200mg'),(60,'M60','LAMOTRIGINE DISPERSIBLE TABLETS 100MG','lamotrigine dispersible tablets 100mg'),(61,'M61','LAMOTRIGINE DISPERSIBLE TABLETS 50MG','lamotrigine dispersible tablets 50mg'),(62,'M62','LAMOTRIGINE TABLETS 25MG','lamotrigine tablets 25mg'),(63,'M63','LACOSAMIDE TABLETS 100MG','lacosamide tablets 100mg'),(64,'M64','MIRTAZAPINE TABLETS 7.5MG','mirtazapine tablets 7.5mg'),(65,'M65','MIRTAZAPINE TABLETS 15MG','mirtazapine tablets 15mg'),(66,'M66','NITRAZEPAM TABLETS 10MG','nitrazepam tablets 10mg'),(67,'M67','OLANZAPINE TABLETS 2.5MG','olanzapine tablets 2.5mg'),(68,'M68','OLANZAPINE TABLETS 10MG','olanzapine tablets 10mg'),(69,'M69','OLANZAPINE TABLETS 5MG','olanzapine tablets 5mg'),(70,'M70','QUETIAPINE TABLETS 25MG','quetiapine tablets 25mg'),(71,'M71','QUETIAPINE TABLETS 50MG','quetiapine tablets 50mg'),(72,'M72','QUETIAPINE TABLETS 100MG','quetiapine tablets 100mg'),(73,'M73','QUETIAPINE TABLETS 200MG','quetiapine tablets 200mg'),(74,'M74','MEMANTINE HCL & DONEPEZIL HCL TABLETS ','memantine hcl & donepezil hcl tablets '),(75,'M75','PROPRANOLOL SUSTAINED RELEASE TABLETS 40MG','propranolol sustained release tablets 40mg'),(76,'M76','PROPRANOLOL TABLETS 20MG','propranolol tablets 20mg'),(77,'M77','PHENOBARBITONE TABLETS 30MG','phenobarbitone tablets 30mg'),(78,'M78','PHENYTOIN SODIUM TABLETS 100MG','phenytoin sodium tablets 100mg'),(79,'M79','PHENOBARBITONE TABLETS 60MG','phenobarbitone tablets 60mg'),(80,'M80','PIMOZIDE TABLETS 2MG','pimozide tablets 2mg'),(81,'M81','SV 300MG','sv 300mg'),(82,'M82','SV 200MG','sv 200mg'),(83,'M83','SV 500MG','sv 500mg'),(84,'M84','LEVETIRACETAM TABLETS 500 MG','levetiracetam tablets 500 mg'),(85,'M85','LEVETIRACETAM TABLETS 250 MG','levetiracetam tablets 250 mg'),(86,'M86','CLOBAZAM TABLETS 10 MG','clobazam tablets 10 mg'),(87,'M87','CLOBAZAM TABLETS 5 MG','clobazam tablets 5 mg'),(88,'M88','CLONAZEPAM & ESCITALOPRAM OXALATE TABLETS 5 MG','clonazepam & escitalopram oxalate tablets 5 mg'),(89,'M89','CLONAZEPAM TABLETS 0.5 MG','clonazepam tablets 0.5 mg'),(90,'M90','LORAZEPAM TABLETS 1 MG','lorazepam tablets 1 mg'),(91,'M91','LORAZEPAM TABLETS 2MG ','lorazepam tablets 2mg '),(92,'M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','risperidone oral solution bp 1mg/ml'),(93,'M93','FLUPHENAZINE DECANOATE INJECTION IP 1ML','fluphenazine decanoate injection ip 1ml'),(94,'M94','DIVALPROEX SUSTAINED RELEASE TABLETS IP 250','divalproex sustained release tablets ip 250'),(95,'M95','TRIFLUOPERAZINE TABLETS IP 5MG','trifluoperazine tablets ip 5mg'),(96,'M96','OLANZAPINE 7.5','olanzapine 7.5');
/*!40000 ALTER TABLE `medicine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicinehistory`
--

DROP TABLE IF EXISTS `medicinehistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicinehistory` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `MedicineId` int DEFAULT NULL,
  `txnDate` datetime DEFAULT NULL,
  `mno` varchar(45) DEFAULT NULL,
  `medName` varchar(200) DEFAULT NULL,
  `txnType` varchar(45) DEFAULT NULL,
  `desc` varchar(45) DEFAULT NULL,
  `openingMain` int DEFAULT NULL,
  `openingSub` int DEFAULT NULL,
  `openingAKit` int DEFAULT NULL,
  `openingBKit` int DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `closingMain` int DEFAULT NULL,
  `closingSub` int DEFAULT NULL,
  `closingAKit` int DEFAULT NULL,
  `closingBKit` int DEFAULT NULL,
  `pno` varchar(45) DEFAULT NULL,
  `patientName` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3474 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicinehistory`
--

LOCK TABLES `medicinehistory` WRITE;
/*!40000 ALTER TABLE `medicinehistory` DISABLE KEYS */;
INSERT INTO `medicinehistory` VALUES (1,1,'2021-08-11 00:00:00','M1','CLOZAPINE 200MG','Add','To main stock',0,0,0,0,400,400,0,0,0,'',''),(2,1,'2021-08-11 00:00:00','M1','CLOZAPINE 200MG','Edit','Edit stock',400,0,0,0,0,400,0,0,0,'',''),(3,2,'2021-08-11 00:00:00','M2','AMISULPRIDE 50MG','Add','To main stock',0,0,0,0,324,324,0,0,0,'',''),(4,3,'2021-08-11 00:00:00','M3',' AMISULPRIDE 100MG','Add','To main stock',0,0,0,0,244,244,0,0,0,'',''),(5,2,'2021-08-11 00:00:00','M2','T. AMISULPRIDE 50MG','Edit','Edit stock',324,0,0,0,0,324,0,0,0,'',''),(6,4,'2021-08-12 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Add','To main stock',0,0,0,0,479,479,0,0,0,'',''),(7,5,'2021-08-12 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Add','To main stock',0,0,0,0,349,349,0,0,0,'',''),(8,6,'2021-08-12 00:00:00','M6','ESCITALOPRAM TABLETS 20MG','Add','To main stock',0,0,0,0,277,277,0,0,0,'',''),(9,7,'2021-08-12 00:00:00','M7','MIRABEGRON EXTENDED FELEASE TABLETS 50MG','Add','To main stock',0,0,0,0,30,30,0,0,0,'',''),(10,8,'2021-08-12 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Add','To main stock',0,0,0,0,324,324,0,0,0,'',''),(11,9,'2021-08-12 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Add','To main stock',0,0,0,0,244,244,0,0,0,'',''),(12,10,'2021-08-12 00:00:00','M10','AMISULPRIDE TABLETS 200MG','Add','To main stock',0,0,0,0,150,150,0,0,0,'',''),(13,11,'2021-08-12 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Add','To main stock',0,0,0,0,1,1,0,0,0,'',''),(14,12,'2021-08-12 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Add','To main stock',0,0,0,0,400,400,0,0,0,'',''),(15,13,'2021-08-12 00:00:00','M13','GLYCOPYRROLATE TABLETS 2MG','Add','To main stock',0,0,0,0,85,85,0,0,0,'',''),(16,14,'2021-08-12 00:00:00','M14','FLUVOXAMINE TABLETS 100MG','Add','To main stock',0,0,0,0,161,161,0,0,0,'',''),(17,15,'2021-08-12 00:00:00','M15','AMITRIPTYLINE TABLETS 10MG','Add','To main stock',0,0,0,0,82,82,0,0,0,'',''),(18,16,'2021-08-12 00:00:00','M16','AMITRIPTYLINE HCL TABLETS 10MG','Add','To main stock',0,0,0,0,5,5,0,0,0,'',''),(19,17,'2021-08-12 00:00:00','M17','AMITRIPTYLINE TABLETS 25MG','Add','To main stock',0,0,0,0,114,114,0,0,0,'',''),(20,18,'2021-08-12 00:00:00','M18','BUPROPION HCL EXTENDED RELEASE TABLETS 150MG','Add','To main stock',0,0,0,0,30,30,0,0,0,'',''),(21,19,'2021-08-12 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Add','To main stock',0,0,0,0,142,142,0,0,0,'',''),(22,20,'2021-08-12 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Add','To main stock',0,0,0,0,613,613,0,0,0,'',''),(23,21,'2021-08-12 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Add','To main stock',0,0,0,0,303,303,0,0,0,'',''),(24,22,'2021-08-12 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Add','To main stock',0,0,0,0,152,152,0,0,0,'',''),(25,23,'2021-08-12 00:00:00','M23','FLUOXETINE CAPSULES 10MG','Add','To main stock',0,0,0,0,151,151,0,0,0,'',''),(26,24,'2021-08-12 00:00:00','M24','GABAPENTIN TABLETS 100MG','Add','To main stock',0,0,0,0,319,319,0,0,0,'',''),(27,25,'2021-08-12 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Add','To main stock',0,0,0,0,60,60,0,0,0,'',''),(28,26,'2021-08-12 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Add','To main stock',0,0,0,0,170,170,0,0,0,'',''),(29,27,'2021-08-12 00:00:00','M27','LURASIDONE HCL TABLETS 40MG','Add','To main stock',0,0,0,0,155,155,0,0,0,'',''),(30,28,'2021-08-12 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Add','To main stock',0,0,0,0,803,803,0,0,0,'',''),(31,29,'2021-08-12 00:00:00','M29','LITHIUM CARBONATE 300MG','Add','To main stock',0,0,0,0,585,585,0,0,0,'',''),(32,30,'2021-08-12 00:00:00','M30','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 4MG','Add','To main stock',0,0,0,0,86,86,0,0,0,'',''),(33,31,'2021-08-12 00:00:00','M31','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 3MG','Add','To main stock',0,0,0,0,393,393,0,0,0,'',''),(34,32,'2021-08-12 00:00:00','M32','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 2MG','Add','To main stock',0,0,0,0,511,511,0,0,0,'',''),(35,33,'2021-08-12 00:00:00','M33','RISPERIDONE TABLETS 1MG','Add','To main stock',0,0,0,0,434,434,0,0,0,'',''),(36,34,'2021-08-12 00:00:00','M34','RISPERIDONE TABLETS 2MG','Add','To main stock',0,0,0,0,217,217,0,0,0,'',''),(37,35,'2021-08-12 00:00:00','M35','RISPERIDONE TABLETS 3MG','Add','To main stock',0,0,0,0,227,227,0,0,0,'',''),(38,36,'2021-08-12 00:00:00','M36','RISPERIDONE TABLETS 4MG','Add','To main stock',0,0,0,0,687,687,0,0,0,'',''),(39,37,'2021-08-12 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Add','To main stock',0,0,0,0,1662,1662,0,0,0,'',''),(40,38,'2021-08-12 00:00:00','M38','SERTRALINE HCL TABLETS 100MG','Add','To main stock',0,0,0,0,219,219,0,0,0,'',''),(41,39,'2021-08-12 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Add','To main stock',0,0,0,0,265,265,0,0,0,'',''),(42,40,'2021-08-12 00:00:00','M40','SERTRALINE HCL TABLETS 25MG','Add','To main stock',0,0,0,0,378,378,0,0,0,'',''),(43,41,'2021-08-12 00:00:00','M41','VENLAFAXINE HCL PROLONGED-RELEASE CAPSULES 37.5MG','Add','To main stock',0,0,0,0,60,60,0,0,0,'',''),(44,42,'2021-08-12 00:00:00','M42','VENLAFAXINE EXTENDED REIEASE CAPSULES 37.5MG','Add','To main stock',0,0,0,0,116,116,0,0,0,'',''),(45,43,'2021-08-12 00:00:00','M43','VENLAFAXINE EXTENDED RELEASE CAPSULES 75MG','Add','To main stock',0,0,0,0,163,163,0,0,0,'',''),(46,44,'2021-08-12 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Add','To main stock',0,0,0,0,32,32,0,0,0,'',''),(47,45,'2021-08-12 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Add','To main stock',0,0,0,0,639,639,0,0,0,'',''),(48,46,'2021-08-12 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Add','To main stock',0,0,0,0,752,752,0,0,0,'',''),(49,47,'2021-08-12 00:00:00','M47','CLOZAPINE TABLETS 25MG','Add','To main stock',0,0,0,0,456,456,0,0,0,'',''),(50,48,'2021-08-12 00:00:00','M48','CLOZAPINE TABLETS 50MG','Add','To main stock',0,0,0,0,531,531,0,0,0,'',''),(51,49,'2021-08-12 00:00:00','M49','CLOZAPINE TABLETS 100MG','Add','To main stock',0,0,0,0,453,453,0,0,0,'',''),(52,50,'2021-08-12 00:00:00','M50','CLOZAPINE TABLETS 200MG','Add','To main stock',0,0,0,0,559,559,0,0,0,'',''),(53,51,'2021-08-12 00:00:00','M51','DONEPEZIL HCL TABLETS 5MG','Add','To main stock',0,0,0,0,16,16,0,0,0,'',''),(54,52,'2021-08-12 00:00:00','M52','DONEPEZIL HCL TABLETS 10MG','Add','To main stock',0,0,0,0,30,30,0,0,0,'',''),(55,53,'2021-08-12 00:00:00','M53','DOSULEPIN TABLETS 25MG','Add','To main stock',0,0,0,0,45,45,0,0,0,'',''),(56,54,'2021-08-12 00:00:00','M54','DOSULEPIN TABLETS BP 75MG','Add','To main stock',0,0,0,0,90,90,0,0,0,'',''),(57,55,'2021-08-12 00:00:00','M55','DOSULEPIN TABLETS BP 50MG','Add','To main stock',0,0,0,0,100,100,0,0,0,'',''),(58,56,'2021-08-12 00:00:00','M56','CLOMIPRAMINE TABLETS 25MG','Add','To main stock',0,0,0,0,65,65,0,0,0,'',''),(59,57,'2021-08-12 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Add','To main stock',0,0,0,0,311,311,0,0,0,'',''),(60,58,'2021-08-12 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Add','To main stock',0,0,0,0,203,203,0,0,0,'',''),(61,59,'2021-08-12 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Add','To main stock',0,0,0,0,988,988,0,0,0,'',''),(62,60,'2021-08-12 00:00:00','M60','LAMOTRIGINE DISPERSIBLE TABLETS 100MG','Add','To main stock',0,0,0,0,100,100,0,0,0,'',''),(63,61,'2021-08-12 00:00:00','M61','LAMOTRIGINE DISPERSIBLE TABLETS 50MG','Add','To main stock',0,0,0,0,181,181,0,0,0,'',''),(64,62,'2021-08-12 00:00:00','M62','LAMOTRIGINE TABLETS 25MG','Add','To main stock',0,0,0,0,108,108,0,0,0,'',''),(65,63,'2021-08-12 00:00:00','M63','LACOSAMIDE TABLETS 100MG','Add','To main stock',0,0,0,0,173,173,0,0,0,'',''),(66,64,'2021-08-12 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Add','To main stock',0,0,0,0,152,152,0,0,0,'',''),(67,65,'2021-08-12 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Add','To main stock',0,0,0,0,81,81,0,0,0,'',''),(68,66,'2021-08-12 00:00:00','M66','NITRAZEPAM TABLETS 10MG','Add','To main stock',0,0,0,0,60,60,0,0,0,'',''),(69,67,'2021-08-12 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Add','To main stock',0,0,0,0,50,50,0,0,0,'',''),(70,68,'2021-08-12 00:00:00','M68','OLANZAPINE TABLETS 10MG','Add','To main stock',0,0,0,0,281,281,0,0,0,'',''),(71,69,'2021-08-12 00:00:00','M69','OLANZAPINE TABLETS 5MG','Add','To main stock',0,0,0,0,340,340,0,0,0,'',''),(72,70,'2021-08-12 00:00:00','M70','QUETIAPINE TABLETS 25MG','Add','To main stock',0,0,0,0,578,578,0,0,0,'',''),(73,71,'2021-08-12 00:00:00','M71','QUETIAPINE TABLETS 50MG','Add','To main stock',0,0,0,0,225,225,0,0,0,'',''),(74,72,'2021-08-12 00:00:00','M72','QUETIAPINE TABLETS 100MG','Add','To main stock',0,0,0,0,270,270,0,0,0,'',''),(75,73,'2021-08-12 00:00:00','M73','QUETIAPINE TABLETS 200MG','Add','To main stock',0,0,0,0,94,94,0,0,0,'',''),(76,74,'2021-08-12 00:00:00','M74','MEMANTINE HCL & DONEPEZIL HCL TABLETS ','Add','To main stock',0,0,0,0,70,70,0,0,0,'',''),(77,75,'2021-08-12 00:00:00','M75','PROPRANOLOL SUSTAINED RELEASE TABLETS 40MG','Add','To main stock',0,0,0,0,97,97,0,0,0,'',''),(78,76,'2021-08-12 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Add','To main stock',0,0,0,0,234,234,0,0,0,'',''),(79,77,'2021-08-12 00:00:00','M77','PHENOBARBITONE TABLETS 30MG','Add','To main stock',0,0,0,0,90,90,0,0,0,'',''),(80,78,'2021-08-12 00:00:00','M78','PHENYTOIN SODIUM TABLETS 100MG','Add','To main stock',0,0,0,0,340,340,0,0,0,'',''),(81,79,'2021-08-12 00:00:00','M79','PHENOBARBITONE TABLETS 60MG','Add','To main stock',0,0,0,0,60,60,0,0,0,'',''),(82,80,'2021-08-12 00:00:00','M80','PIMOZIDE TABLETS 2MG','Add','To main stock',0,0,0,0,60,60,0,0,0,'',''),(83,81,'2021-08-12 00:00:00','M81','SV 300','Add','To main stock',0,0,0,0,423,423,0,0,0,'',''),(84,82,'2021-08-12 00:00:00','M82','SV 200MG','Add','To main stock',0,0,0,0,423,423,0,0,0,'',''),(85,83,'2021-08-12 00:00:00','M83','SV 500MG','Add','To main stock',0,0,0,0,2016,2016,0,0,0,'',''),(86,82,'2021-08-12 00:00:00','M82','SV 200MG','Edit','Edit stock',423,0,0,0,0,1345,0,0,0,'',''),(87,84,'2021-08-13 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Add','To main stock',0,0,0,0,380,380,0,0,0,'',''),(88,85,'2021-08-13 00:00:00','M85','LEVETIRACETAM TABLETS 250 MG','Add','To main stock',0,0,0,0,618,618,0,0,0,'',''),(89,86,'2021-08-13 00:00:00','M86','CLOBAZAM TABLETS 10 MG','Add','To main stock',0,0,0,0,250,250,0,0,0,'',''),(90,87,'2021-08-13 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Add','To main stock',0,0,0,0,625,625,0,0,0,'',''),(91,88,'2021-08-13 00:00:00','M88','CLONAZEPAM & ESCITALOPRAM OXALATE TABLETS 5 MG','Add','To main stock',0,0,0,0,70,70,0,0,0,'',''),(92,89,'2021-08-13 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Add','To main stock',0,0,0,0,130,130,0,0,0,'',''),(93,90,'2021-08-13 00:00:00','M90','LORAZEPAM TABLETS 1 MG','Add','To main stock',0,0,0,0,214,214,0,0,0,'',''),(94,91,'2021-08-13 00:00:00','M91','LORAZEPAM TABLETS 2MG ','Add','To main stock',0,0,0,0,85,85,0,0,0,'',''),(95,9,'2021-08-13 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Edit','Edit stock',244,0,0,0,0,244,0,0,0,'',''),(96,1,'2021-08-13 00:00:00','M1','','Edit','Edit stock',400,0,0,0,0,0,0,0,0,'',''),(97,2,'2021-08-13 00:00:00','M2','','Edit','Edit stock',324,0,0,0,0,0,0,0,0,'',''),(98,3,'2021-08-13 00:00:00','M3','','Edit','Edit stock',244,0,0,0,0,0,0,0,0,'',''),(99,92,'2021-08-13 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Add','To main stock',0,0,0,0,2,2,0,0,0,'',''),(100,46,'2021-08-13 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Main to Sub',752,0,0,0,84,668,84,0,0,'',''),(101,46,'2021-08-13 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',668,84,0,0,0,668,0,0,0,'',''),(102,46,'2021-08-13 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',668,0,0,0,0,584,0,0,0,'',''),(103,83,'2021-08-13 00:00:00','M83','SV 500MG','Edit','Edit stock',2016,0,0,0,0,1960,0,0,0,'',''),(104,35,'2021-08-13 00:00:00','M35','RISPERIDONE TABLETS 3MG','Edit','Edit stock',227,0,0,0,0,199,0,0,0,'',''),(105,50,'2021-08-13 00:00:00','M50','CLOZAPINE TABLETS 200MG','Edit','Edit stock',559,0,0,0,0,531,0,0,0,'',''),(106,68,'2021-08-13 00:00:00','M68','OLANZAPINE TABLETS 10MG','Edit','Edit stock',281,0,0,0,0,253,0,0,0,'',''),(107,83,'2021-08-13 00:00:00','M83','SV 500MG','Edit','Edit stock',1960,0,0,0,0,1932,0,0,0,'',''),(108,82,'2021-08-13 00:00:00','M82','SV 200MG','Edit','Edit stock',1345,0,0,0,0,1317,0,0,0,'',''),(109,46,'2021-08-13 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',584,0,0,0,0,556,0,0,0,'',''),(110,81,'2021-08-13 00:00:00','M81','SV 300MG','Edit','Edit stock',423,0,0,0,0,381,0,0,0,'',''),(111,37,'2021-08-13 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Edit','Edit stock',1662,0,0,0,0,1620,0,0,0,'',''),(112,82,'2021-08-13 00:00:00','M82','SV 200MG','Edit','Edit stock',1317,0,0,0,0,1261,0,0,0,'',''),(113,36,'2021-08-13 00:00:00','M36','RISPERIDONE TABLETS 4MG','Edit','Edit stock',687,0,0,0,0,659,0,0,0,'',''),(114,5,'2021-08-13 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Edit','Edit stock',349,0,0,0,0,321,0,0,0,'',''),(115,46,'2021-08-13 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',556,0,0,0,0,528,0,0,0,'',''),(116,83,'2021-08-13 00:00:00','M83','SV 500MG','Edit','Edit stock',1932,0,0,0,0,1930,0,0,0,'',''),(117,68,'2021-08-13 00:00:00','M68','OLANZAPINE TABLETS 10MG','Edit','Edit stock',253,0,0,0,0,251,0,0,0,'',''),(118,46,'2021-08-13 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',528,0,0,0,0,524,0,0,0,'',''),(119,83,'2021-08-13 00:00:00','M83','SV 500MG','Edit','Edit stock',1930,0,0,0,0,1923,0,0,0,'',''),(120,28,'2021-08-13 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Edit','Edit stock',803,0,0,0,0,761,0,0,0,'',''),(121,5,'2021-08-13 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Edit','Edit stock',321,0,0,0,0,300,0,0,0,'',''),(122,48,'2021-08-13 00:00:00','M48','CLOZAPINE TABLETS 50MG','Edit','Edit stock',531,0,0,0,0,475,0,0,0,'',''),(123,47,'2021-08-13 00:00:00','M47','CLOZAPINE TABLETS 25MG','Edit','Edit stock',456,0,0,0,0,400,0,0,0,'',''),(124,20,'2021-08-13 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Edit','Edit stock',613,0,0,0,0,557,0,0,0,'',''),(125,83,'2021-08-13 00:00:00','M83','SV 500MG','Edit','Edit stock',1923,0,0,0,0,1895,0,0,0,'',''),(126,82,'2021-08-13 00:00:00','M82','SV 200MG','Edit','Edit stock',1261,0,0,0,0,1247,0,0,0,'',''),(127,26,'2021-08-13 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Edit','Edit stock',170,0,0,0,0,142,0,0,0,'',''),(128,48,'2021-08-13 00:00:00','M48','CLOZAPINE TABLETS 50MG','Edit','Edit stock',475,0,0,0,0,461,0,0,0,'',''),(129,47,'2021-08-13 00:00:00','M47','CLOZAPINE TABLETS 25MG','Edit','Edit stock',400,0,0,0,0,286,0,0,0,'',''),(130,46,'2021-08-13 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',524,0,0,0,0,482,0,0,0,'',''),(131,49,'2021-08-13 00:00:00','M49','CLOZAPINE TABLETS 100MG','Edit','Edit stock',453,0,0,0,0,439,0,0,0,'',''),(132,90,'2021-08-13 00:00:00','M90','LORAZEPAM TABLETS 1 MG','Edit','Edit stock',214,0,0,0,0,212,0,0,0,'',''),(133,4,'2021-08-13 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Edit','Edit stock',479,0,0,0,0,458,0,0,0,'',''),(134,81,'2021-08-13 00:00:00','M81','SV 300MG','Edit','Edit stock',381,0,0,0,0,353,0,0,0,'',''),(135,83,'2021-08-13 00:00:00','M83','SV 500MG','Edit','Edit stock',1895,0,0,0,0,1881,0,0,0,'',''),(136,68,'2021-08-13 00:00:00','M68','OLANZAPINE TABLETS 10MG','Edit','Edit stock',251,0,0,0,0,237,0,0,0,'',''),(137,89,'2021-08-13 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Edit','Edit stock',130,0,0,0,0,123,0,0,0,'',''),(138,70,'2021-08-13 00:00:00','M70','QUETIAPINE TABLETS 25MG','Edit','Edit stock',578,0,0,0,0,571,0,0,0,'',''),(139,83,'2021-08-13 00:00:00','M83','SV 500MG','Edit','Edit stock',1881,0,0,0,0,1825,0,0,0,'',''),(140,70,'2021-08-13 00:00:00','M70','QUETIAPINE TABLETS 25MG','Edit','Edit stock',571,0,0,0,0,543,0,0,0,'',''),(141,83,'2021-08-13 00:00:00','M83','SV 500MG','Edit','Edit stock',1825,0,0,0,0,1796,0,0,0,'',''),(142,36,'2021-08-13 00:00:00','M36','RISPERIDONE TABLETS 4MG','Edit','Edit stock',659,0,0,0,0,631,0,0,0,'',''),(143,33,'2021-08-13 00:00:00','M33','RISPERIDONE TABLETS 1MG','Edit','Edit stock',434,0,0,0,0,406,0,0,0,'',''),(144,83,'2021-08-13 00:00:00','M83','SV 500MG','Edit','Edit stock',1796,0,0,0,0,1797,0,0,0,'',''),(145,47,'2021-08-13 00:00:00','M47','CLOZAPINE TABLETS 25MG','Edit','Edit stock',286,0,0,0,0,258,0,0,0,'',''),(146,46,'2021-08-13 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',482,0,0,0,0,370,0,0,0,'',''),(147,73,'2021-08-13 00:00:00','M73','QUETIAPINE TABLETS 200MG','Edit','Edit stock',94,0,0,0,0,80,0,0,0,'',''),(148,46,'2021-08-13 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',370,0,0,0,0,349,0,0,0,'',''),(149,83,'2021-08-13 00:00:00','M83','SV 500MG','Edit','Edit stock',1797,0,0,0,0,1783,0,0,0,'',''),(150,26,'2021-08-13 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Edit','Edit stock',142,0,0,0,0,135,0,0,0,'',''),(151,25,'2021-08-13 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Edit','Edit stock',60,0,0,0,0,53,0,0,0,'',''),(152,47,'2021-08-13 00:00:00','M47','CLOZAPINE TABLETS 25MG','Edit','Edit stock',258,0,0,0,0,251,0,0,0,'',''),(153,92,'2021-08-13 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Edit','Edit stock',2,0,0,0,0,1,0,0,0,'',''),(154,73,'2021-09-01 00:00:00','M73','QUETIAPINE TABLETS 200MG','Edit','Edit stock',80,0,0,0,0,52,0,0,0,'',''),(155,46,'2021-09-01 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',349,0,0,0,0,307,0,0,0,'',''),(156,16,'2021-09-03 00:00:00','M16','AMITRIPTYLINE HCL TABLETS 10MG','Edit','Edit stock',5,0,0,0,0,0,0,0,0,'',''),(157,16,'2021-09-03 00:00:00','M16','PHENYTOIN TABLETS 100MG','Edit','Edit stock',0,0,0,0,0,122,0,0,0,'',''),(158,3,'2021-09-03 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Edit','Edit stock',0,0,0,0,0,200,0,0,0,'',''),(159,9,'2021-09-12 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Edit','Edit stock',244,0,0,0,0,374,0,0,0,'',''),(160,10,'2021-09-12 00:00:00','M10','AMISULPRIDE TABLETS 200MG','Edit','Edit stock',150,0,0,0,0,150,0,0,0,'',''),(161,8,'2021-09-12 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Edit','Edit stock',324,0,0,0,0,124,0,0,0,'',''),(162,15,'2021-09-12 00:00:00','M15','AMITRIPTYLINE TABLETS 10MG','Edit','Edit stock',82,0,0,0,0,155,0,0,0,'',''),(163,17,'2021-09-12 00:00:00','M17','AMITRIPTYLINE TABLETS 25MG','Edit','Edit stock',114,0,0,0,0,135,0,0,0,'',''),(164,19,'2021-09-12 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Edit','Edit stock',142,0,0,0,0,100,0,0,0,'',''),(165,59,'2021-09-12 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Edit','Edit stock',988,0,0,0,0,265,0,0,0,'',''),(166,58,'2021-09-12 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Edit','Edit stock',203,0,0,0,0,150,0,0,0,'',''),(167,57,'2021-09-12 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Edit','Edit stock',311,0,0,0,0,850,0,0,0,'',''),(168,86,'2021-09-12 00:00:00','M86','CLOBAZAM TABLETS 10 MG','Edit','Edit stock',250,0,0,0,0,252,0,0,0,'',''),(169,87,'2021-09-12 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Edit','Edit stock',625,0,0,0,0,578,0,0,0,'',''),(170,56,'2021-09-12 00:00:00','M56','CLOMIPRAMINE TABLETS 25MG','Edit','Edit stock',65,0,0,0,0,2,0,0,0,'',''),(171,3,'2021-09-12 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Edit','Edit stock',200,0,0,0,0,157,0,0,0,'',''),(172,89,'2021-09-12 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Edit','Edit stock',123,0,0,0,0,156,0,0,0,'',''),(173,49,'2021-09-12 00:00:00','M49','CLOZAPINE TABLETS 100MG','Edit','Edit stock',439,0,0,0,0,507,0,0,0,'',''),(174,50,'2021-09-12 00:00:00','M50','CLOZAPINE TABLETS 200MG','Edit','Edit stock',531,0,0,0,0,473,0,0,0,'',''),(175,47,'2021-09-12 00:00:00','M47','CLOZAPINE TABLETS 25MG','Edit','Edit stock',251,0,0,0,0,331,0,0,0,'',''),(176,48,'2021-09-12 00:00:00','M48','CLOZAPINE TABLETS 50MG','Edit','Edit stock',461,0,0,0,0,309,0,0,0,'',''),(177,51,'2021-09-12 00:00:00','M51','DONEPEZIL HCL TABLETS 5MG','Edit','Edit stock',16,0,0,0,0,50,0,0,0,'',''),(178,53,'2021-09-12 00:00:00','M53','DOSULEPIN TABLETS 25MG','Edit','Edit stock',45,0,0,0,0,16,0,0,0,'',''),(179,5,'2021-09-12 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Edit','Edit stock',300,0,0,0,0,49,0,0,0,'',''),(180,6,'2021-09-12 00:00:00','M6','ESCITALOPRAM TABLETS 20MG','Edit','Edit stock',277,0,0,0,0,114,0,0,0,'',''),(181,4,'2021-09-12 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Edit','Edit stock',458,0,0,0,0,236,0,0,0,'',''),(182,12,'2021-09-12 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Edit','Edit stock',400,0,0,0,0,232,0,0,0,'',''),(183,21,'2021-09-12 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Edit','Edit stock',303,0,0,0,0,535,0,0,0,'',''),(184,20,'2021-09-12 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Edit','Edit stock',557,0,0,0,0,646,0,0,0,'',''),(185,22,'2021-09-12 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Edit','Edit stock',152,0,0,0,0,0,0,0,0,'',''),(186,14,'2021-09-12 00:00:00','M14','FLUVOXAMINE TABLETS 100MG','Edit','Edit stock',161,0,0,0,0,179,0,0,0,'',''),(187,24,'2021-09-12 00:00:00','M24','GABAPENTIN TABLETS 100MG','Edit','Edit stock',319,0,0,0,0,236,0,0,0,'',''),(188,13,'2021-09-12 00:00:00','M13','GLYCOPYRROLATE TABLETS 2MG','Edit','Edit stock',85,0,0,0,0,128,0,0,0,'',''),(189,26,'2021-09-12 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Edit','Edit stock',135,0,0,0,0,74,0,0,0,'',''),(190,25,'2021-09-12 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Edit','Edit stock',53,0,0,0,0,119,0,0,0,'',''),(191,63,'2021-09-12 00:00:00','M63','LACOSAMIDE TABLETS 100MG','Edit','Edit stock',173,0,0,0,0,113,0,0,0,'',''),(192,60,'2021-09-12 00:00:00','M60','LAMOTRIGINE DISPERSIBLE TABLETS 100MG','Edit','Edit stock',100,0,0,0,0,105,0,0,0,'',''),(193,61,'2021-09-12 00:00:00','M61','LAMOTRIGINE DISPERSIBLE TABLETS 50MG','Edit','Edit stock',181,0,0,0,0,189,0,0,0,'',''),(194,62,'2021-09-12 00:00:00','M62','LAMOTRIGINE TABLETS 25MG','Edit','Edit stock',108,0,0,0,0,66,0,0,0,'',''),(195,85,'2021-09-12 00:00:00','M85','LEVETIRACETAM TABLETS 250 MG','Edit','Edit stock',618,0,0,0,0,260,0,0,0,'',''),(196,84,'2021-09-12 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Edit','Edit stock',380,0,0,0,0,347,0,0,0,'',''),(197,29,'2021-09-12 00:00:00','M29','LITHIUM CARBONATE 300MG','Edit','Edit stock',585,0,0,0,0,596,0,0,0,'',''),(198,28,'2021-09-12 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Edit','Edit stock',761,0,0,0,0,536,0,0,0,'',''),(199,90,'2021-09-12 00:00:00','M90','LORAZEPAM TABLETS 1 MG','Edit','Edit stock',212,0,0,0,0,151,0,0,0,'',''),(200,91,'2021-09-12 00:00:00','M91','LORAZEPAM TABLETS 2MG ','Edit','Edit stock',85,0,0,0,0,251,0,0,0,'',''),(201,27,'2021-09-12 00:00:00','M27','LURASIDONE HCL TABLETS 40MG','Edit','Edit stock',155,0,0,0,0,141,0,0,0,'',''),(202,74,'2021-09-12 00:00:00','M74','MEMANTINE HCL & DONEPEZIL HCL TABLETS ','Edit','Edit stock',70,0,0,0,0,170,0,0,0,'',''),(203,7,'2021-09-12 00:00:00','M7','MIRABEGRON EXTENDED FELEASE TABLETS 50MG','Edit','Edit stock',30,0,0,0,0,0,0,0,0,'',''),(204,65,'2021-09-12 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Edit','Edit stock',81,0,0,0,0,218,0,0,0,'',''),(205,64,'2021-09-12 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Edit','Edit stock',152,0,0,0,0,110,0,0,0,'',''),(206,66,'2021-09-12 00:00:00','M66','NITRAZEPAM TABLETS 10MG','Edit','Edit stock',60,0,0,0,0,58,0,0,0,'',''),(207,68,'2021-09-12 00:00:00','M68','OLANZAPINE TABLETS 10MG','Edit','Edit stock',237,0,0,0,0,93,0,0,0,'',''),(208,67,'2021-09-12 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Edit','Edit stock',50,0,0,0,0,60,0,0,0,'',''),(209,69,'2021-09-12 00:00:00','M69','OLANZAPINE TABLETS 5MG','Edit','Edit stock',340,0,0,0,0,213,0,0,0,'',''),(210,77,'2021-09-12 00:00:00','M77','PHENOBARBITONE TABLETS 30MG','Edit','Edit stock',90,0,0,0,0,190,0,0,0,'',''),(211,78,'2021-09-12 00:00:00','M78','PHENYTOIN SODIUM TABLETS 100MG','Edit','Edit stock',340,0,0,0,0,200,0,0,0,'',''),(212,76,'2021-09-12 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Edit','Edit stock',234,0,0,0,0,52,0,0,0,'',''),(213,72,'2021-09-12 00:00:00','M72','QUETIAPINE TABLETS 100MG','Edit','Edit stock',270,0,0,0,0,506,0,0,0,'',''),(214,73,'2021-09-12 00:00:00','M73','QUETIAPINE TABLETS 200MG','Edit','Edit stock',52,0,0,0,0,364,0,0,0,'',''),(215,70,'2021-09-12 00:00:00','M70','QUETIAPINE TABLETS 25MG','Edit','Edit stock',543,0,0,0,0,154,0,0,0,'',''),(216,71,'2021-09-12 00:00:00','M71','QUETIAPINE TABLETS 50MG','Edit','Edit stock',225,0,0,0,0,604,0,0,0,'',''),(217,32,'2021-09-12 00:00:00','M32','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',511,0,0,0,0,493,0,0,0,'',''),(218,31,'2021-09-12 00:00:00','M31','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 3MG','Edit','Edit stock',393,0,0,0,0,393,0,0,0,'',''),(219,92,'2021-09-12 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Edit','Edit stock',1,0,0,0,0,8,0,0,0,'',''),(220,33,'2021-09-12 00:00:00','M33','RISPERIDONE TABLETS 1MG','Edit','Edit stock',406,0,0,0,0,497,0,0,0,'',''),(221,34,'2021-09-12 00:00:00','M34','RISPERIDONE TABLETS 2MG','Edit','Edit stock',217,0,0,0,0,297,0,0,0,'',''),(222,35,'2021-09-12 00:00:00','M35','RISPERIDONE TABLETS 3MG','Edit','Edit stock',199,0,0,0,0,250,0,0,0,'',''),(223,36,'2021-09-12 00:00:00','M36','RISPERIDONE TABLETS 4MG','Edit','Edit stock',631,0,0,0,0,212,0,0,0,'',''),(224,38,'2021-09-12 00:00:00','M38','SERTRALINE HCL TABLETS 100MG','Edit','Edit stock',219,0,0,0,0,168,0,0,0,'',''),(225,40,'2021-09-12 00:00:00','M40','SERTRALINE HCL TABLETS 25MG','Edit','Edit stock',378,0,0,0,0,245,0,0,0,'',''),(226,39,'2021-09-12 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Edit','Edit stock',265,0,0,0,0,312,0,0,0,'',''),(227,11,'2021-09-12 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Edit','Edit stock',1,0,0,0,0,2,0,0,0,'',''),(228,82,'2021-09-12 00:00:00','M82','SV 200MG','Edit','Edit stock',1247,0,0,0,0,967,0,0,0,'',''),(229,81,'2021-09-12 00:00:00','M81','SV 300MG','Edit','Edit stock',353,0,0,0,0,736,0,0,0,'',''),(230,83,'2021-09-12 00:00:00','M83','SV 500MG','Edit','Edit stock',1783,0,0,0,0,565,0,0,0,'',''),(231,45,'2021-09-12 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Edit','Edit stock',639,0,0,0,0,443,0,0,0,'',''),(232,37,'2021-09-12 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Edit','Edit stock',1620,0,0,0,0,1485,0,0,0,'',''),(233,46,'2021-09-12 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',307,0,0,0,0,2516,0,0,0,'',''),(234,42,'2021-09-12 00:00:00','M42','VENLAFAXINE EXTENDED REIEASE CAPSULES 37.5MG','Edit','Edit stock',116,0,0,0,0,60,0,0,0,'',''),(235,42,'2021-09-12 00:00:00','M42','VENLAFAXINE EXTENDED REIEASE CAPSULES 37.5MG','Edit','Edit stock',60,0,0,0,0,56,0,0,0,'',''),(236,43,'2021-09-12 00:00:00','M43','VENLAFAXINE EXTENDED RELEASE CAPSULES 75MG','Edit','Edit stock',163,0,0,0,0,107,0,0,0,'',''),(237,44,'2021-09-12 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Edit','Edit stock',32,0,0,0,0,206,0,0,0,'',''),(238,9,'2021-09-18 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Edit','Edit stock',374,0,0,0,0,374,1,0,0,'',''),(239,9,'2021-09-18 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Edit','Edit stock',374,1,0,0,0,374,0,0,0,'',''),(240,9,'2021-09-23 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Edit','Edit stock',374,0,0,0,0,0,374,0,0,'',''),(241,10,'2021-09-23 00:00:00','M10','AMISULPRIDE TABLETS 200MG','Edit','Edit stock',150,0,0,0,0,0,150,0,0,'',''),(242,8,'2021-09-23 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Edit','Edit stock',124,0,0,0,0,0,124,0,0,'',''),(243,15,'2021-09-23 00:00:00','M15','AMITRIPTYLINE TABLETS 10MG','Edit','Edit stock',155,0,0,0,0,0,155,0,0,'',''),(244,17,'2021-09-23 00:00:00','M17','AMITRIPTYLINE TABLETS 25MG','Edit','Edit stock',135,0,0,0,0,0,135,0,0,'',''),(245,19,'2021-09-23 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Edit','Edit stock',100,0,0,0,0,0,100,0,0,'',''),(246,18,'2021-09-23 00:00:00','M18','BUPROPION HCL EXTENDED RELEASE TABLETS 150MG','Edit','Edit stock',30,0,0,0,0,0,30,0,0,'',''),(247,59,'2021-09-23 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Edit','Edit stock',265,0,0,0,0,0,265,0,0,'',''),(248,58,'2021-09-23 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Edit','Edit stock',150,0,0,0,0,0,150,0,0,'',''),(249,57,'2021-09-23 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Edit','Edit stock',850,0,0,0,0,0,850,0,0,'',''),(250,86,'2021-09-23 00:00:00','M86','CLOBAZAM TABLETS 10 MG','Edit','Edit stock',252,0,0,0,0,0,252,0,0,'',''),(251,87,'2021-09-23 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Edit','Edit stock',578,0,0,0,0,0,578,0,0,'',''),(252,88,'2021-09-23 00:00:00','M88','CLONAZEPAM & ESCITALOPRAM OXALATE TABLETS 5 MG','Edit','Edit stock',70,0,0,0,0,0,70,0,0,'',''),(253,56,'2021-09-23 00:00:00','M56','CLOMIPRAMINE TABLETS 25MG','Edit','Edit stock',2,0,0,0,0,0,2,0,0,'',''),(254,3,'2021-09-23 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Edit','Edit stock',157,0,0,0,0,0,157,0,0,'',''),(255,89,'2021-09-23 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Edit','Edit stock',156,0,0,0,0,0,156,0,0,'',''),(256,49,'2021-09-23 00:00:00','M49','CLOZAPINE TABLETS 100MG','Edit','Edit stock',507,0,0,0,0,0,507,0,0,'',''),(257,50,'2021-09-23 00:00:00','M50','CLOZAPINE TABLETS 200MG','Edit','Edit stock',473,0,0,0,0,0,473,0,0,'',''),(258,47,'2021-10-02 00:00:00','M47','CLOZAPINE TABLETS 25MG','Edit','Edit stock',331,0,0,0,0,0,331,0,0,'',''),(259,44,'2021-10-08 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Edit','Edit stock',206,0,0,0,0,0,206,0,0,'',''),(260,48,'2021-10-08 00:00:00','M48','CLOZAPINE TABLETS 50MG','Edit','Edit stock',309,0,0,0,0,0,309,0,0,'',''),(261,52,'2021-10-08 00:00:00','M52','DONEPEZIL HCL TABLETS 10MG','Edit','Edit stock',30,0,0,0,0,0,30,0,0,'',''),(262,51,'2021-10-08 00:00:00','M51','DONEPEZIL HCL TABLETS 5MG','Edit','Edit stock',50,0,0,0,0,0,50,0,0,'',''),(263,53,'2021-10-08 00:00:00','M53','DOSULEPIN TABLETS 25MG','Edit','Edit stock',16,0,0,0,0,0,16,0,0,'',''),(264,55,'2021-10-14 00:00:00','M55','DOSULEPIN TABLETS BP 50MG','Edit','Edit stock',100,0,0,0,0,0,100,0,0,'',''),(265,54,'2021-10-14 00:00:00','M54','DOSULEPIN TABLETS BP 75MG','Edit','Edit stock',90,0,0,0,0,0,90,0,0,'',''),(266,5,'2021-10-14 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Edit','Edit stock',49,0,0,0,0,0,49,0,0,'',''),(267,6,'2021-10-14 00:00:00','M6','ESCITALOPRAM TABLETS 20MG','Edit','Edit stock',114,0,0,0,0,0,114,0,0,'',''),(268,4,'2021-10-14 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Edit','Edit stock',236,0,0,0,0,0,236,0,0,'',''),(269,41,'2021-10-14 00:00:00','M41','VENLAFAXINE HCL PROLONGED-RELEASE CAPSULES 37.5MG','Edit','Edit stock',60,0,0,0,0,0,60,0,0,'',''),(270,23,'2021-10-14 00:00:00','M23','FLUOXETINE CAPSULES 10MG','Edit','Edit stock',151,0,0,0,0,0,151,0,0,'',''),(271,12,'2021-10-14 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Edit','Edit stock',232,0,0,0,0,0,232,0,0,'',''),(272,14,'2021-10-14 00:00:00','M14','FLUVOXAMINE TABLETS 100MG','Edit','Edit stock',179,0,0,0,0,0,179,0,0,'',''),(273,21,'2021-10-14 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Edit','Edit stock',535,0,0,0,0,0,535,0,0,'',''),(274,20,'2021-10-14 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Edit','Edit stock',646,0,0,0,0,0,646,0,0,'',''),(275,22,'2021-10-14 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Edit','Edit stock',0,0,0,0,0,0,100,0,0,'',''),(276,24,'2021-10-14 00:00:00','M24','GABAPENTIN TABLETS 100MG','Edit','Edit stock',236,0,0,0,0,0,236,0,0,'',''),(277,13,'2021-10-14 00:00:00','M13','GLYCOPYRROLATE TABLETS 2MG','Edit','Edit stock',128,0,0,0,0,0,128,0,0,'',''),(278,26,'2021-10-14 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Edit','Edit stock',74,0,0,0,0,0,74,0,0,'',''),(279,25,'2021-10-14 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Edit','Edit stock',119,0,0,0,0,0,119,0,0,'',''),(280,63,'2021-10-14 00:00:00','M63','LACOSAMIDE TABLETS 100MG','Edit','Edit stock',113,0,0,0,0,0,113,0,0,'',''),(281,60,'2021-10-14 00:00:00','M60','LAMOTRIGINE DISPERSIBLE TABLETS 100MG','Edit','Edit stock',105,0,0,0,0,0,105,0,0,'',''),(282,61,'2021-10-14 00:00:00','M61','LAMOTRIGINE DISPERSIBLE TABLETS 50MG','Edit','Edit stock',189,0,0,0,0,0,189,0,0,'',''),(283,62,'2021-10-14 00:00:00','M62','LAMOTRIGINE TABLETS 25MG','Edit','Edit stock',66,0,0,0,0,0,66,0,0,'',''),(284,85,'2021-10-14 00:00:00','M85','LEVETIRACETAM TABLETS 250 MG','Edit','Edit stock',260,0,0,0,0,0,260,0,0,'',''),(285,84,'2021-10-14 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Edit','Edit stock',347,0,0,0,0,0,347,0,0,'',''),(286,29,'2021-10-14 00:00:00','M29','LITHIUM CARBONATE 300MG','Edit','Edit stock',596,0,0,0,0,0,596,0,0,'',''),(287,39,'2021-10-14 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Edit','Edit stock',312,0,0,0,0,0,312,0,0,'',''),(288,11,'2021-10-14 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Edit','Edit stock',2,0,0,0,0,0,10,0,0,'',''),(289,28,'2021-10-15 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Edit','Edit stock',536,0,0,0,0,0,536,0,0,'',''),(290,90,'2021-10-15 00:00:00','M90','LORAZEPAM TABLETS 1 MG','Edit','Edit stock',151,0,0,0,0,0,151,0,0,'',''),(291,91,'2021-10-23 00:00:00','M91','LORAZEPAM TABLETS 2MG ','Edit','Edit stock',251,0,0,0,0,0,251,0,0,'',''),(292,82,'2021-10-23 00:00:00','M82','SV 200MG','Edit','Edit stock',967,0,0,0,0,967,967,0,0,'',''),(293,27,'2021-10-23 00:00:00','M27','LURASIDONE HCL TABLETS 40MG','Edit','Edit stock',141,0,0,0,0,0,141,0,0,'',''),(294,74,'2021-10-23 00:00:00','M74','MEMANTINE HCL & DONEPEZIL HCL TABLETS ','Edit','Edit stock',170,0,0,0,0,0,170,0,0,'',''),(295,65,'2021-10-23 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Edit','Edit stock',218,0,0,0,0,0,218,0,0,'',''),(296,64,'2021-10-23 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Edit','Edit stock',110,0,0,0,0,0,110,0,0,'',''),(297,93,'2021-10-23 00:00:00','M93','FLUPHENAZINE DECANOATE INJECTION IP 1ML','Add','To main stock',0,0,0,0,18,18,0,0,0,'',''),(298,94,'2021-10-23 00:00:00','M94','DIVALPROEX SUSTAINED RELEASE TABLETS IP 250','Add','To main stock',0,0,0,0,70,70,0,0,0,'',''),(299,95,'2021-10-23 00:00:00','M95','TRIFLUOPERAZINE TABLETS IP 5MG','Add','To main stock',0,0,0,0,455,455,0,0,0,'',''),(300,9,'2021-10-23 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Edit','Edit stock',0,374,0,0,0,0,2,0,0,'',''),(301,10,'2021-10-23 00:00:00','M10','AMISULPRIDE TABLETS 200MG','Edit','Edit stock',0,150,0,0,0,0,150,0,0,'',''),(302,8,'2021-10-23 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Edit','Edit stock',0,124,0,0,0,0,257,0,0,'',''),(303,15,'2021-10-23 00:00:00','M15','AMITRIPTYLINE TABLETS 10MG','Edit','Edit stock',0,155,0,0,0,0,210,0,0,'',''),(304,17,'2021-10-23 00:00:00','M17','AMITRIPTYLINE TABLETS 25MG','Edit','Edit stock',0,135,0,0,0,0,15,0,0,'',''),(305,19,'2021-10-23 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Edit','Edit stock',0,100,0,0,0,0,27,0,0,'',''),(306,59,'2021-10-23 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Edit','Edit stock',0,265,0,0,0,0,611,0,0,'',''),(307,57,'2021-10-23 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Edit','Edit stock',0,850,0,0,0,0,147,0,0,'',''),(308,86,'2021-10-23 00:00:00','M86','CLOBAZAM TABLETS 10 MG','Edit','Edit stock',0,252,0,0,0,0,192,0,0,'',''),(309,87,'2021-10-23 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Edit','Edit stock',0,578,0,0,0,0,516,0,0,'',''),(310,56,'2021-10-23 00:00:00','M56','CLOMIPRAMINE TABLETS 25MG','Edit','Edit stock',0,2,0,0,0,0,12,0,0,'',''),(311,3,'2021-10-23 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Edit','Edit stock',0,157,0,0,0,0,89,0,0,'',''),(312,89,'2021-10-23 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Edit','Edit stock',0,156,0,0,0,0,124,0,0,'',''),(313,49,'2021-10-23 00:00:00','M49','CLOZAPINE TABLETS 100MG','Edit','Edit stock',0,507,0,0,0,0,300,0,0,'',''),(314,50,'2021-10-23 00:00:00','M50','CLOZAPINE TABLETS 200MG','Edit','Edit stock',0,473,0,0,0,0,386,0,0,'',''),(315,47,'2021-10-23 00:00:00','M47','CLOZAPINE TABLETS 25MG','Edit','Edit stock',0,331,0,0,0,0,238,0,0,'',''),(316,48,'2021-10-23 00:00:00','M48','CLOZAPINE TABLETS 50MG','Edit','Edit stock',0,309,0,0,0,0,278,0,0,'',''),(317,94,'2021-10-23 00:00:00','M94','DIVALPROEX SUSTAINED RELEASE TABLETS IP 250','Edit','Edit stock',70,0,0,0,0,0,0,0,0,'',''),(318,66,'2021-10-23 00:00:00','M66','NITRAZEPAM TABLETS 10MG','Edit','Edit stock',58,0,0,0,0,0,58,0,0,'',''),(319,68,'2021-10-23 00:00:00','M68','OLANZAPINE TABLETS 10MG','Edit','Edit stock',93,0,0,0,0,0,93,0,0,'',''),(320,67,'2021-10-23 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Edit','Edit stock',60,0,0,0,0,0,60,0,0,'',''),(321,43,'2021-10-23 00:00:00','M43','VENLAFAXINE EXTENDED RELEASE CAPSULES 75MG','Edit','Edit stock',107,0,0,0,0,0,107,0,0,'',''),(322,42,'2021-10-23 00:00:00','M42','VENLAFAXINE EXTENDED REIEASE CAPSULES 37.5MG','Edit','Edit stock',56,0,0,0,0,0,56,0,0,'',''),(323,46,'2021-10-23 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',2516,0,0,0,0,0,2516,0,0,'',''),(324,38,'2021-10-23 00:00:00','M38','SERTRALINE HCL TABLETS 100MG','Edit','Edit stock',168,0,0,0,0,0,168,0,0,'',''),(325,40,'2021-10-23 00:00:00','M40','SERTRALINE HCL TABLETS 25MG','Edit','Edit stock',245,0,0,0,0,0,245,0,0,'',''),(326,82,'2021-10-23 00:00:00','M82','SV 200MG','Edit','Edit stock',967,967,0,0,0,0,967,0,0,'',''),(327,81,'2021-10-23 00:00:00','M81','SV 300MG','Edit','Edit stock',736,0,0,0,0,0,736,0,0,'',''),(328,83,'2021-10-23 00:00:00','M83','SV 500MG','Edit','Edit stock',565,0,0,0,0,0,565,0,0,'',''),(329,95,'2021-10-23 00:00:00','M95','TRIFLUOPERAZINE TABLETS IP 5MG','Edit','Edit stock',455,0,0,0,0,0,455,0,0,'',''),(330,37,'2021-10-23 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Edit','Edit stock',1485,0,0,0,0,0,1485,0,0,'',''),(331,45,'2021-10-23 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Edit','Edit stock',443,0,0,0,0,0,443,0,0,'',''),(332,69,'2021-10-23 00:00:00','M69','OLANZAPINE TABLETS 5MG','Edit','Edit stock',213,0,0,0,0,0,213,0,0,'',''),(333,77,'2021-10-23 00:00:00','M77','PHENOBARBITONE TABLETS 30MG','Edit','Edit stock',190,0,0,0,0,0,190,0,0,'',''),(334,79,'2021-10-23 00:00:00','M79','PHENOBARBITONE TABLETS 60MG','Edit','Edit stock',60,0,0,0,0,0,60,0,0,'',''),(335,78,'2021-10-23 00:00:00','M78','PHENYTOIN SODIUM TABLETS 100MG','Edit','Edit stock',200,0,0,0,0,0,200,0,0,'',''),(336,16,'2021-10-23 00:00:00','M16','PHENYTOIN TABLETS 100MG','Edit','Edit stock',122,0,0,0,0,0,0,0,0,'',''),(337,80,'2021-10-23 00:00:00','M80','PIMOZIDE TABLETS 2MG','Edit','Edit stock',60,0,0,0,0,0,60,0,0,'',''),(338,75,'2021-10-23 00:00:00','M75','PROPRANOLOL SUSTAINED RELEASE TABLETS 40MG','Edit','Edit stock',97,0,0,0,0,0,97,0,0,'',''),(339,76,'2021-10-23 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Edit','Edit stock',52,0,0,0,0,0,52,0,0,'',''),(340,72,'2021-10-23 00:00:00','M72','QUETIAPINE TABLETS 100MG','Edit','Edit stock',506,0,0,0,0,0,506,0,0,'',''),(341,73,'2021-10-23 00:00:00','M73','QUETIAPINE TABLETS 200MG','Edit','Edit stock',364,0,0,0,0,0,364,0,0,'',''),(342,70,'2021-10-23 00:00:00','M70','QUETIAPINE TABLETS 25MG','Edit','Edit stock',154,0,0,0,0,0,154,0,0,'',''),(343,71,'2021-10-23 00:00:00','M71','QUETIAPINE TABLETS 50MG','Edit','Edit stock',604,0,0,0,0,0,604,0,0,'',''),(344,32,'2021-10-23 00:00:00','M32','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',493,0,0,0,0,0,493,0,0,'',''),(345,31,'2021-10-23 00:00:00','M31','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 3MG','Edit','Edit stock',393,0,0,0,0,0,393,0,0,'',''),(346,30,'2021-10-23 00:00:00','M30','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 4MG','Edit','Edit stock',86,0,0,0,0,0,86,0,0,'',''),(347,92,'2021-10-23 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Edit','Edit stock',8,0,0,0,0,0,8,0,0,'',''),(348,33,'2021-10-23 00:00:00','M33','RISPERIDONE TABLETS 1MG','Edit','Edit stock',497,0,0,0,0,0,497,0,0,'',''),(349,34,'2021-10-23 00:00:00','M34','RISPERIDONE TABLETS 2MG','Edit','Edit stock',297,0,0,0,0,0,297,0,0,'',''),(350,35,'2021-10-23 00:00:00','M35','RISPERIDONE TABLETS 3MG','Edit','Edit stock',250,0,0,0,0,0,250,0,0,'',''),(351,36,'2021-10-23 00:00:00','M36','RISPERIDONE TABLETS 4MG','Edit','Edit stock',212,0,0,0,0,0,212,0,0,'',''),(352,12,'2021-10-01 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,232,0,0,28,0,204,0,0,'112/2017','SAIFUNEESA'),(353,34,'2021-10-01 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,297,0,0,28,0,269,0,0,'112/2017','SAIFUNEESA'),(354,46,'2021-10-01 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,2516,0,0,28,0,2488,0,0,'112/2017','SAIFUNEESA'),(355,9,'2021-10-24 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Edit','Edit stock',0,2,0,0,0,0,200,0,0,'',''),(356,9,'2021-10-22 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,200,0,0,28,0,172,0,0,'112/2017','SAIFUNEESA'),(357,35,'2021-09-03 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,250,0,0,42,0,208,0,0,'144/2019','JAMSHI'),(358,46,'2021-09-03 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,2488,0,0,42,0,2446,0,0,'144/2019','JAMSHI'),(359,5,'2021-10-22 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,49,0,0,28,0,21,0,0,'202/2021','SHAJI'),(360,3,'2021-10-22 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,89,0,0,5,0,84,0,0,'202/2021','SHAJI'),(361,21,'2021-10-22 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,535,0,0,28,0,507,0,0,'77/2017','SUHARA'),(362,69,'2021-10-22 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,213,0,0,28,0,185,0,0,'77/2017','SUHARA'),(363,23,'2021-10-22 00:00:00','M23','FLUOXETINE CAPSULES 10MG','Transfer','Sub to OP',0,151,0,0,56,0,95,0,0,'77/2017','SUHARA'),(364,93,'2021-10-24 00:00:00','M93','FLUPHENAZINE DECANOATE INJECTION IP 1ML','Edit','Edit stock',18,0,0,0,0,0,18,0,0,'',''),(365,93,'2021-10-22 00:00:00','M93','FLUPHENAZINE DECANOATE INJECTION IP 1ML','Transfer','Sub to OP',0,18,0,0,1,0,17,0,0,'196/2021','MUHAMMAD KUTTI'),(366,35,'2021-10-22 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,208,0,0,14,0,194,0,0,'196/2021','MUHAMMAD KUTTI'),(367,38,'2021-10-22 00:00:00','M38','SERTRALINE HCL TABLETS 100MG','Transfer','Sub to OP',0,168,0,0,28,0,140,0,0,'105/2014','SUBAIDA'),(368,39,'2021-10-22 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Transfer','Sub to OP',0,312,0,0,28,0,284,0,0,'105/2014','SUBAIDA'),(369,4,'2021-10-22 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,236,0,0,28,0,208,0,0,'105/2014','SUBAIDA'),(370,71,'2021-10-22 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,604,0,0,56,0,548,0,0,'49/2017','RUKKIYA'),(371,70,'2021-10-22 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,154,0,0,56,0,98,0,0,'49/2017','RUKKIYA'),(372,83,'2021-10-22 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,565,0,0,168,0,397,0,0,'137/2017','MUJEEBRAHMAN'),(373,73,'2021-10-22 00:00:00','M73','QUETIAPINE TABLETS 200MG','Transfer','Sub to OP',0,364,0,0,84,0,280,0,0,'137/2017','MUJEEBRAHMAN'),(374,46,'2021-10-22 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,2446,0,0,256,0,2190,0,0,'137/2017','MUJEEBRAHMAN'),(375,48,'2021-09-24 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,278,0,0,42,0,236,0,0,'48/2017','ABDUL HASEEB'),(376,47,'2021-09-24 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,238,0,0,42,0,196,0,0,'48/2017','ABDUL HASEEB'),(377,71,'2021-09-24 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,548,0,0,42,0,506,0,0,'48/2017','ABDUL HASEEB'),(378,46,'2021-09-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,2190,0,0,84,0,2106,0,0,'48/2017','ABDUL HASEEB'),(379,34,'2021-09-24 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,269,0,0,84,0,185,0,0,'48/2017','ABDUL HASEEB'),(380,12,'2021-10-22 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,204,0,0,42,0,162,0,0,'161/2019','ASHRAF CP'),(381,44,'2021-10-22 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Transfer','Sub to OP',0,206,0,0,84,0,122,0,0,'161/2019','ASHRAF CP'),(382,65,'2021-10-22 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,218,0,0,84,0,134,0,0,'161/2019','ASHRAF CP'),(383,50,'2021-10-15 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,386,0,0,14,0,372,0,0,'231/2021','MUHAMMAD IQBAL'),(384,48,'2021-10-15 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,236,0,0,5,0,231,0,0,'231/2021','MUHAMMAD IQBAL'),(385,81,'2021-10-15 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,736,0,0,14,0,722,0,0,'232/2021','USMAN'),(386,83,'2021-10-15 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,397,0,0,14,0,383,0,0,'232/2021','USMAN'),(387,70,'2021-10-15 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,98,0,0,14,0,84,0,0,'232/2021','USMAN'),(388,46,'2021-10-15 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,2106,0,0,28,0,2078,0,0,'232/2021','USMAN'),(389,36,'2021-10-15 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,212,0,0,14,0,198,0,0,'232/2021','USMAN'),(390,76,'2021-10-15 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,52,0,0,14,0,38,0,0,'232/2021','USMAN'),(391,65,'2021-10-01 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,134,0,0,56,0,78,0,0,'205/2021','SAINABA'),(392,70,'2021-10-01 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,84,0,0,14,0,70,0,0,'205/2021','SAINABA'),(393,89,'2021-10-01 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,124,0,0,14,0,110,0,0,'205/2021','SAINABA'),(394,57,'2021-10-08 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Transfer','Sub to OP',0,147,0,0,42,0,105,0,0,'206/2021','FARHANA SHIRIL'),(395,34,'2021-10-08 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,185,0,0,32,0,153,0,0,'206/2021','FARHANA SHIRIL'),(396,33,'2021-09-17 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,497,0,0,21,0,476,0,0,'0112/2017','ZEHARABI'),(397,82,'2021-09-03 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,967,0,0,56,0,911,0,0,'135/2018','SOUDHA'),(398,83,'2021-09-03 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,383,0,0,56,0,327,0,0,'135/2018','SOUDHA'),(399,84,'2021-09-03 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,347,0,0,112,0,235,0,0,'135/2018','SOUDHA'),(400,69,'2021-09-03 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,185,0,0,56,0,129,0,0,'135/2018','SOUDHA'),(401,67,'2021-09-03 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,60,0,0,56,0,4,0,0,'135/2018','SOUDHA'),(402,67,'2021-10-28 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Edit','Edit stock',0,4,0,0,0,0,200,0,0,'',''),(403,69,'2021-09-10 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,129,0,0,49,0,80,0,0,'16/2021','SAFIYA'),(404,67,'2021-09-10 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,200,0,0,49,0,151,0,0,'16/2021','SAFIYA'),(405,83,'2021-09-10 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,327,0,0,49,0,278,0,0,'16/2021','SAFIYA'),(406,82,'2021-09-10 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,911,0,0,49,0,862,0,0,'16/2021','SAFIYA'),(407,46,'2021-09-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,2078,0,0,49,0,2029,0,0,'16/2021','SAFIYA'),(408,69,'2021-09-17 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,80,0,0,42,0,38,0,0,'135/2020','ALAVI'),(409,12,'2021-09-17 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,162,0,0,42,0,120,0,0,'135/2020','ALAVI'),(410,82,'2021-09-17 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,862,0,0,84,0,778,0,0,'135/2020','ALAVI'),(411,35,'2021-09-17 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,194,0,0,74,0,120,0,0,'088/2017','MUHAMMAD RAFEEQ'),(412,34,'2021-09-17 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,153,0,0,10,0,143,0,0,'088/2017','MUHAMMAD RAFEEQ'),(413,33,'2021-09-17 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,476,0,0,32,0,444,0,0,'088/2017','MUHAMMAD RAFEEQ'),(414,46,'2021-09-17 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,2029,0,0,42,0,1987,0,0,'088/2017','MUHAMMAD RAFEEQ'),(415,49,'2021-09-17 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,300,0,0,42,0,258,0,0,'88/2017','MUHAMMAD RAFI'),(416,47,'2021-09-17 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,196,0,0,42,0,154,0,0,'88/2017','MUHAMMAD RAFI'),(417,9,'2021-09-17 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,172,0,0,42,0,130,0,0,'88/2017','MUHAMMAD RAFI'),(418,46,'2021-09-17 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1987,0,0,42,0,1945,0,0,'88/2017','MUHAMMAD RAFI'),(419,83,'2021-09-03 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,278,0,0,56,0,222,0,0,'26/2017','ABDURAHMAN'),(420,49,'2021-08-20 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,258,0,0,70,0,188,0,0,'99/2019','SUNIL'),(421,48,'2021-08-20 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,231,0,0,70,0,161,0,0,'99/2019','SUNIL'),(422,6,'2021-08-20 00:00:00','M6','ESCITALOPRAM TABLETS 20MG','Transfer','Sub to OP',0,114,0,0,70,0,44,0,0,'99/2019','SUNIL'),(423,59,'2021-08-27 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Transfer','Sub to OP',0,611,0,0,73,0,538,0,0,'89/2018','MUHAMMAD'),(424,58,'2021-08-27 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Transfer','Sub to OP',0,150,0,0,73,0,77,0,0,'89/2018','MUHAMMAD'),(425,71,'2021-08-27 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,506,0,0,73,0,433,0,0,'89/2018','MUHAMMAD'),(426,70,'2021-08-27 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,70,0,0,70,0,0,0,0,'89/2018','MUHAMMAD'),(427,24,'2021-08-27 00:00:00','M24','GABAPENTIN TABLETS 100MG','Transfer','Sub to OP',0,236,0,0,73,0,163,0,0,'89/2018','MUHAMMAD'),(428,5,'2021-10-28 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Edit','Edit stock',0,21,0,0,0,0,200,0,0,'',''),(429,70,'2021-10-28 00:00:00','M70','QUETIAPINE TABLETS 25MG','Edit','Edit stock',0,0,0,0,0,0,200,0,0,'',''),(430,6,'2021-10-28 00:00:00','M6','ESCITALOPRAM TABLETS 20MG','Edit','Edit stock',0,44,0,0,0,0,200,0,0,'',''),(431,6,'2021-09-03 00:00:00','M6','ESCITALOPRAM TABLETS 20MG','Transfer','Sub to OP',0,200,0,0,56,0,144,0,0,'14/2021','PRIYA'),(432,81,'2021-09-03 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,722,0,0,112,0,610,0,0,'83/2019','FARSANA THASNI'),(433,84,'2021-09-03 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,235,0,0,112,0,123,0,0,'83/2019','FARSANA THASNI'),(434,59,'2021-09-03 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Transfer','Sub to OP',0,538,0,0,56,0,482,0,0,'83/2019','FARSANA THASNI'),(435,57,'2021-09-03 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Transfer','Sub to OP',0,105,0,0,56,0,49,0,0,'83/2019','FARSANA THASNI'),(436,83,'2021-09-03 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,222,0,0,112,0,110,0,0,'01/2018','ABDUL NAZAR'),(437,50,'2021-09-03 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,372,0,0,56,0,316,0,0,'01/2018','ABDUL NAZAR'),(438,48,'2021-09-03 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,161,0,0,56,0,105,0,0,'01/2018','ABDUL NAZAR'),(439,68,'2021-09-03 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,93,0,0,56,0,37,0,0,'01/2018','ABDUL NAZAR'),(440,69,'2021-09-03 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,38,0,0,23,0,15,0,0,'01/2018','ABDUL NAZAR'),(441,22,'2021-09-03 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,100,0,0,56,0,44,0,0,'01/2018','ABDUL NAZAR'),(442,81,'2021-10-29 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,610,0,0,28,0,582,0,0,'232/2021','USMAN'),(443,83,'2021-10-29 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,110,0,0,28,0,82,0,0,'232/2021','USMAN'),(444,46,'2021-10-29 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1945,0,0,84,0,1861,0,0,'232/2021','USMAN'),(445,36,'2021-10-29 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,198,0,0,28,0,170,0,0,'232/2021','USMAN'),(446,76,'2021-10-29 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,38,0,0,28,0,10,0,0,'232/2021','USMAN'),(447,83,'2021-10-29 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,82,0,0,14,0,68,0,0,'247/2021','NOUSHAD '),(448,68,'2021-10-29 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,37,0,0,7,0,30,0,0,'247/2021','NOUSHAD '),(449,21,'2021-10-29 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,507,0,0,7,0,500,0,0,'247/2021','NOUSHAD '),(450,46,'2021-10-29 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1861,0,0,7,0,1854,0,0,'247/2021','NOUSHAD '),(451,35,'2021-10-29 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,120,0,0,14,0,106,0,0,'088/2017','MUHAMMAD RAFEEQ'),(452,33,'2021-10-29 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,444,0,0,7,0,437,0,0,'088/2017','MUHAMMAD RAFEEQ'),(453,46,'2021-10-29 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1854,0,0,7,0,1847,0,0,'088/2017','MUHAMMAD RAFEEQ'),(454,17,'2021-11-04 00:00:00','M17','AMITRIPTYLINE TABLETS 25MG','Edit','Edit stock',0,15,0,0,0,0,100,0,0,'',''),(455,19,'2021-11-04 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Edit','Edit stock',0,27,0,0,0,0,100,0,0,'',''),(456,56,'2021-11-04 00:00:00','M56','CLOMIPRAMINE TABLETS 25MG','Edit','Edit stock',0,12,0,0,0,0,100,0,0,'',''),(457,65,'2021-11-04 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Edit','Edit stock',0,78,0,0,0,0,150,0,0,'',''),(458,68,'2021-11-04 00:00:00','M68','OLANZAPINE TABLETS 10MG','Edit','Edit stock',0,30,0,0,0,0,100,0,0,'',''),(459,69,'2021-11-04 00:00:00','M69','OLANZAPINE TABLETS 5MG','Edit','Edit stock',0,15,0,0,0,0,100,0,0,'',''),(460,26,'2021-11-04 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Edit','Edit stock',0,74,0,0,0,0,100,0,0,'',''),(461,22,'2021-11-04 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Edit','Edit stock',0,44,0,0,0,0,100,0,0,'',''),(462,66,'2021-11-04 00:00:00','M66','NITRAZEPAM TABLETS 10MG','Edit','Edit stock',0,58,0,0,0,0,100,0,0,'',''),(463,76,'2021-11-04 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Edit','Edit stock',0,10,0,0,0,0,100,0,0,'',''),(464,83,'2021-11-04 00:00:00','M83','SV 500MG','Edit','Edit stock',0,68,0,0,0,0,500,0,0,'',''),(465,42,'2021-11-04 00:00:00','M42','VENLAFAXINE EXTENDED REIEASE CAPSULES 37.5MG','Edit','Edit stock',0,56,0,0,0,0,100,0,0,'',''),(466,41,'2021-11-04 00:00:00','M41','VENLAFAXINE HCL PROLONGED-RELEASE CAPSULES 37.5MG','Edit','Edit stock',0,60,0,0,0,0,100,0,0,'',''),(467,65,'2021-10-29 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,150,0,0,84,0,66,0,0,'205/2021','SAINABA'),(468,70,'2021-10-29 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,200,0,0,21,0,179,0,0,'205/2021','SAINABA'),(469,35,'2021-10-29 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,106,0,0,98,0,8,0,0,'088/2017','MUHAMMAD RAFEEQ'),(470,33,'2021-10-29 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,437,0,0,49,0,388,0,0,'088/2017','MUHAMMAD RAFEEQ'),(471,46,'2021-10-29 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1847,0,0,49,0,1798,0,0,'088/2017','MUHAMMAD RAFEEQ'),(472,49,'2021-10-29 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,188,0,0,56,0,132,0,0,'88/2017','MUHAMMAD RAFI'),(473,47,'2021-10-29 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,154,0,0,56,0,98,0,0,'88/2017','MUHAMMAD RAFI'),(474,9,'2021-10-29 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,130,0,0,56,0,74,0,0,'88/2017','MUHAMMAD RAFI'),(475,46,'2021-10-29 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1798,0,0,56,0,1742,0,0,'88/2017','MUHAMMAD RAFI'),(476,81,'2021-10-29 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,582,0,0,112,0,470,0,0,'83/2019','FARSANA THASNI'),(477,84,'2021-10-29 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,123,0,0,112,0,11,0,0,'83/2019','FARSANA THASNI'),(478,59,'2021-10-29 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Transfer','Sub to OP',0,482,0,0,56,0,426,0,0,'83/2019','FARSANA THASNI'),(479,76,'2021-11-04 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Edit','Edit stock',0,100,0,0,0,0,200,0,0,'',''),(480,84,'2021-11-04 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Edit','Edit stock',0,11,0,0,0,0,200,0,0,'',''),(481,83,'2021-10-29 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,500,0,0,56,0,444,0,0,'135/2018','SOUDHA'),(482,82,'2021-10-29 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,778,0,0,56,0,722,0,0,'135/2018','SOUDHA'),(483,84,'2021-10-29 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,200,0,0,112,0,88,0,0,'135/2018','SOUDHA'),(484,69,'2021-10-29 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,100,0,0,56,0,44,0,0,'135/2018','SOUDHA'),(485,67,'2021-10-29 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,151,0,0,56,0,95,0,0,'135/2018','SOUDHA'),(486,76,'2021-10-29 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,200,0,0,112,0,88,0,0,'135/2018','SOUDHA'),(487,46,'2021-10-29 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1742,0,0,56,0,1686,0,0,'135/2018','SOUDHA'),(488,49,'2021-10-29 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,132,0,0,84,0,48,0,0,'99/2019','SUNIL'),(489,48,'2021-10-29 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,105,0,0,84,0,21,0,0,'99/2019','SUNIL'),(490,6,'2021-10-29 00:00:00','M6','ESCITALOPRAM TABLETS 20MG','Transfer','Sub to OP',0,144,0,0,84,0,60,0,0,'99/2019','SUNIL'),(491,5,'2021-10-29 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,200,0,0,84,0,116,0,0,'99/2019','SUNIL'),(492,57,'2021-11-04 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Edit','Edit stock',0,49,0,0,0,0,200,0,0,'',''),(493,58,'2021-11-04 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Edit','Edit stock',0,77,0,0,0,0,200,0,0,'',''),(494,57,'2021-10-29 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Transfer','Sub to OP',0,200,0,0,56,0,144,0,0,'206/2021','FARHANA SHIRIL'),(495,33,'2021-10-29 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,388,0,0,56,0,332,0,0,'206/2021','FARHANA SHIRIL'),(496,48,'2021-11-04 00:00:00','M48','CLOZAPINE TABLETS 50MG','Edit','Edit stock',0,21,0,0,0,0,200,0,0,'',''),(497,47,'2021-10-29 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,98,0,0,56,0,42,0,0,'27/2017','FADALU (FAIZAL)'),(498,48,'2021-10-29 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,200,0,0,56,0,144,0,0,'27/2017','FADALU (FAIZAL)'),(499,20,'2021-10-29 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,646,0,0,56,0,590,0,0,'27/2017','FADALU (FAIZAL)'),(500,69,'2021-11-04 00:00:00','M69','OLANZAPINE TABLETS 5MG','Edit','Edit stock',0,44,0,0,0,0,200,0,0,'',''),(501,69,'2021-10-29 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,200,0,0,56,0,144,0,0,'16/2021','SAFIYA'),(502,67,'2021-10-29 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,95,0,0,56,0,39,0,0,'16/2021','SAFIYA'),(503,83,'2021-10-29 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,444,0,0,56,0,388,0,0,'16/2021','SAFIYA'),(504,82,'2021-10-29 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,722,0,0,56,0,666,0,0,'16/2021','SAFIYA'),(505,46,'2021-10-29 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1686,0,0,56,0,1630,0,0,'16/2021','SAFIYA'),(506,67,'2021-11-04 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Edit','Edit stock',0,39,0,0,0,0,200,0,0,'',''),(507,83,'2021-10-29 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,388,0,0,112,0,276,0,0,'01/2018','ABDUL NAZAR'),(508,50,'2021-10-29 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,316,0,0,56,0,260,0,0,'01/2018','ABDUL NAZAR'),(509,48,'2021-10-29 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,144,0,0,56,0,88,0,0,'01/2018','ABDUL NAZAR'),(510,68,'2021-10-29 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,100,0,0,56,0,44,0,0,'01/2018','ABDUL NAZAR'),(511,67,'2021-10-29 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,200,0,0,56,0,144,0,0,'01/2018','ABDUL NAZAR'),(512,12,'2021-10-29 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,120,0,0,56,0,64,0,0,'01/2018','ABDUL NAZAR'),(513,9,'2021-11-04 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Edit','Edit stock',0,74,0,0,0,0,200,0,0,'',''),(514,47,'2021-11-04 00:00:00','M47','CLOZAPINE TABLETS 25MG','Edit','Edit stock',0,42,0,0,0,0,200,0,0,'',''),(515,48,'2021-11-04 00:00:00','M48','CLOZAPINE TABLETS 50MG','Edit','Edit stock',0,88,0,0,0,0,200,0,0,'',''),(516,35,'2021-11-04 00:00:00','M35','RISPERIDONE TABLETS 3MG','Edit','Edit stock',0,8,0,0,0,0,200,0,0,'',''),(517,68,'2021-11-04 00:00:00','M68','OLANZAPINE TABLETS 10MG','Edit','Edit stock',0,44,0,0,0,0,200,0,0,'',''),(518,35,'2021-10-22 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,200,0,0,56,0,144,0,0,'134/2020','MADHU'),(519,46,'2021-10-22 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1630,0,0,84,0,1546,0,0,'134/2020','MADHU'),(520,83,'2021-10-22 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,276,0,0,56,0,220,0,0,'134/2020','MADHU'),(521,70,'2021-10-22 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,179,0,0,28,0,151,0,0,'134/2020','MADHU'),(522,71,'2021-10-22 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,433,0,0,28,0,405,0,0,'134/2020','MADHU'),(523,26,'2021-11-04 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Edit','Edit stock',0,100,0,0,0,0,500,0,0,'',''),(524,83,'2021-10-22 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,220,0,0,156,0,64,0,0,'137/2017','MUJEEBRAHMAN'),(525,26,'2021-10-22 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,500,0,0,117,0,383,0,0,'137/2017','MUJEEBRAHMAN'),(526,73,'2021-10-22 00:00:00','M73','QUETIAPINE TABLETS 200MG','Transfer','Sub to OP',0,280,0,0,78,0,202,0,0,'137/2017','MUJEEBRAHMAN'),(527,46,'2021-10-22 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1546,0,0,234,0,1312,0,0,'137/2017','MUJEEBRAHMAN'),(528,83,'2021-11-04 00:00:00','M83','SV 500MG','Edit','Edit stock',0,64,0,0,0,0,1000,0,0,'',''),(529,73,'2021-10-01 00:00:00','M73','QUETIAPINE TABLETS 200MG','Transfer','Sub to OP',0,202,0,0,42,0,160,0,0,'182/2021','MOHAMMAD BASHEER'),(530,72,'2021-10-01 00:00:00','M72','QUETIAPINE TABLETS 100MG','Transfer','Sub to OP',0,506,0,0,42,0,464,0,0,'182/2021','MOHAMMAD BASHEER'),(531,46,'2021-10-01 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1312,0,0,126,0,1186,0,0,'182/2021','MOHAMMAD BASHEER'),(532,83,'2021-10-01 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,1000,0,0,84,0,916,0,0,'182/2021','MOHAMMAD BASHEER'),(533,25,'2021-10-01 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,119,0,0,42,0,77,0,0,'182/2021','MOHAMMAD BASHEER'),(534,26,'2021-10-01 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,383,0,0,42,0,341,0,0,'182/2021','MOHAMMAD BASHEER'),(535,48,'2021-10-01 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,200,0,0,42,0,158,0,0,'182/2021','MOHAMMAD BASHEER'),(536,12,'2021-10-01 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,64,0,0,56,0,8,0,0,'112/2017','SAIFUNEESA'),(537,34,'2021-10-01 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,143,0,0,56,0,87,0,0,'112/2017','SAIFUNEESA'),(538,46,'2021-10-01 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1186,0,0,56,0,1130,0,0,'112/2017','SAIFUNEESA'),(539,9,'2021-10-01 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,200,0,0,56,0,144,0,0,'112/2017','SAIFUNEESA'),(540,83,'2021-10-01 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,916,0,0,112,0,804,0,0,'58/2021','SUMAYYA'),(541,50,'2021-10-01 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,260,0,0,56,0,204,0,0,'58/2021','SUMAYYA'),(542,48,'2021-10-01 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,158,0,0,56,0,102,0,0,'58/2021','SUMAYYA'),(543,46,'2021-10-01 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1130,0,0,56,0,1074,0,0,'58/2021','SUMAYYA'),(544,83,'2021-09-10 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,804,0,0,112,0,692,0,0,'059/2021','YASHODHA'),(545,70,'2021-09-10 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,151,0,0,56,0,95,0,0,'059/2021','YASHODHA'),(546,49,'2021-11-04 00:00:00','M49','CLOZAPINE TABLETS 100MG','Edit','Edit stock',0,48,0,0,0,0,200,0,0,'',''),(547,49,'2021-09-10 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,200,0,0,112,0,88,0,0,'137/2020','SADHASHIVAN'),(548,48,'2021-09-10 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,102,0,0,56,0,46,0,0,'137/2020','SADHASHIVAN'),(549,36,'2021-09-10 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,170,0,0,56,0,114,0,0,'137/2020','SADHASHIVAN'),(550,46,'2021-09-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1074,0,0,56,0,1018,0,0,'137/2020','SADHASHIVAN'),(551,82,'2021-09-10 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,666,0,0,56,0,610,0,0,'137/2020','SADHASHIVAN'),(552,83,'2021-09-10 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,692,0,0,56,0,636,0,0,'137/2020','SADHASHIVAN'),(553,36,'2021-10-01 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,114,0,0,28,0,86,0,0,'36/2020','UMMUHABEEBA'),(554,33,'2021-10-01 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,332,0,0,28,0,304,0,0,'36/2020','UMMUHABEEBA'),(555,49,'2021-10-01 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,88,0,0,56,0,32,0,0,'36/2020','UMMUHABEEBA'),(556,46,'2021-10-01 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1018,0,0,56,0,962,0,0,'36/2020','UMMUHABEEBA'),(557,11,'2021-10-01 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,10,0,0,1,0,9,0,0,'36/2020','UMMUHABEEBA'),(558,83,'2021-10-22 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,636,0,0,28,0,608,0,0,'38/2017','UNNEENKUTTY'),(559,82,'2021-10-22 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,610,0,0,14,0,596,0,0,'38/2017','UNNEENKUTTY'),(560,26,'2021-10-22 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,341,0,0,28,0,313,0,0,'38/2017','UNNEENKUTTY'),(561,46,'2021-10-22 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,962,0,0,42,0,920,0,0,'38/2017','UNNEENKUTTY'),(562,49,'2021-10-22 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,32,0,0,14,0,18,0,0,'38/2017','UNNEENKUTTY'),(563,48,'2021-10-22 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,46,0,0,28,0,18,0,0,'38/2017','UNNEENKUTTY'),(564,48,'2021-11-04 00:00:00','M48','CLOZAPINE TABLETS 50MG','Edit','Edit stock',0,18,0,0,0,0,200,0,0,'',''),(565,83,'2021-10-01 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,608,0,0,70,0,538,0,0,'93/2017','SOORAJ'),(566,35,'2021-10-01 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,144,0,0,35,0,109,0,0,'93/2017','SOORAJ'),(567,48,'2021-10-01 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,200,0,0,35,0,165,0,0,'93/2017','SOORAJ'),(568,50,'2021-10-01 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,204,0,0,35,0,169,0,0,'93/2017','SOORAJ'),(569,46,'2021-10-01 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,920,0,0,105,0,815,0,0,'93/2017','SOORAJ'),(570,82,'2021-09-24 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,596,0,0,42,0,554,0,0,'06/2018','BIYYUTTI PP'),(571,83,'2021-09-24 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,538,0,0,42,0,496,0,0,'06/2018','BIYYUTTI PP'),(572,36,'2021-09-24 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,86,0,0,84,0,2,0,0,'06/2018','BIYYUTTI PP'),(573,46,'2021-09-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,815,0,0,126,0,689,0,0,'06/2018','BIYYUTTI PP'),(574,48,'2021-09-24 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,165,0,0,42,0,123,0,0,'48/2017','ABDUL HASEEB'),(575,47,'2021-09-24 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,200,0,0,42,0,158,0,0,'48/2017','ABDUL HASEEB'),(576,71,'2021-09-24 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,405,0,0,42,0,363,0,0,'48/2017','ABDUL HASEEB'),(577,46,'2021-09-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,689,0,0,126,0,563,0,0,'48/2017','ABDUL HASEEB'),(578,34,'2021-09-24 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,87,0,0,84,0,3,0,0,'48/2017','ABDUL HASEEB'),(579,22,'2021-10-08 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,100,0,0,56,0,44,0,0,'67/2021','ANEESHA'),(580,33,'2021-10-08 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,304,0,0,28,0,276,0,0,'67/2021','ANEESHA'),(581,83,'2021-11-05 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,496,0,0,42,0,454,0,0,'247/2021','NOUSHAD '),(582,68,'2021-11-05 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,200,0,0,21,0,179,0,0,'247/2021','NOUSHAD '),(583,21,'2021-11-05 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,500,0,0,21,0,479,0,0,'247/2021','NOUSHAD '),(584,46,'2021-11-05 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,563,0,0,21,0,542,0,0,'247/2021','NOUSHAD '),(585,88,'2021-11-06 00:00:00','M88','CLONAZEPAM & ESCITALOPRAM OXALATE TABLETS 5 MG','Edit','Edit stock',0,70,0,0,0,0,200,0,0,'',''),(586,3,'2021-11-06 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Edit','Edit stock',0,84,0,0,0,0,200,0,0,'',''),(587,49,'2021-11-06 00:00:00','M49','CLOZAPINE TABLETS 100MG','Edit','Edit stock',0,18,0,0,0,0,500,0,0,'',''),(588,6,'2021-11-06 00:00:00','M6','ESCITALOPRAM TABLETS 20MG','Edit','Edit stock',0,60,0,0,0,0,200,0,0,'',''),(589,36,'2021-11-06 00:00:00','M36','RISPERIDONE TABLETS 4MG','Edit','Edit stock',0,2,0,0,0,0,200,0,0,'',''),(590,34,'2021-11-06 00:00:00','M34','RISPERIDONE TABLETS 2MG','Edit','Edit stock',0,3,0,0,0,0,300,0,0,'',''),(591,23,'2021-11-06 00:00:00','M23','FLUOXETINE CAPSULES 10MG','Edit','Edit stock',0,95,0,0,0,0,200,0,0,'',''),(592,82,'2021-11-05 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,554,0,0,28,0,526,0,0,'34/2018','SAKHEER'),(593,83,'2021-11-05 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,454,0,0,28,0,426,0,0,'34/2018','SAKHEER'),(594,36,'2021-11-05 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,200,0,0,28,0,172,0,0,'34/2018','SAKHEER'),(595,33,'2021-11-05 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,276,0,0,28,0,248,0,0,'34/2018','SAKHEER'),(596,46,'2021-11-05 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,542,0,0,28,0,514,0,0,'34/2018','SAKHEER'),(597,71,'2021-10-15 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,363,0,0,42,0,321,0,0,'078/2021','MANIKANDAN'),(598,37,'2021-10-15 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Transfer','Sub to OP',0,1485,0,0,84,0,1401,0,0,'078/2021','MANIKANDAN'),(599,36,'2021-10-15 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,172,0,0,28,0,144,0,0,'078/2021','MANIKANDAN'),(600,44,'2021-11-11 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Edit','Edit stock',0,122,0,0,0,0,1000,0,0,'',''),(601,9,'2021-11-11 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Edit','Edit stock',0,144,0,0,0,0,1000,0,0,'',''),(602,10,'2021-11-11 00:00:00','M10','AMISULPRIDE TABLETS 200MG','Edit','Edit stock',0,150,0,0,0,0,1000,0,0,'',''),(603,8,'2021-11-11 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Edit','Edit stock',0,257,0,0,0,0,1000,0,0,'',''),(604,15,'2021-11-11 00:00:00','M15','AMITRIPTYLINE TABLETS 10MG','Edit','Edit stock',0,210,0,0,0,0,1000,0,0,'',''),(605,17,'2021-11-11 00:00:00','M17','AMITRIPTYLINE TABLETS 25MG','Edit','Edit stock',0,100,0,0,0,0,1000,0,0,'',''),(606,19,'2021-11-11 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Edit','Edit stock',0,100,0,0,0,0,1000,0,0,'',''),(607,59,'2021-11-11 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Edit','Edit stock',0,426,0,0,0,0,1000,0,0,'',''),(608,37,'2021-10-15 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Transfer','Sub to OP',0,1401,0,0,56,0,1345,0,0,'112/2018','FOUSIYA'),(609,82,'2021-10-29 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,526,0,0,42,0,484,0,0,'8/2014','DHANISHMA'),(610,50,'2021-10-29 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,169,0,0,21,0,148,0,0,'231/2021','MUHAMMAD IQBAL'),(611,48,'2021-10-29 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,123,0,0,21,0,102,0,0,'231/2021','MUHAMMAD IQBAL'),(612,92,'2021-10-29 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,8,0,0,1,0,7,0,0,'231/2021','MUHAMMAD IQBAL'),(613,11,'2021-10-29 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,9,0,0,1,0,8,0,0,'231/2021','MUHAMMAD IQBAL'),(614,46,'2021-10-29 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,514,0,0,21,0,493,0,0,'231/2021','MUHAMMAD IQBAL'),(615,92,'2021-10-29 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,7,0,0,3,0,4,0,0,'157/2019','FATHIMMA'),(616,46,'2021-10-29 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,493,0,0,42,0,451,0,0,'157/2019','FATHIMMA'),(617,47,'2021-10-29 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,158,0,0,21,0,137,0,0,'157/2019','FATHIMMA'),(618,36,'2021-11-11 00:00:00','M36','RISPERIDONE TABLETS 4MG','Edit','Edit stock',0,144,0,0,0,0,1000,0,0,'',''),(619,46,'2021-11-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',0,451,0,0,0,0,1000,0,0,'',''),(620,70,'2021-11-11 00:00:00','M70','QUETIAPINE TABLETS 25MG','Edit','Edit stock',0,95,0,0,0,0,1000,0,0,'',''),(621,71,'2021-11-11 00:00:00','M71','QUETIAPINE TABLETS 50MG','Edit','Edit stock',0,321,0,0,0,0,1000,0,0,'',''),(622,72,'2021-11-11 00:00:00','M72','QUETIAPINE TABLETS 100MG','Edit','Edit stock',0,464,0,0,0,0,1000,0,0,'',''),(623,62,'2021-11-11 00:00:00','M62','LAMOTRIGINE TABLETS 25MG','Edit','Edit stock',0,66,0,0,0,0,1000,0,0,'',''),(624,64,'2021-11-11 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Edit','Edit stock',0,110,0,0,0,0,1000,0,0,'',''),(625,47,'2021-11-11 00:00:00','M47','CLOZAPINE TABLETS 25MG','Edit','Edit stock',0,137,0,0,0,0,1000,0,0,'',''),(626,44,'2021-10-01 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Transfer','Sub to OP',0,1000,0,0,363,0,637,0,0,'137/2020','SADHASHIVAN'),(627,36,'2021-10-01 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1000,0,0,168,0,832,0,0,'137/2020','SADHASHIVAN'),(628,46,'2021-10-01 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1000,0,0,531,0,469,0,0,'137/2020','SADHASHIVAN'),(629,72,'2021-10-01 00:00:00','M72','QUETIAPINE TABLETS 100MG','Transfer','Sub to OP',0,1000,0,0,168,0,832,0,0,'137/2020','SADHASHIVAN'),(630,71,'2021-10-01 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,1000,0,0,168,0,832,0,0,'137/2020','SADHASHIVAN'),(631,62,'2021-10-01 00:00:00','M62','LAMOTRIGINE TABLETS 25MG','Transfer','Sub to OP',0,1000,0,0,168,0,832,0,0,'137/2020','SADHASHIVAN'),(632,64,'2021-10-01 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Transfer','Sub to OP',0,1000,0,0,168,0,832,0,0,'137/2020','SADHASHIVAN'),(633,47,'2021-10-01 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1000,0,0,168,0,832,0,0,'137/2020','SADHASHIVAN'),(634,58,'2021-11-17 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Edit','Edit stock',0,200,0,0,0,0,1000,0,0,'',''),(635,57,'2021-11-17 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Edit','Edit stock',0,144,0,0,0,0,1000,0,0,'',''),(636,86,'2021-11-17 00:00:00','M86','CLOBAZAM TABLETS 10 MG','Edit','Edit stock',0,192,0,0,0,0,1000,0,0,'',''),(637,87,'2021-11-17 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Edit','Edit stock',0,516,0,0,0,0,1000,0,0,'',''),(638,56,'2021-11-17 00:00:00','M56','CLOMIPRAMINE TABLETS 25MG','Edit','Edit stock',0,100,0,0,0,0,1000,0,0,'',''),(639,88,'2021-11-17 00:00:00','M88','CLONAZEPAM & ESCITALOPRAM OXALATE TABLETS 5 MG','Edit','Edit stock',0,200,0,0,0,0,1000,0,0,'',''),(640,3,'2021-11-17 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Edit','Edit stock',0,200,0,0,0,0,1000,0,0,'',''),(641,89,'2021-11-17 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Edit','Edit stock',0,110,0,0,0,0,1000,0,0,'',''),(642,49,'2021-11-17 00:00:00','M49','CLOZAPINE TABLETS 100MG','Edit','Edit stock',0,500,0,0,0,0,1000,0,0,'',''),(643,50,'2021-11-17 00:00:00','M50','CLOZAPINE TABLETS 200MG','Edit','Edit stock',0,148,0,0,0,0,1000,0,0,'',''),(644,47,'2021-11-17 00:00:00','M47','CLOZAPINE TABLETS 25MG','Edit','Edit stock',0,832,0,0,0,0,1000,0,0,'',''),(645,48,'2021-11-17 00:00:00','M48','CLOZAPINE TABLETS 50MG','Edit','Edit stock',0,102,0,0,0,0,1000,0,0,'',''),(646,94,'2021-11-17 00:00:00','M94','DIVALPROEX SUSTAINED RELEASE TABLETS IP 250','Edit','Edit stock',0,0,0,0,0,0,1000,0,0,'',''),(647,52,'2021-11-17 00:00:00','M52','DONEPEZIL HCL TABLETS 10MG','Edit','Edit stock',0,30,0,0,0,0,1000,0,0,'',''),(648,51,'2021-11-17 00:00:00','M51','DONEPEZIL HCL TABLETS 5MG','Edit','Edit stock',0,50,0,0,0,0,1000,0,0,'',''),(649,53,'2021-11-17 00:00:00','M53','DOSULEPIN TABLETS 25MG','Edit','Edit stock',0,16,0,0,0,0,1000,0,0,'',''),(650,55,'2021-11-17 00:00:00','M55','DOSULEPIN TABLETS BP 50MG','Edit','Edit stock',0,100,0,0,0,0,1000,0,0,'',''),(651,54,'2021-11-17 00:00:00','M54','DOSULEPIN TABLETS BP 75MG','Edit','Edit stock',0,90,0,0,0,0,1000,0,0,'',''),(652,5,'2021-11-17 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Edit','Edit stock',0,116,0,0,0,0,1000,0,0,'',''),(653,6,'2021-11-17 00:00:00','M6','ESCITALOPRAM TABLETS 20MG','Edit','Edit stock',0,200,0,0,0,0,1000,0,0,'',''),(654,4,'2021-11-17 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Edit','Edit stock',0,208,0,0,0,0,1000,0,0,'',''),(655,23,'2021-11-17 00:00:00','M23','FLUOXETINE CAPSULES 10MG','Edit','Edit stock',0,200,0,0,0,0,1000,0,0,'',''),(656,12,'2021-11-17 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Edit','Edit stock',0,8,0,0,0,0,1000,0,0,'',''),(657,21,'2021-11-17 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Edit','Edit stock',0,479,0,0,0,0,1000,0,0,'',''),(658,20,'2021-11-17 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Edit','Edit stock',0,590,0,0,0,0,1000,0,0,'',''),(659,22,'2021-11-17 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Edit','Edit stock',0,44,0,0,0,0,1000,0,0,'',''),(660,93,'2021-11-17 00:00:00','M93','FLUPHENAZINE DECANOATE INJECTION IP 1ML','Edit','Edit stock',0,17,0,0,0,0,1000,0,0,'',''),(661,14,'2021-11-17 00:00:00','M14','FLUVOXAMINE TABLETS 100MG','Edit','Edit stock',0,179,0,0,0,0,1000,0,0,'',''),(662,24,'2021-11-17 00:00:00','M24','GABAPENTIN TABLETS 100MG','Edit','Edit stock',0,163,0,0,0,0,1000,0,0,'',''),(663,13,'2021-11-17 00:00:00','M13','GLYCOPYRROLATE TABLETS 2MG','Edit','Edit stock',0,128,0,0,0,0,1000,0,0,'',''),(664,26,'2021-11-17 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Edit','Edit stock',0,313,0,0,0,0,1000,0,0,'',''),(665,25,'2021-11-17 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Edit','Edit stock',0,77,0,0,0,0,1000,0,0,'',''),(666,63,'2021-11-17 00:00:00','M63','LACOSAMIDE TABLETS 100MG','Edit','Edit stock',0,113,0,0,0,0,1000,0,0,'',''),(667,60,'2021-11-17 00:00:00','M60','LAMOTRIGINE DISPERSIBLE TABLETS 100MG','Edit','Edit stock',0,105,0,0,0,0,1000,0,0,'',''),(668,61,'2021-11-17 00:00:00','M61','LAMOTRIGINE DISPERSIBLE TABLETS 50MG','Edit','Edit stock',0,189,0,0,0,0,1000,0,0,'',''),(669,62,'2021-11-17 00:00:00','M62','LAMOTRIGINE TABLETS 25MG','Edit','Edit stock',0,832,0,0,0,0,1000,0,0,'',''),(670,85,'2021-11-17 00:00:00','M85','LEVETIRACETAM TABLETS 250 MG','Edit','Edit stock',0,260,0,0,0,0,1000,0,0,'',''),(671,84,'2021-11-17 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Edit','Edit stock',0,88,0,0,0,0,1000,0,0,'',''),(672,29,'2021-11-17 00:00:00','M29','LITHIUM CARBONATE 300MG','Edit','Edit stock',0,596,0,0,0,0,1000,0,0,'',''),(673,28,'2021-11-17 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Edit','Edit stock',0,536,0,0,0,0,1000,0,0,'',''),(674,90,'2021-11-17 00:00:00','M90','LORAZEPAM TABLETS 1 MG','Edit','Edit stock',0,151,0,0,0,0,1000,0,0,'',''),(675,91,'2021-11-17 00:00:00','M91','LORAZEPAM TABLETS 2MG ','Edit','Edit stock',0,251,0,0,0,0,1000,0,0,'',''),(676,27,'2021-11-17 00:00:00','M27','LURASIDONE HCL TABLETS 40MG','Edit','Edit stock',0,141,0,0,0,0,1000,0,0,'',''),(677,74,'2021-11-17 00:00:00','M74','MEMANTINE HCL & DONEPEZIL HCL TABLETS ','Edit','Edit stock',0,170,0,0,0,0,1000,0,0,'',''),(678,7,'2021-11-17 00:00:00','M7','MIRABEGRON EXTENDED FELEASE TABLETS 50MG','Edit','Edit stock',0,0,0,0,0,0,1000,0,0,'',''),(679,65,'2021-11-17 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Edit','Edit stock',0,66,0,0,0,0,1000,0,0,'',''),(680,64,'2021-11-17 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Edit','Edit stock',0,832,0,0,0,0,1000,0,0,'',''),(681,66,'2021-11-17 00:00:00','M66','NITRAZEPAM TABLETS 10MG','Edit','Edit stock',0,100,0,0,0,0,1000,0,0,'',''),(682,68,'2021-11-17 00:00:00','M68','OLANZAPINE TABLETS 10MG','Edit','Edit stock',0,179,0,0,0,0,1000,0,0,'',''),(683,83,'2021-11-05 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,426,0,0,28,0,398,0,0,'38/2017','UNNEENKUTTY'),(684,26,'2021-11-05 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,1000,0,0,28,0,972,0,0,'38/2017','UNNEENKUTTY'),(685,49,'2021-11-05 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1000,0,0,14,0,986,0,0,'38/2017','UNNEENKUTTY'),(686,48,'2021-11-05 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1000,0,0,14,0,986,0,0,'38/2017','UNNEENKUTTY'),(687,47,'2021-11-05 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1000,0,0,14,0,986,0,0,'38/2017','UNNEENKUTTY'),(688,35,'2021-10-22 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,109,0,0,56,0,53,0,0,'134/2020','MADHU'),(689,46,'2021-10-22 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,469,0,0,84,0,385,0,0,'134/2020','MADHU'),(690,83,'2021-10-22 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,398,0,0,56,0,342,0,0,'134/2020','MADHU'),(691,70,'2021-10-22 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,1000,0,0,28,0,972,0,0,'134/2020','MADHU'),(692,71,'2021-10-22 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,832,0,0,28,0,804,0,0,'134/2020','MADHU'),(693,82,'2021-11-05 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,484,0,0,28,0,456,0,0,'58/2021','SUMAYYA'),(694,83,'2021-11-05 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,342,0,0,14,0,328,0,0,'58/2021','SUMAYYA'),(695,48,'2021-11-05 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,986,0,0,14,0,972,0,0,'58/2021','SUMAYYA'),(696,50,'2021-11-05 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,1000,0,0,14,0,986,0,0,'58/2021','SUMAYYA'),(697,46,'2021-11-05 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,385,0,0,14,0,371,0,0,'58/2021','SUMAYYA'),(698,65,'2021-10-08 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,1000,0,0,42,0,958,0,0,'59/2021','KUNJUMUHAMMAD'),(699,19,'2021-10-08 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,1000,0,0,21,0,979,0,0,'59/2021','KUNJUMUHAMMAD'),(700,20,'2021-10-08 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,1000,0,0,42,0,958,0,0,'59/2021','KUNJUMUHAMMAD'),(701,28,'2021-10-22 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,1000,0,0,42,0,958,0,0,'04/2018','ABDUL SAMAD'),(702,46,'2021-10-22 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,371,0,0,28,0,343,0,0,'04/2018','ABDUL SAMAD'),(703,39,'2021-10-22 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Transfer','Sub to OP',0,284,0,0,28,0,256,0,0,'04/2018','ABDUL SAMAD'),(704,50,'2021-09-24 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,986,0,0,56,0,930,0,0,'9/2018','RAFEENA'),(705,49,'2021-09-24 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,986,0,0,56,0,930,0,0,'9/2018','RAFEENA'),(706,34,'2021-09-24 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,300,0,0,112,0,188,0,0,'9/2018','RAFEENA'),(707,46,'2021-09-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,343,0,0,112,0,231,0,0,'9/2018','RAFEENA'),(708,11,'2021-09-24 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,8,0,0,2,0,6,0,0,'9/2018','RAFEENA'),(709,46,'2021-10-01 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,231,0,0,98,0,133,0,0,'211/2019','RAJAN'),(710,45,'2021-10-01 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,443,0,0,98,0,345,0,0,'211/2019','RAJAN'),(711,87,'2021-10-01 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Transfer','Sub to OP',0,1000,0,0,98,0,902,0,0,'211/2019','RAJAN'),(712,81,'2021-10-01 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,470,0,0,98,0,372,0,0,'211/2019','RAJAN'),(713,36,'2021-10-01 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,832,0,0,49,0,783,0,0,'211/2019','RAJAN'),(714,4,'2021-10-01 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,1000,0,0,49,0,951,0,0,'211/2019','RAJAN'),(715,68,'2021-09-24 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1000,0,0,56,0,944,0,0,'75/2019','UNNIKRISHNAN'),(716,69,'2021-09-24 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,144,0,0,56,0,88,0,0,'75/2019','UNNIKRISHNAN'),(717,46,'2021-09-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,133,0,0,112,0,21,0,0,'75/2019','UNNIKRISHNAN'),(718,83,'2021-09-24 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,328,0,0,56,0,272,0,0,'75/2019','UNNIKRISHNAN'),(719,83,'2021-11-12 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,272,0,0,28,0,244,0,0,'251/2021','ANOOP NARAYANAN'),(720,48,'2021-11-12 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,972,0,0,14,0,958,0,0,'251/2021','ANOOP NARAYANAN'),(721,50,'2021-11-12 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,930,0,0,14,0,916,0,0,'251/2021','ANOOP NARAYANAN'),(722,10,'2021-11-12 00:00:00','M10','AMISULPRIDE TABLETS 200MG','Transfer','Sub to OP',0,1000,0,0,42,0,958,0,0,'251/2021','ANOOP NARAYANAN'),(723,36,'2021-11-12 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,783,0,0,14,0,769,0,0,'251/2021','ANOOP NARAYANAN'),(724,30,'2021-11-12 00:00:00','M30','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 4MG','Transfer','Sub to OP',0,86,0,0,28,0,58,0,0,'251/2021','ANOOP NARAYANAN'),(725,37,'2021-10-08 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Transfer','Sub to OP',0,1345,0,0,84,0,1261,0,0,'104/2018','HASEENA'),(726,81,'2021-10-08 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,372,0,0,56,0,316,0,0,'104/2018','HASEENA'),(727,81,'2021-11-12 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,316,0,0,28,0,288,0,0,'250/2021','HASEENA '),(728,12,'2021-11-12 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,1000,0,0,14,0,986,0,0,'250/2021','HASEENA '),(729,69,'2021-11-12 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,88,0,0,14,0,74,0,0,'250/2021','HASEENA '),(730,67,'2021-11-12 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,144,0,0,14,0,130,0,0,'250/2021','HASEENA '),(731,33,'2021-11-26 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,248,0,0,28,0,220,0,0,'0112/2017','ZEHARABI'),(732,83,'2021-11-12 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,244,0,0,112,0,132,0,0,'059/2021','YASHODHA'),(733,70,'2021-11-12 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,972,0,0,56,0,916,0,0,'059/2021','YASHODHA'),(734,35,'2021-12-08 00:00:00','M35','RISPERIDONE TABLETS 3MG','Edit','Edit stock',0,53,0,0,0,0,1000,0,0,'',''),(735,67,'2021-12-08 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Edit','Edit stock',0,130,0,0,0,0,1000,0,0,'',''),(736,69,'2021-12-08 00:00:00','M69','OLANZAPINE TABLETS 5MG','Edit','Edit stock',0,74,0,0,0,0,1000,0,0,'',''),(737,77,'2021-12-08 00:00:00','M77','PHENOBARBITONE TABLETS 30MG','Edit','Edit stock',0,190,0,0,0,0,1000,0,0,'',''),(738,82,'2021-12-08 00:00:00','M82','SV 200MG','Edit','Edit stock',0,456,0,0,0,0,1000,0,0,'',''),(739,81,'2021-12-08 00:00:00','M81','SV 300MG','Edit','Edit stock',0,288,0,0,0,0,1000,0,0,'',''),(740,83,'2021-12-08 00:00:00','M83','SV 500MG','Edit','Edit stock',0,132,0,0,0,0,1000,0,0,'',''),(741,33,'2021-12-08 00:00:00','M33','RISPERIDONE TABLETS 1MG','Edit','Edit stock',0,220,0,0,0,0,1000,0,0,'',''),(742,34,'2021-12-08 00:00:00','M34','RISPERIDONE TABLETS 2MG','Edit','Edit stock',0,188,0,0,0,0,1000,0,0,'',''),(743,46,'2021-12-08 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',0,21,0,0,0,0,1000,0,0,'',''),(744,73,'2021-12-08 00:00:00','M73','QUETIAPINE TABLETS 200MG','Edit','Edit stock',0,160,0,0,0,0,1000,0,0,'',''),(745,36,'2021-12-08 00:00:00','M36','RISPERIDONE TABLETS 4MG','Edit','Edit stock',0,769,0,0,0,0,1000,0,0,'',''),(746,83,'2021-11-26 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,1000,0,0,112,0,888,0,0,'77/2021','VIJAYAKUMARI'),(747,35,'2021-11-26 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,1000,0,0,112,0,888,0,0,'77/2021','VIJAYAKUMARI'),(748,33,'2021-11-26 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1000,0,0,56,0,944,0,0,'77/2021','VIJAYAKUMARI'),(749,47,'2021-11-26 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,986,0,0,56,0,930,0,0,'77/2021','VIJAYAKUMARI'),(750,46,'2021-11-26 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1000,0,0,168,0,832,0,0,'77/2021','VIJAYAKUMARI'),(751,34,'2021-10-22 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1000,0,0,56,0,944,0,0,'106/2017','VIJAYALAKSHMI'),(752,46,'2021-10-22 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,832,0,0,56,0,776,0,0,'106/2017','VIJAYALAKSHMI'),(753,83,'2021-11-19 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,888,0,0,42,0,846,0,0,'75/2019','UNNIKRISHNAN'),(754,68,'2021-11-19 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,944,0,0,42,0,902,0,0,'75/2019','UNNIKRISHNAN'),(755,69,'2021-11-19 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1000,0,0,42,0,958,0,0,'75/2019','UNNIKRISHNAN'),(756,46,'2021-11-19 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,776,0,0,126,0,650,0,0,'75/2019','UNNIKRISHNAN'),(757,81,'2021-11-26 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,1000,0,0,28,0,972,0,0,'232/2021','USMAN'),(758,83,'2021-11-26 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,846,0,0,28,0,818,0,0,'232/2021','USMAN'),(759,46,'2021-11-26 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,650,0,0,84,0,566,0,0,'232/2021','USMAN'),(760,34,'2021-11-26 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,944,0,0,28,0,916,0,0,'232/2021','USMAN'),(761,76,'2021-11-26 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,88,0,0,28,0,60,0,0,'232/2021','USMAN'),(762,68,'2021-11-26 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,902,0,0,28,0,874,0,0,'232/2021','USMAN'),(763,48,'2021-11-05 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,958,0,0,35,0,923,0,0,'93/2017','SOORAJ'),(764,50,'2021-11-05 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,916,0,0,35,0,881,0,0,'93/2017','SOORAJ'),(765,35,'2021-11-05 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,888,0,0,35,0,853,0,0,'93/2017','SOORAJ'),(766,83,'2021-11-05 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,818,0,0,70,0,748,0,0,'93/2017','SOORAJ'),(767,82,'2021-11-05 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,1000,0,0,35,0,965,0,0,'93/2017','SOORAJ'),(768,46,'2021-11-05 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,566,0,0,140,0,426,0,0,'93/2017','SOORAJ'),(769,45,'2021-10-15 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,345,0,0,112,0,233,0,0,'45/2017','KORAN'),(770,33,'2021-10-15 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,944,0,0,56,0,888,0,0,'45/2017','KORAN'),(771,47,'2021-10-15 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,930,0,0,56,0,874,0,0,'45/2017','KORAN'),(772,48,'2021-10-15 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,923,0,0,56,0,867,0,0,'45/2017','KORAN'),(773,82,'2021-12-03 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,965,0,0,14,0,951,0,0,'288/2021','SABIRA'),(774,35,'2021-12-03 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,853,0,0,7,0,846,0,0,'288/2021','SABIRA'),(775,46,'2021-12-03 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,426,0,0,7,0,419,0,0,'288/2021','SABIRA'),(776,11,'2021-12-03 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,6,0,0,1,0,5,0,0,'231/2021','MUHAMMAD IQBAL'),(777,49,'2021-12-03 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,930,0,0,7,0,923,0,0,'231/2021','MUHAMMAD IQBAL'),(778,92,'2021-12-03 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,4,0,0,1,0,3,0,0,'231/2021','MUHAMMAD IQBAL'),(779,46,'2021-12-03 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,419,0,0,7,0,412,0,0,'231/2021','MUHAMMAD IQBAL'),(780,10,'2021-11-26 00:00:00','M10','AMISULPRIDE TABLETS 200MG','Transfer','Sub to OP',0,958,0,0,42,0,916,0,0,'251/2021','ANOOP NARAYANAN'),(781,83,'2021-11-26 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,748,0,0,42,0,706,0,0,'251/2021','ANOOP NARAYANAN'),(782,49,'2021-11-26 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,923,0,0,42,0,881,0,0,'251/2021','ANOOP NARAYANAN'),(783,36,'2021-11-26 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1000,0,0,28,0,972,0,0,'251/2021','ANOOP NARAYANAN'),(784,37,'2021-11-26 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Transfer','Sub to OP',0,1261,0,0,42,0,1219,0,0,'251/2021','ANOOP NARAYANAN'),(785,91,'2021-11-26 00:00:00','M91','LORAZEPAM TABLETS 2MG ','Transfer','Sub to OP',0,1000,0,0,42,0,958,0,0,'251/2021','ANOOP NARAYANAN'),(786,82,'2021-11-12 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,951,0,0,112,0,839,0,0,'205/2019','SUBAIDA'),(787,27,'2021-11-12 00:00:00','M27','LURASIDONE HCL TABLETS 40MG','Transfer','Sub to OP',0,1000,0,0,28,0,972,0,0,'205/2019','SUBAIDA'),(788,83,'2021-11-19 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,706,0,0,56,0,650,0,0,'38/2017','UNNEENKUTTY'),(789,26,'2021-11-19 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,972,0,0,42,0,930,0,0,'38/2017','UNNEENKUTTY'),(790,49,'2021-11-19 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,881,0,0,28,0,853,0,0,'38/2017','UNNEENKUTTY'),(791,47,'2021-11-19 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,874,0,0,28,0,846,0,0,'38/2017','UNNEENKUTTY'),(792,48,'2021-11-19 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,867,0,0,28,0,839,0,0,'38/2017','UNNEENKUTTY'),(793,46,'2021-11-19 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,412,0,0,28,0,384,0,0,'38/2017','UNNEENKUTTY'),(794,47,'2021-11-26 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,846,0,0,63,0,783,0,0,'138/2019','UMMAR'),(795,34,'2021-11-26 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,916,0,0,42,0,874,0,0,'138/2019','UMMAR'),(796,36,'2021-11-26 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,972,0,0,42,0,930,0,0,'138/2019','UMMAR'),(797,33,'2021-11-26 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,888,0,0,42,0,846,0,0,'138/2019','UMMAR'),(798,79,'2021-12-16 00:00:00','M79','PHENOBARBITONE TABLETS 60MG','Edit','Edit stock',0,60,0,0,0,0,1000,0,0,'',''),(799,11,'2021-12-10 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,5,0,0,1,0,4,0,0,'231/2021','MUHAMMAD IQBAL'),(800,49,'2021-12-10 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,853,0,0,14,0,839,0,0,'231/2021','MUHAMMAD IQBAL'),(801,92,'2021-12-10 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,3,0,0,1,0,2,0,0,'231/2021','MUHAMMAD IQBAL'),(802,46,'2021-12-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,384,0,0,14,0,370,0,0,'231/2021','MUHAMMAD IQBAL'),(803,46,'2021-11-26 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,370,0,0,28,0,342,0,0,'144/2019','JAMSHI'),(804,92,'2021-11-26 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2,0,0,1,0,1,0,0,'144/2019','JAMSHI'),(805,81,'2021-11-26 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,972,0,0,56,0,916,0,0,'250/2021','HASEENA '),(806,12,'2021-11-26 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,986,0,0,28,0,958,0,0,'250/2021','HASEENA '),(807,67,'2021-11-26 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,1000,0,0,28,0,972,0,0,'250/2021','HASEENA '),(808,69,'2021-11-26 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,958,0,0,28,0,930,0,0,'250/2021','HASEENA '),(809,5,'2021-12-03 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,1000,0,0,21,0,979,0,0,'202/2021','SHAJI'),(810,4,'2021-12-03 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,951,0,0,21,0,930,0,0,'202/2021','SHAJI'),(811,11,'2021-12-10 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,4,0,0,1,0,3,0,0,'288/2021','SABIRA'),(812,36,'2021-12-10 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,930,0,0,14,0,916,0,0,'288/2021','SABIRA'),(813,46,'2021-12-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,342,0,0,28,0,314,0,0,'288/2021','SABIRA'),(814,9,'2021-10-01 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,1000,0,0,84,0,916,0,0,'63/2018','BABY'),(815,8,'2021-10-01 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Transfer','Sub to OP',0,1000,0,0,84,0,916,0,0,'63/2018','BABY'),(816,83,'2021-12-17 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,650,0,0,14,0,636,0,0,'15/2021','KADHEEJA'),(817,82,'2021-12-17 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,839,0,0,7,0,832,0,0,'15/2021','KADHEEJA'),(818,69,'2021-12-17 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,930,0,0,7,0,923,0,0,'15/2021','KADHEEJA'),(819,12,'2021-12-17 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,958,0,0,7,0,951,0,0,'15/2021','KADHEEJA'),(820,70,'2021-12-31 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,916,0,0,7,0,909,0,0,'289/2021','DILEEP VM'),(821,71,'2021-12-31 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,804,0,0,7,0,797,0,0,'289/2021','DILEEP VM'),(822,12,'2021-12-10 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,951,0,0,28,0,923,0,0,'112/2017','SAIFUNEESA'),(823,34,'2021-12-10 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,874,0,0,28,0,846,0,0,'112/2017','SAIFUNEESA'),(824,46,'2021-12-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,314,0,0,28,0,286,0,0,'112/2017','SAIFUNEESA'),(825,9,'2021-12-10 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,916,0,0,28,0,888,0,0,'112/2017','SAIFUNEESA'),(826,21,'2021-12-17 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,1000,0,0,42,0,958,0,0,'161/2019','ASHRAF CP'),(827,44,'2021-12-17 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Transfer','Sub to OP',0,637,0,0,42,0,595,0,0,'161/2019','ASHRAF CP'),(828,64,'2021-12-17 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Transfer','Sub to OP',0,1000,0,0,21,0,979,0,0,'161/2019','ASHRAF CP'),(829,73,'2021-11-26 00:00:00','M73','QUETIAPINE TABLETS 200MG','Transfer','Sub to OP',0,1000,0,0,42,0,958,0,0,'182/2021','MOHAMMAD BASHEER'),(830,46,'2021-11-26 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,286,0,0,126,0,160,0,0,'182/2021','MOHAMMAD BASHEER'),(831,83,'2021-11-26 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,636,0,0,84,0,552,0,0,'182/2021','MOHAMMAD BASHEER'),(832,25,'2021-11-26 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,1000,0,0,42,0,958,0,0,'182/2021','MOHAMMAD BASHEER'),(833,26,'2021-11-26 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,930,0,0,42,0,888,0,0,'182/2021','MOHAMMAD BASHEER'),(834,48,'2021-11-26 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,839,0,0,42,0,797,0,0,'182/2021','MOHAMMAD BASHEER'),(835,92,'2021-12-31 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,1,0,0,1,0,0,0,0,'291/2021','AMINA'),(836,36,'2021-12-17 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,916,0,0,42,0,874,0,0,'158/2020','SUBRAHMANYAN'),(837,48,'2021-12-17 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,797,0,0,42,0,755,0,0,'158/2020','SUBRAHMANYAN'),(838,49,'2021-12-17 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,839,0,0,21,0,818,0,0,'158/2020','SUBRAHMANYAN'),(839,89,'2021-12-17 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,1000,0,0,11,0,989,0,0,'158/2020','SUBRAHMANYAN'),(840,29,'2021-12-17 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,1000,0,0,21,0,979,0,0,'158/2020','SUBRAHMANYAN'),(841,83,'2021-12-17 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,552,0,0,42,0,510,0,0,'158/2020','SUBRAHMANYAN'),(842,46,'2021-12-17 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,160,0,0,42,0,118,0,0,'158/2020','SUBRAHMANYAN'),(843,83,'2021-12-24 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,510,0,0,28,0,482,0,0,'38/2017','UNNEENKUTTY'),(844,82,'2021-12-24 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,832,0,0,14,0,818,0,0,'38/2017','UNNEENKUTTY'),(845,26,'2021-12-24 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,888,0,0,14,0,874,0,0,'38/2017','UNNEENKUTTY'),(846,25,'2021-12-24 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,958,0,0,21,0,937,0,0,'38/2017','UNNEENKUTTY'),(847,46,'2021-12-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,118,0,0,42,0,76,0,0,'38/2017','UNNEENKUTTY'),(848,49,'2021-12-24 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,818,0,0,14,0,804,0,0,'38/2017','UNNEENKUTTY'),(849,48,'2021-12-24 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,755,0,0,14,0,741,0,0,'38/2017','UNNEENKUTTY'),(850,47,'2021-12-24 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,783,0,0,28,0,755,0,0,'38/2017','UNNEENKUTTY'),(851,50,'2021-12-24 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,881,0,0,14,0,867,0,0,'01/2018','ABDUL NAZAR'),(852,47,'2021-12-24 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,755,0,0,14,0,741,0,0,'01/2018','ABDUL NAZAR'),(853,83,'2021-12-24 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,482,0,0,28,0,454,0,0,'01/2018','ABDUL NAZAR'),(854,67,'2021-12-24 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,972,0,0,14,0,958,0,0,'01/2018','ABDUL NAZAR'),(855,68,'2021-12-24 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,874,0,0,14,0,860,0,0,'01/2018','ABDUL NAZAR'),(856,12,'2021-12-24 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,923,0,0,14,0,909,0,0,'01/2018','ABDUL NAZAR'),(857,43,'2022-01-06 00:00:00','M43','VENLAFAXINE EXTENDED RELEASE CAPSULES 75MG','Edit','Edit stock',0,107,0,0,0,0,1000,0,0,'',''),(858,43,'2021-10-22 00:00:00','M43','VENLAFAXINE EXTENDED RELEASE CAPSULES 75MG','Transfer','Sub to OP',0,1000,0,0,168,0,832,0,0,'0130/2017','SHANDHA'),(859,65,'2021-10-22 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,958,0,0,84,0,874,0,0,'0130/2017','SHANDHA'),(860,70,'2021-10-22 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,909,0,0,84,0,825,0,0,'0130/2017','SHANDHA'),(861,82,'2021-10-22 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,818,0,0,168,0,650,0,0,'0130/2017','SHANDHA'),(862,46,'2022-01-06 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',0,76,0,0,0,0,10000,0,0,'',''),(863,83,'2021-12-10 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,454,0,0,84,0,370,0,0,'93/2017','SOORAJ'),(864,82,'2021-12-10 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,650,0,0,42,0,608,0,0,'93/2017','SOORAJ'),(865,34,'2021-12-10 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,846,0,0,42,0,804,0,0,'93/2017','SOORAJ'),(866,50,'2021-12-10 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,867,0,0,42,0,825,0,0,'93/2017','SOORAJ'),(867,48,'2021-12-10 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,741,0,0,63,0,678,0,0,'93/2017','SOORAJ'),(868,46,'2021-12-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,10000,0,0,168,0,9832,0,0,'93/2017','SOORAJ'),(869,76,'2022-01-06 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Edit','Edit stock',0,60,0,0,0,0,1000,0,0,'',''),(870,83,'2021-12-24 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,370,0,0,84,0,286,0,0,'135/2018','SOUDHA'),(871,82,'2021-12-24 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,608,0,0,84,0,524,0,0,'135/2018','SOUDHA'),(872,84,'2021-12-24 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,1000,0,0,168,0,832,0,0,'135/2018','SOUDHA'),(873,69,'2021-12-24 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,923,0,0,84,0,839,0,0,'135/2018','SOUDHA'),(874,67,'2021-12-24 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,958,0,0,84,0,874,0,0,'135/2018','SOUDHA'),(875,76,'2021-12-24 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,1000,0,0,168,0,832,0,0,'135/2018','SOUDHA'),(876,46,'2021-12-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,9832,0,0,168,0,9664,0,0,'135/2018','SOUDHA'),(877,82,'2021-12-10 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,524,0,0,168,0,356,0,0,'205/2019','SUBAIDA'),(878,27,'2021-12-10 00:00:00','M27','LURASIDONE HCL TABLETS 40MG','Transfer','Sub to OP',0,972,0,0,42,0,930,0,0,'205/2019','SUBAIDA'),(879,82,'2021-12-31 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,356,0,0,21,0,335,0,0,'288/2021','SABIRA'),(880,83,'2021-12-31 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,286,0,0,21,0,265,0,0,'288/2021','SABIRA'),(881,36,'2021-12-31 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,874,0,0,21,0,853,0,0,'288/2021','SABIRA'),(882,46,'2021-12-31 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,9664,0,0,63,0,9601,0,0,'288/2021','SABIRA'),(883,5,'2021-12-31 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,979,0,0,14,0,965,0,0,'290/2021','SHAHUL HAMEED'),(884,4,'2021-12-31 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,930,0,0,14,0,916,0,0,'290/2021','SHAHUL HAMEED'),(885,21,'2021-12-31 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,958,0,0,14,0,944,0,0,'290/2021','SHAHUL HAMEED'),(886,69,'2021-12-31 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,839,0,0,14,0,825,0,0,'290/2021','SHAHUL HAMEED'),(887,68,'2021-12-31 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,860,0,0,14,0,846,0,0,'290/2021','SHAHUL HAMEED'),(888,35,'2021-12-31 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,846,0,0,14,0,832,0,0,'290/2021','SHAHUL HAMEED'),(889,65,'2021-12-17 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,874,0,0,56,0,818,0,0,'249/2021','SUDHAKARAN'),(890,70,'2021-12-17 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,825,0,0,28,0,797,0,0,'249/2021','SUDHAKARAN'),(891,59,'2021-12-31 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Transfer','Sub to OP',0,1000,0,0,28,0,972,0,0,'292/2021','ABDUL NAZAR'),(892,70,'2021-12-31 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,797,0,0,7,0,790,0,0,'292/2021','ABDUL NAZAR'),(893,3,'2021-12-31 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,1000,0,0,7,0,993,0,0,'292/2021','ABDUL NAZAR'),(894,68,'2021-12-31 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,846,0,0,14,0,832,0,0,'292/2021','ABDUL NAZAR'),(895,33,'2021-12-24 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,846,0,0,56,0,790,0,0,'0112/2017','ZEHARABI'),(896,4,'2022-01-07 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,916,0,0,21,0,895,0,0,'03/2022','SUBAIDHA'),(897,24,'2022-01-07 00:00:00','M24','GABAPENTIN TABLETS 100MG','Transfer','Sub to OP',0,1000,0,0,28,0,972,0,0,'89/2018','MUHAMMAD'),(898,58,'2022-01-07 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Transfer','Sub to OP',0,1000,0,0,56,0,944,0,0,'89/2018','MUHAMMAD'),(899,72,'2022-01-07 00:00:00','M72','QUETIAPINE TABLETS 100MG','Transfer','Sub to OP',0,832,0,0,28,0,804,0,0,'89/2018','MUHAMMAD'),(900,34,'2022-01-07 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,804,0,0,7,0,797,0,0,'02/2022','GIRIJA'),(901,46,'2022-01-07 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,9601,0,0,7,0,9594,0,0,'02/2022','GIRIJA'),(902,81,'2021-12-31 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,916,0,0,21,0,895,0,0,'059/2021','YASHODHA'),(903,83,'2021-12-31 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,265,0,0,21,0,244,0,0,'059/2021','YASHODHA'),(904,70,'2021-12-31 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,790,0,0,21,0,769,0,0,'059/2021','YASHODHA'),(905,34,'2021-12-17 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,797,0,0,84,0,713,0,0,'106/2017','VIJAYALAKSHMI'),(906,46,'2021-12-17 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,9594,0,0,84,0,9510,0,0,'106/2017','VIJAYALAKSHMI'),(907,34,'2021-12-10 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,713,0,0,84,0,629,0,0,'36/2020','UMMUHABEEBA'),(908,35,'2021-12-10 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,832,0,0,84,0,748,0,0,'36/2020','UMMUHABEEBA'),(909,49,'2021-12-10 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,804,0,0,84,0,720,0,0,'36/2020','UMMUHABEEBA'),(910,46,'2021-12-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,9510,0,0,968,0,8542,0,0,'36/2020','UMMUHABEEBA'),(911,11,'2021-12-10 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,3,0,0,2,0,1,0,0,'36/2020','UMMUHABEEBA'),(912,46,'2022-01-07 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,8542,0,0,42,0,8500,0,0,'38/2017','UNNEENKUTTY'),(913,26,'2022-01-07 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,874,0,0,14,0,860,0,0,'38/2017','UNNEENKUTTY'),(914,25,'2022-01-07 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,937,0,0,21,0,916,0,0,'38/2017','UNNEENKUTTY'),(915,83,'2022-01-07 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,244,0,0,28,0,216,0,0,'38/2017','UNNEENKUTTY'),(916,49,'2022-01-07 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,720,0,0,14,0,706,0,0,'38/2017','UNNEENKUTTY'),(917,48,'2022-01-07 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,678,0,0,28,0,650,0,0,'38/2017','UNNEENKUTTY'),(918,47,'2022-01-07 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,741,0,0,14,0,727,0,0,'38/2017','UNNEENKUTTY'),(919,34,'2022-01-07 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,629,0,0,42,0,587,0,0,'138/2019','UMMAR'),(920,35,'2022-01-07 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,748,0,0,84,0,664,0,0,'138/2019','UMMAR'),(921,46,'2022-01-07 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,8500,0,0,84,0,8416,0,0,'138/2019','UMMAR'),(922,48,'2022-01-07 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,650,0,0,42,0,608,0,0,'138/2019','UMMAR'),(923,46,'2021-12-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,8416,0,0,126,0,8290,0,0,'75/2019','UNNIKRISHNAN'),(924,82,'2021-12-24 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,335,0,0,42,0,293,0,0,'75/2019','UNNIKRISHNAN'),(925,83,'2021-12-24 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,216,0,0,42,0,174,0,0,'75/2019','UNNIKRISHNAN'),(926,68,'2021-12-24 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,832,0,0,84,0,748,0,0,'75/2019','UNNIKRISHNAN'),(927,82,'2022-01-13 00:00:00','M82','SV 200MG','Edit','Edit stock',0,293,0,0,0,0,1000,0,0,'',''),(928,83,'2022-01-13 00:00:00','M83','SV 500MG','Edit','Edit stock',0,174,0,0,0,0,1000,0,0,'',''),(929,81,'2022-01-07 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,895,0,0,7,0,888,0,0,'232/2021','USMAN'),(930,83,'2022-01-07 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,1000,0,0,7,0,993,0,0,'232/2021','USMAN'),(931,46,'2022-01-07 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,8290,0,0,21,0,8269,0,0,'232/2021','USMAN'),(932,71,'2022-01-07 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,797,0,0,7,0,790,0,0,'232/2021','USMAN'),(933,36,'2022-01-07 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,853,0,0,7,0,846,0,0,'232/2021','USMAN'),(934,67,'2021-12-24 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,874,0,0,42,0,832,0,0,'16/2021','SAFIYA'),(935,69,'2021-12-24 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,825,0,0,42,0,783,0,0,'16/2021','SAFIYA'),(936,83,'2021-12-24 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,993,0,0,42,0,951,0,0,'16/2021','SAFIYA'),(937,82,'2021-12-24 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,1000,0,0,42,0,958,0,0,'16/2021','SAFIYA'),(938,46,'2021-12-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,8269,0,0,42,0,8227,0,0,'16/2021','SAFIYA'),(939,82,'2021-12-03 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,958,0,0,126,0,832,0,0,'34/2018','SAKHEER'),(940,33,'2021-12-03 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,790,0,0,42,0,748,0,0,'34/2018','SAKHEER'),(941,36,'2021-12-03 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,846,0,0,42,0,804,0,0,'34/2018','SAKHEER'),(942,46,'2021-12-03 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,8227,0,0,42,0,8185,0,0,'34/2018','SAKHEER'),(943,50,'2021-11-19 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,825,0,0,56,0,769,0,0,'9/2018','RAFEENA'),(944,49,'2021-11-19 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,706,0,0,56,0,650,0,0,'9/2018','RAFEENA'),(945,46,'2021-11-19 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,8185,0,0,112,0,8073,0,0,'9/2018','RAFEENA'),(946,34,'2021-11-19 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,587,0,0,112,0,475,0,0,'9/2018','RAFEENA'),(947,5,'2021-12-24 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,965,0,0,42,0,923,0,0,'202/2021','SHAJI'),(948,4,'2021-12-24 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,895,0,0,42,0,853,0,0,'202/2021','SHAJI'),(949,82,'2021-12-24 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,832,0,0,56,0,776,0,0,'137/2020','SADHASHIVAN'),(950,83,'2021-12-24 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,951,0,0,56,0,895,0,0,'137/2020','SADHASHIVAN'),(951,36,'2021-12-24 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,804,0,0,56,0,748,0,0,'137/2020','SADHASHIVAN'),(952,48,'2021-12-24 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,608,0,0,56,0,552,0,0,'137/2020','SADHASHIVAN'),(953,37,'2021-12-24 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Transfer','Sub to OP',0,1219,0,0,56,0,1163,0,0,'105/2014','SUBAIDA'),(954,49,'2021-12-17 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,650,0,0,56,0,594,0,0,'99/2019','SUNIL'),(955,48,'2021-12-17 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,552,0,0,56,0,496,0,0,'99/2019','SUNIL'),(956,5,'2021-12-17 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,923,0,0,112,0,811,0,0,'99/2019','SUNIL'),(957,70,'2021-11-26 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,769,0,0,56,0,713,0,0,'76/2021','SHEEJA'),(958,35,'2021-11-26 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,664,0,0,112,0,552,0,0,'76/2021','SHEEJA'),(959,46,'2021-11-26 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,8073,0,0,112,0,7961,0,0,'76/2021','SHEEJA'),(960,12,'2021-12-10 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,909,0,0,28,0,881,0,0,'112/2017','SAIFUNEESA'),(961,34,'2021-12-10 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,475,0,0,28,0,447,0,0,'112/2017','SAIFUNEESA'),(962,46,'2021-12-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7961,0,0,28,0,7933,0,0,'112/2017','SAIFUNEESA'),(963,9,'2021-12-10 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,888,0,0,28,0,860,0,0,'112/2017','SAIFUNEESA'),(964,4,'2022-01-07 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,853,0,0,7,0,846,0,0,'03/2022','SUBAIDHA'),(965,82,'2021-12-10 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,776,0,0,84,0,692,0,0,'205/2019','SUBAIDA'),(966,27,'2021-12-10 00:00:00','M27','LURASIDONE HCL TABLETS 40MG','Transfer','Sub to OP',0,930,0,0,42,0,888,0,0,'205/2019','SUBAIDA'),(967,92,'2022-01-13 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Edit','Edit stock',0,0,0,0,0,0,10,0,0,'',''),(968,92,'2022-01-07 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,10,0,0,2,0,8,0,0,'116/2019','SUBAIDA'),(969,37,'2022-01-07 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Transfer','Sub to OP',0,1163,0,0,112,0,1051,0,0,'116/2019','SUBAIDA'),(970,46,'2022-01-07 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7933,0,0,42,0,7891,0,0,'158/2020','SUBRAHMANYAN'),(971,83,'2022-01-07 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,895,0,0,28,0,867,0,0,'158/2020','SUBRAHMANYAN'),(972,82,'2022-01-07 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,692,0,0,14,0,678,0,0,'158/2020','SUBRAHMANYAN'),(973,29,'2022-01-07 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,979,0,0,4,0,975,0,0,'158/2020','SUBRAHMANYAN'),(974,89,'2022-01-07 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,989,0,0,7,0,982,0,0,'158/2020','SUBRAHMANYAN'),(975,48,'2022-01-07 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,496,0,0,28,0,468,0,0,'158/2020','SUBRAHMANYAN'),(976,49,'2022-01-07 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,594,0,0,14,0,580,0,0,'158/2020','SUBRAHMANYAN'),(977,36,'2022-01-07 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,748,0,0,28,0,720,0,0,'158/2020','SUBRAHMANYAN'),(978,12,'2021-12-31 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,881,0,0,28,0,853,0,0,'77/2017','SUHARA'),(979,21,'2021-12-31 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,944,0,0,28,0,916,0,0,'77/2017','SUHARA'),(980,69,'2021-12-31 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,783,0,0,28,0,755,0,0,'77/2017','SUHARA'),(981,28,'2021-12-03 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,958,0,0,112,0,846,0,0,'79/2021','HAMEED'),(982,83,'2021-12-03 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,867,0,0,56,0,811,0,0,'79/2021','HAMEED'),(983,4,'2021-12-03 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,846,0,0,56,0,790,0,0,'79/2021','HAMEED'),(984,81,'2021-12-24 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,888,0,0,56,0,832,0,0,'104/2018','HASEENA'),(985,37,'2021-12-24 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Transfer','Sub to OP',0,1051,0,0,112,0,939,0,0,'104/2018','HASEENA'),(986,5,'2022-01-07 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,811,0,0,14,0,797,0,0,'168/2021','FATHIMAKUTTY'),(987,28,'2021-12-17 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,846,0,0,80,0,766,0,0,'04/2018','ABDUL SAMAD'),(988,46,'2021-12-17 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7891,0,0,56,0,7835,0,0,'04/2018','ABDUL SAMAD'),(989,39,'2021-12-17 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Transfer','Sub to OP',0,256,0,0,28,0,228,0,0,'04/2018','ABDUL SAMAD'),(990,83,'2021-12-03 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,811,0,0,84,0,727,0,0,'92/2018','CHEKUTTI'),(991,68,'2021-12-03 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,748,0,0,84,0,664,0,0,'92/2018','CHEKUTTI'),(992,95,'2021-12-03 00:00:00','M95','TRIFLUOPERAZINE TABLETS IP 5MG','Transfer','Sub to OP',0,455,0,0,84,0,371,0,0,'92/2018','CHEKUTTI'),(993,3,'2021-12-03 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,993,0,0,42,0,951,0,0,'92/2018','CHEKUTTI'),(994,68,'2021-12-03 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,664,0,0,84,0,580,0,0,'92/2018','CHEKUTTI'),(995,69,'2021-12-03 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,755,0,0,42,0,713,0,0,'92/2018','CHEKUTTI'),(996,92,'2021-12-31 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,8,0,0,1,0,7,0,0,'144/2019','JAMSHI'),(997,46,'2021-12-31 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7835,0,0,14,0,7821,0,0,'144/2019','JAMSHI'),(998,83,'2021-12-24 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,727,0,0,42,0,685,0,0,'15/2021','KADHEEJA'),(999,82,'2021-12-24 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,678,0,0,21,0,657,0,0,'15/2021','KADHEEJA'),(1000,12,'2021-12-24 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,853,0,0,21,0,832,0,0,'15/2021','KADHEEJA'),(1001,69,'2021-12-24 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,713,0,0,21,0,692,0,0,'15/2021','KADHEEJA'),(1002,82,'2021-12-03 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,657,0,0,84,0,573,0,0,'58/2021','SUMAYYA'),(1003,83,'2021-12-03 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,685,0,0,42,0,643,0,0,'58/2021','SUMAYYA'),(1004,46,'2021-12-03 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7821,0,0,126,0,7695,0,0,'58/2021','SUMAYYA'),(1005,83,'2021-12-10 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,643,0,0,70,0,573,0,0,'247/2021','NOUSHAD '),(1006,67,'2021-12-10 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,832,0,0,35,0,797,0,0,'247/2021','NOUSHAD '),(1007,69,'2021-12-10 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,692,0,0,35,0,657,0,0,'247/2021','NOUSHAD '),(1008,21,'2021-12-10 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,916,0,0,35,0,881,0,0,'247/2021','NOUSHAD '),(1009,46,'2021-12-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7695,0,0,35,0,7660,0,0,'247/2021','NOUSHAD '),(1010,12,'2021-12-24 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,832,0,0,42,0,790,0,0,'250/2021','HASEENA '),(1011,81,'2021-12-24 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,832,0,0,42,0,790,0,0,'250/2021','HASEENA '),(1012,83,'2021-12-24 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,573,0,0,42,0,531,0,0,'250/2021','HASEENA '),(1013,69,'2021-12-24 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,657,0,0,42,0,615,0,0,'250/2021','HASEENA '),(1014,33,'2022-01-07 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,748,0,0,4,0,744,0,0,'263/2021','FATHIMMA PP'),(1015,70,'2022-01-07 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,713,0,0,4,0,709,0,0,'263/2021','FATHIMMA PP'),(1016,4,'2022-01-07 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,790,0,0,7,0,783,0,0,'263/2021','FATHIMMA PP'),(1017,64,'2022-01-07 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Transfer','Sub to OP',0,979,0,0,4,0,975,0,0,'161/2019','ASHRAF CP'),(1018,21,'2022-01-07 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,881,0,0,14,0,867,0,0,'161/2019','ASHRAF CP'),(1019,44,'2022-01-07 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Transfer','Sub to OP',0,595,0,0,14,0,581,0,0,'161/2019','ASHRAF CP'),(1020,83,'2022-01-14 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,531,0,0,56,0,475,0,0,'26/2017','ABDURAHMAN'),(1021,83,'2022-01-14 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,475,0,0,28,0,447,0,0,'288/2021','SABIRA'),(1022,82,'2022-01-14 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,573,0,0,28,0,545,0,0,'288/2021','SABIRA'),(1023,36,'2022-01-14 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,720,0,0,28,0,692,0,0,'288/2021','SABIRA'),(1024,46,'2022-01-14 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7660,0,0,84,0,7576,0,0,'288/2021','SABIRA'),(1025,92,'2022-01-07 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,7,0,0,1,0,6,0,0,'291/2021','AMINA'),(1026,5,'2022-01-14 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,797,0,0,7,0,790,0,0,'04/2022','BIJU'),(1027,3,'2022-01-14 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,951,0,0,7,0,944,0,0,'04/2022','BIJU'),(1028,36,'2022-01-14 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,692,0,0,7,0,685,0,0,'02/2022','GIRIJA'),(1029,46,'2022-01-14 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7576,0,0,7,0,7569,0,0,'02/2022','GIRIJA'),(1030,4,'2022-01-14 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,783,0,0,21,0,762,0,0,'03/2022','SUBAIDHA'),(1031,81,'2022-01-14 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,790,0,0,14,0,776,0,0,'232/2021','USMAN'),(1032,83,'2022-01-14 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,447,0,0,14,0,433,0,0,'232/2021','USMAN'),(1033,36,'2022-01-14 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,685,0,0,14,0,671,0,0,'232/2021','USMAN'),(1034,46,'2022-01-14 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7569,0,0,56,0,7513,0,0,'232/2021','USMAN'),(1035,47,'2022-01-14 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,727,0,0,14,0,713,0,0,'232/2021','USMAN'),(1036,22,'2022-01-14 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,1000,0,0,14,0,986,0,0,'248/2021','RAMLA'),(1037,82,'2022-01-14 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,545,0,0,35,0,510,0,0,'137/2020','SADHASHIVAN'),(1038,83,'2022-01-14 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,433,0,0,35,0,398,0,0,'137/2020','SADHASHIVAN'),(1039,36,'2022-01-14 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,671,0,0,35,0,636,0,0,'137/2020','SADHASHIVAN'),(1040,49,'2022-01-14 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,580,0,0,35,0,545,0,0,'137/2020','SADHASHIVAN'),(1041,46,'2022-01-14 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7513,0,0,35,0,7478,0,0,'137/2020','SADHASHIVAN'),(1042,12,'2022-01-14 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,790,0,0,42,0,748,0,0,'112/2017','SAIFUNEESA'),(1043,34,'2022-01-14 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,447,0,0,42,0,405,0,0,'112/2017','SAIFUNEESA'),(1044,46,'2022-01-14 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7478,0,0,42,0,7436,0,0,'112/2017','SAIFUNEESA'),(1045,9,'2022-01-14 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,860,0,0,42,0,818,0,0,'112/2017','SAIFUNEESA'),(1046,48,'2022-01-14 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,468,0,0,28,0,440,0,0,'92/2018','CHEKUTTI'),(1047,83,'2022-01-14 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,398,0,0,56,0,342,0,0,'92/2018','CHEKUTTI'),(1048,68,'2022-01-14 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,580,0,0,56,0,524,0,0,'92/2018','CHEKUTTI'),(1049,95,'2022-01-14 00:00:00','M95','TRIFLUOPERAZINE TABLETS IP 5MG','Transfer','Sub to OP',0,371,0,0,56,0,315,0,0,'92/2018','CHEKUTTI'),(1050,83,'2022-01-14 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,342,0,0,56,0,286,0,0,'15/2021','KADHEEJA'),(1051,82,'2022-01-14 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,510,0,0,28,0,482,0,0,'15/2021','KADHEEJA'),(1052,12,'2022-01-14 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,748,0,0,28,0,720,0,0,'15/2021','KADHEEJA'),(1053,69,'2022-01-14 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,615,0,0,28,0,587,0,0,'15/2021','KADHEEJA'),(1054,82,'2022-01-14 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,482,0,0,21,0,461,0,0,'75/2019','UNNIKRISHNAN'),(1055,83,'2022-01-14 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,286,0,0,21,0,265,0,0,'75/2019','UNNIKRISHNAN'),(1056,68,'2022-01-14 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,524,0,0,21,0,503,0,0,'75/2019','UNNIKRISHNAN'),(1057,81,'2022-01-14 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,776,0,0,28,0,748,0,0,'250/2021','HASEENA '),(1058,83,'2022-01-14 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,265,0,0,28,0,237,0,0,'250/2021','HASEENA '),(1059,12,'2022-01-14 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,720,0,0,28,0,692,0,0,'250/2021','HASEENA '),(1060,69,'2022-01-14 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,587,0,0,28,0,559,0,0,'250/2021','HASEENA '),(1061,83,'2022-01-14 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,237,0,0,56,0,181,0,0,'247/2021','NOUSHAD '),(1062,67,'2022-01-14 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,797,0,0,28,0,769,0,0,'247/2021','NOUSHAD '),(1063,69,'2022-01-14 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,559,0,0,28,0,531,0,0,'247/2021','NOUSHAD '),(1064,21,'2022-01-14 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,867,0,0,28,0,839,0,0,'247/2021','NOUSHAD '),(1065,46,'2022-01-14 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7436,0,0,28,0,7408,0,0,'247/2021','NOUSHAD '),(1066,50,'2022-01-14 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,769,0,0,56,0,713,0,0,'9/2018','RAFEENA'),(1067,46,'2022-01-14 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7408,0,0,112,0,7296,0,0,'9/2018','RAFEENA'),(1068,34,'2022-01-14 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,405,0,0,112,0,293,0,0,'9/2018','RAFEENA'),(1069,4,'2022-01-14 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,762,0,0,14,0,748,0,0,'168/2021','FATHIMAKUTTY'),(1070,26,'2022-01-14 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,860,0,0,28,0,832,0,0,'38/2017','UNNEENKUTTY'),(1071,83,'2022-01-14 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,181,0,0,28,0,153,0,0,'38/2017','UNNEENKUTTY'),(1072,49,'2022-01-14 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,545,0,0,14,0,531,0,0,'38/2017','UNNEENKUTTY'),(1073,48,'2022-01-14 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,440,0,0,14,0,426,0,0,'38/2017','UNNEENKUTTY'),(1074,47,'2022-01-14 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,713,0,0,14,0,699,0,0,'38/2017','UNNEENKUTTY'),(1075,46,'2022-01-14 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7296,0,0,42,0,7254,0,0,'38/2017','UNNEENKUTTY'),(1076,76,'2022-01-14 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,832,0,0,14,0,818,0,0,'90/2017','RANEESH'),(1077,48,'2022-01-14 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,426,0,0,28,0,398,0,0,'90/2017','RANEESH'),(1078,46,'2022-01-14 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7254,0,0,84,0,7170,0,0,'90/2017','RANEESH'),(1079,33,'2022-01-14 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,744,0,0,28,0,716,0,0,'90/2017','RANEESH'),(1080,83,'2022-01-14 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,153,0,0,56,0,97,0,0,'90/2017','RANEESH'),(1081,82,'2022-01-14 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,461,0,0,56,0,405,0,0,'58/2021','SUMAYYA'),(1082,83,'2022-01-14 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,97,0,0,28,0,69,0,0,'58/2021','SUMAYYA'),(1083,50,'2022-01-14 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,713,0,0,28,0,685,0,0,'58/2021','SUMAYYA'),(1084,47,'2022-01-14 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,699,0,0,28,0,671,0,0,'58/2021','SUMAYYA'),(1085,48,'2022-01-14 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,398,0,0,28,0,370,0,0,'58/2021','SUMAYYA'),(1086,46,'2022-01-14 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7170,0,0,84,0,7086,0,0,'58/2021','SUMAYYA'),(1087,69,'2022-01-14 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,531,0,0,56,0,475,0,0,'135/2020','ALAVI'),(1088,22,'2022-01-14 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,986,0,0,56,0,930,0,0,'135/2020','ALAVI'),(1089,82,'2022-01-14 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,405,0,0,112,0,293,0,0,'135/2020','ALAVI'),(1090,82,'2021-12-17 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,293,0,0,56,0,237,0,0,'54/2017','PUSHPAVATHI'),(1091,83,'2021-12-17 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,69,0,0,56,0,13,0,0,'54/2017','PUSHPAVATHI'),(1092,68,'2021-12-17 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,503,0,0,56,0,447,0,0,'54/2017','PUSHPAVATHI'),(1093,46,'2021-12-17 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7086,0,0,56,0,7030,0,0,'54/2017','PUSHPAVATHI'),(1094,8,'2021-12-17 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Transfer','Sub to OP',0,916,0,0,56,0,860,0,0,'54/2017','PUSHPAVATHI'),(1095,59,'2022-01-07 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Transfer','Sub to OP',0,972,0,0,28,0,944,0,0,'292/2021','ABDUL NAZAR'),(1096,3,'2022-01-07 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,944,0,0,10,0,934,0,0,'292/2021','ABDUL NAZAR'),(1097,70,'2022-01-07 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,709,0,0,14,0,695,0,0,'292/2021','ABDUL NAZAR'),(1098,68,'2022-01-07 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,447,0,0,28,0,419,0,0,'292/2021','ABDUL NAZAR'),(1099,70,'2021-12-10 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,695,0,0,84,0,611,0,0,'49/2017','RUKKIYA'),(1100,71,'2021-12-10 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,790,0,0,84,0,706,0,0,'49/2017','RUKKIYA'),(1101,45,'2021-12-31 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,233,0,0,98,0,135,0,0,'211/2019','RAJAN'),(1102,87,'2021-12-31 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Transfer','Sub to OP',0,902,0,0,74,0,828,0,0,'211/2019','RAJAN'),(1103,81,'2021-12-31 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,748,0,0,98,0,650,0,0,'211/2019','RAJAN'),(1104,36,'2021-12-31 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,636,0,0,49,0,587,0,0,'211/2019','RAJAN'),(1105,46,'2021-12-31 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,7030,0,0,147,0,6883,0,0,'211/2019','RAJAN'),(1106,4,'2021-12-31 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,748,0,0,49,0,699,0,0,'211/2019','RAJAN'),(1107,82,'2022-01-15 00:00:00','M82','SV 200MG','Edit','Edit stock',0,237,0,0,0,0,10000,0,0,'',''),(1108,83,'2022-01-15 00:00:00','M83','SV 500MG','Edit','Edit stock',0,13,0,0,0,0,10000,0,0,'',''),(1109,81,'2022-01-15 00:00:00','M81','SV 300MG','Edit','Edit stock',0,650,0,0,0,0,10000,0,0,'',''),(1110,72,'2022-01-07 00:00:00','M72','QUETIAPINE TABLETS 100MG','Transfer','Sub to OP',0,804,0,0,56,0,748,0,0,'182/2021','MOHAMMAD BASHEER'),(1111,71,'2022-01-07 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,706,0,0,56,0,650,0,0,'182/2021','MOHAMMAD BASHEER'),(1112,46,'2022-01-07 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,6883,0,0,168,0,6715,0,0,'182/2021','MOHAMMAD BASHEER'),(1113,83,'2022-01-07 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,10000,0,0,112,0,9888,0,0,'182/2021','MOHAMMAD BASHEER'),(1114,25,'2022-01-07 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,916,0,0,56,0,860,0,0,'182/2021','MOHAMMAD BASHEER'),(1115,26,'2022-01-07 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,832,0,0,56,0,776,0,0,'182/2021','MOHAMMAD BASHEER'),(1116,48,'2022-01-07 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,370,0,0,56,0,314,0,0,'182/2021','MOHAMMAD BASHEER'),(1117,35,'2021-12-24 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,552,0,0,112,0,440,0,0,'088/2017','MUHAMMAD RAFEEQ'),(1118,33,'2021-12-24 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,716,0,0,56,0,660,0,0,'088/2017','MUHAMMAD RAFEEQ'),(1119,46,'2021-12-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,6715,0,0,56,0,6659,0,0,'088/2017','MUHAMMAD RAFEEQ'),(1120,35,'2021-12-31 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,440,0,0,28,0,412,0,0,'196/2021','MUHAMMAD KUTTI'),(1121,46,'2021-12-31 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,6659,0,0,28,0,6631,0,0,'196/2021','MUHAMMAD KUTTI'),(1122,9,'2021-12-24 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,818,0,0,84,0,734,0,0,'88/2017','MUHAMMAD RAFI'),(1123,49,'2021-12-24 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,531,0,0,56,0,475,0,0,'88/2017','MUHAMMAD RAFI'),(1124,47,'2021-12-24 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,671,0,0,56,0,615,0,0,'88/2017','MUHAMMAD RAFI'),(1125,46,'2021-12-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,6631,0,0,56,0,6575,0,0,'88/2017','MUHAMMAD RAFI'),(1126,11,'2022-01-15 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Edit','Edit stock',0,1,0,0,0,0,20,0,0,'',''),(1127,93,'2021-12-24 00:00:00','M93','FLUPHENAZINE DECANOATE INJECTION IP 1ML','Transfer','Sub to OP',0,1000,0,0,2,0,998,0,0,'231/2021','MUHAMMAD IQBAL'),(1128,11,'2021-12-24 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,20,0,0,4,0,16,0,0,'231/2021','MUHAMMAD IQBAL'),(1129,49,'2021-12-24 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,475,0,0,28,0,447,0,0,'231/2021','MUHAMMAD IQBAL'),(1130,92,'2021-12-24 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,6,0,0,2,0,4,0,0,'231/2021','MUHAMMAD IQBAL'),(1131,46,'2021-12-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,6575,0,0,28,0,6547,0,0,'231/2021','MUHAMMAD IQBAL'),(1132,39,'2021-12-24 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Transfer','Sub to OP',0,228,0,0,42,0,186,0,0,'230/2021','NUSAIBA'),(1133,12,'2021-10-01 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,692,0,0,14,0,678,0,0,'204/2021','KADHEEJA'),(1134,65,'2021-11-19 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,818,0,0,84,0,734,0,0,'59/2021','KUNJUMUHAMMAD'),(1135,19,'2021-11-19 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,979,0,0,42,0,937,0,0,'59/2021','KUNJUMUHAMMAD'),(1136,20,'2021-11-19 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,958,0,0,84,0,874,0,0,'59/2021','KUNJUMUHAMMAD'),(1137,45,'2022-01-15 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Edit','Edit stock',0,135,0,0,0,0,1000,0,0,'',''),(1138,45,'2021-12-24 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,1000,0,0,168,0,832,0,0,'45/2017','KORAN'),(1139,47,'2021-12-24 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,615,0,0,84,0,531,0,0,'45/2017','KORAN'),(1140,48,'2021-12-24 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,314,0,0,84,0,230,0,0,'45/2017','KORAN'),(1141,83,'2021-12-17 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,9888,0,0,56,0,9832,0,0,'47/2017','KUNJATHU'),(1142,70,'2021-12-17 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,611,0,0,56,0,555,0,0,'47/2017','KUNJATHU'),(1143,83,'2021-12-31 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,9832,0,0,56,0,9776,0,0,'137/2017','MUJEEBRAHMAN'),(1144,26,'2021-12-31 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,776,0,0,42,0,734,0,0,'137/2017','MUJEEBRAHMAN'),(1145,73,'2021-12-31 00:00:00','M73','QUETIAPINE TABLETS 200MG','Transfer','Sub to OP',0,958,0,0,28,0,930,0,0,'137/2017','MUJEEBRAHMAN'),(1146,46,'2021-12-31 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,6547,0,0,84,0,6463,0,0,'137/2017','MUJEEBRAHMAN'),(1147,76,'2021-12-31 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,818,0,0,28,0,790,0,0,'137/2017','MUJEEBRAHMAN'),(1148,35,'2021-12-24 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,412,0,0,56,0,356,0,0,'134/2020','MADHU'),(1149,46,'2021-12-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,6463,0,0,84,0,6379,0,0,'134/2020','MADHU'),(1150,83,'2021-12-24 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,9776,0,0,56,0,9720,0,0,'134/2020','MADHU'),(1151,71,'2021-12-24 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,650,0,0,28,0,622,0,0,'134/2020','MADHU'),(1152,71,'2021-11-26 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,622,0,0,56,0,566,0,0,'078/2021','MANIKANDAN'),(1153,70,'2021-11-26 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,555,0,0,56,0,499,0,0,'078/2021','MANIKANDAN'),(1154,37,'2021-11-26 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Transfer','Sub to OP',0,939,0,0,112,0,827,0,0,'078/2021','MANIKANDAN'),(1155,35,'2021-11-26 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,356,0,0,112,0,244,0,0,'078/2021','MANIKANDAN'),(1156,85,'2021-12-24 00:00:00','M85','LEVETIRACETAM TABLETS 250 MG','Transfer','Sub to OP',0,1000,0,0,28,0,972,0,0,'44/2017','ABUBAKAR'),(1157,34,'2021-12-24 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,293,0,0,14,0,279,0,0,'44/2017','ABUBAKAR'),(1158,34,'2021-12-31 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,279,0,0,42,0,237,0,0,'287/2021','AYISHA'),(1159,46,'2021-12-31 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,6379,0,0,42,0,6337,0,0,'287/2021','AYISHA'),(1160,67,'2021-12-31 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,769,0,0,21,0,748,0,0,'287/2021','AYISHA'),(1161,20,'2021-12-23 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,874,0,0,42,0,832,0,0,'44/2020','MOHAMMAD ASHIQ'),(1162,12,'2021-12-23 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,678,0,0,42,0,636,0,0,'44/2020','MOHAMMAD ASHIQ'),(1163,56,'2021-12-23 00:00:00','M56','CLOMIPRAMINE TABLETS 25MG','Transfer','Sub to OP',0,1000,0,0,126,0,874,0,0,'44/2020','MOHAMMAD ASHIQ'),(1164,12,'2021-11-26 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,636,0,0,42,0,594,0,0,'67/2021','ANEESHA'),(1165,33,'2021-11-26 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,660,0,0,21,0,639,0,0,'67/2021','ANEESHA'),(1166,48,'2021-12-17 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,230,0,0,42,0,188,0,0,'48/2017','ABDUL HASEEB'),(1167,47,'2021-12-17 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,531,0,0,42,0,489,0,0,'48/2017','ABDUL HASEEB'),(1168,70,'2021-12-17 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,499,0,0,42,0,457,0,0,'48/2017','ABDUL HASEEB'),(1169,71,'2021-12-17 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,566,0,0,42,0,524,0,0,'48/2017','ABDUL HASEEB'),(1170,46,'2021-12-17 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,6337,0,0,126,0,6211,0,0,'48/2017','ABDUL HASEEB'),(1171,34,'2021-12-17 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,237,0,0,84,0,153,0,0,'48/2017','ABDUL HASEEB'),(1172,82,'2021-12-10 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,10000,0,0,56,0,9944,0,0,'06/2018','BIYYUTTI PP'),(1173,83,'2021-12-10 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,9720,0,0,56,0,9664,0,0,'06/2018','BIYYUTTI PP'),(1174,36,'2021-12-10 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,587,0,0,112,0,475,0,0,'06/2018','BIYYUTTI PP'),(1175,46,'2021-12-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,6211,0,0,168,0,6043,0,0,'06/2018','BIYYUTTI PP'),(1176,9,'2021-12-24 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,734,0,0,42,0,692,0,0,'63/2018','BABY'),(1177,8,'2021-12-24 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Transfer','Sub to OP',0,860,0,0,42,0,818,0,0,'63/2018','BABY'),(1178,21,'2021-12-31 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,839,0,0,84,0,755,0,0,'60/2021','CHITHRA RK'),(1179,82,'2021-11-12 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,9944,0,0,84,0,9860,0,0,'8/2014','DHANISHMA'),(1180,57,'2021-11-26 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Transfer','Sub to OP',0,1000,0,0,112,0,888,0,0,'206/2021','FARHANA SHIRIL'),(1181,34,'2021-11-26 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,153,0,0,56,0,97,0,0,'206/2021','FARHANA SHIRIL'),(1182,81,'2021-12-24 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,10000,0,0,168,0,9832,0,0,'83/2019','FARSANA THASNI'),(1183,84,'2021-12-24 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,832,0,0,168,0,664,0,0,'83/2019','FARSANA THASNI'),(1184,59,'2021-12-24 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Transfer','Sub to OP',0,944,0,0,84,0,860,0,0,'83/2019','FARSANA THASNI'),(1185,57,'2021-12-24 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Transfer','Sub to OP',0,888,0,0,84,0,804,0,0,'83/2019','FARSANA THASNI'),(1186,37,'2021-12-10 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Transfer','Sub to OP',0,827,0,0,168,0,659,0,0,'07/2017','FATHIMMA'),(1187,19,'2021-12-10 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,937,0,0,84,0,853,0,0,'07/2017','FATHIMMA'),(1188,37,'2021-12-24 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Transfer','Sub to OP',0,659,0,0,112,0,547,0,0,'112/2018','FOUSIYA'),(1189,19,'2021-12-24 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,853,0,0,28,0,825,0,0,'112/2018','FOUSIYA'),(1190,33,'2022-01-21 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,639,0,0,84,0,555,0,0,'36/2020','UMMUHABEEBA'),(1191,36,'2022-01-21 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,475,0,0,84,0,391,0,0,'36/2020','UMMUHABEEBA'),(1192,49,'2022-01-21 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,447,0,0,84,0,363,0,0,'36/2020','UMMUHABEEBA'),(1193,46,'2022-01-21 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,6043,0,0,168,0,5875,0,0,'36/2020','UMMUHABEEBA'),(1194,11,'2022-01-21 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,16,0,0,2,0,14,0,0,'36/2020','UMMUHABEEBA'),(1195,92,'2022-01-21 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,4,0,0,1,0,3,0,0,'05/2022','SHAMEERALI'),(1196,49,'2022-01-21 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,363,0,0,14,0,349,0,0,'05/2022','SHAMEERALI'),(1197,72,'2022-01-21 00:00:00','M72','QUETIAPINE TABLETS 100MG','Transfer','Sub to OP',0,748,0,0,14,0,734,0,0,'05/2022','SHAMEERALI'),(1198,92,'2022-01-21 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,3,0,0,1,0,2,0,0,'291/2021','AMINA'),(1199,4,'2022-01-21 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,699,0,0,21,0,678,0,0,'04/2022','BIJU'),(1200,23,'2022-01-21 00:00:00','M23','FLUOXETINE CAPSULES 10MG','Transfer','Sub to OP',0,1000,0,0,21,0,979,0,0,'04/2022','BIJU'),(1201,3,'2022-01-21 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,934,0,0,21,0,913,0,0,'04/2022','BIJU'),(1202,64,'2022-01-21 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Transfer','Sub to OP',0,975,0,0,21,0,954,0,0,'04/2022','BIJU'),(1203,85,'2022-01-21 00:00:00','M85','LEVETIRACETAM TABLETS 250 MG','Transfer','Sub to OP',0,972,0,0,56,0,916,0,0,'44/2017','ABUBAKAR'),(1204,33,'2022-01-21 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,555,0,0,28,0,527,0,0,'44/2017','ABUBAKAR'),(1205,83,'2022-01-21 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,9664,0,0,84,0,9580,0,0,'47/2017','KUNJATHU'),(1206,70,'2022-01-21 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,457,0,0,84,0,373,0,0,'47/2017','KUNJATHU'),(1207,12,'2022-01-21 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,594,0,0,42,0,552,0,0,'27/2017','FADALU (FAIZAL)'),(1208,21,'2022-01-21 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,755,0,0,42,0,713,0,0,'27/2017','FADALU (FAIZAL)'),(1209,23,'2022-01-21 00:00:00','M23','FLUOXETINE CAPSULES 10MG','Transfer','Sub to OP',0,979,0,0,63,0,916,0,0,'27/2017','FADALU (FAIZAL)'),(1210,48,'2022-01-21 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,188,0,0,42,0,146,0,0,'27/2017','FADALU (FAIZAL)'),(1211,47,'2022-01-21 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,489,0,0,21,0,468,0,0,'27/2017','FADALU (FAIZAL)'),(1212,49,'2022-01-21 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,349,0,0,56,0,293,0,0,'231/2021','MUHAMMAD IQBAL'),(1213,92,'2022-01-21 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2,0,0,2,0,0,0,0,'231/2021','MUHAMMAD IQBAL'),(1214,11,'2022-01-21 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,14,0,0,2,0,12,0,0,'231/2021','MUHAMMAD IQBAL'),(1215,93,'2022-01-21 00:00:00','M93','FLUPHENAZINE DECANOATE INJECTION IP 1ML','Transfer','Sub to OP',0,998,0,0,4,0,994,0,0,'231/2021','MUHAMMAD IQBAL'),(1216,46,'2022-01-21 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,5875,0,0,56,0,5819,0,0,'231/2021','MUHAMMAD IQBAL'),(1217,82,'2022-01-21 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,9860,0,0,168,0,9692,0,0,'0130/2017','SHANDHA'),(1218,43,'2022-01-21 00:00:00','M43','VENLAFAXINE EXTENDED RELEASE CAPSULES 75MG','Transfer','Sub to OP',0,832,0,0,112,0,720,0,0,'0130/2017','SHANDHA'),(1219,65,'2022-01-21 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,734,0,0,56,0,678,0,0,'0130/2017','SHANDHA'),(1220,70,'2022-01-21 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,373,0,0,56,0,317,0,0,'0130/2017','SHANDHA'),(1221,50,'2022-01-21 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,685,0,0,56,0,629,0,0,'93/2017','SOORAJ'),(1222,48,'2022-01-21 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,146,0,0,112,0,34,0,0,'93/2017','SOORAJ'),(1223,83,'2022-01-21 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,9580,0,0,112,0,9468,0,0,'93/2017','SOORAJ'),(1224,82,'2022-01-21 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,9692,0,0,56,0,9636,0,0,'93/2017','SOORAJ'),(1225,34,'2022-01-21 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,97,0,0,56,0,41,0,0,'93/2017','SOORAJ'),(1226,46,'2022-01-21 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,5819,0,0,224,0,5595,0,0,'93/2017','SOORAJ'),(1227,34,'2022-01-21 00:00:00','M34','RISPERIDONE TABLETS 2MG','Edit','Edit stock',0,41,0,0,0,0,1000,0,0,'',''),(1228,33,'2022-01-21 00:00:00','M33','RISPERIDONE TABLETS 1MG','Edit','Edit stock',0,527,0,0,0,0,1000,0,0,'',''),(1229,35,'2022-01-21 00:00:00','M35','RISPERIDONE TABLETS 3MG','Edit','Edit stock',0,244,0,0,0,0,1000,0,0,'',''),(1230,36,'2022-01-21 00:00:00','M36','RISPERIDONE TABLETS 4MG','Edit','Edit stock',0,391,0,0,0,0,1000,0,0,'',''),(1231,34,'2022-01-21 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1000,0,0,112,0,888,0,0,'287/2021','AYISHA'),(1232,46,'2022-01-21 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,5595,0,0,112,0,5483,0,0,'287/2021','AYISHA'),(1233,69,'2022-01-21 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,475,0,0,28,0,447,0,0,'287/2021','AYISHA'),(1234,82,'2022-01-21 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,9636,0,0,112,0,9524,0,0,'287/2021','AYISHA'),(1235,82,'2022-01-21 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,9524,0,0,56,0,9468,0,0,'290/2021','SHAHUL HAMEED'),(1236,21,'2022-01-21 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,713,0,0,28,0,685,0,0,'290/2021','SHAHUL HAMEED'),(1237,68,'2022-01-21 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,419,0,0,56,0,363,0,0,'290/2021','SHAHUL HAMEED'),(1238,36,'2022-01-21 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1000,0,0,28,0,972,0,0,'290/2021','SHAHUL HAMEED'),(1239,35,'2022-01-21 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,1000,0,0,28,0,972,0,0,'112/2017','SAIFUNEESA'),(1240,46,'2022-01-21 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,5483,0,0,28,0,5455,0,0,'112/2017','SAIFUNEESA'),(1241,59,'2022-01-21 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Transfer','Sub to OP',0,860,0,0,35,0,825,0,0,'292/2021','ABDUL NAZAR'),(1242,70,'2022-01-21 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,317,0,0,35,0,282,0,0,'292/2021','ABDUL NAZAR'),(1243,68,'2022-01-21 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,363,0,0,70,0,293,0,0,'292/2021','ABDUL NAZAR'),(1244,57,'2022-01-21 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Transfer','Sub to OP',0,804,0,0,84,0,720,0,0,'206/2021','FARHANA SHIRIL'),(1245,34,'2022-01-21 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,888,0,0,42,0,846,0,0,'206/2021','FARHANA SHIRIL'),(1246,34,'2022-01-21 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,846,0,0,28,0,818,0,0,'158/2020','SUBRAHMANYAN'),(1247,35,'2022-01-21 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,972,0,0,56,0,916,0,0,'158/2020','SUBRAHMANYAN'),(1248,46,'2022-01-21 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,5455,0,0,84,0,5371,0,0,'158/2020','SUBRAHMANYAN'),(1249,83,'2022-01-21 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,9468,0,0,56,0,9412,0,0,'158/2020','SUBRAHMANYAN'),(1250,82,'2022-01-21 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,9468,0,0,28,0,9440,0,0,'158/2020','SUBRAHMANYAN'),(1251,49,'2022-01-21 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,293,0,0,28,0,265,0,0,'158/2020','SUBRAHMANYAN'),(1252,49,'2022-01-21 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,265,0,0,14,0,251,0,0,'158/2020','SUBRAHMANYAN'),(1253,35,'2022-01-21 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,916,0,0,98,0,818,0,0,'134/2020','MADHU'),(1254,46,'2022-01-21 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,5371,0,0,147,0,5224,0,0,'134/2020','MADHU'),(1255,83,'2022-01-21 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,9412,0,0,98,0,9314,0,0,'134/2020','MADHU'),(1256,71,'2022-01-21 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,524,0,0,49,0,475,0,0,'134/2020','MADHU'),(1257,12,'2022-01-28 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,552,0,0,21,0,531,0,0,'291/2021','AMINA'),(1258,34,'2022-01-28 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,818,0,0,28,0,790,0,0,'02/2022','GIRIJA'),(1259,35,'2022-01-28 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,818,0,0,28,0,790,0,0,'02/2022','GIRIJA'),(1260,46,'2022-01-28 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,5224,0,0,28,0,5196,0,0,'02/2022','GIRIJA'),(1261,47,'2022-01-28 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,468,0,0,28,0,440,0,0,'45/2017','KORAN'),(1262,48,'2022-01-28 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,34,0,0,28,0,6,0,0,'45/2017','KORAN'),(1263,49,'2022-01-28 00:00:00','M49','CLOZAPINE TABLETS 100MG','Edit','Edit stock',0,251,0,0,0,0,1000,0,0,'',''),(1264,50,'2022-01-28 00:00:00','M50','CLOZAPINE TABLETS 200MG','Edit','Edit stock',0,629,0,0,0,0,1000,0,0,'',''),(1265,47,'2022-01-28 00:00:00','M47','CLOZAPINE TABLETS 25MG','Edit','Edit stock',0,440,0,0,0,0,1000,0,0,'',''),(1266,48,'2022-01-28 00:00:00','M48','CLOZAPINE TABLETS 50MG','Edit','Edit stock',0,6,0,0,0,0,1000,0,0,'',''),(1267,83,'2022-01-28 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,9314,0,0,42,0,9272,0,0,'38/2017','UNNEENKUTTY'),(1268,46,'2022-01-28 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,5196,0,0,63,0,5133,0,0,'38/2017','UNNEENKUTTY'),(1269,49,'2022-01-28 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1000,0,0,21,0,979,0,0,'38/2017','UNNEENKUTTY'),(1270,47,'2022-01-28 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1000,0,0,21,0,979,0,0,'38/2017','UNNEENKUTTY'),(1271,48,'2022-01-28 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1000,0,0,21,0,979,0,0,'38/2017','UNNEENKUTTY'),(1272,26,'2022-01-28 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,734,0,0,42,0,692,0,0,'38/2017','UNNEENKUTTY'),(1273,25,'2022-01-28 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,860,0,0,21,0,839,0,0,'38/2017','UNNEENKUTTY'),(1274,5,'2022-01-28 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,790,0,0,21,0,769,0,0,'168/2021','FATHIMAKUTTY'),(1275,48,'2022-01-28 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,979,0,0,28,0,951,0,0,'48/2017','ABDUL HASEEB'),(1276,47,'2022-01-28 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,979,0,0,28,0,951,0,0,'48/2017','ABDUL HASEEB'),(1277,71,'2022-01-28 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,475,0,0,28,0,447,0,0,'48/2017','ABDUL HASEEB'),(1278,70,'2022-01-28 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,282,0,0,28,0,254,0,0,'48/2017','ABDUL HASEEB'),(1279,46,'2022-01-28 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,5133,0,0,84,0,5049,0,0,'48/2017','ABDUL HASEEB'),(1280,34,'2022-01-28 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,790,0,0,56,0,734,0,0,'48/2017','ABDUL HASEEB'),(1281,68,'2022-01-28 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,293,0,0,14,0,279,0,0,'99/2019','SUNIL'),(1282,28,'2022-01-28 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,766,0,0,112,0,654,0,0,'79/2021','HAMEED'),(1283,83,'2022-01-28 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,9272,0,0,56,0,9216,0,0,'79/2021','HAMEED'),(1284,4,'2022-01-28 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,678,0,0,56,0,622,0,0,'79/2021','HAMEED'),(1285,83,'2022-01-28 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,9216,0,0,56,0,9160,0,0,'059/2021','YASHODHA'),(1286,82,'2022-01-28 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,9440,0,0,56,0,9384,0,0,'059/2021','YASHODHA'),(1287,70,'2022-01-28 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,254,0,0,56,0,198,0,0,'059/2021','YASHODHA'),(1288,21,'2022-01-28 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,685,0,0,28,0,657,0,0,'77/2017','SUHARA'),(1289,12,'2022-01-28 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,531,0,0,28,0,503,0,0,'77/2017','SUHARA'),(1290,25,'2022-01-28 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,839,0,0,28,0,811,0,0,'77/2017','SUHARA'),(1291,48,'2022-01-28 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,951,0,0,21,0,930,0,0,'232/2021','USMAN'),(1292,83,'2022-01-28 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,9160,0,0,21,0,9139,0,0,'232/2021','USMAN'),(1293,81,'2022-01-28 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,9832,0,0,21,0,9811,0,0,'232/2021','USMAN'),(1294,36,'2022-01-28 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,972,0,0,21,0,951,0,0,'232/2021','USMAN'),(1295,46,'2022-01-28 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,5049,0,0,84,0,4965,0,0,'232/2021','USMAN'),(1296,35,'2022-01-28 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,790,0,0,28,0,762,0,0,'196/2021','MUHAMMAD KUTTI'),(1297,46,'2022-01-28 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,4965,0,0,28,0,4937,0,0,'196/2021','MUHAMMAD KUTTI'),(1298,83,'2022-01-28 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,9139,0,0,112,0,9027,0,0,'137/2017','MUJEEBRAHMAN'),(1299,26,'2022-01-28 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,692,0,0,56,0,636,0,0,'137/2017','MUJEEBRAHMAN'),(1300,25,'2022-01-28 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,811,0,0,56,0,755,0,0,'137/2017','MUJEEBRAHMAN'),(1301,72,'2022-01-28 00:00:00','M72','QUETIAPINE TABLETS 100MG','Transfer','Sub to OP',0,734,0,0,56,0,678,0,0,'137/2017','MUJEEBRAHMAN'),(1302,71,'2022-01-28 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,447,0,0,56,0,391,0,0,'137/2017','MUJEEBRAHMAN'),(1303,46,'2022-01-28 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,4937,0,0,168,0,4769,0,0,'137/2017','MUJEEBRAHMAN'),(1304,76,'2022-01-28 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,790,0,0,56,0,734,0,0,'137/2017','MUJEEBRAHMAN'),(1305,58,'2022-02-04 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Transfer','Sub to OP',0,944,0,0,84,0,860,0,0,'89/2018','MUHAMMAD'),(1306,72,'2022-02-04 00:00:00','M72','QUETIAPINE TABLETS 100MG','Transfer','Sub to OP',0,678,0,0,42,0,636,0,0,'89/2018','MUHAMMAD'),(1307,24,'2022-02-04 00:00:00','M24','GABAPENTIN TABLETS 100MG','Transfer','Sub to OP',0,972,0,0,42,0,930,0,0,'89/2018','MUHAMMAD'),(1308,4,'2022-02-04 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,622,0,0,28,0,594,0,0,'03/2022','SUBAIDHA'),(1309,5,'2022-02-04 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,769,0,0,70,0,699,0,0,'202/2021','SHAJI'),(1310,4,'2022-02-04 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,594,0,0,70,0,524,0,0,'202/2021','SHAJI'),(1311,21,'2022-02-04 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,657,0,0,84,0,573,0,0,'161/2019','ASHRAF CP'),(1312,44,'2022-02-04 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Transfer','Sub to OP',0,581,0,0,84,0,497,0,0,'161/2019','ASHRAF CP'),(1313,83,'2022-02-04 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,9027,0,0,28,0,8999,0,0,'290/2021','SHAHUL HAMEED'),(1314,21,'2022-02-04 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,573,0,0,14,0,559,0,0,'290/2021','SHAHUL HAMEED'),(1315,68,'2022-02-04 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,279,0,0,28,0,251,0,0,'290/2021','SHAHUL HAMEED'),(1316,35,'2022-02-04 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,762,0,0,14,0,748,0,0,'290/2021','SHAHUL HAMEED'),(1317,82,'2022-02-04 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,9384,0,0,56,0,9328,0,0,'75/2019','UNNIKRISHNAN'),(1318,83,'2022-02-04 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8999,0,0,56,0,8943,0,0,'75/2019','UNNIKRISHNAN'),(1319,68,'2022-02-04 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,251,0,0,56,0,195,0,0,'75/2019','UNNIKRISHNAN'),(1320,46,'2022-02-04 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,4769,0,0,112,0,4657,0,0,'75/2019','UNNIKRISHNAN'),(1321,92,'2022-02-04 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Edit','Edit stock',0,0,0,0,0,0,100,0,0,'',''),(1322,92,'2022-02-04 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,100,0,0,1,0,99,0,0,'05/2022','SHAMEERALI'),(1323,49,'2022-02-04 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,979,0,0,28,0,951,0,0,'05/2022','SHAMEERALI'),(1324,71,'2022-02-04 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,391,0,0,28,0,363,0,0,'05/2022','SHAMEERALI'),(1325,47,'2022-02-04 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,951,0,0,42,0,909,0,0,'45/2017','KORAN'),(1326,48,'2022-02-04 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,930,0,0,42,0,888,0,0,'45/2017','KORAN'),(1327,5,'2022-02-04 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,699,0,0,7,0,692,0,0,'14/2021','PRIYA'),(1328,6,'2022-02-04 00:00:00','M6','ESCITALOPRAM TABLETS 20MG','Transfer','Sub to OP',0,1000,0,0,21,0,979,0,0,'14/2021','PRIYA'),(1329,82,'2022-02-04 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,9328,0,0,42,0,9286,0,0,'205/2019','SUBAIDA'),(1330,27,'2022-02-04 00:00:00','M27','LURASIDONE HCL TABLETS 40MG','Transfer','Sub to OP',0,888,0,0,21,0,867,0,0,'205/2019','SUBAIDA'),(1331,81,'2022-02-11 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,9811,0,0,28,0,9783,0,0,'250/2021','HASEENA '),(1332,83,'2022-02-11 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8943,0,0,28,0,8915,0,0,'250/2021','HASEENA '),(1333,12,'2022-02-11 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,503,0,0,28,0,475,0,0,'250/2021','HASEENA '),(1334,69,'2022-02-11 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,447,0,0,28,0,419,0,0,'250/2021','HASEENA '),(1335,81,'2022-03-11 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,9783,0,0,21,0,9762,0,0,'250/2021','HASEENA '),(1336,83,'2022-03-11 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8915,0,0,21,0,8894,0,0,'250/2021','HASEENA '),(1337,12,'2022-03-11 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,475,0,0,21,0,454,0,0,'250/2021','HASEENA '),(1338,69,'2022-03-11 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,419,0,0,21,0,398,0,0,'250/2021','HASEENA '),(1339,37,'2022-02-18 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Transfer','Sub to OP',0,547,0,0,252,0,295,0,0,'104/2018','HASEENA'),(1340,81,'2022-02-18 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,9762,0,0,42,0,9720,0,0,'104/2018','HASEENA'),(1341,28,'2022-02-25 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,654,0,0,56,0,598,0,0,'79/2021','HAMEED'),(1342,83,'2022-02-25 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8894,0,0,28,0,8866,0,0,'79/2021','HAMEED'),(1343,4,'2022-02-25 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,524,0,0,28,0,496,0,0,'79/2021','HAMEED'),(1344,70,'2022-02-25 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,198,0,0,28,0,170,0,0,'263/2021','FATHIMMA PP'),(1345,4,'2022-02-25 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,496,0,0,28,0,468,0,0,'263/2021','FATHIMMA PP'),(1346,19,'2022-02-18 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,825,0,0,42,0,783,0,0,'112/2018','FOUSIYA'),(1347,37,'2022-02-18 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Transfer','Sub to OP',0,295,0,0,168,0,127,0,0,'112/2018','FOUSIYA'),(1348,81,'2022-03-11 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,9720,0,0,56,0,9664,0,0,'83/2019','FARSANA THASNI'),(1349,84,'2022-03-11 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,664,0,0,56,0,608,0,0,'83/2019','FARSANA THASNI'),(1350,59,'2022-03-11 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Transfer','Sub to OP',0,825,0,0,28,0,797,0,0,'83/2019','FARSANA THASNI'),(1351,57,'2022-03-11 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Transfer','Sub to OP',0,720,0,0,28,0,692,0,0,'83/2019','FARSANA THASNI'),(1352,49,'2022-02-11 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,951,0,0,56,0,895,0,0,'38/2017','UNNEENKUTTY'),(1353,47,'2022-02-11 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,909,0,0,56,0,853,0,0,'38/2017','UNNEENKUTTY'),(1354,83,'2022-02-11 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8866,0,0,56,0,8810,0,0,'38/2017','UNNEENKUTTY'),(1355,46,'2022-02-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,4657,0,0,84,0,4573,0,0,'38/2017','UNNEENKUTTY'),(1356,26,'2022-02-11 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,636,0,0,56,0,580,0,0,'38/2017','UNNEENKUTTY'),(1357,25,'2022-02-11 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,755,0,0,28,0,727,0,0,'38/2017','UNNEENKUTTY'),(1358,49,'2022-03-18 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,895,0,0,56,0,839,0,0,'38/2017','UNNEENKUTTY'),(1359,47,'2022-03-18 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,853,0,0,84,0,769,0,0,'38/2017','UNNEENKUTTY'),(1360,83,'2022-03-18 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8810,0,0,56,0,8754,0,0,'38/2017','UNNEENKUTTY'),(1361,46,'2022-03-18 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,4573,0,0,84,0,4489,0,0,'38/2017','UNNEENKUTTY'),(1362,26,'2022-03-18 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,580,0,0,56,0,524,0,0,'38/2017','UNNEENKUTTY'),(1363,25,'2022-03-18 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,727,0,0,28,0,699,0,0,'38/2017','UNNEENKUTTY'),(1364,5,'2022-02-18 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,692,0,0,28,0,664,0,0,'168/2021','FATHIMAKUTTY'),(1365,5,'2022-02-25 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,664,0,0,28,0,636,0,0,'168/2021','FATHIMAKUTTY'),(1366,82,'2022-02-04 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,9286,0,0,56,0,9230,0,0,'8/2014','DHANISHMA'),(1367,82,'2022-03-04 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,9230,0,0,70,0,9160,0,0,'8/2014','DHANISHMA'),(1368,47,'2022-02-18 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,769,0,0,35,0,734,0,0,'92/2018','CHEKUTTI'),(1369,48,'2022-02-18 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,888,0,0,35,0,853,0,0,'92/2018','CHEKUTTI'),(1370,83,'2022-02-18 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8754,0,0,70,0,8684,0,0,'92/2018','CHEKUTTI'),(1371,68,'2022-02-18 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,195,0,0,35,0,160,0,0,'92/2018','CHEKUTTI'),(1372,95,'2022-02-18 00:00:00','M95','TRIFLUOPERAZINE TABLETS IP 5MG','Transfer','Sub to OP',0,315,0,0,70,0,245,0,0,'92/2018','CHEKUTTI'),(1373,69,'2022-02-11 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,398,0,0,21,0,377,0,0,'135/2020','ALAVI'),(1374,12,'2022-02-11 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,454,0,0,21,0,433,0,0,'135/2020','ALAVI'),(1375,82,'2022-02-11 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,9160,0,0,42,0,9118,0,0,'135/2020','ALAVI'),(1376,83,'2022-02-11 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8684,0,0,21,0,8663,0,0,'26/2017','ABDURAHMAN'),(1377,85,'2022-02-18 00:00:00','M85','LEVETIRACETAM TABLETS 250 MG','Transfer','Sub to OP',0,916,0,0,112,0,804,0,0,'44/2017','ABUBAKAR'),(1378,34,'2022-02-18 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,734,0,0,56,0,678,0,0,'44/2017','ABUBAKAR'),(1379,48,'2022-02-25 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,853,0,0,28,0,825,0,0,'48/2017','ABDUL HASEEB'),(1380,47,'2022-02-25 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,734,0,0,28,0,706,0,0,'48/2017','ABDUL HASEEB'),(1381,71,'2022-02-25 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,363,0,0,28,0,335,0,0,'48/2017','ABDUL HASEEB'),(1382,70,'2022-02-25 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,170,0,0,28,0,142,0,0,'48/2017','ABDUL HASEEB'),(1383,46,'2022-02-25 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,4489,0,0,84,0,4405,0,0,'48/2017','ABDUL HASEEB'),(1384,34,'2022-02-25 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,678,0,0,56,0,622,0,0,'48/2017','ABDUL HASEEB'),(1385,68,'2022-02-25 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,160,0,0,56,0,104,0,0,'292/2021','ABDUL NAZAR'),(1386,69,'2022-02-25 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,377,0,0,28,0,349,0,0,'292/2021','ABDUL NAZAR'),(1387,70,'2022-02-25 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,142,0,0,28,0,114,0,0,'292/2021','ABDUL NAZAR'),(1388,92,'2022-02-18 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,99,0,0,1,0,98,0,0,'144/2019','JAMSHI'),(1389,46,'2022-02-18 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,4405,0,0,28,0,4377,0,0,'144/2019','JAMSHI'),(1390,36,'2022-02-25 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,951,0,0,14,0,937,0,0,'144/2019','JAMSHI'),(1391,92,'2022-02-25 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,98,0,0,1,0,97,0,0,'144/2019','JAMSHI'),(1392,46,'2022-02-25 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,4377,0,0,14,0,4363,0,0,'144/2019','JAMSHI'),(1393,92,'2022-03-18 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,97,0,0,1,0,96,0,0,'144/2019','JAMSHI'),(1394,46,'2022-03-18 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,4363,0,0,28,0,4335,0,0,'144/2019','JAMSHI'),(1395,93,'2022-03-18 00:00:00','M93','FLUPHENAZINE DECANOATE INJECTION IP 1ML','Transfer','Sub to OP',0,994,0,0,2,0,992,0,0,'144/2019','JAMSHI'),(1396,36,'2022-02-11 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,937,0,0,21,0,916,0,0,'02/2022','GIRIJA'),(1397,46,'2022-02-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,4335,0,0,21,0,4314,0,0,'02/2022','GIRIJA'),(1398,36,'2022-03-03 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,916,0,0,42,0,874,0,0,'02/2022','GIRIJA'),(1399,46,'2022-03-03 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,4314,0,0,42,0,4272,0,0,'02/2022','GIRIJA'),(1400,46,'2022-03-18 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,4272,0,0,14,0,4258,0,0,'02/2022','GIRIJA'),(1401,69,'2022-03-18 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,349,0,0,14,0,335,0,0,'02/2022','GIRIJA'),(1402,8,'2022-03-18 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Transfer','Sub to OP',0,818,0,0,42,0,776,0,0,'63/2018','BABY'),(1403,9,'2022-03-18 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,692,0,0,42,0,650,0,0,'63/2018','BABY'),(1404,35,'2022-02-18 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,748,0,0,35,0,713,0,0,'088/2017','MUHAMMAD RAFEEQ'),(1405,36,'2022-02-18 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,874,0,0,35,0,839,0,0,'088/2017','MUHAMMAD RAFEEQ'),(1406,46,'2022-02-18 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,4258,0,0,35,0,4223,0,0,'088/2017','MUHAMMAD RAFEEQ'),(1407,33,'2022-03-18 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1000,0,0,35,0,965,0,0,'0112/2017','ZEHARABI'),(1408,9,'2022-03-18 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,650,0,0,70,0,580,0,0,'88/2017','MUHAMMAD RAFI'),(1409,46,'2022-03-18 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,4223,0,0,35,0,4188,0,0,'88/2017','MUHAMMAD RAFI'),(1410,49,'2022-03-18 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,839,0,0,35,0,804,0,0,'88/2017','MUHAMMAD RAFI'),(1411,47,'2022-03-18 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,706,0,0,35,0,671,0,0,'88/2017','MUHAMMAD RAFI'),(1412,45,'2022-02-18 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,832,0,0,112,0,720,0,0,'211/2019','RAJAN'),(1413,87,'2022-02-18 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Transfer','Sub to OP',0,828,0,0,84,0,744,0,0,'211/2019','RAJAN'),(1414,81,'2022-02-18 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,9664,0,0,112,0,9552,0,0,'211/2019','RAJAN'),(1415,46,'2022-02-18 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,4188,0,0,168,0,4020,0,0,'211/2019','RAJAN'),(1416,36,'2022-02-18 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,839,0,0,56,0,783,0,0,'211/2019','RAJAN'),(1417,5,'2022-02-18 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,636,0,0,56,0,580,0,0,'211/2019','RAJAN'),(1418,71,'2021-07-02 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,335,0,0,56,0,279,0,0,'49/2017','RUKKIYA'),(1419,70,'2021-07-02 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,114,0,0,56,0,58,0,0,'49/2017','RUKKIYA'),(1420,70,'2021-08-27 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,58,0,0,56,0,2,0,0,'49/2017','RUKKIYA'),(1421,71,'2021-08-27 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,279,0,0,56,0,223,0,0,'49/2017','RUKKIYA'),(1422,70,'2022-03-24 00:00:00','M70','QUETIAPINE TABLETS 25MG','Edit','Edit stock',0,2,0,0,0,0,20000,0,0,'',''),(1423,68,'2022-03-24 00:00:00','M68','OLANZAPINE TABLETS 10MG','Edit','Edit stock',0,104,0,0,0,0,20000,0,0,'',''),(1424,70,'2022-03-04 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,20000,0,0,84,0,19916,0,0,'49/2017','RUKKIYA'),(1425,71,'2022-03-04 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,223,0,0,84,0,139,0,0,'49/2017','RUKKIYA'),(1426,5,'2022-02-11 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,580,0,0,28,0,552,0,0,'04/2022','BIJU'),(1427,3,'2022-02-11 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,913,0,0,28,0,885,0,0,'04/2022','BIJU'),(1428,64,'2022-02-11 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Transfer','Sub to OP',0,954,0,0,28,0,926,0,0,'04/2022','BIJU'),(1429,5,'2022-03-11 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,552,0,0,7,0,545,0,0,'04/2022','BIJU'),(1430,4,'2022-03-11 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,468,0,0,7,0,461,0,0,'04/2022','BIJU'),(1431,65,'2022-03-11 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,678,0,0,7,0,671,0,0,'04/2022','BIJU'),(1432,3,'2022-03-11 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,885,0,0,7,0,878,0,0,'04/2022','BIJU'),(1433,5,'2022-03-18 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,545,0,0,42,0,503,0,0,'04/2022','BIJU'),(1434,4,'2022-03-18 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,461,0,0,42,0,419,0,0,'04/2022','BIJU'),(1435,65,'2022-03-18 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,671,0,0,42,0,629,0,0,'04/2022','BIJU'),(1436,92,'2022-03-18 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,96,0,0,2,0,94,0,0,'291/2021','AMINA'),(1437,92,'2022-02-18 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,94,0,0,1,0,93,0,0,'291/2021','AMINA'),(1438,20,'2021-10-08 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,832,0,0,42,0,790,0,0,'44/2020','MOHAMMAD ASHIQ'),(1439,22,'2021-10-08 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,930,0,0,42,0,888,0,0,'44/2020','MOHAMMAD ASHIQ'),(1440,56,'2021-10-08 00:00:00','M56','CLOMIPRAMINE TABLETS 25MG','Transfer','Sub to OP',0,874,0,0,220,0,654,0,0,'44/2020','MOHAMMAD ASHIQ'),(1441,12,'2022-02-18 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,433,0,0,42,0,391,0,0,'67/2021','ANEESHA'),(1442,33,'2022-02-18 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,965,0,0,21,0,944,0,0,'67/2021','ANEESHA'),(1443,82,'2022-03-18 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,9118,0,0,42,0,9076,0,0,'287/2021','AYISHA'),(1444,83,'2022-03-18 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8663,0,0,42,0,8621,0,0,'287/2021','AYISHA'),(1445,34,'2022-03-18 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,622,0,0,126,0,496,0,0,'287/2021','AYISHA'),(1446,46,'2022-03-18 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,4020,0,0,84,0,3936,0,0,'287/2021','AYISHA'),(1447,50,'2022-03-18 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,1000,0,0,42,0,958,0,0,'01/2018','ABDUL NAZAR'),(1448,83,'2022-03-18 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8621,0,0,84,0,8537,0,0,'01/2018','ABDUL NAZAR'),(1449,68,'2022-03-18 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,20000,0,0,42,0,19958,0,0,'01/2018','ABDUL NAZAR'),(1450,67,'2022-03-18 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,748,0,0,42,0,706,0,0,'01/2018','ABDUL NAZAR'),(1451,12,'2022-03-18 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,391,0,0,42,0,349,0,0,'01/2018','ABDUL NAZAR'),(1452,28,'2022-02-11 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,598,0,0,49,0,549,0,0,'04/2018','ABDUL SAMAD'),(1453,46,'2022-02-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,3936,0,0,28,0,3908,0,0,'04/2018','ABDUL SAMAD'),(1454,39,'2022-02-11 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Transfer','Sub to OP',0,186,0,0,28,0,158,0,0,'04/2018','ABDUL SAMAD'),(1455,28,'2022-03-11 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,549,0,0,84,0,465,0,0,'04/2018','ABDUL SAMAD'),(1456,39,'2022-03-11 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Transfer','Sub to OP',0,158,0,0,56,0,102,0,0,'04/2018','ABDUL SAMAD'),(1457,72,'2022-03-04 00:00:00','M72','QUETIAPINE TABLETS 100MG','Transfer','Sub to OP',0,636,0,0,70,0,566,0,0,'182/2021','MOHAMMAD BASHEER'),(1458,46,'2022-03-04 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,3908,0,0,210,0,3698,0,0,'182/2021','MOHAMMAD BASHEER'),(1459,83,'2022-03-04 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8537,0,0,140,0,8397,0,0,'182/2021','MOHAMMAD BASHEER'),(1460,25,'2022-03-04 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,699,0,0,70,0,629,0,0,'182/2021','MOHAMMAD BASHEER'),(1461,26,'2022-03-04 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,524,0,0,70,0,454,0,0,'182/2021','MOHAMMAD BASHEER'),(1462,48,'2022-03-04 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,825,0,0,70,0,755,0,0,'182/2021','MOHAMMAD BASHEER'),(1463,93,'2022-03-03 00:00:00','M93','FLUPHENAZINE DECANOATE INJECTION IP 1ML','Transfer','Sub to OP',0,992,0,0,2,0,990,0,0,'231/2021','MUHAMMAD IQBAL'),(1464,46,'2022-03-03 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,3698,0,0,14,0,3684,0,0,'231/2021','MUHAMMAD IQBAL'),(1465,92,'2022-03-03 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,93,0,0,1,0,92,0,0,'231/2021','MUHAMMAD IQBAL'),(1466,49,'2022-03-03 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,804,0,0,14,0,790,0,0,'231/2021','MUHAMMAD IQBAL'),(1467,11,'2022-03-03 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,12,0,0,1,0,11,0,0,'231/2021','MUHAMMAD IQBAL'),(1468,93,'2022-03-18 00:00:00','M93','FLUPHENAZINE DECANOATE INJECTION IP 1ML','Transfer','Sub to OP',0,990,0,0,4,0,986,0,0,'231/2021','MUHAMMAD IQBAL'),(1469,46,'2022-03-18 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,3684,0,0,56,0,3628,0,0,'231/2021','MUHAMMAD IQBAL'),(1470,92,'2022-03-18 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,92,0,0,3,0,89,0,0,'231/2021','MUHAMMAD IQBAL'),(1471,49,'2022-03-18 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,790,0,0,26,0,764,0,0,'231/2021','MUHAMMAD IQBAL'),(1472,11,'2022-03-18 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,11,0,0,4,0,7,0,0,'231/2021','MUHAMMAD IQBAL'),(1473,70,'2022-03-18 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19916,0,0,56,0,19860,0,0,'89/2018','MUHAMMAD'),(1474,71,'2022-03-18 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,139,0,0,56,0,83,0,0,'89/2018','MUHAMMAD'),(1475,58,'2022-03-18 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Transfer','Sub to OP',0,860,0,0,112,0,748,0,0,'89/2018','MUHAMMAD'),(1476,24,'2022-03-18 00:00:00','M24','GABAPENTIN TABLETS 100MG','Transfer','Sub to OP',0,930,0,0,56,0,874,0,0,'89/2018','MUHAMMAD'),(1477,65,'2022-02-11 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,629,0,0,84,0,545,0,0,'59/2021','KUNJUMUHAMMAD'),(1478,19,'2022-02-11 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,783,0,0,42,0,741,0,0,'59/2021','KUNJUMUHAMMAD'),(1479,20,'2022-02-11 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,790,0,0,84,0,706,0,0,'59/2021','KUNJUMUHAMMAD'),(1480,47,'2022-03-18 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,671,0,0,70,0,601,0,0,'45/2017','KORAN'),(1481,48,'2022-03-18 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,755,0,0,70,0,685,0,0,'45/2017','KORAN'),(1482,71,'2022-02-11 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,83,0,0,28,0,55,0,0,'078/2021','MANIKANDAN'),(1483,70,'2022-02-11 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19860,0,0,28,0,19832,0,0,'078/2021','MANIKANDAN'),(1484,37,'2022-02-11 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Transfer','Sub to OP',0,127,0,0,28,0,99,0,0,'078/2021','MANIKANDAN'),(1485,36,'2022-02-11 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,783,0,0,56,0,727,0,0,'078/2021','MANIKANDAN'),(1486,46,'2022-02-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,3628,0,0,28,0,3600,0,0,'078/2021','MANIKANDAN'),(1487,68,'2022-02-11 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,19958,0,0,56,0,19902,0,0,'54/2017','PUSHPAVATHI'),(1488,82,'2022-02-11 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,9076,0,0,56,0,9020,0,0,'54/2017','PUSHPAVATHI'),(1489,83,'2022-02-11 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8397,0,0,56,0,8341,0,0,'54/2017','PUSHPAVATHI'),(1490,46,'2022-02-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,3600,0,0,56,0,3544,0,0,'54/2017','PUSHPAVATHI'),(1491,8,'2022-02-11 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Transfer','Sub to OP',0,776,0,0,56,0,720,0,0,'54/2017','PUSHPAVATHI'),(1492,64,'2022-03-18 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Transfer','Sub to OP',0,926,0,0,28,0,898,0,0,'161/2019','ASHRAF CP'),(1493,69,'2022-03-18 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,335,0,0,56,0,279,0,0,'161/2019','ASHRAF CP'),(1494,89,'2022-03-18 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,982,0,0,14,0,968,0,0,'161/2019','ASHRAF CP'),(1495,44,'2022-03-18 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Transfer','Sub to OP',0,497,0,0,112,0,385,0,0,'161/2019','ASHRAF CP'),(1496,21,'2022-03-18 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,559,0,0,112,0,447,0,0,'161/2019','ASHRAF CP'),(1497,12,'2022-01-28 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,349,0,0,21,0,328,0,0,'248/2021','RAMLA'),(1498,12,'2022-02-25 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,328,0,0,28,0,300,0,0,'248/2021','RAMLA'),(1499,35,'2022-02-11 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,713,0,0,28,0,685,0,0,'77/2021','VIJAYAKUMARI'),(1500,36,'2022-02-11 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,727,0,0,28,0,699,0,0,'77/2021','VIJAYAKUMARI'),(1501,83,'2022-02-11 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8341,0,0,56,0,8285,0,0,'77/2021','VIJAYAKUMARI'),(1502,47,'2022-02-11 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,601,0,0,28,0,573,0,0,'77/2021','VIJAYAKUMARI'),(1503,46,'2022-02-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,3544,0,0,84,0,3460,0,0,'77/2021','VIJAYAKUMARI'),(1504,34,'2022-03-11 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,496,0,0,84,0,412,0,0,'106/2017','VIJAYALAKSHMI'),(1505,46,'2022-03-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,3460,0,0,84,0,3376,0,0,'106/2017','VIJAYALAKSHMI'),(1506,46,'2022-03-25 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,3376,0,0,56,0,3320,0,0,'088/2017','MUHAMMAD RAFEEQ'),(1507,35,'2022-03-25 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,685,0,0,56,0,629,0,0,'088/2017','MUHAMMAD RAFEEQ'),(1508,36,'2022-03-25 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,699,0,0,56,0,643,0,0,'088/2017','MUHAMMAD RAFEEQ'),(1509,82,'2022-02-25 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,9020,0,0,56,0,8964,0,0,'205/2019','SUBAIDA'),(1510,27,'2022-02-25 00:00:00','M27','LURASIDONE HCL TABLETS 40MG','Transfer','Sub to OP',0,867,0,0,28,0,839,0,0,'205/2019','SUBAIDA'),(1511,27,'2022-03-25 00:00:00','M27','LURASIDONE HCL TABLETS 40MG','Transfer','Sub to OP',0,839,0,0,56,0,783,0,0,'205/2019','SUBAIDA'),(1512,82,'2022-03-25 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,8964,0,0,112,0,8852,0,0,'205/2019','SUBAIDA'),(1513,5,'2022-03-25 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,503,0,0,42,0,461,0,0,'168/2021','FATHIMAKUTTY'),(1514,72,'2022-03-25 00:00:00','M72','QUETIAPINE TABLETS 100MG','Transfer','Sub to OP',0,566,0,0,56,0,510,0,0,'137/2017','MUJEEBRAHMAN'),(1515,70,'2022-03-25 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19832,0,0,56,0,19776,0,0,'137/2017','MUJEEBRAHMAN'),(1516,83,'2022-03-25 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8285,0,0,112,0,8173,0,0,'137/2017','MUJEEBRAHMAN'),(1517,26,'2022-03-25 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,454,0,0,56,0,398,0,0,'137/2017','MUJEEBRAHMAN'),(1518,25,'2022-03-25 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,629,0,0,56,0,573,0,0,'137/2017','MUJEEBRAHMAN'),(1519,46,'2022-03-25 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,3320,0,0,168,0,3152,0,0,'137/2017','MUJEEBRAHMAN'),(1520,76,'2022-03-25 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,734,0,0,56,0,678,0,0,'137/2017','MUJEEBRAHMAN'),(1521,47,'2022-05-06 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,573,0,0,84,0,489,0,0,'45/2017','KORAN'),(1522,48,'2022-05-06 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,685,0,0,84,0,601,0,0,'45/2017','KORAN'),(1523,11,'2022-02-18 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,7,0,0,2,0,5,0,0,'52/2022','ISMAIL'),(1524,92,'2022-02-18 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,89,0,0,1,0,88,0,0,'52/2022','ISMAIL'),(1525,92,'2022-03-04 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,88,0,0,2,0,86,0,0,'52/2022','ISMAIL'),(1526,11,'2022-03-04 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,5,0,0,2,0,3,0,0,'52/2022','ISMAIL'),(1527,92,'2022-03-18 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,86,0,0,4,0,82,0,0,'52/2022','ISMAIL'),(1528,11,'2022-03-18 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,3,0,0,3,0,0,0,0,'52/2022','ISMAIL'),(1529,11,'2022-06-25 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Edit','Edit stock',0,0,0,0,0,0,1000,0,0,'',''),(1530,92,'2022-06-10 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,82,0,0,2,0,80,0,0,'52/2022','ISMAIL'),(1531,11,'2022-06-10 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,1000,0,0,2,0,998,0,0,'52/2022','ISMAIL'),(1532,92,'2022-06-24 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,80,0,0,4,0,76,0,0,'52/2022','ISMAIL'),(1533,11,'2022-06-24 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,998,0,0,4,0,994,0,0,'52/2022','ISMAIL'),(1534,28,'2022-03-25 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,465,0,0,112,0,353,0,0,'79/2021','HAMEED'),(1535,83,'2022-03-25 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8173,0,0,56,0,8117,0,0,'79/2021','HAMEED'),(1536,4,'2022-03-25 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,419,0,0,56,0,363,0,0,'79/2021','HAMEED'),(1537,28,'2022-04-08 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,353,0,0,56,0,297,0,0,'79/2021','HAMEED'),(1538,83,'2022-04-08 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8117,0,0,28,0,8089,0,0,'79/2021','HAMEED'),(1539,4,'2022-04-08 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,363,0,0,28,0,335,0,0,'79/2021','HAMEED'),(1540,28,'2022-05-06 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,297,0,0,112,0,185,0,0,'79/2021','HAMEED'),(1541,83,'2022-05-06 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8089,0,0,56,0,8033,0,0,'79/2021','HAMEED'),(1542,4,'2022-05-06 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,335,0,0,56,0,279,0,0,'79/2021','HAMEED'),(1543,81,'2022-04-01 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,9552,0,0,56,0,9496,0,0,'250/2021','HASEENA '),(1544,83,'2022-04-01 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,8033,0,0,56,0,7977,0,0,'250/2021','HASEENA '),(1545,12,'2022-04-01 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,300,0,0,56,0,244,0,0,'250/2021','HASEENA '),(1546,69,'2022-04-01 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,279,0,0,56,0,223,0,0,'250/2021','HASEENA '),(1547,69,'2022-05-27 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,223,0,0,4,0,219,0,0,'250/2021','HASEENA '),(1548,81,'2022-05-27 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,9496,0,0,7,0,9489,0,0,'250/2021','HASEENA '),(1549,83,'2022-05-27 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,7977,0,0,7,0,7970,0,0,'250/2021','HASEENA '),(1550,22,'2022-05-27 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,888,0,0,7,0,881,0,0,'250/2021','HASEENA '),(1551,81,'2022-06-03 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,9489,0,0,21,0,9468,0,0,'250/2021','HASEENA '),(1552,83,'2022-06-03 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,7970,0,0,21,0,7949,0,0,'250/2021','HASEENA '),(1553,12,'2022-06-03 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,244,0,0,21,0,223,0,0,'250/2021','HASEENA '),(1554,69,'2022-06-03 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,219,0,0,21,0,198,0,0,'250/2021','HASEENA '),(1555,19,'2022-06-24 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,741,0,0,14,0,727,0,0,'250/2021','HASEENA '),(1556,81,'2022-06-24 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,9468,0,0,14,0,9454,0,0,'250/2021','HASEENA '),(1557,83,'2022-06-24 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,7949,0,0,14,0,7935,0,0,'250/2021','HASEENA '),(1558,12,'2022-06-24 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,223,0,0,14,0,209,0,0,'250/2021','HASEENA '),(1559,69,'2022-06-24 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,198,0,0,14,0,184,0,0,'250/2021','HASEENA '),(1560,37,'2022-06-25 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Edit','Edit stock',0,99,0,0,0,0,100000,0,0,'',''),(1561,37,'2022-05-13 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Transfer','Sub to OP',0,100000,0,0,252,0,99748,0,0,'104/2018','HASEENA'),(1562,81,'2022-05-13 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,9454,0,0,84,0,9370,0,0,'104/2018','HASEENA'),(1563,69,'2022-04-01 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,184,0,0,56,0,128,0,0,'02/2022','GIRIJA'),(1564,46,'2022-04-01 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,3152,0,0,14,0,3138,0,0,'02/2022','GIRIJA'),(1565,68,'2022-05-06 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,19902,0,0,56,0,19846,0,0,'02/2022','GIRIJA'),(1566,46,'2022-05-06 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,3138,0,0,28,0,3110,0,0,'02/2022','GIRIJA'),(1567,37,'2022-05-27 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Transfer','Sub to OP',0,99748,0,0,112,0,99636,0,0,'07/2017','FATHIMMA'),(1568,19,'2022-05-27 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,727,0,0,56,0,671,0,0,'07/2017','FATHIMMA'),(1569,70,'2022-03-25 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19776,0,0,56,0,19720,0,0,'263/2021','FATHIMMA PP'),(1570,4,'2022-03-25 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,279,0,0,56,0,223,0,0,'263/2021','FATHIMMA PP'),(1571,71,'2022-06-25 00:00:00','M71','QUETIAPINE TABLETS 50MG','Edit','Edit stock',0,55,0,0,0,0,10000,0,0,'',''),(1572,71,'2022-05-20 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,10000,0,0,70,0,9930,0,0,'263/2021','FATHIMMA PP'),(1573,4,'2022-05-20 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,223,0,0,70,0,153,0,0,'263/2021','FATHIMMA PP'),(1574,81,'2022-04-08 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,9370,0,0,112,0,9258,0,0,'83/2019','FARSANA THASNI'),(1575,84,'2022-04-08 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,608,0,0,112,0,496,0,0,'83/2019','FARSANA THASNI'),(1576,59,'2022-04-08 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Transfer','Sub to OP',0,797,0,0,56,0,741,0,0,'83/2019','FARSANA THASNI'),(1577,57,'2022-04-08 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Transfer','Sub to OP',0,692,0,0,56,0,636,0,0,'83/2019','FARSANA THASNI'),(1578,83,'2022-06-10 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,7935,0,0,56,0,7879,0,0,'83/2019','FARSANA THASNI'),(1579,84,'2022-06-10 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,496,0,0,56,0,440,0,0,'83/2019','FARSANA THASNI'),(1580,59,'2022-06-10 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Transfer','Sub to OP',0,741,0,0,28,0,713,0,0,'83/2019','FARSANA THASNI'),(1581,57,'2022-06-10 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Transfer','Sub to OP',0,636,0,0,28,0,608,0,0,'83/2019','FARSANA THASNI'),(1582,58,'2022-05-20 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Transfer','Sub to OP',0,748,0,0,84,0,664,0,0,'206/2021','FARHANA SHIRIL'),(1583,34,'2022-05-20 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,412,0,0,42,0,370,0,0,'206/2021','FARHANA SHIRIL'),(1584,82,'2022-03-25 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,8852,0,0,84,0,8768,0,0,'059/2021','YASHODHA'),(1585,83,'2022-03-25 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,7879,0,0,84,0,7795,0,0,'059/2021','YASHODHA'),(1586,70,'2022-03-25 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19720,0,0,84,0,19636,0,0,'059/2021','YASHODHA'),(1587,82,'2022-06-17 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,8768,0,0,84,0,8684,0,0,'059/2021','YASHODHA'),(1588,83,'2022-06-17 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,7795,0,0,84,0,7711,0,0,'059/2021','YASHODHA'),(1589,70,'2022-06-17 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19636,0,0,84,0,19552,0,0,'059/2021','YASHODHA'),(1590,81,'2022-02-25 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,9258,0,0,7,0,9251,0,0,'232/2021','USMAN'),(1591,83,'2022-02-25 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,7711,0,0,7,0,7704,0,0,'232/2021','USMAN'),(1592,36,'2022-02-25 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,643,0,0,7,0,636,0,0,'232/2021','USMAN'),(1593,46,'2022-02-25 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,3110,0,0,21,0,3089,0,0,'232/2021','USMAN'),(1594,47,'2022-02-25 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,489,0,0,7,0,482,0,0,'232/2021','USMAN'),(1595,48,'2022-03-04 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,601,0,0,28,0,573,0,0,'232/2021','USMAN'),(1596,46,'2022-03-04 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,3089,0,0,84,0,3005,0,0,'232/2021','USMAN'),(1597,81,'2022-03-04 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,9251,0,0,28,0,9223,0,0,'232/2021','USMAN'),(1598,83,'2022-03-04 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,7704,0,0,28,0,7676,0,0,'232/2021','USMAN'),(1599,36,'2022-03-04 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,636,0,0,28,0,608,0,0,'232/2021','USMAN'),(1600,83,'2022-04-01 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,7676,0,0,42,0,7634,0,0,'232/2021','USMAN'),(1601,81,'2022-04-01 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,9223,0,0,42,0,9181,0,0,'232/2021','USMAN'),(1602,36,'2022-04-01 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,608,0,0,42,0,566,0,0,'232/2021','USMAN'),(1603,46,'2022-04-01 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,3005,0,0,124,0,2881,0,0,'232/2021','USMAN'),(1604,48,'2022-04-01 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,573,0,0,42,0,531,0,0,'232/2021','USMAN'),(1605,81,'2022-05-13 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,9181,0,0,42,0,9139,0,0,'232/2021','USMAN'),(1606,36,'2022-05-13 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,566,0,0,42,0,524,0,0,'232/2021','USMAN'),(1607,46,'2022-05-13 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,2881,0,0,124,0,2757,0,0,'232/2021','USMAN'),(1608,48,'2022-05-13 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,531,0,0,42,0,489,0,0,'232/2021','USMAN'),(1609,81,'2022-06-24 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,9139,0,0,14,0,9125,0,0,'232/2021','USMAN'),(1610,83,'2022-06-24 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,7634,0,0,14,0,7620,0,0,'232/2021','USMAN'),(1611,46,'2022-06-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,2757,0,0,42,0,2715,0,0,'232/2021','USMAN'),(1612,48,'2022-06-24 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,489,0,0,14,0,475,0,0,'232/2021','USMAN'),(1613,34,'2022-04-15 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,370,0,0,28,0,342,0,0,'36/2020','UMMUHABEEBA'),(1614,35,'2022-04-15 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,629,0,0,28,0,601,0,0,'36/2020','UMMUHABEEBA'),(1615,49,'2022-04-15 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,764,0,0,28,0,736,0,0,'36/2020','UMMUHABEEBA'),(1616,46,'2022-04-15 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,2715,0,0,56,0,2659,0,0,'36/2020','UMMUHABEEBA'),(1617,82,'2022-04-15 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,8684,0,0,84,0,8600,0,0,'36/2020','UMMUHABEEBA'),(1618,9,'2022-08-08 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Edit','Edit stock',0,580,0,0,0,0,3000,0,0,'',''),(1619,10,'2022-08-08 00:00:00','M10','AMISULPRIDE TABLETS 200MG','Edit','Edit stock',0,916,0,0,0,0,3000,0,0,'',''),(1620,8,'2022-08-08 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Edit','Edit stock',0,720,0,0,0,0,3000,0,0,'',''),(1621,15,'2022-08-08 00:00:00','M15','AMITRIPTYLINE TABLETS 10MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1622,17,'2022-08-08 00:00:00','M17','AMITRIPTYLINE TABLETS 25MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1623,19,'2022-08-08 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Edit','Edit stock',0,671,0,0,0,0,3000,0,0,'',''),(1624,18,'2022-08-08 00:00:00','M18','BUPROPION HCL EXTENDED RELEASE TABLETS 150MG','Edit','Edit stock',0,30,0,0,0,0,3000,0,0,'',''),(1625,59,'2022-08-08 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Edit','Edit stock',0,713,0,0,0,0,3000,0,0,'',''),(1626,58,'2022-08-08 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Edit','Edit stock',0,664,0,0,0,0,3000,0,0,'',''),(1627,57,'2022-08-08 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Edit','Edit stock',0,608,0,0,0,0,3000,0,0,'',''),(1628,86,'2022-08-08 00:00:00','M86','CLOBAZAM TABLETS 10 MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1629,87,'2022-08-08 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Edit','Edit stock',0,744,0,0,0,0,3000,0,0,'',''),(1630,56,'2022-08-08 00:00:00','M56','CLOMIPRAMINE TABLETS 25MG','Edit','Edit stock',0,654,0,0,0,0,3000,0,0,'',''),(1631,88,'2022-08-08 00:00:00','M88','CLONAZEPAM & ESCITALOPRAM OXALATE TABLETS 5 MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1632,3,'2022-08-08 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Edit','Edit stock',0,878,0,0,0,0,3000,0,0,'',''),(1633,89,'2022-08-08 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Edit','Edit stock',0,968,0,0,0,0,3000,0,0,'',''),(1634,49,'2022-08-08 00:00:00','M49','CLOZAPINE TABLETS 100MG','Edit','Edit stock',0,736,0,0,0,0,3000,0,0,'',''),(1635,50,'2022-08-08 00:00:00','M50','CLOZAPINE TABLETS 200MG','Edit','Edit stock',0,958,0,0,0,0,3000,0,0,'',''),(1636,47,'2022-08-08 00:00:00','M47','CLOZAPINE TABLETS 25MG','Edit','Edit stock',0,482,0,0,0,0,3000,0,0,'',''),(1637,48,'2022-08-08 00:00:00','M48','CLOZAPINE TABLETS 50MG','Edit','Edit stock',0,475,0,0,0,0,3000,0,0,'',''),(1638,94,'2022-08-08 00:00:00','M94','DIVALPROEX SUSTAINED RELEASE TABLETS IP 250','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1639,52,'2022-08-08 00:00:00','M52','DONEPEZIL HCL TABLETS 10MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1640,51,'2022-08-08 00:00:00','M51','DONEPEZIL HCL TABLETS 5MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1641,53,'2022-08-08 00:00:00','M53','DOSULEPIN TABLETS 25MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1642,55,'2022-08-08 00:00:00','M55','DOSULEPIN TABLETS BP 50MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1643,54,'2022-08-08 00:00:00','M54','DOSULEPIN TABLETS BP 75MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1644,5,'2022-08-08 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Edit','Edit stock',0,461,0,0,0,0,3000,0,0,'',''),(1645,6,'2022-08-13 00:00:00','M6','ESCITALOPRAM TABLETS 20MG','Edit','Edit stock',0,979,0,0,0,0,3000,0,0,'',''),(1646,4,'2022-08-13 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Edit','Edit stock',0,153,0,0,0,0,3000,0,0,'',''),(1647,23,'2022-08-13 00:00:00','M23','FLUOXETINE CAPSULES 10MG','Edit','Edit stock',0,916,0,0,0,0,3000,0,0,'',''),(1648,12,'2022-08-13 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Edit','Edit stock',0,209,0,0,0,0,3000,0,0,'',''),(1649,21,'2022-08-13 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Edit','Edit stock',0,447,0,0,0,0,3000,0,0,'',''),(1650,20,'2022-08-13 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Edit','Edit stock',0,706,0,0,0,0,3000,0,0,'',''),(1651,22,'2022-08-13 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Edit','Edit stock',0,881,0,0,0,0,3000,0,0,'',''),(1652,93,'2022-08-13 00:00:00','M93','FLUPHENAZINE DECANOATE INJECTION IP 1ML','Edit','Edit stock',0,986,0,0,0,0,3000,0,0,'',''),(1653,14,'2022-08-13 00:00:00','M14','FLUVOXAMINE TABLETS 100MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1654,24,'2022-08-13 00:00:00','M24','GABAPENTIN TABLETS 100MG','Edit','Edit stock',0,874,0,0,0,0,3000,0,0,'',''),(1655,13,'2022-08-13 00:00:00','M13','GLYCOPYRROLATE TABLETS 2MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1656,26,'2022-08-13 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Edit','Edit stock',0,398,0,0,0,0,3000,0,0,'',''),(1657,25,'2022-08-13 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Edit','Edit stock',0,573,0,0,0,0,573,0,0,'',''),(1658,85,'2022-08-13 00:00:00','M85','LEVETIRACETAM TABLETS 250 MG','Edit','Edit stock',0,804,0,0,0,0,3000,0,0,'',''),(1659,25,'2022-08-13 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Edit','Edit stock',0,573,0,0,0,0,3000,0,0,'',''),(1660,84,'2022-08-13 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Edit','Edit stock',0,440,0,0,0,0,3000,0,0,'',''),(1661,29,'2022-08-13 00:00:00','M29','LITHIUM CARBONATE 300MG','Edit','Edit stock',0,975,0,0,0,0,3000,0,0,'',''),(1662,28,'2022-08-13 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Edit','Edit stock',0,185,0,0,0,0,3000,0,0,'',''),(1663,91,'2022-08-13 00:00:00','M91','LORAZEPAM TABLETS 2MG ','Edit','Edit stock',0,958,0,0,0,0,3000,0,0,'',''),(1664,27,'2022-08-13 00:00:00','M27','LURASIDONE HCL TABLETS 40MG','Edit','Edit stock',0,783,0,0,0,0,3000,0,0,'',''),(1665,65,'2022-08-13 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Edit','Edit stock',0,545,0,0,0,0,3000,0,0,'',''),(1666,64,'2022-08-13 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Edit','Edit stock',0,898,0,0,0,0,3000,0,0,'',''),(1667,42,'2022-08-13 00:00:00','M42','VENLAFAXINE EXTENDED REIEASE CAPSULES 37.5MG','Edit','Edit stock',0,100,0,0,0,0,3000,0,0,'',''),(1668,63,'2022-08-16 00:00:00','M63','LACOSAMIDE TABLETS 100MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1669,60,'2022-08-16 00:00:00','M60','LAMOTRIGINE DISPERSIBLE TABLETS 100MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1670,61,'2022-08-16 00:00:00','M61','LAMOTRIGINE DISPERSIBLE TABLETS 50MG','Edit','Edit stock',0,1000,0,0,0,0,1000,0,0,'',''),(1671,61,'2022-08-16 00:00:00','M61','LAMOTRIGINE DISPERSIBLE TABLETS 50MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1672,62,'2022-08-16 00:00:00','M62','LAMOTRIGINE TABLETS 25MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1673,90,'2022-08-16 00:00:00','M90','LORAZEPAM TABLETS 1 MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1674,74,'2022-08-16 00:00:00','M74','MEMANTINE HCL & DONEPEZIL HCL TABLETS ','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1675,7,'2022-08-16 00:00:00','M7','MIRABEGRON EXTENDED FELEASE TABLETS 50MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1676,66,'2022-08-16 00:00:00','M66','NITRAZEPAM TABLETS 10MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1677,38,'2022-08-16 00:00:00','M38','SERTRALINE HCL TABLETS 100MG','Edit','Edit stock',0,140,0,0,0,0,3000,0,0,'',''),(1678,40,'2022-08-16 00:00:00','M40','SERTRALINE HCL TABLETS 25MG','Edit','Edit stock',0,245,0,0,0,0,3000,0,0,'',''),(1679,39,'2022-08-16 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Edit','Edit stock',0,102,0,0,0,0,3000,0,0,'',''),(1680,11,'2022-08-16 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Edit','Edit stock',0,994,0,0,0,0,3000,0,0,'',''),(1681,82,'2022-08-16 00:00:00','M82','SV 200MG','Edit','Edit stock',0,8600,0,0,0,0,100000,0,0,'',''),(1682,81,'2022-08-16 00:00:00','M81','SV 300MG','Edit','Edit stock',0,9125,0,0,0,0,1000000,0,0,'',''),(1683,83,'2022-08-16 00:00:00','M83','SV 500MG','Edit','Edit stock',0,7620,0,0,0,0,1000000,0,0,'',''),(1684,82,'2022-08-16 00:00:00','M82','SV 200MG','Edit','Edit stock',0,100000,0,0,0,0,1000000,0,0,'',''),(1685,45,'2022-08-16 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Edit','Edit stock',0,720,0,0,0,0,3000,0,0,'',''),(1686,37,'2022-08-16 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Edit','Edit stock',0,99636,0,0,0,0,1000000,0,0,'',''),(1687,95,'2022-08-16 00:00:00','M95','TRIFLUOPERAZINE TABLETS IP 5MG','Edit','Edit stock',0,245,0,0,0,0,3000,0,0,'',''),(1688,68,'2022-08-16 00:00:00','M68','OLANZAPINE TABLETS 10MG','Edit','Edit stock',0,19846,0,0,0,0,3000,0,0,'',''),(1689,46,'2022-08-16 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',0,2659,0,0,0,0,1000000,0,0,'',''),(1690,43,'2022-08-16 00:00:00','M43','VENLAFAXINE EXTENDED RELEASE CAPSULES 75MG','Edit','Edit stock',0,720,0,0,0,0,3000,0,0,'',''),(1691,41,'2022-08-16 00:00:00','M41','VENLAFAXINE HCL PROLONGED-RELEASE CAPSULES 37.5MG','Edit','Edit stock',0,100,0,0,0,0,3000,0,0,'',''),(1692,44,'2022-08-16 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Edit','Edit stock',0,385,0,0,0,0,3000,0,0,'',''),(1693,67,'2022-08-16 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Edit','Edit stock',0,706,0,0,0,0,3000,0,0,'',''),(1694,69,'2022-08-16 00:00:00','M69','OLANZAPINE TABLETS 5MG','Edit','Edit stock',0,128,0,0,0,0,3000,0,0,'',''),(1695,77,'2022-08-16 00:00:00','M77','PHENOBARBITONE TABLETS 30MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1696,79,'2022-08-16 00:00:00','M79','PHENOBARBITONE TABLETS 60MG','Edit','Edit stock',0,1000,0,0,0,0,3000,0,0,'',''),(1697,78,'2022-08-16 00:00:00','M78','PHENYTOIN SODIUM TABLETS 100MG','Edit','Edit stock',0,200,0,0,0,0,3000,0,0,'',''),(1698,80,'2022-08-16 00:00:00','M80','PIMOZIDE TABLETS 2MG','Edit','Edit stock',0,60,0,0,0,0,3000,0,0,'',''),(1699,75,'2022-08-16 00:00:00','M75','PROPRANOLOL SUSTAINED RELEASE TABLETS 40MG','Edit','Edit stock',0,97,0,0,0,0,3000,0,0,'',''),(1700,76,'2022-08-16 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Edit','Edit stock',0,678,0,0,0,0,3000,0,0,'',''),(1701,72,'2022-08-16 00:00:00','M72','QUETIAPINE TABLETS 100MG','Edit','Edit stock',0,510,0,0,0,0,3000,0,0,'',''),(1702,73,'2022-08-16 00:00:00','M73','QUETIAPINE TABLETS 200MG','Edit','Edit stock',0,930,0,0,0,0,3000,0,0,'',''),(1703,32,'2022-08-16 00:00:00','M32','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 2MG','Edit','Edit stock',0,493,0,0,0,0,3000,0,0,'',''),(1704,31,'2022-08-16 00:00:00','M31','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 3MG','Edit','Edit stock',0,393,0,0,0,0,3000,0,0,'',''),(1705,30,'2022-08-16 00:00:00','M30','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 4MG','Edit','Edit stock',0,58,0,0,0,0,3000,0,0,'',''),(1706,92,'2022-08-16 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Edit','Edit stock',0,76,0,0,0,0,3000,0,0,'',''),(1707,33,'2022-08-16 00:00:00','M33','RISPERIDONE TABLETS 1MG','Edit','Edit stock',0,944,0,0,0,0,3000,0,0,'',''),(1708,34,'2022-08-16 00:00:00','M34','RISPERIDONE TABLETS 2MG','Edit','Edit stock',0,342,0,0,0,0,3000,0,0,'',''),(1709,35,'2022-08-16 00:00:00','M35','RISPERIDONE TABLETS 3MG','Edit','Edit stock',0,601,0,0,0,0,3000,0,0,'',''),(1710,36,'2022-08-16 00:00:00','M36','RISPERIDONE TABLETS 4MG','Edit','Edit stock',0,524,0,0,0,0,3000,0,0,'',''),(1711,82,'2022-08-05 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,1000000,0,0,21,0,999979,0,0,'136/2022','ABDU SAMAD '),(1712,71,'2022-08-05 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9930,0,0,7,0,9923,0,0,'136/2022','ABDU SAMAD '),(1713,82,'2022-08-12 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999979,0,0,42,0,999937,0,0,'136/2022','ABDU SAMAD '),(1714,71,'2022-08-12 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9923,0,0,14,0,9909,0,0,'136/2022','ABDU SAMAD '),(1715,12,'2021-11-19 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,3000,0,0,56,0,2944,0,0,'161/2019','ASHRAF CP'),(1716,44,'2021-11-19 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Transfer','Sub to OP',0,3000,0,0,56,0,2944,0,0,'161/2019','ASHRAF CP'),(1717,65,'2021-11-19 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,3000,0,0,28,0,2972,0,0,'161/2019','ASHRAF CP'),(1718,12,'2021-12-03 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2944,0,0,21,0,2923,0,0,'161/2019','ASHRAF CP'),(1719,21,'2021-12-03 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,3000,0,0,21,0,2979,0,0,'161/2019','ASHRAF CP'),(1720,44,'2021-12-03 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Transfer','Sub to OP',0,2944,0,0,42,0,2902,0,0,'161/2019','ASHRAF CP'),(1721,64,'2021-12-03 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Transfer','Sub to OP',0,3000,0,0,21,0,2979,0,0,'161/2019','ASHRAF CP'),(1722,44,'2021-12-17 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Transfer','Sub to OP',0,2902,0,0,42,0,2860,0,0,'161/2019','ASHRAF CP'),(1723,21,'2021-12-17 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,2979,0,0,42,0,2937,0,0,'161/2019','ASHRAF CP'),(1724,64,'2021-12-17 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Transfer','Sub to OP',0,2979,0,0,21,0,2958,0,0,'161/2019','ASHRAF CP'),(1725,21,'2022-01-07 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,2937,0,0,56,0,2881,0,0,'161/2019','ASHRAF CP'),(1726,44,'2022-01-07 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Transfer','Sub to OP',0,2860,0,0,56,0,2804,0,0,'161/2019','ASHRAF CP'),(1727,64,'2022-01-07 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Transfer','Sub to OP',0,2958,0,0,28,0,2930,0,0,'161/2019','ASHRAF CP'),(1728,21,'2022-02-04 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,2881,0,0,84,0,2797,0,0,'161/2019','ASHRAF CP'),(1729,44,'2022-02-04 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Transfer','Sub to OP',0,2804,0,0,84,0,2720,0,0,'161/2019','ASHRAF CP'),(1730,21,'2022-02-18 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,2797,0,0,112,0,2685,0,0,'161/2019','ASHRAF CP'),(1731,44,'2022-02-18 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Transfer','Sub to OP',0,2720,0,0,112,0,2608,0,0,'161/2019','ASHRAF CP'),(1732,89,'2022-02-18 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,3000,0,0,20,0,2980,0,0,'161/2019','ASHRAF CP'),(1733,64,'2022-02-18 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Transfer','Sub to OP',0,2930,0,0,28,0,2902,0,0,'161/2019','ASHRAF CP'),(1734,69,'2022-02-18 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,3000,0,0,56,0,2944,0,0,'161/2019','ASHRAF CP'),(1735,96,'2022-08-29 00:00:00','M96','OLANZAPINE ','Add','To main stock',0,0,0,0,10000000,10000000,0,0,0,'',''),(1736,82,'2022-08-05 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999937,0,0,21,0,999916,0,0,'135/2022','ASHRAF'),(1737,68,'2022-08-05 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,3000,0,0,14,0,2986,0,0,'135/2022','ASHRAF'),(1738,34,'2022-08-05 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,3000,0,0,7,0,2993,0,0,'135/2022','ASHRAF'),(1739,36,'2022-08-05 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,3000,0,0,7,0,2993,0,0,'135/2022','ASHRAF'),(1740,72,'2022-08-05 00:00:00','M72','QUETIAPINE TABLETS 100MG','Transfer','Sub to OP',0,3000,0,0,7,0,2993,0,0,'135/2022','ASHRAF'),(1741,46,'2022-08-05 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,1000000,0,0,21,0,999979,0,0,'135/2022','ASHRAF'),(1742,48,'2022-08-05 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,3000,0,0,7,0,2993,0,0,'135/2022','ASHRAF'),(1743,82,'2022-08-12 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999916,0,0,42,0,999874,0,0,'135/2022','ASHRAF'),(1744,68,'2022-08-12 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2986,0,0,28,0,2958,0,0,'135/2022','ASHRAF'),(1745,34,'2022-08-12 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2993,0,0,14,0,2979,0,0,'135/2022','ASHRAF'),(1746,36,'2022-08-12 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2993,0,0,14,0,2979,0,0,'135/2022','ASHRAF'),(1747,72,'2022-08-12 00:00:00','M72','QUETIAPINE TABLETS 100MG','Transfer','Sub to OP',0,2993,0,0,14,0,2979,0,0,'135/2022','ASHRAF'),(1748,46,'2022-08-12 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999979,0,0,42,0,999937,0,0,'135/2022','ASHRAF'),(1749,48,'2022-08-12 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2993,0,0,14,0,2979,0,0,'135/2022','ASHRAF'),(1750,82,'2022-08-26 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999874,0,0,21,0,999853,0,0,'135/2022','ASHRAF'),(1751,68,'2022-08-26 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2958,0,0,14,0,2944,0,0,'135/2022','ASHRAF'),(1752,34,'2022-08-26 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2979,0,0,7,0,2972,0,0,'135/2022','ASHRAF'),(1753,36,'2022-08-26 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2979,0,0,7,0,2972,0,0,'135/2022','ASHRAF'),(1754,71,'2022-08-26 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9909,0,0,7,0,9902,0,0,'135/2022','ASHRAF'),(1755,46,'2022-08-26 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999937,0,0,21,0,999916,0,0,'135/2022','ASHRAF'),(1756,48,'2022-08-26 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2979,0,0,7,0,2972,0,0,'135/2022','ASHRAF'),(1757,28,'2021-09-10 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,3000,0,0,63,0,2937,0,0,'04/2018','ABDUL SAMAD'),(1758,46,'2021-09-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999916,0,0,42,0,999874,0,0,'04/2018','ABDUL SAMAD'),(1759,39,'2021-09-10 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Transfer','Sub to OP',0,3000,0,0,21,0,2979,0,0,'04/2018','ABDUL SAMAD'),(1760,28,'2021-10-22 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2937,0,0,42,0,2895,0,0,'04/2018','ABDUL SAMAD'),(1761,46,'2021-10-22 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999874,0,0,28,0,999846,0,0,'04/2018','ABDUL SAMAD'),(1762,39,'2021-10-22 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Transfer','Sub to OP',0,2979,0,0,14,0,2965,0,0,'04/2018','ABDUL SAMAD'),(1763,28,'2022-08-19 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2895,0,0,32,0,2863,0,0,'04/2018','ABDUL SAMAD'),(1764,35,'2022-08-19 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,3000,0,0,42,0,2958,0,0,'04/2018','ABDUL SAMAD'),(1765,46,'2022-08-19 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999846,0,0,21,0,999825,0,0,'04/2018','ABDUL SAMAD'),(1766,35,'2022-08-12 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2958,0,0,28,0,2930,0,0,'04/2018','ABDUL SAMAD'),(1767,46,'2022-08-12 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999825,0,0,14,0,999811,0,0,'04/2018','ABDUL SAMAD'),(1768,28,'2022-08-12 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2863,0,0,22,0,2841,0,0,'04/2018','ABDUL SAMAD'),(1769,36,'2022-08-05 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2972,0,0,7,0,2965,0,0,'04/2018','ABDUL SAMAD'),(1770,28,'2022-08-05 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2841,0,0,11,0,2830,0,0,'04/2018','ABDUL SAMAD'),(1771,28,'2022-07-29 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2830,0,0,42,0,2788,0,0,'04/2018','ABDUL SAMAD'),(1772,34,'2022-07-29 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2972,0,0,28,0,2944,0,0,'04/2018','ABDUL SAMAD'),(1773,28,'2022-07-01 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2788,0,0,42,0,2746,0,0,'04/2018','ABDUL SAMAD'),(1774,39,'2022-07-01 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Transfer','Sub to OP',0,2965,0,0,28,0,2937,0,0,'04/2018','ABDUL SAMAD'),(1775,40,'2022-07-01 00:00:00','M40','SERTRALINE HCL TABLETS 25MG','Transfer','Sub to OP',0,3000,0,0,28,0,2972,0,0,'04/2018','ABDUL SAMAD'),(1776,28,'2022-05-06 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2746,0,0,84,0,2662,0,0,'04/2018','ABDUL SAMAD'),(1777,40,'2022-05-06 00:00:00','M40','SERTRALINE HCL TABLETS 25MG','Transfer','Sub to OP',0,2972,0,0,56,0,2916,0,0,'04/2018','ABDUL SAMAD'),(1778,39,'2022-05-06 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Transfer','Sub to OP',0,2937,0,0,56,0,2881,0,0,'04/2018','ABDUL SAMAD'),(1779,40,'2022-03-11 00:00:00','M40','SERTRALINE HCL TABLETS 25MG','Transfer','Sub to OP',0,2916,0,0,168,0,2748,0,0,'04/2018','ABDUL SAMAD'),(1780,28,'2022-03-11 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2662,0,0,126,0,2536,0,0,'04/2018','ABDUL SAMAD'),(1781,40,'2022-02-11 00:00:00','M40','SERTRALINE HCL TABLETS 25MG','Transfer','Sub to OP',0,2748,0,0,56,0,2692,0,0,'04/2018','ABDUL SAMAD'),(1782,46,'2022-02-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999811,0,0,28,0,999783,0,0,'04/2018','ABDUL SAMAD'),(1783,28,'2022-02-11 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2536,0,0,42,0,2494,0,0,'04/2018','ABDUL SAMAD'),(1784,28,'2021-12-17 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2494,0,0,42,0,2452,0,0,'04/2018','ABDUL SAMAD'),(1785,46,'2021-12-17 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999783,0,0,28,0,999755,0,0,'04/2018','ABDUL SAMAD'),(1786,40,'2021-12-17 00:00:00','M40','SERTRALINE HCL TABLETS 25MG','Transfer','Sub to OP',0,2692,0,0,56,0,2636,0,0,'04/2018','ABDUL SAMAD'),(1787,28,'2021-11-19 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2452,0,0,42,0,2410,0,0,'04/2018','ABDUL SAMAD'),(1788,46,'2021-11-19 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999755,0,0,28,0,999727,0,0,'04/2018','ABDUL SAMAD'),(1789,40,'2021-11-19 00:00:00','M40','SERTRALINE HCL TABLETS 25MG','Transfer','Sub to OP',0,2636,0,0,56,0,2580,0,0,'04/2018','ABDUL SAMAD'),(1790,28,'2021-08-06 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2410,0,0,63,0,2347,0,0,'04/2018','ABDUL SAMAD'),(1791,46,'2021-08-06 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999727,0,0,42,0,999685,0,0,'04/2018','ABDUL SAMAD'),(1792,40,'2021-08-06 00:00:00','M40','SERTRALINE HCL TABLETS 25MG','Transfer','Sub to OP',0,2580,0,0,84,0,2496,0,0,'04/2018','ABDUL SAMAD'),(1793,28,'2021-07-09 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2347,0,0,28,0,2319,0,0,'04/2018','ABDUL SAMAD'),(1794,33,'2021-07-09 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,3000,0,0,28,0,2972,0,0,'04/2018','ABDUL SAMAD'),(1795,46,'2021-07-09 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999685,0,0,28,0,999657,0,0,'04/2018','ABDUL SAMAD'),(1796,40,'2021-07-09 00:00:00','M40','SERTRALINE HCL TABLETS 25MG','Transfer','Sub to OP',0,2496,0,0,56,0,2440,0,0,'04/2018','ABDUL SAMAD'),(1797,28,'2021-06-11 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2319,0,0,56,0,2263,0,0,'04/2018','ABDUL SAMAD'),(1798,33,'2021-06-11 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2972,0,0,28,0,2944,0,0,'04/2018','ABDUL SAMAD'),(1799,46,'2021-06-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999657,0,0,28,0,999629,0,0,'04/2018','ABDUL SAMAD'),(1800,40,'2021-06-11 00:00:00','M40','SERTRALINE HCL TABLETS 25MG','Transfer','Sub to OP',0,2440,0,0,56,0,2384,0,0,'04/2018','ABDUL SAMAD'),(1801,33,'2021-05-07 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2944,0,0,28,0,2916,0,0,'04/2018','ABDUL SAMAD'),(1802,46,'2021-05-07 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999629,0,0,28,0,999601,0,0,'04/2018','ABDUL SAMAD'),(1803,28,'2021-05-07 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2263,0,0,42,0,2221,0,0,'04/2018','ABDUL SAMAD'),(1804,40,'2021-05-07 00:00:00','M40','SERTRALINE HCL TABLETS 25MG','Transfer','Sub to OP',0,2384,0,0,56,0,2328,0,0,'04/2018','ABDUL SAMAD'),(1805,34,'2021-04-08 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2944,0,0,28,0,2916,0,0,'04/2018','ABDUL SAMAD'),(1806,28,'2021-04-08 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2221,0,0,42,0,2179,0,0,'04/2018','ABDUL SAMAD'),(1807,46,'2021-04-08 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999601,0,0,28,0,999573,0,0,'04/2018','ABDUL SAMAD'),(1808,40,'2021-04-08 00:00:00','M40','SERTRALINE HCL TABLETS 25MG','Transfer','Sub to OP',0,2328,0,0,56,0,2272,0,0,'04/2018','ABDUL SAMAD'),(1809,33,'2022-07-29 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2916,0,0,14,0,2902,0,0,'130/2022','AHAMMED KUTTY'),(1810,34,'2022-08-12 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2916,0,0,14,0,2902,0,0,'130/2022','AHAMMED KUTTY'),(1811,35,'2022-08-26 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2930,0,0,14,0,2916,0,0,'130/2022','AHAMMED KUTTY'),(1812,70,'2022-08-26 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19552,0,0,14,0,19538,0,0,'130/2022','AHAMMED KUTTY'),(1813,34,'2022-09-30 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2902,0,0,28,0,2874,0,0,'202/2022','BINDU'),(1814,46,'2022-09-30 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999573,0,0,56,0,999517,0,0,'202/2022','BINDU'),(1815,34,'2022-09-16 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2874,0,0,14,0,2860,0,0,'202/2022','BINDU'),(1816,46,'2022-09-16 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999517,0,0,14,0,999503,0,0,'202/2022','BINDU'),(1817,83,'2022-09-30 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,1000000,0,0,14,0,999986,0,0,'204/2022','ANSIF'),(1818,68,'2022-09-30 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2944,0,0,21,0,2923,0,0,'204/2022','ANSIF'),(1819,28,'2022-09-30 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2179,0,0,7,0,2172,0,0,'204/2022','ANSIF'),(1820,46,'2022-09-30 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999503,0,0,14,0,999489,0,0,'204/2022','ANSIF'),(1821,33,'2022-09-30 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2902,0,0,14,0,2888,0,0,'200/2022','KOLAVAM'),(1822,33,'2022-09-09 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2888,0,0,84,0,2804,0,0,'115/2022','HUSSAN'),(1823,33,'2022-07-15 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2804,0,0,56,0,2748,0,0,'115/2022','HUSSAN'),(1824,33,'2022-07-08 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2748,0,0,7,0,2741,0,0,'115/2022','HUSSAN'),(1825,12,'2022-09-30 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2923,0,0,7,0,2916,0,0,'201/2022','PRAMOD'),(1826,33,'2022-09-30 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2741,0,0,4,0,2737,0,0,'201/2022','PRAMOD'),(1827,81,'2022-09-30 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,1000000,0,0,7,0,999993,0,0,'203/2022','RASIYA BANU'),(1828,83,'2022-09-30 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999986,0,0,7,0,999979,0,0,'203/2022','RASIYA BANU'),(1829,69,'2022-09-30 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2944,0,0,7,0,2937,0,0,'203/2022','RASIYA BANU'),(1830,67,'2022-09-30 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,3000,0,0,7,0,2993,0,0,'203/2022','RASIYA BANU'),(1831,22,'2022-09-30 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,3000,0,0,7,0,2993,0,0,'203/2022','RASIYA BANU'),(1832,91,'2022-09-30 00:00:00','M91','LORAZEPAM TABLETS 2MG ','Transfer','Sub to OP',0,3000,0,0,7,0,2993,0,0,'203/2022','RASIYA BANU'),(1833,82,'2022-09-02 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999853,0,0,14,0,999839,0,0,'171/2022','SHRHARBAN'),(1834,34,'2022-09-02 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2860,0,0,7,0,2853,0,0,'171/2022','SHRHARBAN'),(1835,83,'2022-08-19 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999979,0,0,14,0,999965,0,0,'155/2022','SAINUDHEEN'),(1836,34,'2022-08-19 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2853,0,0,7,0,2846,0,0,'155/2022','SAINUDHEEN'),(1837,83,'2022-08-26 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999965,0,0,84,0,999881,0,0,'155/2022','SAINUDHEEN'),(1838,34,'2022-08-26 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2846,0,0,42,0,2804,0,0,'155/2022','SAINUDHEEN'),(1839,29,'2022-09-09 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,3000,0,0,168,0,2832,0,0,'92/2022','MOHAMMED '),(1840,25,'2022-09-09 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,3000,0,0,56,0,2944,0,0,'92/2022','MOHAMMED '),(1841,46,'2022-09-09 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999489,0,0,112,0,999377,0,0,'92/2022','MOHAMMED '),(1842,29,'2022-09-23 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,2832,0,0,42,0,2790,0,0,'205/2022','ABDUL RASAK'),(1843,36,'2022-09-23 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2965,0,0,28,0,2937,0,0,'205/2022','ABDUL RASAK'),(1844,46,'2022-09-23 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999377,0,0,28,0,999349,0,0,'205/2022','ABDUL RASAK'),(1845,20,'2022-09-23 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,3000,0,0,14,0,2986,0,0,'205/2022','ABDUL RASAK'),(1846,12,'2022-09-23 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2916,0,0,14,0,2902,0,0,'205/2022','ABDUL RASAK'),(1847,56,'2022-09-23 00:00:00','M56','CLOMIPRAMINE TABLETS 25MG','Transfer','Sub to OP',0,3000,0,0,28,0,2972,0,0,'205/2022','ABDUL RASAK'),(1848,46,'2022-09-30 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999349,0,0,28,0,999321,0,0,'190/2022','NOUSHAD '),(1849,35,'2022-09-30 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2916,0,0,28,0,2888,0,0,'190/2022','NOUSHAD '),(1850,89,'2022-09-30 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,2980,0,0,28,0,2952,0,0,'190/2022','NOUSHAD '),(1851,67,'2022-03-25 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2993,0,0,55,0,2938,0,0,'292/2021','ABDUL NAZAR'),(1852,70,'2022-03-25 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19538,0,0,55,0,19483,0,0,'292/2021','ABDUL NAZAR'),(1853,67,'2022-05-05 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2938,0,0,84,0,2854,0,0,'292/2021','ABDUL NAZAR'),(1854,70,'2022-05-05 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19483,0,0,84,0,19399,0,0,'292/2021','ABDUL NAZAR'),(1855,67,'2022-08-12 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2854,0,0,80,0,2774,0,0,'292/2021','ABDUL NAZAR'),(1856,70,'2022-08-28 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19399,0,0,56,0,19343,0,0,'292/2021','ABDUL NAZAR'),(1857,48,'2022-03-25 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2972,0,0,30,0,2942,0,0,'48/2017','ABDUL HASEEB'),(1858,47,'2022-03-25 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,3000,0,0,30,0,2970,0,0,'48/2017','ABDUL HASEEB'),(1859,71,'2022-03-25 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9902,0,0,30,0,9872,0,0,'48/2017','ABDUL HASEEB'),(1860,70,'2022-03-25 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19343,0,0,30,0,19313,0,0,'48/2017','ABDUL HASEEB'),(1861,46,'2022-03-25 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999321,0,0,90,0,999231,0,0,'48/2017','ABDUL HASEEB'),(1862,34,'2022-03-25 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2804,0,0,60,0,2744,0,0,'48/2017','ABDUL HASEEB'),(1863,48,'2022-04-22 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2942,0,0,43,0,2899,0,0,'48/2017','ABDUL HASEEB'),(1864,47,'2022-04-22 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2970,0,0,45,0,2925,0,0,'48/2017','ABDUL HASEEB'),(1865,71,'2022-04-22 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9872,0,0,45,0,9827,0,0,'48/2017','ABDUL HASEEB'),(1866,70,'2022-04-22 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19313,0,0,45,0,19268,0,0,'48/2017','ABDUL HASEEB'),(1867,46,'2022-04-22 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999231,0,0,135,0,999096,0,0,'48/2017','ABDUL HASEEB'),(1868,34,'2022-04-22 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2744,0,0,70,0,2674,0,0,'48/2017','ABDUL HASEEB'),(1869,48,'2022-06-03 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2899,0,0,20,0,2879,0,0,'48/2017','ABDUL HASEEB'),(1870,47,'2022-06-03 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2925,0,0,20,0,2905,0,0,'48/2017','ABDUL HASEEB'),(1871,71,'2022-06-03 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9827,0,0,20,0,9807,0,0,'48/2017','ABDUL HASEEB'),(1872,70,'2022-06-03 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19268,0,0,20,0,19248,0,0,'48/2017','ABDUL HASEEB'),(1873,46,'2022-06-03 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999096,0,0,60,0,999036,0,0,'48/2017','ABDUL HASEEB'),(1874,34,'2022-06-03 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2674,0,0,40,0,2634,0,0,'48/2017','ABDUL HASEEB'),(1875,48,'2022-06-24 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2879,0,0,30,0,2849,0,0,'48/2017','ABDUL HASEEB'),(1876,47,'2022-06-24 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2905,0,0,30,0,2875,0,0,'48/2017','ABDUL HASEEB'),(1877,71,'2022-06-24 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9807,0,0,30,0,9777,0,0,'48/2017','ABDUL HASEEB'),(1878,70,'2022-06-24 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19248,0,0,30,0,19218,0,0,'48/2017','ABDUL HASEEB'),(1879,46,'2022-06-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,999036,0,0,90,0,998946,0,0,'48/2017','ABDUL HASEEB'),(1880,34,'2022-06-24 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2634,0,0,60,0,2574,0,0,'48/2017','ABDUL HASEEB'),(1881,48,'2022-07-22 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2849,0,0,30,0,2819,0,0,'48/2017','ABDUL HASEEB'),(1882,47,'2022-07-22 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2875,0,0,30,0,2845,0,0,'48/2017','ABDUL HASEEB'),(1883,71,'2022-07-22 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9777,0,0,30,0,9747,0,0,'48/2017','ABDUL HASEEB'),(1884,70,'2022-07-22 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19218,0,0,30,0,19188,0,0,'48/2017','ABDUL HASEEB'),(1885,46,'2022-07-22 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998946,0,0,90,0,998856,0,0,'48/2017','ABDUL HASEEB'),(1886,34,'2022-07-22 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2574,0,0,60,0,2514,0,0,'48/2017','ABDUL HASEEB'),(1887,49,'2022-09-30 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,3000,0,0,43,0,2957,0,0,'48/2017','ABDUL HASEEB'),(1888,35,'2022-09-30 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2888,0,0,43,0,2845,0,0,'48/2017','ABDUL HASEEB'),(1889,46,'2022-09-30 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998856,0,0,129,0,998727,0,0,'48/2017','ABDUL HASEEB'),(1890,5,'2022-10-07 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,3000,0,0,28,0,2972,0,0,'04/2022','BIJU'),(1891,4,'2022-10-07 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,3000,0,0,28,0,2972,0,0,'04/2022','BIJU'),(1892,65,'2022-10-07 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,2972,0,0,28,0,2944,0,0,'04/2022','BIJU'),(1893,3,'2022-10-07 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,3000,0,0,28,0,2972,0,0,'04/2022','BIJU'),(1894,82,'2022-10-07 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999839,0,0,28,0,999811,0,0,'135/2020','ALAVI'),(1895,69,'2022-10-07 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2937,0,0,14,0,2923,0,0,'135/2020','ALAVI'),(1896,12,'2022-10-07 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2902,0,0,14,0,2888,0,0,'135/2020','ALAVI'),(1897,46,'2022-10-07 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998727,0,0,14,0,998713,0,0,'135/2020','ALAVI'),(1898,5,'2022-10-07 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2972,0,0,28,0,2944,0,0,'202/2021','SHAJI'),(1899,20,'2022-10-07 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,2986,0,0,14,0,2972,0,0,'59/2021','KUNJUMUHAMMAD'),(1900,65,'2022-10-07 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,2944,0,0,14,0,2930,0,0,'59/2021','KUNJUMUHAMMAD'),(1901,19,'2022-10-07 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,3000,0,0,7,0,2993,0,0,'59/2021','KUNJUMUHAMMAD'),(1902,49,'2022-10-07 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2957,0,0,28,0,2929,0,0,'48/2017','ABDUL HASEEB'),(1903,47,'2022-10-07 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2845,0,0,28,0,2817,0,0,'48/2017','ABDUL HASEEB'),(1904,31,'2022-10-07 00:00:00','M31','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 3MG','Transfer','Sub to OP',0,3000,0,0,28,0,2972,0,0,'48/2017','ABDUL HASEEB'),(1905,46,'2022-10-07 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998713,0,0,84,0,998629,0,0,'48/2017','ABDUL HASEEB'),(1906,49,'2022-10-07 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2929,0,0,28,0,2901,0,0,'48/2017','ABDUL HASEEB'),(1907,47,'2022-10-07 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2817,0,0,28,0,2789,0,0,'48/2017','ABDUL HASEEB'),(1908,31,'2022-10-07 00:00:00','M31','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 3MG','Transfer','Sub to OP',0,2972,0,0,28,0,2944,0,0,'48/2017','ABDUL HASEEB'),(1909,46,'2022-10-07 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998629,0,0,84,0,998545,0,0,'48/2017','ABDUL HASEEB'),(1910,82,'2022-10-07 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999811,0,0,7,0,999804,0,0,'247/2021','NOUSHAD '),(1911,83,'2022-10-07 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999881,0,0,7,0,999874,0,0,'247/2021','NOUSHAD '),(1912,35,'2022-10-07 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2845,0,0,7,0,2838,0,0,'247/2021','NOUSHAD '),(1913,34,'2022-10-07 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2514,0,0,7,0,2507,0,0,'247/2021','NOUSHAD '),(1914,71,'2022-10-07 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9747,0,0,7,0,9740,0,0,'247/2021','NOUSHAD '),(1915,46,'2022-10-07 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998545,0,0,21,0,998524,0,0,'247/2021','NOUSHAD '),(1916,82,'2022-10-07 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999804,0,0,30,0,999774,0,0,'0130/2017','SHANDHA'),(1917,43,'2022-10-07 00:00:00','M43','VENLAFAXINE EXTENDED RELEASE CAPSULES 75MG','Transfer','Sub to OP',0,3000,0,0,20,0,2980,0,0,'0130/2017','SHANDHA'),(1918,65,'2022-10-07 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,2930,0,0,10,0,2920,0,0,'0130/2017','SHANDHA'),(1919,82,'2022-10-07 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999774,0,0,28,0,999746,0,0,'118/2022','FIROZ'),(1920,83,'2022-10-07 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999874,0,0,28,0,999846,0,0,'118/2022','FIROZ'),(1921,47,'2022-10-07 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2789,0,0,28,0,2761,0,0,'118/2022','FIROZ'),(1922,50,'2022-10-07 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,3000,0,0,28,0,2972,0,0,'9/2018','RAFEENA'),(1923,49,'2022-10-07 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2901,0,0,28,0,2873,0,0,'9/2018','RAFEENA'),(1924,46,'2022-10-07 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998524,0,0,56,0,998468,0,0,'9/2018','RAFEENA'),(1925,34,'2022-10-07 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2507,0,0,42,0,2465,0,0,'9/2018','RAFEENA'),(1926,35,'2022-10-07 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2838,0,0,28,0,2810,0,0,'9/2018','RAFEENA'),(1927,34,'2022-08-26 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2465,0,0,7,0,2458,0,0,'170/2022','HAMZA'),(1928,34,'2022-09-02 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2458,0,0,28,0,2430,0,0,'170/2022','HAMZA'),(1929,34,'2022-10-07 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2430,0,0,28,0,2402,0,0,'170/2022','HAMZA'),(1930,82,'2022-10-07 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999746,0,0,28,0,999718,0,0,'059/2021','YASHODHA'),(1931,83,'2022-10-07 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999846,0,0,28,0,999818,0,0,'059/2021','YASHODHA'),(1932,70,'2022-10-07 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19188,0,0,28,0,19160,0,0,'059/2021','YASHODHA'),(1933,34,'2022-10-07 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2402,0,0,28,0,2374,0,0,'138/2019','UMMAR'),(1934,35,'2022-10-07 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2810,0,0,56,0,2754,0,0,'138/2019','UMMAR'),(1935,22,'2022-10-07 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2993,0,0,14,0,2979,0,0,'201/2022','PRAMOD'),(1936,33,'2022-10-07 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2737,0,0,7,0,2730,0,0,'201/2022','PRAMOD'),(1937,34,'2022-10-07 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2374,0,0,7,0,2367,0,0,'201/2022','PRAMOD'),(1938,83,'2022-10-07 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999818,0,0,28,0,999790,0,0,'204/2022','ANSIF'),(1939,82,'2022-10-07 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999718,0,0,14,0,999704,0,0,'204/2022','ANSIF'),(1940,68,'2022-10-07 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2923,0,0,21,0,2902,0,0,'204/2022','ANSIF'),(1941,28,'2022-10-07 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2172,0,0,14,0,2158,0,0,'204/2022','ANSIF'),(1942,46,'2022-10-07 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998468,0,0,28,0,998440,0,0,'204/2022','ANSIF'),(1943,81,'2022-10-07 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999993,0,0,14,0,999979,0,0,'203/2022','RASIYA BANU'),(1944,83,'2022-10-07 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999790,0,0,14,0,999776,0,0,'203/2022','RASIYA BANU'),(1945,69,'2022-10-07 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2923,0,0,10,0,2913,0,0,'203/2022','RASIYA BANU'),(1946,12,'2022-10-07 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2888,0,0,14,0,2874,0,0,'203/2022','RASIYA BANU'),(1947,90,'2022-10-07 00:00:00','M90','LORAZEPAM TABLETS 1 MG','Transfer','Sub to OP',0,3000,0,0,14,0,2986,0,0,'203/2022','RASIYA BANU'),(1948,45,'2022-10-07 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,3000,0,0,56,0,2944,0,0,'211/2019','RAJAN'),(1949,87,'2022-10-07 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Transfer','Sub to OP',0,3000,0,0,21,0,2979,0,0,'211/2019','RAJAN'),(1950,81,'2022-10-07 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999979,0,0,56,0,999923,0,0,'211/2019','RAJAN'),(1951,35,'2022-10-07 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2754,0,0,28,0,2726,0,0,'211/2019','RAJAN'),(1952,5,'2022-10-07 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2944,0,0,28,0,2916,0,0,'211/2019','RAJAN'),(1953,46,'2022-10-07 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998440,0,0,56,0,998384,0,0,'211/2019','RAJAN'),(1954,76,'2022-10-07 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,3000,0,0,56,0,2944,0,0,'211/2019','RAJAN'),(1955,19,'2022-10-07 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,2993,0,0,21,0,2972,0,0,'080/2020','SAJNA'),(1956,45,'2022-10-07 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,2944,0,0,14,0,2930,0,0,'080/2020','SAJNA'),(1957,12,'2022-10-07 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2874,0,0,14,0,2860,0,0,'02/2022','GIRIJA'),(1958,12,'2022-10-07 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2860,0,0,28,0,2832,0,0,'02/2022','GIRIJA'),(1959,82,'2022-10-07 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999704,0,0,28,0,999676,0,0,'26/2017','ABDURAHMAN'),(1960,83,'2022-10-07 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999776,0,0,28,0,999748,0,0,'26/2017','ABDURAHMAN'),(1961,34,'2022-10-07 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2367,0,0,28,0,2339,0,0,'26/2017','ABDURAHMAN'),(1962,83,'2022-10-07 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999748,0,0,28,0,999720,0,0,'137/2017','MUJEEBRAHMAN'),(1963,26,'2022-10-07 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,3000,0,0,21,0,2979,0,0,'137/2017','MUJEEBRAHMAN'),(1964,76,'2022-10-07 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,2944,0,0,28,0,2916,0,0,'137/2017','MUJEEBRAHMAN'),(1965,46,'2022-10-07 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998384,0,0,84,0,998300,0,0,'137/2017','MUJEEBRAHMAN'),(1966,48,'2022-08-26 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2819,0,0,28,0,2791,0,0,'48/2017','ABDUL HASEEB'),(1967,47,'2022-08-26 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2761,0,0,28,0,2733,0,0,'48/2017','ABDUL HASEEB'),(1968,70,'2022-08-26 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19160,0,0,28,0,19132,0,0,'48/2017','ABDUL HASEEB'),(1969,46,'2022-08-26 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998300,0,0,74,0,998226,0,0,'48/2017','ABDUL HASEEB'),(1970,36,'2022-08-26 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2937,0,0,28,0,2909,0,0,'48/2017','ABDUL HASEEB'),(1971,59,'2022-01-07 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Transfer','Sub to OP',0,3000,0,0,28,0,2972,0,0,'01/2018','ABDUL NAZAR'),(1972,3,'2022-01-07 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2972,0,0,10,0,2962,0,0,'01/2018','ABDUL NAZAR'),(1973,70,'2022-01-21 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19132,0,0,28,0,19104,0,0,'01/2018','ABDUL NAZAR'),(1974,68,'2022-01-21 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2902,0,0,56,0,2846,0,0,'01/2018','ABDUL NAZAR'),(1975,59,'2022-01-21 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Transfer','Sub to OP',0,2972,0,0,28,0,2944,0,0,'01/2018','ABDUL NAZAR'),(1976,68,'2022-02-25 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2846,0,0,56,0,2790,0,0,'01/2018','ABDUL NAZAR'),(1977,69,'2022-02-25 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2913,0,0,28,0,2885,0,0,'01/2018','ABDUL NAZAR'),(1978,70,'2022-02-25 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19104,0,0,28,0,19076,0,0,'01/2018','ABDUL NAZAR'),(1979,83,'2022-06-03 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999720,0,0,56,0,999664,0,0,'01/2018','ABDUL NAZAR'),(1980,50,'2022-06-03 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2972,0,0,28,0,2944,0,0,'01/2018','ABDUL NAZAR'),(1981,48,'2022-06-03 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2791,0,0,28,0,2763,0,0,'01/2018','ABDUL NAZAR'),(1982,68,'2022-06-03 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2790,0,0,28,0,2762,0,0,'01/2018','ABDUL NAZAR'),(1983,67,'2022-06-03 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2774,0,0,28,0,2746,0,0,'01/2018','ABDUL NAZAR'),(1984,22,'2022-06-03 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2979,0,0,28,0,2951,0,0,'01/2018','ABDUL NAZAR'),(1985,50,'2022-08-26 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2944,0,0,28,0,2916,0,0,'01/2018','ABDUL NAZAR'),(1986,83,'2022-08-26 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999664,0,0,56,0,999608,0,0,'01/2018','ABDUL NAZAR'),(1987,68,'2022-08-26 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2762,0,0,28,0,2734,0,0,'01/2018','ABDUL NAZAR'),(1988,67,'2022-08-26 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2746,0,0,28,0,2718,0,0,'01/2018','ABDUL NAZAR'),(1989,12,'2022-08-26 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2832,0,0,28,0,2804,0,0,'01/2018','ABDUL NAZAR'),(1990,69,'2022-08-12 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2885,0,0,28,0,2857,0,0,'292/2021','ABDUL NAZAR'),(1991,68,'2022-08-12 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2734,0,0,56,0,2678,0,0,'292/2021','ABDUL NAZAR'),(1992,70,'2022-08-12 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19076,0,0,28,0,19048,0,0,'292/2021','ABDUL NAZAR'),(1993,28,'2022-09-02 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2158,0,0,28,0,2130,0,0,'04/2018','ABDUL SAMAD'),(1994,31,'2022-09-02 00:00:00','M31','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 3MG','Transfer','Sub to OP',0,2944,0,0,42,0,2902,0,0,'04/2018','ABDUL SAMAD'),(1995,46,'2022-09-02 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998226,0,0,21,0,998205,0,0,'04/2018','ABDUL SAMAD'),(1996,28,'2022-09-30 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2130,0,0,42,0,2088,0,0,'04/2018','ABDUL SAMAD'),(1997,31,'2022-09-30 00:00:00','M31','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 3MG','Transfer','Sub to OP',0,2902,0,0,56,0,2846,0,0,'04/2018','ABDUL SAMAD'),(1998,46,'2022-09-30 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998205,0,0,28,0,998177,0,0,'04/2018','ABDUL SAMAD'),(1999,83,'2022-02-18 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999608,0,0,28,0,999580,0,0,'26/2017','ABDURAHMAN'),(2000,83,'2022-03-25 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999580,0,0,7,0,999573,0,0,'26/2017','ABDURAHMAN'),(2001,34,'2022-03-25 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2339,0,0,7,0,2332,0,0,'26/2017','ABDURAHMAN'),(2002,83,'2022-04-01 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999573,0,0,28,0,999545,0,0,'26/2017','ABDURAHMAN'),(2003,34,'2022-04-01 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2332,0,0,28,0,2304,0,0,'26/2017','ABDURAHMAN'),(2004,82,'2022-04-01 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999676,0,0,28,0,999648,0,0,'26/2017','ABDURAHMAN'),(2005,83,'2022-05-13 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999545,0,0,28,0,999517,0,0,'26/2017','ABDURAHMAN'),(2006,82,'2022-05-13 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999648,0,0,28,0,999620,0,0,'26/2017','ABDURAHMAN'),(2007,34,'2022-05-13 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2304,0,0,28,0,2276,0,0,'26/2017','ABDURAHMAN'),(2008,83,'2022-06-10 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999517,0,0,28,0,999489,0,0,'26/2017','ABDURAHMAN'),(2009,81,'2022-06-10 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999923,0,0,28,0,999895,0,0,'26/2017','ABDURAHMAN'),(2010,81,'2022-08-05 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999895,0,0,28,0,999867,0,0,'26/2017','ABDURAHMAN'),(2011,83,'2022-08-05 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999489,0,0,28,0,999461,0,0,'26/2017','ABDURAHMAN'),(2012,34,'2022-08-05 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2276,0,0,2,0,2274,0,0,'26/2017','ABDURAHMAN'),(2013,30,'2022-09-09 00:00:00','M30','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 4MG','Transfer','Sub to OP',0,3000,0,0,21,0,2979,0,0,'130/2022','AHAMMED KUTTY'),(2014,70,'2022-09-09 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19048,0,0,21,0,19027,0,0,'130/2022','AHAMMED KUTTY'),(2015,35,'2022-09-30 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2726,0,0,28,0,2698,0,0,'130/2022','AHAMMED KUTTY'),(2016,70,'2022-09-30 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,19027,0,0,28,0,18999,0,0,'130/2022','AHAMMED KUTTY'),(2017,46,'2022-09-30 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998177,0,0,28,0,998149,0,0,'130/2022','AHAMMED KUTTY'),(2018,82,'2022-03-25 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999620,0,0,21,0,999599,0,0,'135/2020','ALAVI'),(2019,69,'2022-03-25 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2857,0,0,10,0,2847,0,0,'135/2020','ALAVI'),(2020,69,'2022-04-01 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2847,0,0,7,0,2840,0,0,'135/2020','ALAVI'),(2021,22,'2022-04-01 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2951,0,0,7,0,2944,0,0,'135/2020','ALAVI'),(2022,82,'2022-04-01 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999599,0,0,14,0,999585,0,0,'135/2020','ALAVI'),(2023,12,'2022-04-08 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2804,0,0,21,0,2783,0,0,'135/2020','ALAVI'),(2024,82,'2022-04-08 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999585,0,0,42,0,999543,0,0,'135/2020','ALAVI'),(2025,69,'2022-04-08 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2840,0,0,21,0,2819,0,0,'135/2020','ALAVI'),(2026,69,'2022-05-13 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2819,0,0,28,0,2791,0,0,'135/2020','ALAVI'),(2027,22,'2022-05-13 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2944,0,0,28,0,2916,0,0,'135/2020','ALAVI'),(2028,82,'2022-05-13 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999543,0,0,56,0,999487,0,0,'135/2020','ALAVI'),(2029,82,'2022-06-10 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999487,0,0,56,0,999431,0,0,'135/2020','ALAVI'),(2030,69,'2022-06-10 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2791,0,0,42,0,2749,0,0,'135/2020','ALAVI'),(2031,22,'2022-06-10 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2916,0,0,28,0,2888,0,0,'135/2020','ALAVI'),(2032,82,'2022-06-24 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999431,0,0,28,0,999403,0,0,'135/2020','ALAVI'),(2033,82,'2022-06-24 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999431,0,0,28,0,999403,0,0,'135/2020','ALAVI'),(2034,12,'2022-06-24 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2783,0,0,28,0,2755,0,0,'135/2020','ALAVI'),(2035,12,'2022-06-24 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2755,0,0,28,0,2727,0,0,'135/2020','ALAVI'),(2036,46,'2022-06-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998149,0,0,28,0,998121,0,0,'135/2020','ALAVI'),(2037,46,'2022-06-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998121,0,0,28,0,998093,0,0,'135/2020','ALAVI'),(2038,69,'2022-06-24 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2749,0,0,28,0,2721,0,0,'135/2020','ALAVI'),(2039,69,'2022-06-24 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2721,0,0,28,0,2693,0,0,'135/2020','ALAVI'),(2040,82,'2022-06-24 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999375,0,0,28,0,999347,0,0,'135/2020','ALAVI'),(2041,12,'2022-06-24 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2727,0,0,28,0,2699,0,0,'135/2020','ALAVI'),(2042,46,'2022-06-24 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998093,0,0,28,0,998065,0,0,'135/2020','ALAVI'),(2043,69,'2022-06-24 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2693,0,0,28,0,2665,0,0,'135/2020','ALAVI'),(2044,22,'2022-08-12 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2888,0,0,28,0,2860,0,0,'67/2021','ANEESHA'),(2045,92,'2022-08-12 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,3000,0,0,14,0,2986,0,0,'67/2021','ANEESHA'),(2046,82,'2022-09-02 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999347,0,0,14,0,999333,0,0,'135/2022','ASHRAF'),(2047,83,'2022-09-02 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999461,0,0,14,0,999447,0,0,'135/2022','ASHRAF'),(2048,68,'2022-09-02 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2678,0,0,21,0,2657,0,0,'135/2022','ASHRAF'),(2049,71,'2022-09-02 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9740,0,0,14,0,9726,0,0,'135/2022','ASHRAF'),(2050,34,'2022-09-02 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2274,0,0,14,0,2260,0,0,'135/2022','ASHRAF'),(2051,46,'2022-09-02 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998065,0,0,42,0,998023,0,0,'135/2022','ASHRAF'),(2052,48,'2022-09-02 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2763,0,0,14,0,2749,0,0,'135/2022','ASHRAF'),(2053,82,'2022-09-16 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999333,0,0,28,0,999305,0,0,'135/2022','ASHRAF'),(2054,83,'2022-09-16 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999447,0,0,28,0,999419,0,0,'135/2022','ASHRAF'),(2055,68,'2022-09-16 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2657,0,0,32,0,2625,0,0,'135/2022','ASHRAF'),(2056,32,'2022-09-16 00:00:00','M32','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,3000,0,0,28,0,2972,0,0,'135/2022','ASHRAF'),(2057,30,'2022-09-16 00:00:00','M30','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 4MG','Transfer','Sub to OP',0,2979,0,0,28,0,2951,0,0,'135/2022','ASHRAF'),(2058,71,'2022-09-16 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9726,0,0,28,0,9698,0,0,'135/2022','ASHRAF'),(2059,46,'2022-09-16 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,998023,0,0,84,0,997939,0,0,'135/2022','ASHRAF'),(2060,48,'2022-09-16 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2749,0,0,28,0,2721,0,0,'135/2022','ASHRAF'),(2061,21,'2022-05-13 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,2685,0,0,110,0,2575,0,0,'161/2019','ASHRAF CP'),(2062,44,'2022-05-13 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Transfer','Sub to OP',0,2608,0,0,110,0,2498,0,0,'161/2019','ASHRAF CP'),(2063,64,'2022-05-13 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Transfer','Sub to OP',0,2902,0,0,28,0,2874,0,0,'161/2019','ASHRAF CP'),(2064,89,'2022-05-13 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,2952,0,0,55,0,2897,0,0,'161/2019','ASHRAF CP'),(2065,69,'2022-05-13 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2665,0,0,55,0,2610,0,0,'161/2019','ASHRAF CP'),(2066,21,'2022-06-03 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,2575,0,0,70,0,2505,0,0,'161/2019','ASHRAF CP'),(2067,44,'2022-06-03 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Transfer','Sub to OP',0,2498,0,0,70,0,2428,0,0,'161/2019','ASHRAF CP'),(2068,69,'2022-06-03 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2610,0,0,35,0,2575,0,0,'161/2019','ASHRAF CP'),(2069,21,'2022-07-08 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,2505,0,0,80,0,2425,0,0,'161/2019','ASHRAF CP'),(2070,44,'2022-07-08 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Transfer','Sub to OP',0,2428,0,0,80,0,2348,0,0,'161/2019','ASHRAF CP'),(2071,69,'2022-07-08 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2575,0,0,40,0,2535,0,0,'161/2019','ASHRAF CP'),(2072,21,'2022-08-19 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,2425,0,0,120,0,2305,0,0,'161/2019','ASHRAF CP'),(2073,69,'2022-08-19 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2535,0,0,60,0,2475,0,0,'161/2019','ASHRAF CP'),(2074,43,'2022-08-19 00:00:00','M43','VENLAFAXINE EXTENDED RELEASE CAPSULES 75MG','Transfer','Sub to OP',0,2980,0,0,60,0,2920,0,0,'161/2019','ASHRAF CP'),(2075,44,'2022-08-19 00:00:00','M44','VENLAFAXINE PROLONGED RELEASE TABLETS 150MG','Transfer','Sub to OP',0,2348,0,0,60,0,2288,0,0,'161/2019','ASHRAF CP'),(2076,82,'2022-06-03 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999305,0,0,84,0,999221,0,0,'287/2021','AYISHA'),(2077,83,'2022-06-03 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999419,0,0,84,0,999335,0,0,'287/2021','AYISHA'),(2078,34,'2022-06-03 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2260,0,0,252,0,2008,0,0,'287/2021','AYISHA'),(2079,46,'2022-06-03 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,997939,0,0,168,0,997771,0,0,'287/2021','AYISHA'),(2080,82,'2022-08-26 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999221,0,0,60,0,999161,0,0,'287/2021','AYISHA'),(2081,83,'2022-08-26 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999335,0,0,60,0,999275,0,0,'287/2021','AYISHA'),(2082,34,'2022-08-26 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,2008,0,0,180,0,1828,0,0,'287/2021','AYISHA'),(2083,46,'2022-08-26 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,997771,0,0,120,0,997651,0,0,'287/2021','AYISHA'),(2084,9,'2022-06-03 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,3000,0,0,84,0,2916,0,0,'63/2018','BABY'),(2085,8,'2022-06-03 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Transfer','Sub to OP',0,3000,0,0,84,0,2916,0,0,'63/2018','BABY'),(2086,9,'2022-08-26 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,2916,0,0,60,0,2856,0,0,'63/2018','BABY'),(2087,8,'2022-08-26 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Transfer','Sub to OP',0,2916,0,0,60,0,2856,0,0,'63/2018','BABY'),(2088,5,'2022-04-29 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2916,0,0,42,0,2874,0,0,'04/2022','BIJU'),(2089,65,'2022-04-29 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,2920,0,0,42,0,2878,0,0,'04/2022','BIJU'),(2090,64,'2022-08-05 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Transfer','Sub to OP',0,2874,0,0,56,0,2818,0,0,'04/2022','BIJU'),(2091,3,'2022-08-05 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2962,0,0,56,0,2906,0,0,'04/2022','BIJU'),(2092,83,'2022-04-01 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999275,0,0,42,0,999233,0,0,'92/2018','CHEKUTTI'),(2093,68,'2022-04-01 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2625,0,0,84,0,2541,0,0,'92/2018','CHEKUTTI'),(2094,95,'2022-04-01 00:00:00','M95','TRIFLUOPERAZINE TABLETS IP 5MG','Transfer','Sub to OP',0,3000,0,0,84,0,2916,0,0,'92/2018','CHEKUTTI'),(2095,48,'2022-04-01 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2721,0,0,42,0,2679,0,0,'92/2018','CHEKUTTI'),(2096,47,'2022-04-01 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2733,0,0,42,0,2691,0,0,'92/2018','CHEKUTTI'),(2097,83,'2022-05-27 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999233,0,0,60,0,999173,0,0,'92/2018','CHEKUTTI'),(2098,68,'2022-05-27 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2541,0,0,120,0,2421,0,0,'92/2018','CHEKUTTI'),(2099,95,'2022-05-27 00:00:00','M95','TRIFLUOPERAZINE TABLETS IP 5MG','Transfer','Sub to OP',0,2916,0,0,120,0,2796,0,0,'92/2018','CHEKUTTI'),(2100,48,'2022-05-27 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2679,0,0,90,0,2589,0,0,'92/2018','CHEKUTTI'),(2101,83,'2022-07-29 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999173,0,0,57,0,999116,0,0,'92/2018','CHEKUTTI'),(2102,68,'2022-07-29 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2421,0,0,114,0,2307,0,0,'92/2018','CHEKUTTI'),(2103,46,'2022-07-29 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,997651,0,0,57,0,997594,0,0,'92/2018','CHEKUTTI'),(2104,49,'2022-07-29 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2873,0,0,57,0,2816,0,0,'92/2018','CHEKUTTI'),(2105,83,'2022-09-30 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999116,0,0,60,0,999056,0,0,'92/2018','CHEKUTTI'),(2106,40,'2022-09-30 00:00:00','M40','SERTRALINE HCL TABLETS 25MG','Transfer','Sub to OP',0,2272,0,0,30,0,2242,0,0,'92/2018','CHEKUTTI'),(2107,49,'2022-09-30 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2816,0,0,45,0,2771,0,0,'92/2018','CHEKUTTI'),(2108,82,'2022-06-03 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,999161,0,0,168,0,998993,0,0,'8/2014','DHANISHMA'),(2109,82,'2022-09-16 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,998993,0,0,84,0,998909,0,0,'8/2014','DHANISHMA'),(2110,5,'2022-04-15 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2874,0,0,14,0,2860,0,0,'202/2021','SHAJI'),(2111,4,'2022-04-15 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,2972,0,0,14,0,2958,0,0,'202/2021','SHAJI'),(2112,81,'2022-08-05 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999867,0,0,56,0,999811,0,0,'104/2018','HASEENA'),(2113,40,'2022-08-05 00:00:00','M40','SERTRALINE HCL TABLETS 25MG','Transfer','Sub to OP',0,2242,0,0,112,0,2130,0,0,'104/2018','HASEENA'),(2114,38,'2022-10-14 00:00:00','M38','SERTRALINE HCL TABLETS 100MG','Transfer','Sub to OP',0,3000,0,0,180,0,2820,0,0,'104/2018','HASEENA'),(2115,81,'2022-10-14 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999811,0,0,90,0,999721,0,0,'104/2018','HASEENA'),(2116,73,'2022-04-29 00:00:00','M73','QUETIAPINE TABLETS 200MG','Transfer','Sub to OP',0,3000,0,0,7,0,2993,0,0,'0078/2022','SREEDEVI'),(2117,83,'2022-04-29 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999056,0,0,14,0,999042,0,0,'0078/2022','SREEDEVI'),(2118,49,'2022-04-29 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2771,0,0,7,0,2764,0,0,'0078/2022','SREEDEVI'),(2119,47,'2022-04-29 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2691,0,0,7,0,2684,0,0,'0078/2022','SREEDEVI'),(2120,46,'2022-04-29 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,997594,0,0,14,0,997580,0,0,'0078/2022','SREEDEVI'),(2121,89,'2022-04-29 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,2897,0,0,14,0,2883,0,0,'0078/2022','SREEDEVI'),(2122,29,'2022-04-29 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,2790,0,0,14,0,2776,0,0,'0078/2022','SREEDEVI'),(2123,83,'2022-05-05 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999042,0,0,28,0,999014,0,0,'0078/2022','SREEDEVI'),(2124,73,'2022-05-05 00:00:00','M73','QUETIAPINE TABLETS 200MG','Transfer','Sub to OP',0,2993,0,0,14,0,2979,0,0,'0078/2022','SREEDEVI'),(2125,49,'2022-05-05 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2764,0,0,14,0,2750,0,0,'0078/2022','SREEDEVI'),(2126,47,'2022-05-05 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2684,0,0,14,0,2670,0,0,'0078/2022','SREEDEVI'),(2127,46,'2022-05-05 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,997580,0,0,28,0,997552,0,0,'0078/2022','SREEDEVI'),(2128,29,'2022-05-05 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,2776,0,0,28,0,2748,0,0,'0078/2022','SREEDEVI'),(2129,83,'2022-05-20 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,999014,0,0,56,0,998958,0,0,'0078/2022','SREEDEVI'),(2130,49,'2022-05-20 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2750,0,0,28,0,2722,0,0,'0078/2022','SREEDEVI'),(2131,47,'2022-05-20 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2670,0,0,28,0,2642,0,0,'0078/2022','SREEDEVI'),(2132,46,'2022-05-20 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,997552,0,0,56,0,997496,0,0,'0078/2022','SREEDEVI'),(2133,29,'2022-05-20 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,2748,0,0,28,0,2720,0,0,'0078/2022','SREEDEVI'),(2134,72,'2022-05-20 00:00:00','M72','QUETIAPINE TABLETS 100MG','Transfer','Sub to OP',0,2979,0,0,28,0,2951,0,0,'0078/2022','SREEDEVI'),(2135,71,'2022-06-17 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9698,0,0,28,0,9670,0,0,'0078/2022','SREEDEVI'),(2136,46,'2022-06-17 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,997496,0,0,56,0,997440,0,0,'0078/2022','SREEDEVI'),(2137,29,'2022-06-17 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,2720,0,0,56,0,2664,0,0,'0078/2022','SREEDEVI'),(2138,70,'2022-07-15 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18999,0,0,42,0,18957,0,0,'0078/2022','SREEDEVI'),(2139,46,'2022-07-15 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,997440,0,0,84,0,997356,0,0,'0078/2022','SREEDEVI'),(2140,29,'2022-07-15 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,2664,0,0,84,0,2580,0,0,'0078/2022','SREEDEVI'),(2141,83,'2022-07-15 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,998958,0,0,84,0,998874,0,0,'0078/2022','SREEDEVI'),(2142,49,'2022-07-15 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2722,0,0,42,0,2680,0,0,'0078/2022','SREEDEVI'),(2143,47,'2022-07-15 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2642,0,0,42,0,2600,0,0,'0078/2022','SREEDEVI'),(2144,28,'2022-07-29 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2088,0,0,84,0,2004,0,0,'79/2021','HAMEED'),(2145,83,'2022-07-29 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,998874,0,0,84,0,998790,0,0,'79/2021','HAMEED'),(2146,4,'2022-07-29 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,2958,0,0,84,0,2874,0,0,'79/2021','HAMEED'),(2147,48,'2022-04-15 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2589,0,0,56,0,2533,0,0,'27/2017','FADALU (FAIZAL)'),(2148,47,'2022-04-15 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2600,0,0,56,0,2544,0,0,'27/2017','FADALU (FAIZAL)'),(2149,20,'2022-04-15 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,2972,0,0,56,0,2916,0,0,'27/2017','FADALU (FAIZAL)'),(2150,48,'2022-07-08 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2533,0,0,84,0,2449,0,0,'27/2017','FADALU (FAIZAL)'),(2151,20,'2022-07-08 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,2916,0,0,84,0,2832,0,0,'27/2017','FADALU (FAIZAL)'),(2152,48,'2022-08-19 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2449,0,0,56,0,2393,0,0,'27/2017','FADALU (FAIZAL)'),(2153,20,'2022-08-19 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,2832,0,0,56,0,2776,0,0,'27/2017','FADALU (FAIZAL)'),(2154,48,'2022-10-14 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2393,0,0,84,0,2309,0,0,'27/2017','FADALU (FAIZAL)'),(2155,20,'2022-10-14 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,2776,0,0,84,0,2692,0,0,'27/2017','FADALU (FAIZAL)'),(2156,21,'2022-09-16 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,2305,0,0,112,0,2193,0,0,'161/2019','ASHRAF CP'),(2157,43,'2022-09-16 00:00:00','M43','VENLAFAXINE EXTENDED RELEASE CAPSULES 75MG','Transfer','Sub to OP',0,2920,0,0,112,0,2808,0,0,'161/2019','ASHRAF CP'),(2158,69,'2022-09-16 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2475,0,0,56,0,2419,0,0,'161/2019','ASHRAF CP'),(2159,43,'2022-10-14 00:00:00','M43','VENLAFAXINE EXTENDED RELEASE CAPSULES 75MG','Transfer','Sub to OP',0,2808,0,0,58,0,2750,0,0,'161/2019','ASHRAF CP'),(2160,21,'2022-10-14 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,2193,0,0,112,0,2081,0,0,'161/2019','ASHRAF CP'),(2161,69,'2022-10-14 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2419,0,0,58,0,2361,0,0,'161/2019','ASHRAF CP'),(2162,46,'2022-02-18 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,997356,0,0,42,0,997314,0,0,'90/2017','RANEESH'),(2163,48,'2022-02-18 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2309,0,0,14,0,2295,0,0,'90/2017','RANEESH'),(2164,83,'2022-02-18 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,998790,0,0,28,0,998762,0,0,'90/2017','RANEESH'),(2165,34,'2022-02-18 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1828,0,0,14,0,1814,0,0,'90/2017','RANEESH'),(2166,76,'2022-02-18 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,2916,0,0,14,0,2902,0,0,'90/2017','RANEESH'),(2167,83,'2022-03-04 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,998762,0,0,56,0,998706,0,0,'90/2017','RANEESH'),(2168,46,'2022-03-04 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,997314,0,0,84,0,997230,0,0,'90/2017','RANEESH'),(2169,48,'2022-03-04 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2295,0,0,28,0,2267,0,0,'90/2017','RANEESH'),(2170,76,'2022-03-04 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,2902,0,0,28,0,2874,0,0,'90/2017','RANEESH'),(2171,34,'2022-03-04 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1814,0,0,28,0,1786,0,0,'90/2017','RANEESH'),(2172,82,'2022-10-14 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,998909,0,0,14,0,998895,0,0,'90/2017','RANEESH'),(2173,83,'2022-10-14 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,998706,0,0,28,0,998678,0,0,'90/2017','RANEESH'),(2174,46,'2022-10-14 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,997230,0,0,42,0,997188,0,0,'90/2017','RANEESH'),(2175,49,'2022-10-14 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2680,0,0,14,0,2666,0,0,'90/2017','RANEESH'),(2176,48,'2022-10-14 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2267,0,0,14,0,2253,0,0,'90/2017','RANEESH'),(2177,76,'2022-10-14 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,2874,0,0,14,0,2860,0,0,'90/2017','RANEESH'),(2178,70,'2022-10-14 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18957,0,0,14,0,18943,0,0,'90/2017','RANEESH'),(2179,83,'2022-10-14 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,998678,0,0,56,0,998622,0,0,'155/2022','SAINUDHEEN'),(2180,34,'2022-10-14 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1786,0,0,28,0,1758,0,0,'155/2022','SAINUDHEEN'),(2181,45,'2022-10-14 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,2930,0,0,56,0,2874,0,0,'211/2019','RAJAN'),(2182,88,'2022-10-14 00:00:00','M88','CLONAZEPAM & ESCITALOPRAM OXALATE TABLETS 5 MG','Transfer','Sub to OP',0,3000,0,0,42,0,2958,0,0,'211/2019','RAJAN'),(2183,81,'2022-10-14 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999721,0,0,56,0,999665,0,0,'211/2019','RAJAN'),(2184,31,'2022-10-14 00:00:00','M31','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 3MG','Transfer','Sub to OP',0,2846,0,0,56,0,2790,0,0,'211/2019','RAJAN'),(2185,46,'2022-10-14 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,997188,0,0,56,0,997132,0,0,'211/2019','RAJAN'),(2186,5,'2022-10-14 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2860,0,0,56,0,2804,0,0,'211/2019','RAJAN'),(2187,76,'2022-10-14 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,2860,0,0,56,0,2804,0,0,'211/2019','RAJAN'),(2188,68,'2022-10-14 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2307,0,0,126,0,2181,0,0,'99/2019','SUNIL'),(2189,34,'2022-10-14 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1758,0,0,7,0,1751,0,0,'247/2021','NOUSHAD '),(2190,35,'2022-10-14 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2698,0,0,7,0,2691,0,0,'247/2021','NOUSHAD '),(2191,83,'2022-10-14 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,998622,0,0,14,0,998608,0,0,'247/2021','NOUSHAD '),(2192,82,'2022-10-14 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,998895,0,0,7,0,998888,0,0,'247/2021','NOUSHAD '),(2193,46,'2022-10-14 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,997132,0,0,21,0,997111,0,0,'247/2021','NOUSHAD '),(2194,71,'2022-10-14 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9670,0,0,7,0,9663,0,0,'247/2021','NOUSHAD '),(2195,87,'2022-10-14 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Transfer','Sub to OP',0,2979,0,0,11,0,2968,0,0,'247/2021','NOUSHAD '),(2196,19,'2022-10-14 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,2972,0,0,21,0,2951,0,0,'080/2020','SAJNA'),(2197,45,'2022-10-14 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,2874,0,0,7,0,2867,0,0,'080/2020','SAJNA'),(2198,34,'2022-10-14 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1751,0,0,28,0,1723,0,0,'202/2022','BINDU'),(2199,46,'2022-10-14 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,997111,0,0,56,0,997055,0,0,'202/2022','BINDU'),(2200,82,'2022-10-14 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,998888,0,0,70,0,998818,0,0,'75/2019','UNNIKRISHNAN'),(2201,83,'2022-10-14 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,998608,0,0,70,0,998538,0,0,'75/2019','UNNIKRISHNAN'),(2202,46,'2022-10-14 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,997055,0,0,140,0,996915,0,0,'75/2019','UNNIKRISHNAN'),(2203,68,'2022-10-14 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2181,0,0,105,0,2076,0,0,'75/2019','UNNIKRISHNAN'),(2204,33,'2022-10-14 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2730,0,0,28,0,2702,0,0,'200/2022','KOLAVAM'),(2205,29,'2022-10-14 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,2580,0,0,84,0,2496,0,0,'205/2022','ABDUL RASAK'),(2206,36,'2022-10-14 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2909,0,0,56,0,2853,0,0,'205/2022','ABDUL RASAK'),(2207,46,'2022-10-14 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,996915,0,0,56,0,996859,0,0,'205/2022','ABDUL RASAK'),(2208,21,'2022-10-14 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,2081,0,0,56,0,2025,0,0,'205/2022','ABDUL RASAK'),(2209,56,'2022-10-14 00:00:00','M56','CLOMIPRAMINE TABLETS 25MG','Transfer','Sub to OP',0,2972,0,0,56,0,2916,0,0,'205/2022','ABDUL RASAK'),(2210,12,'2022-10-14 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2699,0,0,14,0,2685,0,0,'201/2022','PRAMOD'),(2211,31,'2022-10-14 00:00:00','M31','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 3MG','Transfer','Sub to OP',0,2790,0,0,7,0,2783,0,0,'201/2022','PRAMOD'),(2212,83,'2022-08-19 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,998538,0,0,112,0,998426,0,0,'0078/2022','SREEDEVI'),(2213,49,'2022-08-19 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2666,0,0,56,0,2610,0,0,'0078/2022','SREEDEVI'),(2214,47,'2022-08-19 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2544,0,0,56,0,2488,0,0,'0078/2022','SREEDEVI'),(2215,71,'2022-08-19 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9663,0,0,56,0,9607,0,0,'0078/2022','SREEDEVI'),(2216,70,'2022-08-19 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18943,0,0,56,0,18887,0,0,'0078/2022','SREEDEVI'),(2217,46,'2022-08-19 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,996859,0,0,112,0,996747,0,0,'0078/2022','SREEDEVI'),(2218,29,'2022-08-19 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,2496,0,0,56,0,2440,0,0,'0078/2022','SREEDEVI'),(2219,83,'2022-09-09 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,998426,0,0,56,0,998370,0,0,'0078/2022','SREEDEVI'),(2220,49,'2022-09-09 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2610,0,0,28,0,2582,0,0,'0078/2022','SREEDEVI'),(2221,47,'2022-09-09 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2488,0,0,28,0,2460,0,0,'0078/2022','SREEDEVI'),(2222,71,'2022-09-09 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9607,0,0,28,0,9579,0,0,'0078/2022','SREEDEVI'),(2223,70,'2022-09-09 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18887,0,0,28,0,18859,0,0,'0078/2022','SREEDEVI'),(2224,46,'2022-09-09 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,996747,0,0,56,0,996691,0,0,'0078/2022','SREEDEVI'),(2225,49,'2022-10-14 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2582,0,0,56,0,2526,0,0,'0078/2022','SREEDEVI'),(2226,47,'2022-10-14 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2460,0,0,56,0,2404,0,0,'0078/2022','SREEDEVI'),(2227,83,'2022-10-14 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,998370,0,0,112,0,998258,0,0,'0078/2022','SREEDEVI'),(2228,46,'2022-10-14 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,996691,0,0,112,0,996579,0,0,'0078/2022','SREEDEVI'),(2229,46,'2022-10-21 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,996579,0,0,7,0,996572,0,0,'225/2022','KUNJALU'),(2230,36,'2022-10-21 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2853,0,0,7,0,2846,0,0,'225/2022','KUNJALU'),(2231,82,'2022-10-21 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,998818,0,0,70,0,998748,0,0,'58/2021','SUMAYYA'),(2232,83,'2022-10-21 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,998258,0,0,35,0,998223,0,0,'58/2021','SUMAYYA'),(2233,50,'2022-10-21 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2916,0,0,35,0,2881,0,0,'58/2021','SUMAYYA'),(2234,48,'2022-10-21 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2253,0,0,35,0,2218,0,0,'58/2021','SUMAYYA'),(2235,46,'2022-10-21 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,996572,0,0,140,0,996432,0,0,'58/2021','SUMAYYA'),(2236,83,'2022-08-26 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,998223,0,0,50,0,998173,0,0,'58/2021','SUMAYYA'),(2237,82,'2022-08-26 00:00:00','M82','SV 200MG','Transfer','Sub to OP',0,998748,0,0,100,0,998648,0,0,'58/2021','SUMAYYA'),(2238,48,'2022-08-26 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2218,0,0,50,0,2168,0,0,'58/2021','SUMAYYA'),(2239,50,'2022-08-26 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2881,0,0,50,0,2831,0,0,'58/2021','SUMAYYA'),(2240,46,'2022-08-26 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,996432,0,0,200,0,996232,0,0,'58/2021','SUMAYYA'),(2241,50,'2022-02-11 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2831,0,0,56,0,2775,0,0,'58/2021','SUMAYYA'),(2242,47,'2022-02-11 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2404,0,0,56,0,2348,0,0,'58/2021','SUMAYYA'),(2243,48,'2022-02-11 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2168,0,0,56,0,2112,0,0,'58/2021','SUMAYYA'),(2244,46,'2022-02-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,996232,0,0,168,0,996064,0,0,'58/2021','SUMAYYA'),(2245,82,'2022-10-24 00:00:00','M82','SV 200MG','Inbound','To main stock',0,998648,0,0,3000,3000,998648,0,0,'',''),(2246,82,'2022-04-08 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,998648,0,0,112,3000,998536,0,0,'58/2021','SUMAYYA'),(2247,83,'2022-04-08 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,998173,0,0,56,0,998117,0,0,'58/2021','SUMAYYA'),(2248,50,'2022-04-08 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2775,0,0,56,0,2719,0,0,'58/2021','SUMAYYA'),(2249,47,'2022-04-08 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2348,0,0,56,0,2292,0,0,'58/2021','SUMAYYA'),(2250,48,'2022-04-08 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2112,0,0,56,0,2056,0,0,'58/2021','SUMAYYA'),(2251,46,'2022-04-08 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,996064,0,0,168,0,995896,0,0,'58/2021','SUMAYYA'),(2252,82,'2022-07-08 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,998536,0,0,98,3000,998438,0,0,'58/2021','SUMAYYA'),(2253,83,'2022-07-08 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,998117,0,0,50,0,998067,0,0,'58/2021','SUMAYYA'),(2254,50,'2022-07-08 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2719,0,0,50,0,2669,0,0,'58/2021','SUMAYYA'),(2255,47,'2022-07-08 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2292,0,0,50,0,2242,0,0,'58/2021','SUMAYYA'),(2256,48,'2022-07-08 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2056,0,0,50,0,2006,0,0,'58/2021','SUMAYYA'),(2257,46,'2022-07-08 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,995896,0,0,150,0,995746,0,0,'58/2021','SUMAYYA'),(2258,33,'2022-05-20 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2702,0,0,100,0,2602,0,0,'0112/2017','ZEHARABI'),(2259,33,'2022-07-29 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2602,0,0,84,0,2518,0,0,'0112/2017','ZEHARABI'),(2260,33,'2022-10-21 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2518,0,0,74,0,2444,0,0,'0112/2017','ZEHARABI'),(2261,82,'2022-05-27 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,998438,0,0,7,3000,998431,0,0,'90/2022','MOHAMMED RUFAID '),(2262,81,'2022-05-27 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999665,0,0,7,0,999658,0,0,'90/2022','MOHAMMED RUFAID '),(2263,86,'2022-05-27 00:00:00','M86','CLOBAZAM TABLETS 10 MG','Transfer','Sub to OP',0,3000,0,0,14,0,2986,0,0,'90/2022','MOHAMMED RUFAID '),(2264,33,'2022-05-27 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2444,0,0,7,0,2437,0,0,'90/2022','MOHAMMED RUFAID '),(2265,82,'2022-06-03 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,998431,0,0,56,3000,998375,0,0,'90/2022','MOHAMMED RUFAID '),(2266,86,'2022-06-03 00:00:00','M86','CLOBAZAM TABLETS 10 MG','Transfer','Sub to OP',0,2986,0,0,56,0,2930,0,0,'90/2022','MOHAMMED RUFAID '),(2267,33,'2022-06-03 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2437,0,0,56,0,2381,0,0,'90/2022','MOHAMMED RUFAID '),(2268,81,'2022-08-26 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999658,0,0,84,0,999574,0,0,'90/2022','MOHAMMED RUFAID '),(2269,86,'2022-08-26 00:00:00','M86','CLOBAZAM TABLETS 10 MG','Transfer','Sub to OP',0,2930,0,0,84,0,2846,0,0,'90/2022','MOHAMMED RUFAID '),(2270,33,'2022-08-26 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2381,0,0,42,0,2339,0,0,'90/2022','MOHAMMED RUFAID '),(2271,81,'2022-10-21 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999574,0,0,56,0,999518,0,0,'90/2022','MOHAMMED RUFAID '),(2272,86,'2022-10-21 00:00:00','M86','CLOBAZAM TABLETS 10 MG','Transfer','Sub to OP',0,2846,0,0,112,0,2734,0,0,'90/2022','MOHAMMED RUFAID '),(2273,33,'2022-10-21 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2339,0,0,56,0,2283,0,0,'90/2022','MOHAMMED RUFAID '),(2274,20,'2022-10-21 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,2692,0,0,35,0,2657,0,0,'59/2021','KUNJUMUHAMMAD'),(2275,65,'2022-10-21 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,2878,0,0,35,0,2843,0,0,'59/2021','KUNJUMUHAMMAD'),(2276,19,'2022-10-21 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,2951,0,0,18,0,2933,0,0,'59/2021','KUNJUMUHAMMAD'),(2277,20,'2022-09-02 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,2657,0,0,49,0,2608,0,0,'59/2021','KUNJUMUHAMMAD'),(2278,65,'2022-09-02 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,2843,0,0,74,0,2769,0,0,'59/2021','KUNJUMUHAMMAD'),(2279,36,'2022-08-26 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2846,0,0,56,0,2790,0,0,'232/2021','USMAN'),(2280,46,'2022-08-26 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,995746,0,0,168,0,995578,0,0,'232/2021','USMAN'),(2281,82,'2022-08-26 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,998375,0,0,112,3000,998263,0,0,'232/2021','USMAN'),(2282,83,'2022-08-26 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,998067,0,0,56,0,998011,0,0,'232/2021','USMAN'),(2283,49,'2022-08-26 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2526,0,0,56,0,2470,0,0,'232/2021','USMAN'),(2284,82,'2022-10-21 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,998263,0,0,70,3000,998193,0,0,'232/2021','USMAN'),(2285,83,'2022-10-21 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,998011,0,0,35,0,997976,0,0,'232/2021','USMAN'),(2286,46,'2022-10-21 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,995578,0,0,95,0,995483,0,0,'232/2021','USMAN'),(2287,36,'2022-10-21 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2790,0,0,35,0,2755,0,0,'232/2021','USMAN'),(2288,49,'2022-10-21 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2470,0,0,35,0,2435,0,0,'232/2021','USMAN'),(2289,82,'2022-07-29 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,998193,0,0,14,3000,998179,0,0,'133/2022','SEMI'),(2290,34,'2022-07-29 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1723,0,0,7,0,1716,0,0,'133/2022','SEMI'),(2291,82,'2022-08-12 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,998179,0,0,7,3000,998172,0,0,'133/2022','SEMI'),(2292,83,'2022-08-12 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,997976,0,0,7,0,997969,0,0,'133/2022','SEMI'),(2293,34,'2022-08-12 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1716,0,0,7,0,1709,0,0,'133/2022','SEMI'),(2294,36,'2022-08-19 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2755,0,0,14,0,2741,0,0,'133/2022','SEMI'),(2295,70,'2022-08-19 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18859,0,0,14,0,18845,0,0,'133/2022','SEMI'),(2296,83,'2022-08-26 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,997969,0,0,14,0,997955,0,0,'133/2022','SEMI'),(2297,35,'2022-08-26 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2691,0,0,14,0,2677,0,0,'133/2022','SEMI'),(2298,70,'2022-08-26 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18845,0,0,7,0,18838,0,0,'133/2022','SEMI'),(2299,83,'2022-10-21 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,997955,0,0,28,0,997927,0,0,'133/2022','SEMI'),(2300,36,'2022-10-21 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2741,0,0,14,0,2727,0,0,'133/2022','SEMI'),(2301,70,'2022-10-21 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18838,0,0,14,0,18824,0,0,'133/2022','SEMI'),(2302,12,'2022-10-21 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2685,0,0,14,0,2671,0,0,'201/2022','PRAMOD'),(2303,35,'2022-10-21 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2677,0,0,14,0,2663,0,0,'201/2022','PRAMOD'),(2304,46,'2022-10-21 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,995483,0,0,14,0,995469,0,0,'201/2022','PRAMOD'),(2305,82,'2022-02-11 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,998172,0,0,35,3000,998137,0,0,'288/2021','SABIRA'),(2306,83,'2022-02-11 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,997927,0,0,35,0,997892,0,0,'288/2021','SABIRA'),(2307,36,'2022-02-11 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2727,0,0,35,0,2692,0,0,'288/2021','SABIRA'),(2308,46,'2022-02-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,995469,0,0,35,0,995434,0,0,'288/2021','SABIRA'),(2309,82,'2022-03-18 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,998137,0,0,56,3000,998081,0,0,'288/2021','SABIRA'),(2310,83,'2022-03-18 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,997892,0,0,56,0,997836,0,0,'288/2021','SABIRA'),(2311,35,'2022-03-18 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2663,0,0,56,0,2607,0,0,'288/2021','SABIRA'),(2312,46,'2022-03-18 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,995434,0,0,56,0,995378,0,0,'288/2021','SABIRA'),(2313,82,'2022-04-15 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,998081,0,0,252,3000,997829,0,0,'288/2021','SABIRA'),(2314,36,'2022-04-15 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2692,0,0,84,0,2608,0,0,'288/2021','SABIRA'),(2315,46,'2022-04-15 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,995378,0,0,252,0,995126,0,0,'288/2021','SABIRA'),(2316,82,'2022-08-19 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,997829,0,0,210,3000,997619,0,0,'288/2021','SABIRA'),(2317,35,'2022-08-19 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2607,0,0,70,0,2537,0,0,'288/2021','SABIRA'),(2318,46,'2022-08-19 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,995126,0,0,210,0,994916,0,0,'288/2021','SABIRA'),(2319,82,'2022-07-29 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,997619,0,0,252,3000,997367,0,0,'288/2021','SABIRA'),(2320,34,'2022-07-29 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1709,0,0,84,0,1625,0,0,'288/2021','SABIRA'),(2321,46,'2022-07-29 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,994916,0,0,252,0,994664,0,0,'288/2021','SABIRA'),(2322,19,'2022-07-29 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,2933,0,0,84,0,2849,0,0,'288/2021','SABIRA'),(2323,82,'2022-10-21 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,997367,0,0,63,3000,997304,0,0,'288/2021','SABIRA'),(2324,34,'2022-10-21 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1625,0,0,21,0,1604,0,0,'288/2021','SABIRA'),(2325,46,'2022-10-21 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,994664,0,0,21,0,994643,0,0,'288/2021','SABIRA'),(2326,19,'2022-10-21 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,2849,0,0,21,0,2828,0,0,'288/2021','SABIRA'),(2327,22,'2022-04-01 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2860,0,0,42,0,2818,0,0,'248/2021','RAMLA'),(2328,21,'2022-05-06 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,2025,0,0,56,0,1969,0,0,'248/2021','RAMLA'),(2329,22,'2022-08-26 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2818,0,0,63,0,2755,0,0,'248/2021','RAMLA'),(2330,22,'2022-09-09 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2755,0,0,14,0,2741,0,0,'248/2021','RAMLA'),(2331,22,'2022-10-21 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2741,0,0,14,0,2727,0,0,'248/2021','RAMLA'),(2332,82,'2022-06-17 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,997304,0,0,28,3000,997276,0,0,'90/2022','MOHAMMED RUFAID '),(2333,81,'2022-06-17 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999518,0,0,28,0,999490,0,0,'90/2022','MOHAMMED RUFAID '),(2334,81,'2022-07-15 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999490,0,0,112,0,999378,0,0,'90/2022','MOHAMMED RUFAID '),(2335,86,'2022-07-15 00:00:00','M86','CLOBAZAM TABLETS 10 MG','Transfer','Sub to OP',0,2734,0,0,112,0,2622,0,0,'90/2022','MOHAMMED RUFAID '),(2336,35,'2022-07-15 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2537,0,0,56,0,2481,0,0,'90/2022','MOHAMMED RUFAID '),(2337,81,'2022-10-21 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999378,0,0,21,0,999357,0,0,'203/2022','RASIYA BANU'),(2338,83,'2022-10-21 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,997836,0,0,21,0,997815,0,0,'203/2022','RASIYA BANU'),(2339,69,'2022-10-21 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2361,0,0,21,0,2340,0,0,'203/2022','RASIYA BANU'),(2340,67,'2022-10-21 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2718,0,0,21,0,2697,0,0,'203/2022','RASIYA BANU'),(2341,22,'2022-10-21 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2727,0,0,21,0,2706,0,0,'203/2022','RASIYA BANU'),(2342,28,'2022-10-21 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2004,0,0,168,0,1836,0,0,'79/2021','HAMEED'),(2343,83,'2022-10-21 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,997815,0,0,84,0,997731,0,0,'79/2021','HAMEED'),(2344,5,'2022-10-21 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2804,0,0,84,0,2720,0,0,'79/2021','HAMEED'),(2345,83,'2022-05-20 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,997731,0,0,112,0,997619,0,0,'137/2017','MUJEEBRAHMAN'),(2346,26,'2022-05-20 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,2979,0,0,84,0,2895,0,0,'137/2017','MUJEEBRAHMAN'),(2347,72,'2022-05-20 00:00:00','M72','QUETIAPINE TABLETS 100MG','Transfer','Sub to OP',0,2951,0,0,56,0,2895,0,0,'137/2017','MUJEEBRAHMAN'),(2348,71,'2022-05-20 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9579,0,0,56,0,9523,0,0,'137/2017','MUJEEBRAHMAN'),(2349,46,'2022-05-20 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,994643,0,0,168,0,994475,0,0,'137/2017','MUJEEBRAHMAN'),(2350,76,'2022-05-20 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,2804,0,0,56,0,2748,0,0,'137/2017','MUJEEBRAHMAN'),(2351,83,'2022-07-15 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,997619,0,0,168,0,997451,0,0,'137/2017','MUJEEBRAHMAN'),(2352,26,'2022-07-15 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,2895,0,0,84,0,2811,0,0,'137/2017','MUJEEBRAHMAN'),(2353,70,'2022-07-15 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18824,0,0,14,0,18810,0,0,'137/2017','MUJEEBRAHMAN'),(2354,46,'2022-07-15 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,994475,0,0,252,0,994223,0,0,'137/2017','MUJEEBRAHMAN'),(2355,76,'2022-07-15 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,2748,0,0,84,0,2664,0,0,'137/2017','MUJEEBRAHMAN'),(2356,35,'2022-07-22 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2481,0,0,84,0,2397,0,0,'52/2022','ISMAIL'),(2357,92,'2022-09-09 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2986,0,0,3,0,2983,0,0,'52/2022','ISMAIL'),(2358,11,'2022-09-09 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,3000,0,0,2,0,2998,0,0,'52/2022','ISMAIL'),(2359,11,'2022-10-21 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,2998,0,0,2,0,2996,0,0,'52/2022','ISMAIL'),(2360,92,'2022-10-21 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2983,0,0,2,0,2981,0,0,'52/2022','ISMAIL'),(2361,82,'2022-05-27 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,997276,0,0,182,3000,997094,0,0,'205/2019','SUBAIDA'),(2362,27,'2022-05-27 00:00:00','M27','LURASIDONE HCL TABLETS 40MG','Transfer','Sub to OP',0,3000,0,0,91,0,2909,0,0,'205/2019','SUBAIDA'),(2363,82,'2022-08-26 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,997094,0,0,70,3000,997024,0,0,'205/2019','SUBAIDA'),(2364,27,'2022-08-26 00:00:00','M27','LURASIDONE HCL TABLETS 40MG','Transfer','Sub to OP',0,2909,0,0,35,0,2874,0,0,'205/2019','SUBAIDA'),(2365,82,'2022-10-21 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,997024,0,0,168,3000,996856,0,0,'205/2019','SUBAIDA'),(2366,27,'2022-10-21 00:00:00','M27','LURASIDONE HCL TABLETS 40MG','Transfer','Sub to OP',0,2874,0,0,84,0,2790,0,0,'205/2019','SUBAIDA'),(2367,82,'2022-10-21 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996856,0,0,35,3000,996821,0,0,'287/2021','AYISHA'),(2368,83,'2022-10-21 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,997451,0,0,35,0,997416,0,0,'287/2021','AYISHA'),(2369,34,'2022-10-21 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1604,0,0,105,0,1499,0,0,'287/2021','AYISHA'),(2370,46,'2022-10-21 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,994223,0,0,70,0,994153,0,0,'287/2021','AYISHA'),(2371,83,'2022-03-18 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,997416,0,0,84,0,997332,0,0,'16/2021','SAFIYA'),(2372,82,'2022-03-18 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996821,0,0,84,3000,996737,0,0,'16/2021','SAFIYA'),(2373,69,'2022-03-18 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2340,0,0,84,0,2256,0,0,'16/2021','SAFIYA'),(2374,67,'2022-03-18 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2697,0,0,84,0,2613,0,0,'16/2021','SAFIYA'),(2375,46,'2022-03-18 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,994153,0,0,84,0,994069,0,0,'16/2021','SAFIYA'),(2376,83,'2022-06-03 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,997332,0,0,84,0,997248,0,0,'16/2021','SAFIYA'),(2377,82,'2022-06-03 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996737,0,0,84,3000,996653,0,0,'16/2021','SAFIYA'),(2378,69,'2022-06-03 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2256,0,0,84,0,2172,0,0,'16/2021','SAFIYA'),(2379,67,'2022-06-03 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2613,0,0,84,0,2529,0,0,'16/2021','SAFIYA'),(2380,46,'2022-06-03 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,994069,0,0,84,0,993985,0,0,'16/2021','SAFIYA'),(2381,83,'2022-08-26 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,997248,0,0,63,0,997185,0,0,'16/2021','SAFIYA'),(2382,69,'2022-08-26 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2172,0,0,63,0,2109,0,0,'16/2021','SAFIYA'),(2383,82,'2022-08-26 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996653,0,0,63,3000,996590,0,0,'16/2021','SAFIYA'),(2384,67,'2022-08-26 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2529,0,0,63,0,2466,0,0,'16/2021','SAFIYA'),(2385,46,'2022-08-26 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,993985,0,0,63,0,993922,0,0,'16/2021','SAFIYA'),(2386,83,'2022-10-21 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,997185,0,0,28,0,997157,0,0,'16/2021','SAFIYA'),(2387,68,'2022-10-21 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2076,0,0,14,0,2062,0,0,'16/2021','SAFIYA'),(2388,46,'2022-10-21 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,993922,0,0,14,0,993908,0,0,'16/2021','SAFIYA'),(2389,9,'2022-10-21 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,2856,0,0,56,0,2800,0,0,'63/2018','BABY'),(2390,8,'2022-10-21 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Transfer','Sub to OP',0,2856,0,0,56,0,2800,0,0,'63/2018','BABY'),(2391,50,'2022-10-21 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2669,0,0,49,0,2620,0,0,'01/2018','ABDUL NAZAR'),(2392,83,'2022-10-21 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,997157,0,0,98,0,997059,0,0,'01/2018','ABDUL NAZAR'),(2393,68,'2022-10-21 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2062,0,0,49,0,2013,0,0,'01/2018','ABDUL NAZAR'),(2394,67,'2022-10-21 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2466,0,0,49,0,2417,0,0,'01/2018','ABDUL NAZAR'),(2395,22,'2022-10-21 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2706,0,0,49,0,2657,0,0,'01/2018','ABDUL NAZAR'),(2396,49,'2022-08-26 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2435,0,0,63,0,2372,0,0,'45/2017','KORAN'),(2397,49,'2022-10-21 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2372,0,0,84,0,2288,0,0,'45/2017','KORAN'),(2398,49,'2022-07-29 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2288,0,0,28,0,2260,0,0,'45/2017','KORAN'),(2399,11,'2022-10-21 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,2996,0,0,2,0,2994,0,0,'36/2020','UMMUHABEEBA'),(2400,49,'2022-10-21 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2260,0,0,21,0,2239,0,0,'36/2020','UMMUHABEEBA'),(2401,47,'2022-10-21 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2242,0,0,21,0,2221,0,0,'36/2020','UMMUHABEEBA'),(2402,34,'2022-10-21 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1499,0,0,21,0,1478,0,0,'36/2020','UMMUHABEEBA'),(2403,12,'2022-10-28 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2671,0,0,56,0,2615,0,0,'97/2022','SAMEERA'),(2404,82,'2022-10-28 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996590,0,0,112,3000,996478,0,0,'97/2022','SAMEERA'),(2405,69,'2022-10-28 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2109,0,0,56,0,2053,0,0,'97/2022','SAMEERA'),(2406,22,'2022-10-28 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2657,0,0,56,0,2601,0,0,'97/2022','SAMEERA'),(2407,46,'2022-10-28 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,993908,0,0,56,0,993852,0,0,'97/2022','SAMEERA'),(2408,82,'2022-10-28 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996478,0,0,56,3000,996422,0,0,'134/2022','SABITHA '),(2409,83,'2022-10-28 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,997059,0,0,56,0,997003,0,0,'134/2022','SABITHA '),(2410,69,'2022-10-28 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,2053,0,0,56,0,1997,0,0,'134/2022','SABITHA '),(2411,69,'2022-08-05 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1997,0,0,7,0,1990,0,0,'134/2022','SABITHA '),(2412,82,'2022-08-05 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996422,0,0,14,3000,996408,0,0,'134/2022','SABITHA '),(2413,69,'2022-08-12 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1990,0,0,7,0,1983,0,0,'134/2022','SABITHA '),(2414,82,'2022-08-12 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996408,0,0,14,3000,996394,0,0,'134/2022','SABITHA '),(2415,69,'2022-08-19 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1983,0,0,28,0,1955,0,0,'134/2022','SABITHA '),(2416,82,'2022-08-19 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996394,0,0,56,3000,996338,0,0,'134/2022','SABITHA '),(2417,82,'2022-09-09 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996338,0,0,7,3000,996331,0,0,'134/2022','SABITHA '),(2418,83,'2022-09-09 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,997003,0,0,7,0,996996,0,0,'134/2022','SABITHA '),(2419,68,'2022-09-09 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2013,0,0,7,0,2006,0,0,'134/2022','SABITHA '),(2420,83,'2022-09-16 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,996996,0,0,14,0,996982,0,0,'134/2022','SABITHA '),(2421,82,'2022-09-16 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996331,0,0,14,3000,996317,0,0,'134/2022','SABITHA '),(2422,69,'2022-09-16 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1955,0,0,14,0,1941,0,0,'134/2022','SABITHA '),(2423,67,'2022-09-16 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2417,0,0,14,0,2403,0,0,'134/2022','SABITHA '),(2424,82,'2022-09-30 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996317,0,0,28,3000,996289,0,0,'134/2022','SABITHA '),(2425,83,'2022-09-30 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,996982,0,0,28,0,996954,0,0,'134/2022','SABITHA '),(2426,69,'2022-09-30 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1941,0,0,28,0,1913,0,0,'134/2022','SABITHA '),(2427,67,'2022-09-30 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2403,0,0,28,0,2375,0,0,'134/2022','SABITHA '),(2428,12,'2022-06-03 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2615,0,0,7,0,2608,0,0,'97/2022','SAMEERA'),(2429,35,'2022-04-15 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2397,0,0,56,0,2341,0,0,'211/2019','RAJAN'),(2430,45,'2022-04-15 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,2867,0,0,112,0,2755,0,0,'211/2019','RAJAN'),(2431,87,'2022-04-15 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Transfer','Sub to OP',0,2968,0,0,84,0,2884,0,0,'211/2019','RAJAN'),(2432,81,'2022-04-15 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999357,0,0,112,0,999245,0,0,'211/2019','RAJAN'),(2433,46,'2022-04-15 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,993852,0,0,168,0,993684,0,0,'211/2019','RAJAN'),(2434,5,'2022-04-15 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2720,0,0,56,0,2664,0,0,'211/2019','RAJAN'),(2435,45,'2022-06-10 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,2755,0,0,112,0,2643,0,0,'211/2019','RAJAN'),(2436,87,'2022-06-10 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Transfer','Sub to OP',0,2884,0,0,84,0,2800,0,0,'211/2019','RAJAN'),(2437,81,'2022-06-10 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999245,0,0,112,0,999133,0,0,'211/2019','RAJAN'),(2438,34,'2022-06-10 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1478,0,0,56,0,1422,0,0,'211/2019','RAJAN'),(2439,46,'2022-06-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,993684,0,0,112,0,993572,0,0,'211/2019','RAJAN'),(2440,5,'2022-06-10 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2664,0,0,56,0,2608,0,0,'211/2019','RAJAN'),(2441,76,'2022-06-10 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,2664,0,0,56,0,2608,0,0,'211/2019','RAJAN'),(2442,45,'2022-08-05 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,2643,0,0,56,0,2587,0,0,'211/2019','RAJAN'),(2443,87,'2022-08-05 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Transfer','Sub to OP',0,2800,0,0,42,0,2758,0,0,'211/2019','RAJAN'),(2444,81,'2022-08-05 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999133,0,0,56,0,999077,0,0,'211/2019','RAJAN'),(2445,35,'2022-08-05 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2341,0,0,28,0,2313,0,0,'211/2019','RAJAN'),(2446,46,'2022-08-05 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,993572,0,0,56,0,993516,0,0,'211/2019','RAJAN'),(2447,5,'2022-08-05 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2608,0,0,28,0,2580,0,0,'211/2019','RAJAN'),(2448,76,'2022-08-05 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,2608,0,0,28,0,2580,0,0,'211/2019','RAJAN'),(2449,45,'2022-10-28 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,2587,0,0,84,0,2503,0,0,'211/2019','RAJAN'),(2450,87,'2022-10-28 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Transfer','Sub to OP',0,2758,0,0,63,0,2695,0,0,'211/2019','RAJAN'),(2451,82,'2022-10-28 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996289,0,0,42,3000,996247,0,0,'211/2019','RAJAN'),(2452,81,'2022-10-28 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999077,0,0,42,0,999035,0,0,'211/2019','RAJAN'),(2453,34,'2022-10-28 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1422,0,0,42,0,1380,0,0,'211/2019','RAJAN'),(2454,5,'2022-10-28 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2580,0,0,42,0,2538,0,0,'211/2019','RAJAN'),(2455,76,'2022-10-28 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,2580,0,0,84,0,2496,0,0,'211/2019','RAJAN'),(2456,82,'2022-10-28 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996247,0,0,112,3000,996135,0,0,'135/2020','ALAVI'),(2457,69,'2022-10-28 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1913,0,0,56,0,1857,0,0,'135/2020','ALAVI'),(2458,22,'2022-10-28 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2601,0,0,56,0,2545,0,0,'135/2020','ALAVI'),(2459,46,'2022-10-28 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,993516,0,0,56,0,993460,0,0,'135/2020','ALAVI'),(2460,12,'2022-06-10 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2608,0,0,14,0,2594,0,0,'97/2022','SAMEERA'),(2461,12,'2022-06-24 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2594,0,0,28,0,2566,0,0,'97/2022','SAMEERA'),(2462,12,'2022-07-22 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2566,0,0,28,0,2538,0,0,'97/2022','SAMEERA'),(2463,12,'2022-08-19 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2538,0,0,56,0,2482,0,0,'97/2022','SAMEERA'),(2464,12,'2022-10-28 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2482,0,0,28,0,2454,0,0,'97/2022','SAMEERA'),(2465,81,'2022-10-28 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,999035,0,0,168,0,998867,0,0,'83/2019','FARSANA THASNI'),(2466,84,'2022-10-28 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,3000,0,0,168,0,2832,0,0,'83/2019','FARSANA THASNI'),(2467,59,'2022-10-28 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Transfer','Sub to OP',0,2944,0,0,84,0,2860,0,0,'83/2019','FARSANA THASNI'),(2468,57,'2022-10-28 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Transfer','Sub to OP',0,3000,0,0,84,0,2916,0,0,'83/2019','FARSANA THASNI'),(2469,81,'2022-09-09 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,998867,0,0,56,0,998811,0,0,'83/2019','FARSANA THASNI'),(2470,84,'2022-09-09 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,2832,0,0,56,0,2776,0,0,'83/2019','FARSANA THASNI'),(2471,59,'2022-09-09 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Transfer','Sub to OP',0,2860,0,0,28,0,2832,0,0,'83/2019','FARSANA THASNI'),(2472,57,'2022-09-09 00:00:00','M57','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 400MG','Transfer','Sub to OP',0,2916,0,0,28,0,2888,0,0,'83/2019','FARSANA THASNI'),(2473,83,'2022-03-04 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,996954,0,0,14,0,996940,0,0,'93/2017','SOORAJ'),(2474,82,'2022-03-04 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996135,0,0,7,3000,996128,0,0,'93/2017','SOORAJ'),(2475,34,'2022-03-04 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1380,0,0,7,0,1373,0,0,'93/2017','SOORAJ'),(2476,49,'2022-03-04 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2239,0,0,7,0,2232,0,0,'93/2017','SOORAJ'),(2477,48,'2022-03-04 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,2006,0,0,7,0,1999,0,0,'93/2017','SOORAJ'),(2478,46,'2022-03-04 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,993460,0,0,28,0,993432,0,0,'93/2017','SOORAJ'),(2479,82,'2022-03-11 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996128,0,0,14,3000,996114,0,0,'93/2017','SOORAJ'),(2480,83,'2022-03-11 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,996940,0,0,28,0,996912,0,0,'93/2017','SOORAJ'),(2481,34,'2022-03-11 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1373,0,0,14,0,1359,0,0,'93/2017','SOORAJ'),(2482,50,'2022-03-11 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2620,0,0,14,0,2606,0,0,'93/2017','SOORAJ'),(2483,48,'2022-03-11 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1999,0,0,14,0,1985,0,0,'93/2017','SOORAJ'),(2484,46,'2022-03-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,993432,0,0,56,0,993376,0,0,'93/2017','SOORAJ'),(2485,82,'2022-03-25 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996114,0,0,28,3000,996086,0,0,'93/2017','SOORAJ'),(2486,83,'2022-03-25 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,996912,0,0,56,0,996856,0,0,'93/2017','SOORAJ'),(2487,34,'2022-03-25 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1359,0,0,28,0,1331,0,0,'93/2017','SOORAJ'),(2488,50,'2022-03-25 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2606,0,0,28,0,2578,0,0,'93/2017','SOORAJ'),(2489,48,'2022-03-25 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1985,0,0,56,0,1929,0,0,'93/2017','SOORAJ'),(2490,46,'2022-03-25 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,993376,0,0,112,0,993264,0,0,'93/2017','SOORAJ'),(2491,82,'2022-04-22 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996086,0,0,28,3000,996058,0,0,'93/2017','SOORAJ'),(2492,83,'2022-04-22 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,996856,0,0,56,0,996800,0,0,'93/2017','SOORAJ'),(2493,34,'2022-04-22 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1331,0,0,28,0,1303,0,0,'93/2017','SOORAJ'),(2494,50,'2022-04-22 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2578,0,0,28,0,2550,0,0,'93/2017','SOORAJ'),(2495,48,'2022-04-22 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1929,0,0,56,0,1873,0,0,'93/2017','SOORAJ'),(2496,46,'2022-04-22 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,993264,0,0,112,0,993152,0,0,'93/2017','SOORAJ'),(2497,82,'2022-05-20 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996058,0,0,56,3000,996002,0,0,'93/2017','SOORAJ'),(2498,83,'2022-05-20 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,996800,0,0,112,0,996688,0,0,'93/2017','SOORAJ'),(2499,34,'2022-05-20 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1303,0,0,56,0,1247,0,0,'93/2017','SOORAJ'),(2500,50,'2022-05-20 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2550,0,0,56,0,2494,0,0,'93/2017','SOORAJ'),(2501,48,'2022-05-20 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1873,0,0,112,0,1761,0,0,'93/2017','SOORAJ'),(2502,46,'2022-05-20 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,993152,0,0,224,0,992928,0,0,'93/2017','SOORAJ'),(2503,82,'2022-07-22 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,996002,0,0,56,3000,995946,0,0,'93/2017','SOORAJ'),(2504,83,'2022-07-22 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,996688,0,0,112,0,996576,0,0,'93/2017','SOORAJ'),(2505,50,'2022-07-22 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2494,0,0,58,0,2436,0,0,'93/2017','SOORAJ'),(2506,48,'2022-07-22 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1761,0,0,112,0,1649,0,0,'93/2017','SOORAJ'),(2507,46,'2022-07-22 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,992928,0,0,224,0,992704,0,0,'93/2017','SOORAJ'),(2508,82,'2022-09-16 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,995946,0,0,56,3000,995890,0,0,'93/2017','SOORAJ'),(2509,83,'2022-09-16 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,996576,0,0,112,0,996464,0,0,'93/2017','SOORAJ'),(2510,50,'2022-09-16 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2436,0,0,56,0,2380,0,0,'93/2017','SOORAJ'),(2511,48,'2022-09-16 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1649,0,0,112,0,1537,0,0,'93/2017','SOORAJ'),(2512,46,'2022-09-16 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,992704,0,0,224,0,992480,0,0,'93/2017','SOORAJ'),(2513,82,'2022-10-28 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,995890,0,0,42,3000,995848,0,0,'93/2017','SOORAJ'),(2514,83,'2022-10-28 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,996464,0,0,84,0,996380,0,0,'93/2017','SOORAJ'),(2515,50,'2022-10-28 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2380,0,0,42,0,2338,0,0,'93/2017','SOORAJ'),(2516,48,'2022-10-28 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1537,0,0,84,0,1453,0,0,'93/2017','SOORAJ'),(2517,46,'2022-10-28 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,992480,0,0,168,0,992312,0,0,'93/2017','SOORAJ'),(2518,83,'2022-03-18 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,996380,0,0,84,0,996296,0,0,'135/2018','SOUDHA'),(2519,82,'2022-03-18 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,995848,0,0,84,3000,995764,0,0,'135/2018','SOUDHA'),(2520,84,'2022-03-18 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,2776,0,0,168,0,2608,0,0,'135/2018','SOUDHA'),(2521,69,'2022-03-18 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1857,0,0,84,0,1773,0,0,'135/2018','SOUDHA'),(2522,67,'2022-03-18 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2375,0,0,84,0,2291,0,0,'135/2018','SOUDHA'),(2523,76,'2022-03-18 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,2496,0,0,168,0,2328,0,0,'135/2018','SOUDHA'),(2524,46,'2022-03-18 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,992312,0,0,84,0,992228,0,0,'135/2018','SOUDHA'),(2525,83,'2022-06-10 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,996296,0,0,84,0,996212,0,0,'135/2018','SOUDHA'),(2526,82,'2022-06-10 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,995764,0,0,84,3000,995680,0,0,'135/2018','SOUDHA'),(2527,84,'2022-06-10 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,2608,0,0,168,0,2440,0,0,'135/2018','SOUDHA'),(2528,69,'2022-06-10 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1773,0,0,84,0,1689,0,0,'135/2018','SOUDHA'),(2529,76,'2022-06-10 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,2328,0,0,168,0,2160,0,0,'135/2018','SOUDHA'),(2530,46,'2022-06-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,992228,0,0,84,0,992144,0,0,'135/2018','SOUDHA'),(2531,83,'2022-07-01 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,996212,0,0,7,0,996205,0,0,'135/2018','SOUDHA'),(2532,82,'2022-07-01 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,995680,0,0,7,3000,995673,0,0,'135/2018','SOUDHA'),(2533,84,'2022-07-01 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,2440,0,0,14,0,2426,0,0,'135/2018','SOUDHA'),(2534,69,'2022-07-01 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1689,0,0,7,0,1682,0,0,'135/2018','SOUDHA'),(2535,67,'2022-07-01 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2291,0,0,7,0,2284,0,0,'135/2018','SOUDHA'),(2536,76,'2022-07-01 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,2160,0,0,14,0,2146,0,0,'135/2018','SOUDHA'),(2537,46,'2022-07-01 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,992144,0,0,7,0,992137,0,0,'135/2018','SOUDHA'),(2538,82,'2022-07-08 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,995673,0,0,56,3000,995617,0,0,'135/2018','SOUDHA'),(2539,83,'2022-07-08 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,996205,0,0,56,0,996149,0,0,'135/2018','SOUDHA'),(2540,84,'2022-07-08 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,2426,0,0,112,0,2314,0,0,'135/2018','SOUDHA'),(2541,69,'2022-07-08 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1682,0,0,56,0,1626,0,0,'135/2018','SOUDHA'),(2542,67,'2022-07-08 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2284,0,0,56,0,2228,0,0,'135/2018','SOUDHA'),(2543,76,'2022-07-08 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,2146,0,0,112,0,2034,0,0,'135/2018','SOUDHA'),(2544,82,'2022-09-02 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,995617,0,0,168,3000,995449,0,0,'135/2018','SOUDHA'),(2545,84,'2022-09-02 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,2314,0,0,112,0,2202,0,0,'135/2018','SOUDHA'),(2546,69,'2022-09-02 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1626,0,0,56,0,1570,0,0,'135/2018','SOUDHA'),(2547,67,'2022-09-02 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2228,0,0,56,0,2172,0,0,'135/2018','SOUDHA'),(2548,76,'2022-09-02 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,2034,0,0,112,0,1922,0,0,'135/2018','SOUDHA'),(2549,82,'2022-10-28 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,995449,0,0,168,3000,995281,0,0,'135/2018','SOUDHA'),(2550,84,'2022-10-28 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,2202,0,0,112,0,2090,0,0,'135/2018','SOUDHA'),(2551,69,'2022-10-28 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1570,0,0,56,0,1514,0,0,'135/2018','SOUDHA'),(2552,67,'2022-10-28 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2172,0,0,56,0,2116,0,0,'135/2018','SOUDHA'),(2553,75,'2022-10-28 00:00:00','M75','PROPRANOLOL SUSTAINED RELEASE TABLETS 40MG','Transfer','Sub to OP',0,3000,0,0,70,0,2930,0,0,'135/2018','SOUDHA'),(2554,46,'2022-10-28 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,992137,0,0,56,0,992081,0,0,'135/2018','SOUDHA'),(2555,11,'2022-04-15 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,2994,0,0,1,0,2993,0,0,'231/2021','MUHAMMAD IQBAL'),(2556,49,'2022-04-15 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2232,0,0,56,0,2176,0,0,'231/2021','MUHAMMAD IQBAL'),(2557,92,'2022-04-15 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2981,0,0,2,0,2979,0,0,'231/2021','MUHAMMAD IQBAL'),(2558,46,'2022-04-15 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,992081,0,0,56,0,992025,0,0,'231/2021','MUHAMMAD IQBAL'),(2559,11,'2022-06-10 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,2993,0,0,2,0,2991,0,0,'231/2021','MUHAMMAD IQBAL'),(2560,49,'2022-06-10 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2176,0,0,56,0,2120,0,0,'231/2021','MUHAMMAD IQBAL'),(2561,92,'2022-06-10 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2979,0,0,1,0,2978,0,0,'231/2021','MUHAMMAD IQBAL'),(2562,46,'2022-06-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,992025,0,0,56,0,991969,0,0,'231/2021','MUHAMMAD IQBAL'),(2563,11,'2022-08-12 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,2991,0,0,1,0,2990,0,0,'231/2021','MUHAMMAD IQBAL'),(2564,49,'2022-08-12 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2120,0,0,28,0,2092,0,0,'231/2021','MUHAMMAD IQBAL'),(2565,92,'2022-08-12 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2978,0,0,2,0,2976,0,0,'231/2021','MUHAMMAD IQBAL'),(2566,46,'2022-08-12 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,991969,0,0,58,0,991911,0,0,'231/2021','MUHAMMAD IQBAL'),(2567,11,'2022-09-30 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,2990,0,0,1,0,2989,0,0,'231/2021','MUHAMMAD IQBAL'),(2568,49,'2022-09-30 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2092,0,0,28,0,2064,0,0,'231/2021','MUHAMMAD IQBAL'),(2569,92,'2022-09-30 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2976,0,0,2,0,2974,0,0,'231/2021','MUHAMMAD IQBAL'),(2570,46,'2022-09-30 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,991911,0,0,28,0,991883,0,0,'231/2021','MUHAMMAD IQBAL'),(2571,11,'2022-10-28 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,2989,0,0,2,0,2987,0,0,'231/2021','MUHAMMAD IQBAL'),(2572,49,'2022-10-28 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2064,0,0,42,0,2022,0,0,'231/2021','MUHAMMAD IQBAL'),(2573,92,'2022-10-28 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2974,0,0,2,0,2972,0,0,'231/2021','MUHAMMAD IQBAL'),(2574,46,'2022-10-28 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,991883,0,0,42,0,991841,0,0,'231/2021','MUHAMMAD IQBAL'),(2575,83,'2022-10-28 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,996149,0,0,84,0,996065,0,0,'92/2018','CHEKUTTI'),(2576,49,'2022-10-28 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,2022,0,0,63,0,1959,0,0,'92/2018','CHEKUTTI'),(2577,39,'2022-10-28 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Transfer','Sub to OP',0,2881,0,0,42,0,2839,0,0,'92/2018','CHEKUTTI'),(2578,69,'2022-04-01 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1514,0,0,14,0,1500,0,0,'56/2022','UNNIKRISHNAN'),(2579,70,'2022-04-01 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18810,0,0,14,0,18796,0,0,'56/2022','UNNIKRISHNAN'),(2580,69,'2022-04-15 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1500,0,0,28,0,1472,0,0,'56/2022','UNNIKRISHNAN'),(2581,70,'2022-04-15 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18796,0,0,28,0,18768,0,0,'56/2022','UNNIKRISHNAN'),(2582,69,'2022-05-13 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1472,0,0,28,0,1444,0,0,'56/2022','UNNIKRISHNAN'),(2583,70,'2022-05-13 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18768,0,0,28,0,18740,0,0,'56/2022','UNNIKRISHNAN'),(2584,69,'2022-06-10 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1444,0,0,42,0,1402,0,0,'56/2022','UNNIKRISHNAN'),(2585,70,'2022-06-10 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18740,0,0,21,0,18719,0,0,'56/2022','UNNIKRISHNAN'),(2586,69,'2022-09-30 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1402,0,0,42,0,1360,0,0,'56/2022','UNNIKRISHNAN'),(2587,70,'2022-09-30 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18719,0,0,28,0,18691,0,0,'56/2022','UNNIKRISHNAN'),(2588,68,'2022-10-28 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,2006,0,0,56,0,1950,0,0,'56/2022','UNNIKRISHNAN'),(2589,70,'2022-10-28 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18691,0,0,28,0,18663,0,0,'56/2022','UNNIKRISHNAN'),(2590,5,'2022-05-27 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2538,0,0,14,0,2524,0,0,'168/2021','FATHIMAKUTTY'),(2591,4,'2022-05-27 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,2874,0,0,14,0,2860,0,0,'168/2021','FATHIMAKUTTY'),(2592,4,'2022-06-17 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,2860,0,0,21,0,2839,0,0,'168/2021','FATHIMAKUTTY'),(2593,5,'2022-06-17 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2524,0,0,21,0,2503,0,0,'168/2021','FATHIMAKUTTY'),(2594,5,'2022-07-15 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2503,0,0,28,0,2475,0,0,'168/2021','FATHIMAKUTTY'),(2595,4,'2022-07-15 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,2839,0,0,28,0,2811,0,0,'168/2021','FATHIMAKUTTY'),(2596,4,'2022-07-29 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,2811,0,0,14,0,2797,0,0,'168/2021','FATHIMAKUTTY'),(2597,5,'2022-07-29 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2475,0,0,14,0,2461,0,0,'168/2021','FATHIMAKUTTY'),(2598,5,'2022-09-09 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2461,0,0,14,0,2447,0,0,'168/2021','FATHIMAKUTTY'),(2599,4,'2022-09-09 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,2797,0,0,14,0,2783,0,0,'168/2021','FATHIMAKUTTY'),(2600,64,'2022-09-09 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Transfer','Sub to OP',0,2818,0,0,14,0,2804,0,0,'168/2021','FATHIMAKUTTY'),(2601,4,'2022-10-28 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,2783,0,0,28,0,2755,0,0,'168/2021','FATHIMAKUTTY'),(2602,23,'2022-10-28 00:00:00','M23','FLUOXETINE CAPSULES 10MG','Transfer','Sub to OP',0,3000,0,0,28,0,2972,0,0,'168/2021','FATHIMAKUTTY'),(2603,83,'2022-10-21 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,996065,0,0,42,0,996023,0,0,'204/2022','ANSIF'),(2604,82,'2022-10-21 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,995281,0,0,21,3000,995260,0,0,'204/2022','ANSIF'),(2605,69,'2022-10-21 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1360,0,0,42,0,1318,0,0,'204/2022','ANSIF'),(2606,68,'2022-10-21 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1950,0,0,21,0,1929,0,0,'204/2022','ANSIF'),(2607,28,'2022-10-21 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,1836,0,0,63,0,1773,0,0,'204/2022','ANSIF'),(2608,46,'2022-10-21 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,991841,0,0,42,0,991799,0,0,'204/2022','ANSIF'),(2609,83,'2022-10-28 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,996023,0,0,28,0,995995,0,0,'204/2022','ANSIF'),(2610,68,'2022-10-28 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1929,0,0,14,0,1915,0,0,'204/2022','ANSIF'),(2611,82,'2022-10-28 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,995260,0,0,14,3000,995246,0,0,'204/2022','ANSIF'),(2612,28,'2022-10-28 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,1773,0,0,21,0,1752,0,0,'204/2022','ANSIF'),(2613,46,'2022-10-28 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,991799,0,0,28,0,991771,0,0,'204/2022','ANSIF'),(2614,83,'2022-04-29 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,995995,0,0,56,0,995939,0,0,'38/2017','UNNEENKUTTY'),(2615,46,'2022-04-29 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,991771,0,0,84,0,991687,0,0,'38/2017','UNNEENKUTTY'),(2616,50,'2022-04-29 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2338,0,0,28,0,2310,0,0,'38/2017','UNNEENKUTTY'),(2617,47,'2022-04-29 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2221,0,0,84,0,2137,0,0,'38/2017','UNNEENKUTTY'),(2618,26,'2022-04-29 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,2811,0,0,56,0,2755,0,0,'38/2017','UNNEENKUTTY'),(2619,25,'2022-04-29 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,2944,0,0,28,0,2916,0,0,'38/2017','UNNEENKUTTY'),(2620,83,'2022-05-27 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,995939,0,0,56,0,995883,0,0,'38/2017','UNNEENKUTTY'),(2621,46,'2022-05-27 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,991687,0,0,84,0,991603,0,0,'38/2017','UNNEENKUTTY'),(2622,50,'2022-05-27 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2310,0,0,28,0,2282,0,0,'38/2017','UNNEENKUTTY'),(2623,47,'2022-05-27 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2137,0,0,84,0,2053,0,0,'38/2017','UNNEENKUTTY'),(2624,26,'2022-05-27 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,2755,0,0,56,0,2699,0,0,'38/2017','UNNEENKUTTY'),(2625,25,'2022-05-27 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,2916,0,0,28,0,2888,0,0,'38/2017','UNNEENKUTTY'),(2626,83,'2022-06-17 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,995883,0,0,42,0,995841,0,0,'38/2017','UNNEENKUTTY'),(2627,46,'2022-06-17 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,991603,0,0,63,0,991540,0,0,'38/2017','UNNEENKUTTY'),(2628,50,'2022-06-17 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2282,0,0,21,0,2261,0,0,'38/2017','UNNEENKUTTY'),(2629,48,'2022-06-17 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1453,0,0,42,0,1411,0,0,'38/2017','UNNEENKUTTY'),(2630,26,'2022-06-17 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,2699,0,0,42,0,2657,0,0,'38/2017','UNNEENKUTTY'),(2631,83,'2022-07-01 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,995841,0,0,14,0,995827,0,0,'38/2017','UNNEENKUTTY'),(2632,46,'2022-07-01 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,991540,0,0,21,0,991519,0,0,'38/2017','UNNEENKUTTY'),(2633,50,'2022-07-01 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2261,0,0,7,0,2254,0,0,'38/2017','UNNEENKUTTY'),(2634,48,'2022-07-01 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1411,0,0,7,0,1404,0,0,'38/2017','UNNEENKUTTY'),(2635,26,'2022-07-01 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,2657,0,0,14,0,2643,0,0,'38/2017','UNNEENKUTTY'),(2636,25,'2022-07-01 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,2888,0,0,7,0,2881,0,0,'38/2017','UNNEENKUTTY'),(2637,91,'2022-07-01 00:00:00','M91','LORAZEPAM TABLETS 2MG ','Transfer','Sub to OP',0,2993,0,0,14,0,2979,0,0,'38/2017','UNNEENKUTTY'),(2638,82,'2022-07-15 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,995246,0,0,7,3000,995239,0,0,'38/2017','UNNEENKUTTY'),(2639,83,'2022-07-15 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,995827,0,0,7,0,995820,0,0,'38/2017','UNNEENKUTTY'),(2640,46,'2022-07-15 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,991519,0,0,21,0,991498,0,0,'38/2017','UNNEENKUTTY'),(2641,50,'2022-07-15 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2254,0,0,7,0,2247,0,0,'38/2017','UNNEENKUTTY'),(2642,48,'2022-07-15 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1404,0,0,7,0,1397,0,0,'38/2017','UNNEENKUTTY'),(2643,26,'2022-07-15 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,2643,0,0,21,0,2622,0,0,'38/2017','UNNEENKUTTY'),(2644,90,'2022-07-15 00:00:00','M90','LORAZEPAM TABLETS 1 MG','Transfer','Sub to OP',0,2986,0,0,7,0,2979,0,0,'38/2017','UNNEENKUTTY'),(2645,82,'2022-07-29 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,995239,0,0,14,3000,995225,0,0,'38/2017','UNNEENKUTTY'),(2646,83,'2022-07-29 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,995820,0,0,14,0,995806,0,0,'38/2017','UNNEENKUTTY'),(2647,46,'2022-07-29 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,991498,0,0,42,0,991456,0,0,'38/2017','UNNEENKUTTY'),(2648,50,'2022-07-29 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2247,0,0,14,0,2233,0,0,'38/2017','UNNEENKUTTY'),(2649,48,'2022-07-29 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1397,0,0,14,0,1383,0,0,'38/2017','UNNEENKUTTY'),(2650,26,'2022-07-29 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,2622,0,0,42,0,2580,0,0,'38/2017','UNNEENKUTTY'),(2651,90,'2022-07-29 00:00:00','M90','LORAZEPAM TABLETS 1 MG','Transfer','Sub to OP',0,2979,0,0,14,0,2965,0,0,'38/2017','UNNEENKUTTY'),(2652,90,'2022-10-28 00:00:00','M90','LORAZEPAM TABLETS 1 MG','Transfer','Sub to OP',0,2965,0,0,28,0,2937,0,0,'38/2017','UNNEENKUTTY'),(2653,71,'2022-10-28 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9523,0,0,28,0,9495,0,0,'38/2017','UNNEENKUTTY'),(2654,49,'2022-05-20 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1959,0,0,70,0,1889,0,0,'088/2017','MUHAMMAD RAFEEQ'),(2655,47,'2022-05-20 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,2053,0,0,70,0,1983,0,0,'088/2017','MUHAMMAD RAFEEQ'),(2656,9,'2022-05-20 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,2800,0,0,70,0,2730,0,0,'088/2017','MUHAMMAD RAFEEQ'),(2657,46,'2022-05-20 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,991456,0,0,70,0,991386,0,0,'088/2017','MUHAMMAD RAFEEQ'),(2658,36,'2022-07-29 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2608,0,0,168,0,2440,0,0,'088/2017','MUHAMMAD RAFEEQ'),(2659,46,'2022-07-29 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,991386,0,0,84,0,991302,0,0,'088/2017','MUHAMMAD RAFEEQ'),(2660,36,'2022-10-21 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2440,0,0,168,0,2272,0,0,'088/2017','MUHAMMAD RAFEEQ'),(2661,46,'2022-10-21 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,991302,0,0,84,0,991218,0,0,'088/2017','MUHAMMAD RAFEEQ'),(2662,49,'2022-03-25 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1889,0,0,56,0,1833,0,0,'88/2017','MUHAMMAD RAFI'),(2663,47,'2022-03-25 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1983,0,0,56,0,1927,0,0,'88/2017','MUHAMMAD RAFI'),(2664,9,'2022-03-25 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,2730,0,0,56,0,2674,0,0,'88/2017','MUHAMMAD RAFI'),(2665,46,'2022-03-25 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,991218,0,0,56,0,991162,0,0,'88/2017','MUHAMMAD RAFI'),(2666,49,'2022-05-20 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1833,0,0,70,0,1763,0,0,'88/2017','MUHAMMAD RAFI'),(2667,47,'2022-05-20 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1927,0,0,70,0,1857,0,0,'88/2017','MUHAMMAD RAFI'),(2668,9,'2022-05-20 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,2674,0,0,140,0,2534,0,0,'88/2017','MUHAMMAD RAFI'),(2669,49,'2022-07-29 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1763,0,0,84,0,1679,0,0,'88/2017','MUHAMMAD RAFI'),(2670,47,'2022-07-29 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1857,0,0,84,0,1773,0,0,'88/2017','MUHAMMAD RAFI'),(2671,9,'2022-07-29 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,2534,0,0,168,0,2366,0,0,'88/2017','MUHAMMAD RAFI'),(2672,46,'2022-07-29 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,991162,0,0,84,0,991078,0,0,'88/2017','MUHAMMAD RAFI'),(2673,49,'2022-10-21 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1679,0,0,84,0,1595,0,0,'88/2017','MUHAMMAD RAFI'),(2674,47,'2022-10-21 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1773,0,0,84,0,1689,0,0,'88/2017','MUHAMMAD RAFI'),(2675,9,'2022-10-21 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,2366,0,0,168,0,2198,0,0,'88/2017','MUHAMMAD RAFI'),(2676,46,'2022-10-21 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,991078,0,0,84,0,990994,0,0,'88/2017','MUHAMMAD RAFI'),(2677,85,'2022-10-28 00:00:00','M85','LEVETIRACETAM TABLETS 250 MG','Transfer','Sub to OP',0,3000,0,0,14,0,2986,0,0,'8/2014','DHANISHMA'),(2678,81,'2022-11-04 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,998811,0,0,7,0,998804,0,0,'203/2022','RASIYA BANU'),(2679,83,'2022-11-04 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,995806,0,0,7,0,995799,0,0,'203/2022','RASIYA BANU'),(2680,68,'2022-11-04 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1915,0,0,7,0,1908,0,0,'203/2022','RASIYA BANU'),(2681,12,'2022-11-04 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2454,0,0,7,0,2447,0,0,'203/2022','RASIYA BANU'),(2682,68,'2022-11-04 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1908,0,0,112,0,1796,0,0,'292/2021','ABDUL NAZAR'),(2683,69,'2022-11-04 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1318,0,0,56,0,1262,0,0,'292/2021','ABDUL NAZAR'),(2684,70,'2022-11-04 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18663,0,0,56,0,18607,0,0,'292/2021','ABDUL NAZAR'),(2685,31,'2022-03-04 00:00:00','M31','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 3MG','Transfer','Sub to OP',0,2783,0,0,98,0,2685,0,0,'134/2020','MADHU'),(2686,46,'2022-03-04 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,990994,0,0,147,0,990847,0,0,'134/2020','MADHU'),(2687,83,'2022-03-04 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,995799,0,0,98,0,995701,0,0,'134/2020','MADHU'),(2688,71,'2022-03-04 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9495,0,0,49,0,9446,0,0,'134/2020','MADHU'),(2689,36,'2022-04-22 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2272,0,0,28,0,2244,0,0,'134/2020','MADHU'),(2690,33,'2022-04-22 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2283,0,0,28,0,2255,0,0,'134/2020','MADHU'),(2691,46,'2022-04-22 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,990847,0,0,84,0,990763,0,0,'134/2020','MADHU'),(2692,83,'2022-04-22 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,995701,0,0,56,0,995645,0,0,'134/2020','MADHU'),(2693,71,'2022-04-22 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9446,0,0,28,0,9418,0,0,'134/2020','MADHU'),(2694,36,'2022-05-20 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2244,0,0,56,0,2188,0,0,'134/2020','MADHU'),(2695,82,'2022-05-20 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,995225,0,0,112,3000,995113,0,0,'134/2020','MADHU'),(2696,83,'2022-05-20 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,995645,0,0,56,0,995589,0,0,'134/2020','MADHU'),(2697,82,'2022-07-15 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,995113,0,0,56,3000,995057,0,0,'134/2020','MADHU'),(2698,83,'2022-07-15 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,995589,0,0,56,0,995533,0,0,'134/2020','MADHU'),(2699,36,'2022-07-15 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2188,0,0,56,0,2132,0,0,'134/2020','MADHU'),(2700,33,'2022-07-15 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2255,0,0,56,0,2199,0,0,'134/2020','MADHU'),(2701,71,'2022-07-15 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9418,0,0,56,0,9362,0,0,'134/2020','MADHU'),(2702,46,'2022-07-15 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,990763,0,0,56,0,990707,0,0,'134/2020','MADHU'),(2703,82,'2022-09-09 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,995057,0,0,84,3000,994973,0,0,'134/2020','MADHU'),(2704,83,'2022-09-09 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,995533,0,0,84,0,995449,0,0,'134/2020','MADHU'),(2705,36,'2022-09-09 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2132,0,0,84,0,2048,0,0,'134/2020','MADHU'),(2706,33,'2022-09-09 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2199,0,0,84,0,2115,0,0,'134/2020','MADHU'),(2707,71,'2022-09-09 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9362,0,0,84,0,9278,0,0,'134/2020','MADHU'),(2708,46,'2022-09-09 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,990707,0,0,252,0,990455,0,0,'134/2020','MADHU'),(2709,82,'2022-11-04 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,994973,0,0,84,3000,994889,0,0,'134/2020','MADHU'),(2710,83,'2022-11-04 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,995449,0,0,84,0,995365,0,0,'134/2020','MADHU'),(2711,36,'2022-11-04 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,2048,0,0,84,0,1964,0,0,'134/2020','MADHU'),(2712,33,'2022-11-04 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2115,0,0,84,0,2031,0,0,'134/2020','MADHU'),(2713,71,'2022-11-04 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9278,0,0,84,0,9194,0,0,'134/2020','MADHU'),(2714,46,'2022-11-04 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,990455,0,0,252,0,990203,0,0,'134/2020','MADHU'),(2715,72,'2022-05-13 00:00:00','M72','QUETIAPINE TABLETS 100MG','Transfer','Sub to OP',0,2895,0,0,70,0,2825,0,0,'182/2021','MOHAMMAD BASHEER'),(2716,71,'2022-05-13 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9194,0,0,70,0,9124,0,0,'182/2021','MOHAMMAD BASHEER'),(2717,46,'2022-05-13 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,990203,0,0,210,0,989993,0,0,'182/2021','MOHAMMAD BASHEER'),(2718,83,'2022-05-13 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,995365,0,0,140,0,995225,0,0,'182/2021','MOHAMMAD BASHEER'),(2719,25,'2022-05-13 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,2881,0,0,210,0,2671,0,0,'182/2021','MOHAMMAD BASHEER'),(2720,48,'2022-05-13 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1383,0,0,70,0,1313,0,0,'182/2021','MOHAMMAD BASHEER'),(2721,72,'2022-07-08 00:00:00','M72','QUETIAPINE TABLETS 100MG','Transfer','Sub to OP',0,2825,0,0,84,0,2741,0,0,'182/2021','MOHAMMAD BASHEER'),(2722,46,'2022-07-08 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,989993,0,0,252,0,989741,0,0,'182/2021','MOHAMMAD BASHEER'),(2723,83,'2022-07-08 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,995225,0,0,168,0,995057,0,0,'182/2021','MOHAMMAD BASHEER'),(2724,25,'2022-07-08 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,2671,0,0,252,0,2419,0,0,'182/2021','MOHAMMAD BASHEER'),(2725,48,'2022-07-08 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1313,0,0,84,0,1229,0,0,'182/2021','MOHAMMAD BASHEER'),(2726,83,'2022-11-04 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,995057,0,0,84,0,994973,0,0,'182/2021','MOHAMMAD BASHEER'),(2727,82,'2022-11-04 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,994889,0,0,42,3000,994847,0,0,'182/2021','MOHAMMAD BASHEER'),(2728,71,'2022-11-04 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9124,0,0,42,0,9082,0,0,'182/2021','MOHAMMAD BASHEER'),(2729,26,'2022-11-04 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,2580,0,0,84,0,2496,0,0,'182/2021','MOHAMMAD BASHEER'),(2730,49,'2022-11-04 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1595,0,0,63,0,1532,0,0,'182/2021','MOHAMMAD BASHEER'),(2731,46,'2022-11-04 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,989741,0,0,126,0,989615,0,0,'182/2021','MOHAMMAD BASHEER'),(2732,82,'2022-02-25 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,994847,0,0,84,3000,994763,0,0,'34/2018','SAKHEER'),(2733,36,'2022-02-25 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1964,0,0,28,0,1936,0,0,'34/2018','SAKHEER'),(2734,33,'2022-02-25 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2031,0,0,28,0,2003,0,0,'34/2018','SAKHEER'),(2735,46,'2022-02-25 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,989615,0,0,28,0,989587,0,0,'34/2018','SAKHEER'),(2736,82,'2022-04-22 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,994763,0,0,168,3000,994595,0,0,'34/2018','SAKHEER'),(2737,36,'2022-04-22 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1936,0,0,56,0,1880,0,0,'34/2018','SAKHEER'),(2738,46,'2022-04-22 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,989587,0,0,112,0,989475,0,0,'34/2018','SAKHEER'),(2739,82,'2022-06-17 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,994595,0,0,168,3000,994427,0,0,'34/2018','SAKHEER'),(2740,36,'2022-06-17 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1880,0,0,56,0,1824,0,0,'34/2018','SAKHEER'),(2741,33,'2022-06-17 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,2003,0,0,56,0,1947,0,0,'34/2018','SAKHEER'),(2742,46,'2022-06-17 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,989475,0,0,56,0,989419,0,0,'34/2018','SAKHEER'),(2743,82,'2022-08-12 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,994427,0,0,252,3000,994175,0,0,'34/2018','SAKHEER'),(2744,36,'2022-08-12 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1824,0,0,84,0,1740,0,0,'34/2018','SAKHEER'),(2745,33,'2022-08-12 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1947,0,0,84,0,1863,0,0,'34/2018','SAKHEER'),(2746,46,'2022-08-12 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,989419,0,0,84,0,989335,0,0,'34/2018','SAKHEER'),(2747,82,'2022-11-04 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,994175,0,0,168,3000,994007,0,0,'34/2018','SAKHEER'),(2748,36,'2022-11-04 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1740,0,0,56,0,1684,0,0,'34/2018','SAKHEER'),(2749,33,'2022-11-04 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1863,0,0,56,0,1807,0,0,'34/2018','SAKHEER'),(2750,46,'2022-11-04 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,989335,0,0,56,0,989279,0,0,'34/2018','SAKHEER'),(2751,34,'2022-06-03 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1247,0,0,56,0,1191,0,0,'106/2017','VIJAYALAKSHMI'),(2752,46,'2022-06-03 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,989279,0,0,56,0,989223,0,0,'106/2017','VIJAYALAKSHMI'),(2753,34,'2022-07-29 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1191,0,0,56,0,1135,0,0,'106/2017','VIJAYALAKSHMI'),(2754,46,'2022-07-29 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,989223,0,0,56,0,989167,0,0,'106/2017','VIJAYALAKSHMI'),(2755,34,'2022-08-12 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1135,0,0,84,0,1051,0,0,'106/2017','VIJAYALAKSHMI'),(2756,46,'2022-08-12 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,989167,0,0,84,0,989083,0,0,'106/2017','VIJAYALAKSHMI'),(2757,34,'2022-11-04 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,1051,0,0,56,0,995,0,0,'106/2017','VIJAYALAKSHMI'),(2758,46,'2022-11-04 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,989083,0,0,56,0,989027,0,0,'106/2017','VIJAYALAKSHMI'),(2759,47,'2022-07-22 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1689,0,0,7,0,1682,0,0,'118/2022','FIROZ'),(2760,82,'2022-07-22 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,994007,0,0,14,3000,993993,0,0,'118/2022','FIROZ'),(2761,82,'2022-07-29 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,993993,0,0,63,3000,993930,0,0,'118/2022','FIROZ'),(2762,50,'2022-07-29 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2233,0,0,42,0,2191,0,0,'118/2022','FIROZ'),(2763,82,'2022-08-12 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,993930,0,0,7,3000,993923,0,0,'118/2022','FIROZ'),(2764,83,'2022-08-12 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,994973,0,0,7,0,994966,0,0,'118/2022','FIROZ'),(2765,47,'2022-08-12 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1682,0,0,7,0,1675,0,0,'118/2022','FIROZ'),(2766,82,'2022-08-19 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,993923,0,0,21,3000,993902,0,0,'118/2022','FIROZ'),(2767,83,'2022-08-19 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,994966,0,0,21,0,994945,0,0,'118/2022','FIROZ'),(2768,47,'2022-08-19 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1675,0,0,21,0,1654,0,0,'118/2022','FIROZ'),(2769,82,'2022-09-02 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,993902,0,0,35,3000,993867,0,0,'118/2022','FIROZ'),(2770,83,'2022-09-02 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,994945,0,0,35,0,994910,0,0,'118/2022','FIROZ'),(2771,47,'2022-09-02 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1654,0,0,35,0,1619,0,0,'118/2022','FIROZ'),(2772,82,'2022-11-04 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,993867,0,0,35,3000,993832,0,0,'118/2022','FIROZ'),(2773,83,'2022-11-04 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,994910,0,0,35,0,994875,0,0,'118/2022','FIROZ'),(2774,47,'2022-11-04 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1619,0,0,35,0,1584,0,0,'118/2022','FIROZ'),(2775,69,'2022-11-04 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1262,0,0,42,0,1220,0,0,'02/2022','GIRIJA'),(2776,12,'2022-11-04 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2447,0,0,42,0,2405,0,0,'02/2022','GIRIJA'),(2777,19,'2022-11-04 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,2828,0,0,42,0,2786,0,0,'080/2020','SAJNA'),(2778,45,'2022-11-04 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,2503,0,0,14,0,2489,0,0,'080/2020','SAJNA'),(2779,83,'2022-11-04 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,994875,0,0,56,0,994819,0,0,'133/2022','SEMI'),(2780,36,'2022-11-04 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1684,0,0,28,0,1656,0,0,'133/2022','SEMI'),(2781,70,'2022-11-04 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18607,0,0,28,0,18579,0,0,'133/2022','SEMI'),(2782,58,'2022-05-20 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Transfer','Sub to OP',0,3000,0,0,140,0,2860,0,0,'89/2018','MUHAMMAD'),(2783,71,'2022-05-20 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9082,0,0,70,0,9012,0,0,'89/2018','MUHAMMAD'),(2784,24,'2022-05-20 00:00:00','M24','GABAPENTIN TABLETS 100MG','Transfer','Sub to OP',0,3000,0,0,70,0,2930,0,0,'89/2018','MUHAMMAD'),(2785,58,'2022-07-29 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Transfer','Sub to OP',0,2860,0,0,168,0,2692,0,0,'89/2018','MUHAMMAD'),(2786,70,'2022-07-29 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18579,0,0,84,0,18495,0,0,'89/2018','MUHAMMAD'),(2787,24,'2022-07-29 00:00:00','M24','GABAPENTIN TABLETS 100MG','Transfer','Sub to OP',0,2930,0,0,84,0,2846,0,0,'89/2018','MUHAMMAD'),(2788,70,'2022-11-04 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18495,0,0,42,0,18453,0,0,'89/2018','MUHAMMAD'),(2789,58,'2022-11-04 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Transfer','Sub to OP',0,2692,0,0,84,0,2608,0,0,'89/2018','MUHAMMAD'),(2790,24,'2022-11-04 00:00:00','M24','GABAPENTIN TABLETS 100MG','Transfer','Sub to OP',0,2846,0,0,42,0,2804,0,0,'89/2018','MUHAMMAD'),(2791,33,'2022-11-04 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1807,0,0,7,0,1800,0,0,'237/2022','RAHMATHUNNEESA'),(2792,22,'2022-11-04 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2545,0,0,28,0,2517,0,0,'201/2022','PRAMOD'),(2793,35,'2022-11-04 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2313,0,0,28,0,2285,0,0,'201/2022','PRAMOD'),(2794,46,'2022-11-04 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,989027,0,0,28,0,988999,0,0,'201/2022','PRAMOD'),(2795,29,'2022-11-04 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,2440,0,0,63,0,2377,0,0,'92/2022','MOHAMMED '),(2796,25,'2022-11-04 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,2419,0,0,21,0,2398,0,0,'92/2022','MOHAMMED '),(2797,46,'2022-11-04 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,988999,0,0,42,0,988957,0,0,'92/2022','MOHAMMED '),(2798,45,'2022-11-04 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,2489,0,0,56,0,2433,0,0,'211/2019','RAJAN'),(2799,87,'2022-11-04 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Transfer','Sub to OP',0,2695,0,0,32,0,2663,0,0,'211/2019','RAJAN'),(2800,81,'2022-11-04 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,998804,0,0,56,0,998748,0,0,'211/2019','RAJAN'),(2801,33,'2022-11-04 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1800,0,0,28,0,1772,0,0,'211/2019','RAJAN'),(2802,76,'2022-11-04 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,1922,0,0,56,0,1866,0,0,'211/2019','RAJAN'),(2803,6,'2022-11-04 00:00:00','M6','ESCITALOPRAM TABLETS 20MG','Transfer','Sub to OP',0,3000,0,0,14,0,2986,0,0,'04/2022','BIJU'),(2804,65,'2022-11-04 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,2769,0,0,14,0,2755,0,0,'04/2022','BIJU'),(2805,47,'2022-11-04 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1584,0,0,14,0,1570,0,0,'04/2022','BIJU'),(2806,58,'2022-08-12 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Transfer','Sub to OP',0,2608,0,0,168,0,2440,0,0,'206/2021','FARHANA SHIRIL'),(2807,34,'2022-08-12 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,995,0,0,84,0,911,0,0,'206/2021','FARHANA SHIRIL'),(2808,58,'2022-11-04 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Transfer','Sub to OP',0,2440,0,0,112,0,2328,0,0,'206/2021','FARHANA SHIRIL'),(2809,33,'2022-11-04 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1772,0,0,56,0,1716,0,0,'206/2021','FARHANA SHIRIL'),(2810,83,'2022-11-04 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,994819,0,0,56,0,994763,0,0,'16/2021','SAFIYA'),(2811,68,'2022-11-04 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1796,0,0,28,0,1768,0,0,'16/2021','SAFIYA'),(2812,46,'2022-11-04 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,988957,0,0,28,0,988929,0,0,'16/2021','SAFIYA'),(2813,92,'2022-11-04 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2972,0,0,2,0,2970,0,0,'170/2022','HAMZA'),(2814,71,'2022-11-11 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,9012,0,0,84,0,8928,0,0,'49/2017','RUKKIYA'),(2815,70,'2022-11-11 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18453,0,0,84,0,18369,0,0,'49/2017','RUKKIYA'),(2816,70,'2022-08-19 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18369,0,0,84,0,18285,0,0,'49/2017','RUKKIYA'),(2817,71,'2022-08-19 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,8928,0,0,84,0,8844,0,0,'49/2017','RUKKIYA'),(2818,83,'2022-11-11 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,994763,0,0,28,0,994735,0,0,'204/2022','ANSIF'),(2819,82,'2022-11-11 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,993832,0,0,14,3000,993818,0,0,'204/2022','ANSIF'),(2820,69,'2022-11-11 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1220,0,0,14,0,1206,0,0,'204/2022','ANSIF'),(2821,36,'2022-11-11 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1656,0,0,14,0,1642,0,0,'204/2022','ANSIF'),(2822,33,'2022-11-11 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1716,0,0,14,0,1702,0,0,'204/2022','ANSIF'),(2823,28,'2022-11-11 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,1752,0,0,21,0,1731,0,0,'204/2022','ANSIF'),(2824,46,'2022-11-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,988929,0,0,28,0,988901,0,0,'204/2022','ANSIF'),(2825,85,'2022-11-11 00:00:00','M85','LEVETIRACETAM TABLETS 250 MG','Transfer','Sub to OP',0,2986,0,0,112,0,2874,0,0,'8/2014','DHANISHMA'),(2826,83,'2022-11-11 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,994735,0,0,112,0,994623,0,0,'155/2022','SAINUDHEEN'),(2827,34,'2022-11-11 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,911,0,0,56,0,855,0,0,'155/2022','SAINUDHEEN'),(2828,50,'2022-11-11 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2191,0,0,56,0,2135,0,0,'158/2020','SUBRAHMANYAN'),(2829,48,'2022-11-11 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1229,0,0,56,0,1173,0,0,'158/2020','SUBRAHMANYAN'),(2830,83,'2022-11-11 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,994623,0,0,112,0,994511,0,0,'158/2020','SUBRAHMANYAN'),(2831,82,'2022-11-11 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,993818,0,0,56,3000,993762,0,0,'158/2020','SUBRAHMANYAN'),(2832,36,'2022-09-16 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1642,0,0,56,0,1586,0,0,'158/2020','SUBRAHMANYAN'),(2833,50,'2022-09-16 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2135,0,0,56,0,2079,0,0,'158/2020','SUBRAHMANYAN'),(2834,48,'2022-09-16 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1173,0,0,56,0,1117,0,0,'158/2020','SUBRAHMANYAN'),(2835,83,'2022-09-16 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,994511,0,0,112,0,994399,0,0,'158/2020','SUBRAHMANYAN'),(2836,82,'2022-09-16 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,993762,0,0,56,3000,993706,0,0,'158/2020','SUBRAHMANYAN'),(2837,39,'2022-09-16 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Transfer','Sub to OP',0,2839,0,0,168,0,2671,0,0,'158/2020','SUBRAHMANYAN'),(2838,38,'2022-09-16 00:00:00','M38','SERTRALINE HCL TABLETS 100MG','Transfer','Sub to OP',0,2820,0,0,112,0,2708,0,0,'112/2018','FOUSIYA'),(2839,19,'2022-09-16 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,2786,0,0,28,0,2758,0,0,'112/2018','FOUSIYA'),(2840,38,'2022-11-11 00:00:00','M38','SERTRALINE HCL TABLETS 100MG','Transfer','Sub to OP',0,2708,0,0,168,0,2540,0,0,'112/2018','FOUSIYA'),(2841,19,'2022-11-11 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,2758,0,0,42,0,2716,0,0,'112/2018','FOUSIYA'),(2842,38,'2022-09-16 00:00:00','M38','SERTRALINE HCL TABLETS 100MG','Transfer','Sub to OP',0,2540,0,0,112,0,2428,0,0,'07/2017','FATHIMMA'),(2843,19,'2022-09-16 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,2716,0,0,56,0,2660,0,0,'07/2017','FATHIMMA'),(2844,39,'2022-11-11 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Transfer','Sub to OP',0,2671,0,0,168,0,2503,0,0,'07/2017','FATHIMMA'),(2845,19,'2022-11-11 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,2660,0,0,84,0,2576,0,0,'07/2017','FATHIMMA'),(2846,36,'2022-11-11 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1586,0,0,42,0,1544,0,0,'138/2019','UMMAR'),(2847,49,'2022-11-11 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1532,0,0,42,0,1490,0,0,'138/2019','UMMAR'),(2848,34,'2022-11-11 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,855,0,0,84,0,771,0,0,'138/2019','UMMAR'),(2849,46,'2022-11-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,988901,0,0,84,0,988817,0,0,'138/2019','UMMAR'),(2850,49,'2022-11-11 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1490,0,0,42,0,1448,0,0,'48/2017','ABDUL HASEEB'),(2851,48,'2022-11-11 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1117,0,0,42,0,1075,0,0,'48/2017','ABDUL HASEEB'),(2852,35,'2022-11-11 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2285,0,0,42,0,2243,0,0,'48/2017','ABDUL HASEEB'),(2853,46,'2022-11-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,988817,0,0,126,0,988691,0,0,'48/2017','ABDUL HASEEB'),(2854,83,'2022-11-11 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,994399,0,0,112,0,994287,0,0,'250/2021','HASEENA '),(2855,22,'2022-11-11 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2517,0,0,56,0,2461,0,0,'250/2021','HASEENA '),(2856,68,'2022-11-11 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1768,0,0,56,0,1712,0,0,'250/2021','HASEENA '),(2857,83,'2022-09-30 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,994287,0,0,84,0,994203,0,0,'250/2021','HASEENA '),(2858,12,'2022-09-30 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2405,0,0,42,0,2363,0,0,'250/2021','HASEENA '),(2859,68,'2022-09-30 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1712,0,0,42,0,1670,0,0,'250/2021','HASEENA '),(2860,29,'2022-11-11 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,2377,0,0,168,0,2209,0,0,'92/2022','MOHAMMED '),(2861,25,'2022-11-11 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,2398,0,0,56,0,2342,0,0,'92/2022','MOHAMMED '),(2862,46,'2022-11-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,988691,0,0,112,0,988579,0,0,'92/2022','MOHAMMED '),(2863,11,'2022-11-11 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,2987,0,0,2,0,2985,0,0,'36/2020','UMMUHABEEBA'),(2864,49,'2022-11-11 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1448,0,0,28,0,1420,0,0,'36/2020','UMMUHABEEBA'),(2865,47,'2022-11-11 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1570,0,0,28,0,1542,0,0,'36/2020','UMMUHABEEBA'),(2866,46,'2022-11-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,988579,0,0,56,0,988523,0,0,'36/2020','UMMUHABEEBA'),(2867,82,'2022-11-11 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,993706,0,0,168,3000,993538,0,0,'288/2021','SABIRA'),(2868,46,'2022-11-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,988523,0,0,168,0,988355,0,0,'288/2021','SABIRA'),(2869,34,'2022-11-11 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,771,0,0,56,0,715,0,0,'288/2021','SABIRA'),(2870,19,'2022-11-11 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,2576,0,0,112,0,2464,0,0,'288/2021','SABIRA'),(2871,79,'2022-11-11 00:00:00','M79','PHENOBARBITONE TABLETS 60MG','Transfer','Sub to OP',0,3000,0,0,56,0,2944,0,0,'190/2022','NOUSHAD '),(2872,35,'2022-11-11 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2243,0,0,28,0,2215,0,0,'190/2022','NOUSHAD '),(2873,46,'2022-11-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,988355,0,0,28,0,988327,0,0,'190/2022','NOUSHAD '),(2874,89,'2022-11-11 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,2883,0,0,28,0,2855,0,0,'190/2022','NOUSHAD '),(2875,79,'2022-09-16 00:00:00','M79','PHENOBARBITONE TABLETS 60MG','Transfer','Sub to OP',0,2944,0,0,28,0,2916,0,0,'190/2022','NOUSHAD '),(2876,35,'2022-09-16 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2215,0,0,14,0,2201,0,0,'190/2022','NOUSHAD '),(2877,46,'2022-09-16 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,988327,0,0,14,0,988313,0,0,'190/2022','NOUSHAD '),(2878,89,'2022-09-16 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,2855,0,0,14,0,2841,0,0,'190/2022','NOUSHAD '),(2879,34,'2022-11-11 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,715,0,0,21,0,694,0,0,'237/2022','RAHMATHUNNEESA'),(2880,46,'2022-11-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,988313,0,0,21,0,988292,0,0,'237/2022','RAHMATHUNNEESA'),(2881,83,'2022-11-11 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,994203,0,0,56,0,994147,0,0,'247/2021','NOUSHAD '),(2882,82,'2022-11-11 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,993538,0,0,28,3000,993510,0,0,'247/2021','NOUSHAD '),(2883,36,'2022-11-11 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1544,0,0,28,0,1516,0,0,'247/2021','NOUSHAD '),(2884,33,'2022-11-11 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1702,0,0,28,0,1674,0,0,'247/2021','NOUSHAD '),(2885,46,'2022-11-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,988292,0,0,84,0,988208,0,0,'247/2021','NOUSHAD '),(2886,71,'2022-11-11 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,8844,0,0,28,0,8816,0,0,'247/2021','NOUSHAD '),(2887,87,'2022-11-11 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Transfer','Sub to OP',0,2663,0,0,42,0,2621,0,0,'247/2021','NOUSHAD '),(2888,3,'2022-11-11 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2906,0,0,28,0,2878,0,0,'247/2021','NOUSHAD '),(2889,82,'2022-11-11 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,993510,0,0,84,3000,993426,0,0,'135/2022','ASHRAF'),(2890,83,'2022-11-11 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,994147,0,0,84,0,994063,0,0,'135/2022','ASHRAF'),(2891,68,'2022-11-11 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1670,0,0,126,0,1544,0,0,'135/2022','ASHRAF'),(2892,34,'2022-11-11 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,694,0,0,84,0,610,0,0,'135/2022','ASHRAF'),(2893,36,'2022-11-11 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1516,0,0,84,0,1432,0,0,'135/2022','ASHRAF'),(2894,46,'2022-11-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,988208,0,0,252,0,987956,0,0,'135/2022','ASHRAF'),(2895,48,'2022-11-11 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,1075,0,0,84,0,991,0,0,'135/2022','ASHRAF'),(2896,70,'2022-11-11 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18285,0,0,84,0,18201,0,0,'135/2022','ASHRAF'),(2897,71,'2022-08-12 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,8816,0,0,21,0,8795,0,0,'263/2021','FATHIMMA PP'),(2898,3,'2022-08-12 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2878,0,0,14,0,2864,0,0,'263/2021','FATHIMMA PP'),(2899,71,'2022-11-11 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,8795,0,0,56,0,8739,0,0,'263/2021','FATHIMMA PP'),(2900,3,'2022-11-11 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2864,0,0,14,0,2850,0,0,'263/2021','FATHIMMA PP'),(2901,36,'2022-11-11 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1432,0,0,58,0,1374,0,0,'130/2022','AHAMMED KUTTY'),(2902,70,'2022-11-11 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18201,0,0,56,0,18145,0,0,'130/2022','AHAMMED KUTTY'),(2903,46,'2022-11-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,987956,0,0,56,0,987900,0,0,'130/2022','AHAMMED KUTTY'),(2904,82,'2022-11-11 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,993426,0,0,28,3000,993398,0,0,'90/2017','RANEESH'),(2905,83,'2022-11-11 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,994063,0,0,56,0,994007,0,0,'90/2017','RANEESH'),(2906,46,'2022-11-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,987900,0,0,168,0,987732,0,0,'90/2017','RANEESH'),(2907,76,'2022-11-11 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,1866,0,0,56,0,1810,0,0,'90/2017','RANEESH'),(2908,73,'2022-11-11 00:00:00','M73','QUETIAPINE TABLETS 200MG','Transfer','Sub to OP',0,2979,0,0,56,0,2923,0,0,'90/2017','RANEESH'),(2909,72,'2022-11-11 00:00:00','M72','QUETIAPINE TABLETS 100MG','Transfer','Sub to OP',0,2741,0,0,56,0,2685,0,0,'90/2017','RANEESH'),(2910,49,'2022-11-11 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1420,0,0,56,0,1364,0,0,'90/2017','RANEESH'),(2911,48,'2022-11-11 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,991,0,0,56,0,935,0,0,'90/2017','RANEESH'),(2912,4,'2022-11-11 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,2755,0,0,14,0,2741,0,0,'243/2022','KUNJIPATHUMA'),(2913,4,'2022-11-11 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,2741,0,0,14,0,2727,0,0,'242/2022','HARIDASAN'),(2914,36,'2022-11-11 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1374,0,0,112,0,1262,0,0,'205/2022','ABDUL RASAK'),(2915,29,'2022-11-11 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,2209,0,0,168,0,2041,0,0,'205/2022','ABDUL RASAK'),(2916,46,'2022-11-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,987732,0,0,112,0,987620,0,0,'205/2022','ABDUL RASAK'),(2917,20,'2022-11-11 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,2608,0,0,56,0,2552,0,0,'205/2022','ABDUL RASAK'),(2918,22,'2022-11-11 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2461,0,0,56,0,2405,0,0,'205/2022','ABDUL RASAK'),(2919,56,'2022-11-11 00:00:00','M56','CLOMIPRAMINE TABLETS 25MG','Transfer','Sub to OP',0,2916,0,0,112,0,2804,0,0,'205/2022','ABDUL RASAK'),(2920,5,'2022-11-11 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2447,0,0,56,0,2391,0,0,'202/2021','SHAJI'),(2921,34,'2022-11-04 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,610,0,0,21,0,589,0,0,'238/2022','RAJESH'),(2922,34,'2022-11-11 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,589,0,0,7,0,582,0,0,'238/2022','RAJESH'),(2923,83,'2022-11-11 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,994007,0,0,28,0,993979,0,0,'203/2022','RASIYA BANU'),(2924,50,'2022-11-11 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2079,0,0,70,0,2009,0,0,'65/2021','MUHAMMAD ISMAIL PM'),(2925,49,'2022-11-11 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1364,0,0,70,0,1294,0,0,'65/2021','MUHAMMAD ISMAIL PM'),(2926,35,'2022-11-11 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2201,0,0,70,0,2131,0,0,'65/2021','MUHAMMAD ISMAIL PM'),(2927,46,'2022-11-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,987620,0,0,70,0,987550,0,0,'65/2021','MUHAMMAD ISMAIL PM'),(2928,34,'2022-11-11 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,582,0,0,56,0,526,0,0,'202/2022','BINDU'),(2929,46,'2022-11-11 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,987550,0,0,112,0,987438,0,0,'202/2022','BINDU'),(2930,68,'2022-11-18 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1544,0,0,7,0,1537,0,0,'203/2022','RASIYA BANU'),(2931,69,'2022-11-18 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1206,0,0,7,0,1199,0,0,'203/2022','RASIYA BANU'),(2932,22,'2022-11-18 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2405,0,0,7,0,2398,0,0,'203/2022','RASIYA BANU'),(2933,3,'2022-11-18 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2850,0,0,7,0,2843,0,0,'203/2022','RASIYA BANU'),(2934,48,'2022-11-18 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,935,0,0,7,0,928,0,0,'28/2020','ASSAINAR'),(2935,47,'2022-11-18 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1542,0,0,7,0,1535,0,0,'28/2020','ASSAINAR'),(2936,34,'2022-11-18 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,526,0,0,7,0,519,0,0,'28/2020','ASSAINAR'),(2937,81,'2022-11-18 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,998748,0,0,42,0,998706,0,0,'90/2022','MOHAMMED RUFAID '),(2938,86,'2022-11-18 00:00:00','M86','CLOBAZAM TABLETS 10 MG','Transfer','Sub to OP',0,2622,0,0,84,0,2538,0,0,'90/2022','MOHAMMED RUFAID '),(2939,33,'2022-11-18 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1674,0,0,42,0,1632,0,0,'90/2022','MOHAMMED RUFAID '),(2940,82,'2022-11-18 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,993398,0,0,126,3000,993272,0,0,'0130/2017','SHANDHA'),(2941,43,'2022-11-18 00:00:00','M43','VENLAFAXINE EXTENDED RELEASE CAPSULES 75MG','Transfer','Sub to OP',0,2750,0,0,84,0,2666,0,0,'0130/2017','SHANDHA'),(2942,65,'2022-11-18 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,2755,0,0,42,0,2713,0,0,'0130/2017','SHANDHA'),(2943,50,'2022-11-18 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,2009,0,0,84,0,1925,0,0,'9/2018','RAFEENA'),(2944,49,'2022-11-18 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1294,0,0,84,0,1210,0,0,'9/2018','RAFEENA'),(2945,46,'2022-11-18 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,987438,0,0,168,0,987270,0,0,'9/2018','RAFEENA'),(2946,34,'2022-11-18 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,519,0,0,84,0,435,0,0,'9/2018','RAFEENA'),(2947,35,'2022-11-18 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2131,0,0,84,0,2047,0,0,'9/2018','RAFEENA'),(2948,65,'2022-11-18 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,2713,0,0,42,0,2671,0,0,'04/2022','BIJU'),(2949,3,'2022-11-18 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2843,0,0,42,0,2801,0,0,'04/2022','BIJU'),(2950,6,'2022-11-18 00:00:00','M6','ESCITALOPRAM TABLETS 20MG','Transfer','Sub to OP',0,2986,0,0,42,0,2944,0,0,'04/2022','BIJU'),(2951,48,'2022-11-25 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',0,928,0,0,21,0,907,0,0,'28/2020','ASSAINAR'),(2952,47,'2022-11-25 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1535,0,0,21,0,1514,0,0,'28/2020','ASSAINAR'),(2953,34,'2022-11-25 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,435,0,0,21,0,414,0,0,'28/2020','ASSAINAR'),(2954,82,'2022-11-25 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,993272,0,0,112,3000,993160,0,0,'232/2021','USMAN'),(2955,83,'2022-11-25 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,993979,0,0,56,0,993923,0,0,'232/2021','USMAN'),(2956,36,'2022-11-25 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1262,0,0,56,0,1206,0,0,'232/2021','USMAN'),(2957,46,'2022-11-25 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,987270,0,0,168,0,987102,0,0,'232/2021','USMAN'),(2958,49,'2022-11-25 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1210,0,0,56,0,1154,0,0,'232/2021','USMAN'),(2959,20,'2022-11-25 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,2552,0,0,70,0,2482,0,0,'59/2021','KUNJUMUHAMMAD'),(2960,65,'2022-11-25 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,2671,0,0,105,0,2566,0,0,'59/2021','KUNJUMUHAMMAD'),(2961,19,'2022-11-25 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,2464,0,0,35,0,2429,0,0,'59/2021','KUNJUMUHAMMAD'),(2962,4,'2022-11-25 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,2727,0,0,21,0,2706,0,0,'243/2022','KUNJIPATHUMA'),(2963,29,'2022-11-25 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,2041,0,0,168,0,1873,0,0,'92/2022','MOHAMMED '),(2964,25,'2022-11-25 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,2342,0,0,56,0,2286,0,0,'92/2022','MOHAMMED '),(2965,46,'2022-11-25 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,987102,0,0,112,0,986990,0,0,'92/2022','MOHAMMED '),(2966,33,'2022-11-25 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1632,0,0,14,0,1618,0,0,'249/2022','FARSANA VP'),(2967,12,'2022-11-25 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2363,0,0,28,0,2335,0,0,'201/2022','PRAMOD'),(2968,36,'2022-11-25 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1206,0,0,28,0,1178,0,0,'201/2022','PRAMOD'),(2969,46,'2022-11-25 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,986990,0,0,28,0,986962,0,0,'201/2022','PRAMOD'),(2970,49,'2022-11-25 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1154,0,0,70,0,1084,0,0,'137/2022','SREEDEVI'),(2971,35,'2022-11-25 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,2047,0,0,84,0,1963,0,0,'196/2021','MUHAMMAD KUTTI'),(2972,46,'2022-11-25 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,986962,0,0,84,0,986878,0,0,'196/2021','MUHAMMAD KUTTI'),(2973,9,'2022-11-25 00:00:00','M9','AMISULPRIDE TABLETS 100MG','Transfer','Sub to OP',0,2198,0,0,84,0,2114,0,0,'63/2018','BABY'),(2974,8,'2022-11-25 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Transfer','Sub to OP',0,2800,0,0,84,0,2716,0,0,'63/2018','BABY'),(2975,46,'2022-11-25 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,986878,0,0,84,0,986794,0,0,'63/2018','BABY'),(2976,82,'2022-11-25 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,993160,0,0,35,3000,993125,0,0,'059/2021','YASHODHA'),(2977,83,'2022-11-25 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,993923,0,0,35,0,993888,0,0,'059/2021','YASHODHA'),(2978,71,'2022-11-25 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,8739,0,0,35,0,8704,0,0,'059/2021','YASHODHA'),(2979,28,'2022-09-30 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,1731,0,0,126,0,1605,0,0,'136/2022','ABDU SAMAD '),(2980,35,'2022-09-30 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,1963,0,0,84,0,1879,0,0,'136/2022','ABDU SAMAD '),(2981,46,'2022-09-30 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,986794,0,0,84,0,986710,0,0,'136/2022','ABDU SAMAD '),(2982,28,'2022-11-25 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,1605,0,0,84,0,1521,0,0,'136/2022','ABDU SAMAD '),(2983,35,'2022-11-25 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,1879,0,0,168,0,1711,0,0,'136/2022','ABDU SAMAD '),(2984,46,'2022-11-25 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,986710,0,0,84,0,986626,0,0,'136/2022','ABDU SAMAD '),(2985,92,'2022-11-25 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2970,0,0,1,0,2969,0,0,'77/2017','SUHARA'),(2986,93,'2022-11-25 00:00:00','M93','FLUPHENAZINE DECANOATE INJECTION IP 1ML','Transfer','Sub to OP',0,3000,0,0,2,0,2998,0,0,'77/2017','SUHARA'),(2987,5,'2022-11-25 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2391,0,0,28,0,2363,0,0,'242/2022','HARIDASAN'),(2988,83,'2022-11-25 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,993888,0,0,56,0,993832,0,0,'203/2022','RASIYA BANU'),(2989,68,'2022-11-25 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1537,0,0,28,0,1509,0,0,'203/2022','RASIYA BANU'),(2990,12,'2022-11-25 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2335,0,0,28,0,2307,0,0,'203/2022','RASIYA BANU'),(2991,23,'2022-11-25 00:00:00','M23','FLUOXETINE CAPSULES 10MG','Transfer','Sub to OP',0,2972,0,0,28,0,2944,0,0,'203/2022','RASIYA BANU'),(2992,3,'2022-11-25 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2801,0,0,14,0,2787,0,0,'203/2022','RASIYA BANU'),(2993,83,'2022-11-25 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,993832,0,0,56,0,993776,0,0,'204/2022','ANSIF'),(2994,82,'2022-11-25 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,993125,0,0,28,3000,993097,0,0,'204/2022','ANSIF'),(2995,35,'2022-11-25 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,1711,0,0,28,0,1683,0,0,'204/2022','ANSIF'),(2996,28,'2022-11-25 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,1521,0,0,42,0,1479,0,0,'204/2022','ANSIF'),(2997,46,'2022-11-25 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,986626,0,0,84,0,986542,0,0,'204/2022','ANSIF'),(2998,11,'2022-12-02 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,2985,0,0,4,0,2981,0,0,'52/2022','ISMAIL'),(2999,92,'2022-12-02 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2969,0,0,2,0,2967,0,0,'52/2022','ISMAIL'),(3000,82,'2022-12-02 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,993097,0,0,112,3000,992985,0,0,'287/2021','AYISHA'),(3001,83,'2022-12-02 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,993776,0,0,112,0,993664,0,0,'287/2021','AYISHA'),(3002,34,'2022-12-02 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,414,0,0,336,0,78,0,0,'287/2021','AYISHA'),(3003,46,'2022-12-02 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,986542,0,0,224,0,986318,0,0,'287/2021','AYISHA'),(3004,65,'2022-12-02 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,2566,0,0,42,0,2524,0,0,'249/2021','SUDHAKARAN'),(3005,71,'2022-12-02 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,8704,0,0,42,0,8662,0,0,'249/2021','SUDHAKARAN'),(3006,89,'2022-12-02 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,2841,0,0,42,0,2799,0,0,'249/2021','SUDHAKARAN'),(3007,34,'2022-12-02 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',0,78,0,0,28,0,50,0,0,'237/2022','RAHMATHUNNEESA'),(3008,46,'2022-12-02 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,986318,0,0,28,0,986290,0,0,'237/2022','RAHMATHUNNEESA'),(3009,82,'2022-12-02 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,992985,0,0,252,3000,992733,0,0,'34/2018','SAKHEER'),(3010,35,'2022-12-02 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,1683,0,0,84,0,1599,0,0,'34/2018','SAKHEER'),(3011,33,'2022-12-02 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1618,0,0,168,0,1450,0,0,'34/2018','SAKHEER'),(3012,46,'2022-12-02 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,986290,0,0,84,0,986206,0,0,'34/2018','SAKHEER'),(3013,34,'2022-12-06 00:00:00','M34','RISPERIDONE TABLETS 2MG','Inbound','To main stock',0,50,0,0,1000,1000,50,0,0,'',''),(3014,48,'2022-12-06 00:00:00','M48','CLOZAPINE TABLETS 50MG','Inbound','To main stock',0,907,0,0,5000,5000,907,0,0,'',''),(3015,19,'2022-12-02 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,2429,0,0,126,0,2303,0,0,'080/2020','SAJNA'),(3016,45,'2022-12-02 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,2433,0,0,42,0,2391,0,0,'080/2020','SAJNA'),(3017,5,'2022-12-02 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2363,0,0,56,0,2307,0,0,'168/2021','FATHIMAKUTTY'),(3018,56,'2022-12-02 00:00:00','M56','CLOMIPRAMINE TABLETS 25MG','Transfer','Sub to OP',0,2804,0,0,20,0,2784,0,0,'168/2021','FATHIMAKUTTY'),(3019,83,'2022-12-02 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,993664,0,0,168,0,993496,0,0,'137/2017','MUJEEBRAHMAN'),(3020,26,'2022-12-02 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,2496,0,0,126,0,2370,0,0,'137/2017','MUJEEBRAHMAN'),(3021,76,'2022-12-02 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,1810,0,0,84,0,1726,0,0,'137/2017','MUJEEBRAHMAN'),(3022,46,'2022-12-02 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,986206,0,0,252,0,985954,0,0,'137/2017','MUJEEBRAHMAN'),(3023,33,'2022-12-02 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1450,0,0,84,0,1366,0,0,'115/2022','HUSSAN'),(3024,83,'2022-12-02 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,993496,0,0,168,0,993328,0,0,'15/2021','KADHEEJA'),(3025,82,'2022-12-02 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,992733,0,0,84,3000,992649,0,0,'15/2021','KADHEEJA'),(3026,22,'2022-12-02 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2398,0,0,84,0,2314,0,0,'15/2021','KADHEEJA'),(3027,67,'2022-12-02 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2116,0,0,84,0,2032,0,0,'15/2021','KADHEEJA'),(3028,82,'2022-12-02 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,992649,0,0,28,3000,992621,0,0,'54/2017','PUSHPAVATHI'),(3029,83,'2022-12-02 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,993328,0,0,28,0,993300,0,0,'54/2017','PUSHPAVATHI'),(3030,68,'2022-12-02 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1509,0,0,28,0,1481,0,0,'54/2017','PUSHPAVATHI'),(3031,46,'2022-12-02 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,985954,0,0,28,0,985926,0,0,'54/2017','PUSHPAVATHI'),(3032,8,'2022-12-02 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Transfer','Sub to OP',0,2716,0,0,28,0,2688,0,0,'54/2017','PUSHPAVATHI'),(3033,83,'2022-12-02 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,993300,0,0,168,0,993132,0,0,'16/2021','SAFIYA'),(3034,68,'2022-12-02 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1481,0,0,84,0,1397,0,0,'16/2021','SAFIYA'),(3035,46,'2022-12-02 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,985926,0,0,84,0,985842,0,0,'16/2021','SAFIYA'),(3036,83,'2022-12-02 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,993132,0,0,63,0,993069,0,0,'90/2017','RANEESH'),(3037,46,'2022-12-02 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,985842,0,0,84,0,985758,0,0,'90/2017','RANEESH'),(3038,49,'2022-12-02 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1084,0,0,21,0,1063,0,0,'90/2017','RANEESH'),(3039,47,'2022-12-02 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1514,0,0,21,0,1493,0,0,'90/2017','RANEESH'),(3040,76,'2022-12-02 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,1726,0,0,21,0,1705,0,0,'90/2017','RANEESH'),(3041,70,'2022-12-02 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18145,0,0,21,0,18124,0,0,'90/2017','RANEESH'),(3042,33,'2022-12-02 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1366,0,0,7,0,1359,0,0,'045/2020','KOYAMU'),(3043,33,'2022-12-09 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1359,0,0,21,0,1338,0,0,'045/2020','KOYAMU'),(3044,83,'2022-12-09 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,993069,0,0,84,0,992985,0,0,'93/2017','SOORAJ'),(3045,50,'2022-12-09 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,1925,0,0,42,0,1883,0,0,'93/2017','SOORAJ'),(3046,48,'2022-12-09 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',5000,907,0,0,84,5000,823,0,0,'93/2017','SOORAJ'),(3047,46,'2022-12-09 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,985758,0,0,126,0,985632,0,0,'93/2017','SOORAJ'),(3048,70,'2022-12-09 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18124,0,0,42,0,18082,0,0,'93/2017','SOORAJ'),(3049,82,'2022-12-09 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,992621,0,0,56,3000,992565,0,0,'134/2022','SABITHA '),(3050,83,'2022-12-09 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,992985,0,0,56,0,992929,0,0,'134/2022','SABITHA '),(3051,69,'2022-12-09 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1199,0,0,56,0,1143,0,0,'134/2022','SABITHA '),(3052,82,'2022-12-09 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,992565,0,0,56,3000,992509,0,0,'92/2018','CHEKUTTI'),(3053,83,'2022-12-09 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,992929,0,0,56,0,992873,0,0,'92/2018','CHEKUTTI'),(3054,68,'2022-12-09 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1397,0,0,56,0,1341,0,0,'92/2018','CHEKUTTI'),(3055,37,'2022-12-09 00:00:00','M37','TRIFLUOPERAZINE HCL & TRIHEXYPHENIDYL HCL TABLETS ','Transfer','Sub to OP',0,1000000,0,0,112,0,999888,0,0,'92/2018','CHEKUTTI'),(3056,45,'2022-12-09 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,2391,0,0,84,0,2307,0,0,'211/2019','RAJAN'),(3057,87,'2022-12-09 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Transfer','Sub to OP',0,2621,0,0,84,0,2537,0,0,'211/2019','RAJAN'),(3058,82,'2022-12-09 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,992509,0,0,56,3000,992453,0,0,'211/2019','RAJAN'),(3059,81,'2022-12-09 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,998706,0,0,56,0,998650,0,0,'211/2019','RAJAN'),(3060,46,'2022-12-09 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,985632,0,0,112,0,985520,0,0,'211/2019','RAJAN'),(3061,5,'2022-12-09 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2307,0,0,56,0,2251,0,0,'211/2019','RAJAN'),(3062,76,'2022-12-09 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,1705,0,0,112,0,1593,0,0,'211/2019','RAJAN'),(3063,69,'2022-12-09 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1143,0,0,56,0,1087,0,0,'211/2019','RAJAN'),(3064,11,'2022-12-09 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,2981,0,0,1,0,2980,0,0,'231/2021','MUHAMMAD IQBAL'),(3065,49,'2022-12-09 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1063,0,0,56,0,1007,0,0,'231/2021','MUHAMMAD IQBAL'),(3066,48,'2022-12-09 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',5000,823,0,0,56,5000,767,0,0,'231/2021','MUHAMMAD IQBAL'),(3067,92,'2022-12-09 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2967,0,0,1,0,2966,0,0,'231/2021','MUHAMMAD IQBAL'),(3068,46,'2022-12-09 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,985520,0,0,56,0,985464,0,0,'231/2021','MUHAMMAD IQBAL'),(3069,93,'2022-12-09 00:00:00','M93','FLUPHENAZINE DECANOATE INJECTION IP 1ML','Transfer','Sub to OP',0,2998,0,0,4,0,2994,0,0,'231/2021','MUHAMMAD IQBAL'),(3070,11,'2022-12-09 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,2980,0,0,2,0,2978,0,0,'36/2020','UMMUHABEEBA'),(3071,49,'2022-12-09 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,1007,0,0,42,0,965,0,0,'36/2020','UMMUHABEEBA'),(3072,46,'2022-12-09 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,985464,0,0,84,0,985380,0,0,'36/2020','UMMUHABEEBA'),(3073,82,'2022-12-09 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,992453,0,0,168,3000,992285,0,0,'288/2021','SABIRA'),(3074,33,'2022-12-09 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1338,0,0,56,0,1282,0,0,'288/2021','SABIRA'),(3075,46,'2022-12-09 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,985380,0,0,168,0,985212,0,0,'288/2021','SABIRA'),(3076,19,'2022-12-09 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,2303,0,0,168,0,2135,0,0,'288/2021','SABIRA'),(3077,83,'2022-12-09 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,992873,0,0,168,0,992705,0,0,'01/2018','ABDUL NAZAR'),(3078,50,'2022-12-09 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,1883,0,0,84,0,1799,0,0,'01/2018','ABDUL NAZAR'),(3079,68,'2022-12-09 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1341,0,0,84,0,1257,0,0,'01/2018','ABDUL NAZAR'),(3080,67,'2022-12-09 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,2032,0,0,84,0,1948,0,0,'01/2018','ABDUL NAZAR'),(3081,22,'2022-12-09 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2314,0,0,84,0,2230,0,0,'01/2018','ABDUL NAZAR'),(3082,92,'2022-12-09 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2966,0,0,28,0,2938,0,0,'77/2017','SUHARA'),(3083,93,'2022-12-09 00:00:00','M93','FLUPHENAZINE DECANOATE INJECTION IP 1ML','Transfer','Sub to OP',0,2994,0,0,2,0,2992,0,0,'77/2017','SUHARA'),(3084,83,'2022-12-09 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,992705,0,0,112,0,992593,0,0,'58/2021','SUMAYYA'),(3085,47,'2022-12-09 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1493,0,0,56,0,1437,0,0,'58/2021','SUMAYYA'),(3086,46,'2022-12-09 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,985212,0,0,224,0,984988,0,0,'58/2021','SUMAYYA'),(3087,21,'2022-12-09 00:00:00','M21','FLUOXETINE HCL CAPSULES 40MG','Transfer','Sub to OP',0,1969,0,0,168,0,1801,0,0,'161/2019','ASHRAF CP'),(3088,69,'2022-12-09 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1087,0,0,84,0,1003,0,0,'161/2019','ASHRAF CP'),(3089,81,'2022-12-09 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,998650,0,0,28,0,998622,0,0,'203/2022','RASIYA BANU'),(3090,83,'2022-12-09 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,992593,0,0,28,0,992565,0,0,'203/2022','RASIYA BANU'),(3091,68,'2022-12-09 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1257,0,0,28,0,1229,0,0,'203/2022','RASIYA BANU'),(3092,69,'2022-12-09 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,1003,0,0,28,0,975,0,0,'203/2022','RASIYA BANU'),(3093,12,'2022-12-09 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2307,0,0,28,0,2279,0,0,'203/2022','RASIYA BANU'),(3094,23,'2022-12-09 00:00:00','M23','FLUOXETINE CAPSULES 10MG','Transfer','Sub to OP',0,2944,0,0,28,0,2916,0,0,'203/2022','RASIYA BANU'),(3095,3,'2022-12-09 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2787,0,0,10,0,2777,0,0,'203/2022','RASIYA BANU'),(3096,46,'2022-12-09 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,984988,0,0,28,0,984960,0,0,'203/2022','RASIYA BANU'),(3097,83,'2022-12-09 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,992565,0,0,28,0,992537,0,0,'247/2021','NOUSHAD '),(3098,82,'2022-12-09 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,992285,0,0,28,3000,992257,0,0,'247/2021','NOUSHAD '),(3099,46,'2022-12-09 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,984960,0,0,32,0,984928,0,0,'247/2021','NOUSHAD '),(3100,71,'2022-12-09 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,8662,0,0,14,0,8648,0,0,'247/2021','NOUSHAD '),(3101,87,'2022-12-09 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Transfer','Sub to OP',0,2537,0,0,21,0,2516,0,0,'247/2021','NOUSHAD '),(3102,89,'2022-12-09 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,2799,0,0,14,0,2785,0,0,'247/2021','NOUSHAD '),(3103,35,'2022-12-09 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,1599,0,0,84,0,1515,0,0,'112/2017','SAIFUNEESA'),(3104,46,'2022-12-09 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,984928,0,0,84,0,984844,0,0,'112/2017','SAIFUNEESA'),(3105,34,'2022-12-09 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',1000,50,0,0,14,1000,36,0,0,'249/2022','FARSANA VP'),(3106,46,'2022-12-09 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,984844,0,0,14,0,984830,0,0,'249/2022','FARSANA VP'),(3107,83,'2022-12-09 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,992537,0,0,168,0,992369,0,0,'0078/2022','SREEDEVI'),(3108,49,'2022-12-09 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,965,0,0,84,0,881,0,0,'0078/2022','SREEDEVI'),(3109,46,'2022-12-09 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,984830,0,0,168,0,984662,0,0,'0078/2022','SREEDEVI'),(3110,83,'2022-12-16 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,992369,0,0,56,0,992313,0,0,'182/2021','MOHAMMAD BASHEER'),(3111,82,'2022-12-16 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,992257,0,0,28,3000,992229,0,0,'182/2021','MOHAMMAD BASHEER'),(3112,26,'2022-12-16 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,2370,0,0,56,0,2314,0,0,'182/2021','MOHAMMAD BASHEER'),(3113,49,'2022-12-16 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,881,0,0,42,0,839,0,0,'182/2021','MOHAMMAD BASHEER'),(3114,46,'2022-12-16 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,984662,0,0,72,0,984590,0,0,'182/2021','MOHAMMAD BASHEER'),(3115,82,'2022-12-16 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,992229,0,0,42,3000,992187,0,0,'118/2022','FIROZ'),(3116,83,'2022-12-16 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,992313,0,0,42,0,992271,0,0,'118/2022','FIROZ'),(3117,47,'2022-12-16 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1437,0,0,42,0,1395,0,0,'118/2022','FIROZ'),(3118,92,'2022-12-16 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2938,0,0,2,0,2936,0,0,'170/2022','HAMZA'),(3119,58,'2022-12-16 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Transfer','Sub to OP',0,2328,0,0,112,0,2216,0,0,'89/2018','MUHAMMAD'),(3120,70,'2022-12-16 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18082,0,0,56,0,18026,0,0,'89/2018','MUHAMMAD'),(3121,24,'2022-12-16 00:00:00','M24','GABAPENTIN TABLETS 100MG','Transfer','Sub to OP',0,2804,0,0,56,0,2748,0,0,'89/2018','MUHAMMAD'),(3122,4,'2022-12-16 00:00:00','M4','ESCITALOPRAM TABLETS 5MG','Transfer','Sub to OP',0,2706,0,0,21,0,2685,0,0,'243/2022','KUNJIPATHUMA'),(3123,69,'2022-12-16 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,975,0,0,84,0,891,0,0,'02/2022','GIRIJA'),(3124,22,'2022-12-16 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2230,0,0,84,0,2146,0,0,'02/2022','GIRIJA'),(3125,36,'2022-12-23 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1178,0,0,21,0,1157,0,0,'270/2022','KARTHIYAYINI'),(3126,89,'2022-12-23 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,2785,0,0,42,0,2743,0,0,'270/2022','KARTHIYAYINI'),(3127,93,'2022-12-23 00:00:00','M93','FLUPHENAZINE DECANOATE INJECTION IP 1ML','Transfer','Sub to OP',0,2992,0,0,2,0,2990,0,0,'270/2022','KARTHIYAYINI'),(3128,46,'2022-12-23 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,984590,0,0,42,0,984548,0,0,'270/2022','KARTHIYAYINI'),(3129,34,'2022-12-23 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',1000,36,0,0,7,1000,29,0,0,'270/2022','KARTHIYAYINI'),(3130,89,'2022-12-23 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,2743,0,0,14,0,2729,0,0,'270/2022','KARTHIYAYINI'),(3131,93,'2022-12-23 00:00:00','M93','FLUPHENAZINE DECANOATE INJECTION IP 1ML','Transfer','Sub to OP',0,2990,0,0,1,0,2989,0,0,'270/2022','KARTHIYAYINI'),(3132,46,'2022-12-23 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,984548,0,0,14,0,984534,0,0,'270/2022','KARTHIYAYINI'),(3133,48,'2022-12-23 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',5000,767,0,0,42,5000,725,0,0,'28/2020','ASSAINAR'),(3134,47,'2022-12-23 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1395,0,0,42,0,1353,0,0,'28/2020','ASSAINAR'),(3135,36,'2022-12-23 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1157,0,0,21,0,1136,0,0,'28/2020','ASSAINAR'),(3136,49,'2022-12-23 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,839,0,0,28,0,811,0,0,'45/2017','KORAN'),(3137,83,'2022-12-23 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,992271,0,0,84,0,992187,0,0,'75/2019','UNNIKRISHNAN'),(3138,68,'2022-12-23 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1229,0,0,168,0,1061,0,0,'75/2019','UNNIKRISHNAN'),(3139,46,'2022-12-23 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,984534,0,0,252,0,984282,0,0,'75/2019','UNNIKRISHNAN'),(3140,82,'2022-09-30 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,992187,0,0,56,3000,992131,0,0,'137/2020','SADHASHIVAN'),(3141,83,'2022-09-30 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,992187,0,0,56,0,992131,0,0,'137/2020','SADHASHIVAN'),(3142,36,'2022-09-30 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1136,0,0,56,0,1080,0,0,'137/2020','SADHASHIVAN'),(3143,48,'2022-09-30 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',5000,725,0,0,56,5000,669,0,0,'137/2020','SADHASHIVAN'),(3144,82,'2022-04-15 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,992131,0,0,84,3000,992047,0,0,'137/2020','SADHASHIVAN'),(3145,83,'2022-04-15 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,992131,0,0,84,0,992047,0,0,'137/2020','SADHASHIVAN'),(3146,36,'2022-04-15 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,1080,0,0,84,0,996,0,0,'137/2020','SADHASHIVAN'),(3147,49,'2022-04-15 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,811,0,0,84,0,727,0,0,'137/2020','SADHASHIVAN'),(3148,48,'2022-04-15 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',5000,669,0,0,84,5000,585,0,0,'137/2020','SADHASHIVAN'),(3149,46,'2022-04-15 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,984282,0,0,168,0,984114,0,0,'137/2020','SADHASHIVAN'),(3150,82,'2022-12-23 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,992047,0,0,84,3000,991963,0,0,'137/2020','SADHASHIVAN'),(3151,83,'2022-12-23 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,992047,0,0,84,0,991963,0,0,'137/2020','SADHASHIVAN'),(3152,36,'2022-12-23 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,996,0,0,84,0,912,0,0,'137/2020','SADHASHIVAN'),(3153,49,'2022-12-23 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,727,0,0,84,0,643,0,0,'137/2020','SADHASHIVAN'),(3154,46,'2022-12-23 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,984114,0,0,84,0,984030,0,0,'137/2020','SADHASHIVAN'),(3155,12,'2022-12-23 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2279,0,0,42,0,2237,0,0,'201/2022','PRAMOD'),(3156,36,'2022-12-23 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,912,0,0,42,0,870,0,0,'201/2022','PRAMOD'),(3157,33,'2022-12-23 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1282,0,0,42,0,1240,0,0,'201/2022','PRAMOD'),(3158,46,'2022-12-23 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,984030,0,0,42,0,983988,0,0,'201/2022','PRAMOD'),(3159,49,'2022-12-23 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,643,0,0,70,0,573,0,0,'48/2017','ABDUL HASEEB'),(3160,48,'2022-12-23 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',5000,585,0,0,70,5000,515,0,0,'48/2017','ABDUL HASEEB'),(3161,47,'2022-12-23 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1353,0,0,70,0,1283,0,0,'48/2017','ABDUL HASEEB'),(3162,35,'2022-12-23 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,1515,0,0,70,0,1445,0,0,'48/2017','ABDUL HASEEB'),(3163,46,'2022-12-23 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,983988,0,0,210,0,983778,0,0,'48/2017','ABDUL HASEEB'),(3164,83,'2022-09-30 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,991963,0,0,84,0,991879,0,0,'47/2017','KUNJATHU'),(3165,70,'2022-09-30 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,18026,0,0,84,0,17942,0,0,'47/2017','KUNJATHU'),(3166,83,'2022-12-23 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,991879,0,0,84,0,991795,0,0,'47/2017','KUNJATHU'),(3167,71,'2022-12-23 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,8648,0,0,84,0,8564,0,0,'47/2017','KUNJATHU'),(3168,83,'2022-12-23 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,991795,0,0,56,0,991739,0,0,'204/2022','ANSIF'),(3169,82,'2022-12-23 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,991963,0,0,28,3000,991935,0,0,'204/2022','ANSIF'),(3170,68,'2022-12-23 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1061,0,0,28,0,1033,0,0,'204/2022','ANSIF'),(3171,35,'2022-12-23 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,1445,0,0,28,0,1417,0,0,'204/2022','ANSIF'),(3172,28,'2022-12-23 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,1479,0,0,42,0,1437,0,0,'204/2022','ANSIF'),(3173,46,'2022-12-23 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,983778,0,0,56,0,983722,0,0,'204/2022','ANSIF'),(3174,83,'2022-12-23 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,991739,0,0,14,0,991725,0,0,'247/2021','NOUSHAD '),(3175,82,'2022-12-23 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,991935,0,0,14,3000,991921,0,0,'247/2021','NOUSHAD '),(3176,35,'2022-12-23 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,1417,0,0,7,0,1410,0,0,'247/2021','NOUSHAD '),(3177,34,'2022-12-23 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',1000,29,0,0,7,1000,22,0,0,'247/2021','NOUSHAD '),(3178,46,'2022-12-23 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,983722,0,0,28,0,983694,0,0,'247/2021','NOUSHAD '),(3179,71,'2022-12-23 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,8564,0,0,7,0,8557,0,0,'247/2021','NOUSHAD '),(3180,87,'2022-12-23 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Transfer','Sub to OP',0,2516,0,0,10,0,2506,0,0,'247/2021','NOUSHAD '),(3181,89,'2022-12-23 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,2729,0,0,7,0,2722,0,0,'247/2021','NOUSHAD '),(3182,5,'2022-12-23 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2251,0,0,63,0,2188,0,0,'242/2022','HARIDASAN'),(3183,68,'2022-12-23 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,1033,0,0,70,0,963,0,0,'56/2022','UNNIKRISHNAN'),(3184,82,'2022-12-23 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,991921,0,0,252,3000,991669,0,0,'135/2018','SOUDHA'),(3185,84,'2022-12-23 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,2090,0,0,168,0,1922,0,0,'135/2018','SOUDHA'),(3186,67,'2022-12-23 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,1948,0,0,84,0,1864,0,0,'135/2018','SOUDHA'),(3187,69,'2022-12-23 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,891,0,0,84,0,807,0,0,'135/2018','SOUDHA'),(3188,75,'2022-12-23 00:00:00','M75','PROPRANOLOL SUSTAINED RELEASE TABLETS 40MG','Transfer','Sub to OP',0,2930,0,0,63,0,2867,0,0,'135/2018','SOUDHA'),(3189,46,'2022-12-23 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,983694,0,0,84,0,983610,0,0,'135/2018','SOUDHA'),(3190,83,'2022-12-23 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,991725,0,0,105,0,991620,0,0,'90/2017','RANEESH'),(3191,46,'2022-12-23 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,983610,0,0,140,0,983470,0,0,'90/2017','RANEESH'),(3192,49,'2022-12-23 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',0,573,0,0,35,0,538,0,0,'90/2017','RANEESH'),(3193,76,'2022-12-23 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,1593,0,0,35,0,1558,0,0,'90/2017','RANEESH'),(3194,70,'2022-12-23 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,17942,0,0,35,0,17907,0,0,'90/2017','RANEESH'),(3195,36,'2022-12-23 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,870,0,0,70,0,800,0,0,'90/2017','RANEESH'),(3196,67,'2022-12-30 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,1864,0,0,84,0,1780,0,0,'292/2021','ABDUL NAZAR'),(3197,70,'2022-12-30 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,17907,0,0,84,0,17823,0,0,'292/2021','ABDUL NAZAR'),(3198,33,'2022-12-30 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1240,0,0,84,0,1156,0,0,'237/2022','RAHMATHUNNEESA'),(3199,46,'2022-12-30 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,983470,0,0,42,0,983428,0,0,'237/2022','RAHMATHUNNEESA'),(3200,82,'2022-12-30 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,991669,0,0,112,3000,991557,0,0,'059/2021','YASHODHA'),(3201,83,'2022-12-30 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,991620,0,0,112,0,991508,0,0,'059/2021','YASHODHA'),(3202,71,'2022-12-30 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,8557,0,0,112,0,8445,0,0,'059/2021','YASHODHA'),(3203,49,'2023-01-04 00:00:00','M49','CLOZAPINE TABLETS 100MG','Edit','Edit stock',0,538,0,0,0,0,538,0,0,'',''),(3204,49,'2023-01-04 00:00:00','M49','CLOZAPINE TABLETS 100MG','Inbound','To main stock',0,538,0,0,5000,5000,538,0,0,'',''),(3205,34,'2023-01-04 00:00:00','M34','RISPERIDONE TABLETS 2MG','Inbound','To main stock',1000,22,0,0,5000,6000,22,0,0,'',''),(3206,34,'2023-01-04 00:00:00','M34','RISPERIDONE TABLETS 2MG','Inbound','To main stock',6000,22,0,0,100,6100,22,0,0,'',''),(3207,34,'2023-01-04 00:00:00','M34','RISPERIDONE TABLETS 2MG','Edit','Edit stock',6100,22,0,0,0,6100,22,0,0,'',''),(3208,34,'2023-01-04 00:00:00','M34','RISPERIDONE TABLETS 2MG','Edit','Edit stock',6100,22,0,0,0,6100,5022,0,0,'',''),(3209,34,'2023-01-04 00:00:00','M34','RISPERIDONE TABLETS 2MG','Edit','Edit stock',6100,5022,0,0,0,5100,5022,0,0,'',''),(3210,34,'2023-01-04 00:00:00','M34','RISPERIDONE TABLETS 2MG','Edit','Edit stock',5100,5022,0,0,0,5100,5122,0,0,'',''),(3211,49,'2023-01-04 00:00:00','M49','CLOZAPINE TABLETS 100MG','Edit','Edit stock',5000,538,0,0,0,5000,5538,0,0,'',''),(3212,34,'2022-12-30 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',5100,5122,0,0,112,5100,5010,0,0,'106/2017','VIJAYALAKSHMI'),(3213,46,'2022-12-30 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,983428,0,0,112,0,983316,0,0,'106/2017','VIJAYALAKSHMI'),(3214,81,'2022-12-30 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,998622,0,0,56,0,998566,0,0,'90/2022','MOHAMMED RUFAID '),(3215,86,'2022-12-30 00:00:00','M86','CLOBAZAM TABLETS 10 MG','Transfer','Sub to OP',0,2538,0,0,56,0,2482,0,0,'90/2022','MOHAMMED RUFAID '),(3216,33,'2022-12-30 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1156,0,0,28,0,1128,0,0,'90/2022','MOHAMMED RUFAID '),(3217,81,'2022-12-30 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,998566,0,0,252,0,998314,0,0,'0130/2017','SHANDHA'),(3218,43,'2022-12-30 00:00:00','M43','VENLAFAXINE EXTENDED RELEASE CAPSULES 75MG','Transfer','Sub to OP',0,2666,0,0,168,0,2498,0,0,'0130/2017','SHANDHA'),(3219,65,'2022-12-30 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,2524,0,0,84,0,2440,0,0,'0130/2017','SHANDHA'),(3220,82,'2022-12-30 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,991557,0,0,42,3000,991515,0,0,'54/2017','PUSHPAVATHI'),(3221,83,'2022-12-30 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,991508,0,0,42,0,991466,0,0,'54/2017','PUSHPAVATHI'),(3222,46,'2022-12-30 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,983316,0,0,42,0,983274,0,0,'54/2017','PUSHPAVATHI'),(3223,8,'2022-12-30 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Transfer','Sub to OP',0,2688,0,0,42,0,2646,0,0,'54/2017','PUSHPAVATHI'),(3224,11,'2023-01-06 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,2978,0,0,6,0,2972,0,0,'52/2022','ISMAIL'),(3225,35,'2023-01-06 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,1410,0,0,112,0,1298,0,0,'52/2022','ISMAIL'),(3226,79,'2023-01-06 00:00:00','M79','PHENOBARBITONE TABLETS 60MG','Transfer','Sub to OP',0,2916,0,0,168,0,2748,0,0,'190/2022','NOUSHAD '),(3227,35,'2023-01-06 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,1298,0,0,84,0,1214,0,0,'190/2022','NOUSHAD '),(3228,46,'2023-01-06 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,983274,0,0,84,0,983190,0,0,'190/2022','NOUSHAD '),(3229,89,'2023-01-06 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,2722,0,0,84,0,2638,0,0,'190/2022','NOUSHAD '),(3230,5,'2023-01-06 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2188,0,0,42,0,2146,0,0,'243/2022','KUNJIPATHUMA'),(3231,35,'2023-01-06 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,1214,0,0,28,0,1186,0,0,'249/2022','FARSANA VP'),(3232,46,'2023-01-06 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,983190,0,0,28,0,983162,0,0,'249/2022','FARSANA VP'),(3233,58,'2023-01-06 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Transfer','Sub to OP',0,2216,0,0,168,0,2048,0,0,'206/2021','FARHANA SHIRIL'),(3234,34,'2023-01-06 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',5100,5010,0,0,84,5100,4926,0,0,'206/2021','FARHANA SHIRIL'),(3235,49,'2023-01-06 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',5000,5538,0,0,28,5000,5510,0,0,'27/2017','FADALU (FAIZAL)'),(3236,20,'2023-01-06 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,2482,0,0,28,0,2454,0,0,'27/2017','FADALU (FAIZAL)'),(3237,83,'2023-01-06 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,991466,0,0,28,0,991438,0,0,'247/2021','NOUSHAD '),(3238,82,'2023-01-06 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,991515,0,0,14,3000,991501,0,0,'247/2021','NOUSHAD '),(3239,36,'2023-01-06 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,800,0,0,14,0,786,0,0,'247/2021','NOUSHAD '),(3240,63,'2023-01-06 00:00:00','M63','LACOSAMIDE TABLETS 100MG','Transfer','Sub to OP',0,3000,0,0,7,0,2993,0,0,'247/2021','NOUSHAD '),(3241,70,'2023-01-06 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,17823,0,0,14,0,17809,0,0,'247/2021','NOUSHAD '),(3242,46,'2023-01-06 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,983162,0,0,21,0,983141,0,0,'247/2021','NOUSHAD '),(3243,68,'2023-01-06 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,963,0,0,126,0,837,0,0,'99/2019','SUNIL'),(3244,83,'2023-01-06 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,991438,0,0,168,0,991270,0,0,'155/2022','SAINUDHEEN'),(3245,34,'2023-01-06 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',5100,4926,0,0,84,5100,4842,0,0,'155/2022','SAINUDHEEN'),(3246,82,'2023-01-06 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,991501,0,0,168,3000,991333,0,0,'135/2020','ALAVI'),(3247,69,'2023-01-06 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,807,0,0,42,0,765,0,0,'135/2020','ALAVI'),(3248,22,'2023-01-06 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2146,0,0,84,0,2062,0,0,'135/2020','ALAVI'),(3249,46,'2023-01-06 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,983141,0,0,84,0,983057,0,0,'135/2020','ALAVI'),(3250,71,'2023-01-06 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,8445,0,0,72,0,8373,0,0,'263/2021','FATHIMMA PP'),(3251,3,'2023-01-06 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2777,0,0,20,0,2757,0,0,'263/2021','FATHIMMA PP'),(3252,83,'2023-01-06 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,991270,0,0,56,0,991214,0,0,'263/2021','FATHIMMA PP'),(3253,22,'2023-01-06 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2062,0,0,56,0,2006,0,0,'263/2021','FATHIMMA PP'),(3254,68,'2023-01-06 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,837,0,0,28,0,809,0,0,'263/2021','FATHIMMA PP'),(3255,3,'2023-01-06 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2757,0,0,10,0,2747,0,0,'263/2021','FATHIMMA PP'),(3256,81,'2023-01-06 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,998314,0,0,84,0,998230,0,0,'104/2018','HASEENA'),(3257,39,'2023-01-06 00:00:00','M39','SERTRALINE HCL TABLETS 50MG','Transfer','Sub to OP',0,2503,0,0,252,0,2251,0,0,'104/2018','HASEENA'),(3258,85,'2023-01-06 00:00:00','M85','LEVETIRACETAM TABLETS 250 MG','Transfer','Sub to OP',0,2874,0,0,168,0,2706,0,0,'8/2014','DHANISHMA'),(3259,69,'2023-01-06 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,765,0,0,84,0,681,0,0,'250/2021','HASEENA '),(3260,67,'2023-01-06 00:00:00','M67','OLANZAPINE TABLETS 2.5MG','Transfer','Sub to OP',0,1780,0,0,84,0,1696,0,0,'250/2021','HASEENA '),(3261,36,'2023-01-06 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,786,0,0,56,0,730,0,0,'130/2022','AHAMMED KUTTY'),(3262,33,'2023-01-06 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1128,0,0,56,0,1072,0,0,'130/2022','AHAMMED KUTTY'),(3263,70,'2023-01-06 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,17809,0,0,56,0,17753,0,0,'130/2022','AHAMMED KUTTY'),(3264,46,'2023-01-06 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,983057,0,0,56,0,983001,0,0,'130/2022','AHAMMED KUTTY'),(3265,34,'2023-01-06 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',5100,4842,0,0,56,5100,4786,0,0,'138/2019','UMMAR'),(3266,35,'2023-01-06 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,1186,0,0,112,0,1074,0,0,'138/2019','UMMAR'),(3267,49,'2023-01-06 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',5000,5510,0,0,56,5000,5454,0,0,'138/2019','UMMAR'),(3268,47,'2023-01-06 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1283,0,0,56,0,1227,0,0,'138/2019','UMMAR'),(3269,6,'2023-01-06 00:00:00','M6','ESCITALOPRAM TABLETS 20MG','Transfer','Sub to OP',0,2944,0,0,28,0,2916,0,0,'283/2022','MAIMOONA'),(3270,5,'2023-01-06 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2146,0,0,28,0,2118,0,0,'283/2022','MAIMOONA'),(3271,89,'2023-01-06 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,2638,0,0,14,0,2624,0,0,'283/2022','MAIMOONA'),(3272,3,'2023-01-06 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2747,0,0,14,0,2733,0,0,'283/2022','MAIMOONA'),(3273,65,'2023-01-06 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,2440,0,0,28,0,2412,0,0,'283/2022','MAIMOONA'),(3274,6,'2022-12-23 00:00:00','M6','ESCITALOPRAM TABLETS 20MG','Transfer','Sub to OP',0,2916,0,0,28,0,2888,0,0,'283/2022','MAIMOONA'),(3275,89,'2022-12-23 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,2624,0,0,14,0,2610,0,0,'283/2022','MAIMOONA'),(3276,64,'2022-12-23 00:00:00','M64','MIRTAZAPINE TABLETS 7.5MG','Transfer','Sub to OP',0,2804,0,0,14,0,2790,0,0,'283/2022','MAIMOONA'),(3277,83,'2023-01-06 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,991214,0,0,28,0,991186,0,0,'280/2022','YAHUTTY'),(3278,82,'2023-01-06 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,991333,0,0,14,3000,991319,0,0,'280/2022','YAHUTTY'),(3279,36,'2023-01-06 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,730,0,0,28,0,702,0,0,'280/2022','YAHUTTY'),(3280,46,'2023-01-06 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,983001,0,0,42,0,982959,0,0,'280/2022','YAHUTTY'),(3281,76,'2023-01-06 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,1558,0,0,28,0,1530,0,0,'280/2022','YAHUTTY'),(3282,71,'2023-01-06 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,8373,0,0,14,0,8359,0,0,'280/2022','YAHUTTY'),(3283,69,'2023-01-06 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,681,0,0,21,0,660,0,0,'279/2022','KAMARUNEESA'),(3284,22,'2023-01-06 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,2006,0,0,21,0,1985,0,0,'279/2022','KAMARUNEESA'),(3285,83,'2023-01-06 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,991186,0,0,56,0,991130,0,0,'203/2022','RASIYA BANU'),(3286,12,'2023-01-06 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2237,0,0,56,0,2181,0,0,'203/2022','RASIYA BANU'),(3287,68,'2023-01-06 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,809,0,0,28,0,781,0,0,'203/2022','RASIYA BANU'),(3288,69,'2023-01-06 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,660,0,0,28,0,632,0,0,'203/2022','RASIYA BANU'),(3289,3,'2023-01-06 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2733,0,0,10,0,2723,0,0,'203/2022','RASIYA BANU'),(3290,29,'2023-01-06 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,1873,0,0,252,0,1621,0,0,'205/2022','ABDUL RASAK'),(3291,36,'2023-01-06 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,702,0,0,168,0,534,0,0,'205/2022','ABDUL RASAK'),(3292,46,'2023-01-06 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,982959,0,0,168,0,982791,0,0,'205/2022','ABDUL RASAK'),(3293,12,'2023-01-06 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2181,0,0,168,0,2013,0,0,'205/2022','ABDUL RASAK'),(3294,56,'2023-01-06 00:00:00','M56','CLOMIPRAMINE TABLETS 25MG','Transfer','Sub to OP',0,2784,0,0,168,0,2616,0,0,'205/2022','ABDUL RASAK'),(3295,83,'2023-01-06 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,991130,0,0,14,0,991116,0,0,'204/2022','ANSIF'),(3296,82,'2023-01-06 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,991319,0,0,14,3000,991305,0,0,'204/2022','ANSIF'),(3297,36,'2023-01-06 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,534,0,0,28,0,506,0,0,'204/2022','ANSIF'),(3298,29,'2023-01-06 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,1621,0,0,28,0,1593,0,0,'204/2022','ANSIF'),(3299,46,'2023-01-06 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,982791,0,0,42,0,982749,0,0,'204/2022','ANSIF'),(3300,34,'2023-01-06 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',5100,4786,0,0,84,5100,4702,0,0,'202/2022','BINDU'),(3301,46,'2023-01-06 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,982749,0,0,168,0,982581,0,0,'202/2022','BINDU'),(3302,82,'2023-01-13 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,991305,0,0,112,3000,991193,0,0,'90/2022','MOHAMMED RUFAID '),(3303,27,'2023-01-13 00:00:00','M27','LURASIDONE HCL TABLETS 40MG','Transfer','Sub to OP',0,2790,0,0,56,0,2734,0,0,'90/2022','MOHAMMED RUFAID '),(3304,82,'2023-01-13 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,991193,0,0,21,3000,991172,0,0,'288/2021','SABIRA'),(3305,33,'2023-01-13 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1072,0,0,7,0,1065,0,0,'288/2021','SABIRA'),(3306,46,'2023-01-13 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,982581,0,0,7,0,982574,0,0,'288/2021','SABIRA'),(3307,19,'2023-01-13 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,2135,0,0,21,0,2114,0,0,'288/2021','SABIRA'),(3308,34,'2023-01-13 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',5100,4702,0,0,28,5100,4674,0,0,'270/2022','KARTHIYAYINI'),(3309,89,'2023-01-13 00:00:00','M89','CLONAZEPAM TABLETS 0.5 MG','Transfer','Sub to OP',0,2610,0,0,56,0,2554,0,0,'270/2022','KARTHIYAYINI'),(3310,93,'2023-01-13 00:00:00','M93','FLUPHENAZINE DECANOATE INJECTION IP 1ML','Transfer','Sub to OP',0,2989,0,0,1,0,2988,0,0,'270/2022','KARTHIYAYINI'),(3311,46,'2023-01-13 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,982574,0,0,56,0,982518,0,0,'270/2022','KARTHIYAYINI'),(3312,5,'2023-01-13 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2118,0,0,42,0,2076,0,0,'202/2021','SHAJI'),(3313,49,'2023-01-13 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',5000,5454,0,0,28,5000,5426,0,0,'45/2017','KORAN'),(3314,28,'2023-01-13 00:00:00','M28','LITHIUM CARBONATE EXTENDED RELEASE TABLETS 400MG','Transfer','Sub to OP',0,1437,0,0,168,0,1269,0,0,'79/2021','HAMEED'),(3315,83,'2023-01-13 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,991116,0,0,84,0,991032,0,0,'79/2021','HAMEED'),(3316,5,'2023-01-13 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,2076,0,0,84,0,1992,0,0,'79/2021','HAMEED'),(3317,83,'2023-01-13 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,991032,0,0,28,0,991004,0,0,'182/2021','MOHAMMAD BASHEER'),(3318,71,'2023-01-13 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,8359,0,0,14,0,8345,0,0,'182/2021','MOHAMMAD BASHEER'),(3319,26,'2023-01-13 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,2314,0,0,28,0,2286,0,0,'182/2021','MOHAMMAD BASHEER'),(3320,49,'2023-01-13 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',5000,5426,0,0,14,5000,5412,0,0,'182/2021','MOHAMMAD BASHEER'),(3321,46,'2023-01-13 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,982518,0,0,32,0,982486,0,0,'182/2021','MOHAMMAD BASHEER'),(3322,65,'2023-01-13 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,2412,0,0,35,0,2377,0,0,'249/2021','SUDHAKARAN'),(3323,71,'2023-01-13 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,8345,0,0,14,0,8331,0,0,'249/2021','SUDHAKARAN'),(3324,70,'2023-01-13 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,17753,0,0,14,0,17739,0,0,'249/2021','SUDHAKARAN'),(3325,3,'2023-01-13 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2723,0,0,14,0,2709,0,0,'249/2021','SUDHAKARAN'),(3326,36,'2023-01-13 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,506,0,0,168,0,338,0,0,'088/2017','MUHAMMAD RAFEEQ'),(3327,46,'2023-01-13 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,982486,0,0,84,0,982402,0,0,'088/2017','MUHAMMAD RAFEEQ'),(3328,49,'2023-01-13 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',5000,5412,0,0,84,5000,5328,0,0,'88/2017','MUHAMMAD RAFI'),(3329,47,'2023-01-13 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1227,0,0,84,0,1143,0,0,'88/2017','MUHAMMAD RAFI'),(3330,10,'2023-01-13 00:00:00','M10','AMISULPRIDE TABLETS 200MG','Transfer','Sub to OP',0,3000,0,0,84,0,2916,0,0,'88/2017','MUHAMMAD RAFI'),(3331,46,'2023-01-13 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,982402,0,0,84,0,982318,0,0,'88/2017','MUHAMMAD RAFI'),(3332,33,'2023-01-13 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,1065,0,0,84,0,981,0,0,'0112/2017','ZEHARABI'),(3333,34,'2023-01-20 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',5100,4674,0,0,56,5100,4618,0,0,'200/2022','KOLAVAM'),(3334,83,'2023-01-20 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,991004,0,0,84,0,990920,0,0,'280/2022','YAHUTTY'),(3335,83,'2023-01-20 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,990920,0,0,56,0,990864,0,0,'203/2022','RASIYA BANU'),(3336,12,'2023-01-20 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,2013,0,0,56,0,1957,0,0,'203/2022','RASIYA BANU'),(3337,69,'2023-01-20 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,632,0,0,28,0,604,0,0,'203/2022','RASIYA BANU'),(3338,68,'2023-01-20 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,781,0,0,28,0,753,0,0,'203/2022','RASIYA BANU'),(3339,3,'2023-01-20 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2709,0,0,10,0,2699,0,0,'203/2022','RASIYA BANU'),(3340,48,'2023-01-20 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',5000,515,0,0,84,5000,431,0,0,'05/2022','SHAMEERALI'),(3341,92,'2023-01-20 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2936,0,0,4,0,2932,0,0,'05/2022','SHAMEERALI'),(3342,83,'2023-01-20 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,990864,0,0,112,0,990752,0,0,'93/2017','SOORAJ'),(3343,50,'2023-01-20 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,1799,0,0,56,0,1743,0,0,'93/2017','SOORAJ'),(3344,49,'2023-01-20 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',5000,5328,0,0,56,5000,5272,0,0,'93/2017','SOORAJ'),(3345,46,'2023-01-20 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,982318,0,0,168,0,982150,0,0,'93/2017','SOORAJ'),(3346,29,'2023-01-20 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,1593,0,0,168,0,1425,0,0,'92/2022','MOHAMMED '),(3347,25,'2023-01-20 00:00:00','M25','HALOPERIDOL TABLETS 5MG','Transfer','Sub to OP',0,2286,0,0,56,0,2230,0,0,'92/2022','MOHAMMED '),(3348,46,'2023-01-20 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,982150,0,0,112,0,982038,0,0,'92/2022','MOHAMMED '),(3349,81,'2023-01-20 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,998230,0,0,56,0,998174,0,0,'90/2022','MOHAMMED RUFAID '),(3350,86,'2023-01-20 00:00:00','M86','CLOBAZAM TABLETS 10 MG','Transfer','Sub to OP',0,2482,0,0,56,0,2426,0,0,'90/2022','MOHAMMED RUFAID '),(3351,33,'2023-01-20 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,981,0,0,28,0,953,0,0,'90/2022','MOHAMMED RUFAID '),(3352,22,'2023-01-20 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,1985,0,0,56,0,1929,0,0,'201/2022','PRAMOD'),(3353,36,'2023-01-20 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,338,0,0,56,0,282,0,0,'201/2022','PRAMOD'),(3354,33,'2023-01-20 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,953,0,0,56,0,897,0,0,'201/2022','PRAMOD'),(3355,46,'2023-01-20 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,982038,0,0,112,0,981926,0,0,'201/2022','PRAMOD'),(3356,82,'2023-01-20 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,991172,0,0,168,3000,991004,0,0,'201/2022','PRAMOD'),(3357,70,'2023-01-20 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,17739,0,0,56,0,17683,0,0,'201/2022','PRAMOD'),(3358,36,'2023-01-20 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,282,0,0,56,0,226,0,0,'201/2022','PRAMOD'),(3359,33,'2023-01-20 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,897,0,0,56,0,841,0,0,'201/2022','PRAMOD'),(3360,46,'2023-01-20 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,981926,0,0,168,0,981758,0,0,'201/2022','PRAMOD'),(3361,19,'2023-01-20 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,2114,0,0,112,0,2002,0,0,'080/2020','SAJNA'),(3362,45,'2023-01-20 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,2307,0,0,56,0,2251,0,0,'080/2020','SAJNA'),(3363,70,'2023-01-20 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,17683,0,0,10,0,17673,0,0,'080/2020','SAJNA'),(3364,83,'2023-01-20 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,990752,0,0,56,0,990696,0,0,'204/2022','ANSIF'),(3365,82,'2023-01-20 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,991004,0,0,28,3000,990976,0,0,'204/2022','ANSIF'),(3366,36,'2023-01-20 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,226,0,0,56,0,170,0,0,'204/2022','ANSIF'),(3367,29,'2023-01-20 00:00:00','M29','LITHIUM CARBONATE 300MG','Transfer','Sub to OP',0,1425,0,0,56,0,1369,0,0,'204/2022','ANSIF'),(3368,46,'2023-01-20 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,981758,0,0,84,0,981674,0,0,'204/2022','ANSIF'),(3369,50,'2023-01-20 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,1743,0,0,84,0,1659,0,0,'65/2021','MUHAMMAD ISMAIL PM'),(3370,49,'2023-01-20 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',5000,5272,0,0,84,5000,5188,0,0,'65/2021','MUHAMMAD ISMAIL PM'),(3371,35,'2023-01-20 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,1074,0,0,84,0,990,0,0,'65/2021','MUHAMMAD ISMAIL PM'),(3372,46,'2023-01-20 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,981674,0,0,84,0,981590,0,0,'65/2021','MUHAMMAD ISMAIL PM'),(3373,82,'2023-01-20 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,990976,0,0,56,3000,990920,0,0,'211/2019','RAJAN'),(3374,81,'2023-01-20 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,998174,0,0,56,0,998118,0,0,'211/2019','RAJAN'),(3375,45,'2023-01-20 00:00:00','M45','TOPIRAMATE TABLETS 25MG','Transfer','Sub to OP',0,2251,0,0,112,0,2139,0,0,'211/2019','RAJAN'),(3376,87,'2023-01-20 00:00:00','M87','CLOBAZAM TABLETS 5 MG','Transfer','Sub to OP',0,2506,0,0,84,0,2422,0,0,'211/2019','RAJAN'),(3377,5,'2023-01-20 00:00:00','M5','ESCITALOPRAM TABLETS 10MG','Transfer','Sub to OP',0,1992,0,0,56,0,1936,0,0,'211/2019','RAJAN'),(3378,69,'2023-01-20 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,604,0,0,56,0,548,0,0,'211/2019','RAJAN'),(3379,76,'2023-01-20 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,1530,0,0,112,0,1418,0,0,'211/2019','RAJAN'),(3380,81,'2023-01-20 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,998118,0,0,56,0,998062,0,0,'83/2019','FARSANA THASNI'),(3381,84,'2023-01-20 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,1922,0,0,56,0,1866,0,0,'83/2019','FARSANA THASNI'),(3382,59,'2023-01-20 00:00:00','M59','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 200MG','Transfer','Sub to OP',0,2832,0,0,56,0,2776,0,0,'83/2019','FARSANA THASNI'),(3383,82,'2023-01-20 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,990920,0,0,168,3000,990752,0,0,'288/2021','SABIRA'),(3384,33,'2023-01-20 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,841,0,0,56,0,785,0,0,'288/2021','SABIRA'),(3385,46,'2023-01-20 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,981590,0,0,168,0,981422,0,0,'288/2021','SABIRA'),(3386,19,'2023-01-20 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,2002,0,0,224,0,1778,0,0,'288/2021','SABIRA'),(3387,82,'2023-01-20 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,990752,0,0,168,3000,990584,0,0,'232/2021','USMAN'),(3388,83,'2023-01-20 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,990696,0,0,84,0,990612,0,0,'232/2021','USMAN'),(3389,36,'2023-01-20 00:00:00','M36','RISPERIDONE TABLETS 4MG','Transfer','Sub to OP',0,170,0,0,84,0,86,0,0,'232/2021','USMAN'),(3390,46,'2023-01-20 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,981422,0,0,252,0,981170,0,0,'232/2021','USMAN'),(3391,49,'2023-01-20 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',5000,5188,0,0,84,5000,5104,0,0,'232/2021','USMAN'),(3392,81,'2023-01-20 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,998062,0,0,56,0,998006,0,0,'90/2022','MOHAMMED RUFAID '),(3393,86,'2023-01-20 00:00:00','M86','CLOBAZAM TABLETS 10 MG','Transfer','Sub to OP',0,2426,0,0,56,0,2370,0,0,'90/2022','MOHAMMED RUFAID '),(3394,33,'2023-01-20 00:00:00','M33','RISPERIDONE TABLETS 1MG','Transfer','Sub to OP',0,785,0,0,28,0,757,0,0,'90/2022','MOHAMMED RUFAID '),(3395,83,'2023-01-27 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,990612,0,0,42,0,990570,0,0,'203/2022','RASIYA BANU'),(3396,22,'2023-01-27 00:00:00','M22','FLUOXETINE HCL TABLETS 20MG','Transfer','Sub to OP',0,1929,0,0,42,0,1887,0,0,'203/2022','RASIYA BANU'),(3397,68,'2023-01-27 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,753,0,0,21,0,732,0,0,'203/2022','RASIYA BANU'),(3398,69,'2023-01-27 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,548,0,0,21,0,527,0,0,'203/2022','RASIYA BANU'),(3399,71,'2023-01-27 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,8331,0,0,42,0,8289,0,0,'249/2021','SUDHAKARAN'),(3400,65,'2023-01-27 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,2377,0,0,84,0,2293,0,0,'249/2021','SUDHAKARAN'),(3401,3,'2023-01-27 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2699,0,0,42,0,2657,0,0,'249/2021','SUDHAKARAN'),(3402,69,'2023-01-27 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,527,0,0,21,0,506,0,0,'279/2022','KAMARUNEESA'),(3403,12,'2023-01-27 00:00:00','M12','FLUOXETINE CAPSULES 20MG','Transfer','Sub to OP',0,1957,0,0,21,0,1936,0,0,'279/2022','KAMARUNEESA'),(3404,83,'2023-01-27 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,990570,0,0,126,0,990444,0,0,'90/2017','RANEESH'),(3405,46,'2023-01-27 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,981170,0,0,168,0,981002,0,0,'90/2017','RANEESH'),(3406,49,'2023-01-27 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',5000,5104,0,0,42,5000,5062,0,0,'90/2017','RANEESH'),(3407,76,'2023-01-27 00:00:00','M76','PROPRANOLOL TABLETS 20MG','Transfer','Sub to OP',0,1418,0,0,42,0,1376,0,0,'90/2017','RANEESH'),(3408,70,'2023-01-27 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,17673,0,0,42,0,17631,0,0,'90/2017','RANEESH'),(3409,82,'2023-01-27 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,990584,0,0,42,3000,990542,0,0,'118/2022','FIROZ'),(3410,83,'2023-01-27 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,990444,0,0,42,0,990402,0,0,'118/2022','FIROZ'),(3411,47,'2023-01-27 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1143,0,0,42,0,1101,0,0,'118/2022','FIROZ'),(3412,92,'2023-01-27 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2932,0,0,4,0,2928,0,0,'170/2022','HAMZA'),(3413,83,'2023-01-27 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,990402,0,0,112,0,990290,0,0,'182/2021','MOHAMMAD BASHEER'),(3414,82,'2023-01-27 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,990542,0,0,56,3000,990486,0,0,'182/2021','MOHAMMAD BASHEER'),(3415,71,'2023-01-27 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,8289,0,0,56,0,8233,0,0,'182/2021','MOHAMMAD BASHEER'),(3416,26,'2023-01-27 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,2286,0,0,112,0,2174,0,0,'182/2021','MOHAMMAD BASHEER'),(3417,49,'2023-01-27 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',5000,5062,0,0,84,5000,4978,0,0,'182/2021','MOHAMMAD BASHEER'),(3418,46,'2023-01-27 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,981002,0,0,168,0,980834,0,0,'182/2021','MOHAMMAD BASHEER'),(3419,11,'2023-02-03 00:00:00','M11','SODIUM VALPROATE ORAL SOLUTION 200ML','Transfer','Sub to OP',0,2972,0,0,56,0,2916,0,0,'58/2021','SUMAYYA'),(3420,50,'2023-02-03 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,1659,0,0,28,0,1631,0,0,'58/2021','SUMAYYA'),(3421,47,'2023-02-03 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1101,0,0,28,0,1073,0,0,'58/2021','SUMAYYA'),(3422,92,'2023-02-03 00:00:00','M92','RISPERIDONE ORAL SOLUTION BP 1MG/ML','Transfer','Sub to OP',0,2928,0,0,1,0,2927,0,0,'231/2021','MUHAMMAD IQBAL'),(3423,49,'2023-02-03 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',5000,4978,0,0,11,5000,4967,0,0,'231/2021','MUHAMMAD IQBAL'),(3424,82,'2023-02-03 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,990486,0,0,28,3000,990458,0,0,'134/2022','SABITHA '),(3425,83,'2023-02-03 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,990290,0,0,28,0,990262,0,0,'134/2022','SABITHA '),(3426,69,'2023-02-03 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,506,0,0,42,0,464,0,0,'134/2022','SABITHA '),(3427,19,'2023-02-03 00:00:00','M19','ARIPIPRAZOLE TABLETS 5MG','Transfer','Sub to OP',0,1778,0,0,28,0,1750,0,0,'07/2017','FATHIMMA'),(3428,38,'2023-02-03 00:00:00','M38','SERTRALINE HCL TABLETS 100MG','Transfer','Sub to OP',0,2428,0,0,56,0,2372,0,0,'07/2017','FATHIMMA'),(3429,49,'2023-02-03 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',5000,4967,0,0,28,5000,4939,0,0,'27/2017','FADALU (FAIZAL)'),(3430,20,'2023-02-03 00:00:00','M20','FLUOXETINE HCL CAPSULES 60MG','Transfer','Sub to OP',0,2454,0,0,28,0,2426,0,0,'27/2017','FADALU (FAIZAL)'),(3431,83,'2023-02-03 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,990262,0,0,28,0,990234,0,0,'203/2022','RASIYA BANU'),(3432,82,'2023-02-03 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,990458,0,0,14,3000,990444,0,0,'203/2022','RASIYA BANU'),(3433,68,'2023-02-03 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,732,0,0,14,0,718,0,0,'203/2022','RASIYA BANU'),(3434,69,'2023-02-03 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,464,0,0,14,0,450,0,0,'203/2022','RASIYA BANU'),(3435,3,'2023-02-03 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2657,0,0,14,0,2643,0,0,'203/2022','RASIYA BANU'),(3436,82,'2023-02-03 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,990444,0,0,28,3000,990416,0,0,'134/2022','SABITHA '),(3437,83,'2023-02-03 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,990234,0,0,28,0,990206,0,0,'134/2022','SABITHA '),(3438,69,'2023-02-03 00:00:00','M69','OLANZAPINE TABLETS 5MG','Transfer','Sub to OP',0,450,0,0,42,0,408,0,0,'134/2022','SABITHA '),(3439,83,'2023-02-03 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,990206,0,0,56,0,990150,0,0,'58/2021','SUMAYYA'),(3440,50,'2023-02-03 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,1631,0,0,28,0,1603,0,0,'58/2021','SUMAYYA'),(3441,47,'2023-02-03 00:00:00','M47','CLOZAPINE TABLETS 25MG','Transfer','Sub to OP',0,1073,0,0,28,0,1045,0,0,'58/2021','SUMAYYA'),(3442,46,'2023-02-03 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,980834,0,0,112,0,980722,0,0,'58/2021','SUMAYYA'),(3443,50,'2023-02-10 00:00:00','M50','CLOZAPINE TABLETS 200MG','Transfer','Sub to OP',0,1603,0,0,56,0,1547,0,0,'9/2018','RAFEENA'),(3444,49,'2023-02-10 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',5000,4939,0,0,56,5000,4883,0,0,'9/2018','RAFEENA'),(3445,46,'2023-02-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,980722,0,0,112,0,980610,0,0,'9/2018','RAFEENA'),(3446,34,'2023-02-10 00:00:00','M34','RISPERIDONE TABLETS 2MG','Transfer','Sub to OP',5100,4618,0,0,56,5100,4562,0,0,'9/2018','RAFEENA'),(3447,35,'2023-02-10 00:00:00','M35','RISPERIDONE TABLETS 3MG','Transfer','Sub to OP',0,990,0,0,56,0,934,0,0,'9/2018','RAFEENA'),(3448,6,'2023-02-10 00:00:00','M6','ESCITALOPRAM TABLETS 20MG','Transfer','Sub to OP',0,2888,0,0,84,0,2804,0,0,'04/2022','BIJU'),(3449,65,'2023-02-10 00:00:00','M65','MIRTAZAPINE TABLETS 15MG','Transfer','Sub to OP',0,2293,0,0,84,0,2209,0,0,'04/2022','BIJU'),(3450,3,'2023-02-10 00:00:00','M3','CLONAZEPAM TABLETS 0.25 MG','Transfer','Sub to OP',0,2643,0,0,84,0,2559,0,0,'04/2022','BIJU'),(3451,82,'2023-02-10 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,990416,0,0,14,3000,990402,0,0,'54/2017','PUSHPAVATHI'),(3452,83,'2023-02-10 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,990150,0,0,14,0,990136,0,0,'54/2017','PUSHPAVATHI'),(3453,68,'2023-02-10 00:00:00','M68','OLANZAPINE TABLETS 10MG','Transfer','Sub to OP',0,718,0,0,14,0,704,0,0,'54/2017','PUSHPAVATHI'),(3454,46,'2023-02-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,980610,0,0,14,0,980596,0,0,'54/2017','PUSHPAVATHI'),(3455,8,'2023-02-10 00:00:00','M8','AMISULPRIDE TABLETS 50MG','Transfer','Sub to OP',0,2646,0,0,14,0,2632,0,0,'54/2017','PUSHPAVATHI'),(3456,70,'2023-02-10 00:00:00','M70','QUETIAPINE TABLETS 25MG','Transfer','Sub to OP',0,17631,0,0,84,0,17547,0,0,'89/2018','MUHAMMAD'),(3457,24,'2023-02-10 00:00:00','M24','GABAPENTIN TABLETS 100MG','Transfer','Sub to OP',0,2748,0,0,84,0,2664,0,0,'89/2018','MUHAMMAD'),(3458,58,'2023-02-10 00:00:00','M58','CARBAMAZEPINE EXTENDED-RELEASE TABLETS 300MG','Transfer','Sub to OP',0,2048,0,0,168,0,1880,0,0,'89/2018','MUHAMMAD'),(3459,82,'2023-02-10 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,990402,0,0,21,3000,990381,0,0,'36/2020','UMMUHABEEBA'),(3460,83,'2023-02-10 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,990136,0,0,21,0,990115,0,0,'36/2020','UMMUHABEEBA'),(3461,46,'2023-02-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,980596,0,0,14,0,980582,0,0,'36/2020','UMMUHABEEBA'),(3462,48,'2023-02-10 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',5000,431,0,0,14,5000,417,0,0,'36/2020','UMMUHABEEBA'),(3463,83,'2023-02-10 00:00:00','M83','SV 500MG','Transfer','Sub to OP',0,990115,0,0,28,0,990087,0,0,'182/2021','MOHAMMAD BASHEER'),(3464,71,'2023-02-10 00:00:00','M71','QUETIAPINE TABLETS 50MG','Transfer','Sub to OP',0,8233,0,0,14,0,8219,0,0,'182/2021','MOHAMMAD BASHEER'),(3465,82,'2023-02-10 00:00:00','M82','SV 200MG','Transfer','Sub to OP',3000,990381,0,0,14,3000,990367,0,0,'182/2021','MOHAMMAD BASHEER'),(3466,26,'2023-02-10 00:00:00','M26','HALOPERIDOL TABLETS 10MG','Transfer','Sub to OP',0,2174,0,0,28,0,2146,0,0,'182/2021','MOHAMMAD BASHEER'),(3467,49,'2023-02-10 00:00:00','M49','CLOZAPINE TABLETS 100MG','Transfer','Sub to OP',5000,4883,0,0,14,5000,4869,0,0,'182/2021','MOHAMMAD BASHEER'),(3468,48,'2023-02-10 00:00:00','M48','CLOZAPINE TABLETS 50MG','Transfer','Sub to OP',5000,417,0,0,14,5000,403,0,0,'182/2021','MOHAMMAD BASHEER'),(3469,46,'2023-02-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,980582,0,0,42,0,980540,0,0,'182/2021','MOHAMMAD BASHEER'),(3470,32,'2023-02-10 00:00:00','M32','RISPERIDONE & TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,2972,0,0,14,0,2958,0,0,'237/2022','RAHMATHUNNEESA'),(3471,46,'2023-02-10 00:00:00','M46','TRIHEXYPHENIDYL HCL TABLETS 2MG','Transfer','Sub to OP',0,980540,0,0,14,0,980526,0,0,'237/2022','RAHMATHUNNEESA'),(3472,81,'2023-02-10 00:00:00','M81','SV 300MG','Transfer','Sub to OP',0,998006,0,0,28,0,997978,0,0,'83/2019','FARSANA THASNI'),(3473,84,'2023-02-10 00:00:00','M84','LEVETIRACETAM TABLETS 500 MG','Transfer','Sub to OP',0,1866,0,0,28,0,1838,0,0,'83/2019','FARSANA THASNI');
/*!40000 ALTER TABLE `medicinehistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicinepurchase`
--

DROP TABLE IF EXISTS `medicinepurchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicinepurchase` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `MedicineId` int NOT NULL,
  `invdate` datetime DEFAULT NULL,
  `invno` varchar(45) DEFAULT NULL,
  `batchno` varchar(45) DEFAULT NULL,
  `expdate` datetime NOT NULL,
  `mfgdate` datetime DEFAULT NULL,
  `rate` decimal(10,2) DEFAULT NULL,
  `dealer` varchar(100) DEFAULT NULL,
  `mainStock` int DEFAULT NULL,
  `subStock` int DEFAULT NULL,
  `return` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicinepurchase`
--

LOCK TABLES `medicinepurchase` WRITE;
/*!40000 ALTER TABLE `medicinepurchase` DISABLE KEYS */;
INSERT INTO `medicinepurchase` VALUES (1,1,'2021-03-22 00:00:00','2000073007727','3781-A','2022-05-01 00:00:00',NULL,170.00,'ILA FOUNDATION',0,0,0),(2,2,'2021-03-01 00:00:00','2100007300672','123','2022-07-11 00:00:00',NULL,170.00,'ILA FOUNDATION',0,0,0),(3,3,'2021-03-01 00:00:00','T6RT66','RWF7EH','2022-03-11 00:00:00',NULL,170.00,'ILA FOUNDATION',0,2559,0),(4,4,'2021-03-04 00:00:00','2000073007727','26848','2023-01-01 00:00:00',NULL,46.00,'ILA FOUNDATION',0,2685,0),(5,5,'2021-03-04 00:00:00','2000073007727','27105','2022-09-01 00:00:00',NULL,85.00,'ILA FOUNDATION',0,1936,0),(6,6,'2021-03-04 00:00:00','2000073007727','26500','2022-02-01 00:00:00',NULL,119.00,'ILA FOUNDATION',0,2804,0),(7,7,'2021-03-04 00:00:00','2000073007727','BRA06075B','2022-05-01 00:00:00',NULL,417.00,'ILA FOUNDATION',0,3000,0),(8,8,'2021-03-04 00:00:00','2000073007727','26927','2023-03-01 00:00:00',NULL,72.00,'ILA FOUNDATION',0,2632,0),(9,9,'2021-03-04 00:00:00','2000073007727','PWZMH02','2022-03-01 00:00:00',NULL,750.00,'ILA FOUNDATION',0,2114,0),(10,10,'2021-03-04 00:00:00','2000073007727','26767','2022-10-01 00:00:00',NULL,233.00,'ILA FOUNDATION',0,2916,0),(11,11,'2021-03-04 00:00:00','2000073007727','L-682','2022-10-01 00:00:00',NULL,129.00,'ILA FOUNDATION',0,2916,0),(12,12,'2021-03-04 00:00:00','2000073007727','26845','2023-01-01 00:00:00',NULL,40.00,'ILA FOUNDATION',0,1936,0),(13,13,'2021-03-04 00:00:00','2000073007727','K2100563','2023-02-01 00:00:00',NULL,162.00,'ILA FOUNDATION',0,3000,0),(14,14,'2021-03-04 00:00:00','2000073007727','26838','2022-12-01 00:00:00',NULL,242.00,'ILA FOUNDATION',0,3000,0),(15,15,'2021-03-01 00:00:00','2000073007727','PWZDC04','2023-01-01 00:00:00',NULL,90.00,'ILA FOUNDATION',0,3000,0),(16,16,'2021-03-01 00:00:00','2000073007727','MOT20397','2022-07-01 00:00:00',NULL,0.00,'ILA FOUNDATION',0,0,0),(17,17,'2021-03-01 00:00:00','2000073007727','26975','2023-05-01 00:00:00',NULL,25.00,'ILA FOUNDATION',0,3000,0),(18,18,'2021-03-04 00:00:00','2000073007727','T.20801','2022-11-01 00:00:00',NULL,89.00,'ILA FOUNDATION',0,3000,0),(19,19,'2021-03-04 00:00:00','2000073007727','3663-A','2022-04-01 00:00:00',NULL,45.00,'ILA FOUNDATION',0,1750,0),(20,20,'2021-03-01 00:00:00','2000073007727','IKC-100','2022-09-01 00:00:00',NULL,95.00,'ILA FOUNDATION',0,2426,0),(21,21,'2021-03-01 00:00:00','2000073007727','IKC-120','2023-01-01 00:00:00',NULL,58.00,'ILA FOUNDATION',0,1801,0),(22,22,'2021-03-04 00:00:00','2000073007727','26976','2023-05-01 00:00:00',NULL,39.00,'ILA FOUNDATION',0,1887,0),(23,23,'2021-03-04 00:00:00','2000073007727','GTC0550A','2023-05-01 00:00:00',NULL,33.32,'ILA FOUNDATION',0,2916,0),(24,24,'2021-03-04 00:00:00','2000073007727','T 20798','2023-05-31 00:00:00',NULL,64.00,'ILA FOUNDATION',0,2664,0),(25,25,'2021-03-04 00:00:00','2000073007727','26943','2023-04-01 00:00:00',NULL,38.00,'ILA FOUNDATION',0,2230,0),(26,26,'2021-03-04 00:00:00','2000073007727','27017','2023-05-31 00:00:00',NULL,49.00,'ILA FOUNDATION',0,2146,0),(27,27,'2021-03-04 00:00:00','2000073007727','DRA05220D','2023-04-01 00:00:00',NULL,120.00,'ILA FOUNDATION',0,2734,0),(28,28,'2021-03-04 00:00:00','2000073007727','4254','2022-10-01 00:00:00',NULL,45.00,'ILA FOUNDATION',0,1269,0),(29,29,'2021-03-04 00:00:00','2000073007727','26788','2022-11-01 00:00:00',NULL,16.30,'ILA FOUNDATION',0,1369,0),(30,30,'2021-03-04 00:00:00','2000073007727','ST-13637','2022-08-01 00:00:00',NULL,75.00,'ILA FOUNDATION',0,2951,0),(31,31,'2021-03-04 00:00:00','2000076007727','26793','2022-11-01 00:00:00',NULL,56.00,'ILA FOUNDATION',0,2685,0),(32,32,'2021-03-04 00:00:00','2000073007727','26858','2023-01-01 00:00:00',NULL,45.00,'ILA FOUNDATION',0,2958,0),(33,33,'2021-03-04 00:00:00','2000073007727','26828','2022-12-01 00:00:00',NULL,24.00,'ILA FOUNDATION',0,757,0),(34,34,'2021-03-04 00:00:00','2000073007727','26935','2023-03-01 00:00:00',NULL,39.50,'ILA FOUNDATION',0,0,0),(35,35,'2021-03-04 00:00:00','2000073007727','26889','2023-02-01 00:00:00',NULL,49.00,'ILA FOUNDATION',0,934,0),(36,36,'2021-03-04 00:00:00','2000073007727','27139','2023-05-31 00:00:00',NULL,75.00,'ILA FOUNDATION',0,86,0),(37,37,'2021-03-04 00:00:00','2000073007727','T-21011','2023-05-31 00:00:00',NULL,16.49,'ILA FOUNDATION',0,999888,0),(38,38,'2021-03-04 00:00:00','2000073007727','26868','2023-01-01 00:00:00',NULL,107.00,'ILA FOUNDATION',0,2372,0),(39,39,'2021-03-04 00:00:00','2000073007727','26869','2023-01-01 00:00:00',NULL,69.00,'ILA FOUNDATION',0,2251,0),(40,40,'2021-03-04 00:00:00','2000073007727','26722','2022-09-01 00:00:00',NULL,40.00,'ILA FOUNDATION',0,2130,0),(41,41,'2021-03-04 00:00:00','2000073007727','GTC0210A','2023-01-01 00:00:00',NULL,56.00,'ILA FOUNDATION',0,3000,0),(42,42,'2021-03-04 00:00:00','2000073007727','26574','2021-10-01 00:00:00',NULL,49.50,'ILA FOUNDATION',0,3000,0),(43,43,'2021-03-04 00:00:00','2000073007727','26855','2022-07-01 00:00:00',NULL,84.50,'ILA FOUNDATION',0,2498,0),(44,44,'2021-03-04 00:00:00','2000073007727','3229','2022-01-01 00:00:00',NULL,110.00,'ILA FOUNDATION',0,2288,0),(45,45,'2021-03-04 00:00:00','2000073007727','T 19606','2022-10-01 00:00:00',NULL,46.20,'ILA FOUNDATION',0,2139,0),(46,46,'2021-03-04 00:00:00','2000073007727','27081','2023-05-31 00:00:00',NULL,13.50,'ILA FOUNDATION',0,980526,0),(47,47,'2021-03-04 00:00:00','2000073007727','27005','2023-05-01 00:00:00',NULL,28.00,'ILA FOUNDATION',0,1045,0),(48,48,'2021-03-04 00:00:00','2000073007727','27060','2023-05-31 00:00:00',NULL,53.00,'ILA FOUNDATION',0,403,0),(49,49,'2021-03-04 00:00:00','2000073007727','26846','2023-01-01 00:00:00',NULL,86.00,'ILA FOUNDATION',0,0,0),(50,50,'2021-03-04 00:00:00','2000073007727','4338','2022-11-01 00:00:00',NULL,170.00,'ILA FOUNDATION',0,1547,0),(51,51,'2021-03-04 00:00:00','2000073007727','26881','2023-02-01 00:00:00',NULL,119.00,'ILA FOUNDATION',0,3000,0),(52,52,'2021-03-04 00:00:00','2000073007727','26577','2022-05-01 00:00:00',NULL,159.00,'ILA FOUNDATION',0,3000,0),(53,53,'2021-03-04 00:00:00','2000073007727','26447','2022-01-01 00:00:00',NULL,43.00,'ILA FOUNDATION',0,3000,0),(54,54,'2021-03-04 00:00:00','2000073007727','26779','2022-11-01 00:00:00',NULL,119.00,'ILA FOUNDATION',0,3000,0),(55,55,'2021-03-04 00:00:00','2000073007727','26990','2023-05-01 00:00:00',NULL,85.00,'ILA FOUNDATION',0,3000,0),(56,56,'2021-03-04 00:00:00','2000073007727','26963','2023-04-01 00:00:00',NULL,61.90,'ILA FOUNDATION',0,2616,0),(57,57,'2021-03-04 00:00:00','2000073007727','27036','2022-12-01 00:00:00',NULL,34.10,'ILA FOUNDATION',0,2888,0),(58,58,'2021-03-04 00:00:00','2000073007727','27058','2023-01-01 00:00:00',NULL,41.40,'ILA FOUNDATION',0,1880,0),(59,59,'2021-03-04 00:00:00','2000073007727','27059','2023-01-01 00:00:00',NULL,10.40,'ILA FOUNDATION',0,2776,0),(60,60,'2021-03-04 00:00:00','2000073007727','ST-91470','2022-02-01 00:00:00',NULL,139.00,'ILA FOUNDATION',0,3000,0),(61,61,'2021-03-04 00:00:00','2000073007727','ST-10989','2022-06-01 00:00:00',NULL,90.00,'ILA FOUNDATION',0,3000,0),(62,62,'2021-03-04 00:00:00','2000073007727','4427','2023-05-01 00:00:00',NULL,40.00,'ILA  FOUNDATION',0,3000,0),(63,63,'2021-03-04 00:00:00','2000073007727','GKCO443A','2023-02-01 00:00:00',NULL,136.00,'ILA FOUNDATION',0,2993,0),(64,64,'2021-03-04 00:00:00','2000073007727','T 20613','2023-05-31 00:00:00',NULL,53.00,'ILA FOUNDATION',0,2790,0),(65,65,'2021-03-04 00:00:00','2000073007727','T 20444','2023-01-01 00:00:00',NULL,84.00,'ILA FOUNDATION',0,2209,0),(66,66,'2021-03-04 00:00:00','2000073007727','26780','2022-11-01 00:00:00',NULL,38.50,'ILA FOUNDATION',0,3000,0),(67,67,'2021-03-04 00:00:00','2000073007727','26966','2023-04-01 00:00:00',NULL,21.50,'ILA FOUNDATION',0,1696,0),(68,68,'2021-03-04 00:00:00','2000073007727','27048','2023-05-31 00:00:00',NULL,35.00,'ILA FOUNDATION',0,704,0),(69,69,'2021-03-04 00:00:00','2000073007727','27048','2023-05-31 00:00:00',NULL,35.00,'ILA FOUNDATION',0,408,0),(70,70,'2021-03-04 00:00:00','2000073007727','27000','2023-05-01 00:00:00',NULL,41.31,'ILA FOUNDATION',0,17547,0),(71,71,'2021-03-04 00:00:00','2000073007727','PWZND03','2023-01-01 00:00:00',NULL,32.00,'ILA FOUNDATION',0,8219,0),(72,72,'2021-03-04 00:00:00','2000073007727','PA2AG02','2021-08-01 00:00:00',NULL,85.00,'ILA FOUNDATION',0,2685,0),(73,73,'2021-03-04 00:00:00','2000073007727','26866','2023-01-01 00:00:00',NULL,126.50,'ILA FOUNDATION',0,2923,0),(74,74,'2021-03-04 00:00:00','2000073007727','N2001033','2022-12-01 00:00:00',NULL,109.00,'ILA FOUNDATION',0,3000,0),(75,75,'2021-03-04 00:00:00','2000073007727','PWZAL03','2022-05-01 00:00:00',NULL,200.00,'ILA FOUNDATION',0,2867,0),(76,76,'2021-03-04 00:00:00','2000073007727','26789','2022-11-01 00:00:00',NULL,18.85,'ILA FOUNDATION',0,1376,0),(77,77,'2021-03-04 00:00:00','2000073007727','26997','2023-05-01 00:00:00',NULL,13.65,'ILA FOUNDATION',0,3000,0),(78,78,'2021-03-04 00:00:00','2000073007727','27033','2023-01-01 00:00:00',NULL,17.35,'ILA FOUNDATION',0,3000,0),(79,79,'2021-03-04 00:00:00','2000073007727','GDB8007','2021-09-01 00:00:00',NULL,55.59,'ILA FOUNDATION',0,2748,0),(80,80,'2021-03-04 00:00:00','200007300727','26669','2022-07-01 00:00:00',NULL,71.00,'ILA FOUNDATION',0,3000,0),(81,81,'2021-03-04 00:00:00','2000073007727','27044','2021-08-01 00:00:00',NULL,68.00,'ILA FOUNDATION',0,997978,0),(82,82,'2021-03-04 00:00:00','2000073007727','27043','2023-01-01 00:00:00',NULL,52.80,'ILA FOUNDATION',0,990367,0),(83,83,'2021-03-04 00:00:00','2000073007727','PWZDR03','2023-04-01 00:00:00',NULL,61.00,'ILA FOUNDATION',0,990087,0),(84,84,'2021-03-04 00:00:00','2000073007727','27029','2023-05-01 00:00:00',NULL,130.90,'ILA FOUNDATION',0,1838,0),(85,85,'2021-03-04 00:00:00','2000073007727','26992','2023-05-01 00:00:00',NULL,65.00,'ILA FOUNDATION',0,2706,0),(86,86,'2021-03-04 00:00:00','2000073007727','26998','2023-05-01 00:00:00',NULL,96.00,'ILA FOUNDATION',0,2370,0),(87,87,'2021-03-04 00:00:00','2000073007727','26720','2022-09-01 00:00:00',NULL,54.00,'ILA FOUNDATION',0,2422,0),(88,88,'2021-03-04 00:00:00','2000073007727','13019','2022-09-01 00:00:00',NULL,57.00,'ILA FOUNDATION',0,2958,0),(89,89,'2021-03-04 00:00:00','2000073007727','13105','2022-10-01 00:00:00',NULL,34.50,'ILA FOUNDATION',0,2554,0),(90,90,'2021-03-04 00:00:00','2000073007727','27045','2023-07-01 00:00:00',NULL,23.00,'ILA FOUNDATION',0,2937,0),(91,91,'2021-03-04 00:00:00','2000073007727','26957','2023-04-01 00:00:00',NULL,28.00,'ILA FOUNDATION',0,2979,0),(92,92,'2021-03-04 00:00:00','2000073007727','A60045','2022-11-01 00:00:00',NULL,126.05,'ILA FOUNDATION',0,2927,0),(93,93,'2021-04-23 00:00:00','','120032','2022-09-01 00:00:00','2020-10-01 00:00:00',52.50,'ILA FOUNDATION',0,2988,0),(94,94,'2021-04-23 00:00:00','','DTG25T-003','2021-09-23 00:00:00','2019-10-23 00:00:00',72.00,'ILA FOUDATION',0,3000,0),(95,95,'2021-04-23 00:00:00','','SER-504','2022-02-01 00:00:00','2019-10-23 00:00:00',120.90,'ILA FOUNDATION',0,2796,0),(96,96,NULL,'12545','67265W','2023-04-28 00:00:00','2020-08-29 00:00:00',0.00,'',10000000,0,0),(97,82,'2022-04-28 00:00:00',NULL,NULL,'2023-08-31 00:00:00','2021-09-21 00:00:00',0.00,NULL,3000,0,0),(98,34,NULL,NULL,NULL,'2024-09-30 00:00:00','2022-04-30 00:00:00',0.00,NULL,0,0,0),(99,48,NULL,NULL,NULL,'2024-12-06 00:00:00','2022-07-31 00:00:00',0.00,NULL,5000,0,0),(100,49,'2022-12-21 00:00:00',NULL,NULL,'2024-09-30 00:00:00','2022-04-30 00:00:00',96.00,NULL,5000,4869,0),(101,34,NULL,'','','2024-09-30 00:00:00','2022-04-30 00:00:00',55.00,'',5000,4462,0),(102,34,'2022-11-02 00:00:00',NULL,NULL,'2024-09-30 00:00:00','2022-03-30 00:00:00',0.00,NULL,100,100,0);
/*!40000 ALTER TABLE `medicinepurchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicinesale`
--

DROP TABLE IF EXISTS `medicinesale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicinesale` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `MedicineId` int DEFAULT NULL,
  `Pno` varchar(50) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Rate` decimal(10,2) DEFAULT NULL,
  `Qty` int DEFAULT NULL,
  `MedicinePurchaseId` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2883 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicinesale`
--

LOCK TABLES `medicinesale` WRITE;
/*!40000 ALTER TABLE `medicinesale` DISABLE KEYS */;
INSERT INTO `medicinesale` VALUES (10,12,'112/2017','2021-10-01 00:00:00',40.00,28,12),(11,34,'112/2017','2021-10-01 00:00:00',39.50,28,34),(12,46,'112/2017','2021-10-01 00:00:00',13.50,28,46),(13,9,'112/2017','2021-10-22 00:00:00',750.00,28,9),(14,35,'144/2019','2021-09-03 00:00:00',49.00,42,35),(15,46,'144/2019','2021-09-03 00:00:00',13.50,42,46),(16,5,'202/2021','2021-10-22 00:00:00',85.00,28,5),(17,3,'202/2021','2021-10-22 00:00:00',170.00,5,3),(18,21,'77/2017','2021-10-22 00:00:00',58.00,28,21),(19,69,'77/2017','2021-10-22 00:00:00',35.00,28,69),(20,23,'77/2017','2021-10-22 00:00:00',33.32,56,23),(21,93,'196/2021','2021-10-22 00:00:00',52.50,1,93),(22,35,'196/2021','2021-10-22 00:00:00',49.00,14,35),(23,38,'105/2014','2021-10-22 00:00:00',107.00,28,38),(24,39,'105/2014','2021-10-22 00:00:00',69.00,28,39),(25,4,'105/2014','2021-10-22 00:00:00',46.00,28,4),(26,71,'49/2017','2021-10-22 00:00:00',32.00,56,71),(27,70,'49/2017','2021-10-22 00:00:00',41.31,56,70),(28,83,'137/2017','2021-10-22 00:00:00',61.00,168,83),(29,73,'137/2017','2021-10-22 00:00:00',126.50,84,73),(30,46,'137/2017','2021-10-22 00:00:00',13.50,256,46),(31,48,'48/2017','2021-09-24 00:00:00',53.00,42,48),(32,47,'48/2017','2021-09-24 00:00:00',28.00,42,47),(33,71,'48/2017','2021-09-24 00:00:00',32.00,42,71),(34,46,'48/2017','2021-09-24 00:00:00',13.50,84,46),(35,34,'48/2017','2021-09-24 00:00:00',39.50,84,34),(36,12,'161/2019','2021-10-22 00:00:00',40.00,42,12),(37,44,'161/2019','2021-10-22 00:00:00',110.00,84,44),(38,65,'161/2019','2021-10-22 00:00:00',84.00,84,65),(39,50,'231/2021','2021-10-15 00:00:00',170.00,14,50),(40,48,'231/2021','2021-10-15 00:00:00',53.00,5,48),(41,81,'232/2021','2021-10-15 00:00:00',68.00,14,81),(42,83,'232/2021','2021-10-15 00:00:00',61.00,14,83),(43,70,'232/2021','2021-10-15 00:00:00',41.31,14,70),(44,46,'232/2021','2021-10-15 00:00:00',13.50,28,46),(45,36,'232/2021','2021-10-15 00:00:00',75.00,14,36),(46,76,'232/2021','2021-10-15 00:00:00',18.85,14,76),(47,65,'205/2021','2021-10-01 00:00:00',84.00,56,65),(48,70,'205/2021','2021-10-01 00:00:00',41.31,14,70),(49,89,'205/2021','2021-10-01 00:00:00',34.50,14,89),(50,57,'206/2021','2021-10-08 00:00:00',34.10,42,57),(51,34,'206/2021','2021-10-08 00:00:00',39.50,32,34),(52,33,'0112/2017','2021-09-17 00:00:00',24.00,21,33),(53,82,'135/2018','2021-09-03 00:00:00',52.80,56,82),(54,83,'135/2018','2021-09-03 00:00:00',61.00,56,83),(55,84,'135/2018','2021-09-03 00:00:00',130.90,112,84),(56,69,'135/2018','2021-09-03 00:00:00',35.00,56,69),(57,67,'135/2018','2021-09-03 00:00:00',21.50,56,67),(58,69,'16/2021','2021-09-10 00:00:00',35.00,49,69),(59,67,'16/2021','2021-09-10 00:00:00',21.50,49,67),(60,83,'16/2021','2021-09-10 00:00:00',61.00,49,83),(61,82,'16/2021','2021-09-10 00:00:00',52.80,49,82),(62,46,'16/2021','2021-09-10 00:00:00',13.50,49,46),(63,69,'135/2020','2021-09-17 00:00:00',35.00,42,69),(64,12,'135/2020','2021-09-17 00:00:00',40.00,42,12),(65,82,'135/2020','2021-09-17 00:00:00',52.80,84,82),(66,35,'088/2017','2021-09-17 00:00:00',49.00,74,35),(67,34,'088/2017','2021-09-17 00:00:00',39.50,10,34),(68,33,'088/2017','2021-09-17 00:00:00',24.00,32,33),(69,46,'088/2017','2021-09-17 00:00:00',13.50,42,46),(70,49,'88/2017','2021-09-17 00:00:00',86.00,42,49),(71,47,'88/2017','2021-09-17 00:00:00',28.00,42,47),(72,9,'88/2017','2021-09-17 00:00:00',750.00,42,9),(73,46,'88/2017','2021-09-17 00:00:00',13.50,42,46),(74,83,'26/2017','2021-09-03 00:00:00',61.00,56,83),(75,49,'99/2019','2021-08-20 00:00:00',86.00,70,49),(76,48,'99/2019','2021-08-20 00:00:00',53.00,70,48),(77,6,'99/2019','2021-08-20 00:00:00',119.00,70,6),(78,59,'89/2018','2021-08-27 00:00:00',10.40,73,59),(79,58,'89/2018','2021-08-27 00:00:00',41.40,73,58),(80,71,'89/2018','2021-08-27 00:00:00',32.00,73,71),(81,70,'89/2018','2021-08-27 00:00:00',41.31,70,70),(82,24,'89/2018','2021-08-27 00:00:00',64.00,73,24),(83,6,'14/2021','2021-09-03 00:00:00',119.00,56,6),(84,81,'83/2019','2021-09-03 00:00:00',68.00,112,81),(85,84,'83/2019','2021-09-03 00:00:00',130.90,112,84),(86,59,'83/2019','2021-09-03 00:00:00',10.40,56,59),(87,57,'83/2019','2021-09-03 00:00:00',34.10,56,57),(88,83,'01/2018','2021-09-03 00:00:00',61.00,112,83),(89,50,'01/2018','2021-09-03 00:00:00',170.00,56,50),(90,48,'01/2018','2021-09-03 00:00:00',53.00,56,48),(91,68,'01/2018','2021-09-03 00:00:00',35.00,56,68),(92,69,'01/2018','2021-09-03 00:00:00',35.00,23,69),(93,22,'01/2018','2021-09-03 00:00:00',39.00,56,22),(94,81,'232/2021','2021-10-29 00:00:00',68.00,28,81),(95,83,'232/2021','2021-10-29 00:00:00',61.00,28,83),(96,46,'232/2021','2021-10-29 00:00:00',13.50,84,46),(97,36,'232/2021','2021-10-29 00:00:00',75.00,28,36),(98,76,'232/2021','2021-10-29 00:00:00',18.85,28,76),(99,83,'247/2021','2021-10-29 00:00:00',61.00,14,83),(100,68,'247/2021','2021-10-29 00:00:00',35.00,7,68),(101,21,'247/2021','2021-10-29 00:00:00',58.00,7,21),(102,46,'247/2021','2021-10-29 00:00:00',13.50,7,46),(103,35,'088/2017','2021-10-29 00:00:00',49.00,14,35),(104,33,'088/2017','2021-10-29 00:00:00',24.00,7,33),(105,46,'088/2017','2021-10-29 00:00:00',13.50,7,46),(106,65,'205/2021','2021-10-29 00:00:00',84.00,84,65),(107,70,'205/2021','2021-10-29 00:00:00',41.31,21,70),(108,35,'088/2017','2021-10-29 00:00:00',49.00,98,35),(109,33,'088/2017','2021-10-29 00:00:00',24.00,49,33),(110,46,'088/2017','2021-10-29 00:00:00',13.50,49,46),(111,49,'88/2017','2021-10-29 00:00:00',86.00,56,49),(112,47,'88/2017','2021-10-29 00:00:00',28.00,56,47),(113,9,'88/2017','2021-10-29 00:00:00',750.00,56,9),(114,46,'88/2017','2021-10-29 00:00:00',13.50,56,46),(115,81,'83/2019','2021-10-29 00:00:00',68.00,112,81),(116,84,'83/2019','2021-10-29 00:00:00',130.90,112,84),(117,59,'83/2019','2021-10-29 00:00:00',10.40,56,59),(118,83,'135/2018','2021-10-29 00:00:00',61.00,56,83),(119,82,'135/2018','2021-10-29 00:00:00',52.80,56,82),(120,84,'135/2018','2021-10-29 00:00:00',130.90,112,84),(121,69,'135/2018','2021-10-29 00:00:00',35.00,56,69),(122,67,'135/2018','2021-10-29 00:00:00',21.50,56,67),(123,76,'135/2018','2021-10-29 00:00:00',18.85,112,76),(124,46,'135/2018','2021-10-29 00:00:00',13.50,56,46),(125,49,'99/2019','2021-10-29 00:00:00',86.00,84,49),(126,48,'99/2019','2021-10-29 00:00:00',53.00,84,48),(127,6,'99/2019','2021-10-29 00:00:00',119.00,84,6),(128,5,'99/2019','2021-10-29 00:00:00',85.00,84,5),(129,57,'206/2021','2021-10-29 00:00:00',34.10,56,57),(130,33,'206/2021','2021-10-29 00:00:00',24.00,56,33),(131,47,'27/2017','2021-10-29 00:00:00',28.00,56,47),(132,48,'27/2017','2021-10-29 00:00:00',53.00,56,48),(133,20,'27/2017','2021-10-29 00:00:00',95.00,56,20),(134,69,'16/2021','2021-10-29 00:00:00',35.00,56,69),(135,67,'16/2021','2021-10-29 00:00:00',21.50,56,67),(136,83,'16/2021','2021-10-29 00:00:00',61.00,56,83),(137,82,'16/2021','2021-10-29 00:00:00',52.80,56,82),(138,46,'16/2021','2021-10-29 00:00:00',13.50,56,46),(139,83,'01/2018','2021-10-29 00:00:00',61.00,112,83),(140,50,'01/2018','2021-10-29 00:00:00',170.00,56,50),(141,48,'01/2018','2021-10-29 00:00:00',53.00,56,48),(142,68,'01/2018','2021-10-29 00:00:00',35.00,56,68),(143,67,'01/2018','2021-10-29 00:00:00',21.50,56,67),(144,12,'01/2018','2021-10-29 00:00:00',40.00,56,12),(145,35,'134/2020','2021-10-22 00:00:00',49.00,56,35),(146,46,'134/2020','2021-10-22 00:00:00',13.50,84,46),(147,83,'134/2020','2021-10-22 00:00:00',61.00,56,83),(148,70,'134/2020','2021-10-22 00:00:00',41.31,28,70),(149,71,'134/2020','2021-10-22 00:00:00',32.00,28,71),(150,83,'137/2017','2021-10-22 00:00:00',61.00,156,83),(151,26,'137/2017','2021-10-22 00:00:00',49.00,117,26),(152,73,'137/2017','2021-10-22 00:00:00',126.50,78,73),(153,46,'137/2017','2021-10-22 00:00:00',13.50,234,46),(154,73,'182/2021','2021-10-01 00:00:00',126.50,42,73),(155,72,'182/2021','2021-10-01 00:00:00',85.00,42,72),(156,46,'182/2021','2021-10-01 00:00:00',13.50,126,46),(157,83,'182/2021','2021-10-01 00:00:00',61.00,84,83),(158,25,'182/2021','2021-10-01 00:00:00',38.00,42,25),(159,26,'182/2021','2021-10-01 00:00:00',49.00,42,26),(160,48,'182/2021','2021-10-01 00:00:00',53.00,42,48),(161,12,'112/2017','2021-10-01 00:00:00',40.00,56,12),(162,34,'112/2017','2021-10-01 00:00:00',39.50,56,34),(163,46,'112/2017','2021-10-01 00:00:00',13.50,56,46),(164,9,'112/2017','2021-10-01 00:00:00',750.00,56,9),(165,83,'58/2021','2021-10-01 00:00:00',61.00,112,83),(166,50,'58/2021','2021-10-01 00:00:00',170.00,56,50),(167,48,'58/2021','2021-10-01 00:00:00',53.00,56,48),(168,46,'58/2021','2021-10-01 00:00:00',13.50,56,46),(169,83,'059/2021','2021-09-10 00:00:00',61.00,112,83),(170,70,'059/2021','2021-09-10 00:00:00',41.31,56,70),(171,49,'137/2020','2021-09-10 00:00:00',86.00,112,49),(172,48,'137/2020','2021-09-10 00:00:00',53.00,56,48),(173,36,'137/2020','2021-09-10 00:00:00',75.00,56,36),(174,46,'137/2020','2021-09-10 00:00:00',13.50,56,46),(175,82,'137/2020','2021-09-10 00:00:00',52.80,56,82),(176,83,'137/2020','2021-09-10 00:00:00',61.00,56,83),(177,36,'36/2020','2021-10-01 00:00:00',75.00,28,36),(178,33,'36/2020','2021-10-01 00:00:00',24.00,28,33),(179,49,'36/2020','2021-10-01 00:00:00',86.00,56,49),(180,46,'36/2020','2021-10-01 00:00:00',13.50,56,46),(181,11,'36/2020','2021-10-01 00:00:00',129.00,1,11),(182,83,'38/2017','2021-10-22 00:00:00',61.00,28,83),(183,82,'38/2017','2021-10-22 00:00:00',52.80,14,82),(184,26,'38/2017','2021-10-22 00:00:00',49.00,28,26),(185,46,'38/2017','2021-10-22 00:00:00',13.50,42,46),(186,49,'38/2017','2021-10-22 00:00:00',86.00,14,49),(187,48,'38/2017','2021-10-22 00:00:00',53.00,28,48),(188,83,'93/2017','2021-10-01 00:00:00',61.00,70,83),(189,35,'93/2017','2021-10-01 00:00:00',49.00,35,35),(190,48,'93/2017','2021-10-01 00:00:00',53.00,35,48),(191,50,'93/2017','2021-10-01 00:00:00',170.00,35,50),(192,46,'93/2017','2021-10-01 00:00:00',13.50,105,46),(193,82,'06/2018','2021-09-24 00:00:00',52.80,42,82),(194,83,'06/2018','2021-09-24 00:00:00',61.00,42,83),(195,36,'06/2018','2021-09-24 00:00:00',75.00,84,36),(196,46,'06/2018','2021-09-24 00:00:00',13.50,126,46),(197,48,'48/2017','2021-09-24 00:00:00',53.00,42,48),(198,47,'48/2017','2021-09-24 00:00:00',28.00,42,47),(199,71,'48/2017','2021-09-24 00:00:00',32.00,42,71),(200,46,'48/2017','2021-09-24 00:00:00',13.50,126,46),(201,34,'48/2017','2021-09-24 00:00:00',39.50,84,34),(202,22,'67/2021','2021-10-08 00:00:00',39.00,56,22),(203,33,'67/2021','2021-10-08 00:00:00',24.00,28,33),(204,83,'247/2021','2021-11-05 00:00:00',61.00,42,83),(205,68,'247/2021','2021-11-05 00:00:00',35.00,21,68),(206,21,'247/2021','2021-11-05 00:00:00',58.00,21,21),(207,46,'247/2021','2021-11-05 00:00:00',13.50,21,46),(208,82,'34/2018','2021-11-05 00:00:00',52.80,28,82),(209,83,'34/2018','2021-11-05 00:00:00',61.00,28,83),(210,36,'34/2018','2021-11-05 00:00:00',75.00,28,36),(211,33,'34/2018','2021-11-05 00:00:00',24.00,28,33),(212,46,'34/2018','2021-11-05 00:00:00',13.50,28,46),(213,71,'078/2021','2021-10-15 00:00:00',32.00,42,71),(214,37,'078/2021','2021-10-15 00:00:00',16.49,84,37),(215,36,'078/2021','2021-10-15 00:00:00',75.00,28,36),(216,37,'112/2018','2021-10-15 00:00:00',16.49,56,37),(217,82,'8/2014','2021-10-29 00:00:00',52.80,42,82),(218,50,'231/2021','2021-10-29 00:00:00',170.00,21,50),(219,48,'231/2021','2021-10-29 00:00:00',53.00,21,48),(220,92,'231/2021','2021-10-29 00:00:00',126.05,1,92),(221,11,'231/2021','2021-10-29 00:00:00',129.00,1,11),(222,46,'231/2021','2021-10-29 00:00:00',13.50,21,46),(223,92,'157/2019','2021-10-29 00:00:00',126.05,3,92),(224,46,'157/2019','2021-10-29 00:00:00',13.50,42,46),(225,47,'157/2019','2021-10-29 00:00:00',28.00,21,47),(226,44,'137/2020','2021-10-01 00:00:00',110.00,363,44),(227,36,'137/2020','2021-10-01 00:00:00',75.00,168,36),(228,46,'137/2020','2021-10-01 00:00:00',13.50,531,46),(229,72,'137/2020','2021-10-01 00:00:00',85.00,168,72),(230,71,'137/2020','2021-10-01 00:00:00',32.00,168,71),(231,62,'137/2020','2021-10-01 00:00:00',40.00,168,62),(232,64,'137/2020','2021-10-01 00:00:00',53.00,168,64),(233,47,'137/2020','2021-10-01 00:00:00',28.00,168,47),(234,83,'38/2017','2021-11-05 00:00:00',61.00,28,83),(235,26,'38/2017','2021-11-05 00:00:00',49.00,28,26),(236,49,'38/2017','2021-11-05 00:00:00',86.00,14,49),(237,48,'38/2017','2021-11-05 00:00:00',53.00,14,48),(238,47,'38/2017','2021-11-05 00:00:00',28.00,14,47),(239,35,'134/2020','2021-10-22 00:00:00',49.00,56,35),(240,46,'134/2020','2021-10-22 00:00:00',13.50,84,46),(241,83,'134/2020','2021-10-22 00:00:00',61.00,56,83),(242,70,'134/2020','2021-10-22 00:00:00',41.31,28,70),(243,71,'134/2020','2021-10-22 00:00:00',32.00,28,71),(244,82,'58/2021','2021-11-05 00:00:00',52.80,28,82),(245,83,'58/2021','2021-11-05 00:00:00',61.00,14,83),(246,48,'58/2021','2021-11-05 00:00:00',53.00,14,48),(247,50,'58/2021','2021-11-05 00:00:00',170.00,14,50),(248,46,'58/2021','2021-11-05 00:00:00',13.50,14,46),(249,65,'59/2021','2021-10-08 00:00:00',84.00,42,65),(250,19,'59/2021','2021-10-08 00:00:00',45.00,21,19),(251,20,'59/2021','2021-10-08 00:00:00',95.00,42,20),(252,28,'04/2018','2021-10-22 00:00:00',45.00,42,28),(253,46,'04/2018','2021-10-22 00:00:00',13.50,28,46),(254,39,'04/2018','2021-10-22 00:00:00',69.00,28,39),(255,50,'9/2018','2021-09-24 00:00:00',170.00,56,50),(256,49,'9/2018','2021-09-24 00:00:00',86.00,56,49),(257,34,'9/2018','2021-09-24 00:00:00',39.50,112,34),(258,46,'9/2018','2021-09-24 00:00:00',13.50,112,46),(259,11,'9/2018','2021-09-24 00:00:00',129.00,2,11),(260,46,'211/2019','2021-10-01 00:00:00',13.50,98,46),(261,45,'211/2019','2021-10-01 00:00:00',46.20,98,45),(262,87,'211/2019','2021-10-01 00:00:00',54.00,98,87),(263,81,'211/2019','2021-10-01 00:00:00',68.00,98,81),(264,36,'211/2019','2021-10-01 00:00:00',75.00,49,36),(265,4,'211/2019','2021-10-01 00:00:00',46.00,49,4),(266,68,'75/2019','2021-09-24 00:00:00',35.00,56,68),(267,69,'75/2019','2021-09-24 00:00:00',35.00,56,69),(268,46,'75/2019','2021-09-24 00:00:00',13.50,112,46),(269,83,'75/2019','2021-09-24 00:00:00',61.00,56,83),(270,83,'251/2021','2021-11-12 00:00:00',61.00,28,83),(271,48,'251/2021','2021-11-12 00:00:00',53.00,14,48),(272,50,'251/2021','2021-11-12 00:00:00',170.00,14,50),(273,10,'251/2021','2021-11-12 00:00:00',233.00,42,10),(274,36,'251/2021','2021-11-12 00:00:00',75.00,14,36),(275,30,'251/2021','2021-11-12 00:00:00',75.00,28,30),(276,37,'104/2018','2021-10-08 00:00:00',16.49,84,37),(277,81,'104/2018','2021-10-08 00:00:00',68.00,56,81),(278,81,'250/2021','2021-11-12 00:00:00',68.00,28,81),(279,12,'250/2021','2021-11-12 00:00:00',40.00,14,12),(280,69,'250/2021','2021-11-12 00:00:00',35.00,14,69),(281,67,'250/2021','2021-11-12 00:00:00',21.50,14,67),(282,33,'0112/2017','2021-11-26 00:00:00',24.00,28,33),(283,83,'059/2021','2021-11-12 00:00:00',61.00,112,83),(284,70,'059/2021','2021-11-12 00:00:00',41.31,56,70),(285,83,'77/2021','2021-11-26 00:00:00',61.00,112,83),(286,35,'77/2021','2021-11-26 00:00:00',49.00,112,35),(287,33,'77/2021','2021-11-26 00:00:00',24.00,56,33),(288,47,'77/2021','2021-11-26 00:00:00',28.00,56,47),(289,46,'77/2021','2021-11-26 00:00:00',13.50,168,46),(290,34,'106/2017','2021-10-22 00:00:00',39.50,56,34),(291,46,'106/2017','2021-10-22 00:00:00',13.50,56,46),(292,83,'75/2019','2021-11-19 00:00:00',61.00,42,83),(293,68,'75/2019','2021-11-19 00:00:00',35.00,42,68),(294,69,'75/2019','2021-11-19 00:00:00',35.00,42,69),(295,46,'75/2019','2021-11-19 00:00:00',13.50,126,46),(296,81,'232/2021','2021-11-26 00:00:00',68.00,28,81),(297,83,'232/2021','2021-11-26 00:00:00',61.00,28,83),(298,46,'232/2021','2021-11-26 00:00:00',13.50,84,46),(299,34,'232/2021','2021-11-26 00:00:00',39.50,28,34),(300,76,'232/2021','2021-11-26 00:00:00',18.85,28,76),(301,68,'232/2021','2021-11-26 00:00:00',35.00,28,68),(302,48,'93/2017','2021-11-05 00:00:00',53.00,35,48),(303,50,'93/2017','2021-11-05 00:00:00',170.00,35,50),(304,35,'93/2017','2021-11-05 00:00:00',49.00,35,35),(305,83,'93/2017','2021-11-05 00:00:00',61.00,70,83),(306,82,'93/2017','2021-11-05 00:00:00',52.80,35,82),(307,46,'93/2017','2021-11-05 00:00:00',13.50,140,46),(308,45,'45/2017','2021-10-15 00:00:00',46.20,112,45),(309,33,'45/2017','2021-10-15 00:00:00',24.00,56,33),(310,47,'45/2017','2021-10-15 00:00:00',28.00,56,47),(311,48,'45/2017','2021-10-15 00:00:00',53.00,56,48),(312,82,'288/2021','2021-12-03 00:00:00',52.80,14,82),(313,35,'288/2021','2021-12-03 00:00:00',49.00,7,35),(314,46,'288/2021','2021-12-03 00:00:00',13.50,7,46),(315,11,'231/2021','2021-12-03 00:00:00',129.00,1,11),(316,49,'231/2021','2021-12-03 00:00:00',86.00,7,49),(317,92,'231/2021','2021-12-03 00:00:00',126.05,1,92),(318,46,'231/2021','2021-12-03 00:00:00',13.50,7,46),(319,10,'251/2021','2021-11-26 00:00:00',233.00,42,10),(320,83,'251/2021','2021-11-26 00:00:00',61.00,42,83),(321,49,'251/2021','2021-11-26 00:00:00',86.00,42,49),(322,36,'251/2021','2021-11-26 00:00:00',75.00,28,36),(323,37,'251/2021','2021-11-26 00:00:00',16.49,42,37),(324,91,'251/2021','2021-11-26 00:00:00',28.00,42,91),(325,82,'205/2019','2021-11-12 00:00:00',52.80,112,82),(326,27,'205/2019','2021-11-12 00:00:00',120.00,28,27),(327,83,'38/2017','2021-11-19 00:00:00',61.00,56,83),(328,26,'38/2017','2021-11-19 00:00:00',49.00,42,26),(329,49,'38/2017','2021-11-19 00:00:00',86.00,28,49),(330,47,'38/2017','2021-11-19 00:00:00',28.00,28,47),(331,48,'38/2017','2021-11-19 00:00:00',53.00,28,48),(332,46,'38/2017','2021-11-19 00:00:00',13.50,28,46),(333,47,'138/2019','2021-11-26 00:00:00',28.00,63,47),(334,34,'138/2019','2021-11-26 00:00:00',39.50,42,34),(335,36,'138/2019','2021-11-26 00:00:00',75.00,42,36),(336,33,'138/2019','2021-11-26 00:00:00',24.00,42,33),(337,11,'231/2021','2021-12-10 00:00:00',129.00,1,11),(338,49,'231/2021','2021-12-10 00:00:00',86.00,14,49),(339,92,'231/2021','2021-12-10 00:00:00',126.05,1,92),(340,46,'231/2021','2021-12-10 00:00:00',13.50,14,46),(341,46,'144/2019','2021-11-26 00:00:00',13.50,28,46),(342,92,'144/2019','2021-11-26 00:00:00',126.05,1,92),(343,81,'250/2021','2021-11-26 00:00:00',68.00,56,81),(344,12,'250/2021','2021-11-26 00:00:00',40.00,28,12),(345,67,'250/2021','2021-11-26 00:00:00',21.50,28,67),(346,69,'250/2021','2021-11-26 00:00:00',35.00,28,69),(347,5,'202/2021','2021-12-03 00:00:00',85.00,21,5),(348,4,'202/2021','2021-12-03 00:00:00',46.00,21,4),(349,11,'288/2021','2021-12-10 00:00:00',129.00,1,11),(350,36,'288/2021','2021-12-10 00:00:00',75.00,14,36),(351,46,'288/2021','2021-12-10 00:00:00',13.50,28,46),(352,9,'63/2018','2021-10-01 00:00:00',750.00,84,9),(353,8,'63/2018','2021-10-01 00:00:00',72.00,84,8),(354,83,'15/2021','2021-12-17 00:00:00',61.00,14,83),(355,82,'15/2021','2021-12-17 00:00:00',52.80,7,82),(356,69,'15/2021','2021-12-17 00:00:00',35.00,7,69),(357,12,'15/2021','2021-12-17 00:00:00',40.00,7,12),(358,70,'289/2021','2021-12-31 00:00:00',41.31,7,70),(359,71,'289/2021','2021-12-31 00:00:00',32.00,7,71),(360,12,'112/2017','2021-12-10 00:00:00',40.00,28,12),(361,34,'112/2017','2021-12-10 00:00:00',39.50,28,34),(362,46,'112/2017','2021-12-10 00:00:00',13.50,28,46),(363,9,'112/2017','2021-12-10 00:00:00',750.00,28,9),(364,21,'161/2019','2021-12-17 00:00:00',58.00,42,21),(365,44,'161/2019','2021-12-17 00:00:00',110.00,42,44),(366,64,'161/2019','2021-12-17 00:00:00',53.00,21,64),(367,73,'182/2021','2021-11-26 00:00:00',126.50,42,73),(368,46,'182/2021','2021-11-26 00:00:00',13.50,126,46),(369,83,'182/2021','2021-11-26 00:00:00',61.00,84,83),(370,25,'182/2021','2021-11-26 00:00:00',38.00,42,25),(371,26,'182/2021','2021-11-26 00:00:00',49.00,42,26),(372,48,'182/2021','2021-11-26 00:00:00',53.00,42,48),(373,92,'291/2021','2021-12-31 00:00:00',126.05,1,92),(374,36,'158/2020','2021-12-17 00:00:00',75.00,42,36),(375,48,'158/2020','2021-12-17 00:00:00',53.00,42,48),(376,49,'158/2020','2021-12-17 00:00:00',86.00,21,49),(377,89,'158/2020','2021-12-17 00:00:00',34.50,11,89),(378,29,'158/2020','2021-12-17 00:00:00',16.30,21,29),(379,83,'158/2020','2021-12-17 00:00:00',61.00,42,83),(380,46,'158/2020','2021-12-17 00:00:00',13.50,42,46),(381,83,'38/2017','2021-12-24 00:00:00',61.00,28,83),(382,82,'38/2017','2021-12-24 00:00:00',52.80,14,82),(383,26,'38/2017','2021-12-24 00:00:00',49.00,14,26),(384,25,'38/2017','2021-12-24 00:00:00',38.00,21,25),(385,46,'38/2017','2021-12-24 00:00:00',13.50,42,46),(386,49,'38/2017','2021-12-24 00:00:00',86.00,14,49),(387,48,'38/2017','2021-12-24 00:00:00',53.00,14,48),(388,47,'38/2017','2021-12-24 00:00:00',28.00,28,47),(389,50,'01/2018','2021-12-24 00:00:00',170.00,14,50),(390,47,'01/2018','2021-12-24 00:00:00',28.00,14,47),(391,83,'01/2018','2021-12-24 00:00:00',61.00,28,83),(392,67,'01/2018','2021-12-24 00:00:00',21.50,14,67),(393,68,'01/2018','2021-12-24 00:00:00',35.00,14,68),(394,12,'01/2018','2021-12-24 00:00:00',40.00,14,12),(395,43,'0130/2017','2021-10-22 00:00:00',84.50,168,43),(396,65,'0130/2017','2021-10-22 00:00:00',84.00,84,65),(397,70,'0130/2017','2021-10-22 00:00:00',41.31,84,70),(398,82,'0130/2017','2021-10-22 00:00:00',52.80,168,82),(399,83,'93/2017','2021-12-10 00:00:00',61.00,84,83),(400,82,'93/2017','2021-12-10 00:00:00',52.80,42,82),(401,34,'93/2017','2021-12-10 00:00:00',39.50,42,34),(402,50,'93/2017','2021-12-10 00:00:00',170.00,42,50),(403,48,'93/2017','2021-12-10 00:00:00',53.00,63,48),(404,46,'93/2017','2021-12-10 00:00:00',13.50,168,46),(405,83,'135/2018','2021-12-24 00:00:00',61.00,84,83),(406,82,'135/2018','2021-12-24 00:00:00',52.80,84,82),(407,84,'135/2018','2021-12-24 00:00:00',130.90,168,84),(408,69,'135/2018','2021-12-24 00:00:00',35.00,84,69),(409,67,'135/2018','2021-12-24 00:00:00',21.50,84,67),(410,76,'135/2018','2021-12-24 00:00:00',18.85,168,76),(411,46,'135/2018','2021-12-24 00:00:00',13.50,168,46),(412,82,'205/2019','2021-12-10 00:00:00',52.80,168,82),(413,27,'205/2019','2021-12-10 00:00:00',120.00,42,27),(414,82,'288/2021','2021-12-31 00:00:00',52.80,21,82),(415,83,'288/2021','2021-12-31 00:00:00',61.00,21,83),(416,36,'288/2021','2021-12-31 00:00:00',75.00,21,36),(417,46,'288/2021','2021-12-31 00:00:00',13.50,63,46),(418,5,'290/2021','2021-12-31 00:00:00',85.00,14,5),(419,4,'290/2021','2021-12-31 00:00:00',46.00,14,4),(420,21,'290/2021','2021-12-31 00:00:00',58.00,14,21),(421,69,'290/2021','2021-12-31 00:00:00',35.00,14,69),(422,68,'290/2021','2021-12-31 00:00:00',35.00,14,68),(423,35,'290/2021','2021-12-31 00:00:00',49.00,14,35),(424,65,'249/2021','2021-12-17 00:00:00',84.00,56,65),(425,70,'249/2021','2021-12-17 00:00:00',41.31,28,70),(426,59,'292/2021','2021-12-31 00:00:00',10.40,28,59),(427,70,'292/2021','2021-12-31 00:00:00',41.31,7,70),(428,3,'292/2021','2021-12-31 00:00:00',170.00,7,3),(429,68,'292/2021','2021-12-31 00:00:00',35.00,14,68),(430,33,'0112/2017','2021-12-24 00:00:00',24.00,56,33),(431,4,'03/2022','2022-01-07 00:00:00',46.00,21,4),(432,24,'89/2018','2022-01-07 00:00:00',64.00,28,24),(433,58,'89/2018','2022-01-07 00:00:00',41.40,56,58),(434,72,'89/2018','2022-01-07 00:00:00',85.00,28,72),(435,34,'02/2022','2022-01-07 00:00:00',39.50,7,34),(436,46,'02/2022','2022-01-07 00:00:00',13.50,7,46),(437,81,'059/2021','2021-12-31 00:00:00',68.00,21,81),(438,83,'059/2021','2021-12-31 00:00:00',61.00,21,83),(439,70,'059/2021','2021-12-31 00:00:00',41.31,21,70),(440,34,'106/2017','2021-12-17 00:00:00',39.50,84,34),(441,46,'106/2017','2021-12-17 00:00:00',13.50,84,46),(442,34,'36/2020','2021-12-10 00:00:00',39.50,84,34),(443,35,'36/2020','2021-12-10 00:00:00',49.00,84,35),(444,49,'36/2020','2021-12-10 00:00:00',86.00,84,49),(445,46,'36/2020','2021-12-10 00:00:00',13.50,968,46),(446,11,'36/2020','2021-12-10 00:00:00',129.00,2,11),(447,46,'38/2017','2022-01-07 00:00:00',13.50,42,46),(448,26,'38/2017','2022-01-07 00:00:00',49.00,14,26),(449,25,'38/2017','2022-01-07 00:00:00',38.00,21,25),(450,83,'38/2017','2022-01-07 00:00:00',61.00,28,83),(451,49,'38/2017','2022-01-07 00:00:00',86.00,14,49),(452,48,'38/2017','2022-01-07 00:00:00',53.00,28,48),(453,47,'38/2017','2022-01-07 00:00:00',28.00,14,47),(454,34,'138/2019','2022-01-07 00:00:00',39.50,42,34),(455,35,'138/2019','2022-01-07 00:00:00',49.00,84,35),(456,46,'138/2019','2022-01-07 00:00:00',13.50,84,46),(457,48,'138/2019','2022-01-07 00:00:00',53.00,42,48),(458,46,'75/2019','2021-12-24 00:00:00',13.50,126,46),(459,82,'75/2019','2021-12-24 00:00:00',52.80,42,82),(460,83,'75/2019','2021-12-24 00:00:00',61.00,42,83),(461,68,'75/2019','2021-12-24 00:00:00',35.00,84,68),(462,81,'232/2021','2022-01-07 00:00:00',68.00,7,81),(463,83,'232/2021','2022-01-07 00:00:00',61.00,7,83),(464,46,'232/2021','2022-01-07 00:00:00',13.50,21,46),(465,71,'232/2021','2022-01-07 00:00:00',32.00,7,71),(466,36,'232/2021','2022-01-07 00:00:00',75.00,7,36),(467,67,'16/2021','2021-12-24 00:00:00',21.50,42,67),(468,69,'16/2021','2021-12-24 00:00:00',35.00,42,69),(469,83,'16/2021','2021-12-24 00:00:00',61.00,42,83),(470,82,'16/2021','2021-12-24 00:00:00',52.80,42,82),(471,46,'16/2021','2021-12-24 00:00:00',13.50,42,46),(472,82,'34/2018','2021-12-03 00:00:00',52.80,126,82),(473,33,'34/2018','2021-12-03 00:00:00',24.00,42,33),(474,36,'34/2018','2021-12-03 00:00:00',75.00,42,36),(475,46,'34/2018','2021-12-03 00:00:00',13.50,42,46),(476,50,'9/2018','2021-11-19 00:00:00',170.00,56,50),(477,49,'9/2018','2021-11-19 00:00:00',86.00,56,49),(478,46,'9/2018','2021-11-19 00:00:00',13.50,112,46),(479,34,'9/2018','2021-11-19 00:00:00',39.50,112,34),(480,5,'202/2021','2021-12-24 00:00:00',85.00,42,5),(481,4,'202/2021','2021-12-24 00:00:00',46.00,42,4),(482,82,'137/2020','2021-12-24 00:00:00',52.80,56,82),(483,83,'137/2020','2021-12-24 00:00:00',61.00,56,83),(484,36,'137/2020','2021-12-24 00:00:00',75.00,56,36),(485,48,'137/2020','2021-12-24 00:00:00',53.00,56,48),(486,37,'105/2014','2021-12-24 00:00:00',16.49,56,37),(487,49,'99/2019','2021-12-17 00:00:00',86.00,56,49),(488,48,'99/2019','2021-12-17 00:00:00',53.00,56,48),(489,5,'99/2019','2021-12-17 00:00:00',85.00,112,5),(490,70,'76/2021','2021-11-26 00:00:00',41.31,56,70),(491,35,'76/2021','2021-11-26 00:00:00',49.00,112,35),(492,46,'76/2021','2021-11-26 00:00:00',13.50,112,46),(493,12,'112/2017','2021-12-10 00:00:00',40.00,28,12),(494,34,'112/2017','2021-12-10 00:00:00',39.50,28,34),(495,46,'112/2017','2021-12-10 00:00:00',13.50,28,46),(496,9,'112/2017','2021-12-10 00:00:00',750.00,28,9),(497,4,'03/2022','2022-01-07 00:00:00',46.00,7,4),(498,82,'205/2019','2021-12-10 00:00:00',52.80,84,82),(499,27,'205/2019','2021-12-10 00:00:00',120.00,42,27),(500,92,'116/2019','2022-01-07 00:00:00',126.05,2,92),(501,37,'116/2019','2022-01-07 00:00:00',16.49,112,37),(502,46,'158/2020','2022-01-07 00:00:00',13.50,42,46),(503,83,'158/2020','2022-01-07 00:00:00',61.00,28,83),(504,82,'158/2020','2022-01-07 00:00:00',52.80,14,82),(505,29,'158/2020','2022-01-07 00:00:00',16.30,4,29),(506,89,'158/2020','2022-01-07 00:00:00',34.50,7,89),(507,48,'158/2020','2022-01-07 00:00:00',53.00,28,48),(508,49,'158/2020','2022-01-07 00:00:00',86.00,14,49),(509,36,'158/2020','2022-01-07 00:00:00',75.00,28,36),(510,12,'77/2017','2021-12-31 00:00:00',40.00,28,12),(511,21,'77/2017','2021-12-31 00:00:00',58.00,28,21),(512,69,'77/2017','2021-12-31 00:00:00',35.00,28,69),(513,28,'79/2021','2021-12-03 00:00:00',45.00,112,28),(514,83,'79/2021','2021-12-03 00:00:00',61.00,56,83),(515,4,'79/2021','2021-12-03 00:00:00',46.00,56,4),(516,81,'104/2018','2021-12-24 00:00:00',68.00,56,81),(517,37,'104/2018','2021-12-24 00:00:00',16.49,112,37),(518,5,'168/2021','2022-01-07 00:00:00',85.00,14,5),(519,28,'04/2018','2021-12-17 00:00:00',45.00,80,28),(520,46,'04/2018','2021-12-17 00:00:00',13.50,56,46),(521,39,'04/2018','2021-12-17 00:00:00',69.00,28,39),(522,83,'92/2018','2021-12-03 00:00:00',61.00,84,83),(523,68,'92/2018','2021-12-03 00:00:00',35.00,84,68),(524,95,'92/2018','2021-12-03 00:00:00',120.90,84,95),(525,3,'92/2018','2021-12-03 00:00:00',170.00,42,3),(526,68,'92/2018','2021-12-03 00:00:00',35.00,84,68),(527,69,'92/2018','2021-12-03 00:00:00',35.00,42,69),(528,92,'144/2019','2021-12-31 00:00:00',126.05,1,92),(529,46,'144/2019','2021-12-31 00:00:00',13.50,14,46),(530,83,'15/2021','2021-12-24 00:00:00',61.00,42,83),(531,82,'15/2021','2021-12-24 00:00:00',52.80,21,82),(532,12,'15/2021','2021-12-24 00:00:00',40.00,21,12),(533,69,'15/2021','2021-12-24 00:00:00',35.00,21,69),(534,82,'58/2021','2021-12-03 00:00:00',52.80,84,82),(535,83,'58/2021','2021-12-03 00:00:00',61.00,42,83),(536,46,'58/2021','2021-12-03 00:00:00',13.50,126,46),(537,83,'247/2021','2021-12-10 00:00:00',61.00,70,83),(538,67,'247/2021','2021-12-10 00:00:00',21.50,35,67),(539,69,'247/2021','2021-12-10 00:00:00',35.00,35,69),(540,21,'247/2021','2021-12-10 00:00:00',58.00,35,21),(541,46,'247/2021','2021-12-10 00:00:00',13.50,35,46),(542,12,'250/2021','2021-12-24 00:00:00',40.00,42,12),(543,81,'250/2021','2021-12-24 00:00:00',68.00,42,81),(544,83,'250/2021','2021-12-24 00:00:00',61.00,42,83),(545,69,'250/2021','2021-12-24 00:00:00',35.00,42,69),(546,33,'263/2021','2022-01-07 00:00:00',24.00,4,33),(547,70,'263/2021','2022-01-07 00:00:00',41.31,4,70),(548,4,'263/2021','2022-01-07 00:00:00',46.00,7,4),(549,64,'161/2019','2022-01-07 00:00:00',53.00,4,64),(550,21,'161/2019','2022-01-07 00:00:00',58.00,14,21),(551,44,'161/2019','2022-01-07 00:00:00',110.00,14,44),(552,83,'26/2017','2022-01-14 00:00:00',61.00,56,83),(553,83,'288/2021','2022-01-14 00:00:00',61.00,28,83),(554,82,'288/2021','2022-01-14 00:00:00',52.80,28,82),(555,36,'288/2021','2022-01-14 00:00:00',75.00,28,36),(556,46,'288/2021','2022-01-14 00:00:00',13.50,84,46),(557,92,'291/2021','2022-01-07 00:00:00',126.05,1,92),(558,5,'04/2022','2022-01-14 00:00:00',85.00,7,5),(559,3,'04/2022','2022-01-14 00:00:00',170.00,7,3),(560,36,'02/2022','2022-01-14 00:00:00',75.00,7,36),(561,46,'02/2022','2022-01-14 00:00:00',13.50,7,46),(562,4,'03/2022','2022-01-14 00:00:00',46.00,21,4),(563,81,'232/2021','2022-01-14 00:00:00',68.00,14,81),(564,83,'232/2021','2022-01-14 00:00:00',61.00,14,83),(565,36,'232/2021','2022-01-14 00:00:00',75.00,14,36),(566,46,'232/2021','2022-01-14 00:00:00',13.50,56,46),(567,47,'232/2021','2022-01-14 00:00:00',28.00,14,47),(568,22,'248/2021','2022-01-14 00:00:00',39.00,14,22),(569,82,'137/2020','2022-01-14 00:00:00',52.80,35,82),(570,83,'137/2020','2022-01-14 00:00:00',61.00,35,83),(571,36,'137/2020','2022-01-14 00:00:00',75.00,35,36),(572,49,'137/2020','2022-01-14 00:00:00',86.00,35,49),(573,46,'137/2020','2022-01-14 00:00:00',13.50,35,46),(574,12,'112/2017','2022-01-14 00:00:00',40.00,42,12),(575,34,'112/2017','2022-01-14 00:00:00',39.50,42,34),(576,46,'112/2017','2022-01-14 00:00:00',13.50,42,46),(577,9,'112/2017','2022-01-14 00:00:00',750.00,42,9),(578,48,'92/2018','2022-01-14 00:00:00',53.00,28,48),(579,83,'92/2018','2022-01-14 00:00:00',61.00,56,83),(580,68,'92/2018','2022-01-14 00:00:00',35.00,56,68),(581,95,'92/2018','2022-01-14 00:00:00',120.90,56,95),(582,83,'15/2021','2022-01-14 00:00:00',61.00,56,83),(583,82,'15/2021','2022-01-14 00:00:00',52.80,28,82),(584,12,'15/2021','2022-01-14 00:00:00',40.00,28,12),(585,69,'15/2021','2022-01-14 00:00:00',35.00,28,69),(586,82,'75/2019','2022-01-14 00:00:00',52.80,21,82),(587,83,'75/2019','2022-01-14 00:00:00',61.00,21,83),(588,68,'75/2019','2022-01-14 00:00:00',35.00,21,68),(589,81,'250/2021','2022-01-14 00:00:00',68.00,28,81),(590,83,'250/2021','2022-01-14 00:00:00',61.00,28,83),(591,12,'250/2021','2022-01-14 00:00:00',40.00,28,12),(592,69,'250/2021','2022-01-14 00:00:00',35.00,28,69),(593,83,'247/2021','2022-01-14 00:00:00',61.00,56,83),(594,67,'247/2021','2022-01-14 00:00:00',21.50,28,67),(595,69,'247/2021','2022-01-14 00:00:00',35.00,28,69),(596,21,'247/2021','2022-01-14 00:00:00',58.00,28,21),(597,46,'247/2021','2022-01-14 00:00:00',13.50,28,46),(598,50,'9/2018','2022-01-14 00:00:00',170.00,56,50),(599,46,'9/2018','2022-01-14 00:00:00',13.50,112,46),(600,34,'9/2018','2022-01-14 00:00:00',39.50,112,34),(601,4,'168/2021','2022-01-14 00:00:00',46.00,14,4),(602,26,'38/2017','2022-01-14 00:00:00',49.00,28,26),(603,83,'38/2017','2022-01-14 00:00:00',61.00,28,83),(604,49,'38/2017','2022-01-14 00:00:00',86.00,14,49),(605,48,'38/2017','2022-01-14 00:00:00',53.00,14,48),(606,47,'38/2017','2022-01-14 00:00:00',28.00,14,47),(607,46,'38/2017','2022-01-14 00:00:00',13.50,42,46),(608,76,'90/2017','2022-01-14 00:00:00',18.85,14,76),(609,48,'90/2017','2022-01-14 00:00:00',53.00,28,48),(610,46,'90/2017','2022-01-14 00:00:00',13.50,84,46),(611,33,'90/2017','2022-01-14 00:00:00',24.00,28,33),(612,83,'90/2017','2022-01-14 00:00:00',61.00,56,83),(613,82,'58/2021','2022-01-14 00:00:00',52.80,56,82),(614,83,'58/2021','2022-01-14 00:00:00',61.00,28,83),(615,50,'58/2021','2022-01-14 00:00:00',170.00,28,50),(616,47,'58/2021','2022-01-14 00:00:00',28.00,28,47),(617,48,'58/2021','2022-01-14 00:00:00',53.00,28,48),(618,46,'58/2021','2022-01-14 00:00:00',13.50,84,46),(619,69,'135/2020','2022-01-14 00:00:00',35.00,56,69),(620,22,'135/2020','2022-01-14 00:00:00',39.00,56,22),(621,82,'135/2020','2022-01-14 00:00:00',52.80,112,82),(622,82,'54/2017','2021-12-17 00:00:00',52.80,56,82),(623,83,'54/2017','2021-12-17 00:00:00',61.00,56,83),(624,68,'54/2017','2021-12-17 00:00:00',35.00,56,68),(625,46,'54/2017','2021-12-17 00:00:00',13.50,56,46),(626,8,'54/2017','2021-12-17 00:00:00',72.00,56,8),(627,59,'292/2021','2022-01-07 00:00:00',10.40,28,59),(628,3,'292/2021','2022-01-07 00:00:00',170.00,10,3),(629,70,'292/2021','2022-01-07 00:00:00',41.31,14,70),(630,68,'292/2021','2022-01-07 00:00:00',35.00,28,68),(631,70,'49/2017','2021-12-10 00:00:00',41.31,84,70),(632,71,'49/2017','2021-12-10 00:00:00',32.00,84,71),(633,45,'211/2019','2021-12-31 00:00:00',46.20,98,45),(634,87,'211/2019','2021-12-31 00:00:00',54.00,74,87),(635,81,'211/2019','2021-12-31 00:00:00',68.00,98,81),(636,36,'211/2019','2021-12-31 00:00:00',75.00,49,36),(637,46,'211/2019','2021-12-31 00:00:00',13.50,147,46),(638,4,'211/2019','2021-12-31 00:00:00',46.00,49,4),(639,72,'182/2021','2022-01-07 00:00:00',85.00,56,72),(640,71,'182/2021','2022-01-07 00:00:00',32.00,56,71),(641,46,'182/2021','2022-01-07 00:00:00',13.50,168,46),(642,83,'182/2021','2022-01-07 00:00:00',61.00,112,83),(643,25,'182/2021','2022-01-07 00:00:00',38.00,56,25),(644,26,'182/2021','2022-01-07 00:00:00',49.00,56,26),(645,48,'182/2021','2022-01-07 00:00:00',53.00,56,48),(646,35,'088/2017','2021-12-24 00:00:00',49.00,112,35),(647,33,'088/2017','2021-12-24 00:00:00',24.00,56,33),(648,46,'088/2017','2021-12-24 00:00:00',13.50,56,46),(649,35,'196/2021','2021-12-31 00:00:00',49.00,28,35),(650,46,'196/2021','2021-12-31 00:00:00',13.50,28,46),(651,9,'88/2017','2021-12-24 00:00:00',750.00,84,9),(652,49,'88/2017','2021-12-24 00:00:00',86.00,56,49),(653,47,'88/2017','2021-12-24 00:00:00',28.00,56,47),(654,46,'88/2017','2021-12-24 00:00:00',13.50,56,46),(655,93,'231/2021','2021-12-24 00:00:00',52.50,2,93),(656,11,'231/2021','2021-12-24 00:00:00',129.00,4,11),(657,49,'231/2021','2021-12-24 00:00:00',86.00,28,49),(658,92,'231/2021','2021-12-24 00:00:00',126.05,2,92),(659,46,'231/2021','2021-12-24 00:00:00',13.50,28,46),(660,39,'230/2021','2021-12-24 00:00:00',69.00,42,39),(661,12,'204/2021','2021-10-01 00:00:00',40.00,14,12),(662,65,'59/2021','2021-11-19 00:00:00',84.00,84,65),(663,19,'59/2021','2021-11-19 00:00:00',45.00,42,19),(664,20,'59/2021','2021-11-19 00:00:00',95.00,84,20),(665,45,'45/2017','2021-12-24 00:00:00',46.20,168,45),(666,47,'45/2017','2021-12-24 00:00:00',28.00,84,47),(667,48,'45/2017','2021-12-24 00:00:00',53.00,84,48),(668,83,'47/2017','2021-12-17 00:00:00',61.00,56,83),(669,70,'47/2017','2021-12-17 00:00:00',41.31,56,70),(670,83,'137/2017','2021-12-31 00:00:00',61.00,56,83),(671,26,'137/2017','2021-12-31 00:00:00',49.00,42,26),(672,73,'137/2017','2021-12-31 00:00:00',126.50,28,73),(673,46,'137/2017','2021-12-31 00:00:00',13.50,84,46),(674,76,'137/2017','2021-12-31 00:00:00',18.85,28,76),(675,35,'134/2020','2021-12-24 00:00:00',49.00,56,35),(676,46,'134/2020','2021-12-24 00:00:00',13.50,84,46),(677,83,'134/2020','2021-12-24 00:00:00',61.00,56,83),(678,71,'134/2020','2021-12-24 00:00:00',32.00,28,71),(679,71,'078/2021','2021-11-26 00:00:00',32.00,56,71),(680,70,'078/2021','2021-11-26 00:00:00',41.31,56,70),(681,37,'078/2021','2021-11-26 00:00:00',16.49,112,37),(682,35,'078/2021','2021-11-26 00:00:00',49.00,112,35),(683,85,'44/2017','2021-12-24 00:00:00',65.00,28,85),(684,34,'44/2017','2021-12-24 00:00:00',39.50,14,34),(685,34,'287/2021','2021-12-31 00:00:00',39.50,42,34),(686,46,'287/2021','2021-12-31 00:00:00',13.50,42,46),(687,67,'287/2021','2021-12-31 00:00:00',21.50,21,67),(688,20,'44/2020','2021-12-23 00:00:00',95.00,42,20),(689,12,'44/2020','2021-12-23 00:00:00',40.00,42,12),(690,56,'44/2020','2021-12-23 00:00:00',61.90,126,56),(691,12,'67/2021','2021-11-26 00:00:00',40.00,42,12),(692,33,'67/2021','2021-11-26 00:00:00',24.00,21,33),(693,48,'48/2017','2021-12-17 00:00:00',53.00,42,48),(694,47,'48/2017','2021-12-17 00:00:00',28.00,42,47),(695,70,'48/2017','2021-12-17 00:00:00',41.31,42,70),(696,71,'48/2017','2021-12-17 00:00:00',32.00,42,71),(697,46,'48/2017','2021-12-17 00:00:00',13.50,126,46),(698,34,'48/2017','2021-12-17 00:00:00',39.50,84,34),(699,82,'06/2018','2021-12-10 00:00:00',52.80,56,82),(700,83,'06/2018','2021-12-10 00:00:00',61.00,56,83),(701,36,'06/2018','2021-12-10 00:00:00',75.00,112,36),(702,46,'06/2018','2021-12-10 00:00:00',13.50,168,46),(703,9,'63/2018','2021-12-24 00:00:00',750.00,42,9),(704,8,'63/2018','2021-12-24 00:00:00',72.00,42,8),(705,21,'60/2021','2021-12-31 00:00:00',58.00,84,21),(706,82,'8/2014','2021-11-12 00:00:00',52.80,84,82),(707,57,'206/2021','2021-11-26 00:00:00',34.10,112,57),(708,34,'206/2021','2021-11-26 00:00:00',39.50,56,34),(709,81,'83/2019','2021-12-24 00:00:00',68.00,168,81),(710,84,'83/2019','2021-12-24 00:00:00',130.90,168,84),(711,59,'83/2019','2021-12-24 00:00:00',10.40,84,59),(712,57,'83/2019','2021-12-24 00:00:00',34.10,84,57),(713,37,'07/2017','2021-12-10 00:00:00',16.49,168,37),(714,19,'07/2017','2021-12-10 00:00:00',45.00,84,19),(715,37,'112/2018','2021-12-24 00:00:00',16.49,112,37),(716,19,'112/2018','2021-12-24 00:00:00',45.00,28,19),(717,33,'36/2020','2022-01-21 00:00:00',24.00,84,33),(718,36,'36/2020','2022-01-21 00:00:00',75.00,84,36),(719,49,'36/2020','2022-01-21 00:00:00',86.00,84,49),(720,46,'36/2020','2022-01-21 00:00:00',13.50,168,46),(721,11,'36/2020','2022-01-21 00:00:00',129.00,2,11),(722,92,'05/2022','2022-01-21 00:00:00',126.05,1,92),(723,49,'05/2022','2022-01-21 00:00:00',86.00,14,49),(724,72,'05/2022','2022-01-21 00:00:00',85.00,14,72),(725,92,'291/2021','2022-01-21 00:00:00',126.05,1,92),(726,4,'04/2022','2022-01-21 00:00:00',46.00,21,4),(727,23,'04/2022','2022-01-21 00:00:00',33.32,21,23),(728,3,'04/2022','2022-01-21 00:00:00',170.00,21,3),(729,64,'04/2022','2022-01-21 00:00:00',53.00,21,64),(730,85,'44/2017','2022-01-21 00:00:00',65.00,56,85),(731,33,'44/2017','2022-01-21 00:00:00',24.00,28,33),(732,83,'47/2017','2022-01-21 00:00:00',61.00,84,83),(733,70,'47/2017','2022-01-21 00:00:00',41.31,84,70),(734,12,'27/2017','2022-01-21 00:00:00',40.00,42,12),(735,21,'27/2017','2022-01-21 00:00:00',58.00,42,21),(736,23,'27/2017','2022-01-21 00:00:00',33.32,63,23),(737,48,'27/2017','2022-01-21 00:00:00',53.00,42,48),(738,47,'27/2017','2022-01-21 00:00:00',28.00,21,47),(739,49,'231/2021','2022-01-21 00:00:00',86.00,56,49),(740,92,'231/2021','2022-01-21 00:00:00',126.05,2,92),(741,11,'231/2021','2022-01-21 00:00:00',129.00,2,11),(742,93,'231/2021','2022-01-21 00:00:00',52.50,4,93),(743,46,'231/2021','2022-01-21 00:00:00',13.50,56,46),(744,82,'0130/2017','2022-01-21 00:00:00',52.80,168,82),(745,43,'0130/2017','2022-01-21 00:00:00',84.50,112,43),(746,65,'0130/2017','2022-01-21 00:00:00',84.00,56,65),(747,70,'0130/2017','2022-01-21 00:00:00',41.31,56,70),(748,50,'93/2017','2022-01-21 00:00:00',170.00,56,50),(749,48,'93/2017','2022-01-21 00:00:00',53.00,112,48),(750,83,'93/2017','2022-01-21 00:00:00',61.00,112,83),(751,82,'93/2017','2022-01-21 00:00:00',52.80,56,82),(752,34,'93/2017','2022-01-21 00:00:00',39.50,56,34),(753,46,'93/2017','2022-01-21 00:00:00',13.50,224,46),(754,34,'287/2021','2022-01-21 00:00:00',39.50,112,34),(755,46,'287/2021','2022-01-21 00:00:00',13.50,112,46),(756,69,'287/2021','2022-01-21 00:00:00',35.00,28,69),(757,82,'287/2021','2022-01-21 00:00:00',52.80,112,82),(758,82,'290/2021','2022-01-21 00:00:00',52.80,56,82),(759,21,'290/2021','2022-01-21 00:00:00',58.00,28,21),(760,68,'290/2021','2022-01-21 00:00:00',35.00,56,68),(761,36,'290/2021','2022-01-21 00:00:00',75.00,28,36),(762,35,'112/2017','2022-01-21 00:00:00',49.00,28,35),(763,46,'112/2017','2022-01-21 00:00:00',13.50,28,46),(764,59,'292/2021','2022-01-21 00:00:00',10.40,35,59),(765,70,'292/2021','2022-01-21 00:00:00',41.31,35,70),(766,68,'292/2021','2022-01-21 00:00:00',35.00,70,68),(767,57,'206/2021','2022-01-21 00:00:00',34.10,84,57),(768,34,'206/2021','2022-01-21 00:00:00',39.50,42,34),(769,34,'158/2020','2022-01-21 00:00:00',39.50,28,34),(770,35,'158/2020','2022-01-21 00:00:00',49.00,56,35),(771,46,'158/2020','2022-01-21 00:00:00',13.50,84,46),(772,83,'158/2020','2022-01-21 00:00:00',61.00,56,83),(773,82,'158/2020','2022-01-21 00:00:00',52.80,28,82),(774,49,'158/2020','2022-01-21 00:00:00',86.00,28,49),(775,49,'158/2020','2022-01-21 00:00:00',86.00,14,49),(776,35,'134/2020','2022-01-21 00:00:00',49.00,98,35),(777,46,'134/2020','2022-01-21 00:00:00',13.50,147,46),(778,83,'134/2020','2022-01-21 00:00:00',61.00,98,83),(779,71,'134/2020','2022-01-21 00:00:00',32.00,49,71),(780,12,'291/2021','2022-01-28 00:00:00',40.00,21,12),(781,34,'02/2022','2022-01-28 00:00:00',39.50,28,34),(782,35,'02/2022','2022-01-28 00:00:00',49.00,28,35),(783,46,'02/2022','2022-01-28 00:00:00',13.50,28,46),(784,47,'45/2017','2022-01-28 00:00:00',28.00,28,47),(785,48,'45/2017','2022-01-28 00:00:00',53.00,28,48),(786,83,'38/2017','2022-01-28 00:00:00',61.00,42,83),(787,46,'38/2017','2022-01-28 00:00:00',13.50,63,46),(788,49,'38/2017','2022-01-28 00:00:00',86.00,21,49),(789,47,'38/2017','2022-01-28 00:00:00',28.00,21,47),(790,48,'38/2017','2022-01-28 00:00:00',53.00,21,48),(791,26,'38/2017','2022-01-28 00:00:00',49.00,42,26),(792,25,'38/2017','2022-01-28 00:00:00',38.00,21,25),(793,5,'168/2021','2022-01-28 00:00:00',85.00,21,5),(794,48,'48/2017','2022-01-28 00:00:00',53.00,28,48),(795,47,'48/2017','2022-01-28 00:00:00',28.00,28,47),(796,71,'48/2017','2022-01-28 00:00:00',32.00,28,71),(797,70,'48/2017','2022-01-28 00:00:00',41.31,28,70),(798,46,'48/2017','2022-01-28 00:00:00',13.50,84,46),(799,34,'48/2017','2022-01-28 00:00:00',39.50,56,34),(800,68,'99/2019','2022-01-28 00:00:00',35.00,14,68),(801,28,'79/2021','2022-01-28 00:00:00',45.00,112,28),(802,83,'79/2021','2022-01-28 00:00:00',61.00,56,83),(803,4,'79/2021','2022-01-28 00:00:00',46.00,56,4),(804,83,'059/2021','2022-01-28 00:00:00',61.00,56,83),(805,82,'059/2021','2022-01-28 00:00:00',52.80,56,82),(806,70,'059/2021','2022-01-28 00:00:00',41.31,56,70),(807,21,'77/2017','2022-01-28 00:00:00',58.00,28,21),(808,12,'77/2017','2022-01-28 00:00:00',40.00,28,12),(809,25,'77/2017','2022-01-28 00:00:00',38.00,28,25),(810,48,'232/2021','2022-01-28 00:00:00',53.00,21,48),(811,83,'232/2021','2022-01-28 00:00:00',61.00,21,83),(812,81,'232/2021','2022-01-28 00:00:00',68.00,21,81),(813,36,'232/2021','2022-01-28 00:00:00',75.00,21,36),(814,46,'232/2021','2022-01-28 00:00:00',13.50,84,46),(815,35,'196/2021','2022-01-28 00:00:00',49.00,28,35),(816,46,'196/2021','2022-01-28 00:00:00',13.50,28,46),(817,83,'137/2017','2022-01-28 00:00:00',61.00,112,83),(818,26,'137/2017','2022-01-28 00:00:00',49.00,56,26),(819,25,'137/2017','2022-01-28 00:00:00',38.00,56,25),(820,72,'137/2017','2022-01-28 00:00:00',85.00,56,72),(821,71,'137/2017','2022-01-28 00:00:00',32.00,56,71),(822,46,'137/2017','2022-01-28 00:00:00',13.50,168,46),(823,76,'137/2017','2022-01-28 00:00:00',18.85,56,76),(824,58,'89/2018','2022-02-04 00:00:00',41.40,84,58),(825,72,'89/2018','2022-02-04 00:00:00',85.00,42,72),(826,24,'89/2018','2022-02-04 00:00:00',64.00,42,24),(827,4,'03/2022','2022-02-04 00:00:00',46.00,28,4),(828,5,'202/2021','2022-02-04 00:00:00',85.00,70,5),(829,4,'202/2021','2022-02-04 00:00:00',46.00,70,4),(830,21,'161/2019','2022-02-04 00:00:00',58.00,84,21),(831,44,'161/2019','2022-02-04 00:00:00',110.00,84,44),(832,83,'290/2021','2022-02-04 00:00:00',61.00,28,83),(833,21,'290/2021','2022-02-04 00:00:00',58.00,14,21),(834,68,'290/2021','2022-02-04 00:00:00',35.00,28,68),(835,35,'290/2021','2022-02-04 00:00:00',49.00,14,35),(836,82,'75/2019','2022-02-04 00:00:00',52.80,56,82),(837,83,'75/2019','2022-02-04 00:00:00',61.00,56,83),(838,68,'75/2019','2022-02-04 00:00:00',35.00,56,68),(839,46,'75/2019','2022-02-04 00:00:00',13.50,112,46),(840,92,'05/2022','2022-02-04 00:00:00',126.05,1,92),(841,49,'05/2022','2022-02-04 00:00:00',86.00,28,49),(842,71,'05/2022','2022-02-04 00:00:00',32.00,28,71),(843,47,'45/2017','2022-02-04 00:00:00',28.00,42,47),(844,48,'45/2017','2022-02-04 00:00:00',53.00,42,48),(845,5,'14/2021','2022-02-04 00:00:00',85.00,7,5),(846,6,'14/2021','2022-02-04 00:00:00',119.00,21,6),(847,82,'205/2019','2022-02-04 00:00:00',52.80,42,82),(848,27,'205/2019','2022-02-04 00:00:00',120.00,21,27),(849,81,'250/2021','2022-02-11 00:00:00',68.00,28,81),(850,83,'250/2021','2022-02-11 00:00:00',61.00,28,83),(851,12,'250/2021','2022-02-11 00:00:00',40.00,28,12),(852,69,'250/2021','2022-02-11 00:00:00',35.00,28,69),(853,81,'250/2021','2022-03-11 00:00:00',68.00,21,81),(854,83,'250/2021','2022-03-11 00:00:00',61.00,21,83),(855,12,'250/2021','2022-03-11 00:00:00',40.00,21,12),(856,69,'250/2021','2022-03-11 00:00:00',35.00,21,69),(857,37,'104/2018','2022-02-18 00:00:00',16.49,252,37),(858,81,'104/2018','2022-02-18 00:00:00',68.00,42,81),(859,28,'79/2021','2022-02-25 00:00:00',45.00,56,28),(860,83,'79/2021','2022-02-25 00:00:00',61.00,28,83),(861,4,'79/2021','2022-02-25 00:00:00',46.00,28,4),(862,70,'263/2021','2022-02-25 00:00:00',41.31,28,70),(863,4,'263/2021','2022-02-25 00:00:00',46.00,28,4),(864,19,'112/2018','2022-02-18 00:00:00',45.00,42,19),(865,37,'112/2018','2022-02-18 00:00:00',16.49,168,37),(866,81,'83/2019','2022-03-11 00:00:00',68.00,56,81),(867,84,'83/2019','2022-03-11 00:00:00',130.90,56,84),(868,59,'83/2019','2022-03-11 00:00:00',10.40,28,59),(869,57,'83/2019','2022-03-11 00:00:00',34.10,28,57),(870,49,'38/2017','2022-02-11 00:00:00',86.00,56,49),(871,47,'38/2017','2022-02-11 00:00:00',28.00,56,47),(872,83,'38/2017','2022-02-11 00:00:00',61.00,56,83),(873,46,'38/2017','2022-02-11 00:00:00',13.50,84,46),(874,26,'38/2017','2022-02-11 00:00:00',49.00,56,26),(875,25,'38/2017','2022-02-11 00:00:00',38.00,28,25),(876,49,'38/2017','2022-03-18 00:00:00',86.00,56,49),(877,47,'38/2017','2022-03-18 00:00:00',28.00,84,47),(878,83,'38/2017','2022-03-18 00:00:00',61.00,56,83),(879,46,'38/2017','2022-03-18 00:00:00',13.50,84,46),(880,26,'38/2017','2022-03-18 00:00:00',49.00,56,26),(881,25,'38/2017','2022-03-18 00:00:00',38.00,28,25),(882,5,'168/2021','2022-02-18 00:00:00',85.00,28,5),(883,5,'168/2021','2022-02-25 00:00:00',85.00,28,5),(884,82,'8/2014','2022-02-04 00:00:00',52.80,56,82),(885,82,'8/2014','2022-03-04 00:00:00',52.80,70,82),(886,47,'92/2018','2022-02-18 00:00:00',28.00,35,47),(887,48,'92/2018','2022-02-18 00:00:00',53.00,35,48),(888,83,'92/2018','2022-02-18 00:00:00',61.00,70,83),(889,68,'92/2018','2022-02-18 00:00:00',35.00,35,68),(890,95,'92/2018','2022-02-18 00:00:00',120.90,70,95),(891,69,'135/2020','2022-02-11 00:00:00',35.00,21,69),(892,12,'135/2020','2022-02-11 00:00:00',40.00,21,12),(893,82,'135/2020','2022-02-11 00:00:00',52.80,42,82),(894,83,'26/2017','2022-02-11 00:00:00',61.00,21,83),(895,85,'44/2017','2022-02-18 00:00:00',65.00,112,85),(896,34,'44/2017','2022-02-18 00:00:00',39.50,56,34),(897,48,'48/2017','2022-02-25 00:00:00',53.00,28,48),(898,47,'48/2017','2022-02-25 00:00:00',28.00,28,47),(899,71,'48/2017','2022-02-25 00:00:00',32.00,28,71),(900,70,'48/2017','2022-02-25 00:00:00',41.31,28,70),(901,46,'48/2017','2022-02-25 00:00:00',13.50,84,46),(902,34,'48/2017','2022-02-25 00:00:00',39.50,56,34),(903,68,'292/2021','2022-02-25 00:00:00',35.00,56,68),(904,69,'292/2021','2022-02-25 00:00:00',35.00,28,69),(905,70,'292/2021','2022-02-25 00:00:00',41.31,28,70),(906,92,'144/2019','2022-02-18 00:00:00',126.05,1,92),(907,46,'144/2019','2022-02-18 00:00:00',13.50,28,46),(908,36,'144/2019','2022-02-25 00:00:00',75.00,14,36),(909,92,'144/2019','2022-02-25 00:00:00',126.05,1,92),(910,46,'144/2019','2022-02-25 00:00:00',13.50,14,46),(911,92,'144/2019','2022-03-18 00:00:00',126.05,1,92),(912,46,'144/2019','2022-03-18 00:00:00',13.50,28,46),(913,93,'144/2019','2022-03-18 00:00:00',52.50,2,93),(914,36,'02/2022','2022-02-11 00:00:00',75.00,21,36),(915,46,'02/2022','2022-02-11 00:00:00',13.50,21,46),(916,36,'02/2022','2022-03-03 00:00:00',75.00,42,36),(917,46,'02/2022','2022-03-03 00:00:00',13.50,42,46),(918,46,'02/2022','2022-03-18 00:00:00',13.50,14,46),(919,69,'02/2022','2022-03-18 00:00:00',35.00,14,69),(920,8,'63/2018','2022-03-18 00:00:00',72.00,42,8),(921,9,'63/2018','2022-03-18 00:00:00',750.00,42,9),(922,35,'088/2017','2022-02-18 00:00:00',49.00,35,35),(923,36,'088/2017','2022-02-18 00:00:00',75.00,35,36),(924,46,'088/2017','2022-02-18 00:00:00',13.50,35,46),(925,33,'0112/2017','2022-03-18 00:00:00',24.00,35,33),(926,9,'88/2017','2022-03-18 00:00:00',750.00,70,9),(927,46,'88/2017','2022-03-18 00:00:00',13.50,35,46),(928,49,'88/2017','2022-03-18 00:00:00',86.00,35,49),(929,47,'88/2017','2022-03-18 00:00:00',28.00,35,47),(930,45,'211/2019','2022-02-18 00:00:00',46.20,112,45),(931,87,'211/2019','2022-02-18 00:00:00',54.00,84,87),(932,81,'211/2019','2022-02-18 00:00:00',68.00,112,81),(933,46,'211/2019','2022-02-18 00:00:00',13.50,168,46),(934,36,'211/2019','2022-02-18 00:00:00',75.00,56,36),(935,5,'211/2019','2022-02-18 00:00:00',85.00,56,5),(936,71,'49/2017','2021-07-02 00:00:00',32.00,56,71),(937,70,'49/2017','2021-07-02 00:00:00',41.31,56,70),(938,70,'49/2017','2021-08-27 00:00:00',41.31,56,70),(939,71,'49/2017','2021-08-27 00:00:00',32.00,56,71),(940,70,'49/2017','2022-03-04 00:00:00',41.31,84,70),(941,71,'49/2017','2022-03-04 00:00:00',32.00,84,71),(942,5,'04/2022','2022-02-11 00:00:00',85.00,28,5),(943,3,'04/2022','2022-02-11 00:00:00',170.00,28,3),(944,64,'04/2022','2022-02-11 00:00:00',53.00,28,64),(945,5,'04/2022','2022-03-11 00:00:00',85.00,7,5),(946,4,'04/2022','2022-03-11 00:00:00',46.00,7,4),(947,65,'04/2022','2022-03-11 00:00:00',84.00,7,65),(948,3,'04/2022','2022-03-11 00:00:00',170.00,7,3),(949,5,'04/2022','2022-03-18 00:00:00',85.00,42,5),(950,4,'04/2022','2022-03-18 00:00:00',46.00,42,4),(951,65,'04/2022','2022-03-18 00:00:00',84.00,42,65),(952,92,'291/2021','2022-03-18 00:00:00',126.05,2,92),(953,92,'291/2021','2022-02-18 00:00:00',126.05,1,92),(954,20,'44/2020','2021-10-08 00:00:00',95.00,42,20),(955,22,'44/2020','2021-10-08 00:00:00',39.00,42,22),(956,56,'44/2020','2021-10-08 00:00:00',61.90,220,56),(957,12,'67/2021','2022-02-18 00:00:00',40.00,42,12),(958,33,'67/2021','2022-02-18 00:00:00',24.00,21,33),(959,82,'287/2021','2022-03-18 00:00:00',52.80,42,82),(960,83,'287/2021','2022-03-18 00:00:00',61.00,42,83),(961,34,'287/2021','2022-03-18 00:00:00',39.50,126,34),(962,46,'287/2021','2022-03-18 00:00:00',13.50,84,46),(963,50,'01/2018','2022-03-18 00:00:00',170.00,42,50),(964,83,'01/2018','2022-03-18 00:00:00',61.00,84,83),(965,68,'01/2018','2022-03-18 00:00:00',35.00,42,68),(966,67,'01/2018','2022-03-18 00:00:00',21.50,42,67),(967,12,'01/2018','2022-03-18 00:00:00',40.00,42,12),(968,28,'04/2018','2022-02-11 00:00:00',45.00,49,28),(969,46,'04/2018','2022-02-11 00:00:00',13.50,28,46),(970,39,'04/2018','2022-02-11 00:00:00',69.00,28,39),(971,28,'04/2018','2022-03-11 00:00:00',45.00,84,28),(972,39,'04/2018','2022-03-11 00:00:00',69.00,56,39),(973,72,'182/2021','2022-03-04 00:00:00',85.00,70,72),(974,46,'182/2021','2022-03-04 00:00:00',13.50,210,46),(975,83,'182/2021','2022-03-04 00:00:00',61.00,140,83),(976,25,'182/2021','2022-03-04 00:00:00',38.00,70,25),(977,26,'182/2021','2022-03-04 00:00:00',49.00,70,26),(978,48,'182/2021','2022-03-04 00:00:00',53.00,70,48),(979,93,'231/2021','2022-03-03 00:00:00',52.50,2,93),(980,46,'231/2021','2022-03-03 00:00:00',13.50,14,46),(981,92,'231/2021','2022-03-03 00:00:00',126.05,1,92),(982,49,'231/2021','2022-03-03 00:00:00',86.00,14,49),(983,11,'231/2021','2022-03-03 00:00:00',129.00,1,11),(984,93,'231/2021','2022-03-18 00:00:00',52.50,4,93),(985,46,'231/2021','2022-03-18 00:00:00',13.50,56,46),(986,92,'231/2021','2022-03-18 00:00:00',126.05,3,92),(987,49,'231/2021','2022-03-18 00:00:00',86.00,26,49),(988,11,'231/2021','2022-03-18 00:00:00',129.00,4,11),(989,70,'89/2018','2022-03-18 00:00:00',41.31,56,70),(990,71,'89/2018','2022-03-18 00:00:00',32.00,56,71),(991,58,'89/2018','2022-03-18 00:00:00',41.40,112,58),(992,24,'89/2018','2022-03-18 00:00:00',64.00,56,24),(993,65,'59/2021','2022-02-11 00:00:00',84.00,84,65),(994,19,'59/2021','2022-02-11 00:00:00',45.00,42,19),(995,20,'59/2021','2022-02-11 00:00:00',95.00,84,20),(996,47,'45/2017','2022-03-18 00:00:00',28.00,70,47),(997,48,'45/2017','2022-03-18 00:00:00',53.00,70,48),(998,71,'078/2021','2022-02-11 00:00:00',32.00,28,71),(999,70,'078/2021','2022-02-11 00:00:00',41.31,28,70),(1000,37,'078/2021','2022-02-11 00:00:00',16.49,28,37),(1001,36,'078/2021','2022-02-11 00:00:00',75.00,56,36),(1002,46,'078/2021','2022-02-11 00:00:00',13.50,28,46),(1003,68,'54/2017','2022-02-11 00:00:00',35.00,56,68),(1004,82,'54/2017','2022-02-11 00:00:00',52.80,56,82),(1005,83,'54/2017','2022-02-11 00:00:00',61.00,56,83),(1006,46,'54/2017','2022-02-11 00:00:00',13.50,56,46),(1007,8,'54/2017','2022-02-11 00:00:00',72.00,56,8),(1008,64,'161/2019','2022-03-18 00:00:00',53.00,28,64),(1009,69,'161/2019','2022-03-18 00:00:00',35.00,56,69),(1010,89,'161/2019','2022-03-18 00:00:00',34.50,14,89),(1011,44,'161/2019','2022-03-18 00:00:00',110.00,112,44),(1012,21,'161/2019','2022-03-18 00:00:00',58.00,112,21),(1013,12,'248/2021','2022-01-28 00:00:00',40.00,21,12),(1014,12,'248/2021','2022-02-25 00:00:00',40.00,28,12),(1015,35,'77/2021','2022-02-11 00:00:00',49.00,28,35),(1016,36,'77/2021','2022-02-11 00:00:00',75.00,28,36),(1017,83,'77/2021','2022-02-11 00:00:00',61.00,56,83),(1018,47,'77/2021','2022-02-11 00:00:00',28.00,28,47),(1019,46,'77/2021','2022-02-11 00:00:00',13.50,84,46),(1020,34,'106/2017','2022-03-11 00:00:00',39.50,84,34),(1021,46,'106/2017','2022-03-11 00:00:00',13.50,84,46),(1022,46,'088/2017','2022-03-25 00:00:00',13.50,56,46),(1023,35,'088/2017','2022-03-25 00:00:00',49.00,56,35),(1024,36,'088/2017','2022-03-25 00:00:00',75.00,56,36),(1025,82,'205/2019','2022-02-25 00:00:00',52.80,56,82),(1026,27,'205/2019','2022-02-25 00:00:00',120.00,28,27),(1027,27,'205/2019','2022-03-25 00:00:00',120.00,56,27),(1028,82,'205/2019','2022-03-25 00:00:00',52.80,112,82),(1029,5,'168/2021','2022-03-25 00:00:00',85.00,42,5),(1030,72,'137/2017','2022-03-25 00:00:00',85.00,56,72),(1031,70,'137/2017','2022-03-25 00:00:00',41.31,56,70),(1032,83,'137/2017','2022-03-25 00:00:00',61.00,112,83),(1033,26,'137/2017','2022-03-25 00:00:00',49.00,56,26),(1034,25,'137/2017','2022-03-25 00:00:00',38.00,56,25),(1035,46,'137/2017','2022-03-25 00:00:00',13.50,168,46),(1036,76,'137/2017','2022-03-25 00:00:00',18.85,56,76),(1037,47,'45/2017','2022-05-06 00:00:00',28.00,84,47),(1038,48,'45/2017','2022-05-06 00:00:00',53.00,84,48),(1039,11,'52/2022','2022-02-18 00:00:00',129.00,2,11),(1040,92,'52/2022','2022-02-18 00:00:00',126.05,1,92),(1041,92,'52/2022','2022-03-04 00:00:00',126.05,2,92),(1042,11,'52/2022','2022-03-04 00:00:00',129.00,2,11),(1043,92,'52/2022','2022-03-18 00:00:00',126.05,4,92),(1044,11,'52/2022','2022-03-18 00:00:00',129.00,3,11),(1045,92,'52/2022','2022-06-10 00:00:00',126.05,2,92),(1046,11,'52/2022','2022-06-10 00:00:00',129.00,2,11),(1047,92,'52/2022','2022-06-24 00:00:00',126.05,4,92),(1048,11,'52/2022','2022-06-24 00:00:00',129.00,4,11),(1049,28,'79/2021','2022-03-25 00:00:00',45.00,112,28),(1050,83,'79/2021','2022-03-25 00:00:00',61.00,56,83),(1051,4,'79/2021','2022-03-25 00:00:00',46.00,56,4),(1052,28,'79/2021','2022-04-08 00:00:00',45.00,56,28),(1053,83,'79/2021','2022-04-08 00:00:00',61.00,28,83),(1054,4,'79/2021','2022-04-08 00:00:00',46.00,28,4),(1055,28,'79/2021','2022-05-06 00:00:00',45.00,112,28),(1056,83,'79/2021','2022-05-06 00:00:00',61.00,56,83),(1057,4,'79/2021','2022-05-06 00:00:00',46.00,56,4),(1058,81,'250/2021','2022-04-01 00:00:00',68.00,56,81),(1059,83,'250/2021','2022-04-01 00:00:00',61.00,56,83),(1060,12,'250/2021','2022-04-01 00:00:00',40.00,56,12),(1061,69,'250/2021','2022-04-01 00:00:00',35.00,56,69),(1062,69,'250/2021','2022-05-27 00:00:00',35.00,4,69),(1063,81,'250/2021','2022-05-27 00:00:00',68.00,7,81),(1064,83,'250/2021','2022-05-27 00:00:00',61.00,7,83),(1065,22,'250/2021','2022-05-27 00:00:00',39.00,7,22),(1066,81,'250/2021','2022-06-03 00:00:00',68.00,21,81),(1067,83,'250/2021','2022-06-03 00:00:00',61.00,21,83),(1068,12,'250/2021','2022-06-03 00:00:00',40.00,21,12),(1069,69,'250/2021','2022-06-03 00:00:00',35.00,21,69),(1070,19,'250/2021','2022-06-24 00:00:00',45.00,14,19),(1071,81,'250/2021','2022-06-24 00:00:00',68.00,14,81),(1072,83,'250/2021','2022-06-24 00:00:00',61.00,14,83),(1073,12,'250/2021','2022-06-24 00:00:00',40.00,14,12),(1074,69,'250/2021','2022-06-24 00:00:00',35.00,14,69),(1075,37,'104/2018','2022-05-13 00:00:00',16.49,252,37),(1076,81,'104/2018','2022-05-13 00:00:00',68.00,84,81),(1077,69,'02/2022','2022-04-01 00:00:00',35.00,56,69),(1078,46,'02/2022','2022-04-01 00:00:00',13.50,14,46),(1079,68,'02/2022','2022-05-06 00:00:00',35.00,56,68),(1080,46,'02/2022','2022-05-06 00:00:00',13.50,28,46),(1081,37,'07/2017','2022-05-27 00:00:00',16.49,112,37),(1082,19,'07/2017','2022-05-27 00:00:00',45.00,56,19),(1083,70,'263/2021','2022-03-25 00:00:00',41.31,56,70),(1084,4,'263/2021','2022-03-25 00:00:00',46.00,56,4),(1085,71,'263/2021','2022-05-20 00:00:00',32.00,70,71),(1086,4,'263/2021','2022-05-20 00:00:00',46.00,70,4),(1087,81,'83/2019','2022-04-08 00:00:00',68.00,112,81),(1088,84,'83/2019','2022-04-08 00:00:00',130.90,112,84),(1089,59,'83/2019','2022-04-08 00:00:00',10.40,56,59),(1090,57,'83/2019','2022-04-08 00:00:00',34.10,56,57),(1091,83,'83/2019','2022-06-10 00:00:00',61.00,56,83),(1092,84,'83/2019','2022-06-10 00:00:00',130.90,56,84),(1093,59,'83/2019','2022-06-10 00:00:00',10.40,28,59),(1094,57,'83/2019','2022-06-10 00:00:00',34.10,28,57),(1095,58,'206/2021','2022-05-20 00:00:00',41.40,84,58),(1096,34,'206/2021','2022-05-20 00:00:00',39.50,42,34),(1097,82,'059/2021','2022-03-25 00:00:00',52.80,84,82),(1098,83,'059/2021','2022-03-25 00:00:00',61.00,84,83),(1099,70,'059/2021','2022-03-25 00:00:00',41.31,84,70),(1100,82,'059/2021','2022-06-17 00:00:00',52.80,84,82),(1101,83,'059/2021','2022-06-17 00:00:00',61.00,84,83),(1102,70,'059/2021','2022-06-17 00:00:00',41.31,84,70),(1103,81,'232/2021','2022-02-25 00:00:00',68.00,7,81),(1104,83,'232/2021','2022-02-25 00:00:00',61.00,7,83),(1105,36,'232/2021','2022-02-25 00:00:00',75.00,7,36),(1106,46,'232/2021','2022-02-25 00:00:00',13.50,21,46),(1107,47,'232/2021','2022-02-25 00:00:00',28.00,7,47),(1108,48,'232/2021','2022-03-04 00:00:00',53.00,28,48),(1109,46,'232/2021','2022-03-04 00:00:00',13.50,84,46),(1110,81,'232/2021','2022-03-04 00:00:00',68.00,28,81),(1111,83,'232/2021','2022-03-04 00:00:00',61.00,28,83),(1112,36,'232/2021','2022-03-04 00:00:00',75.00,28,36),(1113,83,'232/2021','2022-04-01 00:00:00',61.00,42,83),(1114,81,'232/2021','2022-04-01 00:00:00',68.00,42,81),(1115,36,'232/2021','2022-04-01 00:00:00',75.00,42,36),(1116,46,'232/2021','2022-04-01 00:00:00',13.50,124,46),(1117,48,'232/2021','2022-04-01 00:00:00',53.00,42,48),(1118,81,'232/2021','2022-05-13 00:00:00',68.00,42,81),(1119,36,'232/2021','2022-05-13 00:00:00',75.00,42,36),(1120,46,'232/2021','2022-05-13 00:00:00',13.50,124,46),(1121,48,'232/2021','2022-05-13 00:00:00',53.00,42,48),(1122,81,'232/2021','2022-06-24 00:00:00',68.00,14,81),(1123,83,'232/2021','2022-06-24 00:00:00',61.00,14,83),(1124,46,'232/2021','2022-06-24 00:00:00',13.50,42,46),(1125,48,'232/2021','2022-06-24 00:00:00',53.00,14,48),(1126,34,'36/2020','2022-04-15 00:00:00',39.50,28,34),(1127,35,'36/2020','2022-04-15 00:00:00',49.00,28,35),(1128,49,'36/2020','2022-04-15 00:00:00',86.00,28,49),(1129,46,'36/2020','2022-04-15 00:00:00',13.50,56,46),(1130,82,'36/2020','2022-04-15 00:00:00',52.80,84,82),(1131,82,'136/2022','2022-08-05 00:00:00',52.80,21,82),(1132,71,'136/2022','2022-08-05 00:00:00',32.00,7,71),(1133,82,'136/2022','2022-08-12 00:00:00',52.80,42,82),(1134,71,'136/2022','2022-08-12 00:00:00',32.00,14,71),(1135,12,'161/2019','2021-11-19 00:00:00',40.00,56,12),(1136,44,'161/2019','2021-11-19 00:00:00',110.00,56,44),(1137,65,'161/2019','2021-11-19 00:00:00',84.00,28,65),(1138,12,'161/2019','2021-12-03 00:00:00',40.00,21,12),(1139,21,'161/2019','2021-12-03 00:00:00',58.00,21,21),(1140,44,'161/2019','2021-12-03 00:00:00',110.00,42,44),(1141,64,'161/2019','2021-12-03 00:00:00',53.00,21,64),(1142,44,'161/2019','2021-12-17 00:00:00',110.00,42,44),(1143,21,'161/2019','2021-12-17 00:00:00',58.00,42,21),(1144,64,'161/2019','2021-12-17 00:00:00',53.00,21,64),(1145,21,'161/2019','2022-01-07 00:00:00',58.00,56,21),(1146,44,'161/2019','2022-01-07 00:00:00',110.00,56,44),(1147,64,'161/2019','2022-01-07 00:00:00',53.00,28,64),(1148,21,'161/2019','2022-02-04 00:00:00',58.00,84,21),(1149,44,'161/2019','2022-02-04 00:00:00',110.00,84,44),(1150,21,'161/2019','2022-02-18 00:00:00',58.00,112,21),(1151,44,'161/2019','2022-02-18 00:00:00',110.00,112,44),(1152,89,'161/2019','2022-02-18 00:00:00',34.50,20,89),(1153,64,'161/2019','2022-02-18 00:00:00',53.00,28,64),(1154,69,'161/2019','2022-02-18 00:00:00',35.00,56,69),(1155,82,'135/2022','2022-08-05 00:00:00',52.80,21,82),(1156,68,'135/2022','2022-08-05 00:00:00',35.00,14,68),(1157,34,'135/2022','2022-08-05 00:00:00',39.50,7,34),(1158,36,'135/2022','2022-08-05 00:00:00',75.00,7,36),(1159,72,'135/2022','2022-08-05 00:00:00',85.00,7,72),(1160,46,'135/2022','2022-08-05 00:00:00',13.50,21,46),(1161,48,'135/2022','2022-08-05 00:00:00',53.00,7,48),(1162,82,'135/2022','2022-08-12 00:00:00',52.80,42,82),(1163,68,'135/2022','2022-08-12 00:00:00',35.00,28,68),(1164,34,'135/2022','2022-08-12 00:00:00',39.50,14,34),(1165,36,'135/2022','2022-08-12 00:00:00',75.00,14,36),(1166,72,'135/2022','2022-08-12 00:00:00',85.00,14,72),(1167,46,'135/2022','2022-08-12 00:00:00',13.50,42,46),(1168,48,'135/2022','2022-08-12 00:00:00',53.00,14,48),(1169,82,'135/2022','2022-08-26 00:00:00',52.80,21,82),(1170,68,'135/2022','2022-08-26 00:00:00',35.00,14,68),(1171,34,'135/2022','2022-08-26 00:00:00',39.50,7,34),(1172,36,'135/2022','2022-08-26 00:00:00',75.00,7,36),(1173,71,'135/2022','2022-08-26 00:00:00',32.00,7,71),(1174,46,'135/2022','2022-08-26 00:00:00',13.50,21,46),(1175,48,'135/2022','2022-08-26 00:00:00',53.00,7,48),(1176,28,'04/2018','2021-09-10 00:00:00',45.00,63,28),(1177,46,'04/2018','2021-09-10 00:00:00',13.50,42,46),(1178,39,'04/2018','2021-09-10 00:00:00',69.00,21,39),(1179,28,'04/2018','2021-10-22 00:00:00',45.00,42,28),(1180,46,'04/2018','2021-10-22 00:00:00',13.50,28,46),(1181,39,'04/2018','2021-10-22 00:00:00',69.00,14,39),(1182,28,'04/2018','2022-08-19 00:00:00',45.00,32,28),(1183,35,'04/2018','2022-08-19 00:00:00',49.00,42,35),(1184,46,'04/2018','2022-08-19 00:00:00',13.50,21,46),(1185,35,'04/2018','2022-08-12 00:00:00',49.00,28,35),(1186,46,'04/2018','2022-08-12 00:00:00',13.50,14,46),(1187,28,'04/2018','2022-08-12 00:00:00',45.00,22,28),(1188,36,'04/2018','2022-08-05 00:00:00',75.00,7,36),(1189,28,'04/2018','2022-08-05 00:00:00',45.00,11,28),(1190,28,'04/2018','2022-07-29 00:00:00',45.00,42,28),(1191,34,'04/2018','2022-07-29 00:00:00',39.50,28,34),(1192,28,'04/2018','2022-07-01 00:00:00',45.00,42,28),(1193,39,'04/2018','2022-07-01 00:00:00',69.00,28,39),(1194,40,'04/2018','2022-07-01 00:00:00',40.00,28,40),(1195,28,'04/2018','2022-05-06 00:00:00',45.00,84,28),(1196,40,'04/2018','2022-05-06 00:00:00',40.00,56,40),(1197,39,'04/2018','2022-05-06 00:00:00',69.00,56,39),(1198,40,'04/2018','2022-03-11 00:00:00',40.00,168,40),(1199,28,'04/2018','2022-03-11 00:00:00',45.00,126,28),(1200,40,'04/2018','2022-02-11 00:00:00',40.00,56,40),(1201,46,'04/2018','2022-02-11 00:00:00',13.50,28,46),(1202,28,'04/2018','2022-02-11 00:00:00',45.00,42,28),(1203,28,'04/2018','2021-12-17 00:00:00',45.00,42,28),(1204,46,'04/2018','2021-12-17 00:00:00',13.50,28,46),(1205,40,'04/2018','2021-12-17 00:00:00',40.00,56,40),(1206,28,'04/2018','2021-11-19 00:00:00',45.00,42,28),(1207,46,'04/2018','2021-11-19 00:00:00',13.50,28,46),(1208,40,'04/2018','2021-11-19 00:00:00',40.00,56,40),(1209,28,'04/2018','2021-08-06 00:00:00',45.00,63,28),(1210,46,'04/2018','2021-08-06 00:00:00',13.50,42,46),(1211,40,'04/2018','2021-08-06 00:00:00',40.00,84,40),(1212,28,'04/2018','2021-07-09 00:00:00',45.00,28,28),(1213,33,'04/2018','2021-07-09 00:00:00',24.00,28,33),(1214,46,'04/2018','2021-07-09 00:00:00',13.50,28,46),(1215,40,'04/2018','2021-07-09 00:00:00',40.00,56,40),(1216,28,'04/2018','2021-06-11 00:00:00',45.00,56,28),(1217,33,'04/2018','2021-06-11 00:00:00',24.00,28,33),(1218,46,'04/2018','2021-06-11 00:00:00',13.50,28,46),(1219,40,'04/2018','2021-06-11 00:00:00',40.00,56,40),(1220,33,'04/2018','2021-05-07 00:00:00',24.00,28,33),(1221,46,'04/2018','2021-05-07 00:00:00',13.50,28,46),(1222,28,'04/2018','2021-05-07 00:00:00',45.00,42,28),(1223,40,'04/2018','2021-05-07 00:00:00',40.00,56,40),(1224,34,'04/2018','2021-04-08 00:00:00',39.50,28,34),(1225,28,'04/2018','2021-04-08 00:00:00',45.00,42,28),(1226,46,'04/2018','2021-04-08 00:00:00',13.50,28,46),(1227,40,'04/2018','2021-04-08 00:00:00',40.00,56,40),(1228,33,'130/2022','2022-07-29 00:00:00',24.00,14,33),(1229,34,'130/2022','2022-08-12 00:00:00',39.50,14,34),(1230,35,'130/2022','2022-08-26 00:00:00',49.00,14,35),(1231,70,'130/2022','2022-08-26 00:00:00',41.31,14,70),(1232,34,'202/2022','2022-09-30 00:00:00',39.50,28,34),(1233,46,'202/2022','2022-09-30 00:00:00',13.50,56,46),(1234,34,'202/2022','2022-09-16 00:00:00',39.50,14,34),(1235,46,'202/2022','2022-09-16 00:00:00',13.50,14,46),(1236,83,'204/2022','2022-09-30 00:00:00',61.00,14,83),(1237,68,'204/2022','2022-09-30 00:00:00',35.00,21,68),(1238,28,'204/2022','2022-09-30 00:00:00',45.00,7,28),(1239,46,'204/2022','2022-09-30 00:00:00',13.50,14,46),(1240,33,'200/2022','2022-09-30 00:00:00',24.00,14,33),(1241,33,'115/2022','2022-09-09 00:00:00',24.00,84,33),(1242,33,'115/2022','2022-07-15 00:00:00',24.00,56,33),(1243,33,'115/2022','2022-07-08 00:00:00',24.00,7,33),(1244,12,'201/2022','2022-09-30 00:00:00',40.00,7,12),(1245,33,'201/2022','2022-09-30 00:00:00',24.00,4,33),(1246,81,'203/2022','2022-09-30 00:00:00',68.00,7,81),(1247,83,'203/2022','2022-09-30 00:00:00',61.00,7,83),(1248,69,'203/2022','2022-09-30 00:00:00',35.00,7,69),(1249,67,'203/2022','2022-09-30 00:00:00',21.50,7,67),(1250,22,'203/2022','2022-09-30 00:00:00',39.00,7,22),(1251,91,'203/2022','2022-09-30 00:00:00',28.00,7,91),(1252,82,'171/2022','2022-09-02 00:00:00',52.80,14,82),(1253,34,'171/2022','2022-09-02 00:00:00',39.50,7,34),(1254,83,'155/2022','2022-08-19 00:00:00',61.00,14,83),(1255,34,'155/2022','2022-08-19 00:00:00',39.50,7,34),(1256,83,'155/2022','2022-08-26 00:00:00',61.00,84,83),(1257,34,'155/2022','2022-08-26 00:00:00',39.50,42,34),(1258,29,'92/2022','2022-09-09 00:00:00',16.30,168,29),(1259,25,'92/2022','2022-09-09 00:00:00',38.00,56,25),(1260,46,'92/2022','2022-09-09 00:00:00',13.50,112,46),(1261,29,'205/2022','2022-09-23 00:00:00',16.30,42,29),(1262,36,'205/2022','2022-09-23 00:00:00',75.00,28,36),(1263,46,'205/2022','2022-09-23 00:00:00',13.50,28,46),(1264,20,'205/2022','2022-09-23 00:00:00',95.00,14,20),(1265,12,'205/2022','2022-09-23 00:00:00',40.00,14,12),(1266,56,'205/2022','2022-09-23 00:00:00',61.90,28,56),(1267,46,'190/2022','2022-09-30 00:00:00',13.50,28,46),(1268,35,'190/2022','2022-09-30 00:00:00',49.00,28,35),(1269,89,'190/2022','2022-09-30 00:00:00',34.50,28,89),(1270,67,'292/2021','2022-03-25 00:00:00',21.50,55,67),(1271,70,'292/2021','2022-03-25 00:00:00',41.31,55,70),(1272,67,'292/2021','2022-05-05 00:00:00',21.50,84,67),(1273,70,'292/2021','2022-05-05 00:00:00',41.31,84,70),(1274,67,'292/2021','2022-08-12 00:00:00',21.50,80,67),(1275,70,'292/2021','2022-08-28 00:00:00',41.31,56,70),(1276,48,'48/2017','2022-03-25 00:00:00',53.00,30,48),(1277,47,'48/2017','2022-03-25 00:00:00',28.00,30,47),(1278,71,'48/2017','2022-03-25 00:00:00',32.00,30,71),(1279,70,'48/2017','2022-03-25 00:00:00',41.31,30,70),(1280,46,'48/2017','2022-03-25 00:00:00',13.50,90,46),(1281,34,'48/2017','2022-03-25 00:00:00',39.50,60,34),(1282,48,'48/2017','2022-04-22 00:00:00',53.00,43,48),(1283,47,'48/2017','2022-04-22 00:00:00',28.00,45,47),(1284,71,'48/2017','2022-04-22 00:00:00',32.00,45,71),(1285,70,'48/2017','2022-04-22 00:00:00',41.31,45,70),(1286,46,'48/2017','2022-04-22 00:00:00',13.50,135,46),(1287,34,'48/2017','2022-04-22 00:00:00',39.50,70,34),(1288,48,'48/2017','2022-06-03 00:00:00',53.00,20,48),(1289,47,'48/2017','2022-06-03 00:00:00',28.00,20,47),(1290,71,'48/2017','2022-06-03 00:00:00',32.00,20,71),(1291,70,'48/2017','2022-06-03 00:00:00',41.31,20,70),(1292,46,'48/2017','2022-06-03 00:00:00',13.50,60,46),(1293,34,'48/2017','2022-06-03 00:00:00',39.50,40,34),(1294,48,'48/2017','2022-06-24 00:00:00',53.00,30,48),(1295,47,'48/2017','2022-06-24 00:00:00',28.00,30,47),(1296,71,'48/2017','2022-06-24 00:00:00',32.00,30,71),(1297,70,'48/2017','2022-06-24 00:00:00',41.31,30,70),(1298,46,'48/2017','2022-06-24 00:00:00',13.50,90,46),(1299,34,'48/2017','2022-06-24 00:00:00',39.50,60,34),(1300,48,'48/2017','2022-07-22 00:00:00',53.00,30,48),(1301,47,'48/2017','2022-07-22 00:00:00',28.00,30,47),(1302,71,'48/2017','2022-07-22 00:00:00',32.00,30,71),(1303,70,'48/2017','2022-07-22 00:00:00',41.31,30,70),(1304,46,'48/2017','2022-07-22 00:00:00',13.50,90,46),(1305,34,'48/2017','2022-07-22 00:00:00',39.50,60,34),(1306,49,'48/2017','2022-09-30 00:00:00',86.00,43,49),(1307,35,'48/2017','2022-09-30 00:00:00',49.00,43,35),(1308,46,'48/2017','2022-09-30 00:00:00',13.50,129,46),(1309,5,'04/2022','2022-10-07 00:00:00',85.00,28,5),(1310,4,'04/2022','2022-10-07 00:00:00',46.00,28,4),(1311,65,'04/2022','2022-10-07 00:00:00',84.00,28,65),(1312,3,'04/2022','2022-10-07 00:00:00',170.00,28,3),(1313,82,'135/2020','2022-10-07 00:00:00',52.80,28,82),(1314,69,'135/2020','2022-10-07 00:00:00',35.00,14,69),(1315,12,'135/2020','2022-10-07 00:00:00',40.00,14,12),(1316,46,'135/2020','2022-10-07 00:00:00',13.50,14,46),(1317,5,'202/2021','2022-10-07 00:00:00',85.00,28,5),(1318,20,'59/2021','2022-10-07 00:00:00',95.00,14,20),(1319,65,'59/2021','2022-10-07 00:00:00',84.00,14,65),(1320,19,'59/2021','2022-10-07 00:00:00',45.00,7,19),(1321,49,'48/2017','2022-10-07 00:00:00',86.00,28,49),(1322,47,'48/2017','2022-10-07 00:00:00',28.00,28,47),(1323,31,'48/2017','2022-10-07 00:00:00',56.00,28,31),(1324,46,'48/2017','2022-10-07 00:00:00',13.50,84,46),(1325,49,'48/2017','2022-10-07 00:00:00',86.00,28,49),(1326,47,'48/2017','2022-10-07 00:00:00',28.00,28,47),(1327,31,'48/2017','2022-10-07 00:00:00',56.00,28,31),(1328,46,'48/2017','2022-10-07 00:00:00',13.50,84,46),(1329,82,'247/2021','2022-10-07 00:00:00',52.80,7,82),(1330,83,'247/2021','2022-10-07 00:00:00',61.00,7,83),(1331,35,'247/2021','2022-10-07 00:00:00',49.00,7,35),(1332,34,'247/2021','2022-10-07 00:00:00',39.50,7,34),(1333,71,'247/2021','2022-10-07 00:00:00',32.00,7,71),(1334,46,'247/2021','2022-10-07 00:00:00',13.50,21,46),(1335,82,'0130/2017','2022-10-07 00:00:00',52.80,30,82),(1336,43,'0130/2017','2022-10-07 00:00:00',84.50,20,43),(1337,65,'0130/2017','2022-10-07 00:00:00',84.00,10,65),(1338,82,'118/2022','2022-10-07 00:00:00',52.80,28,82),(1339,83,'118/2022','2022-10-07 00:00:00',61.00,28,83),(1340,47,'118/2022','2022-10-07 00:00:00',28.00,28,47),(1341,50,'9/2018','2022-10-07 00:00:00',170.00,28,50),(1342,49,'9/2018','2022-10-07 00:00:00',86.00,28,49),(1343,46,'9/2018','2022-10-07 00:00:00',13.50,56,46),(1344,34,'9/2018','2022-10-07 00:00:00',39.50,42,34),(1345,35,'9/2018','2022-10-07 00:00:00',49.00,28,35),(1346,34,'170/2022','2022-08-26 00:00:00',39.50,7,34),(1347,34,'170/2022','2022-09-02 00:00:00',39.50,28,34),(1348,34,'170/2022','2022-10-07 00:00:00',39.50,28,34),(1349,82,'059/2021','2022-10-07 00:00:00',52.80,28,82),(1350,83,'059/2021','2022-10-07 00:00:00',61.00,28,83),(1351,70,'059/2021','2022-10-07 00:00:00',41.31,28,70),(1352,34,'138/2019','2022-10-07 00:00:00',39.50,28,34),(1353,35,'138/2019','2022-10-07 00:00:00',49.00,56,35),(1354,22,'201/2022','2022-10-07 00:00:00',39.00,14,22),(1355,33,'201/2022','2022-10-07 00:00:00',24.00,7,33),(1356,34,'201/2022','2022-10-07 00:00:00',39.50,7,34),(1357,83,'204/2022','2022-10-07 00:00:00',61.00,28,83),(1358,82,'204/2022','2022-10-07 00:00:00',52.80,14,82),(1359,68,'204/2022','2022-10-07 00:00:00',35.00,21,68),(1360,28,'204/2022','2022-10-07 00:00:00',45.00,14,28),(1361,46,'204/2022','2022-10-07 00:00:00',13.50,28,46),(1362,81,'203/2022','2022-10-07 00:00:00',68.00,14,81),(1363,83,'203/2022','2022-10-07 00:00:00',61.00,14,83),(1364,69,'203/2022','2022-10-07 00:00:00',35.00,10,69),(1365,12,'203/2022','2022-10-07 00:00:00',40.00,14,12),(1366,90,'203/2022','2022-10-07 00:00:00',23.00,14,90),(1367,45,'211/2019','2022-10-07 00:00:00',46.20,56,45),(1368,87,'211/2019','2022-10-07 00:00:00',54.00,21,87),(1369,81,'211/2019','2022-10-07 00:00:00',68.00,56,81),(1370,35,'211/2019','2022-10-07 00:00:00',49.00,28,35),(1371,5,'211/2019','2022-10-07 00:00:00',85.00,28,5),(1372,46,'211/2019','2022-10-07 00:00:00',13.50,56,46),(1373,76,'211/2019','2022-10-07 00:00:00',18.85,56,76),(1374,19,'080/2020','2022-10-07 00:00:00',45.00,21,19),(1375,45,'080/2020','2022-10-07 00:00:00',46.20,14,45),(1376,12,'02/2022','2022-10-07 00:00:00',40.00,14,12),(1377,12,'02/2022','2022-10-07 00:00:00',40.00,28,12),(1378,82,'26/2017','2022-10-07 00:00:00',52.80,28,82),(1379,83,'26/2017','2022-10-07 00:00:00',61.00,28,83),(1380,34,'26/2017','2022-10-07 00:00:00',39.50,28,34),(1381,83,'137/2017','2022-10-07 00:00:00',61.00,28,83),(1382,26,'137/2017','2022-10-07 00:00:00',49.00,21,26),(1383,76,'137/2017','2022-10-07 00:00:00',18.85,28,76),(1384,46,'137/2017','2022-10-07 00:00:00',13.50,84,46),(1385,48,'48/2017','2022-08-26 00:00:00',53.00,28,48),(1386,47,'48/2017','2022-08-26 00:00:00',28.00,28,47),(1387,70,'48/2017','2022-08-26 00:00:00',41.31,28,70),(1388,46,'48/2017','2022-08-26 00:00:00',13.50,74,46),(1389,36,'48/2017','2022-08-26 00:00:00',75.00,28,36),(1390,59,'01/2018','2022-01-07 00:00:00',10.40,28,59),(1391,3,'01/2018','2022-01-07 00:00:00',170.00,10,3),(1392,70,'01/2018','2022-01-21 00:00:00',41.31,28,70),(1393,68,'01/2018','2022-01-21 00:00:00',35.00,56,68),(1394,59,'01/2018','2022-01-21 00:00:00',10.40,28,59),(1395,68,'01/2018','2022-02-25 00:00:00',35.00,56,68),(1396,69,'01/2018','2022-02-25 00:00:00',35.00,28,69),(1397,70,'01/2018','2022-02-25 00:00:00',41.31,28,70),(1398,83,'01/2018','2022-06-03 00:00:00',61.00,56,83),(1399,50,'01/2018','2022-06-03 00:00:00',170.00,28,50),(1400,48,'01/2018','2022-06-03 00:00:00',53.00,28,48),(1401,68,'01/2018','2022-06-03 00:00:00',35.00,28,68),(1402,67,'01/2018','2022-06-03 00:00:00',21.50,28,67),(1403,22,'01/2018','2022-06-03 00:00:00',39.00,28,22),(1404,50,'01/2018','2022-08-26 00:00:00',170.00,28,50),(1405,83,'01/2018','2022-08-26 00:00:00',61.00,56,83),(1406,68,'01/2018','2022-08-26 00:00:00',35.00,28,68),(1407,67,'01/2018','2022-08-26 00:00:00',21.50,28,67),(1408,12,'01/2018','2022-08-26 00:00:00',40.00,28,12),(1409,69,'292/2021','2022-08-12 00:00:00',35.00,28,69),(1410,68,'292/2021','2022-08-12 00:00:00',35.00,56,68),(1411,70,'292/2021','2022-08-12 00:00:00',41.31,28,70),(1412,28,'04/2018','2022-09-02 00:00:00',45.00,28,28),(1413,31,'04/2018','2022-09-02 00:00:00',56.00,42,31),(1414,46,'04/2018','2022-09-02 00:00:00',13.50,21,46),(1415,28,'04/2018','2022-09-30 00:00:00',45.00,42,28),(1416,31,'04/2018','2022-09-30 00:00:00',56.00,56,31),(1417,46,'04/2018','2022-09-30 00:00:00',13.50,28,46),(1418,83,'26/2017','2022-02-18 00:00:00',61.00,28,83),(1419,83,'26/2017','2022-03-25 00:00:00',61.00,7,83),(1420,34,'26/2017','2022-03-25 00:00:00',39.50,7,34),(1421,83,'26/2017','2022-04-01 00:00:00',61.00,28,83),(1422,34,'26/2017','2022-04-01 00:00:00',39.50,28,34),(1423,82,'26/2017','2022-04-01 00:00:00',52.80,28,82),(1424,83,'26/2017','2022-05-13 00:00:00',61.00,28,83),(1425,82,'26/2017','2022-05-13 00:00:00',52.80,28,82),(1426,34,'26/2017','2022-05-13 00:00:00',39.50,28,34),(1427,83,'26/2017','2022-06-10 00:00:00',61.00,28,83),(1428,81,'26/2017','2022-06-10 00:00:00',68.00,28,81),(1429,81,'26/2017','2022-08-05 00:00:00',68.00,28,81),(1430,83,'26/2017','2022-08-05 00:00:00',61.00,28,83),(1431,34,'26/2017','2022-08-05 00:00:00',39.50,2,34),(1432,30,'130/2022','2022-09-09 00:00:00',75.00,21,30),(1433,70,'130/2022','2022-09-09 00:00:00',41.31,21,70),(1434,35,'130/2022','2022-09-30 00:00:00',49.00,28,35),(1435,70,'130/2022','2022-09-30 00:00:00',41.31,28,70),(1436,46,'130/2022','2022-09-30 00:00:00',13.50,28,46),(1437,82,'135/2020','2022-03-25 00:00:00',52.80,21,82),(1438,69,'135/2020','2022-03-25 00:00:00',35.00,10,69),(1439,69,'135/2020','2022-04-01 00:00:00',35.00,7,69),(1440,22,'135/2020','2022-04-01 00:00:00',39.00,7,22),(1441,82,'135/2020','2022-04-01 00:00:00',52.80,14,82),(1442,12,'135/2020','2022-04-08 00:00:00',40.00,21,12),(1443,82,'135/2020','2022-04-08 00:00:00',52.80,42,82),(1444,69,'135/2020','2022-04-08 00:00:00',35.00,21,69),(1445,69,'135/2020','2022-05-13 00:00:00',35.00,28,69),(1446,22,'135/2020','2022-05-13 00:00:00',39.00,28,22),(1447,82,'135/2020','2022-05-13 00:00:00',52.80,56,82),(1448,82,'135/2020','2022-06-10 00:00:00',52.80,56,82),(1449,69,'135/2020','2022-06-10 00:00:00',35.00,42,69),(1450,22,'135/2020','2022-06-10 00:00:00',39.00,28,22),(1451,82,'135/2020','2022-06-24 00:00:00',52.80,28,82),(1452,82,'135/2020','2022-06-24 00:00:00',52.80,28,82),(1453,12,'135/2020','2022-06-24 00:00:00',40.00,28,12),(1454,12,'135/2020','2022-06-24 00:00:00',40.00,28,12),(1455,46,'135/2020','2022-06-24 00:00:00',13.50,28,46),(1456,46,'135/2020','2022-06-24 00:00:00',13.50,28,46),(1457,69,'135/2020','2022-06-24 00:00:00',35.00,28,69),(1458,69,'135/2020','2022-06-24 00:00:00',35.00,28,69),(1459,82,'135/2020','2022-06-24 00:00:00',52.80,28,82),(1460,12,'135/2020','2022-06-24 00:00:00',40.00,28,12),(1461,46,'135/2020','2022-06-24 00:00:00',13.50,28,46),(1462,69,'135/2020','2022-06-24 00:00:00',35.00,28,69),(1463,22,'67/2021','2022-08-12 00:00:00',39.00,28,22),(1464,92,'67/2021','2022-08-12 00:00:00',126.05,14,92),(1465,82,'135/2022','2022-09-02 00:00:00',52.80,14,82),(1466,83,'135/2022','2022-09-02 00:00:00',61.00,14,83),(1467,68,'135/2022','2022-09-02 00:00:00',35.00,21,68),(1468,71,'135/2022','2022-09-02 00:00:00',32.00,14,71),(1469,34,'135/2022','2022-09-02 00:00:00',39.50,14,34),(1470,46,'135/2022','2022-09-02 00:00:00',13.50,42,46),(1471,48,'135/2022','2022-09-02 00:00:00',53.00,14,48),(1472,82,'135/2022','2022-09-16 00:00:00',52.80,28,82),(1473,83,'135/2022','2022-09-16 00:00:00',61.00,28,83),(1474,68,'135/2022','2022-09-16 00:00:00',35.00,32,68),(1475,32,'135/2022','2022-09-16 00:00:00',45.00,28,32),(1476,30,'135/2022','2022-09-16 00:00:00',75.00,28,30),(1477,71,'135/2022','2022-09-16 00:00:00',32.00,28,71),(1478,46,'135/2022','2022-09-16 00:00:00',13.50,84,46),(1479,48,'135/2022','2022-09-16 00:00:00',53.00,28,48),(1480,21,'161/2019','2022-05-13 00:00:00',58.00,110,21),(1481,44,'161/2019','2022-05-13 00:00:00',110.00,110,44),(1482,64,'161/2019','2022-05-13 00:00:00',53.00,28,64),(1483,89,'161/2019','2022-05-13 00:00:00',34.50,55,89),(1484,69,'161/2019','2022-05-13 00:00:00',35.00,55,69),(1485,21,'161/2019','2022-06-03 00:00:00',58.00,70,21),(1486,44,'161/2019','2022-06-03 00:00:00',110.00,70,44),(1487,69,'161/2019','2022-06-03 00:00:00',35.00,35,69),(1488,21,'161/2019','2022-07-08 00:00:00',58.00,80,21),(1489,44,'161/2019','2022-07-08 00:00:00',110.00,80,44),(1490,69,'161/2019','2022-07-08 00:00:00',35.00,40,69),(1491,21,'161/2019','2022-08-19 00:00:00',58.00,120,21),(1492,69,'161/2019','2022-08-19 00:00:00',35.00,60,69),(1493,43,'161/2019','2022-08-19 00:00:00',84.50,60,43),(1494,44,'161/2019','2022-08-19 00:00:00',110.00,60,44),(1495,82,'287/2021','2022-06-03 00:00:00',52.80,84,82),(1496,83,'287/2021','2022-06-03 00:00:00',61.00,84,83),(1497,34,'287/2021','2022-06-03 00:00:00',39.50,252,34),(1498,46,'287/2021','2022-06-03 00:00:00',13.50,168,46),(1499,82,'287/2021','2022-08-26 00:00:00',52.80,60,82),(1500,83,'287/2021','2022-08-26 00:00:00',61.00,60,83),(1501,34,'287/2021','2022-08-26 00:00:00',39.50,180,34),(1502,46,'287/2021','2022-08-26 00:00:00',13.50,120,46),(1503,9,'63/2018','2022-06-03 00:00:00',750.00,84,9),(1504,8,'63/2018','2022-06-03 00:00:00',72.00,84,8),(1505,9,'63/2018','2022-08-26 00:00:00',750.00,60,9),(1506,8,'63/2018','2022-08-26 00:00:00',72.00,60,8),(1507,5,'04/2022','2022-04-29 00:00:00',85.00,42,5),(1508,65,'04/2022','2022-04-29 00:00:00',84.00,42,65),(1509,64,'04/2022','2022-08-05 00:00:00',53.00,56,64),(1510,3,'04/2022','2022-08-05 00:00:00',170.00,56,3),(1511,83,'92/2018','2022-04-01 00:00:00',61.00,42,83),(1512,68,'92/2018','2022-04-01 00:00:00',35.00,84,68),(1513,95,'92/2018','2022-04-01 00:00:00',120.90,84,95),(1514,48,'92/2018','2022-04-01 00:00:00',53.00,42,48),(1515,47,'92/2018','2022-04-01 00:00:00',28.00,42,47),(1516,83,'92/2018','2022-05-27 00:00:00',61.00,60,83),(1517,68,'92/2018','2022-05-27 00:00:00',35.00,120,68),(1518,95,'92/2018','2022-05-27 00:00:00',120.90,120,95),(1519,48,'92/2018','2022-05-27 00:00:00',53.00,90,48),(1520,83,'92/2018','2022-07-29 00:00:00',61.00,57,83),(1521,68,'92/2018','2022-07-29 00:00:00',35.00,114,68),(1522,46,'92/2018','2022-07-29 00:00:00',13.50,57,46),(1523,49,'92/2018','2022-07-29 00:00:00',86.00,57,49),(1524,83,'92/2018','2022-09-30 00:00:00',61.00,60,83),(1525,40,'92/2018','2022-09-30 00:00:00',40.00,30,40),(1526,49,'92/2018','2022-09-30 00:00:00',86.00,45,49),(1527,82,'8/2014','2022-06-03 00:00:00',52.80,168,82),(1528,82,'8/2014','2022-09-16 00:00:00',52.80,84,82),(1529,5,'202/2021','2022-04-15 00:00:00',85.00,14,5),(1530,4,'202/2021','2022-04-15 00:00:00',46.00,14,4),(1531,81,'104/2018','2022-08-05 00:00:00',68.00,56,81),(1532,40,'104/2018','2022-08-05 00:00:00',40.00,112,40),(1533,38,'104/2018','2022-10-14 00:00:00',107.00,180,38),(1534,81,'104/2018','2022-10-14 00:00:00',68.00,90,81),(1535,73,'0078/2022','2022-04-29 00:00:00',126.50,7,73),(1536,83,'0078/2022','2022-04-29 00:00:00',61.00,14,83),(1537,49,'0078/2022','2022-04-29 00:00:00',86.00,7,49),(1538,47,'0078/2022','2022-04-29 00:00:00',28.00,7,47),(1539,46,'0078/2022','2022-04-29 00:00:00',13.50,14,46),(1540,89,'0078/2022','2022-04-29 00:00:00',34.50,14,89),(1541,29,'0078/2022','2022-04-29 00:00:00',16.30,14,29),(1542,83,'0078/2022','2022-05-05 00:00:00',61.00,28,83),(1543,73,'0078/2022','2022-05-05 00:00:00',126.50,14,73),(1544,49,'0078/2022','2022-05-05 00:00:00',86.00,14,49),(1545,47,'0078/2022','2022-05-05 00:00:00',28.00,14,47),(1546,46,'0078/2022','2022-05-05 00:00:00',13.50,28,46),(1547,29,'0078/2022','2022-05-05 00:00:00',16.30,28,29),(1548,83,'0078/2022','2022-05-20 00:00:00',61.00,56,83),(1549,49,'0078/2022','2022-05-20 00:00:00',86.00,28,49),(1550,47,'0078/2022','2022-05-20 00:00:00',28.00,28,47),(1551,46,'0078/2022','2022-05-20 00:00:00',13.50,56,46),(1552,29,'0078/2022','2022-05-20 00:00:00',16.30,28,29),(1553,72,'0078/2022','2022-05-20 00:00:00',85.00,28,72),(1554,71,'0078/2022','2022-06-17 00:00:00',32.00,28,71),(1555,46,'0078/2022','2022-06-17 00:00:00',13.50,56,46),(1556,29,'0078/2022','2022-06-17 00:00:00',16.30,56,29),(1557,70,'0078/2022','2022-07-15 00:00:00',41.31,42,70),(1558,46,'0078/2022','2022-07-15 00:00:00',13.50,84,46),(1559,29,'0078/2022','2022-07-15 00:00:00',16.30,84,29),(1560,83,'0078/2022','2022-07-15 00:00:00',61.00,84,83),(1561,49,'0078/2022','2022-07-15 00:00:00',86.00,42,49),(1562,47,'0078/2022','2022-07-15 00:00:00',28.00,42,47),(1563,28,'79/2021','2022-07-29 00:00:00',45.00,84,28),(1564,83,'79/2021','2022-07-29 00:00:00',61.00,84,83),(1565,4,'79/2021','2022-07-29 00:00:00',46.00,84,4),(1566,48,'27/2017','2022-04-15 00:00:00',53.00,56,48),(1567,47,'27/2017','2022-04-15 00:00:00',28.00,56,47),(1568,20,'27/2017','2022-04-15 00:00:00',95.00,56,20),(1569,48,'27/2017','2022-07-08 00:00:00',53.00,84,48),(1570,20,'27/2017','2022-07-08 00:00:00',95.00,84,20),(1571,48,'27/2017','2022-08-19 00:00:00',53.00,56,48),(1572,20,'27/2017','2022-08-19 00:00:00',95.00,56,20),(1573,48,'27/2017','2022-10-14 00:00:00',53.00,84,48),(1574,20,'27/2017','2022-10-14 00:00:00',95.00,84,20),(1575,21,'161/2019','2022-09-16 00:00:00',58.00,112,21),(1576,43,'161/2019','2022-09-16 00:00:00',84.50,112,43),(1577,69,'161/2019','2022-09-16 00:00:00',35.00,56,69),(1578,43,'161/2019','2022-10-14 00:00:00',84.50,58,43),(1579,21,'161/2019','2022-10-14 00:00:00',58.00,112,21),(1580,69,'161/2019','2022-10-14 00:00:00',35.00,58,69),(1581,46,'90/2017','2022-02-18 00:00:00',13.50,42,46),(1582,48,'90/2017','2022-02-18 00:00:00',53.00,14,48),(1583,83,'90/2017','2022-02-18 00:00:00',61.00,28,83),(1584,34,'90/2017','2022-02-18 00:00:00',39.50,14,34),(1585,76,'90/2017','2022-02-18 00:00:00',18.85,14,76),(1586,83,'90/2017','2022-03-04 00:00:00',61.00,56,83),(1587,46,'90/2017','2022-03-04 00:00:00',13.50,84,46),(1588,48,'90/2017','2022-03-04 00:00:00',53.00,28,48),(1589,76,'90/2017','2022-03-04 00:00:00',18.85,28,76),(1590,34,'90/2017','2022-03-04 00:00:00',39.50,28,34),(1591,82,'90/2017','2022-10-14 00:00:00',52.80,14,82),(1592,83,'90/2017','2022-10-14 00:00:00',61.00,28,83),(1593,46,'90/2017','2022-10-14 00:00:00',13.50,42,46),(1594,49,'90/2017','2022-10-14 00:00:00',86.00,14,49),(1595,48,'90/2017','2022-10-14 00:00:00',53.00,14,48),(1596,76,'90/2017','2022-10-14 00:00:00',18.85,14,76),(1597,70,'90/2017','2022-10-14 00:00:00',41.31,14,70),(1598,83,'155/2022','2022-10-14 00:00:00',61.00,56,83),(1599,34,'155/2022','2022-10-14 00:00:00',39.50,28,34),(1600,45,'211/2019','2022-10-14 00:00:00',46.20,56,45),(1601,88,'211/2019','2022-10-14 00:00:00',57.00,42,88),(1602,81,'211/2019','2022-10-14 00:00:00',68.00,56,81),(1603,31,'211/2019','2022-10-14 00:00:00',56.00,56,31),(1604,46,'211/2019','2022-10-14 00:00:00',13.50,56,46),(1605,5,'211/2019','2022-10-14 00:00:00',85.00,56,5),(1606,76,'211/2019','2022-10-14 00:00:00',18.85,56,76),(1607,68,'99/2019','2022-10-14 00:00:00',35.00,126,68),(1608,34,'247/2021','2022-10-14 00:00:00',39.50,7,34),(1609,35,'247/2021','2022-10-14 00:00:00',49.00,7,35),(1610,83,'247/2021','2022-10-14 00:00:00',61.00,14,83),(1611,82,'247/2021','2022-10-14 00:00:00',52.80,7,82),(1612,46,'247/2021','2022-10-14 00:00:00',13.50,21,46),(1613,71,'247/2021','2022-10-14 00:00:00',32.00,7,71),(1614,87,'247/2021','2022-10-14 00:00:00',54.00,11,87),(1615,19,'080/2020','2022-10-14 00:00:00',45.00,21,19),(1616,45,'080/2020','2022-10-14 00:00:00',46.20,7,45),(1617,34,'202/2022','2022-10-14 00:00:00',39.50,28,34),(1618,46,'202/2022','2022-10-14 00:00:00',13.50,56,46),(1619,82,'75/2019','2022-10-14 00:00:00',52.80,70,82),(1620,83,'75/2019','2022-10-14 00:00:00',61.00,70,83),(1621,46,'75/2019','2022-10-14 00:00:00',13.50,140,46),(1622,68,'75/2019','2022-10-14 00:00:00',35.00,105,68),(1623,33,'200/2022','2022-10-14 00:00:00',24.00,28,33),(1624,29,'205/2022','2022-10-14 00:00:00',16.30,84,29),(1625,36,'205/2022','2022-10-14 00:00:00',75.00,56,36),(1626,46,'205/2022','2022-10-14 00:00:00',13.50,56,46),(1627,21,'205/2022','2022-10-14 00:00:00',58.00,56,21),(1628,56,'205/2022','2022-10-14 00:00:00',61.90,56,56),(1629,12,'201/2022','2022-10-14 00:00:00',40.00,14,12),(1630,31,'201/2022','2022-10-14 00:00:00',56.00,7,31),(1631,83,'0078/2022','2022-08-19 00:00:00',61.00,112,83),(1632,49,'0078/2022','2022-08-19 00:00:00',86.00,56,49),(1633,47,'0078/2022','2022-08-19 00:00:00',28.00,56,47),(1634,71,'0078/2022','2022-08-19 00:00:00',32.00,56,71),(1635,70,'0078/2022','2022-08-19 00:00:00',41.31,56,70),(1636,46,'0078/2022','2022-08-19 00:00:00',13.50,112,46),(1637,29,'0078/2022','2022-08-19 00:00:00',16.30,56,29),(1638,83,'0078/2022','2022-09-09 00:00:00',61.00,56,83),(1639,49,'0078/2022','2022-09-09 00:00:00',86.00,28,49),(1640,47,'0078/2022','2022-09-09 00:00:00',28.00,28,47),(1641,71,'0078/2022','2022-09-09 00:00:00',32.00,28,71),(1642,70,'0078/2022','2022-09-09 00:00:00',41.31,28,70),(1643,46,'0078/2022','2022-09-09 00:00:00',13.50,56,46),(1644,49,'0078/2022','2022-10-14 00:00:00',86.00,56,49),(1645,47,'0078/2022','2022-10-14 00:00:00',28.00,56,47),(1646,83,'0078/2022','2022-10-14 00:00:00',61.00,112,83),(1647,46,'0078/2022','2022-10-14 00:00:00',13.50,112,46),(1648,46,'225/2022','2022-10-21 00:00:00',13.50,7,46),(1649,36,'225/2022','2022-10-21 00:00:00',75.00,7,36),(1650,82,'58/2021','2022-10-21 00:00:00',52.80,70,82),(1651,83,'58/2021','2022-10-21 00:00:00',61.00,35,83),(1652,50,'58/2021','2022-10-21 00:00:00',170.00,35,50),(1653,48,'58/2021','2022-10-21 00:00:00',53.00,35,48),(1654,46,'58/2021','2022-10-21 00:00:00',13.50,140,46),(1655,83,'58/2021','2022-08-26 00:00:00',61.00,50,83),(1656,82,'58/2021','2022-08-26 00:00:00',52.80,100,82),(1657,48,'58/2021','2022-08-26 00:00:00',53.00,50,48),(1658,50,'58/2021','2022-08-26 00:00:00',170.00,50,50),(1659,46,'58/2021','2022-08-26 00:00:00',13.50,200,46),(1660,50,'58/2021','2022-02-11 00:00:00',170.00,56,50),(1661,47,'58/2021','2022-02-11 00:00:00',28.00,56,47),(1662,48,'58/2021','2022-02-11 00:00:00',53.00,56,48),(1663,46,'58/2021','2022-02-11 00:00:00',13.50,168,46),(1664,82,'58/2021','2022-04-08 00:00:00',52.80,112,82),(1665,83,'58/2021','2022-04-08 00:00:00',61.00,56,83),(1666,50,'58/2021','2022-04-08 00:00:00',170.00,56,50),(1667,47,'58/2021','2022-04-08 00:00:00',28.00,56,47),(1668,48,'58/2021','2022-04-08 00:00:00',53.00,56,48),(1669,46,'58/2021','2022-04-08 00:00:00',13.50,168,46),(1670,82,'58/2021','2022-07-08 00:00:00',52.80,98,82),(1671,83,'58/2021','2022-07-08 00:00:00',61.00,50,83),(1672,50,'58/2021','2022-07-08 00:00:00',170.00,50,50),(1673,47,'58/2021','2022-07-08 00:00:00',28.00,50,47),(1674,48,'58/2021','2022-07-08 00:00:00',53.00,50,48),(1675,46,'58/2021','2022-07-08 00:00:00',13.50,150,46),(1676,33,'0112/2017','2022-05-20 00:00:00',24.00,100,33),(1677,33,'0112/2017','2022-07-29 00:00:00',24.00,84,33),(1678,33,'0112/2017','2022-10-21 00:00:00',24.00,74,33),(1679,82,'90/2022','2022-05-27 00:00:00',52.80,7,82),(1680,81,'90/2022','2022-05-27 00:00:00',68.00,7,81),(1681,86,'90/2022','2022-05-27 00:00:00',96.00,14,86),(1682,33,'90/2022','2022-05-27 00:00:00',24.00,7,33),(1683,82,'90/2022','2022-06-03 00:00:00',52.80,56,82),(1684,86,'90/2022','2022-06-03 00:00:00',96.00,56,86),(1685,33,'90/2022','2022-06-03 00:00:00',24.00,56,33),(1686,81,'90/2022','2022-08-26 00:00:00',68.00,84,81),(1687,86,'90/2022','2022-08-26 00:00:00',96.00,84,86),(1688,33,'90/2022','2022-08-26 00:00:00',24.00,42,33),(1689,81,'90/2022','2022-10-21 00:00:00',68.00,56,81),(1690,86,'90/2022','2022-10-21 00:00:00',96.00,112,86),(1691,33,'90/2022','2022-10-21 00:00:00',24.00,56,33),(1692,20,'59/2021','2022-10-21 00:00:00',95.00,35,20),(1693,65,'59/2021','2022-10-21 00:00:00',84.00,35,65),(1694,19,'59/2021','2022-10-21 00:00:00',45.00,18,19),(1695,20,'59/2021','2022-09-02 00:00:00',95.00,49,20),(1696,65,'59/2021','2022-09-02 00:00:00',84.00,74,65),(1697,36,'232/2021','2022-08-26 00:00:00',75.00,56,36),(1698,46,'232/2021','2022-08-26 00:00:00',13.50,168,46),(1699,82,'232/2021','2022-08-26 00:00:00',52.80,112,82),(1700,83,'232/2021','2022-08-26 00:00:00',61.00,56,83),(1701,49,'232/2021','2022-08-26 00:00:00',86.00,56,49),(1702,82,'232/2021','2022-10-21 00:00:00',52.80,70,82),(1703,83,'232/2021','2022-10-21 00:00:00',61.00,35,83),(1704,46,'232/2021','2022-10-21 00:00:00',13.50,95,46),(1705,36,'232/2021','2022-10-21 00:00:00',75.00,35,36),(1706,49,'232/2021','2022-10-21 00:00:00',86.00,35,49),(1707,82,'133/2022','2022-07-29 00:00:00',52.80,14,82),(1708,34,'133/2022','2022-07-29 00:00:00',39.50,7,34),(1709,82,'133/2022','2022-08-12 00:00:00',52.80,7,82),(1710,83,'133/2022','2022-08-12 00:00:00',61.00,7,83),(1711,34,'133/2022','2022-08-12 00:00:00',39.50,7,34),(1712,36,'133/2022','2022-08-19 00:00:00',75.00,14,36),(1713,70,'133/2022','2022-08-19 00:00:00',41.31,14,70),(1714,83,'133/2022','2022-08-26 00:00:00',61.00,14,83),(1715,35,'133/2022','2022-08-26 00:00:00',49.00,14,35),(1716,70,'133/2022','2022-08-26 00:00:00',41.31,7,70),(1717,83,'133/2022','2022-10-21 00:00:00',61.00,28,83),(1718,36,'133/2022','2022-10-21 00:00:00',75.00,14,36),(1719,70,'133/2022','2022-10-21 00:00:00',41.31,14,70),(1720,12,'201/2022','2022-10-21 00:00:00',40.00,14,12),(1721,35,'201/2022','2022-10-21 00:00:00',49.00,14,35),(1722,46,'201/2022','2022-10-21 00:00:00',13.50,14,46),(1723,82,'288/2021','2022-02-11 00:00:00',52.80,35,82),(1724,83,'288/2021','2022-02-11 00:00:00',61.00,35,83),(1725,36,'288/2021','2022-02-11 00:00:00',75.00,35,36),(1726,46,'288/2021','2022-02-11 00:00:00',13.50,35,46),(1727,82,'288/2021','2022-03-18 00:00:00',52.80,56,82),(1728,83,'288/2021','2022-03-18 00:00:00',61.00,56,83),(1729,35,'288/2021','2022-03-18 00:00:00',49.00,56,35),(1730,46,'288/2021','2022-03-18 00:00:00',13.50,56,46),(1731,82,'288/2021','2022-04-15 00:00:00',52.80,252,82),(1732,36,'288/2021','2022-04-15 00:00:00',75.00,84,36),(1733,46,'288/2021','2022-04-15 00:00:00',13.50,252,46),(1734,82,'288/2021','2022-08-19 00:00:00',52.80,210,82),(1735,35,'288/2021','2022-08-19 00:00:00',49.00,70,35),(1736,46,'288/2021','2022-08-19 00:00:00',13.50,210,46),(1737,82,'288/2021','2022-07-29 00:00:00',52.80,252,82),(1738,34,'288/2021','2022-07-29 00:00:00',39.50,84,34),(1739,46,'288/2021','2022-07-29 00:00:00',13.50,252,46),(1740,19,'288/2021','2022-07-29 00:00:00',45.00,84,19),(1741,82,'288/2021','2022-10-21 00:00:00',52.80,63,82),(1742,34,'288/2021','2022-10-21 00:00:00',39.50,21,34),(1743,46,'288/2021','2022-10-21 00:00:00',13.50,21,46),(1744,19,'288/2021','2022-10-21 00:00:00',45.00,21,19),(1745,22,'248/2021','2022-04-01 00:00:00',39.00,42,22),(1746,21,'248/2021','2022-05-06 00:00:00',58.00,56,21),(1747,22,'248/2021','2022-08-26 00:00:00',39.00,63,22),(1748,22,'248/2021','2022-09-09 00:00:00',39.00,14,22),(1749,22,'248/2021','2022-10-21 00:00:00',39.00,14,22),(1750,82,'90/2022','2022-06-17 00:00:00',52.80,28,82),(1751,81,'90/2022','2022-06-17 00:00:00',68.00,28,81),(1752,81,'90/2022','2022-07-15 00:00:00',68.00,112,81),(1753,86,'90/2022','2022-07-15 00:00:00',96.00,112,86),(1754,35,'90/2022','2022-07-15 00:00:00',49.00,56,35),(1755,81,'203/2022','2022-10-21 00:00:00',68.00,21,81),(1756,83,'203/2022','2022-10-21 00:00:00',61.00,21,83),(1757,69,'203/2022','2022-10-21 00:00:00',35.00,21,69),(1758,67,'203/2022','2022-10-21 00:00:00',21.50,21,67),(1759,22,'203/2022','2022-10-21 00:00:00',39.00,21,22),(1760,28,'79/2021','2022-10-21 00:00:00',45.00,168,28),(1761,83,'79/2021','2022-10-21 00:00:00',61.00,84,83),(1762,5,'79/2021','2022-10-21 00:00:00',85.00,84,5),(1763,83,'137/2017','2022-05-20 00:00:00',61.00,112,83),(1764,26,'137/2017','2022-05-20 00:00:00',49.00,84,26),(1765,72,'137/2017','2022-05-20 00:00:00',85.00,56,72),(1766,71,'137/2017','2022-05-20 00:00:00',32.00,56,71),(1767,46,'137/2017','2022-05-20 00:00:00',13.50,168,46),(1768,76,'137/2017','2022-05-20 00:00:00',18.85,56,76),(1769,83,'137/2017','2022-07-15 00:00:00',61.00,168,83),(1770,26,'137/2017','2022-07-15 00:00:00',49.00,84,26),(1771,70,'137/2017','2022-07-15 00:00:00',41.31,14,70),(1772,46,'137/2017','2022-07-15 00:00:00',13.50,252,46),(1773,76,'137/2017','2022-07-15 00:00:00',18.85,84,76),(1774,35,'52/2022','2022-07-22 00:00:00',49.00,84,35),(1775,92,'52/2022','2022-09-09 00:00:00',126.05,3,92),(1776,11,'52/2022','2022-09-09 00:00:00',129.00,2,11),(1777,11,'52/2022','2022-10-21 00:00:00',129.00,2,11),(1778,92,'52/2022','2022-10-21 00:00:00',126.05,2,92),(1779,82,'205/2019','2022-05-27 00:00:00',52.80,182,82),(1780,27,'205/2019','2022-05-27 00:00:00',120.00,91,27),(1781,82,'205/2019','2022-08-26 00:00:00',52.80,70,82),(1782,27,'205/2019','2022-08-26 00:00:00',120.00,35,27),(1783,82,'205/2019','2022-10-21 00:00:00',52.80,168,82),(1784,27,'205/2019','2022-10-21 00:00:00',120.00,84,27),(1785,82,'287/2021','2022-10-21 00:00:00',52.80,35,82),(1786,83,'287/2021','2022-10-21 00:00:00',61.00,35,83),(1787,34,'287/2021','2022-10-21 00:00:00',39.50,105,34),(1788,46,'287/2021','2022-10-21 00:00:00',13.50,70,46),(1789,83,'16/2021','2022-03-18 00:00:00',61.00,84,83),(1790,82,'16/2021','2022-03-18 00:00:00',52.80,84,82),(1791,69,'16/2021','2022-03-18 00:00:00',35.00,84,69),(1792,67,'16/2021','2022-03-18 00:00:00',21.50,84,67),(1793,46,'16/2021','2022-03-18 00:00:00',13.50,84,46),(1794,83,'16/2021','2022-06-03 00:00:00',61.00,84,83),(1795,82,'16/2021','2022-06-03 00:00:00',52.80,84,82),(1796,69,'16/2021','2022-06-03 00:00:00',35.00,84,69),(1797,67,'16/2021','2022-06-03 00:00:00',21.50,84,67),(1798,46,'16/2021','2022-06-03 00:00:00',13.50,84,46),(1799,83,'16/2021','2022-08-26 00:00:00',61.00,63,83),(1800,69,'16/2021','2022-08-26 00:00:00',35.00,63,69),(1801,82,'16/2021','2022-08-26 00:00:00',52.80,63,82),(1802,67,'16/2021','2022-08-26 00:00:00',21.50,63,67),(1803,46,'16/2021','2022-08-26 00:00:00',13.50,63,46),(1804,83,'16/2021','2022-10-21 00:00:00',61.00,28,83),(1805,68,'16/2021','2022-10-21 00:00:00',35.00,14,68),(1806,46,'16/2021','2022-10-21 00:00:00',13.50,14,46),(1807,9,'63/2018','2022-10-21 00:00:00',750.00,56,9),(1808,8,'63/2018','2022-10-21 00:00:00',72.00,56,8),(1809,50,'01/2018','2022-10-21 00:00:00',170.00,49,50),(1810,83,'01/2018','2022-10-21 00:00:00',61.00,98,83),(1811,68,'01/2018','2022-10-21 00:00:00',35.00,49,68),(1812,67,'01/2018','2022-10-21 00:00:00',21.50,49,67),(1813,22,'01/2018','2022-10-21 00:00:00',39.00,49,22),(1814,49,'45/2017','2022-08-26 00:00:00',86.00,63,49),(1815,49,'45/2017','2022-10-21 00:00:00',86.00,84,49),(1816,49,'45/2017','2022-07-29 00:00:00',86.00,28,49),(1817,11,'36/2020','2022-10-21 00:00:00',129.00,2,11),(1818,49,'36/2020','2022-10-21 00:00:00',86.00,21,49),(1819,47,'36/2020','2022-10-21 00:00:00',28.00,21,47),(1820,34,'36/2020','2022-10-21 00:00:00',39.50,21,34),(1821,12,'97/2022','2022-10-28 00:00:00',40.00,56,12),(1822,82,'97/2022','2022-10-28 00:00:00',52.80,112,82),(1823,69,'97/2022','2022-10-28 00:00:00',35.00,56,69),(1824,22,'97/2022','2022-10-28 00:00:00',39.00,56,22),(1825,46,'97/2022','2022-10-28 00:00:00',13.50,56,46),(1826,82,'134/2022','2022-10-28 00:00:00',52.80,56,82),(1827,83,'134/2022','2022-10-28 00:00:00',61.00,56,83),(1828,69,'134/2022','2022-10-28 00:00:00',35.00,56,69),(1829,69,'134/2022','2022-08-05 00:00:00',35.00,7,69),(1830,82,'134/2022','2022-08-05 00:00:00',52.80,14,82),(1831,69,'134/2022','2022-08-12 00:00:00',35.00,7,69),(1832,82,'134/2022','2022-08-12 00:00:00',52.80,14,82),(1833,69,'134/2022','2022-08-19 00:00:00',35.00,28,69),(1834,82,'134/2022','2022-08-19 00:00:00',52.80,56,82),(1835,82,'134/2022','2022-09-09 00:00:00',52.80,7,82),(1836,83,'134/2022','2022-09-09 00:00:00',61.00,7,83),(1837,68,'134/2022','2022-09-09 00:00:00',35.00,7,68),(1838,83,'134/2022','2022-09-16 00:00:00',61.00,14,83),(1839,82,'134/2022','2022-09-16 00:00:00',52.80,14,82),(1840,69,'134/2022','2022-09-16 00:00:00',35.00,14,69),(1841,67,'134/2022','2022-09-16 00:00:00',21.50,14,67),(1842,82,'134/2022','2022-09-30 00:00:00',52.80,28,82),(1843,83,'134/2022','2022-09-30 00:00:00',61.00,28,83),(1844,69,'134/2022','2022-09-30 00:00:00',35.00,28,69),(1845,67,'134/2022','2022-09-30 00:00:00',21.50,28,67),(1846,12,'97/2022','2022-06-03 00:00:00',40.00,7,12),(1847,35,'211/2019','2022-04-15 00:00:00',49.00,56,35),(1848,45,'211/2019','2022-04-15 00:00:00',46.20,112,45),(1849,87,'211/2019','2022-04-15 00:00:00',54.00,84,87),(1850,81,'211/2019','2022-04-15 00:00:00',68.00,112,81),(1851,46,'211/2019','2022-04-15 00:00:00',13.50,168,46),(1852,5,'211/2019','2022-04-15 00:00:00',85.00,56,5),(1853,45,'211/2019','2022-06-10 00:00:00',46.20,112,45),(1854,87,'211/2019','2022-06-10 00:00:00',54.00,84,87),(1855,81,'211/2019','2022-06-10 00:00:00',68.00,112,81),(1856,34,'211/2019','2022-06-10 00:00:00',39.50,56,34),(1857,46,'211/2019','2022-06-10 00:00:00',13.50,112,46),(1858,5,'211/2019','2022-06-10 00:00:00',85.00,56,5),(1859,76,'211/2019','2022-06-10 00:00:00',18.85,56,76),(1860,45,'211/2019','2022-08-05 00:00:00',46.20,56,45),(1861,87,'211/2019','2022-08-05 00:00:00',54.00,42,87),(1862,81,'211/2019','2022-08-05 00:00:00',68.00,56,81),(1863,35,'211/2019','2022-08-05 00:00:00',49.00,28,35),(1864,46,'211/2019','2022-08-05 00:00:00',13.50,56,46),(1865,5,'211/2019','2022-08-05 00:00:00',85.00,28,5),(1866,76,'211/2019','2022-08-05 00:00:00',18.85,28,76),(1867,45,'211/2019','2022-10-28 00:00:00',46.20,84,45),(1868,87,'211/2019','2022-10-28 00:00:00',54.00,63,87),(1869,82,'211/2019','2022-10-28 00:00:00',52.80,42,82),(1870,81,'211/2019','2022-10-28 00:00:00',68.00,42,81),(1871,34,'211/2019','2022-10-28 00:00:00',39.50,42,34),(1872,5,'211/2019','2022-10-28 00:00:00',85.00,42,5),(1873,76,'211/2019','2022-10-28 00:00:00',18.85,84,76),(1874,82,'135/2020','2022-10-28 00:00:00',52.80,112,82),(1875,69,'135/2020','2022-10-28 00:00:00',35.00,56,69),(1876,22,'135/2020','2022-10-28 00:00:00',39.00,56,22),(1877,46,'135/2020','2022-10-28 00:00:00',13.50,56,46),(1878,12,'97/2022','2022-06-10 00:00:00',40.00,14,12),(1879,12,'97/2022','2022-06-24 00:00:00',40.00,28,12),(1880,12,'97/2022','2022-07-22 00:00:00',40.00,28,12),(1881,12,'97/2022','2022-08-19 00:00:00',40.00,56,12),(1882,12,'97/2022','2022-10-28 00:00:00',40.00,28,12),(1883,81,'83/2019','2022-10-28 00:00:00',68.00,168,81),(1884,84,'83/2019','2022-10-28 00:00:00',130.90,168,84),(1885,59,'83/2019','2022-10-28 00:00:00',10.40,84,59),(1886,57,'83/2019','2022-10-28 00:00:00',34.10,84,57),(1887,81,'83/2019','2022-09-09 00:00:00',68.00,56,81),(1888,84,'83/2019','2022-09-09 00:00:00',130.90,56,84),(1889,59,'83/2019','2022-09-09 00:00:00',10.40,28,59),(1890,57,'83/2019','2022-09-09 00:00:00',34.10,28,57),(1891,83,'93/2017','2022-03-04 00:00:00',61.00,14,83),(1892,82,'93/2017','2022-03-04 00:00:00',52.80,7,82),(1893,34,'93/2017','2022-03-04 00:00:00',39.50,7,34),(1894,49,'93/2017','2022-03-04 00:00:00',86.00,7,49),(1895,48,'93/2017','2022-03-04 00:00:00',53.00,7,48),(1896,46,'93/2017','2022-03-04 00:00:00',13.50,28,46),(1897,82,'93/2017','2022-03-11 00:00:00',52.80,14,82),(1898,83,'93/2017','2022-03-11 00:00:00',61.00,28,83),(1899,34,'93/2017','2022-03-11 00:00:00',39.50,14,34),(1900,50,'93/2017','2022-03-11 00:00:00',170.00,14,50),(1901,48,'93/2017','2022-03-11 00:00:00',53.00,14,48),(1902,46,'93/2017','2022-03-11 00:00:00',13.50,56,46),(1903,82,'93/2017','2022-03-25 00:00:00',52.80,28,82),(1904,83,'93/2017','2022-03-25 00:00:00',61.00,56,83),(1905,34,'93/2017','2022-03-25 00:00:00',39.50,28,34),(1906,50,'93/2017','2022-03-25 00:00:00',170.00,28,50),(1907,48,'93/2017','2022-03-25 00:00:00',53.00,56,48),(1908,46,'93/2017','2022-03-25 00:00:00',13.50,112,46),(1909,82,'93/2017','2022-04-22 00:00:00',52.80,28,82),(1910,83,'93/2017','2022-04-22 00:00:00',61.00,56,83),(1911,34,'93/2017','2022-04-22 00:00:00',39.50,28,34),(1912,50,'93/2017','2022-04-22 00:00:00',170.00,28,50),(1913,48,'93/2017','2022-04-22 00:00:00',53.00,56,48),(1914,46,'93/2017','2022-04-22 00:00:00',13.50,112,46),(1915,82,'93/2017','2022-05-20 00:00:00',52.80,56,82),(1916,83,'93/2017','2022-05-20 00:00:00',61.00,112,83),(1917,34,'93/2017','2022-05-20 00:00:00',39.50,56,34),(1918,50,'93/2017','2022-05-20 00:00:00',170.00,56,50),(1919,48,'93/2017','2022-05-20 00:00:00',53.00,112,48),(1920,46,'93/2017','2022-05-20 00:00:00',13.50,224,46),(1921,82,'93/2017','2022-07-22 00:00:00',52.80,56,82),(1922,83,'93/2017','2022-07-22 00:00:00',61.00,112,83),(1923,50,'93/2017','2022-07-22 00:00:00',170.00,58,50),(1924,48,'93/2017','2022-07-22 00:00:00',53.00,112,48),(1925,46,'93/2017','2022-07-22 00:00:00',13.50,224,46),(1926,82,'93/2017','2022-09-16 00:00:00',52.80,56,82),(1927,83,'93/2017','2022-09-16 00:00:00',61.00,112,83),(1928,50,'93/2017','2022-09-16 00:00:00',170.00,56,50),(1929,48,'93/2017','2022-09-16 00:00:00',53.00,112,48),(1930,46,'93/2017','2022-09-16 00:00:00',13.50,224,46),(1931,82,'93/2017','2022-10-28 00:00:00',52.80,42,82),(1932,83,'93/2017','2022-10-28 00:00:00',61.00,84,83),(1933,50,'93/2017','2022-10-28 00:00:00',170.00,42,50),(1934,48,'93/2017','2022-10-28 00:00:00',53.00,84,48),(1935,46,'93/2017','2022-10-28 00:00:00',13.50,168,46),(1936,83,'135/2018','2022-03-18 00:00:00',61.00,84,83),(1937,82,'135/2018','2022-03-18 00:00:00',52.80,84,82),(1938,84,'135/2018','2022-03-18 00:00:00',130.90,168,84),(1939,69,'135/2018','2022-03-18 00:00:00',35.00,84,69),(1940,67,'135/2018','2022-03-18 00:00:00',21.50,84,67),(1941,76,'135/2018','2022-03-18 00:00:00',18.85,168,76),(1942,46,'135/2018','2022-03-18 00:00:00',13.50,84,46),(1943,83,'135/2018','2022-06-10 00:00:00',61.00,84,83),(1944,82,'135/2018','2022-06-10 00:00:00',52.80,84,82),(1945,84,'135/2018','2022-06-10 00:00:00',130.90,168,84),(1946,69,'135/2018','2022-06-10 00:00:00',35.00,84,69),(1947,76,'135/2018','2022-06-10 00:00:00',18.85,168,76),(1948,46,'135/2018','2022-06-10 00:00:00',13.50,84,46),(1949,83,'135/2018','2022-07-01 00:00:00',61.00,7,83),(1950,82,'135/2018','2022-07-01 00:00:00',52.80,7,82),(1951,84,'135/2018','2022-07-01 00:00:00',130.90,14,84),(1952,69,'135/2018','2022-07-01 00:00:00',35.00,7,69),(1953,67,'135/2018','2022-07-01 00:00:00',21.50,7,67),(1954,76,'135/2018','2022-07-01 00:00:00',18.85,14,76),(1955,46,'135/2018','2022-07-01 00:00:00',13.50,7,46),(1956,82,'135/2018','2022-07-08 00:00:00',52.80,56,82),(1957,83,'135/2018','2022-07-08 00:00:00',61.00,56,83),(1958,84,'135/2018','2022-07-08 00:00:00',130.90,112,84),(1959,69,'135/2018','2022-07-08 00:00:00',35.00,56,69),(1960,67,'135/2018','2022-07-08 00:00:00',21.50,56,67),(1961,76,'135/2018','2022-07-08 00:00:00',18.85,112,76),(1962,82,'135/2018','2022-09-02 00:00:00',52.80,168,82),(1963,84,'135/2018','2022-09-02 00:00:00',130.90,112,84),(1964,69,'135/2018','2022-09-02 00:00:00',35.00,56,69),(1965,67,'135/2018','2022-09-02 00:00:00',21.50,56,67),(1966,76,'135/2018','2022-09-02 00:00:00',18.85,112,76),(1967,82,'135/2018','2022-10-28 00:00:00',52.80,168,82),(1968,84,'135/2018','2022-10-28 00:00:00',130.90,112,84),(1969,69,'135/2018','2022-10-28 00:00:00',35.00,56,69),(1970,67,'135/2018','2022-10-28 00:00:00',21.50,56,67),(1971,75,'135/2018','2022-10-28 00:00:00',200.00,70,75),(1972,46,'135/2018','2022-10-28 00:00:00',13.50,56,46),(1973,11,'231/2021','2022-04-15 00:00:00',129.00,1,11),(1974,49,'231/2021','2022-04-15 00:00:00',86.00,56,49),(1975,92,'231/2021','2022-04-15 00:00:00',126.05,2,92),(1976,46,'231/2021','2022-04-15 00:00:00',13.50,56,46),(1977,11,'231/2021','2022-06-10 00:00:00',129.00,2,11),(1978,49,'231/2021','2022-06-10 00:00:00',86.00,56,49),(1979,92,'231/2021','2022-06-10 00:00:00',126.05,1,92),(1980,46,'231/2021','2022-06-10 00:00:00',13.50,56,46),(1981,11,'231/2021','2022-08-12 00:00:00',129.00,1,11),(1982,49,'231/2021','2022-08-12 00:00:00',86.00,28,49),(1983,92,'231/2021','2022-08-12 00:00:00',126.05,2,92),(1984,46,'231/2021','2022-08-12 00:00:00',13.50,58,46),(1985,11,'231/2021','2022-09-30 00:00:00',129.00,1,11),(1986,49,'231/2021','2022-09-30 00:00:00',86.00,28,49),(1987,92,'231/2021','2022-09-30 00:00:00',126.05,2,92),(1988,46,'231/2021','2022-09-30 00:00:00',13.50,28,46),(1989,11,'231/2021','2022-10-28 00:00:00',129.00,2,11),(1990,49,'231/2021','2022-10-28 00:00:00',86.00,42,49),(1991,92,'231/2021','2022-10-28 00:00:00',126.05,2,92),(1992,46,'231/2021','2022-10-28 00:00:00',13.50,42,46),(1993,83,'92/2018','2022-10-28 00:00:00',61.00,84,83),(1994,49,'92/2018','2022-10-28 00:00:00',86.00,63,49),(1995,39,'92/2018','2022-10-28 00:00:00',69.00,42,39),(1996,69,'56/2022','2022-04-01 00:00:00',35.00,14,69),(1997,70,'56/2022','2022-04-01 00:00:00',41.31,14,70),(1998,69,'56/2022','2022-04-15 00:00:00',35.00,28,69),(1999,70,'56/2022','2022-04-15 00:00:00',41.31,28,70),(2000,69,'56/2022','2022-05-13 00:00:00',35.00,28,69),(2001,70,'56/2022','2022-05-13 00:00:00',41.31,28,70),(2002,69,'56/2022','2022-06-10 00:00:00',35.00,42,69),(2003,70,'56/2022','2022-06-10 00:00:00',41.31,21,70),(2004,69,'56/2022','2022-09-30 00:00:00',35.00,42,69),(2005,70,'56/2022','2022-09-30 00:00:00',41.31,28,70),(2006,68,'56/2022','2022-10-28 00:00:00',35.00,56,68),(2007,70,'56/2022','2022-10-28 00:00:00',41.31,28,70),(2008,5,'168/2021','2022-05-27 00:00:00',85.00,14,5),(2009,4,'168/2021','2022-05-27 00:00:00',46.00,14,4),(2010,4,'168/2021','2022-06-17 00:00:00',46.00,21,4),(2011,5,'168/2021','2022-06-17 00:00:00',85.00,21,5),(2012,5,'168/2021','2022-07-15 00:00:00',85.00,28,5),(2013,4,'168/2021','2022-07-15 00:00:00',46.00,28,4),(2014,4,'168/2021','2022-07-29 00:00:00',46.00,14,4),(2015,5,'168/2021','2022-07-29 00:00:00',85.00,14,5),(2016,5,'168/2021','2022-09-09 00:00:00',85.00,14,5),(2017,4,'168/2021','2022-09-09 00:00:00',46.00,14,4),(2018,64,'168/2021','2022-09-09 00:00:00',53.00,14,64),(2019,4,'168/2021','2022-10-28 00:00:00',46.00,28,4),(2020,23,'168/2021','2022-10-28 00:00:00',33.32,28,23),(2021,83,'204/2022','2022-10-21 00:00:00',61.00,42,83),(2022,82,'204/2022','2022-10-21 00:00:00',52.80,21,82),(2023,69,'204/2022','2022-10-21 00:00:00',35.00,42,69),(2024,68,'204/2022','2022-10-21 00:00:00',35.00,21,68),(2025,28,'204/2022','2022-10-21 00:00:00',45.00,63,28),(2026,46,'204/2022','2022-10-21 00:00:00',13.50,42,46),(2027,83,'204/2022','2022-10-28 00:00:00',61.00,28,83),(2028,68,'204/2022','2022-10-28 00:00:00',35.00,14,68),(2029,82,'204/2022','2022-10-28 00:00:00',52.80,14,82),(2030,28,'204/2022','2022-10-28 00:00:00',45.00,21,28),(2031,46,'204/2022','2022-10-28 00:00:00',13.50,28,46),(2032,83,'38/2017','2022-04-29 00:00:00',61.00,56,83),(2033,46,'38/2017','2022-04-29 00:00:00',13.50,84,46),(2034,50,'38/2017','2022-04-29 00:00:00',170.00,28,50),(2035,47,'38/2017','2022-04-29 00:00:00',28.00,84,47),(2036,26,'38/2017','2022-04-29 00:00:00',49.00,56,26),(2037,25,'38/2017','2022-04-29 00:00:00',38.00,28,25),(2038,83,'38/2017','2022-05-27 00:00:00',61.00,56,83),(2039,46,'38/2017','2022-05-27 00:00:00',13.50,84,46),(2040,50,'38/2017','2022-05-27 00:00:00',170.00,28,50),(2041,47,'38/2017','2022-05-27 00:00:00',28.00,84,47),(2042,26,'38/2017','2022-05-27 00:00:00',49.00,56,26),(2043,25,'38/2017','2022-05-27 00:00:00',38.00,28,25),(2044,83,'38/2017','2022-06-17 00:00:00',61.00,42,83),(2045,46,'38/2017','2022-06-17 00:00:00',13.50,63,46),(2046,50,'38/2017','2022-06-17 00:00:00',170.00,21,50),(2047,48,'38/2017','2022-06-17 00:00:00',53.00,42,48),(2048,26,'38/2017','2022-06-17 00:00:00',49.00,42,26),(2049,83,'38/2017','2022-07-01 00:00:00',61.00,14,83),(2050,46,'38/2017','2022-07-01 00:00:00',13.50,21,46),(2051,50,'38/2017','2022-07-01 00:00:00',170.00,7,50),(2052,48,'38/2017','2022-07-01 00:00:00',53.00,7,48),(2053,26,'38/2017','2022-07-01 00:00:00',49.00,14,26),(2054,25,'38/2017','2022-07-01 00:00:00',38.00,7,25),(2055,91,'38/2017','2022-07-01 00:00:00',28.00,14,91),(2056,82,'38/2017','2022-07-15 00:00:00',52.80,7,82),(2057,83,'38/2017','2022-07-15 00:00:00',61.00,7,83),(2058,46,'38/2017','2022-07-15 00:00:00',13.50,21,46),(2059,50,'38/2017','2022-07-15 00:00:00',170.00,7,50),(2060,48,'38/2017','2022-07-15 00:00:00',53.00,7,48),(2061,26,'38/2017','2022-07-15 00:00:00',49.00,21,26),(2062,90,'38/2017','2022-07-15 00:00:00',23.00,7,90),(2063,82,'38/2017','2022-07-29 00:00:00',52.80,14,82),(2064,83,'38/2017','2022-07-29 00:00:00',61.00,14,83),(2065,46,'38/2017','2022-07-29 00:00:00',13.50,42,46),(2066,50,'38/2017','2022-07-29 00:00:00',170.00,14,50),(2067,48,'38/2017','2022-07-29 00:00:00',53.00,14,48),(2068,26,'38/2017','2022-07-29 00:00:00',49.00,42,26),(2069,90,'38/2017','2022-07-29 00:00:00',23.00,14,90),(2070,90,'38/2017','2022-10-28 00:00:00',23.00,28,90),(2071,71,'38/2017','2022-10-28 00:00:00',32.00,28,71),(2072,49,'088/2017','2022-05-20 00:00:00',86.00,70,49),(2073,47,'088/2017','2022-05-20 00:00:00',28.00,70,47),(2074,9,'088/2017','2022-05-20 00:00:00',750.00,70,9),(2075,46,'088/2017','2022-05-20 00:00:00',13.50,70,46),(2076,36,'088/2017','2022-07-29 00:00:00',75.00,168,36),(2077,46,'088/2017','2022-07-29 00:00:00',13.50,84,46),(2078,36,'088/2017','2022-10-21 00:00:00',75.00,168,36),(2079,46,'088/2017','2022-10-21 00:00:00',13.50,84,46),(2080,49,'88/2017','2022-03-25 00:00:00',86.00,56,49),(2081,47,'88/2017','2022-03-25 00:00:00',28.00,56,47),(2082,9,'88/2017','2022-03-25 00:00:00',750.00,56,9),(2083,46,'88/2017','2022-03-25 00:00:00',13.50,56,46),(2084,49,'88/2017','2022-05-20 00:00:00',86.00,70,49),(2085,47,'88/2017','2022-05-20 00:00:00',28.00,70,47),(2086,9,'88/2017','2022-05-20 00:00:00',750.00,140,9),(2087,49,'88/2017','2022-07-29 00:00:00',86.00,84,49),(2088,47,'88/2017','2022-07-29 00:00:00',28.00,84,47),(2089,9,'88/2017','2022-07-29 00:00:00',750.00,168,9),(2090,46,'88/2017','2022-07-29 00:00:00',13.50,84,46),(2091,49,'88/2017','2022-10-21 00:00:00',86.00,84,49),(2092,47,'88/2017','2022-10-21 00:00:00',28.00,84,47),(2093,9,'88/2017','2022-10-21 00:00:00',750.00,168,9),(2094,46,'88/2017','2022-10-21 00:00:00',13.50,84,46),(2095,85,'8/2014','2022-10-28 00:00:00',65.00,14,85),(2096,81,'203/2022','2022-11-04 00:00:00',68.00,7,81),(2097,83,'203/2022','2022-11-04 00:00:00',61.00,7,83),(2098,68,'203/2022','2022-11-04 00:00:00',35.00,7,68),(2099,12,'203/2022','2022-11-04 00:00:00',40.00,7,12),(2100,68,'292/2021','2022-11-04 00:00:00',35.00,112,68),(2101,69,'292/2021','2022-11-04 00:00:00',35.00,56,69),(2102,70,'292/2021','2022-11-04 00:00:00',41.31,56,70),(2103,31,'134/2020','2022-03-04 00:00:00',56.00,98,31),(2104,46,'134/2020','2022-03-04 00:00:00',13.50,147,46),(2105,83,'134/2020','2022-03-04 00:00:00',61.00,98,83),(2106,71,'134/2020','2022-03-04 00:00:00',32.00,49,71),(2107,36,'134/2020','2022-04-22 00:00:00',75.00,28,36),(2108,33,'134/2020','2022-04-22 00:00:00',24.00,28,33),(2109,46,'134/2020','2022-04-22 00:00:00',13.50,84,46),(2110,83,'134/2020','2022-04-22 00:00:00',61.00,56,83),(2111,71,'134/2020','2022-04-22 00:00:00',32.00,28,71),(2112,36,'134/2020','2022-05-20 00:00:00',75.00,56,36),(2113,82,'134/2020','2022-05-20 00:00:00',52.80,112,82),(2114,83,'134/2020','2022-05-20 00:00:00',61.00,56,83),(2115,82,'134/2020','2022-07-15 00:00:00',52.80,56,82),(2116,83,'134/2020','2022-07-15 00:00:00',61.00,56,83),(2117,36,'134/2020','2022-07-15 00:00:00',75.00,56,36),(2118,33,'134/2020','2022-07-15 00:00:00',24.00,56,33),(2119,71,'134/2020','2022-07-15 00:00:00',32.00,56,71),(2120,46,'134/2020','2022-07-15 00:00:00',13.50,56,46),(2121,82,'134/2020','2022-09-09 00:00:00',52.80,84,82),(2122,83,'134/2020','2022-09-09 00:00:00',61.00,84,83),(2123,36,'134/2020','2022-09-09 00:00:00',75.00,84,36),(2124,33,'134/2020','2022-09-09 00:00:00',24.00,84,33),(2125,71,'134/2020','2022-09-09 00:00:00',32.00,84,71),(2126,46,'134/2020','2022-09-09 00:00:00',13.50,252,46),(2127,82,'134/2020','2022-11-04 00:00:00',52.80,84,82),(2128,83,'134/2020','2022-11-04 00:00:00',61.00,84,83),(2129,36,'134/2020','2022-11-04 00:00:00',75.00,84,36),(2130,33,'134/2020','2022-11-04 00:00:00',24.00,84,33),(2131,71,'134/2020','2022-11-04 00:00:00',32.00,84,71),(2132,46,'134/2020','2022-11-04 00:00:00',13.50,252,46),(2133,72,'182/2021','2022-05-13 00:00:00',85.00,70,72),(2134,71,'182/2021','2022-05-13 00:00:00',32.00,70,71),(2135,46,'182/2021','2022-05-13 00:00:00',13.50,210,46),(2136,83,'182/2021','2022-05-13 00:00:00',61.00,140,83),(2137,25,'182/2021','2022-05-13 00:00:00',38.00,210,25),(2138,48,'182/2021','2022-05-13 00:00:00',53.00,70,48),(2139,72,'182/2021','2022-07-08 00:00:00',85.00,84,72),(2140,46,'182/2021','2022-07-08 00:00:00',13.50,252,46),(2141,83,'182/2021','2022-07-08 00:00:00',61.00,168,83),(2142,25,'182/2021','2022-07-08 00:00:00',38.00,252,25),(2143,48,'182/2021','2022-07-08 00:00:00',53.00,84,48),(2144,83,'182/2021','2022-11-04 00:00:00',61.00,84,83),(2145,82,'182/2021','2022-11-04 00:00:00',52.80,42,82),(2146,71,'182/2021','2022-11-04 00:00:00',32.00,42,71),(2147,26,'182/2021','2022-11-04 00:00:00',49.00,84,26),(2148,49,'182/2021','2022-11-04 00:00:00',86.00,63,49),(2149,46,'182/2021','2022-11-04 00:00:00',13.50,126,46),(2150,82,'34/2018','2022-02-25 00:00:00',52.80,84,82),(2151,36,'34/2018','2022-02-25 00:00:00',75.00,28,36),(2152,33,'34/2018','2022-02-25 00:00:00',24.00,28,33),(2153,46,'34/2018','2022-02-25 00:00:00',13.50,28,46),(2154,82,'34/2018','2022-04-22 00:00:00',52.80,168,82),(2155,36,'34/2018','2022-04-22 00:00:00',75.00,56,36),(2156,46,'34/2018','2022-04-22 00:00:00',13.50,112,46),(2157,82,'34/2018','2022-06-17 00:00:00',52.80,168,82),(2158,36,'34/2018','2022-06-17 00:00:00',75.00,56,36),(2159,33,'34/2018','2022-06-17 00:00:00',24.00,56,33),(2160,46,'34/2018','2022-06-17 00:00:00',13.50,56,46),(2161,82,'34/2018','2022-08-12 00:00:00',52.80,252,82),(2162,36,'34/2018','2022-08-12 00:00:00',75.00,84,36),(2163,33,'34/2018','2022-08-12 00:00:00',24.00,84,33),(2164,46,'34/2018','2022-08-12 00:00:00',13.50,84,46),(2165,82,'34/2018','2022-11-04 00:00:00',52.80,168,82),(2166,36,'34/2018','2022-11-04 00:00:00',75.00,56,36),(2167,33,'34/2018','2022-11-04 00:00:00',24.00,56,33),(2168,46,'34/2018','2022-11-04 00:00:00',13.50,56,46),(2169,34,'106/2017','2022-06-03 00:00:00',39.50,56,34),(2170,46,'106/2017','2022-06-03 00:00:00',13.50,56,46),(2171,34,'106/2017','2022-07-29 00:00:00',39.50,56,34),(2172,46,'106/2017','2022-07-29 00:00:00',13.50,56,46),(2173,34,'106/2017','2022-08-12 00:00:00',39.50,84,34),(2174,46,'106/2017','2022-08-12 00:00:00',13.50,84,46),(2175,34,'106/2017','2022-11-04 00:00:00',39.50,56,34),(2176,46,'106/2017','2022-11-04 00:00:00',13.50,56,46),(2177,47,'118/2022','2022-07-22 00:00:00',28.00,7,47),(2178,82,'118/2022','2022-07-22 00:00:00',52.80,14,82),(2179,82,'118/2022','2022-07-29 00:00:00',52.80,63,82),(2180,50,'118/2022','2022-07-29 00:00:00',170.00,42,50),(2181,82,'118/2022','2022-08-12 00:00:00',52.80,7,82),(2182,83,'118/2022','2022-08-12 00:00:00',61.00,7,83),(2183,47,'118/2022','2022-08-12 00:00:00',28.00,7,47),(2184,82,'118/2022','2022-08-19 00:00:00',52.80,21,82),(2185,83,'118/2022','2022-08-19 00:00:00',61.00,21,83),(2186,47,'118/2022','2022-08-19 00:00:00',28.00,21,47),(2187,82,'118/2022','2022-09-02 00:00:00',52.80,35,82),(2188,83,'118/2022','2022-09-02 00:00:00',61.00,35,83),(2189,47,'118/2022','2022-09-02 00:00:00',28.00,35,47),(2190,82,'118/2022','2022-11-04 00:00:00',52.80,35,82),(2191,83,'118/2022','2022-11-04 00:00:00',61.00,35,83),(2192,47,'118/2022','2022-11-04 00:00:00',28.00,35,47),(2193,69,'02/2022','2022-11-04 00:00:00',35.00,42,69),(2194,12,'02/2022','2022-11-04 00:00:00',40.00,42,12),(2195,19,'080/2020','2022-11-04 00:00:00',45.00,42,19),(2196,45,'080/2020','2022-11-04 00:00:00',46.20,14,45),(2197,83,'133/2022','2022-11-04 00:00:00',61.00,56,83),(2198,36,'133/2022','2022-11-04 00:00:00',75.00,28,36),(2199,70,'133/2022','2022-11-04 00:00:00',41.31,28,70),(2200,58,'89/2018','2022-05-20 00:00:00',41.40,140,58),(2201,71,'89/2018','2022-05-20 00:00:00',32.00,70,71),(2202,24,'89/2018','2022-05-20 00:00:00',64.00,70,24),(2203,58,'89/2018','2022-07-29 00:00:00',41.40,168,58),(2204,70,'89/2018','2022-07-29 00:00:00',41.31,84,70),(2205,24,'89/2018','2022-07-29 00:00:00',64.00,84,24),(2206,70,'89/2018','2022-11-04 00:00:00',41.31,42,70),(2207,58,'89/2018','2022-11-04 00:00:00',41.40,84,58),(2208,24,'89/2018','2022-11-04 00:00:00',64.00,42,24),(2209,33,'237/2022','2022-11-04 00:00:00',24.00,7,33),(2210,22,'201/2022','2022-11-04 00:00:00',39.00,28,22),(2211,35,'201/2022','2022-11-04 00:00:00',49.00,28,35),(2212,46,'201/2022','2022-11-04 00:00:00',13.50,28,46),(2213,29,'92/2022','2022-11-04 00:00:00',16.30,63,29),(2214,25,'92/2022','2022-11-04 00:00:00',38.00,21,25),(2215,46,'92/2022','2022-11-04 00:00:00',13.50,42,46),(2216,45,'211/2019','2022-11-04 00:00:00',46.20,56,45),(2217,87,'211/2019','2022-11-04 00:00:00',54.00,32,87),(2218,81,'211/2019','2022-11-04 00:00:00',68.00,56,81),(2219,33,'211/2019','2022-11-04 00:00:00',24.00,28,33),(2220,76,'211/2019','2022-11-04 00:00:00',18.85,56,76),(2221,6,'04/2022','2022-11-04 00:00:00',119.00,14,6),(2222,65,'04/2022','2022-11-04 00:00:00',84.00,14,65),(2223,47,'04/2022','2022-11-04 00:00:00',28.00,14,47),(2224,58,'206/2021','2022-08-12 00:00:00',41.40,168,58),(2225,34,'206/2021','2022-08-12 00:00:00',39.50,84,34),(2226,58,'206/2021','2022-11-04 00:00:00',41.40,112,58),(2227,33,'206/2021','2022-11-04 00:00:00',24.00,56,33),(2228,83,'16/2021','2022-11-04 00:00:00',61.00,56,83),(2229,68,'16/2021','2022-11-04 00:00:00',35.00,28,68),(2230,46,'16/2021','2022-11-04 00:00:00',13.50,28,46),(2231,92,'170/2022','2022-11-04 00:00:00',126.05,2,92),(2232,71,'49/2017','2022-11-11 00:00:00',32.00,84,71),(2233,70,'49/2017','2022-11-11 00:00:00',41.31,84,70),(2234,70,'49/2017','2022-08-19 00:00:00',41.31,84,70),(2235,71,'49/2017','2022-08-19 00:00:00',32.00,84,71),(2236,83,'204/2022','2022-11-11 00:00:00',61.00,28,83),(2237,82,'204/2022','2022-11-11 00:00:00',52.80,14,82),(2238,69,'204/2022','2022-11-11 00:00:00',35.00,14,69),(2239,36,'204/2022','2022-11-11 00:00:00',75.00,14,36),(2240,33,'204/2022','2022-11-11 00:00:00',24.00,14,33),(2241,28,'204/2022','2022-11-11 00:00:00',45.00,21,28),(2242,46,'204/2022','2022-11-11 00:00:00',13.50,28,46),(2243,85,'8/2014','2022-11-11 00:00:00',65.00,112,85),(2244,83,'155/2022','2022-11-11 00:00:00',61.00,112,83),(2245,34,'155/2022','2022-11-11 00:00:00',39.50,56,34),(2246,50,'158/2020','2022-11-11 00:00:00',170.00,56,50),(2247,48,'158/2020','2022-11-11 00:00:00',53.00,56,48),(2248,83,'158/2020','2022-11-11 00:00:00',61.00,112,83),(2249,82,'158/2020','2022-11-11 00:00:00',52.80,56,82),(2250,36,'158/2020','2022-09-16 00:00:00',75.00,56,36),(2251,50,'158/2020','2022-09-16 00:00:00',170.00,56,50),(2252,48,'158/2020','2022-09-16 00:00:00',53.00,56,48),(2253,83,'158/2020','2022-09-16 00:00:00',61.00,112,83),(2254,82,'158/2020','2022-09-16 00:00:00',52.80,56,82),(2255,39,'158/2020','2022-09-16 00:00:00',69.00,168,39),(2256,38,'112/2018','2022-09-16 00:00:00',107.00,112,38),(2257,19,'112/2018','2022-09-16 00:00:00',45.00,28,19),(2258,38,'112/2018','2022-11-11 00:00:00',107.00,168,38),(2259,19,'112/2018','2022-11-11 00:00:00',45.00,42,19),(2260,38,'07/2017','2022-09-16 00:00:00',107.00,112,38),(2261,19,'07/2017','2022-09-16 00:00:00',45.00,56,19),(2262,39,'07/2017','2022-11-11 00:00:00',69.00,168,39),(2263,19,'07/2017','2022-11-11 00:00:00',45.00,84,19),(2264,36,'138/2019','2022-11-11 00:00:00',75.00,42,36),(2265,49,'138/2019','2022-11-11 00:00:00',86.00,42,49),(2266,34,'138/2019','2022-11-11 00:00:00',39.50,84,34),(2267,46,'138/2019','2022-11-11 00:00:00',13.50,84,46),(2268,49,'48/2017','2022-11-11 00:00:00',86.00,42,49),(2269,48,'48/2017','2022-11-11 00:00:00',53.00,42,48),(2270,35,'48/2017','2022-11-11 00:00:00',49.00,42,35),(2271,46,'48/2017','2022-11-11 00:00:00',13.50,126,46),(2272,83,'250/2021','2022-11-11 00:00:00',61.00,112,83),(2273,22,'250/2021','2022-11-11 00:00:00',39.00,56,22),(2274,68,'250/2021','2022-11-11 00:00:00',35.00,56,68),(2275,83,'250/2021','2022-09-30 00:00:00',61.00,84,83),(2276,12,'250/2021','2022-09-30 00:00:00',40.00,42,12),(2277,68,'250/2021','2022-09-30 00:00:00',35.00,42,68),(2278,29,'92/2022','2022-11-11 00:00:00',16.30,168,29),(2279,25,'92/2022','2022-11-11 00:00:00',38.00,56,25),(2280,46,'92/2022','2022-11-11 00:00:00',13.50,112,46),(2281,11,'36/2020','2022-11-11 00:00:00',129.00,2,11),(2282,49,'36/2020','2022-11-11 00:00:00',86.00,28,49),(2283,47,'36/2020','2022-11-11 00:00:00',28.00,28,47),(2284,46,'36/2020','2022-11-11 00:00:00',13.50,56,46),(2285,82,'288/2021','2022-11-11 00:00:00',52.80,168,82),(2286,46,'288/2021','2022-11-11 00:00:00',13.50,168,46),(2287,34,'288/2021','2022-11-11 00:00:00',39.50,56,34),(2288,19,'288/2021','2022-11-11 00:00:00',45.00,112,19),(2289,79,'190/2022','2022-11-11 00:00:00',55.59,56,79),(2290,35,'190/2022','2022-11-11 00:00:00',49.00,28,35),(2291,46,'190/2022','2022-11-11 00:00:00',13.50,28,46),(2292,89,'190/2022','2022-11-11 00:00:00',34.50,28,89),(2293,79,'190/2022','2022-09-16 00:00:00',55.59,28,79),(2294,35,'190/2022','2022-09-16 00:00:00',49.00,14,35),(2295,46,'190/2022','2022-09-16 00:00:00',13.50,14,46),(2296,89,'190/2022','2022-09-16 00:00:00',34.50,14,89),(2297,34,'237/2022','2022-11-11 00:00:00',39.50,21,34),(2298,46,'237/2022','2022-11-11 00:00:00',13.50,21,46),(2299,83,'247/2021','2022-11-11 00:00:00',61.00,56,83),(2300,82,'247/2021','2022-11-11 00:00:00',52.80,28,82),(2301,36,'247/2021','2022-11-11 00:00:00',75.00,28,36),(2302,33,'247/2021','2022-11-11 00:00:00',24.00,28,33),(2303,46,'247/2021','2022-11-11 00:00:00',13.50,84,46),(2304,71,'247/2021','2022-11-11 00:00:00',32.00,28,71),(2305,87,'247/2021','2022-11-11 00:00:00',54.00,42,87),(2306,3,'247/2021','2022-11-11 00:00:00',170.00,28,3),(2307,82,'135/2022','2022-11-11 00:00:00',52.80,84,82),(2308,83,'135/2022','2022-11-11 00:00:00',61.00,84,83),(2309,68,'135/2022','2022-11-11 00:00:00',35.00,126,68),(2310,34,'135/2022','2022-11-11 00:00:00',39.50,84,34),(2311,36,'135/2022','2022-11-11 00:00:00',75.00,84,36),(2312,46,'135/2022','2022-11-11 00:00:00',13.50,252,46),(2313,48,'135/2022','2022-11-11 00:00:00',53.00,84,48),(2314,70,'135/2022','2022-11-11 00:00:00',41.31,84,70),(2315,71,'263/2021','2022-08-12 00:00:00',32.00,21,71),(2316,3,'263/2021','2022-08-12 00:00:00',170.00,14,3),(2317,71,'263/2021','2022-11-11 00:00:00',32.00,56,71),(2318,3,'263/2021','2022-11-11 00:00:00',170.00,14,3),(2319,36,'130/2022','2022-11-11 00:00:00',75.00,58,36),(2320,70,'130/2022','2022-11-11 00:00:00',41.31,56,70),(2321,46,'130/2022','2022-11-11 00:00:00',13.50,56,46),(2322,82,'90/2017','2022-11-11 00:00:00',52.80,28,82),(2323,83,'90/2017','2022-11-11 00:00:00',61.00,56,83),(2324,46,'90/2017','2022-11-11 00:00:00',13.50,168,46),(2325,76,'90/2017','2022-11-11 00:00:00',18.85,56,76),(2326,73,'90/2017','2022-11-11 00:00:00',126.50,56,73),(2327,72,'90/2017','2022-11-11 00:00:00',85.00,56,72),(2328,49,'90/2017','2022-11-11 00:00:00',86.00,56,49),(2329,48,'90/2017','2022-11-11 00:00:00',53.00,56,48),(2330,4,'243/2022','2022-11-11 00:00:00',46.00,14,4),(2331,4,'242/2022','2022-11-11 00:00:00',46.00,14,4),(2332,36,'205/2022','2022-11-11 00:00:00',75.00,112,36),(2333,29,'205/2022','2022-11-11 00:00:00',16.30,168,29),(2334,46,'205/2022','2022-11-11 00:00:00',13.50,112,46),(2335,20,'205/2022','2022-11-11 00:00:00',95.00,56,20),(2336,22,'205/2022','2022-11-11 00:00:00',39.00,56,22),(2337,56,'205/2022','2022-11-11 00:00:00',61.90,112,56),(2338,5,'202/2021','2022-11-11 00:00:00',85.00,56,5),(2339,34,'238/2022','2022-11-04 00:00:00',39.50,21,34),(2340,34,'238/2022','2022-11-11 00:00:00',39.50,7,34),(2341,83,'203/2022','2022-11-11 00:00:00',61.00,28,83),(2342,50,'65/2021','2022-11-11 00:00:00',170.00,70,50),(2343,49,'65/2021','2022-11-11 00:00:00',86.00,70,49),(2344,35,'65/2021','2022-11-11 00:00:00',49.00,70,35),(2345,46,'65/2021','2022-11-11 00:00:00',13.50,70,46),(2346,34,'202/2022','2022-11-11 00:00:00',39.50,56,34),(2347,46,'202/2022','2022-11-11 00:00:00',13.50,112,46),(2348,68,'203/2022','2022-11-18 00:00:00',35.00,7,68),(2349,69,'203/2022','2022-11-18 00:00:00',35.00,7,69),(2350,22,'203/2022','2022-11-18 00:00:00',39.00,7,22),(2351,3,'203/2022','2022-11-18 00:00:00',170.00,7,3),(2352,48,'28/2020','2022-11-18 00:00:00',53.00,7,48),(2353,47,'28/2020','2022-11-18 00:00:00',28.00,7,47),(2354,34,'28/2020','2022-11-18 00:00:00',39.50,7,34),(2355,81,'90/2022','2022-11-18 00:00:00',68.00,42,81),(2356,86,'90/2022','2022-11-18 00:00:00',96.00,84,86),(2357,33,'90/2022','2022-11-18 00:00:00',24.00,42,33),(2358,82,'0130/2017','2022-11-18 00:00:00',52.80,126,82),(2359,43,'0130/2017','2022-11-18 00:00:00',84.50,84,43),(2360,65,'0130/2017','2022-11-18 00:00:00',84.00,42,65),(2361,50,'9/2018','2022-11-18 00:00:00',170.00,84,50),(2362,49,'9/2018','2022-11-18 00:00:00',86.00,84,49),(2363,46,'9/2018','2022-11-18 00:00:00',13.50,168,46),(2364,34,'9/2018','2022-11-18 00:00:00',39.50,84,34),(2365,35,'9/2018','2022-11-18 00:00:00',49.00,84,35),(2366,65,'04/2022','2022-11-18 00:00:00',84.00,42,65),(2367,3,'04/2022','2022-11-18 00:00:00',170.00,42,3),(2368,6,'04/2022','2022-11-18 00:00:00',119.00,42,6),(2369,48,'28/2020','2022-11-25 00:00:00',53.00,21,48),(2370,47,'28/2020','2022-11-25 00:00:00',28.00,21,47),(2371,34,'28/2020','2022-11-25 00:00:00',39.50,21,34),(2372,82,'232/2021','2022-11-25 00:00:00',52.80,112,82),(2373,83,'232/2021','2022-11-25 00:00:00',61.00,56,83),(2374,36,'232/2021','2022-11-25 00:00:00',75.00,56,36),(2375,46,'232/2021','2022-11-25 00:00:00',13.50,168,46),(2376,49,'232/2021','2022-11-25 00:00:00',86.00,56,49),(2377,20,'59/2021','2022-11-25 00:00:00',95.00,70,20),(2378,65,'59/2021','2022-11-25 00:00:00',84.00,105,65),(2379,19,'59/2021','2022-11-25 00:00:00',45.00,35,19),(2380,4,'243/2022','2022-11-25 00:00:00',46.00,21,4),(2381,29,'92/2022','2022-11-25 00:00:00',16.30,168,29),(2382,25,'92/2022','2022-11-25 00:00:00',38.00,56,25),(2383,46,'92/2022','2022-11-25 00:00:00',13.50,112,46),(2384,33,'249/2022','2022-11-25 00:00:00',24.00,14,33),(2385,12,'201/2022','2022-11-25 00:00:00',40.00,28,12),(2386,36,'201/2022','2022-11-25 00:00:00',75.00,28,36),(2387,46,'201/2022','2022-11-25 00:00:00',13.50,28,46),(2388,49,'137/2022','2022-11-25 00:00:00',86.00,70,49),(2389,35,'196/2021','2022-11-25 00:00:00',49.00,84,35),(2390,46,'196/2021','2022-11-25 00:00:00',13.50,84,46),(2391,9,'63/2018','2022-11-25 00:00:00',750.00,84,9),(2392,8,'63/2018','2022-11-25 00:00:00',72.00,84,8),(2393,46,'63/2018','2022-11-25 00:00:00',13.50,84,46),(2394,82,'059/2021','2022-11-25 00:00:00',52.80,35,82),(2395,83,'059/2021','2022-11-25 00:00:00',61.00,35,83),(2396,71,'059/2021','2022-11-25 00:00:00',32.00,35,71),(2397,28,'136/2022','2022-09-30 00:00:00',45.00,126,28),(2398,35,'136/2022','2022-09-30 00:00:00',49.00,84,35),(2399,46,'136/2022','2022-09-30 00:00:00',13.50,84,46),(2400,28,'136/2022','2022-11-25 00:00:00',45.00,84,28),(2401,35,'136/2022','2022-11-25 00:00:00',49.00,168,35),(2402,46,'136/2022','2022-11-25 00:00:00',13.50,84,46),(2403,92,'77/2017','2022-11-25 00:00:00',126.05,1,92),(2404,93,'77/2017','2022-11-25 00:00:00',52.50,2,93),(2405,5,'242/2022','2022-11-25 00:00:00',85.00,28,5),(2406,83,'203/2022','2022-11-25 00:00:00',61.00,56,83),(2407,68,'203/2022','2022-11-25 00:00:00',35.00,28,68),(2408,12,'203/2022','2022-11-25 00:00:00',40.00,28,12),(2409,23,'203/2022','2022-11-25 00:00:00',33.32,28,23),(2410,3,'203/2022','2022-11-25 00:00:00',170.00,14,3),(2411,83,'204/2022','2022-11-25 00:00:00',61.00,56,83),(2412,82,'204/2022','2022-11-25 00:00:00',52.80,28,82),(2413,35,'204/2022','2022-11-25 00:00:00',49.00,28,35),(2414,28,'204/2022','2022-11-25 00:00:00',45.00,42,28),(2415,46,'204/2022','2022-11-25 00:00:00',13.50,84,46),(2416,11,'52/2022','2022-12-02 00:00:00',129.00,4,11),(2417,92,'52/2022','2022-12-02 00:00:00',126.05,2,92),(2418,82,'287/2021','2022-12-02 00:00:00',52.80,112,82),(2419,83,'287/2021','2022-12-02 00:00:00',61.00,112,83),(2420,34,'287/2021','2022-12-02 00:00:00',39.50,336,34),(2421,46,'287/2021','2022-12-02 00:00:00',13.50,224,46),(2422,65,'249/2021','2022-12-02 00:00:00',84.00,42,65),(2423,71,'249/2021','2022-12-02 00:00:00',32.00,42,71),(2424,89,'249/2021','2022-12-02 00:00:00',34.50,42,89),(2425,34,'237/2022','2022-12-02 00:00:00',39.50,28,34),(2426,46,'237/2022','2022-12-02 00:00:00',13.50,28,46),(2427,82,'34/2018','2022-12-02 00:00:00',52.80,252,82),(2428,35,'34/2018','2022-12-02 00:00:00',49.00,84,35),(2429,33,'34/2018','2022-12-02 00:00:00',24.00,168,33),(2430,46,'34/2018','2022-12-02 00:00:00',13.50,84,46),(2431,19,'080/2020','2022-12-02 00:00:00',45.00,126,19),(2432,45,'080/2020','2022-12-02 00:00:00',46.20,42,45),(2433,5,'168/2021','2022-12-02 00:00:00',85.00,56,5),(2434,56,'168/2021','2022-12-02 00:00:00',61.90,20,56),(2435,83,'137/2017','2022-12-02 00:00:00',61.00,168,83),(2436,26,'137/2017','2022-12-02 00:00:00',49.00,126,26),(2437,76,'137/2017','2022-12-02 00:00:00',18.85,84,76),(2438,46,'137/2017','2022-12-02 00:00:00',13.50,252,46),(2439,33,'115/2022','2022-12-02 00:00:00',24.00,84,33),(2440,83,'15/2021','2022-12-02 00:00:00',61.00,168,83),(2441,82,'15/2021','2022-12-02 00:00:00',52.80,84,82),(2442,22,'15/2021','2022-12-02 00:00:00',39.00,84,22),(2443,67,'15/2021','2022-12-02 00:00:00',21.50,84,67),(2444,82,'54/2017','2022-12-02 00:00:00',52.80,28,82),(2445,83,'54/2017','2022-12-02 00:00:00',61.00,28,83),(2446,68,'54/2017','2022-12-02 00:00:00',35.00,28,68),(2447,46,'54/2017','2022-12-02 00:00:00',13.50,28,46),(2448,8,'54/2017','2022-12-02 00:00:00',72.00,28,8),(2449,83,'16/2021','2022-12-02 00:00:00',61.00,168,83),(2450,68,'16/2021','2022-12-02 00:00:00',35.00,84,68),(2451,46,'16/2021','2022-12-02 00:00:00',13.50,84,46),(2452,83,'90/2017','2022-12-02 00:00:00',61.00,63,83),(2453,46,'90/2017','2022-12-02 00:00:00',13.50,84,46),(2454,49,'90/2017','2022-12-02 00:00:00',86.00,21,49),(2455,47,'90/2017','2022-12-02 00:00:00',28.00,21,47),(2456,76,'90/2017','2022-12-02 00:00:00',18.85,21,76),(2457,70,'90/2017','2022-12-02 00:00:00',41.31,21,70),(2458,33,'045/2020','2022-12-02 00:00:00',24.00,7,33),(2459,33,'045/2020','2022-12-09 00:00:00',24.00,21,33),(2460,83,'93/2017','2022-12-09 00:00:00',61.00,84,83),(2461,50,'93/2017','2022-12-09 00:00:00',170.00,42,50),(2462,48,'93/2017','2022-12-09 00:00:00',53.00,84,48),(2463,46,'93/2017','2022-12-09 00:00:00',13.50,126,46),(2464,70,'93/2017','2022-12-09 00:00:00',41.31,42,70),(2465,82,'134/2022','2022-12-09 00:00:00',52.80,56,82),(2466,83,'134/2022','2022-12-09 00:00:00',61.00,56,83),(2467,69,'134/2022','2022-12-09 00:00:00',35.00,56,69),(2468,82,'92/2018','2022-12-09 00:00:00',52.80,56,82),(2469,83,'92/2018','2022-12-09 00:00:00',61.00,56,83),(2470,68,'92/2018','2022-12-09 00:00:00',35.00,56,68),(2471,37,'92/2018','2022-12-09 00:00:00',16.49,112,37),(2472,45,'211/2019','2022-12-09 00:00:00',46.20,84,45),(2473,87,'211/2019','2022-12-09 00:00:00',54.00,84,87),(2474,82,'211/2019','2022-12-09 00:00:00',52.80,56,82),(2475,81,'211/2019','2022-12-09 00:00:00',68.00,56,81),(2476,46,'211/2019','2022-12-09 00:00:00',13.50,112,46),(2477,5,'211/2019','2022-12-09 00:00:00',85.00,56,5),(2478,76,'211/2019','2022-12-09 00:00:00',18.85,112,76),(2479,69,'211/2019','2022-12-09 00:00:00',35.00,56,69),(2480,11,'231/2021','2022-12-09 00:00:00',129.00,1,11),(2481,49,'231/2021','2022-12-09 00:00:00',86.00,56,49),(2482,48,'231/2021','2022-12-09 00:00:00',53.00,56,48),(2483,92,'231/2021','2022-12-09 00:00:00',126.05,1,92),(2484,46,'231/2021','2022-12-09 00:00:00',13.50,56,46),(2485,93,'231/2021','2022-12-09 00:00:00',52.50,4,93),(2486,11,'36/2020','2022-12-09 00:00:00',129.00,2,11),(2487,49,'36/2020','2022-12-09 00:00:00',86.00,42,49),(2488,46,'36/2020','2022-12-09 00:00:00',13.50,84,46),(2489,82,'288/2021','2022-12-09 00:00:00',52.80,168,82),(2490,33,'288/2021','2022-12-09 00:00:00',24.00,56,33),(2491,46,'288/2021','2022-12-09 00:00:00',13.50,168,46),(2492,19,'288/2021','2022-12-09 00:00:00',45.00,168,19),(2493,83,'01/2018','2022-12-09 00:00:00',61.00,168,83),(2494,50,'01/2018','2022-12-09 00:00:00',170.00,84,50),(2495,68,'01/2018','2022-12-09 00:00:00',35.00,84,68),(2496,67,'01/2018','2022-12-09 00:00:00',21.50,84,67),(2497,22,'01/2018','2022-12-09 00:00:00',39.00,84,22),(2498,92,'77/2017','2022-12-09 00:00:00',126.05,28,92),(2499,93,'77/2017','2022-12-09 00:00:00',52.50,2,93),(2500,83,'58/2021','2022-12-09 00:00:00',61.00,112,83),(2501,47,'58/2021','2022-12-09 00:00:00',28.00,56,47),(2502,46,'58/2021','2022-12-09 00:00:00',13.50,224,46),(2503,21,'161/2019','2022-12-09 00:00:00',58.00,168,21),(2504,69,'161/2019','2022-12-09 00:00:00',35.00,84,69),(2505,81,'203/2022','2022-12-09 00:00:00',68.00,28,81),(2506,83,'203/2022','2022-12-09 00:00:00',61.00,28,83),(2507,68,'203/2022','2022-12-09 00:00:00',35.00,28,68),(2508,69,'203/2022','2022-12-09 00:00:00',35.00,28,69),(2509,12,'203/2022','2022-12-09 00:00:00',40.00,28,12),(2510,23,'203/2022','2022-12-09 00:00:00',33.32,28,23),(2511,3,'203/2022','2022-12-09 00:00:00',170.00,10,3),(2512,46,'203/2022','2022-12-09 00:00:00',13.50,28,46),(2513,83,'247/2021','2022-12-09 00:00:00',61.00,28,83),(2514,82,'247/2021','2022-12-09 00:00:00',52.80,28,82),(2515,46,'247/2021','2022-12-09 00:00:00',13.50,32,46),(2516,71,'247/2021','2022-12-09 00:00:00',32.00,14,71),(2517,87,'247/2021','2022-12-09 00:00:00',54.00,21,87),(2518,89,'247/2021','2022-12-09 00:00:00',34.50,14,89),(2519,35,'112/2017','2022-12-09 00:00:00',49.00,84,35),(2520,46,'112/2017','2022-12-09 00:00:00',13.50,84,46),(2521,34,'249/2022','2022-12-09 00:00:00',39.50,14,34),(2522,46,'249/2022','2022-12-09 00:00:00',13.50,14,46),(2523,83,'0078/2022','2022-12-09 00:00:00',61.00,168,83),(2524,49,'0078/2022','2022-12-09 00:00:00',86.00,84,49),(2525,46,'0078/2022','2022-12-09 00:00:00',13.50,168,46),(2526,83,'182/2021','2022-12-16 00:00:00',61.00,56,83),(2527,82,'182/2021','2022-12-16 00:00:00',52.80,28,82),(2528,26,'182/2021','2022-12-16 00:00:00',49.00,56,26),(2529,49,'182/2021','2022-12-16 00:00:00',86.00,42,49),(2530,46,'182/2021','2022-12-16 00:00:00',13.50,72,46),(2531,82,'118/2022','2022-12-16 00:00:00',52.80,42,82),(2532,83,'118/2022','2022-12-16 00:00:00',61.00,42,83),(2533,47,'118/2022','2022-12-16 00:00:00',28.00,42,47),(2534,92,'170/2022','2022-12-16 00:00:00',126.05,2,92),(2535,58,'89/2018','2022-12-16 00:00:00',41.40,112,58),(2536,70,'89/2018','2022-12-16 00:00:00',41.31,56,70),(2537,24,'89/2018','2022-12-16 00:00:00',64.00,56,24),(2538,4,'243/2022','2022-12-16 00:00:00',46.00,21,4),(2539,69,'02/2022','2022-12-16 00:00:00',35.00,84,69),(2540,22,'02/2022','2022-12-16 00:00:00',39.00,84,22),(2541,36,'270/2022','2022-12-23 00:00:00',75.00,21,36),(2542,89,'270/2022','2022-12-23 00:00:00',34.50,42,89),(2543,93,'270/2022','2022-12-23 00:00:00',52.50,2,93),(2544,46,'270/2022','2022-12-23 00:00:00',13.50,42,46),(2545,34,'270/2022','2022-12-23 00:00:00',39.50,7,34),(2546,89,'270/2022','2022-12-23 00:00:00',34.50,14,89),(2547,93,'270/2022','2022-12-23 00:00:00',52.50,1,93),(2548,46,'270/2022','2022-12-23 00:00:00',13.50,14,46),(2549,48,'28/2020','2022-12-23 00:00:00',53.00,42,48),(2550,47,'28/2020','2022-12-23 00:00:00',28.00,42,47),(2551,36,'28/2020','2022-12-23 00:00:00',75.00,21,36),(2552,49,'45/2017','2022-12-23 00:00:00',86.00,28,49),(2553,83,'75/2019','2022-12-23 00:00:00',61.00,84,83),(2554,68,'75/2019','2022-12-23 00:00:00',35.00,168,68),(2555,46,'75/2019','2022-12-23 00:00:00',13.50,252,46),(2556,82,'137/2020','2022-09-30 00:00:00',52.80,56,82),(2557,83,'137/2020','2022-09-30 00:00:00',61.00,56,83),(2558,36,'137/2020','2022-09-30 00:00:00',75.00,56,36),(2559,48,'137/2020','2022-09-30 00:00:00',53.00,56,48),(2560,82,'137/2020','2022-04-15 00:00:00',52.80,84,82),(2561,83,'137/2020','2022-04-15 00:00:00',61.00,84,83),(2562,36,'137/2020','2022-04-15 00:00:00',75.00,84,36),(2563,49,'137/2020','2022-04-15 00:00:00',86.00,84,49),(2564,48,'137/2020','2022-04-15 00:00:00',53.00,84,48),(2565,46,'137/2020','2022-04-15 00:00:00',13.50,168,46),(2566,82,'137/2020','2022-12-23 00:00:00',52.80,84,82),(2567,83,'137/2020','2022-12-23 00:00:00',61.00,84,83),(2568,36,'137/2020','2022-12-23 00:00:00',75.00,84,36),(2569,49,'137/2020','2022-12-23 00:00:00',86.00,84,49),(2570,46,'137/2020','2022-12-23 00:00:00',13.50,84,46),(2571,12,'201/2022','2022-12-23 00:00:00',40.00,42,12),(2572,36,'201/2022','2022-12-23 00:00:00',75.00,42,36),(2573,33,'201/2022','2022-12-23 00:00:00',24.00,42,33),(2574,46,'201/2022','2022-12-23 00:00:00',13.50,42,46),(2575,49,'48/2017','2022-12-23 00:00:00',86.00,70,49),(2576,48,'48/2017','2022-12-23 00:00:00',53.00,70,48),(2577,47,'48/2017','2022-12-23 00:00:00',28.00,70,47),(2578,35,'48/2017','2022-12-23 00:00:00',49.00,70,35),(2579,46,'48/2017','2022-12-23 00:00:00',13.50,210,46),(2580,83,'47/2017','2022-09-30 00:00:00',61.00,84,83),(2581,70,'47/2017','2022-09-30 00:00:00',41.31,84,70),(2582,83,'47/2017','2022-12-23 00:00:00',61.00,84,83),(2583,71,'47/2017','2022-12-23 00:00:00',32.00,84,71),(2584,83,'204/2022','2022-12-23 00:00:00',61.00,56,83),(2585,82,'204/2022','2022-12-23 00:00:00',52.80,28,82),(2586,68,'204/2022','2022-12-23 00:00:00',35.00,28,68),(2587,35,'204/2022','2022-12-23 00:00:00',49.00,28,35),(2588,28,'204/2022','2022-12-23 00:00:00',45.00,42,28),(2589,46,'204/2022','2022-12-23 00:00:00',13.50,56,46),(2590,83,'247/2021','2022-12-23 00:00:00',61.00,14,83),(2591,82,'247/2021','2022-12-23 00:00:00',52.80,14,82),(2592,35,'247/2021','2022-12-23 00:00:00',49.00,7,35),(2593,34,'247/2021','2022-12-23 00:00:00',39.50,7,34),(2594,46,'247/2021','2022-12-23 00:00:00',13.50,28,46),(2595,71,'247/2021','2022-12-23 00:00:00',32.00,7,71),(2596,87,'247/2021','2022-12-23 00:00:00',54.00,10,87),(2597,89,'247/2021','2022-12-23 00:00:00',34.50,7,89),(2598,5,'242/2022','2022-12-23 00:00:00',85.00,63,5),(2599,68,'56/2022','2022-12-23 00:00:00',35.00,70,68),(2600,82,'135/2018','2022-12-23 00:00:00',52.80,252,82),(2601,84,'135/2018','2022-12-23 00:00:00',130.90,168,84),(2602,67,'135/2018','2022-12-23 00:00:00',21.50,84,67),(2603,69,'135/2018','2022-12-23 00:00:00',35.00,84,69),(2604,75,'135/2018','2022-12-23 00:00:00',200.00,63,75),(2605,46,'135/2018','2022-12-23 00:00:00',13.50,84,46),(2606,83,'90/2017','2022-12-23 00:00:00',61.00,105,83),(2607,46,'90/2017','2022-12-23 00:00:00',13.50,140,46),(2608,49,'90/2017','2022-12-23 00:00:00',86.00,35,49),(2609,76,'90/2017','2022-12-23 00:00:00',18.85,35,76),(2610,70,'90/2017','2022-12-23 00:00:00',41.31,35,70),(2611,36,'90/2017','2022-12-23 00:00:00',75.00,70,36),(2612,67,'292/2021','2022-12-30 00:00:00',21.50,84,67),(2613,70,'292/2021','2022-12-30 00:00:00',41.31,84,70),(2614,33,'237/2022','2022-12-30 00:00:00',24.00,84,33),(2615,46,'237/2022','2022-12-30 00:00:00',13.50,42,46),(2616,82,'059/2021','2022-12-30 00:00:00',52.80,112,82),(2617,83,'059/2021','2022-12-30 00:00:00',61.00,112,83),(2618,71,'059/2021','2022-12-30 00:00:00',32.00,112,71),(2619,34,'106/2017','2022-12-30 00:00:00',39.50,22,34),(2620,34,'106/2017','2022-12-30 00:00:00',55.00,90,101),(2621,46,'106/2017','2022-12-30 00:00:00',13.50,112,46),(2622,81,'90/2022','2022-12-30 00:00:00',68.00,56,81),(2623,86,'90/2022','2022-12-30 00:00:00',96.00,56,86),(2624,33,'90/2022','2022-12-30 00:00:00',24.00,28,33),(2625,81,'0130/2017','2022-12-30 00:00:00',68.00,252,81),(2626,43,'0130/2017','2022-12-30 00:00:00',84.50,168,43),(2627,65,'0130/2017','2022-12-30 00:00:00',84.00,84,65),(2628,82,'54/2017','2022-12-30 00:00:00',52.80,42,82),(2629,83,'54/2017','2022-12-30 00:00:00',61.00,42,83),(2630,46,'54/2017','2022-12-30 00:00:00',13.50,42,46),(2631,8,'54/2017','2022-12-30 00:00:00',72.00,42,8),(2632,11,'52/2022','2023-01-06 00:00:00',129.00,6,11),(2633,35,'52/2022','2023-01-06 00:00:00',49.00,112,35),(2634,79,'190/2022','2023-01-06 00:00:00',55.59,168,79),(2635,35,'190/2022','2023-01-06 00:00:00',49.00,84,35),(2636,46,'190/2022','2023-01-06 00:00:00',13.50,84,46),(2637,89,'190/2022','2023-01-06 00:00:00',34.50,84,89),(2638,5,'243/2022','2023-01-06 00:00:00',85.00,42,5),(2639,35,'249/2022','2023-01-06 00:00:00',49.00,28,35),(2640,46,'249/2022','2023-01-06 00:00:00',13.50,28,46),(2641,58,'206/2021','2023-01-06 00:00:00',41.40,168,58),(2642,34,'206/2021','2023-01-06 00:00:00',55.00,84,101),(2643,49,'27/2017','2023-01-06 00:00:00',86.00,28,49),(2644,20,'27/2017','2023-01-06 00:00:00',95.00,28,20),(2645,83,'247/2021','2023-01-06 00:00:00',61.00,28,83),(2646,82,'247/2021','2023-01-06 00:00:00',52.80,14,82),(2647,36,'247/2021','2023-01-06 00:00:00',75.00,14,36),(2648,63,'247/2021','2023-01-06 00:00:00',136.00,7,63),(2649,70,'247/2021','2023-01-06 00:00:00',41.31,14,70),(2650,46,'247/2021','2023-01-06 00:00:00',13.50,21,46),(2651,68,'99/2019','2023-01-06 00:00:00',35.00,126,68),(2652,83,'155/2022','2023-01-06 00:00:00',61.00,168,83),(2653,34,'155/2022','2023-01-06 00:00:00',55.00,84,101),(2654,82,'135/2020','2023-01-06 00:00:00',52.80,168,82),(2655,69,'135/2020','2023-01-06 00:00:00',35.00,42,69),(2656,22,'135/2020','2023-01-06 00:00:00',39.00,84,22),(2657,46,'135/2020','2023-01-06 00:00:00',13.50,84,46),(2658,71,'263/2021','2023-01-06 00:00:00',32.00,72,71),(2659,3,'263/2021','2023-01-06 00:00:00',170.00,20,3),(2660,83,'263/2021','2023-01-06 00:00:00',61.00,56,83),(2661,22,'263/2021','2023-01-06 00:00:00',39.00,56,22),(2662,68,'263/2021','2023-01-06 00:00:00',35.00,28,68),(2663,3,'263/2021','2023-01-06 00:00:00',170.00,10,3),(2664,81,'104/2018','2023-01-06 00:00:00',68.00,84,81),(2665,39,'104/2018','2023-01-06 00:00:00',69.00,252,39),(2666,85,'8/2014','2023-01-06 00:00:00',65.00,168,85),(2667,69,'250/2021','2023-01-06 00:00:00',35.00,84,69),(2668,67,'250/2021','2023-01-06 00:00:00',21.50,84,67),(2669,36,'130/2022','2023-01-06 00:00:00',75.00,56,36),(2670,33,'130/2022','2023-01-06 00:00:00',24.00,56,33),(2671,70,'130/2022','2023-01-06 00:00:00',41.31,56,70),(2672,46,'130/2022','2023-01-06 00:00:00',13.50,56,46),(2673,34,'138/2019','2023-01-06 00:00:00',55.00,56,101),(2674,35,'138/2019','2023-01-06 00:00:00',49.00,112,35),(2675,49,'138/2019','2023-01-06 00:00:00',86.00,56,49),(2676,47,'138/2019','2023-01-06 00:00:00',28.00,56,47),(2677,6,'283/2022','2023-01-06 00:00:00',119.00,28,6),(2678,5,'283/2022','2023-01-06 00:00:00',85.00,28,5),(2679,89,'283/2022','2023-01-06 00:00:00',34.50,14,89),(2680,3,'283/2022','2023-01-06 00:00:00',170.00,14,3),(2681,65,'283/2022','2023-01-06 00:00:00',84.00,28,65),(2682,6,'283/2022','2022-12-23 00:00:00',119.00,28,6),(2683,89,'283/2022','2022-12-23 00:00:00',34.50,14,89),(2684,64,'283/2022','2022-12-23 00:00:00',53.00,14,64),(2685,83,'280/2022','2023-01-06 00:00:00',61.00,28,83),(2686,82,'280/2022','2023-01-06 00:00:00',52.80,14,82),(2687,36,'280/2022','2023-01-06 00:00:00',75.00,28,36),(2688,46,'280/2022','2023-01-06 00:00:00',13.50,42,46),(2689,76,'280/2022','2023-01-06 00:00:00',18.85,28,76),(2690,71,'280/2022','2023-01-06 00:00:00',32.00,14,71),(2691,69,'279/2022','2023-01-06 00:00:00',35.00,21,69),(2692,22,'279/2022','2023-01-06 00:00:00',39.00,21,22),(2693,83,'203/2022','2023-01-06 00:00:00',61.00,56,83),(2694,12,'203/2022','2023-01-06 00:00:00',40.00,56,12),(2695,68,'203/2022','2023-01-06 00:00:00',35.00,28,68),(2696,69,'203/2022','2023-01-06 00:00:00',35.00,28,69),(2697,3,'203/2022','2023-01-06 00:00:00',170.00,10,3),(2698,29,'205/2022','2023-01-06 00:00:00',16.30,252,29),(2699,36,'205/2022','2023-01-06 00:00:00',75.00,168,36),(2700,46,'205/2022','2023-01-06 00:00:00',13.50,168,46),(2701,12,'205/2022','2023-01-06 00:00:00',40.00,168,12),(2702,56,'205/2022','2023-01-06 00:00:00',61.90,168,56),(2703,83,'204/2022','2023-01-06 00:00:00',61.00,14,83),(2704,82,'204/2022','2023-01-06 00:00:00',52.80,14,82),(2705,36,'204/2022','2023-01-06 00:00:00',75.00,28,36),(2706,29,'204/2022','2023-01-06 00:00:00',16.30,28,29),(2707,46,'204/2022','2023-01-06 00:00:00',13.50,42,46),(2708,34,'202/2022','2023-01-06 00:00:00',55.00,84,101),(2709,46,'202/2022','2023-01-06 00:00:00',13.50,168,46),(2710,82,'90/2022','2023-01-13 00:00:00',52.80,112,82),(2711,27,'90/2022','2023-01-13 00:00:00',120.00,56,27),(2712,82,'288/2021','2023-01-13 00:00:00',52.80,21,82),(2713,33,'288/2021','2023-01-13 00:00:00',24.00,7,33),(2714,46,'288/2021','2023-01-13 00:00:00',13.50,7,46),(2715,19,'288/2021','2023-01-13 00:00:00',45.00,21,19),(2716,34,'270/2022','2023-01-13 00:00:00',55.00,28,101),(2717,89,'270/2022','2023-01-13 00:00:00',34.50,56,89),(2718,93,'270/2022','2023-01-13 00:00:00',52.50,1,93),(2719,46,'270/2022','2023-01-13 00:00:00',13.50,56,46),(2720,5,'202/2021','2023-01-13 00:00:00',85.00,42,5),(2721,49,'45/2017','2023-01-13 00:00:00',86.00,28,49),(2722,28,'79/2021','2023-01-13 00:00:00',45.00,168,28),(2723,83,'79/2021','2023-01-13 00:00:00',61.00,84,83),(2724,5,'79/2021','2023-01-13 00:00:00',85.00,84,5),(2725,83,'182/2021','2023-01-13 00:00:00',61.00,28,83),(2726,71,'182/2021','2023-01-13 00:00:00',32.00,14,71),(2727,26,'182/2021','2023-01-13 00:00:00',49.00,28,26),(2728,49,'182/2021','2023-01-13 00:00:00',86.00,14,49),(2729,46,'182/2021','2023-01-13 00:00:00',13.50,32,46),(2730,65,'249/2021','2023-01-13 00:00:00',84.00,35,65),(2731,71,'249/2021','2023-01-13 00:00:00',32.00,14,71),(2732,70,'249/2021','2023-01-13 00:00:00',41.31,14,70),(2733,3,'249/2021','2023-01-13 00:00:00',170.00,14,3),(2734,36,'088/2017','2023-01-13 00:00:00',75.00,168,36),(2735,46,'088/2017','2023-01-13 00:00:00',13.50,84,46),(2736,49,'88/2017','2023-01-13 00:00:00',86.00,84,49),(2737,47,'88/2017','2023-01-13 00:00:00',28.00,84,47),(2738,10,'88/2017','2023-01-13 00:00:00',233.00,84,10),(2739,46,'88/2017','2023-01-13 00:00:00',13.50,84,46),(2740,33,'0112/2017','2023-01-13 00:00:00',24.00,84,33),(2741,34,'200/2022','2023-01-20 00:00:00',55.00,56,101),(2742,83,'280/2022','2023-01-20 00:00:00',61.00,84,83),(2743,83,'203/2022','2023-01-20 00:00:00',61.00,56,83),(2744,12,'203/2022','2023-01-20 00:00:00',40.00,56,12),(2745,69,'203/2022','2023-01-20 00:00:00',35.00,28,69),(2746,68,'203/2022','2023-01-20 00:00:00',35.00,28,68),(2747,3,'203/2022','2023-01-20 00:00:00',170.00,10,3),(2748,48,'05/2022','2023-01-20 00:00:00',53.00,84,48),(2749,92,'05/2022','2023-01-20 00:00:00',126.05,4,92),(2750,83,'93/2017','2023-01-20 00:00:00',61.00,112,83),(2751,50,'93/2017','2023-01-20 00:00:00',170.00,56,50),(2752,49,'93/2017','2023-01-20 00:00:00',86.00,56,49),(2753,46,'93/2017','2023-01-20 00:00:00',13.50,168,46),(2754,29,'92/2022','2023-01-20 00:00:00',16.30,168,29),(2755,25,'92/2022','2023-01-20 00:00:00',38.00,56,25),(2756,46,'92/2022','2023-01-20 00:00:00',13.50,112,46),(2757,81,'90/2022','2023-01-20 00:00:00',68.00,56,81),(2758,86,'90/2022','2023-01-20 00:00:00',96.00,56,86),(2759,33,'90/2022','2023-01-20 00:00:00',24.00,28,33),(2760,22,'201/2022','2023-01-20 00:00:00',39.00,56,22),(2761,36,'201/2022','2023-01-20 00:00:00',75.00,56,36),(2762,33,'201/2022','2023-01-20 00:00:00',24.00,56,33),(2763,46,'201/2022','2023-01-20 00:00:00',13.50,112,46),(2764,82,'201/2022','2023-01-20 00:00:00',52.80,168,82),(2765,70,'201/2022','2023-01-20 00:00:00',41.31,56,70),(2766,36,'201/2022','2023-01-20 00:00:00',75.00,56,36),(2767,33,'201/2022','2023-01-20 00:00:00',24.00,56,33),(2768,46,'201/2022','2023-01-20 00:00:00',13.50,168,46),(2769,19,'080/2020','2023-01-20 00:00:00',45.00,112,19),(2770,45,'080/2020','2023-01-20 00:00:00',46.20,56,45),(2771,70,'080/2020','2023-01-20 00:00:00',41.31,10,70),(2772,83,'204/2022','2023-01-20 00:00:00',61.00,56,83),(2773,82,'204/2022','2023-01-20 00:00:00',52.80,28,82),(2774,36,'204/2022','2023-01-20 00:00:00',75.00,56,36),(2775,29,'204/2022','2023-01-20 00:00:00',16.30,56,29),(2776,46,'204/2022','2023-01-20 00:00:00',13.50,84,46),(2777,50,'65/2021','2023-01-20 00:00:00',170.00,84,50),(2778,49,'65/2021','2023-01-20 00:00:00',86.00,84,49),(2779,35,'65/2021','2023-01-20 00:00:00',49.00,84,35),(2780,46,'65/2021','2023-01-20 00:00:00',13.50,84,46),(2781,82,'211/2019','2023-01-20 00:00:00',52.80,56,82),(2782,81,'211/2019','2023-01-20 00:00:00',68.00,56,81),(2783,45,'211/2019','2023-01-20 00:00:00',46.20,112,45),(2784,87,'211/2019','2023-01-20 00:00:00',54.00,84,87),(2785,5,'211/2019','2023-01-20 00:00:00',85.00,56,5),(2786,69,'211/2019','2023-01-20 00:00:00',35.00,56,69),(2787,76,'211/2019','2023-01-20 00:00:00',18.85,112,76),(2788,81,'83/2019','2023-01-20 00:00:00',68.00,56,81),(2789,84,'83/2019','2023-01-20 00:00:00',130.90,56,84),(2790,59,'83/2019','2023-01-20 00:00:00',10.40,56,59),(2791,82,'288/2021','2023-01-20 00:00:00',52.80,168,82),(2792,33,'288/2021','2023-01-20 00:00:00',24.00,56,33),(2793,46,'288/2021','2023-01-20 00:00:00',13.50,168,46),(2794,19,'288/2021','2023-01-20 00:00:00',45.00,224,19),(2795,82,'232/2021','2023-01-20 00:00:00',52.80,168,82),(2796,83,'232/2021','2023-01-20 00:00:00',61.00,84,83),(2797,36,'232/2021','2023-01-20 00:00:00',75.00,84,36),(2798,46,'232/2021','2023-01-20 00:00:00',13.50,252,46),(2799,49,'232/2021','2023-01-20 00:00:00',86.00,84,49),(2800,81,'90/2022','2023-01-20 00:00:00',68.00,56,81),(2801,86,'90/2022','2023-01-20 00:00:00',96.00,56,86),(2802,33,'90/2022','2023-01-20 00:00:00',24.00,28,33),(2803,83,'203/2022','2023-01-27 00:00:00',61.00,42,83),(2804,22,'203/2022','2023-01-27 00:00:00',39.00,42,22),(2805,68,'203/2022','2023-01-27 00:00:00',35.00,21,68),(2806,69,'203/2022','2023-01-27 00:00:00',35.00,21,69),(2807,71,'249/2021','2023-01-27 00:00:00',32.00,42,71),(2808,65,'249/2021','2023-01-27 00:00:00',84.00,84,65),(2809,3,'249/2021','2023-01-27 00:00:00',170.00,42,3),(2810,69,'279/2022','2023-01-27 00:00:00',35.00,21,69),(2811,12,'279/2022','2023-01-27 00:00:00',40.00,21,12),(2812,83,'90/2017','2023-01-27 00:00:00',61.00,126,83),(2813,46,'90/2017','2023-01-27 00:00:00',13.50,168,46),(2814,49,'90/2017','2023-01-27 00:00:00',86.00,42,49),(2815,76,'90/2017','2023-01-27 00:00:00',18.85,42,76),(2816,70,'90/2017','2023-01-27 00:00:00',41.31,42,70),(2817,82,'118/2022','2023-01-27 00:00:00',52.80,42,82),(2818,83,'118/2022','2023-01-27 00:00:00',61.00,42,83),(2819,47,'118/2022','2023-01-27 00:00:00',28.00,42,47),(2820,92,'170/2022','2023-01-27 00:00:00',126.05,4,92),(2821,83,'182/2021','2023-01-27 00:00:00',61.00,112,83),(2822,82,'182/2021','2023-01-27 00:00:00',52.80,56,82),(2823,71,'182/2021','2023-01-27 00:00:00',32.00,56,71),(2824,26,'182/2021','2023-01-27 00:00:00',49.00,112,26),(2825,49,'182/2021','2023-01-27 00:00:00',86.00,62,49),(2826,49,'182/2021','2023-01-27 00:00:00',96.00,22,100),(2827,46,'182/2021','2023-01-27 00:00:00',13.50,168,46),(2828,11,'58/2021','2023-02-03 00:00:00',129.00,56,11),(2829,50,'58/2021','2023-02-03 00:00:00',170.00,28,50),(2830,47,'58/2021','2023-02-03 00:00:00',28.00,28,47),(2831,92,'231/2021','2023-02-03 00:00:00',126.05,1,92),(2832,49,'231/2021','2023-02-03 00:00:00',96.00,11,100),(2833,82,'134/2022','2023-02-03 00:00:00',52.80,28,82),(2834,83,'134/2022','2023-02-03 00:00:00',61.00,28,83),(2835,69,'134/2022','2023-02-03 00:00:00',35.00,42,69),(2836,19,'07/2017','2023-02-03 00:00:00',45.00,28,19),(2837,38,'07/2017','2023-02-03 00:00:00',107.00,56,38),(2838,49,'27/2017','2023-02-03 00:00:00',96.00,28,100),(2839,20,'27/2017','2023-02-03 00:00:00',95.00,28,20),(2840,83,'203/2022','2023-02-03 00:00:00',61.00,28,83),(2841,82,'203/2022','2023-02-03 00:00:00',52.80,14,82),(2842,68,'203/2022','2023-02-03 00:00:00',35.00,14,68),(2843,69,'203/2022','2023-02-03 00:00:00',35.00,14,69),(2844,3,'203/2022','2023-02-03 00:00:00',170.00,14,3),(2845,82,'134/2022','2023-02-03 00:00:00',52.80,28,82),(2846,83,'134/2022','2023-02-03 00:00:00',61.00,28,83),(2847,69,'134/2022','2023-02-03 00:00:00',35.00,42,69),(2848,83,'58/2021','2023-02-03 00:00:00',61.00,56,83),(2849,50,'58/2021','2023-02-03 00:00:00',170.00,28,50),(2850,47,'58/2021','2023-02-03 00:00:00',28.00,28,47),(2851,46,'58/2021','2023-02-03 00:00:00',13.50,112,46),(2852,50,'9/2018','2023-02-10 00:00:00',170.00,56,50),(2853,49,'9/2018','2023-02-10 00:00:00',96.00,56,100),(2854,46,'9/2018','2023-02-10 00:00:00',13.50,112,46),(2855,34,'9/2018','2023-02-10 00:00:00',55.00,56,101),(2856,35,'9/2018','2023-02-10 00:00:00',49.00,56,35),(2857,6,'04/2022','2023-02-10 00:00:00',119.00,84,6),(2858,65,'04/2022','2023-02-10 00:00:00',84.00,84,65),(2859,3,'04/2022','2023-02-10 00:00:00',170.00,84,3),(2860,82,'54/2017','2023-02-10 00:00:00',52.80,14,82),(2861,83,'54/2017','2023-02-10 00:00:00',61.00,14,83),(2862,68,'54/2017','2023-02-10 00:00:00',35.00,14,68),(2863,46,'54/2017','2023-02-10 00:00:00',13.50,14,46),(2864,8,'54/2017','2023-02-10 00:00:00',72.00,14,8),(2865,70,'89/2018','2023-02-10 00:00:00',41.31,84,70),(2866,24,'89/2018','2023-02-10 00:00:00',64.00,84,24),(2867,58,'89/2018','2023-02-10 00:00:00',41.40,168,58),(2868,82,'36/2020','2023-02-10 00:00:00',52.80,21,82),(2869,83,'36/2020','2023-02-10 00:00:00',61.00,21,83),(2870,46,'36/2020','2023-02-10 00:00:00',13.50,14,46),(2871,48,'36/2020','2023-02-10 00:00:00',53.00,14,48),(2872,83,'182/2021','2023-02-10 00:00:00',61.00,28,83),(2873,71,'182/2021','2023-02-10 00:00:00',32.00,14,71),(2874,82,'182/2021','2023-02-10 00:00:00',52.80,14,82),(2875,26,'182/2021','2023-02-10 00:00:00',49.00,28,26),(2876,49,'182/2021','2023-02-10 00:00:00',96.00,14,100),(2877,48,'182/2021','2023-02-10 00:00:00',53.00,14,48),(2878,46,'182/2021','2023-02-10 00:00:00',13.50,42,46),(2879,32,'237/2022','2023-02-10 00:00:00',45.00,14,32),(2880,46,'237/2022','2023-02-10 00:00:00',13.50,14,46),(2881,81,'83/2019','2023-02-10 00:00:00',68.00,28,81),(2882,84,'83/2019','2023-02-10 00:00:00',130.90,28,84);
/*!40000 ALTER TABLE `medicinesale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicinestock`
--

DROP TABLE IF EXISTS `medicinestock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicinestock` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `MedicineId` int NOT NULL,
  `Main` int DEFAULT NULL,
  `Sub` int DEFAULT NULL,
  `A_kit` int DEFAULT NULL,
  `B_kit` int DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `medicinestock_medicine_idx` (`MedicineId`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicinestock`
--

LOCK TABLES `medicinestock` WRITE;
/*!40000 ALTER TABLE `medicinestock` DISABLE KEYS */;
INSERT INTO `medicinestock` VALUES (1,1,0,0,0,0),(2,2,0,0,0,0),(3,3,0,2559,0,0),(4,4,0,2685,0,0),(5,5,0,1936,0,0),(6,6,0,2804,0,0),(7,7,0,3000,0,0),(8,8,0,2632,0,0),(9,9,0,2114,0,0),(10,10,0,2916,0,0),(11,11,0,2916,0,0),(12,12,0,1936,0,0),(13,13,0,3000,0,0),(14,14,0,3000,0,0),(15,15,0,3000,0,0),(16,16,0,0,0,0),(17,17,0,3000,0,0),(18,18,0,3000,0,0),(19,19,0,1750,0,0),(20,20,0,2426,0,0),(21,21,0,1801,0,0),(22,22,0,1887,0,0),(23,23,0,2916,0,0),(24,24,0,2664,0,0),(25,25,0,2230,0,0),(26,26,0,2146,0,0),(27,27,0,2734,0,0),(28,28,0,1269,0,0),(29,29,0,1369,0,0),(30,30,0,2951,0,0),(31,31,0,2685,0,0),(32,32,0,2958,0,0),(33,33,0,757,0,0),(34,34,5100,4562,0,0),(35,35,0,934,0,0),(36,36,0,86,0,0),(37,37,0,999888,0,0),(38,38,0,2372,0,0),(39,39,0,2251,0,0),(40,40,0,2130,0,0),(41,41,0,3000,0,0),(42,42,0,3000,0,0),(43,43,0,2498,0,0),(44,44,0,2288,0,0),(45,45,0,2139,0,0),(46,46,0,980526,0,0),(47,47,0,1045,0,0),(48,48,5000,403,0,0),(49,49,5000,4869,0,0),(50,50,0,1547,0,0),(51,51,0,3000,0,0),(52,52,0,3000,0,0),(53,53,0,3000,0,0),(54,54,0,3000,0,0),(55,55,0,3000,0,0),(56,56,0,2616,0,0),(57,57,0,2888,0,0),(58,58,0,1880,0,0),(59,59,0,2776,0,0),(60,60,0,3000,0,0),(61,61,0,3000,0,0),(62,62,0,3000,0,0),(63,63,0,2993,0,0),(64,64,0,2790,0,0),(65,65,0,2209,0,0),(66,66,0,3000,0,0),(67,67,0,1696,0,0),(68,68,0,704,0,0),(69,69,0,408,0,0),(70,70,0,17547,0,0),(71,71,0,8219,0,0),(72,72,0,2685,0,0),(73,73,0,2923,0,0),(74,74,0,3000,0,0),(75,75,0,2867,0,0),(76,76,0,1376,0,0),(77,77,0,3000,0,0),(78,78,0,3000,0,0),(79,79,0,2748,0,0),(80,80,0,3000,0,0),(81,81,0,997978,0,0),(82,82,3000,990367,0,0),(83,83,0,990087,0,0),(84,84,0,1838,0,0),(85,85,0,2706,0,0),(86,86,0,2370,0,0),(87,87,0,2422,0,0),(88,88,0,2958,0,0),(89,89,0,2554,0,0),(90,90,0,2937,0,0),(91,91,0,2979,0,0),(92,92,0,2927,0,0),(93,93,0,2988,0,0),(94,94,0,3000,0,0),(95,95,0,2796,0,0),(96,96,10000000,0,0,0);
/*!40000 ALTER TABLE `medicinestock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meeting`
--

DROP TABLE IF EXISTS `meeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `PatientId` int NOT NULL,
  `Date` datetime DEFAULT NULL,
  `Remarks` text,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting`
--

LOCK TABLES `meeting` WRITE;
/*!40000 ALTER TABLE `meeting` DISABLE KEYS */;
INSERT INTO `meeting` VALUES (1,10,'2022-10-07 00:00:00','psi by jayachandran');
/*!40000 ALTER TABLE `meeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `op`
--

DROP TABLE IF EXISTS `op`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `op` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `PatientId` int NOT NULL,
  `Date` datetime DEFAULT NULL,
  `DoctorId` int DEFAULT NULL,
  `Remarks` text,
  `FollowUp` text,
  `NextOPDate` datetime DEFAULT NULL,
  `PsychiatristId` int DEFAULT NULL,
  `PsychologistId` int DEFAULT NULL,
  `ClinicianId` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=940 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `op`
--

LOCK TABLES `op` WRITE;
/*!40000 ALTER TABLE `op` DISABLE KEYS */;
INSERT INTO `op` VALUES (1,29,'2021-08-06 00:00:00',2,'- CONSUMPIRON OF WATER\n- ANXIOUS\n- LOW MOOD (SUISIDAL)\n- WORTHLESS \n- FEAR OF COUTAMINCLION',' NEXT WEEK PSI START ','2021-09-20 00:00:00',0,0,0),(2,29,'2021-08-27 00:00:00',5,'MUCH BETTER NOW\nOCD SYMPTOMS  NOW\nNEED PSYCHO EDUCATION','ILA PHONE FOLLOWUP','2021-09-10 00:00:00',0,0,0),(3,25,'2021-08-27 00:00:00',7,'REPORTED WITH MOTHER \nON REGULAR MEDICATION\nSLEEP NORMAL ,APPETITE NORMAL\nPOOR SELF CARE\nPOOR HYGIENE\nLESS BRUSHING & BATHING   NEED PSI  \nFUNCTIONAL ASSESSMENT','ILA HOME VISIT\nILA PHONE FOLLOWUP','2021-09-17 00:00:00',0,0,0),(4,22,'2021-08-27 00:00:00',2,'ON REGULAR MEDICATION NOW\nOVERALL SAME \nPRE OCCAPAID THERAPY\n','ILA PHONE FOLLOWUP','2021-09-24 00:00:00',0,0,0),(5,17,'2021-08-27 00:00:00',5,'ON REGULAR MEDICATION\nPAST -WATCH MAN JOB -NEED PSI\nPAST - GULT MIGRANT\nSHOP KEEPER','ILA PHONE FOLLOWUP','2021-10-22 00:00:00',0,0,0),(6,19,'2021-08-20 00:00:00',2,'PLAN : REDUCE QUETIAPINE         175MG      0-0-1HS','ILA PHONE FOLLOWUP','2021-10-01 00:00:00',0,0,0),(7,24,'2021-08-20 00:00:00',2,'LESS OCD SUMPTOMS ','ILA PHONE FOLLOWUP ','2021-09-10 00:00:00',0,0,0),(8,11,'2021-08-13 00:00:00',2,'ON REGULAR MEDICINE NOW\n','ILA PHONE FOLLOWUP FOR MEDICINE CHECK','2021-10-08 00:00:00',0,0,5),(9,21,'2021-08-06 00:00:00',2,'STABLE','ILA PHONE FOLLOWUP \nMHAT HOME VISIT','2021-10-01 00:00:00',0,0,0),(10,8,'2021-08-13 00:00:00',2,'ON REGULAR MEDICATION NOW\nOVERALL BETTER NOW , STABLE -MOOD ','ILA PHONE FOLLOWUP ','2021-10-08 00:00:00',0,0,5),(11,6,'2021-08-13 00:00:00',2,'ON REGULAR MEDICATION NOW ,OVER ALL BETTER NOW STABLE -MOOD','ILA PHONE FOLLOWUP ','2021-09-10 00:00:00',0,0,5),(12,27,'2021-08-27 00:00:00',2,'INC-T . RISPERIDONE , IF IMPROVMENT THEY STOP OFF T. CLOZAPINE','NEED ILA VOLONTEER FOLLOWUP \n','2021-09-10 00:00:00',0,0,5),(13,10,'2021-08-13 00:00:00',3,'ON REGULAR MEDICATION NOW , OVERALL BETTER NOW , STABLE MOOD \n','ILA PHONE FOLLOWUP ','2021-09-10 00:00:00',0,0,5),(14,28,'2021-09-03 00:00:00',2,'','ILA PHONE FOLLOWUP24','2021-09-24 00:00:00',0,0,0),(15,26,'2021-08-27 00:00:00',2,'ON REGULAR MEDICINE ,HOME VISIT','ILA , MHAT HOME VISIT\n','2021-10-22 00:00:00',0,0,5),(16,80,'2021-09-03 00:00:00',2,'STOP PROPRANOLOL 20MG 1-0-1\n','ILA PHONE FOLLOWUP ','2021-10-29 00:00:00',0,0,0),(17,20,'2021-09-03 00:00:00',2,'','','2021-10-29 00:00:00',0,0,0),(18,88,'2021-09-03 00:00:00',2,'NO MUCH IMPRO\nSTOP SIZODON LS       0-0-0.5','ILA PHONE FOLLOWUP','2021-10-01 00:00:00',0,0,0),(19,18,'2021-08-27 00:00:00',2,'PROXY REPORTED (BROTHER)\nIRREGULAR MEDICATION\nPT. WAS NOT TAKEN THP , RISPERIDONE ORAL SOLUTION 3ML (LOW DOSEGE)\nT. SERANTINE MEDICIN - TAKEN OVER DOSEGE\nSLEEP NORMAL\nAPPETITE NORMAL \nSTABLE NOW \nAGGRESSION DECREVED\nREPEAT SAME MEDICINE \nMAKE A PLAN FOR REGULAR MEDICINE','ILA PHONE FOLLOWUP \nILA & MHAT HOME VISIT - NEXT WEEK','2021-09-10 00:00:00',0,0,7),(20,12,'2021-08-13 00:00:00',2,'ON REGULAR MEDICATION NOW \nLOW MOOD , BETTER NOW \nCON. PSI','ILA PHONE FOLLOWUP ','2021-09-10 00:00:00',0,0,5),(21,23,'2021-09-09 00:00:00',2,'PHONE FOLLOWUP \nON REGULAR MEDICATION\nBETTER ON MEDICATION\nNOT PARTIPATED IN HOMEHOLD WORKS\nMEDICINE IRREGULAR\nSV ORAL SOLUTION NOT READY TO TAKE\nPLAN : TRY TO CONFUFE','','2021-09-24 00:00:00',0,0,7),(22,7,'2021-08-13 00:00:00',2,'ON REGULAR MEDICATION\nOVERALL BETTER NOW','','2021-09-10 00:00:00',0,0,5),(23,36,'2021-07-16 00:00:00',2,'ON REGULAR MEDICETION NOW\nOVERALL BETTER NOW \nNO FRESH CONPIENT ','','2021-09-10 00:00:00',0,0,5),(24,50,'2021-07-16 00:00:00',0,'','','2021-09-10 00:00:00',0,0,0),(25,13,'2021-08-27 00:00:00',2,'ON REGULAR MEDICETION\nOVERALL STABLE MOOD ','ILA PHONE FOLLOWUP ','2021-09-24 00:00:00',0,0,5),(26,13,'2021-09-03 00:00:00',2,'','ILA PHONE FOLLOWUP ','2021-09-10 00:00:00',0,0,0),(27,87,'2021-08-27 00:00:00',2,'ON REGULAR MEDICATION\nSAME MILD IMPROVEMANT\nNEED PSI\n','','2021-09-10 00:00:00',0,0,5),(28,15,'2021-08-13 00:00:00',2,'ON REGULAR MEDICETION NOW\nOVERALL BETTER NOW , STABLE MOOD \n','ILA PHONE FOLLOWUP','2021-09-10 00:00:00',0,0,5),(29,16,'2021-08-27 00:00:00',2,'ON REGULAR MEDICETION NOW \nMUCH BETTER NOW \nSTABLE MOOD','ILA PHONE FOLLOWUP ','2021-09-10 00:00:00',0,0,5),(30,45,'2021-09-03 00:00:00',2,'','','2021-10-15 00:00:00',0,0,0),(31,3,'2021-08-13 00:00:00',0,'ON REGULAR MEDICETION \nSLEEP - DECOEARED\nHYPER SALIRATION REPORTED\nNEW ADD THP 2MG 1-0-0','','2021-09-10 00:00:00',0,0,7),(32,40,'2021-08-27 00:00:00',2,'BETTER ON MEDICETION\nON REGULAR MEDICETION\n','','2021-09-10 00:00:00',0,0,7),(33,79,'2021-09-03 00:00:00',2,'BETTER NOW','ILA PHONE FOLLOWUP','2021-10-15 00:00:00',0,0,0),(34,23,'2021-09-10 00:00:00',2,'ON REGULAR MEDICATION ( COVERT MEDICETION )\nDELUSIONAL \nFAMILY MEMBER ARE HARMIY \nSLEEP \nSV ORAL SOLUTION 5ML-0-10ML (NOT REGULAR)','ILA PHONE FOLLOUP','2021-10-01 00:00:00',0,0,5),(35,18,'2021-09-10 00:00:00',0,'ON REGULAR MEDICATION NOW\nBEHAVIOUR SYMPTOMS PERSIST\nSOME TIME OVER DOSE TAKING BY ESPECIALY (SERANTINE       5MG) \nPT. AND FAMLIY IS NOT WILLING TO CHENGE MEDICATION \nSO WE CON. THE SAME','ILA PHONE FOLLOWUP','2021-10-08 00:00:00',0,0,5),(36,12,'2021-09-10 00:00:00',2,'ON REGULAR MEDICATION NOW\nMUCH BETTER NOW\nSTABLE MOOD , ','ILA PHONE FOLLOWUP','2021-11-05 00:00:00',0,0,5),(37,87,'2021-09-10 00:00:00',2,'ON REGULAR MEDICATION NOW \nNEED FUNCHONAL ASSECMENT \nSELF CARE - POOR     COMMUNICTION - BETTER\n','TOPIRAMATE                25MG       1-0-1\nCLOBAZAM                    5MG          1-0-1\nSV                                   300MG       1-0-1\nRISPERIDONE                 3MG          0-0-1\nTHP                                   2MG         1-0-0\nESCITALOPRAM              5MG           0-0-1','2021-10-01 00:00:00',0,0,5),(38,10,'2021-09-10 00:00:00',2,'ON REGULAR MEDICATION\nPSI STANED BY SURAYYA THAT FOUND THAT THE NEED ASSERHVE SKILL TRAINING . \nHE HAS DIFICALT IN SOME ARE TO BE ADDRESSED\nSLEEP BETTER NOW\n','ILA PHONE FOLLOWUP','2021-11-05 00:00:00',0,0,5),(39,46,'2021-10-01 00:00:00',2,'BETTER NOW\nSTOP FLUOXETINE NEXT VISIT','','2021-11-26 00:00:00',0,0,5),(40,46,'2021-10-22 00:00:00',0,'ASSESSMENT ACTIVITY MONITERING\nDAILY FOUNTION BETTER \nSOCIAL SKILL POOR','','2021-10-29 00:00:00',9,0,5),(41,45,'2021-09-03 00:00:00',2,'POOR COMPLEINCE TO MEDICINE \n','','2021-10-29 00:00:00',0,0,0),(42,90,'2021-10-22 00:00:00',2,'REPORTED ALONE \nBETTER ON MEDICATION\nNO FRESH COMPLAINTS REPORTED \nSLEEP AND APPETITE WERE NORMAL \nHEADAHEIS NOT PERSISTANT \nDAILY SMIKING QUANTITY INCREASED ( 10 CIGERALTES DAILY )\nPST- SMOKING CESSATION \n','PLAN -- KNOW HIS TOIGGEN TO SMOKE AND PLAN FOR THEN CREATE NEW HABITS INSTEAD OF SMOKING\nNEED - SUSTAINED MOTIVATION','2021-11-19 00:00:00',0,0,7),(43,29,'2021-10-22 00:00:00',0,'ON REGULAR MEDICATION NOW \nIMPROVEMANT \nSOCIO OCCUPECTION - NEED IMPROVEMENT\n','NEED - PSI','2021-11-19 00:00:00',0,0,5),(44,89,'2021-10-22 00:00:00',2,'ON REGULAR MEDICATION \nOVERALL BETTER NOW \nPSYCHOTIC SYMPTOMS - REDUED\nNEED TO IMPROVEMENT IN SOCIAL SKILLS FUNTION\nACCORDY TO PT ----NEED ANY WORK - HE REPORT\nCURRENTY NO OPPARTUNITY - EARLY (HE WAS DONE COOL WORK)\n','','2021-12-17 00:00:00',0,0,5),(45,78,'2021-10-22 00:00:00',2,'ON REGULAR MEDICATION\n','','2021-11-19 00:00:00',0,0,5),(46,39,'2021-10-22 00:00:00',2,'PROXY REPORTED (HUSBAND)\nBETTER ON MEDICATION\nNO FRESH COMPLAINTS REPORTED \nSLEEP AND APPETIK WERE NORMAL\nSELF MEDICATION ISSUE CURRANTIY NOT REPORTED\n','','2021-12-10 00:00:00',0,0,7),(47,86,'2021-10-22 00:00:00',0,'REPORTED ALONE\nNO FRESH COMPLAINTS REPORTED\nTIREDNESS MAINTAINED\nSLEEP AND APPETITE WERE NORMAL\n \n','','2022-01-07 00:00:00',0,0,7),(48,40,'2021-09-24 00:00:00',2,'PHONE FOLLOWUP \nVOMITING ISSUE REPORTED \nD/W Dr. FAVAZ\nDECREASED QUETIAPINE AND ADD OMEPRAZOLE','','2021-11-05 00:00:00',0,0,7),(49,32,'2021-10-22 00:00:00',2,'REPORTED ALONE \nREGULAR MEDICATION \nINCREASED ANXIETY\nPANIC SYMPTOM INGREASED (+)\nPT WANTS TO NEED RESTART FLUOXETINE \nOC SYMPTOMS REPORTED \nTENSIM - FEELING \nD/W Dr. FAVAZ RESTART FLUOXETINE NEXT R/V STOP \nREDUSED DOSE OF MIRTAZAPINE ','','2021-12-03 00:00:00',0,0,7),(50,102,'2021-10-15 00:00:00',2,'SELF TALK ( DURING DAY NIGHT)\nSMOKING ADDICTION\nAT THE AEG 27 AGE ONSET \nSTARLED HE WAS LAYING DINIG HALL ONSET WAS ACCULE SIEEP - SOCIALISATION FEAR FULL ( PERSIAUTAG ) HEARING VOICES ( NO SMOKIG ADDICTION THIS TIME ) ','NEED TO HOME VISIT \nNEED VOLONTEER FOLLOWUP\n','2021-10-29 00:00:00',0,0,5),(51,104,'2021-10-15 00:00:00',2,'','','2021-10-29 00:00:00',0,0,0),(52,95,'2021-10-01 00:00:00',0,'','ILA PHONE FOLLOWUP','2021-10-29 00:00:00',0,0,0),(53,94,'2021-10-08 00:00:00',2,'REPORTED WITH MOTHER\nON REGULAR MEDICATION \nBETTER ON MEDICATION\nSLEEP AND APPETTE WERE NORMAL\nSEDATION MAINTAINED\nMOOD ; EATHYMIC\nNO FRESH COMPLANINT REPORTED\n\n','','2021-10-29 00:00:00',0,0,7),(54,76,'2021-09-17 00:00:00',2,'','ILA PHONE FOLLOWUP','2021-10-29 00:00:00',0,0,0),(55,80,'2021-09-03 00:00:00',2,'STOP PROPRANOLOL TABLETS 20MG 1-0-1','','2021-10-29 00:00:00',0,0,0),(56,3,'2021-09-10 00:00:00',2,'THEY REPORTED DUE TO T. SODIUM VALPROATE SEDATION ','','2021-10-29 00:00:00',0,0,5),(57,83,'2021-09-17 00:00:00',2,'ON REGULAR MEDICATION NOW \nMUCH BETTER STABLE MOOD \nNO ACTIVE PSYCHOTIC SYMPTOMS \n','ILA PHONE FOLLOWUP','2021-10-29 00:00:00',0,0,5),(58,35,'2021-09-17 00:00:00',2,'POOR COMPLAINTS','TO DELIVER THE MEDICATION WEEKLY','2021-10-29 00:00:00',0,0,0),(59,25,'2021-09-17 00:00:00',2,'PSI NEED \nSLEEP POOR','TO DELIVER THE MEDICATION WEEKIL','2021-10-29 00:00:00',0,0,0),(60,84,'2021-09-03 00:00:00',2,'ON REGULAR MEDICATION\nOVERALL BETTER NOW STABLE MOOD\nREFFER THEY CASE PSI','','2021-10-29 00:00:00',0,0,5),(61,84,'2021-10-08 00:00:00',0,'PSI ','','2021-10-29 00:00:00',0,0,0),(62,41,'2021-08-20 00:00:00',2,'OVERALL BETTER','','2021-10-29 00:00:00',0,0,0),(63,17,'2021-08-27 00:00:00',2,'ON REGULAR MEDICATION \nPAST - WATCH MAN JOB - NEED JOB ORIEMT PSI\nSHOP KEEPER','','2021-10-29 00:00:00',0,0,5),(64,49,'2021-09-03 00:00:00',2,'OVERALL BETTER','PSI \nILA PHONE FOLLOWUP (MOTHER)','2021-10-29 00:00:00',0,0,0),(65,49,'2021-10-15 00:00:00',0,'REGULAR OBSERVATION\nNO FRESH COMPLENT\n','PSI CONTINUE','2021-10-29 00:00:00',0,0,0),(66,20,'2021-09-03 00:00:00',2,'PT IS HAS POOR FOOD INTALSE\nPOOR WATER INTALSE','','2021-10-29 00:00:00',0,0,0),(67,37,'2021-09-03 00:00:00',2,'ON REGULR MEDICATION\nOLANZAPINE 5 0-0-0.5','','2021-10-29 00:00:00',0,0,0),(68,76,'2021-10-29 00:00:00',2,'NOT WILLING TO TACK MEDICINE','','2021-12-24 00:00:00',0,0,0),(69,104,'2021-10-29 00:00:00',2,'QUETIAPINE 25 STOP','','2021-11-26 00:00:00',0,0,0),(70,105,'2021-10-29 00:00:00',2,'REFER TO PHYSICIAN FOR DIABETES','','2021-11-05 00:00:00',0,0,0),(71,106,'2021-10-29 00:00:00',2,'NEED TO CONTOTE THOUGHTS AND DOUBTS\nLIST OUT ALL OBSESSIONS AND COMPULSIM ARRONG IN A  HIERARCHY SERIERITY AND INSIGHT INTO THE IRRATINOALITY OF EACH \nTHOUGHT STOPPING FAMILY SUPPORT , PSYCHO EDUCATION','','2021-11-12 00:00:00',0,0,0),(72,35,'2021-10-29 00:00:00',2,'BETTER','','2021-12-24 00:00:00',0,0,0),(73,95,'2021-10-29 00:00:00',2,'OVERALL BETTER','PSI FOLLOWUP','2021-12-10 00:00:00',0,0,0),(74,35,'2021-10-29 00:00:00',2,'','','2021-12-24 00:00:00',0,0,0),(75,25,'2021-10-29 00:00:00',2,'OVERALL BETTER','','2021-12-24 00:00:00',0,0,0),(76,20,'2021-10-29 00:00:00',2,'','','2021-12-24 00:00:00',0,0,0),(77,80,'2021-10-29 00:00:00',2,'','','2021-12-24 00:00:00',0,0,0),(78,41,'2021-10-29 00:00:00',2,'OVERALL BETTER','','2022-01-21 00:00:00',0,0,0),(79,94,'2021-10-29 00:00:00',2,'OVERALL BETTER','','2021-11-26 00:00:00',0,0,0),(80,8,'2021-10-29 00:00:00',2,'OVERALL BETTER','','2022-01-21 00:00:00',0,0,0),(81,3,'2021-10-29 00:00:00',2,'OVERALL BETTER','','2021-12-24 00:00:00',0,0,0),(82,37,'2021-10-29 00:00:00',2,'ON REGULAR MEDICATION\nNEED PSI - INVOLVEMENT MORE','','2021-12-24 00:00:00',0,0,5),(83,9,'2021-10-22 00:00:00',2,'ON REGULAR MEDICATION \nOVERALL BETTER','','2021-11-19 00:00:00',0,0,5),(84,92,'2021-10-22 00:00:00',2,'PSI CONTINUE PSI ( ASSESSMENT )','','2021-11-05 00:00:00',0,0,0),(85,86,'2021-10-22 00:00:00',2,'REPORTED ALONE \nNO FRESH COMPLAINED REPORTED\nTIREDNESS MAINTAINED\nSLEEP AND APPETITE WERE NORMAL\nMOOD EUTHYMIC','','2022-01-07 00:00:00',0,0,7),(86,1,'2021-10-01 00:00:00',2,'OVERALL BETTER\nNEED PSI','','2021-11-12 00:00:00',0,0,0),(87,46,'2021-10-01 00:00:00',2,'OVERALL BETTER\nFLUOXETINE 40 STOP\nFLUOXETINE 20 START','','2021-11-26 00:00:00',0,0,0),(88,46,'2021-10-22 00:00:00',0,'PSI','','2021-11-05 00:00:00',0,0,0),(89,24,'2021-10-01 00:00:00',2,'OVERALL BETTER\n','','2021-11-26 00:00:00',0,0,0),(90,90,'2021-10-29 00:00:00',0,'PSI START','','2021-11-05 00:00:00',0,0,0),(91,12,'2021-09-10 00:00:00',2,'ON REGULAR MEDICATION NOW\nMUCH BETTER NOW\nSTABLE MOOD \nNO FRESH COMPLAINT\n','','2021-11-05 00:00:00',0,0,5),(92,50,'2021-09-10 00:00:00',2,'ON REGULAR MEDICATION\nOVERALL BETTER NOW ','','2021-11-05 00:00:00',0,0,5),(93,23,'2021-10-01 00:00:00',2,'OVERALL BETTER','','2021-11-05 00:00:00',0,0,0),(94,23,'2021-10-22 00:00:00',0,'PSI \nASSESSMENT\nPSI CONTINUE\nCONVERT MEDICATION','','2021-11-05 00:00:00',0,0,0),(95,13,'2021-10-22 00:00:00',2,'SELF TALK ALSO PERSIST ( HEARING VOICES)\n3-4 DAYS BACK -VOMITTED \nORIENTATION FLUCTUEG','','2021-11-05 00:00:00',0,0,5),(96,11,'2021-10-01 00:00:00',2,'SLEEP NOT SET\nSELF TALK','','2021-11-05 00:00:00',0,0,0),(97,34,'2021-09-24 00:00:00',2,'ON REGULAR MEDICATION\nPHYSICALLY SHE IS BETTER-CURRENTY STOPED THER MEDICINE ( WAS ON TREATMENT FROM CALICUT MEDICAL COLL)\nTHAT TIME BLOOD INVESTIGATION DONE\nEVERTHIG IS NORMAL','','2021-11-05 00:00:00',0,0,5),(98,40,'2021-09-24 00:00:00',2,'PHONE FOLLOW UP , VOMITING ISSUE REPORTED , D/W Dr. FAVAZ ,DECREASED QUETIAPINE AND ADD OMEPRAZOLE\n','','2021-11-12 00:00:00',0,0,7),(99,43,'2021-10-08 00:00:00',2,'REPORTED WITH SISTER , ON REGULAR MEDICATION, BETTER ON MEDICATION, MOOD : STABLE, AGGRESSION ISSUES REDUCED, SLEEP AND APPETITE WERE NORMAL SEDATION MAINTAINED , REPEAT SAME MEDICINE, PSI - FOUCSES ON PARENTING , HOW HOLD WORK','','2021-11-26 00:00:00',0,0,7),(100,43,'2021-10-08 00:00:00',0,'PSI FOLLOWUP (SOFIYA)','','2021-11-19 00:00:00',0,0,0),(101,105,'2021-11-05 00:00:00',2,'ON REGULAR MEDICATION NOW, OVERALL BETTER NOW,  MILD IMPROVEMANT REPORTED, PSI PLAN ','','2021-11-19 00:00:00',0,0,5),(102,32,'2021-11-05 00:00:00',0,'PSI FOLLOWUP\nAFTER DISCUSS WITH CLINICIAN','',NULL,0,0,0),(103,7,'2021-11-05 00:00:00',2,'ON REGULAR MEDICATION \nPSI FOLLOWUP ( DISCUSS WITH CLINICIAN','','2021-12-03 00:00:00',0,0,5),(104,99,'2021-10-15 00:00:00',2,'SPEEL IS POOR','','2021-11-12 00:00:00',0,0,0),(105,22,'2021-10-15 00:00:00',2,'BETTER','','2021-11-12 00:00:00',0,0,0),(106,101,'2021-10-29 00:00:00',2,'HOME VISIT NEED: DID NOT SEA THE PATIENT , WE ONLY TAKE HISTORY FOME MOTHER. ','','2021-11-12 00:00:00',0,0,5),(107,102,'2021-10-29 00:00:00',2,'HOME VISIT \n','ILA PHONE FOLLOWUP\nAND VOLUNTEER HOME VISIT','2021-11-12 00:00:00',0,0,5),(108,26,'2021-10-29 00:00:00',2,'HOME VISIT \nON REGULAR MEDICATION (COVERT), CURRENTY MILD IMPROVEMENT, STILL TALK (DELUSIONAL) ACCORDING TO HUSBEND POSSIBIL OF NEW MEDICINE ','','2021-11-12 00:00:00',0,0,5),(109,50,'2021-10-01 00:00:00',2,'','','2021-11-12 00:00:00',0,0,0),(110,13,'2021-11-05 00:00:00',2,'ON REGULAR MEDICATION\nPSYCHOTIC SYMPTOMS, PHYSICAL ISSUESES REPORETED ','ILA PHONE FOLLOWUP','2021-11-19 00:00:00',0,0,7),(111,9,'2021-10-22 00:00:00',2,'ON REGULAR MEDICATION, OVERALL BETTER','','2021-11-19 00:00:00',0,0,5),(112,24,'2021-11-05 00:00:00',2,'ON REGULAR MEDICATION NOW ','','2021-11-19 00:00:00',0,0,5),(113,2,'2021-10-08 00:00:00',2,'REPORTED ALONE \nBETTER ON MEDICATION \nSTABLE MOOD','','2021-11-19 00:00:00',0,0,7),(114,15,'2021-10-22 00:00:00',2,'ON REGULAR MEDICATION NOW, CURRENTLY MOOD BETTER','','2021-11-19 00:00:00',0,0,5),(115,21,'2021-09-24 00:00:00',2,'ON REGULAR MEDICATION, CURRENTIY BETTER','','2021-11-19 00:00:00',0,0,5),(116,87,'2021-10-01 00:00:00',2,'','','2021-11-19 00:00:00',0,0,0),(117,14,'2021-09-24 00:00:00',2,'ON REGULAR MEDICATION','','2021-11-19 00:00:00',0,0,5),(118,107,'2021-11-12 00:00:00',2,'','ILA PHONE FOLLOWUP','2021-11-19 00:00:00',0,0,0),(119,5,'2021-10-08 00:00:00',2,'GONE WITH VOLOUTEER LOOKS BETTER NOW \nOVERALL FUNCTIONS BETTER MONITORING IS DOING BY MOTHER ','NEED ILA VOLOUNTEER HOME VISIT','2021-11-26 00:00:00',0,0,5),(120,108,'2021-11-12 00:00:00',2,'','','2021-11-26 00:00:00',0,0,0),(121,35,'2021-11-19 00:00:00',2,'ON REGULAR MEDICATION \nONE WEEK BEFORE THE REPORT THE HAD EATERN A PEN TOP \nSO SUGGETED TO TAKE X-RAY','ILA HOME VISIT ','2021-12-03 00:00:00',0,0,5),(122,76,'2021-11-26 00:00:00',2,'BETTER\nNOT WILLING IN DAY TO DAY FUNTION','WEEKILY ILA HOME VISIT','2021-12-24 00:00:00',0,0,0),(123,12,'2021-11-12 00:00:00',2,'BETTER','','2022-01-07 00:00:00',0,0,0),(124,42,'2021-11-26 00:00:00',2,'BETTER','','2022-01-21 00:00:00',0,0,0),(125,81,'2021-10-22 00:00:00',2,'ON REGULAR MEDICATION\nOVER ALL FUNCTIONING\nSELFCARE - IMPROVED.\n','','2021-12-17 00:00:00',0,0,5),(126,14,'2021-11-19 00:00:00',2,'REPORTED WITH MOTHER\nON REGULAR MEDICATION\nBETTER ON MEDICATION\n\n','','2021-12-17 00:00:00',0,0,7),(127,104,'2021-11-26 00:00:00',2,'NEW CASE \nBETTER','','2021-12-24 00:00:00',0,0,0),(128,95,'2021-11-05 00:00:00',0,'PSI FOLLOWUP ','',NULL,0,0,0),(129,11,'2021-11-05 00:00:00',2,'REPORTED ALONE \nREGULAR MEDICATION \nNEED TO MONITOR MEDICINAL IN TAKES','ILA VOLUNEETR HOME VISIT','2021-12-10 00:00:00',0,0,7),(130,31,'2021-10-15 00:00:00',2,'OVER ALL BETTER','','2021-12-10 00:00:00',0,0,0),(131,112,'2021-12-03 00:00:00',2,'BLOOD ROUTINE , RBS , SGOT , SGPT , TC , DC','','2021-12-10 00:00:00',0,0,12),(132,102,'2021-12-03 00:00:00',2,'START OUR TREATMENT \n','','2021-12-10 00:00:00',0,0,5),(133,107,'2021-11-26 00:00:00',2,'SLEEP IS POOR','','2021-12-10 00:00:00',0,0,0),(134,44,'2021-11-12 00:00:00',2,'BETTER','','2021-12-10 00:00:00',0,0,0),(135,13,'2021-11-19 00:00:00',2,'PROXY REPORTED (WIFE)\nON REGULAR MEDICATION \nC/O DECREASED SLEEP REPORTED \nPHYSICAL CONPLAINTS TREDTED IN EMS HOSPITAL\nHYPER SALIRATION AND TREMERS WERE REPORTED \nIRRTABILITY \nPSYCHOTIC SYMPTOMS STIL PRESENT ','ILA PHONE FOLLOWUP  \nMHAT HOME VISIT - TO UNDERSTAND THE PHYSICAL CONDITION','2021-12-17 00:00:00',0,0,7),(136,27,'2021-11-26 00:00:00',2,'BETTER','','2021-12-10 00:00:00',0,0,0),(137,102,'2021-12-10 00:00:00',2,'TO START INJ- FFD 25MG ONCE IN 2WEEK FROM NEXT WEEK \nBETTER ON MEDICINE','ILA PHONE FOLLOWUP','2021-12-24 00:00:00',0,0,0),(138,45,'2021-11-26 00:00:00',2,'START RISPERIDONE ORAL SOLUTION 0-0-4ML','ILA HOME VISIT','2021-12-24 00:00:00',0,0,0),(139,108,'2021-11-26 00:00:00',2,'','','2021-12-24 00:00:00',0,0,0),(140,90,'2021-12-03 00:00:00',2,'ON REGULAR MEDICATION NOW \nLAST OP- DID NOT COME BECAUSE HE HAS WORK','','2021-12-24 00:00:00',0,0,5),(141,112,'2021-12-10 00:00:00',2,'IMPROVED IN SYMPTOMS ','','2021-12-24 00:00:00',0,0,0),(142,33,'2021-10-01 00:00:00',2,'NO FRESH COMPLAINS REPORTED\nON REGULAR MEDICINE NOW \nMUCH BETTER NOW ','','2021-12-24 00:00:00',0,0,5),(143,85,'2021-12-17 00:00:00',2,'ON REGULAR MEDICATION NOW \nCONSULTED DR. DIVYA FOR THE C/O - DEPRESSIVE COGNITION \n','','2021-12-24 00:00:00',0,0,5),(144,116,'2021-12-31 00:00:00',2,'','','2022-01-07 00:00:00',0,0,7),(145,46,'2021-12-10 00:00:00',2,'BETTTER\n','','2022-01-07 00:00:00',0,0,0),(146,32,'2021-12-17 00:00:00',2,'REPORTED ALONE\nON REGULAR MEDICATION \nC/O DECREASED SLEEP , PANIC ATTACK CDURING THE NIGHT TIME \nANXIOUS \nMOOD DYSTHYMIC \nOC SYMPTOMS \nWAKE UP 03:00AM \n','','2022-01-07 00:00:00',0,0,7),(147,1,'2021-11-26 00:00:00',2,'','','2022-01-07 00:00:00',0,0,7),(148,1,'2021-12-24 00:00:00',0,'REPORTED ALONE \nREGULAR MEDICATION \nWORK RELATED DISCUSSION ----- PLAN REGULAR WORK \nACTIVITY SCHEDULE CONTINVE \nASSESSMENT NEEDED - RECOVERY STAR \nLATE WAKE UP REPORTED SUGGESTED TO TAKE MADICINES AT EARLIER 7PM \nDISABILITY PENTION - GAT','','2022-01-07 00:00:00',0,0,7),(149,115,'2021-12-31 00:00:00',2,'HOME VISIT OP \nNEW CASE','','2022-01-07 00:00:00',0,0,7),(150,19,'2021-12-17 00:00:00',2,'ON REGULAR MEDICATION NOW\n','','2022-01-07 00:00:00',0,0,5),(151,13,'2021-12-24 00:00:00',2,'HOME VISIT OP ','ILA PHONE FOLLOW UP','2022-01-07 00:00:00',0,0,5),(152,37,'2021-12-24 00:00:00',2,'','','2022-02-11 00:00:00',0,0,5),(153,100,'2021-10-22 00:00:00',2,'PROXY \nON REGULAR MEDICATION\nC/O HEAD ACEC\n4 DAYS BACK FELL DOWN PHYSICAL \nNEED PHYSICAL CONSULTATION (ORTHO)\n','','2022-01-14 00:00:00',0,0,5),(154,11,'2021-12-10 00:00:00',2,'','','2022-01-21 00:00:00',0,0,0),(155,80,'2021-12-24 00:00:00',2,'OVER ALL BETTER','','2022-03-18 00:00:00',0,0,0),(156,44,'2021-12-10 00:00:00',2,'','','2022-01-21 00:00:00',0,0,0),(157,112,'2021-12-31 00:00:00',2,'REPORTED WITH MOTHER \nC/O EDEMA REPORTED SUGGESTED TO PHYSICION \nSLEEP AND APPETITE WERE NORMAL \nPSI - FAMILY INTERVENTION','','2022-01-21 00:00:00',0,0,7),(158,118,'2021-12-31 00:00:00',2,'REPORTED WITH MOTHER \nON REGULAR MEDICATION \nNO IMPROVEMENT ','','2022-01-14 00:00:00',0,0,7),(159,110,'2021-12-17 00:00:00',2,'ON REGULAR MEDICATION NOW \nMOOD - IMPROVEMENT \nGOING TO WORK REGULARLY ','','2022-02-11 00:00:00',0,0,5),(160,117,'2021-12-31 00:00:00',2,'NEW CASE ','','2022-01-07 00:00:00',0,0,7),(161,76,'2021-12-24 00:00:00',2,'OVER ALL BETTER','','2022-02-18 00:00:00',0,0,0),(162,121,'2022-01-07 00:00:00',2,'','','2022-01-14 00:00:00',0,0,0),(163,17,'2022-01-07 00:00:00',2,'DROP IN CASE\nDEPENT MOOD','','2022-02-04 00:00:00',0,0,0),(164,120,'2022-01-07 00:00:00',0,'NEW CASE','','2022-01-14 00:00:00',0,0,0),(165,12,'2021-12-31 00:00:00',2,'REPORTED ALONG\nON REGULAR MEDICATION\nBETTER ON MEDICATION\nEDEMA SETTLED \nMENTAL HEALTH STABLE \nREPEAT SAME MEDICINES','','2022-01-21 00:00:00',0,0,7),(166,81,'2021-12-17 00:00:00',2,'ON REGULAR MEDICATION\nCURRENLY IMPROVEMANT REPORTED','','2022-02-11 00:00:00',0,0,5),(167,23,'2021-12-10 00:00:00',2,'ON REGULAR MEDICATION NOW\nOVERALL BETTER NOW','','2022-01-21 00:00:00',0,0,5),(168,13,'2022-01-07 00:00:00',2,'PHONE FOLLOWUP\nON REGULARTION\nREDUCED SLEEP\nFINANCIAL SUPPORT NEED','','2022-01-21 00:00:00',0,0,7),(169,27,'2022-01-07 00:00:00',2,'PSI FOR MEDICIN COMPLAINCE','','2022-02-18 00:00:00',0,0,0),(170,14,'2021-12-24 00:00:00',2,'','','2022-02-04 00:00:00',0,0,0),(171,104,'2022-01-07 00:00:00',2,'','','2022-01-14 00:00:00',0,0,0),(172,3,'2021-12-24 00:00:00',2,'OVER ALL BETTER','','2022-03-18 00:00:00',0,0,0),(173,7,'2021-12-03 00:00:00',2,'ON REGULAR MEDICATION\nOVERALL BETTER NOW\nSTABLE','','2022-02-25 00:00:00',0,0,5),(174,21,'2021-11-19 00:00:00',2,'REPORTED WITH MOTHER\nON REGULAR MEDICATION\nSLEEP AND APPETITE WERE NORMAL\nBETTER ON MEDICATION\nREPEAT SAME MEDICINES\n','','2022-01-14 00:00:00',0,0,7),(175,90,'2021-12-24 00:00:00',2,'','','2022-02-04 00:00:00',0,0,0),(176,50,'2021-12-24 00:00:00',2,'','','2022-02-18 00:00:00',0,0,0),(177,78,'2021-12-24 00:00:00',2,'BETTER','','2022-02-18 00:00:00',0,0,0),(178,41,'2021-12-17 00:00:00',2,'ON REGULAR MEDICATION NOW\nMENTAL STATE - STABLE','','2022-02-11 00:00:00',0,0,5),(179,30,'2021-11-26 00:00:00',0,'','','2022-01-21 00:00:00',0,0,0),(180,46,'2021-12-10 00:00:00',2,'BETTER','','2022-01-14 00:00:00',0,0,0),(181,121,'2022-01-07 00:00:00',2,'','','2022-01-14 00:00:00',0,0,0),(182,44,'2021-12-10 00:00:00',2,'','','2022-01-21 00:00:00',0,0,0),(183,18,'2022-01-07 00:00:00',2,'','','2022-03-04 00:00:00',0,0,0),(184,19,'2022-01-07 00:00:00',2,'','','2022-01-21 00:00:00',0,0,0),(185,29,'2021-12-31 00:00:00',2,'ON REGULAR MEDICATION','','2022-01-28 00:00:00',0,0,7),(186,10,'2021-12-03 00:00:00',2,'ON REGULAR MEDICIN\nOVERALL BETTER NOW','','2022-01-28 00:00:00',0,0,5),(187,5,'2021-12-24 00:00:00',2,'OVERALL BETTER','',NULL,0,0,0),(188,16,'2022-01-07 00:00:00',2,'PHONE FOLLOWUP \nON REGULAR MEDICATION\n','','2022-01-21 00:00:00',0,0,7),(189,15,'2021-12-17 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER NOW','','2022-02-11 00:00:00',0,0,0),(190,77,'2021-12-03 00:00:00',2,'OVERALL BETTER NOW','','2022-01-14 00:00:00',0,0,5),(191,45,'2021-12-31 00:00:00',2,'IRREGULAR MEDICATION\nSELF TALK REPORTED \nSELF CARE POOR','','2022-01-14 00:00:00',0,0,7),(192,85,'2021-12-24 00:00:00',2,'OVERALL BETTER','','2022-01-14 00:00:00',0,0,0),(193,24,'2021-12-03 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER NOW \nDISCUSSED ABOUT DAY CARE PLAN','','2022-01-14 00:00:00',0,0,5),(194,106,'2022-01-07 00:00:00',2,'RAMLA REPORTED WITH HUSBAND \nASSESSMENT \nCHECKING PER DAY CURRENTIY NOT PRESENT \nHAND WASHING 10 TIMES PER DAY PLATE CLEANING USING WATER MORE \nTIM CONSUMING \nWASHING DRESS 20 MINUTE FIR ONE DERSS\n','','2022-01-14 00:00:00',0,0,7),(195,105,'2021-12-10 00:00:00',2,'','','2022-01-14 00:00:00',0,0,0),(196,108,'2021-12-24 00:00:00',2,'','','2022-01-14 00:00:00',0,0,0),(197,114,'2022-01-07 00:00:00',2,'','','2022-01-14 00:00:00',0,0,0),(198,32,'2022-01-07 00:00:00',2,'','','2022-01-14 00:00:00',0,0,0),(199,84,'2022-01-14 00:00:00',2,'ON REGULAR MEDICATION NOW \nMUCH BETTER - STABLE MOOD \nNO FRESH COMPLAINTS\n','','2022-03-11 00:00:00',0,0,5),(200,112,'2022-01-14 00:00:00',2,'ON REGULAR MEDICATION\nBETTER ON MEDICIN','','2022-02-11 00:00:00',0,0,7),(201,115,'2022-01-07 00:00:00',2,'','','2022-01-21 00:00:00',0,0,0),(202,122,'2022-01-14 00:00:00',2,'NEW CASE\n','','2022-01-21 00:00:00',0,0,7),(203,120,'2022-01-14 00:00:00',2,'REPORTED WITH HUSBAND\nON REGULAR MEDICATION\nINCREASED TALK','','2022-01-21 00:00:00',0,0,7),(204,121,'2022-01-14 00:00:00',2,'ON REGULAR MEDICATION\n','','2022-02-04 00:00:00',0,0,7),(205,104,'2022-01-14 00:00:00',2,'REPORTED WITH WIFE \nON REGULAR MEDICATION\nBETTER ON MEDICATION\n','','2022-01-28 00:00:00',0,0,7),(206,106,'2022-01-14 00:00:00',2,'REPORTED WITH HUSBAND \nMEDICIN STRET','','2022-01-28 00:00:00',0,0,7),(207,50,'2022-01-14 00:00:00',0,'REPORTED ALONE \nON REGULAR MEDICATION\n','','2022-02-18 00:00:00',0,0,7),(208,46,'2022-01-14 00:00:00',2,'OVER ALL BETTER','','2022-02-25 00:00:00',0,0,5),(209,77,'2022-01-14 00:00:00',2,'','','2022-02-11 00:00:00',0,0,5),(210,85,'2022-01-14 00:00:00',2,'ON REGULAR MEDICATION NOW\nOVERALL BETTER NOW\n','','2022-02-11 00:00:00',0,0,5),(211,14,'2022-01-14 00:00:00',2,'ON REGULAR MEDICATION NOW\nMOTHER IS ALSO PT','','2022-02-04 00:00:00',0,0,5),(212,108,'2022-01-14 00:00:00',2,'ON REGULAR MEDICATION NOW \n80/ IMPROVEMENT DOING HOUSE HOLD','','2022-02-11 00:00:00',0,0,5),(213,105,'2022-01-14 00:00:00',2,'MEDICATION IS REGULAR NOW','','2022-02-11 00:00:00',0,0,5),(214,21,'2022-01-14 00:00:00',2,'ON REGULAR MEDICATION NOW\n','','2022-03-11 00:00:00',0,0,5),(215,16,'2022-01-14 00:00:00',2,'ON REGULAR MEDICATION NOW','','2022-01-28 00:00:00',0,0,5),(216,13,'2022-01-14 00:00:00',2,'','','2022-01-28 00:00:00',0,0,5),(217,6,'2022-01-14 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER NOW \n','','2022-02-11 00:00:00',0,0,5),(218,24,'2022-01-14 00:00:00',2,'','','2022-02-11 00:00:00',0,0,5),(219,83,'2022-01-14 00:00:00',2,'ON REGULAR MEDICATION NOW\nMENTAL STATE STABLE','','2022-03-11 00:00:00',0,0,5),(220,36,'2021-12-17 00:00:00',2,'ON REGULAR MEDICATIION NOW\nOVERALL BETTER NOW','','2022-02-11 00:00:00',0,0,5),(221,117,'2022-01-07 00:00:00',2,'','','2022-01-21 00:00:00',0,0,0),(222,39,'2021-12-10 00:00:00',2,'','','2022-03-04 00:00:00',0,0,0),(223,87,'2021-12-31 00:00:00',2,'ON REGULAR MEDICATION NOW \n','','2022-02-18 00:00:00',0,0,7),(224,1,'2022-01-07 00:00:00',2,'ON REGULAR MEDICATION NOW','','2022-03-04 00:00:00',0,0,5),(225,35,'2021-12-24 00:00:00',2,'OVERALL BETTER NOW','','2022-02-18 00:00:00',0,0,0),(226,89,'2021-12-31 00:00:00',2,'','','2022-01-28 00:00:00',0,0,7),(227,89,'2021-12-31 00:00:00',2,'ON REGULAR MEDICATION NOW\n','','2022-01-28 00:00:00',0,0,7),(228,25,'2021-12-24 00:00:00',2,'','','2022-02-18 00:00:00',0,0,0),(229,102,'2021-12-24 00:00:00',2,'OVERALL BETTER NOW ','','2022-01-21 00:00:00',0,0,0),(230,103,'2021-12-24 00:00:00',2,'','','2022-02-04 00:00:00',0,0,0),(231,91,'2021-10-01 00:00:00',2,'','','2022-01-21 00:00:00',0,0,0),(232,2,'2021-11-19 00:00:00',2,'ON REGULAR MEDICIN NOW \nOVER ALL BETTER NOW','','2022-02-11 00:00:00',0,0,5),(233,31,'2021-12-24 00:00:00',2,'','','2022-03-18 00:00:00',0,0,0),(234,4,'2021-12-17 00:00:00',2,'ON REGULAR MEDICATION NOW\nOVERALL BETTER NOW','','2022-03-11 00:00:00',0,0,5),(235,86,'2021-12-31 00:00:00',2,'ON REGULAR MEDICATION NOW ','','2022-01-28 00:00:00',0,0,7),(236,9,'2021-12-24 00:00:00',2,'REPORTED WITH WIFE \nIRREGULAR MEDICATION\nALCAHOL USEGE RESTART','','2022-01-21 00:00:00',0,0,7),(237,99,'2021-11-26 00:00:00',2,'','','2022-01-21 00:00:00',0,0,0),(238,82,'2021-12-24 00:00:00',2,'HOME VISIT \n','','2022-01-21 00:00:00',0,0,5),(239,113,'2021-12-31 00:00:00',2,'PROXY REPORTED WITH MOTHER\nON REGULAR MEDICATION NOW  \nBETTER ON MEDICIN','','2022-01-21 00:00:00',0,0,7),(240,79,'2021-12-23 00:00:00',2,'','','2022-03-18 00:00:00',0,0,0),(241,43,'2021-11-26 00:00:00',2,'ON REGULER MEDICATION NOW \n','','2022-02-18 00:00:00',0,0,5),(242,40,'2021-12-17 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVER ALL BETTER NOW , STABLE MOOD ','','2022-01-28 00:00:00',0,0,5),(243,34,'2021-12-10 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER NOW','','2022-02-04 00:00:00',0,0,5),(244,33,'2021-12-24 00:00:00',2,'','','2022-03-18 00:00:00',0,0,0),(245,47,'2021-12-31 00:00:00',2,'REPORTED ALONE \n','','2022-01-28 00:00:00',0,0,7),(246,101,'2021-11-12 00:00:00',2,'HOME VISIT \nON REGULAR MEDICATION NOW ','','2022-02-04 00:00:00',0,0,5),(247,94,'2021-11-26 00:00:00',2,'','','2022-02-25 00:00:00',0,0,0),(248,20,'2021-12-24 00:00:00',2,'','','2022-03-18 00:00:00',0,0,0),(249,48,'2021-12-10 00:00:00',2,'','','2022-03-04 00:00:00',0,0,0),(250,22,'2021-12-24 00:00:00',2,'','','2022-02-18 00:00:00',0,0,0),(251,92,'2021-11-05 00:00:00',2,'PSI FOLLOWUP','','2022-01-21 00:00:00',0,0,0),(252,112,'2022-01-21 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER NOW \nSTABLE MOOD\nNO FRESH COMPLAINT','','2022-02-18 00:00:00',0,0,5),(253,23,'2022-01-21 00:00:00',2,'','','2022-04-15 00:00:00',0,0,0),(254,123,'2022-01-21 00:00:00',2,'NEW CASE','','2022-02-11 00:00:00',0,0,0),(255,115,'2022-01-21 00:00:00',2,'','','2022-02-18 00:00:00',0,0,0),(256,122,'2022-01-21 00:00:00',2,'','','2022-02-11 00:00:00',0,0,0),(257,82,'2022-01-21 00:00:00',2,'','','2022-02-18 00:00:00',0,0,0),(258,4,'2022-01-21 00:00:00',2,'','','2022-04-15 00:00:00',0,0,0),(259,8,'2022-01-21 00:00:00',2,'','','2022-04-15 00:00:00',0,0,0),(260,102,'2022-01-21 00:00:00',2,'','','2022-03-18 00:00:00',0,0,0),(261,100,'2022-01-21 00:00:00',2,'FAMILY PSYCHO EDUCATION NEED \nNEED TO CALL FAMILY TO THE CLINIC \n','HOME VISIT 25-01-2022','2022-03-18 00:00:00',0,0,0),(262,11,'2022-01-21 00:00:00',2,'','','2022-03-18 00:00:00',0,0,0),(263,113,'2022-01-21 00:00:00',2,'','','2022-03-18 00:00:00',0,0,0),(264,118,'2022-01-21 00:00:00',2,'','','2022-02-18 00:00:00',0,0,0),(265,46,'2022-01-21 00:00:00',2,'','','2022-02-18 00:00:00',0,0,0),(266,117,'2022-01-21 00:00:00',2,'','','2022-02-25 00:00:00',0,0,0),(267,94,'2022-01-21 00:00:00',2,'','','2022-04-15 00:00:00',0,0,0),(268,19,'2022-01-21 00:00:00',2,'','','2022-02-18 00:00:00',0,0,0),(269,9,'2022-01-21 00:00:00',2,'','','2022-03-11 00:00:00',0,0,0),(270,115,'2022-01-28 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER NOW\nSTABLE MOOD','','2022-02-18 00:00:00',0,0,5),(271,120,'2022-01-28 00:00:00',2,'NEED PSI','','2022-02-25 00:00:00',0,0,7),(272,31,'2022-01-28 00:00:00',2,'PHONE FOLLOWUP','','2022-02-25 00:00:00',0,0,7),(273,13,'2022-01-28 00:00:00',2,'','','2022-02-18 00:00:00',0,0,12),(274,16,'2022-01-28 00:00:00',2,'ON REGULAR MEDICATION','','2022-02-18 00:00:00',0,0,7),(275,40,'2022-01-28 00:00:00',2,'','','2022-02-25 00:00:00',0,0,12),(276,41,'2022-01-28 00:00:00',2,'STOP T CLOZAPINE & T ECITALOPRAM','','2022-02-11 00:00:00',0,0,5),(277,10,'2022-01-28 00:00:00',2,'','','2022-03-25 00:00:00',0,0,5),(278,12,'2022-01-28 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER','','2022-03-25 00:00:00',0,0,5),(279,29,'2022-01-28 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER NOW','','2022-02-25 00:00:00',0,0,5),(280,104,'2022-01-28 00:00:00',2,'ON REGULAR MEDICATION NOW','','2022-02-18 00:00:00',0,0,5),(281,89,'2022-01-28 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER NOW','','2022-02-25 00:00:00',0,0,5),(282,86,'2022-01-28 00:00:00',2,'ON REGULAR MEDICATION NOW \n','','2022-03-25 00:00:00',0,0,5),(283,9,'2022-02-04 00:00:00',0,'PSI FOLLOW UP','',NULL,0,0,0),(284,48,'2022-02-04 00:00:00',0,'PSI FOLLOW UP','',NULL,0,0,0),(285,40,'2022-02-04 00:00:00',0,'PSI FOLLOWUP','',NULL,0,0,0),(286,17,'2022-02-04 00:00:00',2,'','','2022-03-18 00:00:00',0,0,0),(287,121,'2022-02-04 00:00:00',2,'','','2022-03-04 00:00:00',0,0,0),(288,90,'2022-02-04 00:00:00',2,'','','2022-04-15 00:00:00',0,0,0),(289,32,'2022-02-04 00:00:00',2,'','','2022-03-18 00:00:00',0,0,0),(290,118,'2022-02-04 00:00:00',2,'','','2022-02-18 00:00:00',0,0,0),(291,14,'2022-02-04 00:00:00',2,'','','2022-04-01 00:00:00',0,0,0),(292,123,'2022-02-04 00:00:00',2,'','','2022-03-04 00:00:00',0,0,0),(293,31,'2022-02-04 00:00:00',2,'','','2022-03-18 00:00:00',0,0,0),(294,49,'2022-02-04 00:00:00',2,'','','2022-03-04 00:00:00',0,0,0),(295,44,'2022-02-04 00:00:00',2,'','','2022-02-25 00:00:00',0,0,0),(296,108,'2022-02-11 00:00:00',2,'','',NULL,0,0,7),(297,108,'2022-03-11 00:00:00',2,'ON REGULAR MEDICATION NOW','','2022-04-01 00:00:00',0,0,5),(298,5,'2022-02-18 00:00:00',2,'OVERALL BETTER NOW','','2022-05-13 00:00:00',0,0,0),(299,10,'2022-02-25 00:00:00',2,'ON REGULAR MEDICATION NOW','','2022-03-18 00:00:00',0,0,5),(300,114,'2022-02-25 00:00:00',2,'ON REGULAR MEDICATION NOW','','2022-03-25 00:00:00',0,0,5),(301,22,'2022-02-18 00:00:00',2,'OVERALL BETTER NOW ','','2022-05-13 00:00:00',0,0,0),(302,20,'2022-03-11 00:00:00',2,'ON REGULAR MEDICINE NOW','','2022-04-08 00:00:00',0,0,12),(303,13,'2022-02-11 00:00:00',2,'ON REGULAR MEDICINE NOW','',NULL,0,0,7),(304,13,'2022-03-18 00:00:00',2,'','','2022-03-18 00:00:00',0,0,0),(305,16,'2022-01-25 00:00:00',0,'PSI FOLLOWUP','',NULL,0,0,0),(306,16,'2022-02-18 00:00:00',2,'','','2022-03-18 00:00:00',0,0,0),(307,16,'2022-02-25 00:00:00',2,'','','2022-03-25 00:00:00',0,0,12),(308,101,'2022-02-04 00:00:00',2,'','',NULL,0,0,5),(309,101,'2022-03-04 00:00:00',2,'','','2022-05-27 00:00:00',0,0,0),(310,77,'2022-02-18 00:00:00',2,'','','2022-03-18 00:00:00',0,0,0),(311,83,'2022-02-11 00:00:00',2,'','ON REGULAR MEDICATION NOW','2022-04-08 00:00:00',0,0,7),(312,84,'2022-02-11 00:00:00',2,'','','2022-04-08 00:00:00',0,0,0),(313,82,'2022-02-18 00:00:00',2,'C/O POOR SLEEP , ASSAQUITIVE BEHAVIOUR ,PHYSICAL CONDITION IS BETTER \n\n','','2022-04-15 00:00:00',0,0,0),(314,40,'2022-02-18 00:00:00',2,'PSI FOLLOW UP ','',NULL,0,0,0),(315,40,'2022-02-25 00:00:00',1,'ON REGULAR MEDICATION , NEED VOLUNTEER HOME VISIT  FOR MEDICINE CHECK \n','','2022-03-25 00:00:00',0,0,5),(316,117,'2022-02-25 00:00:00',2,'ON REGULAR MEDICATION NOW MILD IMPROVMENT ,STOP CARBAMAZAPINE\n','','2022-03-25 00:00:00',0,0,5),(317,45,'2022-02-18 00:00:00',2,'','',NULL,0,0,0),(318,45,'2022-02-25 00:00:00',2,'ON REGULAR MEDICATION NOW\nOVER ALL BETTER NOW\nSTABLE','',NULL,0,0,7),(319,45,'2022-03-18 00:00:00',2,'','','2022-04-15 00:00:00',0,0,0),(320,120,'2022-02-11 00:00:00',2,'','',NULL,0,0,7),(321,120,'2022-03-03 00:00:00',2,'','',NULL,0,0,0),(322,120,'2022-03-18 00:00:00',2,'','','2022-04-01 00:00:00',0,0,0),(323,33,'2022-01-21 00:00:00',2,'','',NULL,0,0,0),(324,33,'2022-02-18 00:00:00',2,'PSI FOLLOWUP','',NULL,0,0,0),(325,33,'2022-03-18 00:00:00',2,'','','2022-06-03 00:00:00',0,0,0),(326,35,'2022-02-18 00:00:00',2,'','','2022-03-25 00:00:00',0,0,0),(327,76,'2022-03-18 00:00:00',2,'OVERALL BETTER NOW','','2022-03-25 00:00:00',0,0,0),(328,25,'2022-03-18 00:00:00',2,'','','2022-03-25 00:00:00',0,0,0),(329,87,'2022-02-03 00:00:00',2,'PSI FOLLOWUP','',NULL,0,0,0),(330,87,'2022-02-18 00:00:00',2,'','','2022-04-15 00:00:00',0,0,0),(331,39,'2021-07-02 00:00:00',2,'','',NULL,0,0,0),(332,39,'2021-08-27 00:00:00',0,'ON REGULAR MEDICATION NOW \nOVERALL BETTER NOW','',NULL,0,0,5),(333,39,'2022-03-04 00:00:00',2,'','','2022-05-27 00:00:00',0,0,0),(334,122,'2022-02-11 00:00:00',2,'','',NULL,0,0,7),(335,122,'2022-03-11 00:00:00',2,'','',NULL,0,0,5),(336,122,'2022-03-18 00:00:00',2,'','','2022-04-29 00:00:00',0,0,0),(337,115,'2022-03-18 00:00:00',2,'','','2022-05-13 00:00:00',0,0,0),(338,115,'2022-02-18 00:00:00',2,'','',NULL,0,0,0),(339,79,'2021-10-08 00:00:00',2,'','',NULL,0,0,5),(340,43,'2022-02-18 00:00:00',2,'','','2022-05-13 00:00:00',0,0,5),(341,113,'2022-03-18 00:00:00',2,'','','2022-06-03 00:00:00',0,0,0),(342,37,'2022-03-18 00:00:00',2,'','','2022-06-03 00:00:00',0,0,0),(343,15,'2022-02-11 00:00:00',2,'','',NULL,0,0,12),(344,15,'2022-03-11 00:00:00',2,'','','2022-05-06 00:00:00',0,0,5),(345,1,'2022-03-04 00:00:00',2,'','','2022-05-13 00:00:00',0,0,5),(346,102,'2022-03-03 00:00:00',2,'','',NULL,0,0,5),(347,102,'2022-03-18 00:00:00',2,'ON REGULAR MEDICATION NOW\nOVERALL BETTER NOW \nNEED SURGEN CONSUITATION NOW','','2022-05-13 00:00:00',0,0,0),(348,17,'2022-03-18 00:00:00',2,'','','2022-05-13 00:00:00',0,0,0),(349,2,'2022-02-11 00:00:00',2,'ON REGULAR MEDICATION NOW \nMAINTAINING WELL \n','','2022-05-06 00:00:00',0,0,7),(350,31,'2022-03-18 00:00:00',0,'ALL BEETER NOW ','','2022-05-20 00:00:00',0,0,0),(351,99,'2022-02-11 00:00:00',2,'HOME VISIT ','',NULL,0,0,5),(352,99,'2022-03-11 00:00:00',2,'HOME VISIT \nNO REGULAR MEDICATION NOW \nOVERALL BETTER NOW ','',NULL,0,0,5),(353,36,'2022-02-11 00:00:00',2,'','','2022-04-08 00:00:00',0,0,12),(354,32,'2022-03-18 00:00:00',2,'','','2022-05-13 00:00:00',0,0,0),(355,106,'2022-01-28 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER \nSTABLE MOOD \nCURRENT FUNTIONING ','',NULL,0,0,5),(356,106,'2022-02-25 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER NOW','',NULL,0,0,5),(357,42,'2022-02-11 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER NOW','',NULL,0,0,5),(358,42,'2022-02-18 00:00:00',2,'HOME VISIT ','',NULL,0,0,5),(359,81,'2022-03-11 00:00:00',2,'ON REGULAER MEDICATION NOW \nOVERALL BETTER NOW','','2022-06-03 00:00:00',0,0,5),(360,35,'2022-03-25 00:00:00',2,'ON REGULAR MEDICATION NOW \nDISSAIED ABOUT DAY CARE \nOVERALL BETTER NOW','','2022-05-20 00:00:00',0,0,5),(361,44,'2022-02-25 00:00:00',2,'ON REGULAR MEDICATION NOW','','2022-04-01 00:00:00',0,0,5),(362,44,'2022-03-25 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER NOW ','','2022-05-20 00:00:00',0,0,5),(363,16,'2022-03-25 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER NOW ','','2022-05-06 00:00:00',0,0,5),(364,86,'2022-03-25 00:00:00',2,'ON REGULAR MEDICATION NOW\nOVERALL BETTER NOW','','2022-05-20 00:00:00',0,0,5),(365,31,'2022-04-08 00:00:00',0,'PSI FOLLOWUP','',NULL,0,0,0),(366,31,'2022-05-06 00:00:00',2,'','','2022-07-29 00:00:00',0,0,0),(367,31,'2022-06-17 00:00:00',0,'PSI FOLLOWUP','',NULL,0,0,0),(368,126,'2022-02-18 00:00:00',2,'NEW CASE','',NULL,0,0,0),(369,126,'2022-03-04 00:00:00',2,'OVERALL BETTER NOW ','',NULL,0,0,0),(370,126,'2022-03-18 00:00:00',2,'OVERALL BETTER NOW ','',NULL,0,0,0),(371,126,'2022-06-10 00:00:00',2,'','',NULL,0,0,0),(372,126,'2022-06-24 00:00:00',2,'','','2022-07-22 00:00:00',0,0,0),(373,10,'2022-03-25 00:00:00',2,'ON REGULAR MEDICATION \nOVERALL BETTER NOW \nSTABLE NOW ','',NULL,0,0,5),(374,10,'2022-04-08 00:00:00',2,'ON REGULAR MEDICATION NOW\nOVERALL ','',NULL,0,0,5),(375,10,'2022-05-06 00:00:00',2,'','','2022-07-15 00:00:00',0,0,0),(376,108,'2022-04-01 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER ','',NULL,0,0,0),(377,108,'2022-05-27 00:00:00',2,'ON REGULAR MEDICATION NOW','',NULL,0,0,5),(378,108,'2022-06-03 00:00:00',2,'ON REGULAR MEDICATION NOW \nBETTER NOW ','',NULL,0,0,5),(379,108,'2022-06-24 00:00:00',2,'','','2022-07-08 00:00:00',0,0,0),(380,5,'2022-05-13 00:00:00',0,'ON REGULAR MEDICATION NOW \nOVERALL BETTER ','','2022-08-05 00:00:00',0,0,5),(381,120,'2022-03-04 00:00:00',0,'PSI FOLLOWUP ','',NULL,0,0,0),(382,120,'2022-03-18 00:00:00',0,'PSI FOLLOWUP','',NULL,0,0,0),(383,120,'2022-03-25 00:00:00',0,'PSI FOLLOWUP','',NULL,0,0,0),(384,120,'2022-04-01 00:00:00',2,'OVERALL BETTER NOW','',NULL,0,0,0),(385,120,'2022-04-22 00:00:00',0,'PSI FOLLOWUP','',NULL,0,0,0),(386,120,'2022-04-29 00:00:00',0,'PSI FOLLOWUP','',NULL,0,0,0),(387,120,'2022-05-06 00:00:00',2,'','','2022-07-01 00:00:00',0,0,0),(388,120,'2022-05-27 00:00:00',0,'PSI FOLLOWUP','',NULL,0,0,0),(389,120,'2022-06-24 00:00:00',0,'PSI FOLLOWUP','',NULL,0,0,0),(390,48,'2022-05-27 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER ','','2022-07-22 00:00:00',0,0,5),(391,114,'2022-03-25 00:00:00',2,'ON REGULAR MEDICATION \nOVERALL BETTER NOW','',NULL,0,0,5),(392,114,'2022-05-20 00:00:00',0,'','','2022-08-12 00:00:00',0,0,0),(393,20,'2022-04-08 00:00:00',0,'ON REGULAR MEDICATION NOW\nOVERALL BETTER NOW\nSTABLE MOOD','',NULL,0,0,5),(394,20,'2022-06-10 00:00:00',2,'','',NULL,0,0,0),(395,94,'2022-05-20 00:00:00',2,'','','2022-08-19 00:00:00',0,0,0),(396,12,'2022-03-25 00:00:00',2,'ON REGULAR MEDICATION \nOVERALL BETTER NOW \nSTABLE MOOD','',NULL,0,0,5),(397,12,'2022-06-17 00:00:00',2,'ON REGULAR MEDICATION \nOVERALL BETTER NOW\n','','2022-09-09 00:00:00',0,0,5),(398,104,'2022-02-25 00:00:00',2,'NOT TAKEN MEDICINE FOR ONE WEEK \nNO SLEEP FOR 3 DAYS \nDRY MOUTH \nTIREDNESS \nAH SETTLED \nFREQUENT HEADACHES \nLACK OF MTEREST \nWORTHLESSNESS \nHOPELESSNESS\nLOW ENERGY \nSTOPPED SMOKING \nFINANCIAL ISSUES REPORTED \nCLIENT DIDNOT VISIT THE CLINIC LAST WEEK AS HE IS UNABLE TO BEAR THE NOISE OF VEHICTES','',NULL,0,0,5),(399,104,'2022-03-04 00:00:00',0,'ON REGULAR MEDICATION NOW ','',NULL,0,0,0),(400,104,'2022-04-01 00:00:00',2,'','',NULL,0,0,0),(401,104,'2022-05-13 00:00:00',0,'OVERALL BETTER NOW','',NULL,0,0,0),(402,104,'2022-06-24 00:00:00',2,'OVERALL BETTER NOW ','','2022-07-08 00:00:00',0,0,0),(403,23,'2022-02-25 00:00:00',0,'PSI FOLLOWUP','',NULL,0,0,0),(404,23,'2022-04-15 00:00:00',2,'','',NULL,0,0,0),(405,141,'2022-08-05 00:00:00',2,'NEW CASE ','',NULL,0,0,5),(406,141,'2022-08-12 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER NOW \nSTABLE MOOD ','','2022-08-26 00:00:00',0,0,5),(407,32,'2021-10-05 00:00:00',2,'PSI FOLLOWUP','',NULL,0,0,0),(408,32,'2021-11-19 00:00:00',2,'PSI FOLLOWUP \nON REGULAR MEDICATION NOW \n','',NULL,0,0,5),(409,32,'2021-12-03 00:00:00',2,'PSI FOLLOW UP \nON REGULAR MEDICATION NOW \n','',NULL,0,0,5),(410,32,'2021-12-17 00:00:00',2,'REPORTED ALONE\nON REGULAR MEDICATION NOW \n','',NULL,0,0,7),(411,32,'2022-01-07 00:00:00',2,'','',NULL,0,0,0),(412,32,'2022-02-04 00:00:00',0,'STOP MIRTAZAPINE TABLETS 7.5MG \nOVERALL BETTER NOW ','',NULL,0,0,0),(413,32,'2022-02-18 00:00:00',2,'','',NULL,0,0,0),(414,138,'2022-08-05 00:00:00',0,'NEW CACE\nON REGULARE MEDICICE','',NULL,0,0,5),(415,138,'2022-08-12 00:00:00',0,'ON REGULAR MEDICATION NOW \nOVERALL BETTER NOW \nSTABLE NOW','',NULL,0,0,5),(416,138,'2022-08-26 00:00:00',0,'IRREGULAR MEDICATION NOW \nFROM 1 WEEK NOT TAKE MEDICINE\n','','2022-09-02 00:00:00',0,0,5),(417,15,'2021-03-25 00:00:00',2,'BPAD','',NULL,0,0,4),(418,15,'2021-09-10 00:00:00',0,'','',NULL,0,0,7),(419,15,'2021-10-22 00:00:00',0,'','',NULL,0,0,5),(420,15,'2022-08-26 00:00:00',0,'PSI FOLLOW UP','','2022-09-02 00:00:00',0,0,0),(421,15,'2022-08-19 00:00:00',0,'','','2022-09-09 00:00:00',0,0,0),(422,15,'2022-08-12 00:00:00',0,'','',NULL,0,0,5),(423,15,'2022-08-05 00:00:00',0,'','',NULL,0,0,5),(424,15,'2022-07-29 00:00:00',0,'','',NULL,0,0,0),(425,15,'2022-07-01 00:00:00',0,'','',NULL,0,0,5),(426,15,'2022-05-20 00:00:00',0,'PSI FOLLOW UP','',NULL,0,0,0),(427,15,'2022-05-06 00:00:00',0,'','',NULL,0,0,0),(428,15,'2022-04-05 00:00:00',0,'PSI FOLLOWUP','',NULL,0,0,0),(429,15,'2022-03-11 00:00:00',0,'','',NULL,0,0,5),(430,15,'2022-02-11 00:00:00',0,'','',NULL,0,0,12),(431,15,'2022-02-04 00:00:00',0,'PSI FOLLOWUP','',NULL,0,0,0),(432,15,'2022-01-14 00:00:00',0,'PSI FOLLOWUP','',NULL,0,0,0),(433,15,'2021-12-24 00:00:00',0,'PSI FOLLOWUP','',NULL,0,0,0),(434,15,'2021-12-17 00:00:00',0,'','',NULL,0,0,5),(435,15,'2021-12-10 00:00:00',0,'PSI FOLLOWUP','',NULL,0,0,0),(436,15,'2021-11-19 00:00:00',2,'','',NULL,0,0,5),(437,15,'2021-08-06 00:00:00',2,'','',NULL,0,0,0),(438,15,'2021-07-09 00:00:00',2,'','',NULL,0,0,5),(439,15,'2021-06-11 00:00:00',2,'','',NULL,0,0,4),(440,15,'2021-05-07 00:00:00',2,'','',NULL,0,0,4),(441,15,'2021-04-08 00:00:00',2,'','',NULL,0,0,0),(442,128,'2022-07-29 00:00:00',2,'','',NULL,0,0,0),(443,128,'2022-08-12 00:00:00',2,'OVER ALL BETTER NOW ON REGULAR MEDICATION NOW','',NULL,0,0,5),(444,128,'2022-08-26 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVER ALL BETTER NOW \n','','2022-09-09 00:00:00',0,0,5),(445,150,'2022-09-30 00:00:00',2,'','','2022-10-28 00:00:00',0,0,0),(446,150,'2022-09-16 00:00:00',2,'NEW CASE','',NULL,0,0,5),(447,151,'2022-09-30 00:00:00',2,'new case','','2022-10-07 00:00:00',0,0,0),(448,149,'2022-09-30 00:00:00',0,'NEW CASE','','2022-10-14 00:00:00',0,0,0),(449,136,'2022-09-09 00:00:00',0,'ON REGULAR MEDICATION NOW ','','2022-12-02 00:00:00',0,0,5),(450,136,'2022-07-15 00:00:00',0,'OVERALL BETTER NOW ','',NULL,0,0,0),(451,136,'2022-07-08 00:00:00',0,'NEW CASE','',NULL,0,0,5),(452,148,'2022-09-30 00:00:00',0,'NEW CASE','','2022-10-07 00:00:00',0,0,0),(453,147,'2022-09-30 00:00:00',0,'NEW CASE','','2022-10-07 00:00:00',0,0,0),(454,146,'2022-09-02 00:00:00',2,'NEW CASE','',NULL,0,0,0),(455,145,'2022-08-19 00:00:00',2,'NEW CASE','',NULL,0,0,0),(456,145,'2022-08-26 00:00:00',2,'ON REGULAR MEDICATION NOW','','2022-10-07 00:00:00',0,0,5),(457,133,'2022-09-09 00:00:00',2,'ON REGULAR MEDICATION NOW \nOVERALL BETTER NOW\nSTABLE MOOD','','2022-11-04 00:00:00',0,0,5),(458,144,'2022-09-23 00:00:00',2,'','','2022-10-14 00:00:00',0,0,0),(459,143,'2022-09-30 00:00:00',2,'OVERALL BETTER\n','','2022-10-28 00:00:00',0,0,0),(460,117,'2022-03-25 00:00:00',2,'','',NULL,0,0,0),(461,117,'2022-05-05 00:00:00',2,'','',NULL,0,0,0),(462,117,'2022-08-12 00:00:00',2,'','',NULL,0,0,0),(463,117,'2022-08-28 00:00:00',2,'','','2022-10-21 00:00:00',0,0,0),(464,40,'2022-03-25 00:00:00',2,'','',NULL,0,0,0),(465,40,'2022-04-22 00:00:00',2,'','',NULL,0,0,0),(466,40,'2022-06-03 00:00:00',1,'','',NULL,0,0,0),(467,40,'2022-06-24 00:00:00',2,'','',NULL,0,0,0),(468,40,'2022-07-22 00:00:00',2,'','',NULL,8,0,0),(469,40,'2022-09-30 00:00:00',2,'TIREDNESS DUE TO MEDICINE\n','','2022-10-11 00:00:00',10,0,0),(470,122,'2022-10-07 00:00:00',0,'PSI NEEDED\n','PHONE FOLLOW-UP','2022-11-04 00:00:00',8,0,0),(471,83,'2022-10-07 00:00:00',0,'THYROID MEDICINE GAVE FOR 14 DAYS','','2022-10-21 00:00:00',8,0,0),(472,90,'2022-10-07 00:00:00',0,'NOT TAKING MEDICINE','PHONE FOLLOW-UP NEEDED','2022-11-04 00:00:00',8,0,0),(473,2,'2022-10-07 00:00:00',0,'CONITNUING SAME MEDICINE','','2022-10-21 00:00:00',8,0,0),(474,40,'2022-10-07 00:00:00',0,'NO PROPER MEDICATION\nNEED VOLUNTEER SUPPORT','','2022-11-11 00:00:00',8,0,0),(475,40,'2022-10-07 00:00:00',0,'NO PROPER MEDICATION\nNEED VOLUNTEER SUPPORT','','2022-11-11 00:00:00',8,0,0),(476,105,'2022-10-07 00:00:00',0,'HAD SEIZURE SO REDUCED DOSE OF MEDICINE\n','','2022-10-14 00:00:00',8,0,0),(477,100,'2022-10-07 00:00:00',0,'STABLED MENTAL CONDITION','\n','2022-10-18 00:00:00',8,0,0),(478,134,'2022-10-07 00:00:00',0,'','','2022-11-04 00:00:00',8,0,0),(479,21,'2022-10-07 00:00:00',2,'NEED HOME VISIT\nIMPROVED\nMOTHER UNDERSTAND THE SERIOUSNESS OF THE ISSUE','HOME VISIT','2022-11-18 00:00:00',8,0,0),(480,153,'2022-08-26 00:00:00',2,'NEW CASE','',NULL,0,0,0),(481,153,'2022-09-02 00:00:00',2,'','',NULL,0,0,13),(482,153,'2022-10-07 00:00:00',2,'','','2022-11-04 00:00:00',0,0,13),(483,12,'2022-10-07 00:00:00',2,'','','2022-12-30 00:00:00',0,0,13),(484,27,'2022-10-07 00:00:00',2,'AFSATH CONTACTED DOCTOR','PHONE FOLLO-UP','2022-11-11 00:00:00',0,0,0),(485,148,'2022-10-07 00:00:00',2,'JULAX MEDICINE GAVE FOR 2 WEEK','','2022-10-21 00:00:00',0,0,13),(486,151,'2022-10-07 00:00:00',2,'IRREGULAR MEDICINE','\n','2022-10-21 00:00:00',0,0,13),(487,147,'2022-10-07 00:00:00',2,'STARTED MEDICINE','','2022-10-21 00:00:00',0,0,13),(488,87,'2022-10-07 00:00:00',2,'PSI DONE\n','','2022-10-14 00:00:00',10,0,0),(489,154,'2022-10-07 00:00:00',2,'PATIENT COMING AFTER 21 MAY 2021\nSTARTED MEDICINE AGAIN','','2022-10-21 00:00:00',0,0,13),(490,120,'2022-10-07 00:00:00',2,'HUSBAND IS SUPPORTIVE\nREDUCED SYMPTOMS','\n','2022-11-04 00:00:00',0,0,13),(491,84,'2022-10-07 00:00:00',2,'','','2022-12-02 00:00:00',0,0,13),(492,86,'2022-10-07 00:00:00',2,'PHYSICAL EXERCISE NEEDED','','2022-12-02 00:00:00',0,0,13),(493,40,'2022-08-26 00:00:00',2,'\n','',NULL,0,0,0),(494,37,'2022-01-07 00:00:00',2,'','',NULL,0,0,0),(495,37,'2022-01-21 00:00:00',2,'','',NULL,8,0,0),(496,37,'2022-02-25 00:00:00',1,'','',NULL,0,0,0),(497,37,'2022-06-03 00:00:00',1,'','',NULL,0,0,0),(498,37,'2022-08-26 00:00:00',1,'','','2022-10-21 00:00:00',0,0,0),(499,117,'2022-08-12 00:00:00',1,'','',NULL,8,0,0),(500,15,'2022-09-02 00:00:00',1,'','',NULL,0,0,0),(501,15,'2022-09-30 00:00:00',2,'','','2022-11-25 00:00:00',8,0,0),(502,84,'2022-02-18 00:00:00',2,'','',NULL,0,0,0),(503,84,'2022-03-25 00:00:00',1,'','',NULL,0,0,5),(504,84,'2022-04-01 00:00:00',2,'','',NULL,0,0,0),(505,84,'2022-04-08 00:00:00',1,'EARLY CONSULTATION \\\nMEDICINE IS THERE','PSI DONE',NULL,0,0,0),(506,84,'2022-05-13 00:00:00',1,'','',NULL,0,0,5),(507,84,'2022-06-10 00:00:00',2,'','',NULL,0,0,0),(508,84,'2022-08-05 00:00:00',1,'','',NULL,0,0,5),(509,128,'2022-09-09 00:00:00',1,'','',NULL,0,0,0),(510,128,'2022-09-30 00:00:00',2,'','',NULL,0,0,0),(511,83,'2022-03-25 00:00:00',1,'','',NULL,0,0,0),(512,83,'2022-04-01 00:00:00',2,'','',NULL,0,0,0),(513,83,'2022-04-08 00:00:00',1,'','',NULL,0,0,5),(514,83,'2022-05-13 00:00:00',1,'','',NULL,0,0,0),(515,83,'2022-06-10 00:00:00',2,'','',NULL,0,0,0),(516,83,'2022-06-24 00:00:00',2,'','',NULL,0,0,0),(517,83,'2022-06-24 00:00:00',2,'','',NULL,0,0,0),(518,83,'2022-06-24 00:00:00',2,'','',NULL,0,0,0),(519,43,'2022-08-12 00:00:00',1,'','',NULL,0,0,0),(520,138,'2022-09-02 00:00:00',2,'','',NULL,0,0,0),(521,138,'2022-09-16 00:00:00',0,'','','2022-11-11 00:00:00',0,0,5),(522,32,'2022-05-13 00:00:00',1,'','',NULL,0,0,0),(523,32,'2022-06-03 00:00:00',1,'','',NULL,0,0,5),(524,32,'2022-07-08 00:00:00',1,'','',NULL,0,0,5),(525,32,'2022-08-19 00:00:00',2,'','','2022-10-14 00:00:00',0,0,0),(526,113,'2022-06-03 00:00:00',1,'','',NULL,0,0,0),(527,113,'2022-08-26 00:00:00',0,'','','2022-10-21 00:00:00',0,0,5),(528,33,'2022-06-03 00:00:00',1,'','',NULL,0,0,5),(529,33,'2022-08-26 00:00:00',1,'','','2022-10-21 00:00:00',0,0,13),(530,122,'2022-04-29 00:00:00',1,'','',NULL,0,0,0),(531,122,'2022-08-05 00:00:00',1,'','',NULL,0,0,5),(532,77,'2022-04-01 00:00:00',2,'','',NULL,0,0,0),(533,77,'2022-05-27 00:00:00',0,'','',NULL,0,0,0),(534,77,'2022-07-29 00:00:00',1,'','',NULL,0,0,0),(535,77,'2022-09-30 00:00:00',1,'','','2022-10-28 00:00:00',0,0,0),(536,101,'2022-06-03 00:00:00',1,'','',NULL,0,0,0),(537,101,'2022-09-16 00:00:00',1,'','','2022-12-09 00:00:00',0,0,0),(538,90,'2022-04-15 00:00:00',2,'','',NULL,0,0,0),(539,5,'2022-08-05 00:00:00',0,'','',NULL,0,0,0),(540,5,'2022-10-14 00:00:00',2,'IMPROVED','','2023-01-06 00:00:00',0,0,0),(541,129,'2022-04-29 00:00:00',1,'','',NULL,8,0,0),(542,129,'2022-05-05 00:00:00',2,'','',NULL,0,0,0),(543,129,'2022-05-20 00:00:00',2,'','',NULL,0,0,0),(544,129,'2022-06-17 00:00:00',2,'','',NULL,0,0,0),(545,129,'2022-07-15 00:00:00',0,'','',NULL,0,0,0),(546,10,'2022-07-29 00:00:00',2,'','','2022-10-21 00:00:00',0,0,0),(547,8,'2022-04-15 00:00:00',2,'','',NULL,0,0,0),(548,8,'2022-07-08 00:00:00',1,'','',NULL,0,0,0),(549,8,'2022-08-19 00:00:00',2,'','',NULL,0,0,0),(550,8,'2022-10-14 00:00:00',2,'','','2023-01-06 00:00:00',0,0,0),(551,32,'2022-09-16 00:00:00',2,'','','2022-11-11 00:00:00',8,0,5),(552,32,'2022-10-14 00:00:00',2,'psi done','','2022-12-09 00:00:00',0,0,13),(553,6,'2022-02-18 00:00:00',1,'','',NULL,0,0,5),(554,6,'2022-03-04 00:00:00',2,'','',NULL,0,0,0),(555,6,'2022-10-14 00:00:00',2,'','',NULL,0,0,13),(556,145,'2022-10-14 00:00:00',2,'','','2022-11-11 00:00:00',0,0,0),(557,87,'2022-10-14 00:00:00',2,'','','2022-12-09 00:00:00',0,0,0),(558,41,'2022-10-14 00:00:00',2,'','','2023-01-06 00:00:00',8,0,0),(559,105,'2022-10-14 00:00:00',2,'','','2022-11-11 00:00:00',0,0,0),(560,154,'2022-10-14 00:00:00',2,'','','2022-11-11 00:00:00',0,0,0),(561,150,'2022-10-14 00:00:00',2,'','','2022-11-11 00:00:00',0,0,0),(562,14,'2022-10-14 00:00:00',2,'','','2022-12-23 00:00:00',0,0,0),(563,149,'2022-10-14 00:00:00',2,'','','2022-11-11 00:00:00',0,0,0),(564,144,'2022-10-14 00:00:00',2,'','','2022-11-11 00:00:00',0,0,0),(565,148,'2022-10-14 00:00:00',2,'','','2022-10-28 00:00:00',8,0,0),(566,129,'2022-08-19 00:00:00',0,'','',NULL,0,0,0),(567,129,'2022-09-09 00:00:00',1,'','',NULL,8,0,0),(568,129,'2022-10-14 00:00:00',2,'','','2022-12-09 00:00:00',8,0,0),(569,155,'2022-10-21 00:00:00',2,'','','2022-10-28 00:00:00',8,0,13),(570,24,'2022-10-21 00:00:00',2,'','','2022-11-25 00:00:00',8,0,13),(571,24,'2022-08-26 00:00:00',1,'','',NULL,0,0,0),(572,24,'2022-02-11 00:00:00',2,'','',NULL,0,0,0),(573,24,'2022-04-08 00:00:00',1,'','',NULL,0,0,0),(574,24,'2022-07-08 00:00:00',2,'','',NULL,0,0,0),(575,76,'2022-05-20 00:00:00',2,'','',NULL,0,0,0),(576,76,'2022-07-29 00:00:00',2,'','',NULL,0,0,0),(577,76,'2022-10-21 00:00:00',2,'','','2023-01-13 00:00:00',0,0,0),(578,132,'2022-05-27 00:00:00',2,'','',NULL,0,0,0),(579,132,'2022-06-03 00:00:00',2,'','',NULL,0,0,0),(580,132,'2022-08-26 00:00:00',2,'','',NULL,0,0,0),(581,132,'2022-10-21 00:00:00',2,'','','2022-11-18 00:00:00',0,0,0),(582,2,'2022-10-21 00:00:00',2,'','','2022-11-25 00:00:00',8,0,13),(583,2,'2022-09-02 00:00:00',2,'','',NULL,0,0,0),(584,104,'2022-08-26 00:00:00',2,'','',NULL,0,0,0),(585,104,'2022-10-21 00:00:00',2,'','','2022-11-25 00:00:00',0,0,0),(586,137,'2022-07-29 00:00:00',2,'','',NULL,8,0,0),(587,137,'2022-08-12 00:00:00',2,'','',NULL,0,0,0),(588,137,'2022-08-19 00:00:00',2,'','',NULL,0,0,0),(589,137,'2022-08-26 00:00:00',2,'','',NULL,0,0,0),(590,137,'2022-10-21 00:00:00',2,'','','2022-11-04 00:00:00',8,0,0),(591,148,'2022-10-21 00:00:00',2,'','','2022-11-04 00:00:00',8,0,0),(592,112,'2022-02-11 00:00:00',2,'','',NULL,8,0,0),(593,112,'2022-03-18 00:00:00',2,'','',NULL,0,0,0),(594,112,'2022-04-15 00:00:00',2,'','',NULL,8,0,0),(595,112,'2022-08-19 00:00:00',2,'','',NULL,8,0,0),(596,112,'2022-07-29 00:00:00',2,'','',NULL,8,0,0),(597,112,'2022-10-21 00:00:00',2,'','','2022-11-11 00:00:00',0,0,13),(598,106,'2022-04-01 00:00:00',2,'','',NULL,0,0,0),(599,106,'2022-05-06 00:00:00',2,'','',NULL,0,0,0),(600,106,'2022-08-26 00:00:00',2,'','',NULL,0,0,0),(601,106,'2022-09-09 00:00:00',2,'','',NULL,0,0,0),(602,106,'2022-10-21 00:00:00',2,'IRREGULAR MEDICINE','',NULL,0,0,0),(603,132,'2022-06-17 00:00:00',2,'','',NULL,8,0,0),(604,132,'2022-07-15 00:00:00',2,'','',NULL,0,0,0),(605,147,'2022-10-21 00:00:00',2,'','','2022-11-11 00:00:00',0,0,0),(606,10,'2022-10-21 00:00:00',2,'','','2023-01-13 00:00:00',0,0,13),(607,86,'2022-05-20 00:00:00',2,'','',NULL,0,0,0),(608,86,'2022-07-15 00:00:00',2,'','',NULL,8,0,0),(609,126,'2022-07-22 00:00:00',2,'','',NULL,8,0,0),(610,126,'2022-09-09 00:00:00',2,'','',NULL,0,0,0),(611,126,'2022-10-21 00:00:00',2,'','','2022-12-09 00:00:00',8,0,13),(612,156,'2022-10-14 00:00:00',2,'MEDICINE FOR STOPPING SMOKING \n','',NULL,0,0,0),(613,44,'2022-05-27 00:00:00',2,'','',NULL,0,0,0),(614,44,'2022-08-26 00:00:00',2,'','',NULL,8,0,0),(615,44,'2022-10-21 00:00:00',2,'','','2023-01-13 00:00:00',0,0,13),(616,113,'2022-10-21 00:00:00',2,'','','2022-11-25 00:00:00',8,0,13),(617,3,'2022-03-18 00:00:00',2,'','',NULL,8,0,0),(618,3,'2022-06-03 00:00:00',2,'','',NULL,0,0,0),(619,3,'2022-08-26 00:00:00',2,'','',NULL,0,0,0),(620,3,'2022-10-21 00:00:00',2,'','','2022-11-04 00:00:00',0,0,13),(621,33,'2022-10-21 00:00:00',2,'','','2022-11-25 00:00:00',0,0,13),(622,37,'2022-10-21 00:00:00',2,'','','2022-12-09 00:00:00',0,0,13),(623,31,'2022-08-26 00:00:00',2,'','',NULL,0,0,13),(624,31,'2022-10-21 00:00:00',2,'','','2023-01-13 00:00:00',0,0,13),(625,31,'2022-07-29 00:00:00',2,'','',NULL,0,0,0),(626,23,'2022-10-21 00:00:00',2,'','','2022-11-11 00:00:00',0,0,13),(627,130,'2022-10-28 00:00:00',2,'patient\'s son attended','','2022-12-23 00:00:00',0,0,0),(628,130,'2022-10-28 00:00:00',2,'\n\n\n\n','',NULL,0,0,0),(629,139,'2022-10-28 00:00:00',2,'','','2022-12-23 00:00:00',0,0,0),(630,139,'2022-08-05 00:00:00',2,'','',NULL,0,0,0),(631,139,'2022-08-12 00:00:00',2,'','',NULL,0,0,0),(632,139,'2022-08-19 00:00:00',2,'','',NULL,0,0,0),(633,139,'2022-09-09 00:00:00',2,'','',NULL,0,0,0),(634,139,'2022-09-16 00:00:00',2,'','',NULL,0,0,0),(635,139,'2022-09-30 00:00:00',2,'','',NULL,0,0,0),(636,130,'2022-06-03 00:00:00',2,'','',NULL,0,0,0),(637,87,'2022-04-15 00:00:00',2,'','',NULL,0,0,0),(638,87,'2022-06-10 00:00:00',2,'','',NULL,0,0,0),(639,87,'2022-08-05 00:00:00',2,'','',NULL,0,0,0),(640,87,'2022-10-28 00:00:00',2,'','','2022-12-09 00:00:00',0,0,0),(641,83,'2022-10-28 00:00:00',2,'','','2022-12-23 00:00:00',0,0,0),(642,130,'2022-06-10 00:00:00',2,'','',NULL,0,0,0),(643,130,'2022-06-24 00:00:00',2,'','',NULL,0,0,0),(644,130,'2022-07-22 00:00:00',2,'','',NULL,0,0,0),(645,130,'2022-08-19 00:00:00',2,'','',NULL,8,0,0),(646,130,'2022-10-28 00:00:00',2,'','',NULL,0,0,0),(647,20,'2022-10-28 00:00:00',2,'','','2023-01-20 00:00:00',0,0,0),(648,20,'2022-09-09 00:00:00',2,'','',NULL,0,0,0),(649,11,'2022-03-04 00:00:00',2,'','',NULL,8,0,0),(650,11,'2022-03-11 00:00:00',1,'','',NULL,0,0,0),(651,11,'2022-03-25 00:00:00',2,'','',NULL,0,0,0),(652,11,'2022-04-22 00:00:00',1,'','',NULL,8,0,0),(653,11,'2022-05-20 00:00:00',2,'','',NULL,8,0,0),(654,11,'2022-07-22 00:00:00',1,'','',NULL,8,0,0),(655,11,'2022-09-16 00:00:00',1,'','','2022-11-11 00:00:00',8,0,0),(656,11,'2022-10-28 00:00:00',2,'','','2022-12-09 00:00:00',8,0,0),(657,80,'2022-03-18 00:00:00',2,'','',NULL,8,0,0),(658,80,'2022-06-10 00:00:00',2,'','',NULL,8,0,0),(659,80,'2022-07-01 00:00:00',1,'','',NULL,0,0,0),(660,80,'2022-07-08 00:00:00',2,'','',NULL,8,0,0),(661,80,'2022-09-02 00:00:00',2,'','',NULL,0,0,0),(662,80,'2022-10-28 00:00:00',2,'','','2022-12-23 00:00:00',8,0,0),(663,102,'2022-04-15 00:00:00',2,'','',NULL,8,0,0),(664,102,'2022-06-10 00:00:00',2,'','',NULL,8,0,0),(665,102,'2022-08-12 00:00:00',2,'','',NULL,8,0,0),(666,102,'2022-09-30 00:00:00',2,'','',NULL,8,0,0),(667,102,'2022-10-28 00:00:00',2,'','','2022-12-09 00:00:00',8,0,0),(668,77,'2022-10-28 00:00:00',2,'','','2022-12-09 00:00:00',0,0,0),(669,124,'2022-04-01 00:00:00',2,'','',NULL,8,0,0),(670,124,'2022-04-15 00:00:00',2,'','',NULL,8,0,0),(671,124,'2022-05-13 00:00:00',2,'','',NULL,0,0,0),(672,124,'2022-06-10 00:00:00',2,'','',NULL,0,0,0),(673,124,'2022-09-30 00:00:00',2,'','',NULL,0,0,0),(674,124,'2022-10-28 00:00:00',2,'consuming alcohol','','2022-12-23 00:00:00',0,0,0),(675,16,'2022-05-27 00:00:00',2,'','',NULL,0,0,0),(676,16,'2022-06-17 00:00:00',2,'','',NULL,0,0,0),(677,16,'2022-07-15 00:00:00',2,'','',NULL,0,0,0),(678,16,'2022-07-29 00:00:00',2,'','',NULL,0,0,0),(679,16,'2022-09-09 00:00:00',2,'','',NULL,0,0,0),(680,16,'2022-10-28 00:00:00',2,'','','2022-11-25 00:00:00',8,0,0),(681,151,'2022-10-21 00:00:00',2,'','',NULL,0,0,0),(682,151,'2022-10-28 00:00:00',2,'psi done','','2022-11-11 00:00:00',0,0,0),(683,13,'2022-04-29 00:00:00',2,'','',NULL,8,0,0),(684,13,'2022-05-27 00:00:00',2,'','',NULL,0,0,0),(685,13,'2022-06-17 00:00:00',2,'','',NULL,0,0,0),(686,13,'2022-07-01 00:00:00',2,'','',NULL,0,0,0),(687,13,'2022-07-15 00:00:00',2,'','',NULL,0,0,0),(688,13,'2022-07-29 00:00:00',2,'','',NULL,0,0,0),(689,13,'2022-10-28 00:00:00',2,'','','2022-11-25 00:00:00',0,0,0),(690,35,'2022-05-20 00:00:00',2,'','',NULL,8,0,0),(691,35,'2022-07-29 00:00:00',2,'','',NULL,8,0,0),(692,35,'2022-10-21 00:00:00',2,'','','2023-01-13 00:00:00',0,0,0),(693,25,'2022-03-25 00:00:00',2,'','',NULL,0,0,0),(694,25,'2022-05-20 00:00:00',2,'','',NULL,0,0,0),(695,25,'2022-07-29 00:00:00',2,'','',NULL,8,0,0),(696,25,'2022-10-21 00:00:00',2,'','','2023-01-13 00:00:00',8,0,0),(697,101,'2022-10-28 00:00:00',2,'','phone follow-up needed','2022-11-11 00:00:00',0,0,0),(698,147,'2022-11-04 00:00:00',2,'','','2022-11-11 00:00:00',0,0,13),(699,117,'2022-11-04 00:00:00',2,'','','2022-12-30 00:00:00',0,0,14),(700,9,'2022-03-04 00:00:00',2,'','',NULL,0,0,0),(701,9,'2022-04-22 00:00:00',2,'','',NULL,0,0,0),(702,9,'2022-05-20 00:00:00',2,'','',NULL,0,0,0),(703,9,'2022-07-15 00:00:00',2,'','',NULL,0,0,0),(704,9,'2022-09-09 00:00:00',2,'','',NULL,0,0,0),(705,9,'2022-11-04 00:00:00',2,'','','2023-01-27 00:00:00',0,0,0),(706,1,'2022-05-13 00:00:00',2,'','',NULL,0,0,0),(707,1,'2022-07-08 00:00:00',2,'','',NULL,0,0,0),(708,1,'2022-11-04 00:00:00',2,'','','2022-12-16 00:00:00',0,0,14),(709,7,'2022-02-25 00:00:00',2,'','',NULL,0,0,0),(710,7,'2022-04-22 00:00:00',2,'','',NULL,0,0,0),(711,7,'2022-06-17 00:00:00',2,'','',NULL,0,0,0),(712,7,'2022-08-12 00:00:00',2,'','',NULL,0,0,0),(713,7,'2022-11-04 00:00:00',2,'','','2022-12-30 00:00:00',0,0,14),(714,81,'2022-06-03 00:00:00',2,'','',NULL,0,0,0),(715,81,'2022-07-29 00:00:00',2,'','',NULL,0,0,0),(716,81,'2022-08-12 00:00:00',2,'','',NULL,0,0,0),(717,81,'2022-11-04 00:00:00',2,'','','2022-12-30 00:00:00',0,0,14),(718,134,'2022-07-22 00:00:00',2,'','',NULL,0,0,0),(719,134,'2022-07-29 00:00:00',2,'','',NULL,0,0,0),(720,134,'2022-08-12 00:00:00',2,'','',NULL,0,0,0),(721,134,'2022-08-19 00:00:00',2,'','',NULL,0,0,0),(722,134,'2022-09-02 00:00:00',2,'','',NULL,0,0,0),(723,134,'2022-11-04 00:00:00',2,'','','2022-12-16 00:00:00',0,0,0),(724,120,'2022-11-04 00:00:00',2,'psi continues','','2022-12-16 00:00:00',0,0,14),(725,154,'2022-11-04 00:00:00',2,'','','2022-12-02 00:00:00',0,0,14),(726,137,'2022-11-04 00:00:00',2,'','','2022-12-02 00:00:00',0,0,14),(727,17,'2022-05-20 00:00:00',2,'','',NULL,0,0,14),(728,17,'2022-07-29 00:00:00',2,'','',NULL,0,0,0),(729,17,'2022-11-04 00:00:00',2,'','','2022-12-16 00:00:00',0,0,14),(730,157,'2022-11-04 00:00:00',2,'','','2022-11-11 00:00:00',0,0,14),(731,148,'2022-11-04 00:00:00',2,'','','2022-12-02 00:00:00',0,0,14),(732,133,'2022-11-04 00:00:00',2,'','','2022-11-25 00:00:00',0,0,14),(733,87,'2022-11-04 00:00:00',2,'','','2022-12-09 00:00:00',0,0,14),(734,122,'2022-11-04 00:00:00',2,'ADDED TO REHABILITATION','','2022-11-18 00:00:00',0,0,14),(735,94,'2022-08-12 00:00:00',2,'','',NULL,0,0,14),(736,94,'2022-11-04 00:00:00',2,'','','2022-12-30 00:00:00',0,0,0),(737,3,'2022-11-04 00:00:00',2,'','','2022-12-02 00:00:00',0,0,14),(738,153,'2022-11-04 00:00:00',2,'','','2022-12-16 00:00:00',0,0,14),(739,39,'2022-11-11 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(740,39,'2022-08-19 00:00:00',2,'','',NULL,0,0,14),(741,156,'2022-11-11 00:00:00',2,'bupropion sr 150 mg ','','2022-12-02 00:00:00',0,0,14),(742,151,'2022-11-11 00:00:00',2,'','','2022-11-25 00:00:00',0,0,14),(743,101,'2022-11-11 00:00:00',2,'','','2023-01-06 00:00:00',0,0,14),(744,145,'2022-11-11 00:00:00',2,'','','2023-01-06 00:00:00',0,0,14),(745,19,'2022-11-11 00:00:00',2,'','','2023-01-06 00:00:00',0,0,14),(746,19,'2022-09-16 00:00:00',2,'','',NULL,0,0,14),(747,22,'2022-09-16 00:00:00',2,'','',NULL,0,0,14),(748,22,'2022-11-11 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(749,48,'2022-09-16 00:00:00',2,'','',NULL,0,0,7),(750,48,'2022-11-11 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(751,27,'2022-11-11 00:00:00',2,'','','2023-01-06 00:00:00',0,0,14),(752,40,'2022-11-11 00:00:00',2,'','','2022-12-23 00:00:00',0,0,14),(753,108,'2022-11-11 00:00:00',2,'','','2023-01-06 00:00:00',0,0,14),(754,108,'2022-09-30 00:00:00',2,'','',NULL,0,0,13),(755,133,'2022-11-11 00:00:00',2,'','','2023-01-06 00:00:00',0,0,13),(756,23,'2022-11-11 00:00:00',2,'','','2022-12-09 00:00:00',0,0,14),(757,112,'2022-11-11 00:00:00',2,'','','2023-01-06 00:00:00',0,0,14),(758,143,'2022-11-11 00:00:00',2,'','','2023-01-06 00:00:00',0,0,14),(759,143,'2022-09-16 00:00:00',2,'','',NULL,0,0,14),(760,157,'2022-11-11 00:00:00',2,'','','2022-12-02 00:00:00',0,0,14),(761,105,'2022-11-11 00:00:00',2,'','','2022-12-09 00:00:00',0,0,14),(762,138,'2022-11-11 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(763,114,'2022-08-12 00:00:00',2,'','',NULL,0,0,0),(764,114,'2022-11-11 00:00:00',2,'','','2023-01-06 00:00:00',0,0,14),(765,128,'2022-11-11 00:00:00',2,'','','2023-01-06 00:00:00',0,0,14),(766,6,'2022-11-11 00:00:00',2,'','','2022-12-09 00:00:00',0,0,14),(767,160,'2022-11-11 00:00:00',2,'','','2022-11-25 00:00:00',0,0,14),(768,158,'2022-11-11 00:00:00',2,'','','2022-11-25 00:00:00',0,0,14),(769,144,'2022-11-11 00:00:00',2,'','','2023-01-06 00:00:00',0,0,14),(770,90,'2022-11-11 00:00:00',2,'','','2023-01-06 00:00:00',0,0,14),(771,159,'2022-11-04 00:00:00',2,'','','2022-12-02 00:00:00',0,0,14),(772,159,'2022-11-11 00:00:00',2,'','','2022-12-02 00:00:00',0,0,14),(773,147,'2022-11-11 00:00:00',2,'','','2022-11-25 00:00:00',0,0,14),(774,52,'2022-11-11 00:00:00',2,'','','2023-01-20 00:00:00',0,0,14),(775,150,'2022-11-11 00:00:00',2,'','','2023-01-06 00:00:00',0,0,14),(776,147,'2022-11-18 00:00:00',2,'','','2022-11-25 00:00:00',0,0,14),(777,161,'2022-11-18 00:00:00',2,'','','2022-11-25 00:00:00',0,0,14),(778,132,'2022-11-18 00:00:00',2,'','','2022-12-30 00:00:00',0,0,14),(779,100,'2022-11-18 00:00:00',2,'','','2022-12-30 00:00:00',0,0,14),(780,21,'2022-11-18 00:00:00',2,'','','2023-02-10 00:00:00',0,0,14),(781,122,'2022-11-18 00:00:00',2,'','','2022-12-30 00:00:00',0,0,14),(782,161,'2022-11-25 00:00:00',2,'','','2022-12-16 00:00:00',0,0,14),(783,104,'2022-11-25 00:00:00',2,'','','2023-01-20 00:00:00',0,0,14),(784,2,'2022-11-25 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(785,160,'2022-11-25 00:00:00',2,'','','2022-12-16 00:00:00',0,0,14),(786,133,'2022-11-25 00:00:00',2,'','','2023-01-20 00:00:00',0,0,14),(787,162,'2022-11-25 00:00:00',2,'','','2022-12-09 00:00:00',0,0,14),(788,148,'2022-11-25 00:00:00',2,'','','2022-12-23 00:00:00',0,0,14),(789,140,'2022-11-25 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(790,89,'2022-11-25 00:00:00',2,'','','2023-02-17 00:00:00',0,0,14),(791,33,'2022-11-25 00:00:00',2,'','','2023-02-17 00:00:00',0,0,14),(792,12,'2022-11-25 00:00:00',2,'','','2022-12-30 00:00:00',0,0,14),(793,141,'2022-09-30 00:00:00',2,'','','2023-02-17 00:00:00',0,0,14),(794,141,'2022-11-25 00:00:00',2,'','','2023-02-17 00:00:00',0,0,14),(795,29,'2022-11-25 00:00:00',2,'','','2022-12-02 00:00:00',0,0,14),(796,158,'2022-11-25 00:00:00',2,'','','2022-12-23 00:00:00',0,0,14),(797,147,'2022-11-25 00:00:00',2,'','','2022-12-23 00:00:00',0,0,14),(798,151,'2022-11-25 00:00:00',2,'','','2022-12-23 00:00:00',0,0,14),(799,126,'2022-12-02 00:00:00',2,'','','2023-01-13 00:00:00',0,0,14),(800,113,'2022-12-02 00:00:00',2,'','','2023-03-24 00:00:00',0,0,14),(801,110,'2022-12-02 00:00:00',2,'','','2023-01-13 00:00:00',0,0,14),(802,157,'2022-12-02 00:00:00',2,'','','2022-12-30 00:00:00',0,0,14),(803,7,'2022-12-02 00:00:00',2,'','','2023-02-24 00:00:00',0,0,14),(804,154,'2022-12-02 00:00:00',2,'','','2023-02-24 00:00:00',0,0,14),(805,16,'2022-12-02 00:00:00',2,'','','2023-01-27 00:00:00',0,0,14),(806,86,'2022-12-02 00:00:00',2,'','','2023-02-24 00:00:00',0,0,14),(807,136,'2022-12-02 00:00:00',2,'','','2023-02-24 00:00:00',0,0,14),(808,85,'2022-12-02 00:00:00',2,'','','2023-02-24 00:00:00',0,0,14),(809,36,'2022-12-02 00:00:00',2,'','','2022-12-30 00:00:00',0,0,14),(810,3,'2022-12-02 00:00:00',2,'','','2023-03-24 00:00:00',0,0,14),(811,6,'2022-12-02 00:00:00',2,'','','2022-12-23 00:00:00',0,0,14),(812,163,'2022-12-02 00:00:00',2,'','','2022-12-09 00:00:00',0,0,14),(813,163,'2022-12-09 00:00:00',2,'','','2022-12-30 00:00:00',0,0,14),(814,11,'2022-12-09 00:00:00',2,'','','2023-01-20 00:00:00',0,0,14),(815,139,'2022-12-09 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(816,77,'2022-12-09 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(817,87,'2022-12-09 00:00:00',2,'','','2023-01-20 00:00:00',0,0,14),(818,102,'2022-12-09 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(819,23,'2022-12-09 00:00:00',2,'','','2023-01-20 00:00:00',0,0,14),(820,112,'2022-12-09 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(821,37,'2022-12-09 00:00:00',2,'','','2023-03-03 00:00:00',0,0,14),(822,29,'2022-12-09 00:00:00',2,'','','2022-12-23 00:00:00',0,0,14),(823,24,'2022-12-09 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(824,32,'2022-12-09 00:00:00',2,'','','2023-03-03 00:00:00',0,0,14),(825,147,'2022-12-09 00:00:00',2,'','','2023-01-06 00:00:00',0,0,14),(826,105,'2022-12-09 00:00:00',2,'','','2022-12-23 00:00:00',0,0,14),(827,46,'2022-12-09 00:00:00',2,'','','2023-03-03 00:00:00',0,0,14),(828,162,'2022-12-09 00:00:00',2,'','','2023-01-06 00:00:00',0,0,14),(829,129,'2022-12-09 00:00:00',2,'','','2023-03-03 00:00:00',0,0,14),(830,1,'2022-12-16 00:00:00',2,'','','2023-01-13 00:00:00',0,0,14),(831,134,'2022-12-16 00:00:00',2,'','','2023-01-27 00:00:00',0,0,14),(832,153,'2022-12-16 00:00:00',2,'','','2023-01-27 00:00:00',0,0,14),(833,17,'2022-12-16 00:00:00',2,'','','2023-02-10 00:00:00',0,0,14),(834,160,'2022-12-16 00:00:00',2,'','','2023-01-06 00:00:00',0,0,14),(835,120,'2022-12-16 00:00:00',2,'','','2023-03-10 00:00:00',0,0,14),(836,164,'2022-12-23 00:00:00',2,'','','2023-01-13 00:00:00',0,0,14),(837,164,'2022-12-23 00:00:00',2,'','',NULL,0,0,14),(838,161,'2022-12-23 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(839,31,'2022-12-23 00:00:00',2,'','',NULL,0,0,14),(840,14,'2022-12-23 00:00:00',2,'','','2023-03-17 00:00:00',0,0,14),(841,50,'2022-09-30 00:00:00',2,'','',NULL,0,0,13),(842,50,'2022-04-15 00:00:00',2,'','',NULL,0,0,13),(843,50,'2022-12-23 00:00:00',2,'','','2023-03-17 00:00:00',0,0,14),(844,148,'2022-12-23 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(845,40,'2022-12-23 00:00:00',2,'','','2023-03-03 00:00:00',0,0,14),(846,4,'2022-09-30 00:00:00',2,'','',NULL,0,0,14),(847,4,'2022-12-23 00:00:00',2,'','','2023-03-17 00:00:00',0,0,14),(848,151,'2022-12-23 00:00:00',2,'','','2023-01-20 00:00:00',0,0,14),(849,105,'2022-12-23 00:00:00',2,'','',NULL,0,0,14),(850,158,'2022-12-23 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(851,124,'2022-12-23 00:00:00',2,'','','2023-03-03 00:00:00',0,0,14),(852,80,'2022-12-23 00:00:00',2,'','','2023-03-17 00:00:00',0,0,14),(853,6,'2022-12-23 00:00:00',2,'','','2023-01-27 00:00:00',0,0,14),(854,117,'2022-12-30 00:00:00',2,'','','2023-03-24 00:00:00',0,0,14),(855,157,'2022-12-30 00:00:00',2,'','','2023-02-10 00:00:00',0,0,14),(856,12,'2022-12-30 00:00:00',2,'','','2023-04-21 00:00:00',0,0,14),(857,81,'2022-12-30 00:00:00',2,'','','2023-04-21 00:00:00',0,0,14),(858,132,'2022-12-30 00:00:00',2,'','','2023-01-27 00:00:00',0,0,14),(859,100,'2022-12-30 00:00:00',2,'','','2023-03-24 00:00:00',0,0,14),(860,36,'2022-12-30 00:00:00',2,'','','2023-02-10 00:00:00',0,0,14),(861,126,'2023-01-06 00:00:00',2,'','','2023-03-03 00:00:00',0,0,14),(862,143,'2023-01-06 00:00:00',2,'','','2023-03-31 00:00:00',0,0,14),(863,160,'2023-01-06 00:00:00',2,'','','2023-02-17 00:00:00',0,0,14),(864,162,'2023-01-06 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(865,94,'2023-01-06 00:00:00',2,'','','2023-03-31 00:00:00',0,0,14),(866,8,'2023-01-06 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(867,105,'2023-01-06 00:00:00',2,'','','2023-01-20 00:00:00',0,0,14),(868,41,'2023-01-06 00:00:00',2,'','','2023-03-31 00:00:00',0,0,14),(869,145,'2023-01-06 00:00:00',2,'','','2023-03-31 00:00:00',0,0,14),(870,83,'2023-01-06 00:00:00',2,'','','2023-03-31 00:00:00',0,0,14),(871,114,'2023-01-06 00:00:00',0,'','','2023-03-03 00:00:00',0,0,14),(872,114,'2023-01-06 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(873,5,'2023-01-06 00:00:00',2,'','','2023-03-31 00:00:00',0,0,14),(874,101,'2023-01-06 00:00:00',2,'','','2023-03-31 00:00:00',0,0,14),(875,108,'2023-01-06 00:00:00',2,'','','2023-03-31 00:00:00',0,0,14),(876,128,'2023-01-06 00:00:00',2,'','','2023-03-03 00:00:00',0,0,14),(877,27,'2023-01-06 00:00:00',2,'','','2023-03-03 00:00:00',0,0,14),(878,167,'2023-01-06 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(879,167,'2022-12-23 00:00:00',2,'','',NULL,0,0,14),(880,165,'2023-01-06 00:00:00',2,'','','2023-01-20 00:00:00',0,0,14),(881,166,'2023-01-06 00:00:00',2,'','','2023-01-27 00:00:00',0,0,14),(882,147,'2023-01-06 00:00:00',2,'','','2023-02-03 00:00:00',0,0,14),(883,144,'2023-01-06 00:00:00',2,'','','2023-03-31 00:00:00',0,0,14),(884,151,'2023-01-06 00:00:00',2,'','','2023-01-20 00:00:00',0,0,14),(885,150,'2023-01-06 00:00:00',2,'','','2023-03-31 00:00:00',0,0,14),(886,132,'2023-01-13 00:00:00',2,'consulted by Dr. Sethu pediatric consultant ','','2023-01-20 00:00:00',0,0,14),(887,132,'2023-01-13 00:00:00',2,'','','2023-03-10 00:00:00',0,0,14),(888,112,'2023-01-13 00:00:00',2,'','','2023-01-20 00:00:00',0,0,14),(889,164,'2023-01-13 00:00:00',2,'','','2023-02-10 00:00:00',0,0,14),(890,90,'2023-01-13 00:00:00',2,'','','2023-02-24 00:00:00',0,0,14),(891,31,'2023-01-13 00:00:00',2,'','','2023-02-10 00:00:00',0,0,14),(892,10,'2023-01-13 00:00:00',2,'','','2023-02-24 00:00:00',0,0,14),(893,1,'2023-01-13 00:00:00',2,'','','2023-01-27 00:00:00',0,0,14),(894,110,'2023-01-13 00:00:00',2,'','','2023-01-27 00:00:00',0,0,14),(895,35,'2023-01-13 00:00:00',2,'','','2023-03-24 00:00:00',0,0,14),(896,25,'2023-01-13 00:00:00',2,'','','2023-03-24 00:00:00',0,0,14),(897,76,'2023-01-13 00:00:00',2,'','','2023-03-24 00:00:00',0,0,14),(898,20,'2023-01-13 00:00:00',2,'consulted by dr. sethu, continue the same medicine','','2023-01-20 00:00:00',0,0,14),(899,149,'2023-01-20 00:00:00',2,'','','2023-03-17 00:00:00',0,0,15),(900,165,'2023-01-20 00:00:00',2,'','','2023-02-17 00:00:00',0,0,15),(901,147,'2023-01-20 00:00:00',2,'','','2023-02-17 00:00:00',0,0,15),(902,123,'2023-01-20 00:00:00',2,'','','2023-04-14 00:00:00',0,0,15),(903,11,'2023-01-20 00:00:00',2,'','','2023-03-17 00:00:00',0,0,15),(904,133,'2023-01-20 00:00:00',2,'','','2023-03-17 00:00:00',0,0,15),(905,132,'2023-01-20 00:00:00',2,'','','2023-02-17 00:00:00',0,0,15),(906,148,'2023-01-20 00:00:00',2,'','','2023-03-17 00:00:00',0,0,15),(907,148,'2023-01-20 00:00:00',2,'','','2023-03-17 00:00:00',0,0,15),(908,154,'2023-01-20 00:00:00',2,'','','2023-03-17 00:00:00',0,0,15),(909,151,'2023-01-20 00:00:00',2,'','','2023-02-17 00:00:00',0,0,15),(910,52,'2023-01-20 00:00:00',2,'','','2023-04-14 00:00:00',0,0,15),(911,87,'2023-01-20 00:00:00',2,'','','2023-03-17 00:00:00',0,0,15),(912,20,'2023-01-20 00:00:00',2,'','','2023-02-17 00:00:00',0,0,15),(913,112,'2023-01-20 00:00:00',2,'','','2023-03-17 00:00:00',0,0,15),(914,104,'2023-01-20 00:00:00',2,'','','2023-04-14 00:00:00',0,0,15),(915,132,'2023-01-20 00:00:00',2,'','','2023-02-17 00:00:00',0,0,15),(916,147,'2023-01-27 00:00:00',2,'','','2023-02-17 00:00:00',0,0,14),(917,110,'2023-01-27 00:00:00',2,'','','2023-03-10 00:00:00',0,0,14),(918,166,'2023-01-27 00:00:00',2,'','','2023-02-17 00:00:00',0,0,14),(919,6,'2023-01-27 00:00:00',2,'','','2023-03-03 00:00:00',0,0,14),(920,134,'2023-01-27 00:00:00',2,'','','2023-03-10 00:00:00',0,0,14),(921,153,'2023-01-27 00:00:00',2,'','','2023-03-10 00:00:00',0,0,14),(922,1,'2023-01-27 00:00:00',2,'','','2023-03-24 00:00:00',0,0,14),(923,24,'2023-02-03 00:00:00',1,'','','2023-02-28 00:00:00',8,0,15),(924,102,'2023-02-03 00:00:00',1,'','','2023-04-28 00:00:00',0,0,15),(925,139,'2023-02-03 00:00:00',1,'','','2023-04-28 00:00:00',0,0,15),(926,48,'2023-02-03 00:00:00',1,'','','2023-04-28 00:00:00',0,0,15),(927,8,'2023-02-03 00:00:00',1,'','','2023-04-28 00:00:00',0,0,15),(928,147,'2023-02-03 00:00:00',1,'','','2023-02-17 00:00:00',0,0,15),(929,139,'2023-02-03 00:00:00',1,'','','2023-04-28 00:00:00',0,0,15),(930,24,'2023-02-03 00:00:00',1,'','','2023-04-28 00:00:00',0,0,15),(931,21,'2023-02-10 00:00:00',0,'','','2023-04-07 00:00:00',0,0,15),(932,122,'2023-02-10 00:00:00',1,'','','2023-05-05 00:00:00',0,0,15),(933,36,'2023-02-10 00:00:00',1,'','','2023-02-24 00:00:00',0,0,15),(934,17,'2023-02-10 00:00:00',1,'','','2023-05-05 00:00:00',0,0,15),(935,23,'2023-02-10 00:00:00',1,'','','2023-02-17 00:00:00',0,0,15),(936,31,'2023-02-10 00:00:00',1,'','','2023-04-07 00:00:00',0,0,15),(937,1,'2023-02-10 00:00:00',1,'','','2023-02-24 00:00:00',0,0,15),(938,157,'2023-02-10 00:00:00',1,'','','2023-02-24 00:00:00',0,0,15),(939,20,'2023-02-10 00:00:00',1,'','','2023-03-10 00:00:00',0,0,15);
/*!40000 ALTER TABLE `op` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opmedicine`
--

DROP TABLE IF EXISTS `opmedicine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opmedicine` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `OpId` int DEFAULT NULL,
  `MedicineId` int DEFAULT NULL,
  `Quantity` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2872 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opmedicine`
--

LOCK TABLES `opmedicine` WRITE;
/*!40000 ALTER TABLE `opmedicine` DISABLE KEYS */;
INSERT INTO `opmedicine` VALUES (1,39,12,28),(2,39,34,28),(3,39,46,28),(4,40,9,28),(5,41,35,42),(6,41,46,42),(7,42,5,28),(8,42,3,5),(9,43,21,28),(10,43,69,28),(11,43,23,56),(12,44,93,1),(13,44,35,14),(14,45,38,28),(15,45,39,28),(16,45,4,28),(17,46,71,56),(18,46,70,56),(19,47,83,168),(20,47,73,84),(21,47,46,256),(22,48,48,42),(23,48,47,42),(24,48,71,42),(25,48,46,84),(26,48,34,84),(27,49,12,42),(28,49,44,84),(29,49,65,84),(30,50,50,14),(31,50,48,5),(32,51,81,14),(33,51,83,14),(34,51,70,14),(35,51,46,28),(36,51,36,14),(37,51,76,14),(38,52,65,56),(39,52,70,14),(40,52,89,14),(41,53,57,42),(42,53,34,32),(43,54,33,21),(44,55,82,56),(45,55,83,56),(46,55,84,112),(47,55,69,56),(48,55,67,56),(49,56,69,49),(50,56,67,49),(51,56,83,49),(52,56,82,49),(53,56,46,49),(54,57,69,42),(55,57,12,42),(56,57,82,84),(57,58,35,74),(58,58,34,10),(59,58,33,32),(60,58,46,42),(61,59,49,42),(62,59,47,42),(63,59,9,42),(64,59,46,42),(65,60,83,56),(66,62,49,70),(67,62,48,70),(68,62,6,70),(69,63,59,73),(70,63,58,73),(71,63,71,73),(72,63,70,70),(73,63,24,73),(74,64,6,56),(75,66,81,112),(76,66,84,112),(77,66,59,56),(78,66,57,56),(79,67,83,112),(80,67,50,56),(81,67,48,56),(82,67,68,56),(83,67,69,23),(84,67,22,56),(85,69,81,28),(86,69,83,28),(87,69,46,84),(88,69,36,28),(89,69,76,28),(90,70,83,14),(91,70,68,7),(92,70,21,7),(93,70,46,7),(94,72,35,14),(95,72,33,7),(96,72,46,7),(97,73,65,84),(98,73,70,21),(99,74,35,98),(100,74,33,49),(101,74,46,49),(102,75,49,56),(103,75,47,56),(104,75,9,56),(105,75,46,56),(106,76,81,112),(107,76,84,112),(108,76,59,56),(109,77,83,56),(110,77,82,56),(111,77,84,112),(112,77,69,56),(113,77,67,56),(114,77,76,112),(115,77,46,56),(116,78,49,84),(117,78,48,84),(118,78,6,84),(119,78,5,84),(120,79,57,56),(121,79,33,56),(122,80,47,56),(123,80,48,56),(124,80,20,56),(125,81,69,56),(126,81,67,56),(127,81,83,56),(128,81,82,56),(129,81,46,56),(130,82,83,112),(131,82,50,56),(132,82,48,56),(133,82,68,56),(134,82,67,56),(135,82,12,56),(136,83,35,56),(137,83,46,84),(138,83,83,56),(139,83,70,28),(140,83,71,28),(141,85,83,156),(142,85,26,117),(143,85,73,78),(144,85,46,234),(145,86,73,42),(146,86,72,42),(147,86,46,126),(148,86,83,84),(149,86,25,42),(150,86,26,42),(151,86,48,42),(152,87,12,56),(153,87,34,56),(154,87,46,56),(155,87,9,56),(156,89,83,112),(157,89,50,56),(158,89,48,56),(159,89,46,56),(160,91,83,112),(161,91,70,56),(162,92,49,112),(163,92,48,56),(164,92,36,56),(165,92,46,56),(166,92,82,56),(167,92,83,56),(168,93,36,28),(169,93,33,28),(170,93,49,56),(171,93,46,56),(172,93,11,1),(173,95,83,28),(174,95,82,14),(175,95,26,28),(176,95,46,42),(177,95,49,14),(178,95,48,28),(179,96,83,70),(180,96,35,35),(181,96,48,35),(182,96,50,35),(183,96,46,105),(184,97,82,42),(185,97,83,42),(186,97,36,84),(187,97,46,126),(188,98,48,42),(189,98,47,42),(190,98,71,42),(191,98,46,126),(192,98,34,84),(193,99,22,56),(194,99,33,28),(195,101,83,42),(196,101,68,21),(197,101,21,21),(198,101,46,21),(199,103,82,28),(200,103,83,28),(201,103,36,28),(202,103,33,28),(203,103,46,28),(204,104,71,42),(205,104,37,84),(206,104,36,28),(207,105,37,56),(208,106,82,42),(209,107,50,21),(210,107,48,21),(211,107,92,1),(212,107,11,1),(213,107,46,21),(214,108,92,3),(215,108,46,42),(216,108,47,21),(217,109,44,363),(218,109,36,168),(219,109,46,531),(220,109,72,168),(221,109,71,168),(222,109,62,168),(223,109,64,168),(224,109,47,168),(225,110,83,28),(226,110,26,28),(227,110,49,14),(228,110,48,14),(229,110,47,14),(230,111,35,56),(231,111,46,84),(232,111,83,56),(233,111,70,28),(234,111,71,28),(235,112,82,28),(236,112,83,14),(237,112,48,14),(238,112,50,14),(239,112,46,14),(240,113,65,42),(241,113,19,21),(242,113,20,42),(243,114,28,42),(244,114,46,28),(245,114,39,28),(246,115,50,56),(247,115,49,56),(248,115,34,112),(249,115,46,112),(250,115,11,2),(251,116,46,98),(252,116,45,98),(253,116,87,98),(254,116,81,98),(255,116,36,49),(256,116,4,49),(257,117,68,56),(258,117,69,56),(259,117,46,112),(260,117,83,56),(261,118,83,28),(262,118,48,14),(263,118,50,14),(264,118,10,42),(265,118,36,14),(266,118,30,28),(267,119,37,84),(268,119,81,56),(269,120,81,28),(270,120,12,14),(271,120,69,14),(272,120,67,14),(273,122,33,28),(274,123,83,112),(275,123,70,56),(276,124,83,112),(277,124,35,112),(278,124,33,56),(279,124,47,56),(280,124,46,168),(281,125,34,56),(282,125,46,56),(283,126,83,42),(284,126,68,42),(285,126,69,42),(286,126,46,126),(287,127,81,28),(288,127,83,28),(289,127,46,84),(290,127,34,28),(291,127,76,28),(292,127,68,28),(293,129,48,35),(294,129,50,35),(295,129,35,35),(296,129,83,70),(297,129,82,35),(298,129,46,140),(299,130,45,112),(300,130,33,56),(301,130,47,56),(302,130,48,56),(303,131,82,14),(304,131,35,7),(305,131,46,7),(306,132,11,1),(307,132,49,7),(308,132,92,1),(309,132,46,7),(310,133,10,42),(311,133,83,42),(312,133,49,42),(313,133,36,28),(314,133,37,42),(315,133,91,42),(316,134,82,112),(317,134,27,28),(318,135,83,56),(319,135,26,42),(320,135,49,28),(321,135,47,28),(322,135,48,28),(323,135,46,28),(324,136,47,63),(325,136,34,42),(326,136,36,42),(327,136,33,42),(328,137,11,1),(329,137,49,14),(330,137,92,1),(331,137,46,14),(332,138,46,28),(333,138,92,1),(334,139,81,56),(335,139,12,28),(336,139,67,28),(337,139,69,28),(338,140,5,21),(339,140,4,21),(340,141,11,1),(341,141,36,14),(342,141,46,28),(343,142,9,84),(344,142,8,84),(345,143,83,14),(346,143,82,7),(347,143,69,7),(348,143,12,7),(349,144,70,7),(350,144,71,7),(351,145,12,28),(352,145,34,28),(353,145,46,28),(354,145,9,28),(355,146,21,42),(356,146,44,42),(357,146,64,21),(358,147,73,42),(359,147,46,126),(360,147,83,84),(361,147,25,42),(362,147,26,42),(363,147,48,42),(364,149,92,1),(365,150,36,42),(366,150,48,42),(367,150,49,21),(368,150,89,11),(369,150,29,21),(370,150,83,42),(371,150,46,42),(372,151,83,28),(373,151,82,14),(374,151,26,14),(375,151,25,21),(376,151,46,42),(377,151,49,14),(378,151,48,14),(379,151,47,28),(380,152,50,14),(381,152,47,14),(382,152,83,28),(383,152,67,14),(384,152,68,14),(385,152,12,14),(386,153,43,168),(387,153,65,84),(388,153,70,84),(389,153,82,168),(390,154,83,84),(391,154,82,42),(392,154,34,42),(393,154,50,42),(394,154,48,63),(395,154,46,168),(396,155,83,84),(397,155,82,84),(398,155,84,168),(399,155,69,84),(400,155,67,84),(401,155,76,168),(402,155,46,168),(403,156,82,168),(404,156,27,42),(405,157,82,21),(406,157,83,21),(407,157,36,21),(408,157,46,63),(409,158,5,14),(410,158,4,14),(411,158,21,14),(412,158,69,14),(413,158,68,14),(414,158,35,14),(415,159,65,56),(416,159,70,28),(417,160,59,28),(418,160,70,7),(419,160,3,7),(420,160,68,14),(421,161,33,56),(422,162,4,21),(423,163,24,28),(424,163,58,56),(425,163,72,28),(426,164,34,7),(427,164,46,7),(428,165,81,21),(429,165,83,21),(430,165,70,21),(431,166,34,84),(432,166,46,84),(433,167,34,84),(434,167,35,84),(435,167,49,84),(436,167,46,968),(437,167,11,2),(438,168,46,42),(439,168,26,14),(440,168,25,21),(441,168,83,28),(442,168,49,14),(443,168,48,28),(444,168,47,14),(445,169,34,42),(446,169,35,84),(447,169,46,84),(448,169,48,42),(449,170,46,126),(450,170,82,42),(451,170,83,42),(452,170,68,84),(453,171,81,7),(454,171,83,7),(455,171,46,21),(456,171,71,7),(457,171,36,7),(458,172,67,42),(459,172,69,42),(460,172,83,42),(461,172,82,42),(462,172,46,42),(463,173,82,126),(464,173,33,42),(465,173,36,42),(466,173,46,42),(467,174,50,56),(468,174,49,56),(469,174,46,112),(470,174,34,112),(471,175,5,42),(472,175,4,42),(473,176,82,56),(474,176,83,56),(475,176,36,56),(476,176,48,56),(477,177,37,56),(478,178,49,56),(479,178,48,56),(480,178,5,112),(481,179,70,56),(482,179,35,112),(483,179,46,112),(484,180,12,28),(485,180,34,28),(486,180,46,28),(487,180,9,28),(488,181,4,7),(489,182,82,84),(490,182,27,42),(491,183,92,2),(492,183,37,112),(493,184,46,42),(494,184,83,28),(495,184,82,14),(496,184,29,4),(497,184,89,7),(498,184,48,28),(499,184,49,14),(500,184,36,28),(501,185,12,28),(502,185,21,28),(503,185,69,28),(504,186,28,112),(505,186,83,56),(506,186,4,56),(507,187,81,56),(508,187,37,112),(509,188,5,14),(510,189,28,80),(511,189,46,56),(512,189,39,28),(513,190,83,84),(514,190,68,84),(515,190,95,84),(516,190,3,42),(517,190,68,84),(518,190,69,42),(519,191,92,1),(520,191,46,14),(521,192,83,42),(522,192,82,21),(523,192,12,21),(524,192,69,21),(525,193,82,84),(526,193,83,42),(527,193,46,126),(528,195,83,70),(529,195,67,35),(530,195,69,35),(531,195,21,35),(532,195,46,35),(533,196,12,42),(534,196,81,42),(535,196,83,42),(536,196,69,42),(537,197,33,4),(538,197,70,4),(539,197,4,7),(540,198,64,4),(541,198,21,14),(542,198,44,14),(543,199,83,56),(544,200,83,28),(545,200,82,28),(546,200,36,28),(547,200,46,84),(548,201,92,1),(549,202,5,7),(550,202,3,7),(551,203,36,7),(552,203,46,7),(553,204,4,21),(554,205,81,14),(555,205,83,14),(556,205,36,14),(557,205,46,56),(558,205,47,14),(559,206,22,14),(560,207,82,35),(561,207,83,35),(562,207,36,35),(563,207,49,35),(564,207,46,35),(565,208,12,42),(566,208,34,42),(567,208,46,42),(568,208,9,42),(569,209,48,28),(570,209,83,56),(571,209,68,56),(572,209,95,56),(573,210,83,56),(574,210,82,28),(575,210,12,28),(576,210,69,28),(577,211,82,21),(578,211,83,21),(579,211,68,21),(580,212,81,28),(581,212,83,28),(582,212,12,28),(583,212,69,28),(584,213,83,56),(585,213,67,28),(586,213,69,28),(587,213,21,28),(588,213,46,28),(589,214,50,56),(590,214,46,112),(591,214,34,112),(592,215,4,14),(593,216,26,28),(594,216,83,28),(595,216,49,14),(596,216,48,14),(597,216,47,14),(598,216,46,42),(599,217,76,14),(600,217,48,28),(601,217,46,84),(602,217,33,28),(603,217,83,56),(604,218,82,56),(605,218,83,28),(606,218,50,28),(607,218,47,28),(608,218,48,28),(609,218,46,84),(610,219,69,56),(611,219,22,56),(612,219,82,112),(613,220,82,56),(614,220,83,56),(615,220,68,56),(616,220,46,56),(617,220,8,56),(618,221,59,28),(619,221,3,10),(620,221,70,14),(621,221,68,28),(622,222,70,84),(623,222,71,84),(624,223,45,98),(625,223,87,74),(626,223,81,98),(627,223,36,49),(628,223,46,147),(629,223,4,49),(630,224,72,56),(631,224,71,56),(632,224,46,168),(633,224,83,112),(634,224,25,56),(635,224,26,56),(636,224,48,56),(637,225,35,112),(638,225,33,56),(639,225,46,56),(640,227,35,28),(641,227,46,28),(642,228,9,84),(643,228,49,56),(644,228,47,56),(645,228,46,56),(646,229,93,2),(647,229,11,4),(648,229,49,28),(649,229,92,2),(650,229,46,28),(651,230,39,42),(652,231,12,14),(653,232,65,84),(654,232,19,42),(655,232,20,84),(656,233,45,168),(657,233,47,84),(658,233,48,84),(659,234,83,56),(660,234,70,56),(661,235,83,56),(662,235,26,42),(663,235,73,28),(664,235,46,84),(665,235,76,28),(666,236,35,56),(667,236,46,84),(668,236,83,56),(669,236,71,28),(670,237,71,56),(671,237,70,56),(672,237,37,112),(673,237,35,112),(674,238,85,28),(675,238,34,14),(676,239,34,42),(677,239,46,42),(678,239,67,21),(679,240,20,42),(680,240,12,42),(681,240,56,126),(682,241,12,42),(683,241,33,21),(684,242,48,42),(685,242,47,42),(686,242,70,42),(687,242,71,42),(688,242,46,126),(689,242,34,84),(690,243,82,56),(691,243,83,56),(692,243,36,112),(693,243,46,168),(694,244,9,42),(695,244,8,42),(696,245,21,84),(697,246,82,84),(698,247,57,112),(699,247,34,56),(700,248,81,168),(701,248,84,168),(702,248,59,84),(703,248,57,84),(704,249,37,168),(705,249,19,84),(706,250,37,112),(707,250,19,28),(708,253,33,84),(709,253,36,84),(710,253,49,84),(711,253,46,168),(712,253,11,2),(713,254,92,1),(714,254,49,14),(715,254,72,14),(716,255,92,1),(717,256,4,21),(718,256,23,21),(719,256,3,21),(720,256,64,21),(721,257,85,56),(722,257,33,28),(723,258,83,84),(724,258,70,84),(725,259,12,42),(726,259,21,42),(727,259,23,63),(728,259,48,42),(729,259,47,21),(730,260,49,56),(731,260,92,2),(732,260,11,2),(733,260,93,4),(734,260,46,56),(735,261,82,168),(736,261,43,112),(737,261,65,56),(738,261,70,56),(739,262,50,56),(740,262,48,112),(741,262,83,112),(742,262,82,56),(743,262,34,56),(744,262,46,224),(745,263,34,112),(746,263,46,112),(747,263,69,28),(748,263,82,112),(749,264,82,56),(750,264,21,28),(751,264,68,56),(752,264,36,28),(753,265,35,28),(754,265,46,28),(755,266,59,35),(756,266,70,35),(757,266,68,70),(758,267,57,84),(759,267,34,42),(760,268,34,28),(761,268,35,56),(762,268,46,84),(763,268,83,56),(764,268,82,28),(765,268,49,28),(766,268,49,14),(767,269,35,98),(768,269,46,147),(769,269,83,98),(770,269,71,49),(771,270,12,21),(772,271,34,28),(773,271,35,28),(774,271,46,28),(775,272,47,28),(776,272,48,28),(777,273,83,42),(778,273,46,63),(779,273,49,21),(780,273,47,21),(781,273,48,21),(782,273,26,42),(783,273,25,21),(784,274,5,21),(785,275,48,28),(786,275,47,28),(787,275,71,28),(788,275,70,28),(789,275,46,84),(790,275,34,56),(791,276,68,14),(792,277,28,112),(793,277,83,56),(794,277,4,56),(795,278,83,56),(796,278,82,56),(797,278,70,56),(798,279,21,28),(799,279,12,28),(800,279,25,28),(801,280,48,21),(802,280,83,21),(803,280,81,21),(804,280,36,21),(805,280,46,84),(806,281,35,28),(807,281,46,28),(808,282,83,112),(809,282,26,56),(810,282,25,56),(811,282,72,56),(812,282,71,56),(813,282,46,168),(814,282,76,56),(815,286,58,84),(816,286,72,42),(817,286,24,42),(818,287,4,28),(819,288,5,70),(820,288,4,70),(821,289,21,84),(822,289,44,84),(823,290,83,28),(824,290,21,14),(825,290,68,28),(826,290,35,14),(827,291,82,56),(828,291,83,56),(829,291,68,56),(830,291,46,112),(831,292,92,1),(832,292,49,28),(833,292,71,28),(834,293,47,42),(835,293,48,42),(836,294,5,7),(837,294,6,21),(838,295,82,42),(839,295,27,21),(840,296,81,28),(841,296,83,28),(842,296,12,28),(843,296,69,28),(844,297,81,21),(845,297,83,21),(846,297,12,21),(847,297,69,21),(848,298,37,252),(849,298,81,42),(850,299,28,56),(851,299,83,28),(852,299,4,28),(853,300,70,28),(854,300,4,28),(855,301,19,42),(856,301,37,168),(857,302,81,56),(858,302,84,56),(859,302,59,28),(860,302,57,28),(861,303,49,56),(862,303,47,56),(863,303,83,56),(864,303,46,84),(865,303,26,56),(866,303,25,28),(867,304,49,56),(868,304,47,84),(869,304,83,56),(870,304,46,84),(871,304,26,56),(872,304,25,28),(873,306,5,28),(874,307,5,28),(875,308,82,56),(876,309,82,70),(877,310,47,35),(878,310,48,35),(879,310,83,70),(880,310,68,35),(881,310,95,70),(882,311,69,21),(883,311,12,21),(884,311,82,42),(885,312,83,21),(886,313,85,112),(887,313,34,56),(888,315,48,28),(889,315,47,28),(890,315,71,28),(891,315,70,28),(892,315,46,84),(893,315,34,56),(894,316,68,56),(895,316,69,28),(896,316,70,28),(897,317,92,1),(898,317,46,28),(899,318,36,14),(900,318,92,1),(901,318,46,14),(902,319,92,1),(903,319,46,28),(904,319,93,2),(905,320,36,21),(906,320,46,21),(907,321,36,42),(908,321,46,42),(909,322,46,14),(910,322,69,14),(911,325,8,42),(912,325,9,42),(913,326,35,35),(914,326,36,35),(915,326,46,35),(916,327,33,35),(917,328,9,70),(918,328,46,35),(919,328,49,35),(920,328,47,35),(921,330,45,112),(922,330,87,84),(923,330,81,112),(924,330,46,168),(925,330,36,56),(926,330,5,56),(927,331,71,56),(928,331,70,56),(929,332,70,56),(930,332,71,56),(931,333,70,84),(932,333,71,84),(933,334,5,28),(934,334,3,28),(935,334,64,28),(936,335,5,7),(937,335,4,7),(938,335,65,7),(939,335,3,7),(940,336,5,42),(941,336,4,42),(942,336,65,42),(943,337,92,2),(944,338,92,1),(945,339,20,42),(946,339,22,42),(947,339,56,220),(948,340,12,42),(949,340,33,21),(950,341,82,42),(951,341,83,42),(952,341,34,126),(953,341,46,84),(954,342,50,42),(955,342,83,84),(956,342,68,42),(957,342,67,42),(958,342,12,42),(959,343,28,49),(960,343,46,28),(961,343,39,28),(962,344,28,84),(963,344,39,56),(964,345,72,70),(965,345,46,210),(966,345,83,140),(967,345,25,70),(968,345,26,70),(969,345,48,70),(970,346,93,2),(971,346,46,14),(972,346,92,1),(973,346,49,14),(974,346,11,1),(975,347,93,4),(976,347,46,56),(977,347,92,3),(978,347,49,26),(979,347,11,4),(980,348,70,56),(981,348,71,56),(982,348,58,112),(983,348,24,56),(984,349,65,84),(985,349,19,42),(986,349,20,84),(987,350,47,70),(988,350,48,70),(989,351,71,28),(990,351,70,28),(991,351,37,28),(992,351,36,56),(993,351,46,28),(994,353,68,56),(995,353,82,56),(996,353,83,56),(997,353,46,56),(998,353,8,56),(999,354,64,28),(1000,354,69,56),(1001,354,89,14),(1002,354,44,112),(1003,354,21,112),(1004,355,12,21),(1005,356,12,28),(1006,357,35,28),(1007,357,36,28),(1008,357,83,56),(1009,357,47,28),(1010,357,46,84),(1011,359,34,84),(1012,359,46,84),(1013,360,46,56),(1014,360,35,56),(1015,360,36,56),(1016,361,82,56),(1017,361,27,28),(1018,362,27,56),(1019,362,82,112),(1020,363,5,42),(1021,364,72,56),(1022,364,70,56),(1023,364,83,112),(1024,364,26,56),(1025,364,25,56),(1026,364,46,168),(1027,364,76,56),(1028,366,47,84),(1029,366,48,84),(1030,368,11,2),(1031,368,92,1),(1032,369,92,2),(1033,369,11,2),(1034,370,92,4),(1035,370,11,3),(1036,371,92,2),(1037,371,11,2),(1038,372,92,4),(1039,372,11,4),(1040,373,28,112),(1041,373,83,56),(1042,373,4,56),(1043,374,28,56),(1044,374,83,28),(1045,374,4,28),(1046,375,28,112),(1047,375,83,56),(1048,375,4,56),(1049,376,81,56),(1050,376,83,56),(1051,376,12,56),(1052,376,69,56),(1053,377,69,4),(1054,377,81,7),(1055,377,83,7),(1056,377,22,7),(1057,378,81,21),(1058,378,83,21),(1059,378,12,21),(1060,378,69,21),(1061,379,19,14),(1062,379,81,14),(1063,379,83,14),(1064,379,12,14),(1065,379,69,14),(1066,380,37,252),(1067,380,81,84),(1068,384,69,56),(1069,384,46,14),(1070,387,68,56),(1071,387,46,28),(1072,390,37,112),(1073,390,19,56),(1074,391,70,56),(1075,391,4,56),(1076,392,71,70),(1077,392,4,70),(1078,393,81,112),(1079,393,84,112),(1080,393,59,56),(1081,393,57,56),(1082,394,83,56),(1083,394,84,56),(1084,394,59,28),(1085,394,57,28),(1086,395,58,84),(1087,395,34,42),(1088,396,82,84),(1089,396,83,84),(1090,396,70,84),(1091,397,82,84),(1092,397,83,84),(1093,397,70,84),(1094,398,81,7),(1095,398,83,7),(1096,398,36,7),(1097,398,46,21),(1098,398,47,7),(1099,399,48,28),(1100,399,46,84),(1101,399,81,28),(1102,399,83,28),(1103,399,36,28),(1104,400,83,42),(1105,400,81,42),(1106,400,36,42),(1107,400,46,124),(1108,400,48,42),(1109,401,81,42),(1110,401,36,42),(1111,401,46,124),(1112,401,48,42),(1113,402,81,14),(1114,402,83,14),(1115,402,46,42),(1116,402,48,14),(1117,404,34,28),(1118,404,35,28),(1119,404,49,28),(1120,404,46,56),(1121,404,82,84),(1122,405,82,21),(1123,405,71,7),(1124,406,82,42),(1125,406,71,14),(1126,408,12,56),(1127,408,44,56),(1128,408,65,28),(1129,409,12,21),(1130,409,21,21),(1131,409,44,42),(1132,409,64,21),(1133,410,44,42),(1134,410,21,42),(1135,410,64,21),(1136,411,21,56),(1137,411,44,56),(1138,411,64,28),(1139,412,21,84),(1140,412,44,84),(1141,413,21,112),(1142,413,44,112),(1143,413,89,20),(1144,413,64,28),(1145,413,69,56),(1146,414,82,21),(1147,414,68,14),(1148,414,34,7),(1149,414,36,7),(1150,414,72,7),(1151,414,46,21),(1152,414,48,7),(1153,415,82,42),(1154,415,68,28),(1155,415,34,14),(1156,415,36,14),(1157,415,72,14),(1158,415,46,42),(1159,415,48,14),(1160,416,82,21),(1161,416,68,14),(1162,416,34,7),(1163,416,36,7),(1164,416,71,7),(1165,416,46,21),(1166,416,48,7),(1167,418,28,63),(1168,418,46,42),(1169,418,39,21),(1170,419,28,42),(1171,419,46,28),(1172,419,39,14),(1173,421,28,32),(1174,421,35,42),(1175,421,46,21),(1176,422,35,28),(1177,422,46,14),(1178,422,28,22),(1179,423,36,7),(1180,423,28,11),(1181,424,28,42),(1182,424,34,28),(1183,425,28,42),(1184,425,39,28),(1185,425,40,28),(1186,427,28,84),(1187,427,40,56),(1188,427,39,56),(1189,429,40,168),(1190,429,28,126),(1191,430,40,56),(1192,430,46,28),(1193,430,28,42),(1194,434,28,42),(1195,434,46,28),(1196,434,40,56),(1197,436,28,42),(1198,436,46,28),(1199,436,40,56),(1200,437,28,63),(1201,437,46,42),(1202,437,40,84),(1203,438,28,28),(1204,438,33,28),(1205,438,46,28),(1206,438,40,56),(1207,439,28,56),(1208,439,33,28),(1209,439,46,28),(1210,439,40,56),(1211,440,33,28),(1212,440,46,28),(1213,440,28,42),(1214,440,40,56),(1215,441,34,28),(1216,441,28,42),(1217,441,46,28),(1218,441,40,56),(1219,442,33,14),(1220,443,34,14),(1221,444,35,14),(1222,444,70,14),(1223,445,34,28),(1224,445,46,56),(1225,446,34,14),(1226,446,46,14),(1227,447,83,14),(1228,447,68,21),(1229,447,28,7),(1230,447,46,14),(1231,448,33,14),(1232,449,33,84),(1233,450,33,56),(1234,451,33,7),(1235,452,12,7),(1236,452,33,4),(1237,453,81,7),(1238,453,83,7),(1239,453,69,7),(1240,453,67,7),(1241,453,22,7),(1242,453,91,7),(1243,454,82,14),(1244,454,34,7),(1245,455,83,14),(1246,455,34,7),(1247,456,83,84),(1248,456,34,42),(1249,457,29,168),(1250,457,25,56),(1251,457,46,112),(1252,458,29,42),(1253,458,36,28),(1254,458,46,28),(1255,458,20,14),(1256,458,12,14),(1257,458,56,28),(1258,459,46,28),(1259,459,35,28),(1260,459,89,28),(1261,460,67,55),(1262,460,70,55),(1263,461,67,84),(1264,461,70,84),(1265,462,67,80),(1266,463,70,56),(1267,464,48,30),(1268,464,47,30),(1269,464,71,30),(1270,464,70,30),(1271,464,46,90),(1272,464,34,60),(1273,465,48,43),(1274,465,47,45),(1275,465,71,45),(1276,465,70,45),(1277,465,46,135),(1278,465,34,70),(1279,466,48,20),(1280,466,47,20),(1281,466,71,20),(1282,466,70,20),(1283,466,46,60),(1284,466,34,40),(1285,467,48,30),(1286,467,47,30),(1287,467,71,30),(1288,467,70,30),(1289,467,46,90),(1290,467,34,60),(1291,468,48,30),(1292,468,47,30),(1293,468,71,30),(1294,468,70,30),(1295,468,46,90),(1296,468,34,60),(1297,469,49,43),(1298,469,35,43),(1299,469,46,129),(1300,470,5,28),(1301,470,4,28),(1302,470,65,28),(1303,470,3,28),(1304,471,82,28),(1305,471,69,14),(1306,471,12,14),(1307,471,46,14),(1308,472,5,28),(1309,473,20,14),(1310,473,65,14),(1311,473,19,7),(1312,474,49,28),(1313,474,47,28),(1314,474,31,28),(1315,474,46,84),(1316,475,49,28),(1317,475,47,28),(1318,475,31,28),(1319,475,46,84),(1320,476,82,7),(1321,476,83,7),(1322,476,35,7),(1323,476,34,7),(1324,476,71,7),(1325,476,46,21),(1326,477,82,30),(1327,477,43,20),(1328,477,65,10),(1329,478,82,28),(1330,478,83,28),(1331,478,47,28),(1332,479,50,28),(1333,479,49,28),(1334,479,46,56),(1335,479,34,42),(1336,479,35,28),(1337,480,34,7),(1338,481,34,28),(1339,482,34,28),(1340,483,82,28),(1341,483,83,28),(1342,483,70,28),(1343,484,34,28),(1344,484,35,56),(1345,485,22,14),(1346,485,33,7),(1347,485,34,7),(1348,486,83,28),(1349,486,82,14),(1350,486,68,21),(1351,486,28,14),(1352,486,46,28),(1353,487,81,14),(1354,487,83,14),(1355,487,69,10),(1356,487,12,14),(1357,487,90,14),(1358,488,45,56),(1359,488,87,21),(1360,488,81,56),(1361,488,35,28),(1362,488,5,28),(1363,488,46,56),(1364,488,76,56),(1365,489,19,21),(1366,489,45,14),(1367,490,12,14),(1368,490,12,28),(1369,491,82,28),(1370,491,83,28),(1371,491,34,28),(1372,492,83,28),(1373,492,26,21),(1374,492,76,28),(1375,492,46,84),(1376,493,48,28),(1377,493,47,28),(1378,493,70,28),(1379,493,46,74),(1380,493,36,28),(1381,494,59,28),(1382,494,3,10),(1383,495,70,28),(1384,495,68,56),(1385,495,59,28),(1386,496,68,56),(1387,496,69,28),(1388,496,70,28),(1389,497,83,56),(1390,497,50,28),(1391,497,48,28),(1392,497,68,28),(1393,497,67,28),(1394,497,22,28),(1395,498,50,28),(1396,498,83,56),(1397,498,68,28),(1398,498,67,28),(1399,498,12,28),(1400,499,69,28),(1401,499,68,56),(1402,499,70,28),(1403,500,28,28),(1404,500,31,42),(1405,500,46,21),(1406,501,28,42),(1407,501,31,56),(1408,501,46,28),(1409,502,83,28),(1410,503,83,7),(1411,503,34,7),(1412,504,83,28),(1413,504,34,28),(1414,504,82,28),(1415,506,83,28),(1416,506,82,28),(1417,506,34,28),(1418,507,83,28),(1419,507,81,28),(1420,508,81,28),(1421,508,83,28),(1422,508,34,2),(1423,509,30,21),(1424,509,70,21),(1425,510,35,28),(1426,510,70,28),(1427,510,46,28),(1428,511,82,21),(1429,511,69,10),(1430,512,69,7),(1431,512,22,7),(1432,512,82,14),(1433,513,12,21),(1434,513,82,42),(1435,513,69,21),(1436,514,69,28),(1437,514,22,28),(1438,514,82,56),(1439,515,82,56),(1440,515,69,42),(1441,515,22,28),(1442,516,82,28),(1443,517,82,28),(1444,516,12,28),(1445,517,12,28),(1446,516,46,28),(1447,517,46,28),(1448,516,69,28),(1449,517,69,28),(1450,518,82,28),(1451,518,12,28),(1452,518,46,28),(1453,518,69,28),(1454,519,22,28),(1455,519,92,14),(1456,520,82,14),(1457,520,83,14),(1458,520,68,21),(1459,520,71,14),(1460,520,34,14),(1461,520,46,42),(1462,520,48,14),(1463,521,82,28),(1464,521,83,28),(1465,521,68,32),(1466,521,32,28),(1467,521,30,28),(1468,521,71,28),(1469,521,46,84),(1470,521,48,28),(1471,522,21,110),(1472,522,44,110),(1473,522,64,28),(1474,522,89,55),(1475,522,69,55),(1476,523,21,70),(1477,523,44,70),(1478,523,69,35),(1479,524,21,80),(1480,524,44,80),(1481,524,69,40),(1482,525,21,120),(1483,525,69,60),(1484,525,43,60),(1485,525,44,60),(1486,526,82,84),(1487,526,83,84),(1488,526,34,252),(1489,526,46,168),(1490,527,82,60),(1491,527,83,60),(1492,527,34,180),(1493,527,46,120),(1494,528,9,84),(1495,528,8,84),(1496,529,9,60),(1497,529,8,60),(1498,530,5,42),(1499,530,65,42),(1500,531,64,56),(1501,531,3,56),(1502,532,83,42),(1503,532,68,84),(1504,532,95,84),(1505,532,48,42),(1506,532,47,42),(1507,533,83,60),(1508,533,68,120),(1509,533,95,120),(1510,533,48,90),(1511,534,83,57),(1512,534,68,114),(1513,534,46,57),(1514,534,49,57),(1515,535,83,60),(1516,535,40,30),(1517,535,49,45),(1518,536,82,168),(1519,537,82,84),(1520,538,5,14),(1521,538,4,14),(1522,539,81,56),(1523,539,40,112),(1524,540,38,180),(1525,540,81,90),(1526,541,73,7),(1527,541,83,14),(1528,541,49,7),(1529,541,47,7),(1530,541,46,14),(1531,541,89,14),(1532,541,29,14),(1533,542,83,28),(1534,542,73,14),(1535,542,49,14),(1536,542,47,14),(1537,542,46,28),(1538,542,29,28),(1539,543,83,56),(1540,543,49,28),(1541,543,47,28),(1542,543,46,56),(1543,543,29,28),(1544,543,72,28),(1545,544,71,28),(1546,544,46,56),(1547,544,29,56),(1548,545,70,42),(1549,545,46,84),(1550,545,29,84),(1551,545,83,84),(1552,545,49,42),(1553,545,47,42),(1554,546,28,84),(1555,546,83,84),(1556,546,4,84),(1557,547,48,56),(1558,547,47,56),(1559,547,20,56),(1560,548,48,84),(1561,548,20,84),(1562,549,48,56),(1563,549,20,56),(1564,550,48,84),(1565,550,20,84),(1566,551,21,112),(1567,551,43,112),(1568,551,69,56),(1569,552,43,58),(1570,552,21,112),(1571,552,69,58),(1572,553,46,42),(1573,553,48,14),(1574,553,83,28),(1575,553,34,14),(1576,553,76,14),(1577,554,83,56),(1578,554,46,84),(1579,554,48,28),(1580,554,76,28),(1581,554,34,28),(1582,555,82,14),(1583,555,83,28),(1584,555,46,42),(1585,555,49,14),(1586,555,48,14),(1587,555,76,14),(1588,555,70,14),(1589,556,83,56),(1590,556,34,28),(1591,557,45,56),(1592,557,88,42),(1593,557,81,56),(1594,557,31,56),(1595,557,46,56),(1596,557,5,56),(1597,557,76,56),(1598,558,68,126),(1599,559,34,7),(1600,559,35,7),(1601,559,83,14),(1602,559,82,7),(1603,559,46,21),(1604,559,71,7),(1605,559,87,11),(1606,560,19,21),(1607,560,45,7),(1608,561,34,28),(1609,561,46,56),(1610,562,82,70),(1611,562,83,70),(1612,562,46,140),(1613,562,68,105),(1614,563,33,28),(1615,564,29,84),(1616,564,36,56),(1617,564,46,56),(1618,564,21,56),(1619,564,56,56),(1620,565,12,14),(1621,565,31,7),(1622,566,83,112),(1623,566,49,56),(1624,566,47,56),(1625,566,71,56),(1626,566,70,56),(1627,566,46,112),(1628,566,29,56),(1629,567,83,56),(1630,567,49,28),(1631,567,47,28),(1632,567,71,28),(1633,567,70,28),(1634,567,46,56),(1635,568,49,56),(1636,568,47,56),(1637,568,83,112),(1638,568,46,112),(1639,569,46,7),(1640,569,36,7),(1641,570,82,70),(1642,570,83,35),(1643,570,50,35),(1644,570,48,35),(1645,570,46,140),(1646,571,83,50),(1647,571,82,100),(1648,571,48,50),(1649,571,50,50),(1650,571,46,200),(1651,572,50,56),(1652,572,47,56),(1653,572,48,56),(1654,572,46,168),(1655,573,82,112),(1656,573,83,56),(1657,573,50,56),(1658,573,47,56),(1659,573,48,56),(1660,573,46,168),(1661,574,82,98),(1662,574,83,50),(1663,574,50,50),(1664,574,47,50),(1665,574,48,50),(1666,574,46,150),(1667,575,33,100),(1668,576,33,84),(1669,577,33,74),(1670,578,82,7),(1671,578,81,7),(1672,578,86,14),(1673,578,33,7),(1674,579,82,56),(1675,579,86,56),(1676,579,33,56),(1677,580,81,84),(1678,580,86,84),(1679,580,33,42),(1680,581,81,56),(1681,581,86,112),(1682,581,33,56),(1683,582,20,35),(1684,582,65,35),(1685,582,19,18),(1686,583,20,49),(1687,583,65,74),(1688,584,36,56),(1689,584,46,168),(1690,584,82,112),(1691,584,83,56),(1692,584,49,56),(1693,585,82,70),(1694,585,83,35),(1695,585,46,95),(1696,585,36,35),(1697,585,49,35),(1698,586,82,14),(1699,586,34,7),(1700,587,82,7),(1701,587,83,7),(1702,587,34,7),(1703,588,36,14),(1704,588,70,14),(1705,589,83,14),(1706,589,35,14),(1707,589,70,7),(1708,590,83,28),(1709,590,36,14),(1710,590,70,14),(1711,591,12,14),(1712,591,35,14),(1713,591,46,14),(1714,592,82,35),(1715,592,83,35),(1716,592,36,35),(1717,592,46,35),(1718,593,82,56),(1719,593,83,56),(1720,593,35,56),(1721,593,46,56),(1722,594,82,252),(1723,594,36,84),(1724,594,46,252),(1725,595,82,210),(1726,595,35,70),(1727,595,46,210),(1728,596,82,252),(1729,596,34,84),(1730,596,46,252),(1731,596,19,84),(1732,597,82,63),(1733,597,34,21),(1734,597,46,21),(1735,597,19,21),(1736,598,22,42),(1737,599,21,56),(1738,600,22,63),(1739,601,22,14),(1740,602,22,14),(1741,603,82,28),(1742,603,81,28),(1743,604,81,112),(1744,604,86,112),(1745,604,35,56),(1746,605,81,21),(1747,605,83,21),(1748,605,69,21),(1749,605,67,21),(1750,605,22,21),(1751,606,28,168),(1752,606,83,84),(1753,606,5,84),(1754,607,83,112),(1755,607,26,84),(1756,607,72,56),(1757,607,71,56),(1758,607,46,168),(1759,607,76,56),(1760,608,83,168),(1761,608,26,84),(1762,608,70,14),(1763,608,46,252),(1764,608,76,84),(1765,609,35,84),(1766,610,92,3),(1767,610,11,2),(1768,611,11,2),(1769,611,92,2),(1770,613,82,182),(1771,613,27,91),(1772,614,82,70),(1773,614,27,35),(1774,615,82,168),(1775,615,27,84),(1776,616,82,35),(1777,616,83,35),(1778,616,34,105),(1779,616,46,70),(1780,617,83,84),(1781,617,82,84),(1782,617,69,84),(1783,617,67,84),(1784,617,46,84),(1785,618,83,84),(1786,618,82,84),(1787,618,69,84),(1788,618,67,84),(1789,618,46,84),(1790,619,83,63),(1791,619,69,63),(1792,619,82,63),(1793,619,67,63),(1794,619,46,63),(1795,620,83,28),(1796,620,68,14),(1797,620,46,14),(1798,621,9,56),(1799,621,8,56),(1800,622,50,49),(1801,622,83,98),(1802,622,68,49),(1803,622,67,49),(1804,622,22,49),(1805,623,49,63),(1806,624,49,84),(1807,625,49,28),(1808,626,11,2),(1809,626,49,21),(1810,626,47,21),(1811,626,34,21),(1812,627,12,56),(1813,628,82,112),(1814,628,69,56),(1815,628,22,56),(1816,628,46,56),(1817,629,82,56),(1818,629,83,56),(1819,629,69,56),(1820,630,69,7),(1821,630,82,14),(1822,631,69,7),(1823,631,82,14),(1824,632,69,28),(1825,632,82,56),(1826,633,82,7),(1827,633,83,7),(1828,633,68,7),(1829,634,83,14),(1830,634,82,14),(1831,634,69,14),(1832,634,67,14),(1833,635,82,28),(1834,635,83,28),(1835,635,69,28),(1836,635,67,28),(1837,636,12,7),(1838,637,35,56),(1839,637,45,112),(1840,637,87,84),(1841,637,81,112),(1842,637,46,168),(1843,637,5,56),(1844,638,45,112),(1845,638,87,84),(1846,638,81,112),(1847,638,34,56),(1848,638,46,112),(1849,638,5,56),(1850,638,76,56),(1851,639,45,56),(1852,639,87,42),(1853,639,81,56),(1854,639,35,28),(1855,639,46,56),(1856,639,5,28),(1857,639,76,28),(1858,640,45,84),(1859,640,87,63),(1860,640,82,42),(1861,640,81,42),(1862,640,34,42),(1863,640,5,42),(1864,640,76,84),(1865,641,82,112),(1866,641,69,56),(1867,641,22,56),(1868,641,46,56),(1869,642,12,14),(1870,643,12,28),(1871,644,12,28),(1872,645,12,56),(1873,646,12,28),(1874,647,81,168),(1875,647,84,168),(1876,647,59,84),(1877,647,57,84),(1878,648,81,56),(1879,648,84,56),(1880,648,59,28),(1881,648,57,28),(1882,649,83,14),(1883,649,82,7),(1884,649,34,7),(1885,649,49,7),(1886,649,48,7),(1887,649,46,28),(1888,650,82,14),(1889,650,83,28),(1890,650,34,14),(1891,650,50,14),(1892,650,48,14),(1893,650,46,56),(1894,651,82,28),(1895,651,83,56),(1896,651,34,28),(1897,651,50,28),(1898,651,48,56),(1899,651,46,112),(1900,652,82,28),(1901,652,83,56),(1902,652,34,28),(1903,652,50,28),(1904,652,48,56),(1905,652,46,112),(1906,653,82,56),(1907,653,83,112),(1908,653,34,56),(1909,653,50,56),(1910,653,48,112),(1911,653,46,224),(1912,654,82,56),(1913,654,83,112),(1914,654,50,58),(1915,654,48,112),(1916,654,46,224),(1917,655,82,56),(1918,655,83,112),(1919,655,50,56),(1920,655,48,112),(1921,655,46,224),(1922,656,82,42),(1923,656,83,84),(1924,656,50,42),(1925,656,48,84),(1926,656,46,168),(1927,657,83,84),(1928,657,82,84),(1929,657,84,168),(1930,657,69,84),(1931,657,67,84),(1932,657,76,168),(1933,657,46,84),(1934,658,83,84),(1935,658,82,84),(1936,658,84,168),(1937,658,69,84),(1938,658,76,168),(1939,658,46,84),(1940,659,83,7),(1941,659,82,7),(1942,659,84,14),(1943,659,69,7),(1944,659,67,7),(1945,659,76,14),(1946,659,46,7),(1947,660,82,56),(1948,660,83,56),(1949,660,84,112),(1950,660,69,56),(1951,660,67,56),(1952,660,76,112),(1953,661,82,168),(1954,661,84,112),(1955,661,69,56),(1956,661,67,56),(1957,661,76,112),(1958,662,82,168),(1959,662,84,112),(1960,662,69,56),(1961,662,67,56),(1962,662,75,70),(1963,662,46,56),(1964,663,11,1),(1965,663,49,56),(1966,663,92,2),(1967,663,46,56),(1968,664,11,2),(1969,664,49,56),(1970,664,92,1),(1971,664,46,56),(1972,665,11,1),(1973,665,49,28),(1974,665,92,2),(1975,665,46,58),(1976,666,11,1),(1977,666,49,28),(1978,666,92,2),(1979,666,46,28),(1980,667,11,2),(1981,667,49,42),(1982,667,92,2),(1983,667,46,42),(1984,668,83,84),(1985,668,49,63),(1986,668,39,42),(1987,669,69,14),(1988,669,70,14),(1989,670,69,28),(1990,670,70,28),(1991,671,69,28),(1992,671,70,28),(1993,672,69,42),(1994,672,70,21),(1995,673,69,42),(1996,673,70,28),(1997,674,68,56),(1998,674,70,28),(1999,675,5,14),(2000,675,4,14),(2001,676,4,21),(2002,676,5,21),(2003,677,5,28),(2004,677,4,28),(2005,678,4,14),(2006,678,5,14),(2007,679,5,14),(2008,679,4,14),(2009,679,64,14),(2010,680,4,28),(2011,680,23,28),(2012,681,83,42),(2013,681,82,21),(2014,681,69,42),(2015,681,68,21),(2016,681,28,63),(2017,681,46,42),(2018,682,83,28),(2019,682,68,14),(2020,682,82,14),(2021,682,28,21),(2022,682,46,28),(2023,683,83,56),(2024,683,46,84),(2025,683,50,28),(2026,683,47,84),(2027,683,26,56),(2028,683,25,28),(2029,684,83,56),(2030,684,46,84),(2031,684,50,28),(2032,684,47,84),(2033,684,26,56),(2034,684,25,28),(2035,685,83,42),(2036,685,46,63),(2037,685,50,21),(2038,685,48,42),(2039,685,26,42),(2040,686,83,14),(2041,686,46,21),(2042,686,50,7),(2043,686,48,7),(2044,686,26,14),(2045,686,25,7),(2046,686,91,14),(2047,687,82,7),(2048,687,83,7),(2049,687,46,21),(2050,687,50,7),(2051,687,48,7),(2052,687,26,21),(2053,687,90,7),(2054,688,82,14),(2055,688,83,14),(2056,688,46,42),(2057,688,50,14),(2058,688,48,14),(2059,688,26,42),(2060,688,90,14),(2061,689,90,28),(2062,689,71,28),(2063,690,49,70),(2064,690,47,70),(2065,690,9,70),(2066,690,46,70),(2067,691,36,168),(2068,691,46,84),(2069,692,36,168),(2070,692,46,84),(2071,693,49,56),(2072,693,47,56),(2073,693,9,56),(2074,693,46,56),(2075,694,49,70),(2076,694,47,70),(2077,694,9,140),(2078,695,49,84),(2079,695,47,84),(2080,695,9,168),(2081,695,46,84),(2082,696,49,84),(2083,696,47,84),(2084,696,9,168),(2085,696,46,84),(2086,697,85,14),(2087,698,81,7),(2088,698,83,7),(2089,698,68,7),(2090,698,12,7),(2091,699,68,112),(2092,699,69,56),(2093,699,70,56),(2094,700,31,98),(2095,700,46,147),(2096,700,83,98),(2097,700,71,49),(2098,701,36,28),(2099,701,33,28),(2100,701,46,84),(2101,701,83,56),(2102,701,71,28),(2103,702,36,56),(2104,702,82,112),(2105,702,83,56),(2106,703,82,56),(2107,703,83,56),(2108,703,36,56),(2109,703,33,56),(2110,703,71,56),(2111,703,46,56),(2112,704,82,84),(2113,704,83,84),(2114,704,36,84),(2115,704,33,84),(2116,704,71,84),(2117,704,46,252),(2118,705,82,84),(2119,705,83,84),(2120,705,36,84),(2121,705,33,84),(2122,705,71,84),(2123,705,46,252),(2124,706,72,70),(2125,706,71,70),(2126,706,46,210),(2127,706,83,140),(2128,706,25,210),(2129,706,48,70),(2130,707,72,84),(2131,707,46,252),(2132,707,83,168),(2133,707,25,252),(2134,707,48,84),(2135,708,83,84),(2136,708,82,42),(2137,708,71,42),(2138,708,26,84),(2139,708,49,63),(2140,708,46,126),(2141,709,82,84),(2142,709,36,28),(2143,709,33,28),(2144,709,46,28),(2145,710,82,168),(2146,710,36,56),(2147,710,46,112),(2148,711,82,168),(2149,711,36,56),(2150,711,33,56),(2151,711,46,56),(2152,712,82,252),(2153,712,36,84),(2154,712,33,84),(2155,712,46,84),(2156,713,82,168),(2157,713,36,56),(2158,713,33,56),(2159,713,46,56),(2160,714,34,56),(2161,714,46,56),(2162,715,34,56),(2163,715,46,56),(2164,716,34,84),(2165,716,46,84),(2166,717,34,56),(2167,717,46,56),(2168,718,47,7),(2169,718,82,14),(2170,719,82,63),(2171,719,50,42),(2172,720,82,7),(2173,720,83,7),(2174,720,47,7),(2175,721,82,21),(2176,721,83,21),(2177,721,47,21),(2178,722,82,35),(2179,722,83,35),(2180,722,47,35),(2181,723,82,35),(2182,723,83,35),(2183,723,47,35),(2184,724,69,42),(2185,724,12,42),(2186,725,19,42),(2187,725,45,14),(2188,726,83,56),(2189,726,36,28),(2190,726,70,28),(2191,727,58,140),(2192,727,71,70),(2193,727,24,70),(2194,728,58,168),(2195,728,70,84),(2196,728,24,84),(2197,729,70,42),(2198,729,58,84),(2199,729,24,42),(2200,730,33,7),(2201,731,22,28),(2202,731,35,28),(2203,731,46,28),(2204,732,29,63),(2205,732,25,21),(2206,732,46,42),(2207,733,45,56),(2208,733,87,32),(2209,733,81,56),(2210,733,33,28),(2211,733,76,56),(2212,734,6,14),(2213,734,65,14),(2214,734,47,14),(2215,735,58,168),(2216,735,34,84),(2217,736,58,112),(2218,736,33,56),(2219,737,83,56),(2220,737,68,28),(2221,737,46,28),(2222,738,92,2),(2223,739,71,84),(2224,739,70,84),(2225,740,70,84),(2226,740,71,84),(2227,742,83,28),(2228,742,82,14),(2229,742,69,14),(2230,742,36,14),(2231,742,33,14),(2232,742,28,21),(2233,742,46,28),(2234,743,85,112),(2235,744,83,112),(2236,744,34,56),(2237,745,50,56),(2238,745,48,56),(2239,745,83,112),(2240,745,82,56),(2241,746,36,56),(2242,746,50,56),(2243,746,48,56),(2244,746,83,112),(2245,746,82,56),(2246,746,39,168),(2247,747,38,112),(2248,747,19,28),(2249,748,38,168),(2250,748,19,42),(2251,749,38,112),(2252,749,19,56),(2253,750,39,168),(2254,750,19,84),(2255,751,36,42),(2256,751,49,42),(2257,751,34,84),(2258,751,46,84),(2259,752,49,42),(2260,752,48,42),(2261,752,35,42),(2262,752,46,126),(2263,753,83,112),(2264,753,22,56),(2265,753,68,56),(2266,754,83,84),(2267,754,12,42),(2268,754,68,42),(2269,755,29,168),(2270,755,25,56),(2271,755,46,112),(2272,756,11,2),(2273,756,49,28),(2274,756,47,28),(2275,756,46,56),(2276,757,82,168),(2277,757,46,168),(2278,757,34,56),(2279,757,19,112),(2280,758,79,56),(2281,758,35,28),(2282,758,46,28),(2283,758,89,28),(2284,759,79,28),(2285,759,35,14),(2286,759,46,14),(2287,759,89,14),(2288,760,34,21),(2289,760,46,21),(2290,761,83,56),(2291,761,82,28),(2292,761,36,28),(2293,761,33,28),(2294,761,46,84),(2295,761,71,28),(2296,761,87,42),(2297,761,3,28),(2298,762,82,84),(2299,762,83,84),(2300,762,68,126),(2301,762,34,84),(2302,762,36,84),(2303,762,46,252),(2304,762,48,84),(2305,762,70,84),(2306,763,71,21),(2307,763,3,14),(2308,764,71,56),(2309,764,3,14),(2310,765,36,58),(2311,765,70,56),(2312,765,46,56),(2313,766,82,28),(2314,766,83,56),(2315,766,46,168),(2316,766,76,56),(2317,766,73,56),(2318,766,72,56),(2319,766,49,56),(2320,766,48,56),(2321,767,4,14),(2322,768,4,14),(2323,769,36,112),(2324,769,29,168),(2325,769,46,112),(2326,769,20,56),(2327,769,22,56),(2328,769,56,112),(2329,770,5,56),(2330,771,34,21),(2331,772,34,7),(2332,773,83,28),(2333,774,50,70),(2334,774,49,70),(2335,774,35,70),(2336,774,46,70),(2337,775,34,56),(2338,775,46,112),(2339,776,68,7),(2340,776,69,7),(2341,776,22,7),(2342,776,3,7),(2343,777,48,7),(2344,777,47,7),(2345,777,34,7),(2346,778,81,42),(2347,778,86,84),(2348,778,33,42),(2349,779,82,126),(2350,779,43,84),(2351,779,65,42),(2352,780,50,84),(2353,780,49,84),(2354,780,46,168),(2355,780,34,84),(2356,780,35,84),(2357,781,65,42),(2358,781,3,42),(2359,781,6,42),(2360,782,48,21),(2361,782,47,21),(2362,782,34,21),(2363,783,82,112),(2364,783,83,56),(2365,783,36,56),(2366,783,46,168),(2367,783,49,56),(2368,784,20,70),(2369,784,65,105),(2370,784,19,35),(2371,785,4,21),(2372,786,29,168),(2373,786,25,56),(2374,786,46,112),(2375,787,33,14),(2376,788,12,28),(2377,788,36,28),(2378,788,46,28),(2379,789,49,70),(2380,790,35,84),(2381,790,46,84),(2382,791,9,84),(2383,791,8,84),(2384,791,46,84),(2385,792,82,35),(2386,792,83,35),(2387,792,71,35),(2388,793,28,126),(2389,793,35,84),(2390,793,46,84),(2391,794,28,84),(2392,794,35,168),(2393,794,46,84),(2394,795,92,1),(2395,795,93,2),(2396,796,5,28),(2397,797,83,56),(2398,797,68,28),(2399,797,12,28),(2400,797,23,28),(2401,797,3,14),(2402,798,83,56),(2403,798,82,28),(2404,798,35,28),(2405,798,28,42),(2406,798,46,84),(2407,799,11,4),(2408,799,92,2),(2409,800,82,112),(2410,800,83,112),(2411,800,34,336),(2412,800,46,224),(2413,801,65,42),(2414,801,71,42),(2415,801,89,42),(2416,802,34,28),(2417,802,46,28),(2418,803,82,252),(2419,803,35,84),(2420,803,33,168),(2421,803,46,84),(2422,804,19,126),(2423,804,45,42),(2424,805,5,56),(2425,805,56,20),(2426,806,83,168),(2427,806,26,126),(2428,806,76,84),(2429,806,46,252),(2430,807,33,84),(2431,808,83,168),(2432,808,82,84),(2433,808,22,84),(2434,808,67,84),(2435,809,82,28),(2436,809,83,28),(2437,809,68,28),(2438,809,46,28),(2439,809,8,28),(2440,810,83,168),(2441,810,68,84),(2442,810,46,84),(2443,811,83,63),(2444,811,46,84),(2445,811,49,21),(2446,811,47,21),(2447,811,76,21),(2448,811,70,21),(2449,812,33,7),(2450,813,33,21),(2451,814,83,84),(2452,814,50,42),(2453,814,48,84),(2454,814,46,126),(2455,814,70,42),(2456,815,82,56),(2457,815,83,56),(2458,815,69,56),(2459,816,82,56),(2460,816,83,56),(2461,816,68,56),(2462,816,37,112),(2463,817,45,84),(2464,817,87,84),(2465,817,82,56),(2466,817,81,56),(2467,817,46,112),(2468,817,5,56),(2469,817,76,112),(2470,817,69,56),(2471,818,11,1),(2472,818,49,56),(2473,818,48,56),(2474,818,92,1),(2475,818,46,56),(2476,818,93,4),(2477,819,11,2),(2478,819,49,42),(2479,819,46,84),(2480,820,82,168),(2481,820,33,56),(2482,820,46,168),(2483,820,19,168),(2484,821,83,168),(2485,821,50,84),(2486,821,68,84),(2487,821,67,84),(2488,821,22,84),(2489,822,92,28),(2490,822,93,2),(2491,823,83,112),(2492,823,47,56),(2493,823,46,224),(2494,824,21,168),(2495,824,69,84),(2496,825,81,28),(2497,825,83,28),(2498,825,68,28),(2499,825,69,28),(2500,825,12,28),(2501,825,23,28),(2502,825,3,10),(2503,825,46,28),(2504,826,83,28),(2505,826,82,28),(2506,826,46,32),(2507,826,71,14),(2508,826,87,21),(2509,826,89,14),(2510,827,35,84),(2511,827,46,84),(2512,828,34,14),(2513,828,46,14),(2514,829,83,168),(2515,829,49,84),(2516,829,46,168),(2517,830,83,56),(2518,830,82,28),(2519,830,26,56),(2520,830,49,42),(2521,830,46,72),(2522,831,82,42),(2523,831,83,42),(2524,831,47,42),(2525,832,92,2),(2526,833,58,112),(2527,833,70,56),(2528,833,24,56),(2529,834,4,21),(2530,835,69,84),(2531,835,22,84),(2532,836,36,21),(2533,836,89,42),(2534,836,93,2),(2535,836,46,42),(2536,837,34,7),(2537,837,89,14),(2538,837,93,1),(2539,837,46,14),(2540,838,48,42),(2541,838,47,42),(2542,838,36,21),(2543,839,49,28),(2544,840,83,84),(2545,840,68,168),(2546,840,46,252),(2547,841,82,56),(2548,841,83,56),(2549,841,36,56),(2550,841,48,56),(2551,842,82,84),(2552,842,83,84),(2553,842,36,84),(2554,842,49,84),(2555,842,48,84),(2556,842,46,168),(2557,843,82,84),(2558,843,83,84),(2559,843,36,84),(2560,843,49,84),(2561,843,46,84),(2562,844,12,42),(2563,844,36,42),(2564,844,33,42),(2565,844,46,42),(2566,845,49,70),(2567,845,48,70),(2568,845,47,70),(2569,845,35,70),(2570,845,46,210),(2571,846,83,84),(2572,846,70,84),(2573,847,83,84),(2574,847,71,84),(2575,848,83,56),(2576,848,82,28),(2577,848,68,28),(2578,848,35,28),(2579,848,28,42),(2580,848,46,56),(2581,849,83,14),(2582,849,82,14),(2583,849,35,7),(2584,849,34,7),(2585,849,46,28),(2586,849,71,7),(2587,849,87,10),(2588,849,89,7),(2589,850,5,63),(2590,851,68,70),(2591,852,82,252),(2592,852,84,168),(2593,852,67,84),(2594,852,69,84),(2595,852,75,63),(2596,852,46,84),(2597,853,83,105),(2598,853,46,140),(2599,853,49,35),(2600,853,76,35),(2601,853,70,35),(2602,853,36,70),(2603,854,67,84),(2604,854,70,84),(2605,855,33,84),(2606,855,46,42),(2607,856,82,112),(2608,856,83,112),(2609,856,71,112),(2610,857,34,112),(2611,857,46,112),(2612,858,81,56),(2613,858,86,56),(2614,858,33,28),(2615,859,81,252),(2616,859,43,168),(2617,859,65,84),(2618,860,82,42),(2619,860,83,42),(2620,860,46,42),(2621,860,8,42),(2622,861,11,6),(2623,861,35,112),(2624,862,79,168),(2625,862,35,84),(2626,862,46,84),(2627,862,89,84),(2628,863,5,42),(2629,864,35,28),(2630,864,46,28),(2631,865,58,168),(2632,865,34,84),(2633,866,49,28),(2634,866,20,28),(2635,867,83,28),(2636,867,82,14),(2637,867,36,14),(2638,867,63,7),(2639,867,70,14),(2640,867,46,21),(2641,868,68,126),(2642,869,83,168),(2643,869,34,84),(2644,870,82,168),(2645,870,69,42),(2646,870,22,84),(2647,870,46,84),(2648,871,71,72),(2649,871,3,20),(2650,872,83,56),(2651,872,22,56),(2652,872,68,28),(2653,872,3,10),(2654,873,81,84),(2655,873,39,252),(2656,874,85,168),(2657,875,69,84),(2658,875,67,84),(2659,876,36,56),(2660,876,33,56),(2661,876,70,56),(2662,876,46,56),(2663,877,34,56),(2664,877,35,112),(2665,877,49,56),(2666,877,47,56),(2667,878,6,28),(2668,878,5,28),(2669,878,89,14),(2670,878,3,14),(2671,878,65,28),(2672,879,6,28),(2673,879,89,14),(2674,879,64,14),(2675,880,83,28),(2676,880,82,14),(2677,880,36,28),(2678,880,46,42),(2679,880,76,28),(2680,880,71,14),(2681,881,69,21),(2682,881,22,21),(2683,882,83,56),(2684,882,12,56),(2685,882,68,28),(2686,882,69,28),(2687,882,3,10),(2688,883,29,252),(2689,883,36,168),(2690,883,46,168),(2691,883,12,168),(2692,883,56,168),(2693,884,83,14),(2694,884,82,14),(2695,884,36,28),(2696,884,29,28),(2697,884,46,42),(2698,885,34,84),(2699,885,46,168),(2700,887,82,112),(2701,887,27,56),(2702,888,82,21),(2703,888,33,7),(2704,888,46,7),(2705,888,19,21),(2706,889,34,28),(2707,889,89,56),(2708,889,93,1),(2709,889,46,56),(2710,890,5,42),(2711,891,49,28),(2712,892,28,168),(2713,892,83,84),(2714,892,5,84),(2715,893,83,28),(2716,893,71,14),(2717,893,26,28),(2718,893,49,14),(2719,893,46,32),(2720,894,65,35),(2721,894,71,14),(2722,894,70,14),(2723,894,3,14),(2724,895,36,168),(2725,895,46,84),(2726,896,49,84),(2727,896,47,84),(2728,896,10,84),(2729,896,46,84),(2730,897,33,84),(2731,899,34,56),(2732,900,83,84),(2733,901,83,56),(2734,901,12,56),(2735,901,69,28),(2736,901,68,28),(2737,901,3,10),(2738,902,48,84),(2739,902,92,4),(2740,903,83,112),(2741,903,50,56),(2742,903,49,56),(2743,903,46,168),(2744,904,29,168),(2745,904,25,56),(2746,904,46,112),(2747,905,81,56),(2748,905,86,56),(2749,905,33,28),(2750,906,22,56),(2751,906,36,56),(2752,906,33,56),(2753,906,46,112),(2754,907,82,168),(2755,907,70,56),(2756,907,36,56),(2757,907,33,56),(2758,907,46,168),(2759,908,19,112),(2760,908,45,56),(2761,908,70,10),(2762,909,83,56),(2763,909,82,28),(2764,909,36,56),(2765,909,29,56),(2766,909,46,84),(2767,910,50,84),(2768,910,49,84),(2769,910,35,84),(2770,910,46,84),(2771,911,82,56),(2772,911,81,56),(2773,911,45,112),(2774,911,87,84),(2775,911,5,56),(2776,911,69,56),(2777,911,76,112),(2778,912,81,56),(2779,912,84,56),(2780,912,59,56),(2781,913,82,168),(2782,913,33,56),(2783,913,46,168),(2784,913,19,224),(2785,914,82,168),(2786,914,83,84),(2787,914,36,84),(2788,914,46,252),(2789,914,49,84),(2790,915,81,56),(2791,915,86,56),(2792,915,33,28),(2793,916,83,42),(2794,916,22,42),(2795,916,68,21),(2796,916,69,21),(2797,917,71,42),(2798,917,65,84),(2799,917,3,42),(2800,918,69,21),(2801,918,12,21),(2802,919,83,126),(2803,919,46,168),(2804,919,49,42),(2805,919,76,42),(2806,919,70,42),(2807,920,82,42),(2808,920,83,42),(2809,920,47,42),(2810,921,92,4),(2811,922,83,112),(2812,922,82,56),(2813,922,71,56),(2814,922,26,112),(2815,922,49,84),(2816,922,46,168),(2817,923,11,56),(2818,923,50,28),(2819,923,47,28),(2820,924,92,1),(2821,924,49,11),(2822,925,82,28),(2823,925,83,28),(2824,925,69,42),(2825,926,19,28),(2826,926,38,56),(2827,927,49,28),(2828,927,20,28),(2829,928,83,28),(2830,928,82,14),(2831,928,68,14),(2832,928,69,14),(2833,928,3,14),(2834,929,82,28),(2835,929,83,28),(2836,929,69,42),(2837,930,83,56),(2838,930,50,28),(2839,930,47,28),(2840,930,46,112),(2841,931,50,56),(2842,931,49,56),(2843,931,46,112),(2844,931,34,56),(2845,931,35,56),(2846,932,6,84),(2847,932,65,84),(2848,932,3,84),(2849,933,82,14),(2850,933,83,14),(2851,933,68,14),(2852,933,46,14),(2853,933,8,14),(2854,934,70,84),(2855,934,24,84),(2856,934,58,168),(2857,935,82,21),(2858,935,83,21),(2859,935,46,14),(2860,935,48,14),(2861,937,83,28),(2862,937,71,14),(2863,937,82,14),(2864,937,26,28),(2865,937,49,14),(2866,937,48,14),(2867,937,46,42),(2868,938,32,14),(2869,938,46,14),(2870,939,81,28),(2871,939,84,28);
/*!40000 ALTER TABLE `opmedicine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `panjayath`
--

DROP TABLE IF EXISTS `panjayath`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `panjayath` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `panjayath`
--

LOCK TABLES `panjayath` WRITE;
/*!40000 ALTER TABLE `panjayath` DISABLE KEYS */;
INSERT INTO `panjayath` VALUES (1,'KUTTIPPURAM'),(2,'THAVANUR'),(3,'ATHAVANAD'),(4,'VALANCHERY'),(5,'IRIMBILIYAM'),(6,'THIRUNAVAYA'),(7,'KALADI'),(8,'EDAPPAL'),(9,'VATTAMKULAM');
/*!40000 ALTER TABLE `panjayath` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `PNo` varchar(45) DEFAULT NULL,
  `Name` varchar(200) DEFAULT NULL,
  `Age` varchar(45) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Grade` varchar(45) DEFAULT NULL,
  `Gender` varchar(45) DEFAULT NULL,
  `Panjayath` varchar(100) DEFAULT NULL,
  `WardNo` varchar(45) DEFAULT NULL,
  `Phone1` varchar(45) DEFAULT NULL,
  `Phone2` varchar(45) DEFAULT NULL,
  `RegDate` datetime DEFAULT NULL,
  `ExpDate` datetime DEFAULT NULL,
  `DropDate` datetime DEFAULT NULL,
  `Volunteer` varchar(100) DEFAULT NULL,
  `Diagnosis` varchar(100) DEFAULT NULL,
  `Temp` tinyint DEFAULT NULL,
  `Route` varchar(100) DEFAULT NULL,
  `HomeCarePlan` varchar(45) DEFAULT NULL,
  `ScreeningDate` datetime DEFAULT NULL,
  `ScreeningReason` text,
  `ScreeningStatus` tinyint DEFAULT NULL,
  `ScreeningRemarks` text,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `PNo_UNIQUE` (`PNo`)
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES (1,'182/2021','MOHAMMAD BASHEER','33','AVIMIKKATTIL (H)\nEDACHALAM\nKUTTIPPURA','','M','KUTTIPPURAM','8','9946782113','7034504363','2021-08-02 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(2,'59/2021','KUNJUMUHAMMAD','59','VERUKUNDIL (H)\nPAIGANNOR\nKUTTIPPURAM','','M','KUTTIPPURAM','10','9048289797','8086515930','2019-08-14 00:00:00',NULL,NULL,'','RECCURENT DEPRESSIVE DISORDER',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(3,'16/2021','SAFIYA','36','PARATHODIYIL (H)\nCHELLUR\nKUTTIPPURAM','','F','KUTTIPPURAM','4','9526206305','','2021-01-13 00:00:00',NULL,NULL,'','MENTAL RETARDDATION , BIPOLAR AFFECTIVE DISORDER',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(4,'47/2017','KUNJATHU','79','KIZAKKATH PARAMBIL (H)\nMOODAL\nKUTTIPPURAM','','F','KUTTIPPURAM','7','8129408711','','2019-08-14 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(5,'104/2018','HASEENA','36','MADATHIL VALAPPIL (H)\nOOROTHUPPALLIYAL\nKUTTIPPURAM','','F','KUTTIPPURAM','3','9846429068','','2019-08-14 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'NADUVETTAM','',NULL,NULL,NULL,NULL),(6,'90/2017','RANEESH','34','MELETHIL (H)\nPAZHUR\nNARRIKULLAM\nKUTTIPPURAM','','M','KUTTIPPURAM','21','9526640139','8943433356','2019-08-14 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'NADUVETTAM','',NULL,NULL,NULL,NULL),(7,'34/2018','SAKHEER','29','PUTHIYA NALAKATH (H)\nRANJATOOR\nKUTTIPPURAM','','M','KUTTIPPURAM','23','8129557504','9048476934','2019-08-14 00:00:00',NULL,NULL,'','ORGANIC MOOD DISORDER',0,'NADUVETTAM','',NULL,NULL,NULL,NULL),(8,'27/2017','FADALU (FAIZAL)','37','KOTHUVAAL PARAMBIL (H)\nVELLANJERI\nKUTTIPPURAM','','M','THAVANUR','6','9895578173','7034082787','2019-08-14 00:00:00',NULL,NULL,'','PSYCHOSIS NOS',0,'MADHIRASHERY','',NULL,NULL,NULL,NULL),(9,'134/2020','MADHU','39','AVAKKATHU PARAMBIL (H)\nPERASANNUR\nKUTTIPPURAM','','M','KUTTIPPURAM','12','9539023518','','2020-10-10 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(10,'79/2021','HAMEED','46','KUNDIPARUTHI (H)\nEDACHALAM\nKUTTIPPURAM','','M','KUTTIPPURAM','12','8606469004','','2021-04-01 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(11,'93/2017','SOORAJ','31','MANGATTIL (H)\nMADHIRASHERY\nTHAVANUR','','M','THAVANUR','7','7034532800','9061592518','2019-08-14 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'THRIKKANNAPURAM','',NULL,NULL,NULL,NULL),(12,'059/2021','YASHODHA','45','MADAMBATH PALLI (H)\nKAAILAS NH\nKUTTIPPURAM','','F','KUTTIPPURAM','19','9995186729','','2021-01-29 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'KUTTIPPURAM SOUTH','',NULL,NULL,NULL,NULL),(13,'38/2017','UNNEENKUTTY','62','KURIPARAMBIL (H)\nPAIGANNUR\nKUTTIPPURAM','','M','KUTTIPPURAM','10','9847447392','','2019-08-14 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(14,'75/2019','UNNIKRISHNAN','22','OZHUPARAKKAL (H)\nNADUVATTAM\nMANNIYAMKADU\nKUTTIPPURAM','','M','KUTTIPPURAM','1','9048882387','9526667938','2019-08-14 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'NADUVETTAM','',NULL,NULL,NULL,NULL),(15,'04/2018','ABDUL SAMAD','36','KOORIPARAMBIL (H)\nKOORADA\nTHAVANUR','','M','THAVANUR','8','9947908333','','2019-08-14 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'AAIGALLAM','',NULL,NULL,NULL,NULL),(16,'168/2021','FATHIMAKUTTY','50','KURIPARAMBIL (H)\nPAIGANOOR\nKUTTIPPURAM','','F','KUTTIPPURAM','8','9847447392','','2021-07-09 00:00:00',NULL,NULL,'','MILD DOPRESSION',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(17,'89/2018','MUHAMMAD','58','THADATHIL (H)\nKAZHUTHALLUR\nPALLIPADI\nKUTTIPPURAM','','M','KUTTIPPURAM','19','8606437386','','2019-08-14 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(18,'116/2019','SUBAIDA','48','PADATH PEEDIYAKKAL (H)\nPERASHANNOOR\nKUTTIPPURAM\n','','F','KUTTIPPURAM','12','9961521565','8921360184','2019-08-14 00:00:00',NULL,NULL,'','INTELLECTUAL DISSABILITY +PSYCHOSES NOS',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(19,'158/2020','SUBRAHMANYAN','47','KANDANAKATH PARAMBIL (H)\nKAZHIRAKUTTI\nTHRIKKANNAPURAM\nTHAVANUR','','M','THAVANUR','11','9995218236','9544525277','2020-08-12 00:00:00',NULL,NULL,'','PSYCHOSIS NOS',0,'THRIKKANNAPURAM','',NULL,NULL,NULL,NULL),(20,'83/2019','FARSANA THASNI','18','KAILASSERI (H)\nRANGATTOOR \nKUMBIDY\nTHAVANUR','','F','THAVANUR','20','9633601396','','2019-08-14 00:00:00',NULL,NULL,'','SEIZURE DISORDER',0,'NADUVETTAM','',NULL,NULL,NULL,NULL),(21,'9/2018','RAFEENA','29','PANTHAL PULAKKAL (H)\nKOLLAKKADU\nKUTTIPPURAM','','F','KUTTIPPURAM','13','7034398883','9037214824','2019-08-14 00:00:00',NULL,NULL,'','PSYCHOSIS NOS',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(22,'112/2018','FOUSIYA','34','ARIYAN KALAYIL (H)\nEDACHALAM\nKUTTIPPURAM','','F','KUTTIPPURAM','12','9539166474','','2019-08-14 00:00:00',NULL,NULL,'','PSYCHOSIS NOS',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(23,'36/2020','UMMUHABEEBA','34','PAADATH (H)\nPERUMPARAMBU\nKUTTIPPURAM','','F','KUTTIPPURAM','7','9746604195','','2020-02-20 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(24,'58/2021','SUMAYYA','27','NADUVATH (H) \nKADAKKASSERI\nTHAVANUR','','F','THAVANUR','4','6235444722','7034050632','2021-03-25 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER +OCD',0,'THRIKKANNAPURAM','',NULL,NULL,NULL,NULL),(25,'88/2017','MUHAMMAD RAFI','38','POOKOTTUVALAPPIL (H)\nKOLAKAD\nKUTTIPPURAM','','M','KUTTIPPURAM','13','8943439438','','2019-08-14 00:00:00',NULL,NULL,'','MENTAL RETARDATION WITH PSYCHOTIC DISORDER',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(26,'157/2019','FATHIMMA','58','KARUVANKATT KAVIL (H)\nPAKKARANELLUR\nKUTTIPPURAM','','F','KUTTIPPURAM','3','9539223425','','2019-09-12 00:00:00',NULL,NULL,'','PSYCHOSIS NOS ',0,'NADUVETTAM','',NULL,NULL,NULL,NULL),(27,'138/2019','UMMAR','50','MURAM KUZHIKUND VALAPPIL (H)\nPAZHUR\nKUTTIPPURAM','','M','KUTTIPPURAM','21','9895983217','04942571936','2019-08-26 00:00:00',NULL,NULL,'','PSYCHOSIS NOS',0,'NADUVETTAM','',NULL,NULL,NULL,NULL),(28,'140/2019','SHAFEEL','23','KUNDANIYIL (H)\nABUDABIPPADI\nPAINKANNUR\nKUKKIPPURAM','','M','KUTTIPPURAM','21','8606707086','9747698195','2019-08-28 00:00:00','2021-10-08 00:00:00',NULL,'','MENTAL RETARDATION WITH PSYCHOTIC DISORDER',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(29,'77/2017','SUHARA','34','THADATHIL (H)\nKACHERIPPARAMBU\nKALADI','','F','KALADI','6','9847445206','','2019-08-16 00:00:00',NULL,NULL,'','OCD ',0,'THRIKKANNAPURAM','',NULL,NULL,NULL,NULL),(30,'76/2021','SHEEJA','38','POOZHAKKAL (H)\nTHAVANUR','','F','THAVANUR','9','9061344194','','2021-04-01 00:00:00','2022-06-10 00:00:00',NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'MADHIRASHERY','',NULL,NULL,NULL,NULL),(31,'45/2017','KORAN','59','MENOTH VALQAPPIL (H)\nVELLANJERI\nTHAVANUR','','M','THAVANUR','6','9645298895','','2019-08-16 00:00:00',NULL,NULL,'','PSYCHOSIS NOS , SEIZURE DISORDER',0,'MADHIRASHERY','',NULL,NULL,NULL,NULL),(32,'161/2019','ASHRAF CP','42','CHELAKKARA PALLIYALIL (H)\nKULAKAD\nKUTTIPPURAM','','M','KUTTIPPURAM','13','7592895467','8156937187','2019-09-16 00:00:00',NULL,NULL,'','DEPRESSION',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(33,'63/2018','BABY','47','CHEROOLIPARAMBIL (H)\nPERASHANNOOR\nKUTTIPPURAM','','F','KUTTIPPURAM','12','9846908412','','2019-08-16 00:00:00',NULL,NULL,'','AFFECTIVE PSYCHOSIS , PSYCHOSIS NOS',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(34,'06/2018','BIYYUTTI PP','50','PARAPPARA (H)\nCHELLUR\nKUTTIPPURAM','','F','KUTTIPPURAM','4','8943647324','','2019-08-16 00:00:00','2022-01-18 00:00:00',NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(35,'088/2017','MUHAMMAD RAFEEQ','30','POOKOTTU VALAPPIL (H)\nKOLKKAD\nKUTTIPPURAM','','M','KUTTIPPURAM','13','7034901389','8943439438','2019-08-16 00:00:00',NULL,NULL,'','PSYCHOSIS NOS',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(36,'54/2017','PUSHPAVATHI','48','PANNIKOT PARAMBIL (H)\nRANGATTOOR\nKUMBIDI\nKUTTIPPURAM','','F','KUTTIPPURAM','23','9946735638','','2019-08-16 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'NADUVETTAM','',NULL,NULL,NULL,NULL),(37,'01/2018','ABDUL NAZAR','44','CHERALA (H)\nMOODAL\nKUTTIPPURAM\n','','M','KUTTIPPURAM','5','9846399572','','2019-08-16 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(38,'136/2020','MUHAMMADALI','50','KAIPATHODIYIL (H)\nMOODAL\nKUTTIPPURAM','','M','KUTTIPPURAM','5','9947836187','','2019-10-21 00:00:00','2021-09-02 00:00:00',NULL,'','PSYCHIATRY',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(39,'49/2017','RUKKIYA','52','CHELAKKARA (H)\nKOLAKKAD \nKUTTIPPURAM','','F','KUTTIPPURAM','7','7559885495','','2019-08-16 00:00:00',NULL,NULL,'','PSYCHOSIS NOS',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(40,'48/2017','ABDUL HASEEB','23','PUTHAN PEEDIKAYIL (H)\nTHRIKKANNAPURAM\nTHAVANUR\nVELLANCHERY','','M','THAVANUR','6','9745381678','','2019-08-16 00:00:00',NULL,NULL,'',' MILD INTELLECTUAL DISABILITY',0,'THRIKKANNAPURAM','',NULL,NULL,NULL,NULL),(41,'99/2019','SUNIL','34','CHELAKKAD PARAMBIL (H)\nCHELLUR\nPAZHUR\nKUTTIPPURAM','','M','KUTTIPPURAM','5','9544083807','9061858005','2019-08-16 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(42,'77/2021','VIJAYAKUMARI','34','PUZHZKKAL (H)\nTHAVANUR','','F','THAVANUR','9','9061344194','','2021-04-01 00:00:00','2022-06-10 00:00:00',NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'MADHIRASHERY','',NULL,NULL,NULL,NULL),(43,'67/2021','ANEESHA','23','ALATH (H)\nKUMARANELLUR\nKAPPUR','','F','KAPPUR','16','9995059868','8075268164','2021-03-11 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'OTHERS','',NULL,NULL,NULL,NULL),(44,'205/2019','SUBAIDA','32','KALATHILTHODI (H)\nOOROTHPALLIYAL\nKUTTIPPURAM','','F','KUTTIPPURAM','3','8086564606','9048905422','2019-11-25 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'NADUVETTAM','',NULL,NULL,NULL,NULL),(45,'144/2019','JAMSHI','35','PALLIMANJALIL (H)\nCHELLUR\nKUTTIPPURAM','','F','KUTTIPPURAM','5','6238720947','7306648637','2019-09-02 00:00:00','2022-07-15 00:00:00',NULL,'','INTELLECTUAL DISABILITY',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(46,'112/2017','SAIFUNEESA','34','CHERALA (H)\nKOLAKAD\nKUTTIPPURAM','','F','KUTTIPPURAM','13','9562229361','','2019-08-16 00:00:00',NULL,NULL,'','PSYCHOSIS NOS',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(47,'60/2021','CHITHRA RK','26','RAMANKULANGARA (H)\nPAZHOOR OP\nCHELLUR\nKUTTIPPURAM','','F','KUTTIPPURAM','5','8606119251','9745672371','2021-03-11 00:00:00','2022-02-18 00:00:00',NULL,'','OCD ',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(48,'07/2017','FATHIMMA','35','THALAKUTTI PARAMBIL (H)\nPALLIPPADI\nKUTTIPPURAM','','F','KUTTIPPURAM','19','9562761691','','2019-08-16 00:00:00',NULL,NULL,'','MENTAL RETARDATION WITH PSYCHOTIC DISORDER',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(49,'14/2021','PRIYA','40','PALLIYALIL (H)\nCHELLUR\nKUTTIPPURAM','','F','KUTTIPPURAM','5','9745672371','','2021-01-01 00:00:00','2022-04-08 00:00:00',NULL,'','DEPRESSION',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(50,'137/2020','SADHASHIVAN','40','PALLIYAL PARAMBIL (H)\nSOUTH BAZAR\nKUTTIPPURAM','','M','KUTTIPPURAM','17','9745582404','8593812054','2020-10-10 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'KUTTIPPURAM SOUTH','',NULL,NULL,NULL,NULL),(51,'191/2020','HABEEDH','32','RAAIM MARANAR VITTIL (H)\nEDAPPAL','','M','EDAPPAL','8','9567183400','','2020-12-23 00:00:00','2021-06-16 00:00:00',NULL,'','PERSONALITY DISORDER',0,'NADUVETTAM','',NULL,NULL,NULL,NULL),(52,'65/2021','MUHAMMAD ISMAIL PM','35','PUTHIYAMALITEKKAL (H)\nVATTAMKULAM PO\nVATTAMKULAM','','M','VATTAMKULAM','','9895497670','','2021-03-11 00:00:00',NULL,NULL,'','SCHIZAPHRENIA',0,'OTHER','',NULL,NULL,NULL,NULL),(53,'40/2019','SUHARA','42','CHERAYA PATHAYAKKALILL (H)\nMOODAL\nKUTTIPPURAM','','F','KUTTIPPURAM','','7293923837','','2019-08-28 00:00:00','2021-07-30 00:00:00',NULL,'','PSYCHIATRY',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(54,'147/2019','MUHAMMAD','62','PUTHUR VALLAPPIL (H)\nAAIGALLAM\nTHAVANUR','','M','THAVANUR','15','9446788167','8547940167','2019-09-03 00:00:00','2021-07-30 00:00:00',NULL,'','PSYCHIATRY',0,'AAIGALLAM','',NULL,NULL,NULL,NULL),(55,'33/2017','NAUSHEEJA','34','KIYAGATH PARAMBIL (H)\nD/O KUNJTHU\nMOODAL\nPAIGANNUR \nKUTTIPPURAM','','F','KUTTIPPURAM','','7592808686','8129408711','2019-08-23 00:00:00','2021-07-30 00:00:00',NULL,'','PSYCHIATRY',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(56,'186/2019','KILLAR','60','VARRIKKAPULAKAL (H)\nKAZHUTHALLUR\nKUTTIPPURAM','','M','KUTTIPPURAM','19','7356414991','7034720540','2019-10-21 00:00:00','2021-07-30 00:00:00',NULL,'','PSYCHIATRY',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(57,'210/2019','FATHIMMA','51','POTTAMMAL VAGAAILL (H)\nEDACHALLAM\nKUTTIPPURAM','','F','KUTTIPPURAM','12','9745204211','9745571439','2019-11-30 00:00:00','2021-07-30 00:00:00',NULL,'','PSYCHIATRY',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(58,'78/2017','REJEENA','38','KARIBNITHODI (H)\nMARKAZ MOODAL\nKUTTIPPURAM','','F','KUTTIPPURAM','13','8606488588','9567377258','2019-08-25 00:00:00','2021-07-30 00:00:00',NULL,'','PSYCHIATRY',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(59,'64/2021','IBRAHIM MATHAR','22','POTTACHOLA (H)\nANANTHAVOOR\nTHIRUNAVAYA','','M','THIRUNAVAYA','19','9895497670','','2021-03-11 00:00:00','2021-04-30 00:00:00',NULL,'','PSYCHIATRY',0,'OTHER','',NULL,NULL,NULL,NULL),(60,'62/2021','AFSAL','37','KOTTARATHOPPIL (H)\nPALLIKKARA PO\nNANNAMMUKKU\nMALAPPURAM','','M','NANNAMMUKKU','8','9048037786','9400146788','2021-03-11 00:00:00','2021-04-30 00:00:00',NULL,'','PSYCHIATRY',0,'OTHER','',NULL,NULL,NULL,NULL),(61,'66/2021','ANSIF PV','18','PALLATHUVALAPPIL (H)\nKUMARNELLUR','','M','KAPPUR','18','9895497670','9961512089','2021-03-11 00:00:00','2021-04-30 00:00:00',NULL,'','PYSCHIATRY',0,'OTHER','',NULL,NULL,NULL,NULL),(62,'63/2021','MUHAMMAD KADAR PC','49','POTTACHOLA (H)\nANANTHAVOOR OP\nPATTARNADAKKAVU\nTHIRUNAVAYA','','M','THIRUNAVAYA','19','8943955689','','2021-03-11 00:00:00','2021-04-30 00:00:00',NULL,'','PSYCHIATRY',0,'OTHER','',NULL,NULL,NULL,NULL),(63,'5/2018','KOYAKKUTTI','48','PARAPPARA (H)\nCHELLUR\nMOODAL\nKUTTIPPURAM\n','','M','KUTTIPPURAM','4','9747748381','9645265839','2019-08-27 00:00:00','2021-08-01 00:00:00',NULL,'','SCHIZOPHORENIFORM DISORDER ',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(64,'80/2020','SAJNA','29','NURUKUNNDIAILL (H)\nPAINGANNUR\nKUTTIPPURAM\n','','F','KUTTIPPURAM','10','9048289797','8086515930','2020-07-08 00:00:00','2021-06-11 00:00:00',NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(65,'115/2019','SEENATH','30','KUNJANAMKATTILL (H)\nEDACHELLAM\nKUTTIPPURAM','','F','KUTTIPPURAM','12','9946878288','','2019-08-28 00:00:00','2021-03-25 00:00:00',NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(66,'79/2019','SAJINI','40','THORAKATTIL THODI (H)\nCHELLOOR\nKUTTIPPURAM','','F','KUTTIPPURAM','1','9946641052','8943630132','2019-08-28 00:00:00','2021-02-28 00:00:00',NULL,'','PSYCHIATRY',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(67,'94/2020','ABDULMOLLA ','92','KARUVATTILL (H)\nPAGARANALLOR\nKUTTIPPURAM','','M','KUTTIPPURAM','','8086779971','','2020-06-06 00:00:00','2021-02-28 00:00:00',NULL,'','PSYCHIATRY',0,'MADHIRASHERY','',NULL,NULL,NULL,NULL),(68,'204/2019','JAYAN','32','MANNARAPARAMBILL (H)\nNADUVETTAM\nNAGAPPARAMBU\n\n','','M','KUTTIPPURAM','22','9048883723','9744942105','2019-11-25 00:00:00','2021-07-30 00:00:00',NULL,'','PSYCHIATRY',0,'NADUVETTAM','',NULL,NULL,NULL,NULL),(69,'143/2019','KADHEEJA','52','PALLIMANJANLILL (H)\nCHELLUR\nKUTTIPPURAM','','F','KUTTIPPURAM','5','6238720947','7306648637','2019-09-02 00:00:00','2021-02-28 00:00:00',NULL,'','PSYCHOSIS NOS',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(70,'94/2015','SHARADHA','79','PALLATH PARAMBILL (H)\nKADAGASHERI\nAAIGALAM','','F','THAVANUR','4','9048430031','','2019-08-28 00:00:00','2021-02-28 00:00:00',NULL,'','PSYCHIATRY',0,'AAIGALLAM','',NULL,NULL,NULL,NULL),(71,'189/2020','MOAIDHEENKUTTI','67','PARAKKAL (H)\nMOODAL\nKUTTIPPURAM','','M','KUTTIPPURAM','5','9946934723','8606520522','2020-12-29 00:00:00','2021-02-28 00:00:00',NULL,'','PSYCHIATRY',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(72,'45/2020','HAFSATH','32','KUNNDIPPARUTHI\nEDACHELLAM','','F','KUTTIPPURAM','12','9745254190','','2020-03-04 00:00:00','2021-07-30 00:00:00',NULL,'','PSYCHIATRY',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(73,'186/2020','VELAYUDHAN','57','CHIRAKKUYIYILL (H)\nMADHIRASHERY\n\n','','M','THAVANUR','','8943409919','9544520073','2020-12-30 00:00:00','2021-02-28 00:00:00',NULL,'','PSYCHIATRY',0,'MADHIRASHERY','',NULL,NULL,NULL,NULL),(74,'174/2020','AYISHA','70','VALLIKOOTTA PARAMBIL (H)\nMARKAZ MOODAL\nKODDIKUNN\n','','F','KUTTIPPURAM','7','9562038208','9526517073','2020-12-17 00:00:00','2021-02-28 00:00:00',NULL,'','PSYCHIATRY',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(75,'165/2019','SUMAYYA','35','CHULATT VATTAVANNALL (H)\nCHELAKKAL \nEDACHELAM','','F','KUTTIPPURAM','8','9633750034','','2019-09-19 00:00:00','2021-02-28 00:00:00',NULL,'','PSYCHIATRY',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(76,'0112/2017','ZEHARABI','30','POOKOTTUVALAPILL (H)\nKOLAKKADU\nKUTTIPPURAM','','F','KUTTIPPURAM','13','8943439438','','2021-06-16 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(77,'92/2018','CHEKUTTI','40','KALLUGHALL (H)\nPAGARANELLOOR','','M','KUTTIPPURAM','','8113817853','','2019-08-29 00:00:00',NULL,NULL,'',' MILD INTELLECTUAL DISABILITY',0,'AAIGALLAM','',NULL,NULL,NULL,NULL),(78,'105/2014','SUBAIDA','36','PUTTUPARAMBIL (H)\nVELLANCHERY\nTHAVANUR','','F','THAVANUR','7','9846441142','','2019-08-29 00:00:00','2022-04-23 00:00:00',NULL,'','ORGANIC DISORDER , CVA',0,'NADUVETTAM','',NULL,NULL,NULL,NULL),(79,'44/2020','MOHAMMAD ASHIQ','16','DHITTAGATH (H)\nEDAKKULLAM\nTHIRUNAVAYA','','M','THIRUNAVAYA','1','9496759599','','2020-03-04 00:00:00',NULL,NULL,'','OCD ',0,'OTHER','',NULL,NULL,NULL,NULL),(80,'135/2018','SOUDHA','33','CHAPPINASHERI (H)\nCHELLUR\n','','F','KUTTIPPURAM','6','9633431359','','2019-08-29 00:00:00',NULL,NULL,'','SEIZURE DISORDER',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(81,'106/2017','VIJAYALAKSHMI','60','MURIGHOLTHODI (H)\nVELLANCHERY','','F','THAVANUR','21','9562231730','7591928181','2019-08-29 00:00:00',NULL,NULL,'','PSYCHOSIS NOS',0,'MADHIRASHERY','',NULL,NULL,NULL,NULL),(82,'44/2017','ABUBAKAR','62','CHULLIYAL (H)\nKUTTIPPURAM','','M','KUTTIPPURAM','','9895349590','','2019-08-29 00:00:00','2022-10-28 00:00:00',NULL,'','VASCULAR DEMENTIA',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(83,'135/2020','ALAVI','72','PALLIMANJNALILL (H)\nCHELLUR','','M','KUTTIPPURAM','','8086280486','9074520547','2020-10-21 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(84,'26/2017','ABDURAHMAN','58','PALLIMANJNALILL (H)\nCHELLUR','','M','KUTTIPPURAM','','8129200547','','2019-08-29 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(85,'15/2021','KADHEEJA','35','KUNNATHU (H)\nPANNDIGASHALA \n\n','','F','KUTTIPPURAM','','7034655709','','2021-01-13 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(86,'137/2017','MUJEEBRAHMAN','38','MANNUPPARAMBIL (H)\nPALLIPPADI\nKUTTIPPURAM','','M','KUTTIPPURAM','','9747897781','','2019-08-29 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER , CORONARY ARTERY DISEASE',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(87,'211/2019','RAJAN','26','THADATHIL PALLIYALIL (H)\nTHRIKKANNAPURAM\nPADDAPARAMBU\nTHAVANUR','','M','THAVANUR','11','9645787010','','2019-12-07 00:00:00',NULL,NULL,'','SEIZURE DISORDER',0,'THRIKKANNAPURAM','',NULL,NULL,NULL,NULL),(88,'195/2021','AYISHA','60','PARAKKATT (H) \nKALADI\nNADAKKAV STOP','','F','VATTAMKULAM','1','9846713040','','2021-08-21 00:00:00','2021-12-24 00:00:00',NULL,'','SOMATOFORM DISORDER',0,'OTHER','',NULL,NULL,NULL,NULL),(89,'196/2021','MUHAMMAD KUTTI','47','THADATHIL (H)\nKACHERIPARAMBU\nKALADI','','M','KALADI','6','8943384762','','2021-08-21 00:00:00',NULL,NULL,'','PSYCHOSIS NOS',0,'THRIKKANNAPURAM','',NULL,NULL,NULL,NULL),(90,'202/2021','SHAJI','48','KONDAMPARAKKAL (H)\nCHELLUR\nKUTTIPPURAM','','M','KUTTIPPURAM','5','9747973554','','2021-09-03 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'CHELLUR , MOODAL','','2021-09-03 00:00:00','He is currently undergoing treatment\nMedicine, Clonazepam 0.5MG          0-0-1\n',1,' Fear , Shortness of breath , insomnia\n'),(91,'204/2021','KADHEEJA','47','THANDA VALAPPIL (H)\nCHELLUR \nKUTTIPPURAM','','F','KUTTIPPURAM','6','9747231957','','2021-09-03 00:00:00','2022-04-08 00:00:00',NULL,'','PSYCHIATRY',0,'CHELLUR , MOODAL','','2021-09-03 00:00:00','SHE WAS CONSULTED BY DR . ABDURAHAMAN (NERO) \n\n',1,'KADHEEJA \'S MOTHER WAS VERY HYGEINIC TOO\nHOUSE IS BELLT AFTER SELLING HUSBAND\'S SHARE'),(92,'203/2021','MURSHIDHA FATHIMMA','13','CHAKKAIL PARAMBIL (H) \nEDAKKULAM \nTHIRUNAVAYA','','F','THIRUNAVAYA','8','7902691525','','2021-09-03 00:00:00','2022-02-18 00:00:00',NULL,'','PSYCHIATRY',0,'OTHER','','2021-09-03 00:00:00','MOTHER HAD PROBLEMSS IN BOTH DELIVERY TIME \nSHE WAS TREATED AT VRC \n',1,'HER UNCLE IS A PSYCHIATRIC PATIENT HE IS UNDER TREATMENT NOW'),(93,'78/2021','FATHIMMA SUHARA','32','THEKKEPPIDIYEKKAL (H)\nPANDDIKASHALA\nKUTTIPPURAM','','F','KUTTIPPURAM','9','6238943807','9562670619','2020-08-23 00:00:00','2021-08-12 00:00:00',NULL,'','PSYCHIATRY',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(94,'206/2021','FARHANA SHIRIL','25','MUMUKKIL (H) \nPERASSANUR\nKUTTIPPURAM','','F','KUTTIPPURAM','11','9567420413','8086643541','2021-09-10 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'PERASHANNOOR','','2021-09-10 00:00:00','',1,'SLEEP LESS\nANGER\nOCD\n'),(95,'205/2021','SAINABA','60','AMBALA PARAMBIL (H)\nIRUMBILIYAM\nVALANCHERY','','F','IRUMBILIYAM','13','9539624731','7510950422','2021-09-10 00:00:00','2022-01-04 00:00:00',NULL,'','PSYCHIATRY',0,'OTHER','','2021-09-10 00:00:00','',1,'SLEEP LESS\nHEAD ACH\nANGER\nWALKING '),(96,'130/2017','MOIDHEEN KUTTI','48','AYAMKULLAM (H)\nKARAMBATHUR','','M','PARUTTUR','1','9633980180','','2021-02-09 00:00:00','2021-08-12 00:00:00',NULL,'','PSYCHIATRY',0,'OTHER','',NULL,NULL,NULL,NULL),(97,'224/2019','AYISHABEEVI','68','KIZHAKKINAKKATH (H)\nCHELLUR\nKUTTIPPURAM','','F','KUTTIPPURAM','6','9526957348','8848990082','2019-12-31 00:00:00','2021-08-11 00:00:00',NULL,'','PSYCHIATRY',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(98,'192/2020','YAHUTTI','55','KALARRIPPARAMBIL (H)\nCHELLUR\nKUTTIPPURAM','','M','KUTTIPPURAM','4','8589800974','','2020-12-02 00:00:00','2021-08-27 00:00:00',NULL,'','PSYCHIATRY',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(99,'078/2021','MANIKANDAN','40','POOZHAKKAL (H)\nTHAGALLPPADI \nTHAVANUR','','M','THAVANUR','9','9061344194','','2021-03-01 00:00:00','2022-06-10 00:00:00',NULL,'','PSYCHOSIS NOS',0,'THRIKKANNAPURAM','',NULL,NULL,NULL,NULL),(100,'0130/2017','SHANDHA','59','KUTTIYATILL (H)\nPERASHANNOOR\nKUTTIPPURAM','','F','KUTTIPPURAM','11','8848110869','','2017-10-24 00:00:00',NULL,NULL,'','RECCURENT DEPRESSIVE DISORDER',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(101,'8/2014','DHANISHMA','13','CHERRELLI (H)\nTHRIKKANNAPURAM\nTHAVANUR','','F','THAVANUR','8','9746670805','7025013751','2014-09-30 00:00:00',NULL,NULL,'','MENTAL RETARDDATION',0,'THRIKKANNAPURAM','',NULL,NULL,NULL,NULL),(102,'231/2021','MUHAMMAD IQBAL','46','AMBALAPARAKKAL (H)\nMARAVANCHERY\nTHAVANUR','','M','THAVANUR','','9539554407','9567038608','2021-09-27 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'AAIGALLAM','','2021-09-27 00:00:00','   SELF TALK\n  INCCOEASED TALK\n  AGGRESSION ( USING ABUSIVE WWORDS )\nSUSPECIONSNESS ( TRY TO KILL ME )\nCHILDREN AND WIFE ARE NOT MINE\nSEEING DEVILS',1,'NO HISTORY OF SEIZMES\nNO HISTORY OF HEAD INJORY'),(103,'230/2021','NUSAIBA','31','MULLAKKAL (H)\nNOLANIPPOTTA\nKOTTAPPURAM\nIRIMBILIYAM','','F','IRIMBILIYAM','','9847271731','8389800405','2021-09-27 00:00:00','2022-02-18 00:00:00',NULL,'','DELUSIONAL DISORDER',0,'OTHER','',NULL,NULL,NULL,NULL),(104,'232/2021','USMAN','52','TORAAIL (H)\nKUMMARANALLUR\nNEW HS\n','','M','','','9567714279','9745872078','2021-10-01 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'OTHER','','2021-10-08 00:00:00','HE WAS ADMITTED AT THE TIME OF THE OCCASIONAL DEPRESSION\nHE\'S FATHER\'S BROTHER WAS MENTALLY ILL',1,'NO ANY SYMPTOS\nSODIUM VALPORATE   300 - 0 - 500\nQUTIAPIN                       0-0-50\nCLONAZEPAM                0-0-0.25\nTHP      2MG                    1-1-0\nRISPERIDONE   2MG      0.5-0-1   '),(105,'247/2021','NOUSHAD ','52','CHELAKOTTIL (H)\nKUMARANELLOOR \n','','M','','','8129182067','8138870053','2021-10-22 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'','','2021-10-22 00:00:00','DOUBT (WIFE) , ANGER , EPILEPSY',1,'IN THE ACCIDENT , THE SKULL RUPTURED AND PART OF THE SKULL WAS REMOVED'),(106,'248/2021','RAMLA','38','THORAAIL (H)\nKUMARANNULLOOR','','F','','','9567714279','9745872078','2021-10-29 00:00:00','2022-11-04 00:00:00',NULL,'','PSYCHIATRY',0,'','',NULL,NULL,NULL,NULL),(107,'251/2021','ANOOP NARAYANAN','40','','','M','','','8086102692','9946411733','2021-11-12 00:00:00','2022-02-18 00:00:00',NULL,'','PSYCHIATRY',0,'OTHER','',NULL,NULL,NULL,NULL),(108,'250/2021','HASEENA ','39','POOYIKUNATH (H)\nPAIKANUR \nPERASHANOOR \nKUTTIPPURAM ','','F','KUTTIPPURAM','','8590523047','','2021-11-05 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(109,'264/2021','MUHAMMED IQBAL','29','PUTHUPPARAMBIL (H)\nTHAVANUR','','M','THAVANUR','','9895461813','','2021-11-12 00:00:00','2022-06-10 00:00:00',NULL,'','PSYCHIATRY',0,'','',NULL,NULL,NULL,NULL),(110,'249/2021','SUDHAKARAN','55','RAMANKULLANGHARA (H)\nCHELLUR \nKUTTIPPURAM','','M','KUTTIPPURAM','','9645127134','','2021-11-05 00:00:00',NULL,NULL,'','DEPRESSION',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(111,'262/2021','SAINUDHEEN','41','ADHIKARATHU VALLAPPIL (H)\nKUTTIPPURAM','','M','KUTTIPPURAM','14','6238694596','','2021-11-05 00:00:00','2021-11-12 00:00:00',NULL,'','PSYCHIATRY',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(112,'288/2021','SABIRA','39','PALATTUVALAPPIL (H)\nPALLIPPADI\nKAZHUTHALLUR\nKUTTIPPURAM','','F','KUTTIPPURAM','','9048767085','9947849672','2021-11-30 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(113,'287/2021','AYISHA','40','PARATHODIYIL (H)\nPAKARANALLUR\nKUTTIPPURAM','','F','KUTTIPPURAM','','9526206305','','2021-11-26 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'NADUVETTAM','',NULL,NULL,NULL,NULL),(114,'263/2021','FATHIMMA PP','56','ANTHUPARAMBIL (H)\nAYINKALAM','','F','','','9496848845','','2021-11-12 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'AAIGALLAM','',NULL,NULL,NULL,NULL),(115,'291/2021','AMINA','70','POOTHUR VALLAPPIL (H) \nKOLLAKAD\nKUTTIPPURAM','','F','KUTTIPPURAM','','8086233157','','2021-12-24 00:00:00','2022-09-30 00:00:00',NULL,'','PSYCHIATRY',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(116,'289/2021','DILEEP VM','36','VAYYAVANATHU MATTUMMAL (H)\nPERASHANNOOR\nKUTTIPPURAM','','M','KUTTIPPURAM','','8086532803','9539411718','2021-12-24 00:00:00','2022-03-04 00:00:00',NULL,'','PSYCHIATRY',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(117,'292/2021','ABDUL NAZAR','48','VALLIYIL (H)\nKAZHUTHALLUR\nKUTTIPPURAM','','M','KUTTIPPURAM','','9656736495','','2021-12-24 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(118,'290/2021','SHAHUL HAMEED','24','KORATH MELETHIL (H)\nKOLAKKADU\nKUTTIPPURAM','','M','KUTTIPPURAM','','7356463270','','2021-12-24 00:00:00','2022-06-23 00:00:00',NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(119,'293/2021','CHEKKUTTI','50','KORATH POOYUKKATTODI (H)\nKUTTIPPURAM','','M','KUTTIPPURAM','','9037713161','','2021-12-24 00:00:00','2021-12-24 00:00:00',NULL,'','PSYCHIATRY',0,'','','2021-12-24 00:00:00','FINANCIALLY BETTER\nALL THE CHILDRENS ARE ABROAD AND HAVE A DECENT INCOME',0,''),(120,'02/2022','GIRIJA','45','THEKKAPARAKKAL (H)\nEDDACHARA','','F','','','9645883571','','2021-12-31 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'','',NULL,NULL,NULL,NULL),(121,'03/2022','SUBAIDHA','48','KORATH MELETTIL (H)\nKUTTIPPURAM','','F','KUTTIPPURAM','','7356463270','','2022-01-07 00:00:00','2022-05-20 00:00:00',NULL,'','PSYCHIATRY',0,'','',NULL,NULL,NULL,NULL),(122,'04/2022','BIJU','42','NADUVILL VITTIL (H)\nKALADI \nNADAKKAV','','M','KALADI','','9961261872','9400944872','2022-01-11 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'OTHER','',NULL,NULL,NULL,NULL),(123,'05/2022','SHAMEERALI','20','CHAOLLAKKAL (H)\nKODIKKUNNU','','M','','','9539956189','7034475189','2022-01-11 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'OTHER','',NULL,NULL,NULL,NULL),(124,'56/2022','UNNIKRISHNAN','34','KOTHALAM KUNNATH (H)\n','','M','','','9539717768','','2022-03-01 00:00:00',NULL,NULL,'','PSYCHOSIS NOS',0,'','',NULL,NULL,NULL,NULL),(125,'54/2022','THITHUMMU','70','','','F','','','','','2022-05-05 00:00:00',NULL,NULL,'','A NOS',0,'','',NULL,NULL,NULL,NULL),(126,'52/2022','ISMAIL','59','KUNNATH (H)\nVALANCHERY PO \nKUTTIPPURAM \nKATTIPPARUTHI','','M','VALANCHERY','','9747893768','8606331341','2022-02-18 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'OTHER','',NULL,NULL,NULL,NULL),(127,'78/2022','MOHAMMED SINAN ','18','PADATH PIDIKAIL (H)\nPERASSANOOR KUTTIPPURAM ','','M','KUTTIPPURAM','12','9048224439','','2022-05-10 00:00:00','2022-05-18 00:00:00',NULL,'','PSYCHIATRY',0,'PERASHANNOOR','','2022-05-17 00:00:00','NILAVILLE SAHAJARYTHIL EDUKAN KAZHIYILA . MARUNUM CHIGILSAYUM MHAT KODUKADHE THANE AVARKU KITTAVUNNA SAHACHARYMANN IPOLL ULADH ',0,''),(128,'130/2022','AHAMMED KUTTY','74','MOORSHINGANAKATH(H)\nPARAPPURAM\nKADAVANJERRY \nKALADI','','M','KALADI','4','7510273688','7510335778','2022-07-27 00:00:00',NULL,NULL,'','ORGANIC PSYCHOSIS',0,'','','2022-07-26 00:00:00','',1,''),(129,'0078/2022','SREEDEVI','36','PARAKKAL (H)\nPAINGANOOR \nKUTTIPPURAM \n','','F','KUTTIPPURAM','10','9778206949','','2022-04-22 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(130,'97/2022','SAMEERA','39','KUNNATH (H)\nPAINGANOOR \nPANDDIGASHALA\nKUTTIPPURAM','','F','KUTTIPPURAM','','9747405520','8921741618','2022-05-27 00:00:00',NULL,NULL,'','PASYCHIATRY',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(131,'58/2022','MAJID MUHSIN ','26','CHOLAYIL THAYADHIL (H)\nTHIRIKANAPURAM \nNADAKAVU','','M','','','9446878526','','2022-04-28 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'THRIKKANNAPURAM','',NULL,NULL,NULL,NULL),(132,'90/2022','MOHAMMED RUFAID ','12','VAKAYIL (H)\nKAZHUTHALLOOR \nASHUPATHIRIPADI\n','','M','KUTTIPPURAM','19','9747751424','','2022-05-27 00:00:00',NULL,NULL,'','SEIZURE DISORDER',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(133,'92/2022','MOHAMMED ','42','PERUMBATH VALAPPIL (H)\nCHEGHANUR','','M','','','9745426412','','2022-05-31 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'OTHER','',NULL,NULL,NULL,NULL),(134,'118/2022','FIROZ','26','KUNNAN PARAMBILL(H)\nTAVANOOR\n','','M','THAVANUR','','8281509120','9496926550','2022-07-22 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'','',NULL,NULL,NULL,NULL),(135,'131/2022','ASHRAF ','32','','','M','','','','','2022-07-29 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'OTHER','',NULL,NULL,NULL,NULL),(136,'115/2022','HUSSAN','35','KUNNATH (H)\nPANDIKASHALA \nPAINKANNUR \nKUTTIPPURAM ','','M','KUTTIPPURAM ','','7034655709','','2022-07-08 00:00:00',NULL,NULL,'','MENTAL RETARDDATION',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(137,'133/2022','SEMI','30','MAMMATH (H)\nMOODAL \nKARETHALA MARKAZ','','F','','','9072750168','','2022-07-29 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(138,'135/2022','ASHRAF','38','KUTHIRAPARAMBILL (H)\nPARAPPURAM \n','','M','KALADI','','6235872339','9072599466','2022-08-02 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'OTHER','','2022-07-29 00:00:00','',1,''),(139,'134/2022','SABITHA ','36','MANNUKUTH\nTHOZHUVANUR','','F','','','9895170524','','2022-08-02 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'OTHER','',NULL,NULL,NULL,NULL),(140,'137/2022','SREEDEVI','31','SRAMBIKKAL (H)\nPAIKANOOR \nKUTTIPPURAM ','','F','KUTTIPPURAM','','9745084130','','2022-08-12 00:00:00',NULL,NULL,'','PSYCHIATRY',0,'','',NULL,NULL,NULL,NULL),(141,'136/2022','ABDU SAMAD ','37','KUTHIRA PARAMBIL (H)\nKADANCHERY \nKALADI\n','','M','KALADI','','9072599466','9846755536','2022-08-05 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'OTHER','',NULL,NULL,NULL,NULL),(142,'57/2022','FARIS','49','PUTHANVETTIL (H)\nKUTTIPPURAM','','M','KUTTIPPURAM','','','','2022-03-11 00:00:00','2022-04-15 00:00:00',NULL,'','PSYCHIATRY',0,'','',NULL,NULL,NULL,NULL),(143,'190/2022','NOUSHAD ','28','VELLATTU VALLAPPIL (H)\nMANOOR\nVATTAM KULLAM ','','M','VATTAMKULAM','1','7012861420','9744609279','2022-09-09 00:00:00',NULL,NULL,'','MENTAL RETARDATION WITH PSYCHOTIC DISORDER',0,'OTHER','',NULL,NULL,NULL,NULL),(144,'205/2022','ABDUL RASAK','38','PARAKKAL HOUSE \nEDACHALAM \nPERASSANOOR','','M','KUTTIPPURAM','8','9656233716','9048899071','2022-09-20 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(145,'155/2022','SAINUDHEEN','32','PALATTU VALAPPIL\nEDACHALAM\n','','M','','','9995429012','9947618655','2022-08-19 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'PERASHANNOOR','',NULL,NULL,NULL,NULL),(146,'171/2022','SHRHARBAN','39','KUNDARIYIL HOUSE\nPANDIKASALA','','F','','','8848289920','','2022-08-30 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'','',NULL,NULL,NULL,NULL),(147,'203/2022','RASIYA BANU','40','KALATHIL VALAPPIL HOUSE\nKUMARANALLOOR','','F','','','9961207759','','2022-09-30 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'OTHER','',NULL,NULL,NULL,NULL),(148,'201/2022','PRAMOD','42','PALLIYALIL H\nMOODAL','','M','KUTTIPPURAM','','9961311759','','2022-09-30 00:00:00',NULL,NULL,'','DEPRESSION',0,'CHELLUR , MOODAL','',NULL,NULL,NULL,NULL),(149,'200/2022','KOLAVAM','53','NADIKOTTAPARAMBIL H\nNADUVATTAM\nKUTTIPPURAM\n','','M','KUTTIPPURAM','','7034948462','','2022-09-30 00:00:00',NULL,NULL,'','PSYCHOSIS NOS',0,'KUTTIPPURAM SOUTH','',NULL,NULL,NULL,NULL),(150,'202/2022','BINDU','43','NADIKOTTAPARAMBIL H\nNADUVATTAM','','F','KUTTIPPURAM','','7034948462','','2022-09-30 00:00:00',NULL,NULL,'','PSYCHOSIS NOS',0,'NADUVETTAM','','2022-09-30 00:00:00','PSYCHOSIS PATIENT TAKING MEDICINE \n',1,''),(151,'204/2022','ANSIF','20','KALATHIL VALAPPIL H\nKUMARANALLOOR','','M','','','9961207759','','2022-09-30 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'OTHER','',NULL,NULL,NULL,NULL),(152,'0190/2022','HAMZA ','50','KANNAM PARAMBIL H\nTHAVANOOR','','M','THAVANOOR','','8281509120','9496926550','2022-08-26 00:00:00','2022-10-08 00:00:00',NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'THAVANOOR','',NULL,NULL,NULL,NULL),(153,'170/2022','HAMZA','50','KANNAM PARAMBIL H\nTHAVANUR','','M','THAVANUR','','8281509120','9496926550','2022-08-26 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'OTHER','',NULL,NULL,NULL,NULL),(154,'080/2020','SAJNA','30','NURUKUNDIL H\nPAINKANUR\nKUTTIPPURAM\n','','F','KUTTIPPURAM','10','9048289797','8086515930','2021-06-11 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'OTHER','',NULL,NULL,NULL,NULL),(155,'225/2022','KUNJALU','60','EENAMPARAMBIL(H)\nNADETT\nATHALLUR','','M','THAVANUR','','9747784329','','2022-10-11 00:00:00','2022-11-11 00:00:00',NULL,'','PSYCHOSIS NOS',0,'OTHER','','2022-10-11 00:00:00','NO INCOME FOR FAMILY ONLY A MARRIED DAUGHTER HAVE TO TAKE CARE',1,'TAKING MEDICINE FROM SEVERAL YEARS\nHAVE HEART DISEASE '),(156,'224/2022','BIJULAL','18','PULLIYANKKAVIL (H)\nATHALUR\nMATHUR','','M','THAVANUR','18','8848866127','','2022-10-11 00:00:00',NULL,NULL,'','OTHER',0,'OTHER','','2022-10-11 00:00:00','SUBSTANCE ABUSE LEAD TO PSYCHIATRIC SYMPTOMS\nPOOR FAMILY',1,''),(157,'237/2022','RAHMATHUNNEESA','29','CHELOOR PUTHER(H)\nMUTTANNOOR\nPURATHUR','','F','PURATHUR','3','9745736279','8592906293','2022-11-04 00:00:00',NULL,NULL,'','MENTAL RETARDDATION',0,'OTHER','','2022-11-03 00:00:00','',1,''),(158,'242/2022','HARIDASAN','33','KUNNATH KANAKKUMTHARA\nTHAZHE ANGAD\nPANDIKASALA\nVALANCHERI','','M','VALANCHERY','','6238757050','9807865644','2022-11-11 00:00:00',NULL,NULL,'','DEPRESSION',0,'OTHER','','2022-11-08 00:00:00','FINANCIALLY BACKWARD AND NO ONE IS  THERE TO CARE',1,''),(159,'238/2022','RAJESH','47','MURINGOL THODI (H)\nPAINKANOOR\nVALANCHERI','','M','VALANCHERY','21','9562231730','7591928181','2022-11-04 00:00:00','2022-12-02 00:00:00',NULL,'','DEPRESSION WITH PSYCHOTIC SYMPTOMS',0,'OTHER','',NULL,NULL,NULL,NULL),(160,'243/2022','KUNJIPATHUMA','54','PUTHIYA NALAKATH\nRANGATOOR\nKUTTIPPURAM','','F','KUTTIPPURAM','','8129557504','9048476934','2022-11-11 00:00:00',NULL,NULL,'','SOMATOFORM DISORDER',0,'KUTTIPPRAM NORTH','',NULL,NULL,NULL,NULL),(161,'28/2020','ASSAINAR','60','THENTHRATHODI\nPALATTUKULAMB\nKUTTIPPURAM','','M','KUTTIPPURAM','','9645353280','','2022-11-18 00:00:00',NULL,NULL,'ASHRAF','PSYCHOSIS NOS',0,'','',NULL,NULL,NULL,NULL),(162,'249/2022','FARSANA VP','22','VEETUPARAMBIL (H)\nTHALAKASSERY KAYATTAM\nKUMARANELLUR','','F','','','9846337833','7558939393','2022-11-25 00:00:00',NULL,NULL,'','AUTISM',0,'OTHER','','2022-11-17 00:00:00','',1,''),(163,'045/2020','KOYAMU','73','KOTTULUNGAL (H)\nKULAKKAD\nKUTTIPPURAM','','M','KUTTIPPURAM','7','9745534315','9496880102','2022-12-02 00:00:00','2022-12-30 00:00:00',NULL,'','',0,'CHELLUR , MOODAL','','2022-12-02 00:00:00','',1,'palliative pt. with psychotic symptoms'),(164,'270/2022','KARTHIYAYINI','55','MANNUKUTH(H)\nTHAZHATHANGADI\nPANDIKASALA-VALANCHERI','','F','VALANCHERY','24','9895623564','9633168566','2022-12-16 00:00:00',NULL,NULL,'','PSYCHOSIS NOS',0,'OTHER','','2022-12-13 00:00:00','',1,''),(165,'280/2022','YAHUTTY','55','PALATHINGAL(H)\nTHRIKKANAPPURAM','','M','THAVANUR','9','9567439658','9562141616','2022-12-30 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'OTHER','','2022-12-29 00:00:00','',1,''),(166,'279/2022','KAMARUNEESA','35','PUZHITHARA(H)\nTHRIKANAPPURAM\nTHAVANUR','','F','THAVANUR','','9656854137','','2022-12-30 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'OTHER','','2022-12-29 00:00:00','',1,''),(167,'283/2022','MAIMOONA','44','KUNNATHVALAPPIL(H)\nKOLATHOL\nNADUVATTAM\n','','F','KUTTIPPURAM','','7559034981','9539418728','2022-12-30 00:00:00',NULL,NULL,'','BIPOLAR AFFECTIVE DISORDER',0,'','','2022-12-23 00:00:00','HOME SCREENING NOT DONE BECAUSE PATIENT\'S PARENTS ARE  ALREADY OUR PATIENTS',1,'');
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patientfamily`
--

DROP TABLE IF EXISTS `patientfamily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patientfamily` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `PatientId` int NOT NULL,
  `Name` varchar(200) DEFAULT NULL,
  `Relation` varchar(45) DEFAULT NULL,
  `Age` int DEFAULT NULL,
  `Education` varchar(200) DEFAULT NULL,
  `MaritalStatus` varchar(45) DEFAULT NULL,
  `Occupation` varchar(200) DEFAULT NULL,
  `Income` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patientfamily`
--

LOCK TABLES `patientfamily` WRITE;
/*!40000 ALTER TABLE `patientfamily` DISABLE KEYS */;
INSERT INTO `patientfamily` VALUES (1,24,'ABDULA','FATHER',49,'3','Married','KULI',500.00),(2,24,'SULAIGHA','MOTHER',46,'6','Married','',0.00),(3,24,'MUHSINA','SISTER',24,'+2','Single','',0.00),(4,24,'SALMAN FARIZ','BROTHER',23,'10','Single','',0.00),(5,19,'PATHMINI','WIFE',46,'10','Married','',0.00),(6,19,'SNEHA ','DAUGHTER',25,'+2','Married','',0.00),(7,19,'SONIYA','DAUGHTER',24,'+2','Married','',0.00),(8,21,'THITHIKKUTTI','MOTHER',59,'','Widowed','KULLI',300.00),(9,21,'THAJUDHEEN','BROTHER',35,'7','Single','',0.00),(10,17,'FATHIMMA','WIFE',56,'4','Widowed','',0.00),(11,17,'FTHIMMA ','WIFE',56,'4','Married','',0.00),(12,17,'RESHEED','SON',28,'10','Married','DRIVER',3000.00),(13,17,'NAZAR','SON',39,'10','Married','DRIVER',3000.00),(14,17,'SUHAILA','daughter in law ',23,'+2','Married','',0.00),(15,17,'FATHIMMA','daughter in law',34,'10','Married','',0.00),(16,17,'NIYA FATHIMMA','granddaughter',8,'2','','',0.00),(17,17,'RIFLA','granddaughter',3,'','','',0.00),(18,40,'MUHAMMAD ALI','FATHER',54,'7','Married','MASJID KEEPER',3000.00),(19,40,'THAHEERA','MOTHER',50,'8','Married','',0.00),(20,37,'LAAILA ','WIFE',43,'10','Married','',0.00),(21,37,'MUBEENA','daughter',23,'degree','Married','',0.00),(22,37,'MOHAMMAD AFSAL','SON',15,'+1','','',0.00),(23,37,'MOHAMMAD AFLAH','SON',5,'LKG','','',0.00),(24,32,'FATHIMMA ','MOTHER',60,'3','Married','',0.00),(25,32,'SAIFUNEESA','SISTER',36,'7','Married','',0.00),(26,32,'SEREENA','SISTER',28,'8','','',0.00),(27,32,'SAFUVANA','sister daughter',12,'7','','',0.00),(28,32,'MASHHUD','sister son',8,'3','','',0.00),(29,43,'JAFAR','HASBAND',31,'10','Married','SPOE',25000.00),(30,43,'HAWA','MOTHER IN LOW',61,'7','Widowed','',0.00),(31,43,'RUKSANA','SISTER IN LOW',30,'DEGREE','Married','',0.00),(32,43,'AAISHA','daughter',2,'','','',0.00),(33,43,'AMAN','brother in son',12,'6','','',0.00),(34,43,'AMDAN','brother in son',9,'1','','',0.00),(35,26,'MUHAMMAD KUTTI','HASBAND',69,'','Married','',0.00),(36,22,'AYISHA','MOTHER',59,'','Widowed','',0.00),(37,22,'THASLEENA','SISTER IN LAW',25,'+1','Married','',0.00),(38,22,'HAIDHAR ALI','BROTHER ',34,'10','Married','GULF',25000.00),(39,22,'ABDURAHMAN','BROTHER',28,'+2','Single','GULF',20000.00),(40,23,'FATHIMMA','MOTHER',66,'','Widowed','',0.00),(41,23,'ABDUL HAMEED','BROTHER',47,'9','Married','MADHARASA UZTHAD',3000.00),(42,23,'MUHAMMAD YASIN','BROTHER\'S SON',7,'2','','',0.00),(43,23,'FATHIMMA USNA','BROTHER\'S DAUGHTER',17,'+2','Single','',0.00),(44,5,'AYISHA','MOTHER',59,'','Widowed','',0.00),(45,5,'THASLI','BROTHER IN LOW',25,'9','Married','',0.00),(46,33,'THEYAN','FATHER',75,'4','Married','',250.00),(47,33,'SULOJAN','MATHER',67,'5','Married','',0.00),(48,33,'SHEEBIDHA','daughter',24,'+2','Married','',0.00),(49,104,'RAMLA','WIFE',38,'10','Married','',0.00),(50,104,'FATHIMMATH SUHARA','daughter',18,'+2','Single','',0.00),(51,104,'AHAMADH FARHAN','SON',15,'10','Single','',0.00),(52,104,'MINSHADH','SON',14,'9','Single','',0.00),(53,46,'KADHEEJA','MOTHER',55,'8','Widowed','',0.00),(54,46,'MOHAMMADH FAIS','BROTHER',23,'+2','Single','NRI',15000.00),(55,27,'FATHIMMA','MOTHER',70,'7','Widowed','',0.00),(56,27,'NOUFAL','BROTHER',37,'10','Married','',10000.00),(57,27,'NESEERA','BROTHE IN LOW',27,'10','Married','',0.00),(58,27,'MOHAMMADH ZIYAN','BROTHE S SON',6,'1','Single','',0.00),(59,27,'FATHIMMA RINSH','Brother s daughter',3,'','Single','',0.00),(60,10,'RAIHANATH','WIFE',40,'10','Married','',0.00),(61,10,'MOHAMMED SHIBILI','SON',15,'10','Single','',0.00),(62,10,'SHAKIRA HANNA','DAUGHTER',14,'9','Single','',0.00),(63,10,'FATHIMMA HASANA','DAUGHTER',19,'BCom','Single','',0.00),(64,115,'LETHIF','SISTHER SON',45,'6','Single','KULI',3000.00),(65,115,'KADHEEJA','SISTHER SON WIFE',40,'10','Married','',0.00),(66,115,'THASLEEMA','SISTHER SON DAUGHTER',20,'BA','Married','',0.00),(67,115,'THASREEFA','SISTHER SON DAUGHTER',19,'BA ENGLISH','','',0.00),(68,115,'ANAS','SISTHER SON SON',15,'10','Single','',0.00),(69,115,'BILAL','SISTHER SON SON',12,'7','Single','',0.00);
/*!40000 ALTER TABLE `patientfamily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patientop`
--

DROP TABLE IF EXISTS `patientop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patientop` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `PatientId` int NOT NULL,
  `Date` datetime DEFAULT NULL,
  `DoctorId` int DEFAULT NULL,
  `Medcines` text,
  `Remarks` text,
  `FollowUp` text,
  `NextOPDate` datetime DEFAULT NULL,
  `IsActive` tinyint DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patientop`
--

LOCK TABLES `patientop` WRITE;
/*!40000 ALTER TABLE `patientop` DISABLE KEYS */;
/*!40000 ALTER TABLE `patientop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patientvolunteer`
--

DROP TABLE IF EXISTS `patientvolunteer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patientvolunteer` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `PatientId` int NOT NULL,
  `VolunteerId` int NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patientvolunteer`
--

LOCK TABLES `patientvolunteer` WRITE;
/*!40000 ALTER TABLE `patientvolunteer` DISABLE KEYS */;
INSERT INTO `patientvolunteer` VALUES (3,91,5),(4,91,21),(5,92,5),(6,92,21),(7,95,2),(8,95,3),(9,95,11),(10,95,23),(11,94,2),(12,94,3),(13,94,11),(14,94,23),(15,102,1),(16,102,15),(17,102,24),(18,90,5),(19,90,21),(22,105,13),(23,105,26),(24,104,5),(25,104,21),(26,119,5),(27,119,21),(28,127,7),(29,127,26),(30,138,7),(31,138,23),(32,128,7),(33,128,26),(36,150,7),(37,150,26),(40,155,19),(41,155,23),(42,156,19),(43,156,23),(44,156,28),(45,157,19),(46,157,23),(47,157,28),(50,158,23),(51,158,28),(55,162,19),(56,162,23),(57,162,28),(64,163,23),(65,163,28),(66,163,30),(70,164,11),(71,164,23),(72,164,28),(73,165,10),(74,165,23),(75,165,30),(76,166,10),(77,166,23),(78,166,30);
/*!40000 ALTER TABLE `patientvolunteer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rehabilitation`
--

DROP TABLE IF EXISTS `rehabilitation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rehabilitation` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Pno` varchar(45) DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL,
  `Quantity` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rehabilitation`
--

LOCK TABLES `rehabilitation` WRITE;
/*!40000 ALTER TABLE `rehabilitation` DISABLE KEYS */;
/*!40000 ALTER TABLE `rehabilitation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `route`
--

DROP TABLE IF EXISTS `route`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `route` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `route`
--

LOCK TABLES `route` WRITE;
/*!40000 ALTER TABLE `route` DISABLE KEYS */;
INSERT INTO `route` VALUES (1,'KUTTIPPRAM NORTH'),(2,'KUTTIPPURAM SOUTH'),(3,'CHELLUR , MOODAL'),(4,'PERASHANNOOR'),(5,'MADHIRASHERY'),(6,'NADUVETTAM'),(7,'AAIGALLAM'),(8,'THRIKKANNAPURAM'),(9,'OTHER');
/*!40000 ALTER TABLE `route` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volunteer`
--

DROP TABLE IF EXISTS `volunteer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volunteer` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) DEFAULT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `Phone` varchar(45) DEFAULT NULL,
  `VolunteerTypeId` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volunteer`
--

LOCK TABLES `volunteer` WRITE;
/*!40000 ALTER TABLE `volunteer` DISABLE KEYS */;
INSERT INTO `volunteer` VALUES (1,'FEMINA THASNI T.P','KUTTIPPURAM','8138963445',1),(2,'AMEENA ANVAR T.K','KUTTIPPURAM','8304848376',1),(3,'FARSANA THASNI ','KUTTIPPURAM','9562587900',1),(4,'SHAMNA SHIRIL M','KUTTIPPURAM','8893614541',1),(5,'SULFIKAR A.A','KUTTIPPURAM','9895841286',1),(6,'NAJEEB KM','KUTTIPPURAM','9447046003',1),(7,'HAFSATH','EDACHELAM','9744722742',1),(8,'AJITH KUMAR','VALANCHERY','9895923924',1),(9,'ANOOP','KUTTIPPURAM','9846561362',1),(10,'INDHU ANOOP','KUTTIPPURAM','9846587698',1),(11,'SALEEM','KUTTIPPURAM','9562580581',1),(12,'RASHEED','MADHIRASHERY','7736222373',1),(13,'ABDHUL AMEER','KUTTIPPURAM','8129155575',1),(14,'NASIM KHADIRI','KUTTIPPURAM','9544062567',1),(15,'HANEEFA','EDACHELAM','9645772299',1),(16,'BARSHADH','KUTTIPPURAM','9746067412',1),(17,'MIRZA NIZAM','KUTTIPPURAM','9605200345',1),(18,'SHIBIL','KUTTIPPURAM','8089614541',1),(19,'MADHU MOHANNAN','CHELLUR','8089032205',1),(20,'SADHIK','KUTTIPPURAM','9946313413',1),(21,'SAINUDHEEN','PONNANI','9995550039',2),(22,'SHUKOOR','KAKKADU','9544708027',2),(23,'SURAYYA','PONNANI','9961207407',2),(24,'SOFIYA','CALICUT','8547652474',2),(25,'RAHILA','MALAPPURAM','8086532096',1),(26,'JAYACHANDRAN','CALICUT','9895988890',2),(27,'IRFAN ','THIRTHALA','8592942229',1),(28,'ANJUBALA','VALANCHERI','9847028794',1),(29,'AMNA FAESHA','ILA','9037920239',1),(30,'DELIN LUKE','KUTTIPPURAM','9895675690',1),(31,'INDHU','KUTTIPPURAM','8086408031',1),(32,'INDHULEKHA','CHELLOOR','8086408031',1),(33,'KAVITHA','KUTTIPPURAM','8943709515',1),(34,'SALMA','KUTTIPPURAM','9895884446',1);
/*!40000 ALTER TABLE `volunteer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volunteertype`
--

DROP TABLE IF EXISTS `volunteertype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volunteertype` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `VolunteerType` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volunteertype`
--

LOCK TABLES `volunteertype` WRITE;
/*!40000 ALTER TABLE `volunteertype` DISABLE KEYS */;
INSERT INTO `volunteertype` VALUES (1,'ILA'),(2,'MHAT');
/*!40000 ALTER TABLE `volunteertype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'palcarepsychiatry'
--
/*!50003 DROP PROCEDURE IF EXISTS `log_msg` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `log_msg`(IN in_msg VARCHAR(255))
BEGIN
 insert into log values(in_msg);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddAccountLedger` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddAccountLedger`(
IN p_in_txndate datetime,
IN p_in_desc varchar(200),
IN p_in_type varchar(45),
IN p_in_amount DECIMAL(10,2),
IN p_in_txntype varchar(45),
IN p_in_name varchar(200),
IN p_in_isReceipt tinyint,
IN p_in_paymentMode varchar(45),
IN p_in_bankMode varchar(45),
IN p_in_bankName varchar(200),
IN p_in_txnNo varchar(100),
IN p_in_chNo varchar(45),
IN p_in_chdate datetime,
IN p_in_chBank varchar(200),
IN p_in_chAmount DECIMAL(10,2),
OUT p_out int
)
BEGIN
	
    Declare p_receiptNo int;
    
	IF extract(year from p_in_txndate) = 1 THEN
		SET p_in_txndate = NULL;
	END IF;
	
	IF extract(year from p_in_chdate) = 1 THEN
		SET p_in_chdate = NULL;
	END IF;
	
    IF p_in_bankMode = "Cheque" THEN
		SET p_in_chAmount = p_in_amount;
        SET p_in_amount = 0;
	END IF;
    
    IF p_in_isReceipt = 1 THEN
		update center set receiptno = receiptno + 1 where id = 1; 
		select receiptno into p_receiptNo from center  where id = 1; 
	END IF;
    
	INSERT INTO `account`
		(
		`txndate`,
		`desc`,
		`type`,
		`amount`,
		`txntype`,
		`name`,
		`receiptNo`,
		`isReceipt`,
		`paymentMode`,
		`bankMode`,
		`bankName`,
		`txnNo`,
		`chNo`,
		`chdate`,
		`chBank`,
		`chAmount`)
		VALUES
		(
        p_in_txndate,
        p_in_desc,
		p_in_type,
        p_in_amount,
        p_in_txntype,
        p_in_name,
        p_receiptNo,
        p_in_isReceipt,
        p_in_paymentMode,
        p_in_bankMode,
        p_in_bankName,
        p_in_txnNo,
        p_in_chNo,
        p_in_chdate,
        p_in_chBank,
        p_in_chAmount
        );
        
        set p_out =  LAST_INSERT_ID();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddBank` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddBank`(
IN p_in_name varchar(200)
)
BEGIN
	INSERT INTO `bank`
	(`Name`)
	VALUES
	(p_in_name );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddCE` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddCE`(
IN p_in_txndate datetime,
IN p_in_source varchar(45),
IN p_in_bankName varchar(200),
IN p_in_amount DECIMAL(10,2)
)
BEGIN
	
    IF p_in_source = "Cash" THEN
		INSERT INTO `account`
		(
		`txndate`,
		`desc`,
		`type`,
		`amount`,
		`txntype`,
		`name`,
		`isReceipt`,
		`paymentMode`,
		`bankMode`,
		`bankName`,
        `chAmount`
		)
		VALUES
		(
        p_in_txndate,
        "Contra Entry - Cash", -- p_in_desc
		"Contra Entry", -- p_in_type
        p_in_amount * -1,
        "Expense", --  p_in_txntype
        "", -- p_in_name
        0, -- p_in_isReceipt
        "Cash", -- p_in_paymentMode
        "", -- p_in_bankMode
        "", -- p_in_bankName
        0 --  `chAmount`
        );
        
        INSERT INTO `account`
		(
		`txndate`,
		`desc`,
		`type`,
		`amount`,
		`txntype`,
		`name`,
		`isReceipt`,
		`paymentMode`,
		`bankMode`,
		`bankName`,
		`chAmount`
		)
		VALUES
		(
        p_in_txndate,
        "Contra Entry - Bank", -- p_in_desc
		"Contra Entry", -- p_in_type
        p_in_amount,
        "Income", --  p_in_txntype
        "", -- p_in_name
        0, -- p_in_isReceipt
        "Bank", -- p_in_paymentMode
        "Transfer", -- p_in_bankMode
        p_in_bankName,
        0 --  `chAmount`
        );
	ELSE
		INSERT INTO `account`
		(
		`txndate`,
		`desc`,
		`type`,
		`amount`,
		`txntype`,
		`name`,
		`isReceipt`,
		`paymentMode`,
		`bankMode`,
		`bankName`,
        `chAmount`
		)
		VALUES
		(
        p_in_txndate,
        "Contra Entry - Bank", -- p_in_desc
		"Contra Entry", -- p_in_type
        p_in_amount * -1,
        "Expense", --  p_in_txntype
        "", -- p_in_name
        0, -- p_in_isReceipt
        "Bank", -- p_in_paymentMode
        "Transfer", -- p_in_bankMode
        p_in_bankName,
        0 --  `chAmount`
        );
        
        INSERT INTO `account`
		(
		`txndate`,
		`desc`,
		`type`,
		`amount`,
		`txntype`,
		`name`,
		`isReceipt`,
		`paymentMode`,
		`bankMode`,
		`bankName`,
        `chAmount`
		)
		VALUES
		(
        p_in_txndate,
        "Contra Entry - Cash", -- p_in_desc
		"Contra Entry", -- p_in_type
        p_in_amount,
        "Income", --  p_in_txntype
        "", -- p_in_name
        0, -- p_in_isReceipt
        "Cash", -- p_in_paymentMode
        "", -- p_in_bankMode
        "", -- p_in_bankName
        0 --  `chAmount`
        );
	END IF;
    	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddDiagnosis` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddDiagnosis`(
IN p_in_name varchar(100)
)
BEGIN
	INSERT INTO `diagnosis`
	(`Name`)
	VALUES
	(p_in_name );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddDoctor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddDoctor`(
 IN p_in_name varchar(100),
 IN p_in_type int
 )
BEGIN
 	INSERT INTO `Doctor`
 	(`Name`,ConsultantTypeId)
 	VALUES
 	(p_in_name,p_in_type );
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddEquipment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddEquipment`(
IN p_in_name varchar(200),
IN p_in_name_lower varchar(200),
IN p_in_stock int,
IN p_in_inuse int,
IN p_in_damage int
)
BEGIN
	declare p_eno varchar(10);
    
    IF NOT EXISTS (SELECT 1 FROM `equipment` where name_lower = p_in_name_lower) THEN
    	select concat('E',ifnull(max(id),0) +1) into p_eno from `equipment`;
      	INSERT INTO `equipment`
		(`eno`,	`name`,	`name_lower`, stock, damage, inuse)
		VALUES (p_eno,p_in_name,p_in_name_lower,p_in_stock, p_in_damage, p_in_inuse );
	ELSE
		UPDATE `equipment`
		SET
		`stock` = p_in_stock,
		`damage` = p_in_damage,
		`inuse` = p_in_inuse
		WHERE `name_lower` = p_in_name_lower;
	END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddExpenseType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddExpenseType`(
IN p_in_expensetype varchar(100)
)
BEGIN
	INSERT INTO `expensetype`
	(`ExpenseType`)
	VALUES
	(p_in_expensetype );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddFamiliy` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddFamiliy`(
IN p_in_pno varchar(45),
IN p_in_name varchar(200),
IN p_in_relation varchar(45),
IN p_in_age int,
IN p_in_education varchar(200),
IN p_in_maritalStatus varchar(45),
IN p_in_occupation varchar(200),
IN p_in_income decimal(10,2)

)
BEGIN

	declare p_pid int;
    select Id into p_pid from patient where Pno = p_in_pno;

	INSERT INTO `patientfamily`
		(
		`PatientId`,
		`Name`,
		`Relation`,
		`Age`,
		`Education`,
		`MaritalStatus`,
		`Occupation`,
		`Income`)
		VALUES
		(
		p_pid,
		p_in_name,
		p_in_relation,
		p_in_age,
		p_in_education,
		p_in_maritalStatus,
		p_in_occupation,
		p_in_income);
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddHomeVisit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddHomeVisit`(
 IN p_in_pno varchar(45),
 IN p_in_date datetime,
 IN p_in_remarks text,
 IN p_in_volunteers varchar(100)
 )
BEGIN
 
 	declare p_pid, p_vid, finished, p_homevisit_id int;
     
     DEClARE curVol CURSOR FOR select Id from volunteer where FIND_IN_SET(Id, p_in_volunteers);    
     DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
     
     SET finished = 0;
     select Id into p_pid from patient where Pno = p_in_pno;
 
 	INSERT INTO `homevisit`
 		(
 		`PatientId`,
 		`Date`,
 		`Remarks`)
 		VALUES
 		(
 		p_pid,
 		p_in_date,
 		p_in_remarks);
         
 	set p_homevisit_id =  LAST_INSERT_ID();
         
 	IF p_in_volunteers != '' THEN
 		
         OPEN curVol;
         volLoop: LOOP
 			FETCH curVol INTO p_vid;
              
 			IF finished = 1 THEN 
 				LEAVE volLoop;
 			END IF;
 			
             INSERT INTO `homevisitvolunteer`
 				(`HomeVisitId`,`VolunteerId`)
 			VALUES
 				(p_homevisit_id, p_vid);
 
         END LOOP volLoop;
         CLOSE curVol;
     END IF;
    
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddIncomeType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddIncomeType`(
IN p_in_incometype varchar(100)
)
BEGIN
	INSERT INTO `incometype`
	(`IncomeType`)
	VALUES
	(p_in_incometype );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddMedicine` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddMedicine`(
IN p_in_txndate datetime,
IN p_in_name varchar(200),
IN p_in_name_lower varchar(200),
IN p_in_stock_main int,
IN p_in_purchase_invdate datetime,
IN p_in_purchase_invno varchar(45),
IN p_in_purchase_batchno varchar(45),
IN p_in_purchase_expdate datetime,
IN p_in_purchase_mfgdate datetime,
IN p_in_purchase_rate decimal(10,2),
IN p_in_purchase_dealer varchar(200),
IN p_in_purchase_mainStock int
)
BEGIN
	declare p_mno varchar(10);
    declare p_m_id int;
    
    IF NOT EXISTS (SELECT 1 FROM `medicine` where NameLower = p_in_name_lower) THEN
    	
        select concat('M',ifnull(max(id),0) +1) into p_mno from `medicine`;
        
    	IF extract(year from p_in_purchase_invdate) = 1 THEN
			SET p_in_purchase_invdate = NULL;
		END IF;
		
		IF extract(year from p_in_purchase_expdate) = 1 THEN
			SET p_in_purchase_expdate = NULL;
		END IF;
		
		IF extract(year from p_in_purchase_mfgdate) = 1 THEN
			SET p_in_purchase_mfgdate = NULL;
		END IF;

		INSERT INTO `medicine`
		(`Mno`,	`Name`,	`NameLower`)
		VALUES (p_mno,p_in_name,p_in_name_lower);

		set p_m_id =  LAST_INSERT_ID();
         
        INSERT INTO `medicinestock`
		(`MedicineId`,`Main`,`Sub`,	`A_kit`,`B_kit`)
		VALUES (p_m_id, p_in_stock_main, 0, 0, 0);
         
        INSERT INTO `medicinepurchase`
		(
		`MedicineId`,
		`invdate`,
		`invno`,
		`batchno`,
		`expdate`,
		`mfgdate`,
		`rate`,
		`dealer`,
		`mainStock`,
		`subStock`,
		`return`)
		VALUES
		(
		p_m_id,
		p_in_purchase_invdate,
		p_in_purchase_invno,
		p_in_purchase_batchno,
		p_in_purchase_expdate,
		p_in_purchase_mfgdate,
		p_in_purchase_rate,
		p_in_purchase_dealer,
		p_in_purchase_mainStock,
		0,
		0);
 		
        CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_mno, 
		p_in_name,
		'Add', -- txnType
		'To main stock', -- desc
		0, -- openingMain
        0, -- openingSub
        0, -- openingAKit
        0, -- openingBKit
		p_in_stock_main, -- qty
		p_in_stock_main, -- closingMain
		0, -- closingSub
        0, -- closingAKit
        0, -- closingBKit
        '', -- pno
        '' -- patientName
        );
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddMedicineHistory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddMedicineHistory`(
IN p_in_m_id int,
IN p_in_txnDate datetime,
IN p_in_mno varchar(45),
IN p_in_medName varchar(200),
IN p_in_txnType varchar(45),
IN p_in_desc varchar(45),
IN p_in_openingMain int,
IN p_in_openingSub int,
IN p_in_openingAKit int,
IN p_in_openingBKit int,
IN p_in_qty int,
IN p_in_closingMain int,
IN p_in_closingSub int,
IN p_in_closingAKit int,
IN p_in_closingBKit int,
IN p_in_pno varchar(45),
IN p_in_patientName  varchar(200)
)
BEGIN
	
    INSERT INTO `medicinehistory`
	(
	`MedicineId`,
	`txnDate`,
	`mno`,
	`medName`,
	`txnType`,
	`desc`,
	`openingMain`,
	`openingSub`,
	`openingAKit`,
	`openingBKit`,
	`qty`,
	`closingMain`,
	`closingSub`,
	`closingAKit`,
	`closingBKit`,
	`pno`,
	`patientName`)
	VALUES
	(
	p_in_m_id,
	p_in_txnDate,
	p_in_mno,
	p_in_medName,
	p_in_txnType,
	p_in_desc,
	p_in_openingMain,
	p_in_openingSub,
	p_in_openingAKit,
	p_in_openingBKit,
	p_in_qty,
	p_in_closingMain,
	p_in_closingSub,
	p_in_closingAKit,
	p_in_closingBKit,
	p_in_pno,
	p_in_patientName);

    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddMeeting` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddMeeting`(
IN p_in_pno varchar(45),
IN p_in_date datetime,
IN p_in_remarks text
)
BEGIN

	declare p_pid int;
    select Id into p_pid from patient where Pno = p_in_pno;

	INSERT INTO `meeting`
		(
		`PatientId`,
		`Date`,
		`Remarks`)
		VALUES
		(
		p_pid,
		p_in_date,
		p_in_remarks);
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddOP` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddOP`(
IN p_in_pno varchar(45),
IN p_in_date datetime,
IN p_in_doctorId int,
IN p_in_psychiatristId int,
IN p_in_psychologistId int,
IN p_in_clinicianId int,
IN p_in_remarks text,
IN p_in_followup text,
IN p_in_nextopdate datetime,
OUT p_out int
)
BEGIN

	declare p_pid int;
    select Id into p_pid from patient where Pno = p_in_pno;

	INSERT INTO `op`
		(
		`PatientId`,
		`Date`,
		`DoctorId`,
        PsychiatristId,
        PsychologistId,
        ClinicianId,
		`Remarks`,
		`FollowUp`,
		`NextOPDate`)
		VALUES
		(
		p_pid,
		p_in_date,
		p_in_doctorId,
        p_in_psychiatristId,
        p_in_psychologistId,
        p_in_clinicianId,
		p_in_remarks,
		p_in_followup,
		p_in_nextopdate);
        
        set p_out =  LAST_INSERT_ID();
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddOPMedicine` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddOPMedicine`(
IN p_in_opid int,
IN p_in_mno varchar(45),
IN p_in_qty int
)
BEGIN

	Declare p_m_id int;
	select Id into p_m_id from medicine where Mno = p_in_mno;
    
    INSERT INTO `opmedicine`
	(`OpId`,`MedicineId`,`Quantity`)
	VALUES
	(p_in_opid, p_m_id, p_in_qty);
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddPanjayath` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddPanjayath`(
IN p_in_name varchar(100)
)
BEGIN
	INSERT INTO `panjayath`
	(`Name`)
	VALUES
	(p_in_name );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddPatient` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddPatient`(
IN p_in_pno varchar(45),
IN p_in_name varchar(200),
IN p_in_age varchar(45),
IN p_in_address varchar(255),
IN p_in_grade varchar(45),
IN p_in_gender varchar(45),
IN p_in_panjayath varchar(100),
IN p_in_wardno varchar(45),
IN p_in_phone1 varchar(45),
IN p_in_phone2 varchar(45),
IN p_in_regdate datetime,
IN p_in_expdate datetime,
IN p_in_dropdate datetime,
IN p_in_volunteer varchar(100),
IN p_in_diagnosis varchar(100),
IN p_in_temp tinyint,
IN p_in_route varchar(100),
IN p_in_homecareplan varchar(45),
OUT p_out varchar(10)
)
BEGIN
	
    IF EXISTS (SELECT 1 FROM patient where PNo = p_in_pno) THEN
    	SET p_out = "1";
    ELSE
    	IF extract(year from p_in_regdate) = 1 THEN
			SET p_in_regdate = NULL;
		END IF;
		
		IF extract(year from p_in_expdate) = 1 THEN
			SET p_in_expdate = NULL;
		END IF;
		
		IF extract(year from p_in_dropdate) = 1 THEN
			SET p_in_dropdate = NULL;
		END IF;

		INSERT INTO `patient`
		(
		`PNo`,
		`Name`,
		`Age`,
		`Address`,
		`Grade`,
		`Gender`,
		`Panjayath`,
		`WardNo`,
		`Phone1`,
		`Phone2`,
		`RegDate`,
		`ExpDate`,
		`DropDate`,
		`Volunteer`,
		`Diagnosis`,
		`Temp`,
		`Route`,
		`HomeCarePlan`)
		VALUES
		(
		p_in_pno,
		p_in_name,
		p_in_age,
		p_in_address,
		p_in_grade,
		p_in_gender,
		p_in_panjayath,
		p_in_wardno,
		p_in_phone1,
		p_in_phone2,
		p_in_regdate,
		p_in_expdate,
		p_in_dropdate,
		p_in_volunteer,
		p_in_diagnosis,
		p_in_temp,
		p_in_route,
		p_in_homecareplan
		);
        
        SET p_out = "0";
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddRehabilitation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddRehabilitation`(
IN p_in_pno varchar(45),
IN p_in_desc varchar(200),
IN p_in_qty int,
IN p_in_date datetime
)
BEGIN

	IF extract(year from p_in_date) = 1 THEN
		SET p_in_date = NULL;
	END IF;

	INSERT INTO `rehabilitation`
	(`Pno`,
	`Date`,
	`Description`,
    `Quantity`)
	VALUES
	(p_in_pno,
    p_in_date,
    p_in_desc,
    p_in_qty
    );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddRoute` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddRoute`(
IN p_in_name varchar(100)
)
BEGIN
	INSERT INTO `route`
	(`Name`)
	VALUES
	(p_in_name );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_AddVolunteer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_AddVolunteer`(
IN p_in_name varchar(100),
IN p_in_location varchar(100),
IN p_in_phone varchar(45),
IN p_in_type int
)
BEGIN
	INSERT INTO `volunteer`
	(`Name`,
	`Location`,
	`Phone`,
    VolunteerTypeId)
	VALUES
	(p_in_name,
    p_in_location,
    p_in_phone,
    p_in_type
    );

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_DeleteFamiliy` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_DeleteFamiliy`(
IN p_in_id int
)
BEGIN

	Delete from `patientfamily`	WHERE `Id` = p_in_id;
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_DisposeEquipment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_DisposeEquipment`(
IN p_in_txndate datetime,
IN p_in_id int,
IN p_in_desc varchar(200),
IN p_in_eno varchar(45),
IN p_in_qty int,
IN p_in_name varchar(200),
OUT p_out int
)
BEGIN
	
    Declare p_receiptNo int;
    
	IF extract(year from p_in_txndate) = 1 THEN
		SET p_in_txndate = NULL;
	END IF;
	
	IF EXISTS (SELECT 1 FROM `equipment` where Id = p_in_id) THEN
      	INSERT INTO `equipmentdispose`
			(
			`EquipmentId`,
			`Eno`,
			`Name`,
			`Desc`,
			`Qty`,
			`TxnDate`)
			VALUES
			(
			p_in_id,
			p_in_eno,
			p_in_name,
			p_in_desc,
			p_in_qty,
			p_in_txndate);
         
        set p_out =  LAST_INSERT_ID();
        
		UPDATE `equipment`
		SET
		damage = (damage - p_in_qty)
		WHERE Id = p_in_id;
	END IF;
       
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetAccountLedger` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetAccountLedger`(
IN p_in_fromdate datetime,
IN p_in_todate datetime
)
BEGIN

SELECT 
	`account`.`Id`,
    `account`.`txndate`,
    `account`.`desc`,
    `account`.`type`,
    `account`.`amount`,
    `account`.`txntype`,
    `account`.`name`,
    `account`.`receiptNo`,
    `account`.`isReceipt`,
    `account`.`paymentMode`,
    `account`.`bankMode`,
    `account`.`bankName`,
    `account`.`txnNo`,
    `account`.`chNo`,
    `account`.`chdate`,
    `account`.`chBank`,
    `account`.`chAmount`
FROM `account`
WHERE 
	(`account`.`txntype` = 'Income' OR `account`.`txntype` = 'Expense') AND
    `account`.`amount` != 0 AND
    `account`.`txndate` >= p_in_fromdate AND
    `account`.`txndate` <= p_in_todate
;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetAccountReceipt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetAccountReceipt`(
IN p_in_id varchar(2000)
)
BEGIN

SELECT 
	`account`.`Id`,
    `account`.`txndate`,
    `account`.`desc`,
    `account`.`type`,
    `account`.`amount`,
    `account`.`txntype`,
    `account`.`name`,
    `account`.`receiptNo`,
    `account`.`isReceipt`,
    `account`.`paymentMode`,
    `account`.`bankMode`,
    `account`.`bankName`,
    `account`.`txnNo`,
    `account`.`chNo`,
    `account`.`chdate`,
    `account`.`chBank`,
    `account`.`chAmount`
FROM `account`
WHERE FIND_IN_SET(Id, p_in_id)
	and isReceipt = 1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetBankList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetBankList`()
BEGIN
	select Id, Name,IsCash from bank order by Name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetCenterDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetCenterDetails`()
BEGIN
SELECT `center`.`Id` AS _id,
    `center`.`Name`,
    `center`.`Address`,
    `center`.`Desc`,
    `center`.`Location`,
    `center`.`Phone`,
    `center`.`RegNo`,
    `center`.`AddressMal`,
     `center`.`DescMal`,
    `center`.`LocationMal`,
    `center`.`NameMal`,
    `center`.`ReceiptNo`,
    `center`.`MedExpiryDays`,
    `center`.`MedThresholdCount`,
    `center`.`ValidTill`,
    `center`.`TodayAPI`
FROM `center`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetChequeReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetChequeReport`(
IN p_in_status varchar(20)
)
BEGIN

	IF p_in_status = 'All' THEN
		SELECT 
			Id,txndate,`desc`,`type`,amount,txntype,`name`,receiptNo,isReceipt,paymentMode,bankMode,
			bankName,txnNo,chNo,chdate,chBank,chAmount
		FROM `account`
		WHERE 
			bankMode = "Cheque";
    ELSEIF p_in_status = 'Pending' THEN
		SELECT 
			Id,txndate,`desc`,`type`,amount,txntype,`name`,receiptNo,isReceipt,paymentMode,bankMode,
			bankName,txnNo,chNo,chdate,chBank,chAmount
		FROM `account`
		WHERE 
			bankMode = "Cheque" AND
            amount = 0;
    ELSEIF p_in_status = 'Cleared' THEN
		SELECT 
			Id,txndate,`desc`,`type`,amount,txntype,`name`,receiptNo,isReceipt,paymentMode,bankMode,
			bankName,txnNo,chNo,chdate,chBank,chAmount
		FROM `account`
		WHERE 
			bankMode = "Cheque" AND
            amount != 0;
    END IF;

	

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetCheques` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetCheques`()
BEGIN
SELECT 
	`account`.`Id`,
    `account`.`txndate`,
    `account`.`desc`,
    `account`.`type`,
    `account`.`amount`,
    `account`.`txntype`,
    `account`.`name`,
    `account`.`receiptNo`,
    `account`.`isReceipt`,
    `account`.`paymentMode`,
    `account`.`bankMode`,
    `account`.`bankName`,
    `account`.`txnNo`,
    `account`.`chNo`,
    `account`.`chdate`,
    `account`.`chBank`,
    `account`.`chAmount`
FROM `account`
WHERE 
    `account`.`amount` = 0 AND
    `account`.`bankMode` = 'Cheque'
;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetDashboard` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetDashboard`()
BEGIN

	select sum(Main) Main, Sum(Sub) Sub, Sum(A_kit) A_Kit, Sum(B_kit) B_Kit
	from medicinestock;
    
    select Grade, Count(Id) total from patient group by Grade;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetDiagnosisList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetDiagnosisList`()
BEGIN
	select Id, Name from diagnosis order by Name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetDisposeReceipt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetDisposeReceipt`(
IN p_in_id varchar(2000)
)
BEGIN

	SELECT
		`equipmentdispose`.`EquipmentId`,
		`equipmentdispose`.`Eno`,
		`equipmentdispose`.`Name`,
		`equipmentdispose`.`Desc`,
		`equipmentdispose`.`Qty`,
		`equipmentdispose`.`TxnDate`
	FROM `equipmentdispose`
    WHERE FIND_IN_SET(Id, p_in_id);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetDoctorList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetDoctorList`()
BEGIN
 	select 
 		d.Id, 
         d.Name,
         IFNULL(t.ConsultantType, '')  ConsultantType,
 		IFNULL(t.id, 0) typeId
 	from Doctor d
     left outer join consultanttype t on d.ConsultantTypeId = t.Id
     order by d.Name;
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetEquipmentDisposeReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetEquipmentDisposeReport`(
IN p_in_fromDate datetime,
IN p_in_toDate datetime
)
BEGIN

	SELECT 
		`equipmentdispose`.`Id`,
		`equipmentdispose`.`EquipmentId`,
		`equipmentdispose`.`Eno`,
		`equipmentdispose`.`Name`,
		`equipmentdispose`.`Desc`,
		`equipmentdispose`.`Qty`,
		`equipmentdispose`.`TxnDate`
	FROM `equipmentdispose`
    WHERE
		TxnDate >= p_in_fromDate AND
        TxnDate <= p_in_toDate;		   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetEquipmentReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetEquipmentReport`(
IN p_in_eno varchar(45)
)
BEGIN

	IF p_in_eno = '' THEN
		select
			t.Id,
			t.patientname,
			t.qty,
			t.outdate,
			t.indate,
            t.pno,
			e.name
		from 
		equipmenttracker t
		inner join equipment e on t.equipmentid = e.id
        order by e.name;
		
    ELSE
		select
			t.Id,
			t.patientname,
			t.qty,
			t.outdate,
			t.indate,
            t.pno,
			e.name
		from 
		equipmenttracker t
		inner join equipment e on t.equipmentid = e.id
		where e.eno = p_in_eno
		order by e.name;
         
    END IF;
		   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetEquipments` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetEquipments`()
BEGIN
	
   SELECT `equipment`.`Id`,
		`equipment`.`eno`,
		`equipment`.`name`,
		`equipment`.`name_lower`,
		`equipment`.`stock`,
		`equipment`.`damage`,
		`equipment`.`inuse`
	FROM `equipment`
    ORDER BY `equipment`.`name`;    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetEquipmentTracker` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetEquipmentTracker`(
IN p_in_eno varchar(45)
)
BEGIN

	select
		t.Id,
		t.patientname,
        t.qty,
        t.outdate,
        t.indate
    from 
	equipmenttracker t
	inner join equipment e on t.equipmentid = e.id
	where e.eno = p_in_eno
    order by t.outdate;
		   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetExpenseTypeList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetExpenseTypeList`()
BEGIN
	select Id, ExpenseType from expensetype order by ExpenseType;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetFamily` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetFamily`(
IN p_in_pno varchar(45)
)
BEGIN

	Declare p_pid int;
	select Id into p_pid from patient where Pno = p_in_pno;
	
    SELECT `patientfamily`.`Id`,
		`patientfamily`.`Name`,
		`patientfamily`.`Relation`,
		`patientfamily`.`Age`,
		`patientfamily`.`Education`,
		`patientfamily`.`MaritalStatus`,
		`patientfamily`.`Occupation`,
		`patientfamily`.`Income`
	FROM `patientfamily`
	where PatientId = p_pid;
		   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetHomeCarePlan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetHomeCarePlan`(
IN p_in_fromdate datetime,
IN p_in_todate datetime
)
BEGIN

	SELECT `homecareplan`.`Id`,
		`homecareplan`.`Pno`,
		`homecareplan`.`Date`,
		`homecareplan`.`Type`,
		`homecareplan`.`PatientName`
	FROM `homecareplan`
    where `homecareplan`.`Date` >= p_in_fromdate and
		`homecareplan`.`Date` <= p_in_todate
	order by `homecareplan`.`Date`
    ;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetHomeCarePlanList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetHomeCarePlanList`(
IN p_in_pno varchar(45)
)
BEGIN
	SELECT 
    `Id`,
    `Date`,
    `Type`,
    `PatientName`
FROM `homecareplan`
where Pno = p_in_pno
order by `Date`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetHomeScreening` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetHomeScreening`(
IN p_in_pno varchar(45)
)
BEGIN

	Declare p_pid int;
	select Id into p_pid from patient where Pno = p_in_pno;
	
	select ScreeningDate, ScreeningReason, 
    ifnull(ScreeningStatus,'') ScreeningStatus, ScreeningRemarks
    from patient where PNo = p_in_pno;
    
    select VolunteerId 
    from patientvolunteer where PatientId = p_pid;
		   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetHomeVisit` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetHomeVisit`(
 IN p_in_pno varchar(45)
 )
BEGIN
 
 	Declare p_pid int;
 	select Id into p_pid from patient where Pno = p_in_pno;
 	
     SELECT `Id`,
 		`PatientId`,
 		`Date`,
 		`Remarks`
 	FROM homevisit
 	where PatientId = p_pid
     order by `Date` desc;
     
 	select HomeVisitId, VolunteerId 
     from homevisitvolunteer where HomeVisitId in
     ( SELECT Id FROM homevisit where PatientId = p_pid);
 		   
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetHomeVisitDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetHomeVisitDetails`(
 IN p_in_id int
 )
BEGIN
 
     SELECT `Id`,
 		`PatientId`,
 		`Date`,
 		`Remarks`
 	FROM homevisit
 	where Id = p_in_id;
     
 	select HomeVisitId, VolunteerId 
     from homevisitvolunteer 
     where HomeVisitId = p_in_id;
 		   
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetIncomeTypeList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetIncomeTypeList`()
BEGIN
	select Id, IncomeType from incometype order by IncomeType;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetLoginDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetLoginDetails`(
IN p_in_UserName varchar(45)
)
BEGIN
 select password from login where username = p_in_UserName;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetMedicineHistory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetMedicineHistory`(
IN p_in_mno varchar(50),
IN p_in_fromDate datetime,
IN p_in_toDate datetime
)
BEGIN

	SELECT 
		`medicinehistory`.`Id`,
		`medicinehistory`.`MedicineId`,
		`medicinehistory`.`txnDate`,
		`medicinehistory`.`mno`,
		`medicinehistory`.`medName`,
		`medicinehistory`.`txnType`,
		`medicinehistory`.`desc`,
		`medicinehistory`.`openingMain`,
		`medicinehistory`.`openingSub`,
		`medicinehistory`.`openingAKit`,
		`medicinehistory`.`openingBKit`,
		`medicinehistory`.`qty`,
		`medicinehistory`.`closingMain`,
		`medicinehistory`.`closingSub`,
		`medicinehistory`.`closingAKit`,
		`medicinehistory`.`closingBKit`,
		`medicinehistory`.`pno`,
		`medicinehistory`.`patientName`
	FROM `medicinehistory`
    WHERE
		mno = p_in_mno AND
        txnDate >= p_in_fromDate AND
        txnDate <= p_in_toDate;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetMedicinePatientHistory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetMedicinePatientHistory`(
IN p_in_pno varchar(20)
)
BEGIN
	
    select 
		txnDate,
        medName,
        qty
	from medicinehistory
	WHERE pno = p_in_pno
    order by txnDate;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetMedicinePurchaseDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetMedicinePurchaseDetails`(
IN p_in_mno varchar(20)
)
BEGIN

	select p.`Id`,
		p.`MedicineId`,
		p.`invdate`,
		p.`invno`,
		p.`batchno`,
		p.`expdate`,
		p.`mfgdate`,
		p.`rate`,
		p.`dealer`,
		p.`mainStock`,
		p.`subStock`,
		p.`return`
	from medicinepurchase p
	inner join medicine m on p.MedicineId = m.Id
	where m.Mno = p_in_mno;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetMedicines` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetMedicines`()
BEGIN
	
    select 
		m.id,
		m.mno,
		m.name,
		st.main,
		st.sub,
		st.A_kit,
		st.B_kit 
	from medicine m
	inner join medicinestock st on m.id = st.MedicineId
    order by m.name;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetMedicineStock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetMedicineStock`(
IN p_in_mno varchar(20)
)
BEGIN
	
    select 
		st.main,
		st.sub,
		st.A_kit,
		st.B_kit 
	from medicine m
	inner join medicinestock st on m.id = st.MedicineId
   WHERE m.Mno = p_in_mno;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetMeeting` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetMeeting`(
IN p_in_pno varchar(45)
)
BEGIN

	Declare p_pid int;
	select Id into p_pid from patient where Pno = p_in_pno;
	
    SELECT `Id`,
		`PatientId`,
		`Date`,
		`Remarks`
	FROM meeting
	where PatientId = p_pid
    order by `Date` desc;
		   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetNextOPReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetNextOPReport`(
IN p_in_date datetime
)
BEGIN

    SELECT `op`.`Id`,
		`op`.`PatientId`,
		`op`.`Date`,
		`op`.`DoctorId`,
		`op`.`Remarks`,
		`op`.`FollowUp`,
		`op`.`NextOPDate`,
        d.Name as Doctor,
        p.PNo,
        p.Name
	FROM `op` op
    inner join doctor d on op.DoctorId = d.Id
    inner join patient p on op.PatientId = p.id
	where op.NextOPDate = p_in_date 
    order by p.Name;
		   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetOP` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetOP`(
IN p_in_pno varchar(45)
)
BEGIN

	Declare p_pid int;
	select Id into p_pid from patient where Pno = p_in_pno;
	
    SELECT `op`.`Id`,
		`op`.`PatientId`,
		`op`.`Date`,
		`op`.`DoctorId`,
		`op`.`Remarks`,
		`op`.`FollowUp`,
		`op`.`NextOPDate`,
        `op`.`PsychiatristId`,
        `op`.`PsychologistId`,
        `op`.`ClinicianId`
	FROM `op` op
    where PatientId = p_pid
    order by `op`.`Date` desc;
    
    select 
		om.OpId,
		m.Mno,
		m.Name,
		om.Quantity
	from opmedicine om
	inner join medicine m on om.MedicineId = m.Id
	where om.OpId IN ( SELECT `op`.`Id` from `op` WHERE PatientId = p_pid);
		   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetOPReport` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetOPReport`(
IN p_in_pno varchar(45),
IN p_in_fromDate datetime,
IN p_in_toDate datetime
)
BEGIN

	Declare p_pid int;
	select Id into p_pid from patient where Pno = p_in_pno;
	
    SELECT `op`.`Id`,
		`op`.`PatientId`,
		`op`.`Date`,
		`op`.`DoctorId`,
		`op`.`Remarks`,
		`op`.`FollowUp`,
		`op`.`NextOPDate`,
        d.Name as Doctor,
        p.PNo,
        p.Name
	FROM `op` op
    inner join doctor d on op.DoctorId = d.Id
    inner join patient p on op.PatientId = p.id
	where 
		op.Date >= p_in_fromDate AND
        op.Date <= p_in_toDate AND
        (p_in_pno = '' OR p.Pno = p_in_pno)
    order by `op`.`Date` ;
		   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetPanjayathList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetPanjayathList`()
BEGIN
	select Id, Name from panjayath order by Name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetPatientDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetPatientDetails`(
IN p_in_pno varchar(20)
)
BEGIN

	select 
	`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
	`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
	from patient
	where Pno = p_in_pno;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetPatientList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetPatientList`(
IN p_in_status varchar(20)
)
BEGIN

	IF p_in_status = 'Active' THEN
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
        where ExpDate is null and DropDate is null and Temp = 0
        Order by `Name`;
	ELSEIF p_in_status = 'Expired' THEN
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
        where ExpDate is not null
        Order by `Name`;
    ELSEIF p_in_status = 'Temp' THEN
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
         where Temp = 1
         Order by `Name`;
    ELSEIF p_in_status = 'Dropout' THEN 
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
        where DropDate is not null
        Order by `Name`;
    ELSEIF p_in_status = 'ActiveWithTemp' THEN 
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
        where ExpDate is null and DropDate is null
        Order by `Name`;
	ELSEIF p_in_status = 'All' THEN 
		select 
		`Id`,`PNo`,`Name`,`Age`,`Address`,`Grade`,`Gender`,`Panjayath`,`WardNo`,`Phone1`,`Phone2`,
		`RegDate`,`ExpDate`,`DropDate`,`Volunteer`,`Diagnosis`,`Temp`,`Route`,`HomeCarePlan`
		from patient
        Order by `Name`;
    END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetRehabilitation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetRehabilitation`(
IN p_in_pno varchar(45)
)
BEGIN
	SELECT 
    `Id`,
    `Date`,
    `Description`,
    `Quantity`
FROM `rehabilitation`
where Pno = p_in_pno
order by `Date`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetReportExpiry` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetReportExpiry`(
IN p_in_fromDate datetime,
IN p_in_toDate datetime
)
BEGIN

	SELECT 
		m.Id, m.Name, m.Mno, p.expdate, p.mainStock, p. subStock  
	from medicinepurchase p
	inner join medicine m on p.MedicineId = m.id
    WHERE
		p.expdate >= p_in_fromDate AND
        p.expdate <= p_in_toDate AND
        (p.mainStock > 0 OR p.subStock > 0) AND
        p.`return` = 0
    ORDER BY p.expdate;    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetReportExpiryCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetReportExpiryCount`(
IN p_in_fromDate datetime,
IN p_in_toDate datetime
)
BEGIN

	SELECT 
		Count(Id) as medCount
	FROM medicinepurchase
    WHERE
		expdate >= p_in_fromDate AND
        expdate <= p_in_toDate AND
        (mainStock > 0 OR subStock > 0) AND
        `return` = 0;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetReportMedicineSale` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetReportMedicineSale`(
 IN p_in_fromdate datetime,
 IN p_in_todate datetime
 )
BEGIN
 
 	select 
 		s.Date, 
 		m.Name Medicine,
 		s.Rate,
 		Sum(s.Qty) Quantity,
 		Sum(s.Qty) * s.Rate SubTotal
 	from medicinesale s
 	inner join medicine m on s.MedicineId = m.Id
     where
 		s.Date >= p_in_fromdate AND
 		s.Date <= p_in_todate
 	group by
 		Date, s.MedicineId, s.Rate
 	order by s.Date asc;
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetReportReceipts` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetReportReceipts`(
IN p_in_fromdate datetime,
IN p_in_todate datetime
)
BEGIN

SELECT 
	`account`.`Id`,
    `account`.`txndate`,
    `account`.`desc`,
    `account`.`type`,
    `account`.`amount`,
    `account`.`txntype`,
    `account`.`name`,
    `account`.`receiptNo`,
    `account`.`isReceipt`,
    `account`.`paymentMode`,
    `account`.`bankMode`,
    `account`.`bankName`,
    `account`.`txnNo`,
    `account`.`chNo`,
    `account`.`chdate`,
    `account`.`chBank`,
    `account`.`chAmount`
FROM `account`
WHERE 
	(`account`.`txntype` = 'Income' OR `account`.`txntype` = 'Expense') AND
    `account`.`isReceipt` = 1 AND
    `account`.`txndate` >= p_in_fromdate AND
    `account`.`txndate` <= p_in_todate
;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetReportThreshold` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetReportThreshold`(
IN p_in_thresholdCount int
)
BEGIN

	select m.Name, m.Mno, s.Main
	from medicinestock s
	inner join medicine m on s.MedicineId = m.id
    where s.Main > 0 AND s.Main <= p_in_thresholdCount
    order by m.Name;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetReportThresholdCount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetReportThresholdCount`(
IN p_in_thresholdCount int
)
BEGIN

	SELECT 
		Count(Id) as medCount
	FROM medicinepurchase
    WHERE
		mainStock > 0 AND 
        mainStock <= p_in_thresholdCount AND
        `return` = 0;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetRouteList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetRouteList`()
BEGIN
	select Id, Name from route order by Name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_GetVolunteerList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_GetVolunteerList`()
BEGIN
	select 
    v.Id, v.Name, v.Location, v.Phone, 
    IFNULL(t.VolunteerType, '')  VolunteerType,
    IFNULL(t.id, 0) typeId
    from 
    volunteer v
    left outer join volunteertype t on v.VolunteerTypeId = t.Id
    order by Name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_MedicineInbound` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_MedicineInbound`(
IN p_in_txndate datetime,
IN p_in_mno varchar(45),
IN p_in_purchase_invdate datetime,
IN p_in_purchase_invno varchar(45),
IN p_in_purchase_batchno varchar(45),
IN p_in_purchase_expdate datetime,
IN p_in_purchase_mfgdate datetime,
IN p_in_purchase_rate decimal(10,2),
IN p_in_purchase_dealer varchar(200),
IN p_in_qty int
)
BEGIN

    Declare p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id INT;
    Declare p_med_name varchar(200);
    
    IF EXISTS (SELECT 1 FROM `medicine` where Mno = p_in_mno) THEN
    	
		select 
			s.Main, s.Sub, s.A_kit, s.B_kit, s.MedicineId, m.Name 
			into p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_med_name
		from medicinestock s
		inner join medicine m on s.MedicineId = m.Id
		where m.Mno = p_in_mno;
        
        IF extract(year from p_in_purchase_invdate) = 1 THEN
			SET p_in_purchase_invdate = NULL;
		END IF;
		
		IF extract(year from p_in_purchase_expdate) = 1 THEN
			SET p_in_purchase_expdate = NULL;
		END IF;
		
		IF extract(year from p_in_purchase_mfgdate) = 1 THEN
			SET p_in_purchase_mfgdate = NULL;
		END IF;

        update medicinestock 
		set Main = (Main + p_in_qty)
		where MedicineId = p_m_id;
         
        INSERT INTO `medicinepurchase`
		(
		`MedicineId`,
		`invdate`,
		`invno`,
		`batchno`,
		`expdate`,
		`mfgdate`,
		`rate`,
		`dealer`,
		`mainStock`,
		`subStock`,
		`return`)
		VALUES
		(
		p_m_id,
		p_in_purchase_invdate,
		p_in_purchase_invno,
		p_in_purchase_batchno,
		p_in_purchase_expdate,
		p_in_purchase_mfgdate,
		p_in_purchase_rate,
		p_in_purchase_dealer,
		p_in_qty,
		0,
		0);
 		
        CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_in_mno, 
		p_med_name,
		'Inbound', -- txnType
		'To main stock', -- desc
		p_openMain, -- openingMain
        p_openSub, -- openingSub
        p_openAKit, -- openingAKit
        p_openBKit, -- openingBKit
		p_in_qty, -- qty
		(p_openMain + p_in_qty), -- closingMain
		p_openSub, -- closingSub
        p_openAKit, -- closingAKit
        p_openBKit, -- closingBKit
        '', -- pno
        '' -- patientName
        );
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_MedicineReturn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_MedicineReturn`(
IN p_in_txndate datetime,
IN p_in_mno varchar(45),
IN p_in_mainRet int,
IN p_in_mainStock int,
IN p_in_subRet int,
IN p_in_subStock int,
IN p_in_purId int
)
BEGIN

    Declare p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id INT;
    Declare p_med_name varchar(200);
    
    IF EXISTS (SELECT 1 FROM `medicine` where Mno = p_in_mno) THEN
    	
        select 
			s.Main, s.Sub, s.A_kit, s.B_kit, s.MedicineId, m.Name 
			into p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_med_name
		from medicinestock s
		inner join medicine m on s.MedicineId = m.Id
		where m.Mno = p_in_mno;
        
        update medicinestock 
			set Main = (Main - p_in_mainRet),
			Sub = (Sub - p_in_subRet)
		where MedicineId = p_m_id;
        
        update medicinepurchase
			set mainStock =  (mainStock - p_in_mainRet),
            subStock =  (subStock - p_in_subRet)
		where Id = p_in_purId;
        
        INSERT INTO `medicinepurchase`
		(
		`MedicineId`,
		`invdate`,
		`invno`,
		`batchno`,
		`expdate`,
		`mfgdate`,
		`rate`,
		`dealer`,
		`mainStock`,
		`subStock`,
		`return`)
		VALUES
		(
		p_m_id,
		p_in_txndate,
		'',
		'',
		p_in_txndate,
		null,
		0,
		'',
		(p_in_mainRet + p_in_subRet),
		0,
		1);
        
        CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_in_mno, 
		p_med_name,
		'Return', -- txnType
		'Return stock', -- desc
		p_openMain, -- openingMain
        p_openSub, -- openingSub
        p_openAKit, -- openingAKit
        p_openBKit, -- openingBKit
		(p_in_mainRet + p_in_subRet), -- qty
		(p_openMain - p_in_mainRet), -- closingMain
		(p_openSub - p_in_subRet), -- closingSub
        p_openAKit, -- closingAKit
        p_openBKit, -- closingBKit
        '', -- pno
        '' -- patientName
        );
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_MedicineTransfer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_MedicineTransfer`(
IN p_in_txndate datetime,
IN p_in_mno varchar(45),
IN p_in_qty int,
IN p_in_source varchar(50),
IN p_in_transferto varchar(50)
)
BEGIN

    Declare p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_purId, p_purMainStock, p_qty INT;
    Declare p_med_name varchar(200);
    DEClARE curPurch 
		CURSOR FOR 
			select 
			p.Id, p.mainStock 
		from 
			medicinepurchase p
			inner join medicine m on p.MedicineId = m.Id
		where 
			m.Mno = p_in_mno
			and p.mainStock > 0
			and p.expdate is not null
            and `return` = 0
		order by p.expdate;
    
    IF EXISTS (SELECT 1 FROM `medicine` where Mno = p_in_mno) THEN
    	
        SET p_qty = p_in_qty;
        
		select 
			s.Main, s.Sub, s.A_kit, s.B_kit, s.MedicineId, m.Name 
			into p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_med_name
		from medicinestock s
		inner join medicine m on s.MedicineId = m.Id
		where m.Mno = p_in_mno;
        
        update medicinestock 
		set Main = (Main - p_in_qty),
        Sub = (Sub + p_in_qty)
		where MedicineId = p_m_id;

        OPEN curPurch;
        
        transferLoop: LOOP
			FETCH curPurch INTO p_purId, p_purMainStock;
                        
            IF p_purMainStock <= p_qty THEN
				update medicinepurchase
				set 
					subStock = (subStock + mainStock),
					mainStock = 0
				where Id = p_purId;
                SET p_qty = p_qty - p_purMainStock;
            ELSE
				update medicinepurchase
				set 
					subStock = (subStock + p_qty),
					mainStock = (mainStock - p_qty)
				where Id = p_purId;
                SET p_qty = 0;
            END IF;

			IF p_qty = 0 THEN
				LEAVE transferLoop;
			END IF;
        END LOOP transferLoop;
        CLOSE curPurch;

        CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_in_mno, 
		p_med_name,
		'Transfer', -- txnType
		'Main to Sub', -- desc
		p_openMain, -- openingMain
        p_openSub, -- openingSub
        p_openAKit, -- openingAKit
        p_openBKit, -- openingBKit
		p_in_qty, -- qty
		(p_openMain - p_in_qty), -- closingMain
		(p_openSub + p_in_qty), -- closingSub
        p_openAKit, -- closingAKit
        p_openBKit, -- closingBKit
        '', -- pno
        '' -- patientName
        );
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_MedicineTransferKitStock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_MedicineTransferKitStock`(
IN p_in_txndate datetime,
IN p_in_mno varchar(45),
IN p_in_qty int,
IN p_in_stocktype varchar(50),
IN p_in_pno varchar(50),
IN p_in_patientname varchar(200)
)
BEGIN

    Declare p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, 
		p_purId, p_purSubStock, p_closeAKit, p_closeBKit INT;
    Declare p_med_name varchar(200);
        
    IF EXISTS (SELECT 1 FROM `medicine` where Mno = p_in_mno) THEN
        
		select 
			s.Main, s.Sub, s.A_kit, s.B_kit, s.MedicineId, m.Name 
			into p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_med_name
		from medicinestock s
		inner join medicine m on s.MedicineId = m.Id
		where m.Mno = p_in_mno;
        
        IF p_in_stocktype = "A Kit" THEN
			update medicinestock 
			set A_kit = (A_kit - p_in_qty)
			where MedicineId = p_m_id;
            
            SET p_closeAKit = p_openAKit - p_in_qty;
            SET p_closeBKit = p_openBKit;
            
        ELSE
			update medicinestock 
			set B_kit = (B_kit - p_in_qty)
			where MedicineId = p_m_id;
            
            SET p_closeAKit = p_openAKit;
            SET p_closeBKit = p_openBKit - p_in_qty;
            
        END IF;
        
        CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_in_mno, 
		p_med_name,
		'Transfer', -- txnType
		CONCAT(p_in_stocktype, ' to OP'), -- desc
		p_openMain, -- openingMain
        p_openSub, -- openingSub
        p_openAKit, -- openingAKit
        p_openBKit, -- openingBKit
		p_in_qty, -- qty
		p_openMain, -- closingMain
		p_openSub, -- closingSub
        p_closeAKit, -- closingAKit
        p_closeBKit, -- closingBKit
        p_in_pno, -- pno
        p_in_patientname -- patientName
        );
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_MedicineTransferSubStock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_MedicineTransferSubStock`(
IN p_in_txndate datetime,
IN p_in_mno varchar(45),
IN p_in_qty int,
IN p_in_source varchar(50),
IN p_in_transferto varchar(50),
IN p_in_pno varchar(50)
)
BEGIN

    Declare p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, 
		p_purId, p_purSubStock, p_qty ,p_closeAKit, p_closeBKit INT;
    Declare p_med_name, p_patient_name varchar(200);
    Declare p_purRate decimal(10,2);
    
    DEClARE curPurch 
		CURSOR FOR 
			select 
			p.Id, p.subStock, p.rate 
		from 
			medicinepurchase p
			inner join medicine m on p.MedicineId = m.Id
		where 
			m.Mno = p_in_mno
			and p.subStock > 0
			and p.expdate is not null
            and `return` = 0
		order by p.expdate;
    
    IF EXISTS (SELECT 1 FROM `medicine` where Mno = p_in_mno) THEN
    	
        SET p_qty = p_in_qty;
        
		select 
			s.Main, s.Sub, s.A_kit, s.B_kit, s.MedicineId, m.Name 
			into p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_med_name
		from medicinestock s
		inner join medicine m on s.MedicineId = m.Id
		where m.Mno = p_in_mno;
        
		IF p_in_transferto = "OP" THEN
			select name into p_patient_name from patient where Pno = p_in_pno;
		ELSE
			Set p_patient_name = "";
        END IF;
        
        update medicinestock 
		set Sub = (Sub - p_in_qty)
		where MedicineId = p_m_id;
        
        IF p_in_transferto = "A Kit" THEN
			update medicinestock 
			set A_kit = (A_kit + p_in_qty)
			where MedicineId = p_m_id;
            
            SET p_closeAKit = p_openAKit + p_in_qty;
            SET p_closeBKit = p_openBKit;
            
        ELSEIF p_in_transferto = "B Kit" THEN
			update medicinestock 
			set B_kit = (B_kit + p_in_qty)
			where MedicineId = p_m_id;
            
            SET p_closeAKit = p_openAKit;
            SET p_closeBKit = p_openBKit + p_in_qty;
            
        ELSE
			SET p_closeAKit = p_openAKit;
			SET p_closeBKit = p_openBKit;
        END IF;
        
        OPEN curPurch;
        
        transferLoop: LOOP
			FETCH curPurch INTO p_purId, p_purSubStock, p_purRate;
                       
            IF p_purSubStock <= p_qty THEN
				update medicinepurchase
				set 
					subStock = 0
				where Id = p_purId;
                
                INSERT INTO `medicinesale`
				(
					`MedicineId`,
                    `MedicinePurchaseId`,
					`Pno`,
					`Date`,
					`Rate`,
					`Qty`
				)
				VALUES
					(
                    p_m_id,
                    p_purId,
                    p_in_pno,
                    p_in_txndate,
                    p_purRate,
                    p_purSubStock
                    );
                
                SET p_qty = p_qty - p_purSubStock;
            ELSE
				update medicinepurchase
				set 
					subStock = (subStock - p_qty)
				where Id = p_purId;
                
                INSERT INTO `medicinesale`
				(
					`MedicineId`,
                    `MedicinePurchaseId`,
					`Pno`,
					`Date`,
					`Rate`,
					`Qty`
				)
				VALUES
					(
                    p_m_id,
                    p_purId,
                    p_in_pno,
                    p_in_txndate,
                    p_purRate,
                    p_qty
                    );
                
                SET p_qty = 0;
            END IF;
            
            IF p_qty = 0 THEN
				LEAVE transferLoop;
			END IF;
        
        END LOOP transferLoop;
        CLOSE curPurch;
        
        CALL `spr_AddMedicineHistory`
		(p_m_id, 
		p_in_txndate, 
		p_in_mno, 
		p_med_name,
		'Transfer', -- txnType
		CONCAT('Sub to ', p_in_transferto), -- desc
		p_openMain, -- openingMain
        p_openSub, -- openingSub
        p_openAKit, -- openingAKit
        p_openBKit, -- openingBKit
		p_in_qty, -- qty
		(p_openMain), -- closingMain
		(p_openSub - p_in_qty), -- closingSub
        p_closeAKit, -- closingAKit
        p_closeBKit, -- closingBKit
        p_in_pno, -- pno
        p_patient_name -- patientName
        );
   END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ProcessCheque` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_ProcessCheque`(
IN p_in_txndate datetime,
IN p_in_id int
)
BEGIN

	declare p_amount DECIMAL(10,2);
	select chAmount into p_amount from `account` where `Id` = p_in_id;

	UPDATE `account`
	SET
	`txndate` = p_in_txndate,
	`amount` = p_amount
	WHERE `Id` = p_in_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReportAccountDetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_ReportAccountDetails`(
IN p_in_fromdate datetime,
IN p_in_todate datetime,
IN p_in_txntype varchar(20)
)
BEGIN

SELECT 
    `account`.`type`,
    `account`.`txntype`,
    sum(`account`.`amount`) amt
FROM `account`
WHERE 
	`account`.`txndate` >= p_in_fromdate AND 
    `account`.`txndate` <= p_in_todate AND 
    `account`.`amount` != 0 AND
    `account`.`txntype` = p_in_txntype
GROUP BY
	 `account`.`type`, `account`.`txntype`
ORDER BY `account`.`type`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReportDaybookBalance` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_ReportDaybookBalance`(
IN p_in_fromdate datetime
)
BEGIN

select bankname, sum(amount) amt from account
where txndate < p_in_fromdate
group by bankname;

select bankname, sum(amount) amt from account
where txndate <= p_in_fromdate
group by bankname;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReportDaybookLedger` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_ReportDaybookLedger`(
IN p_in_fromdate datetime
)
BEGIN

SELECT `account`.`Id`,
    `account`.`type`,
    `account`.`amount`,
    `account`.`txntype`,
    `account`.`bankName`
FROM `account`
WHERE `account`.`txndate` = p_in_fromdate
	AND `account`.`amount` != 0
ORDER BY `account`.`type`;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReportMonthlyBalance` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_ReportMonthlyBalance`(
IN p_in_fromdate datetime,
IN p_in_todate datetime
)
BEGIN

select bankname, sum(amount) amt from account
where txndate < p_in_fromdate
group by bankname;

select bankname, sum(amount) amt from account
where txndate <= p_in_todate
group by bankname;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_ReturnEquipment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_ReturnEquipment`(
IN p_in_indate datetime,
IN p_in_eno varchar(45),
IN p_in_qty int,
IN p_in_id int
)
BEGIN
	
	IF EXISTS (SELECT 1 FROM `equipment` where eno = p_in_eno) THEN
   
		UPDATE `equipment`
		SET
		stock = (stock + p_in_qty),
		inuse = (inuse - p_in_qty)
		WHERE eno = p_in_eno;
    
		UPDATE `equipmenttracker`
        SET indate = p_in_indate
		WHERE Id = p_in_id;
        
	END IF;
       
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_SaveHomeScreening` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_SaveHomeScreening`(
IN p_in_pno varchar(45),
IN p_in_date datetime,
IN p_in_status varchar(10),
IN p_in_reason text,
IN p_in_remarks text,
IN p_in_volunteers varchar(100)
)
BEGIN

	declare p_status tinyint;
    declare p_pid, p_vid, finished int;
    
    DEClARE curVol CURSOR FOR select Id from volunteer where FIND_IN_SET(Id, p_in_volunteers);    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
	
    SET p_status = NULL, finished = 0;
    select Id into p_pid from patient where Pno = p_in_pno;
    
	IF extract(year from p_in_date) = 1 THEN
		SET p_in_date = NULL;
	END IF;
    
    IF p_in_status = "1" THEN
		SET p_status = 1;
	ELSEIF p_in_status = "0" THEN
		SET p_status = 0;
    END IF;

	Update patient
		set ScreeningDate = p_in_date,
        ScreeningReason = p_in_reason,
        ScreeningRemarks = p_in_remarks,
        ScreeningStatus = p_status
    where Id = p_pid;
    
    Delete from patientvolunteer where PatientId = p_pid;
    
    IF p_in_volunteers != '' THEN
		
        OPEN curVol;
        volLoop: LOOP
			FETCH curVol INTO p_vid;
             
			IF finished = 1 THEN 
				LEAVE volLoop;
			END IF;
			
            INSERT INTO `patientvolunteer`
				(`PatientId`,`VolunteerId`)
			VALUES
				(p_pid, p_vid);

        END LOOP volLoop;
        CLOSE curVol;
    END IF;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_TransferEquipment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_TransferEquipment`(
IN p_in_outdate datetime,
IN p_in_eno varchar(45),
IN p_in_qty int,
IN p_in_pno varchar(45),
IN p_in_patientname varchar(200)
)
BEGIN
	
    Declare p_e_id int;
	
	IF EXISTS (SELECT 1 FROM `equipment` where eno = p_in_eno) THEN
    
		select Id into p_e_id from equipment where eno = p_in_eno;
    
		UPDATE `equipment`
		SET
		stock = (stock - p_in_qty),
		inuse = (inuse + p_in_qty)
		WHERE Id = p_e_id;
    
		INSERT INTO `equipmenttracker`
		(
		`EquipmentId`,
		`patientname`,
		`pno`,
		`qty`,
		`outdate`,
		`indate`)
		VALUES
		(
		p_e_id,
		p_in_patientname,
		p_in_pno,
		p_in_qty,
		p_in_outdate,
		null);
        
	END IF;
       
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateAccountLedger` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateAccountLedger`(
IN p_in_id int,
IN p_in_desc varchar(200),
IN p_in_type varchar(45),
IN p_in_amount DECIMAL(10,2),
IN p_in_name varchar(200),
IN p_in_isReceipt tinyint,
IN p_in_paymentMode varchar(45),
IN p_in_bankMode varchar(45),
IN p_in_bankName varchar(200),
IN p_in_txnNo varchar(100),
IN p_in_chNo varchar(45),
IN p_in_chdate datetime,
IN p_in_chBank varchar(200)
)
BEGIN
	
    Declare p_receiptNo int;
    declare p_chAmount DECIMAL(10,2);

	IF extract(year from p_in_chdate) = 1 THEN
		SET p_in_chdate = NULL;
	END IF;
	
    IF p_in_bankMode = "Cheque" THEN
		SET p_chAmount = p_in_amount;
        SET p_in_amount = 0;
	ELSE
		SET p_chAmount = 0;
	END IF;
    
    IF p_in_isReceipt = 1 THEN
		update center set receiptno = receiptno + 1 where id = 1; 
		select receiptno into p_receiptNo from center  where id = 1; 
	ELSE
		SET p_receiptNo = NULL;
	END IF;
    
	UPDATE `account`
	SET
	`desc` = p_in_desc,
	`type` = p_in_type,
	`amount` = p_in_amount,
	`name` = p_in_name,
	`receiptNo` = p_receiptNo,
	`isReceipt` = p_in_isReceipt,
	`paymentMode` = p_in_paymentMode,
	`bankMode` = p_in_bankMode,
	`bankName` = p_in_bankName,
	`txnNo` = p_in_txnNo,
	`chNo` = p_in_chNo,
	`chdate` = p_in_chdate,
	`chBank` = p_in_chBank,
	`chAmount` = p_chAmount
	WHERE `Id` = p_in_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateBank` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateBank`(
IN p_in_id INT,
IN p_in_name varchar(200)
)
BEGIN
	UPDATE `bank`
	SET
	`Name` = p_in_name
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateCenter` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateCenter`(
IN p_in_name varchar(255),
IN p_in_address varchar(255),
IN p_in_desc varchar(255),
IN p_in_location varchar(255),
IN p_in_phone varchar(45),
IN p_in_regno varchar(45),
IN p_in_addressMal nvarchar(255),
IN p_in_locationMal nvarchar(255),
IN p_in_nameMal nvarchar(255),
IN p_in_medExpiryDays int,
IN p_in_medThresholdCount int,
IN p_in_descMal nvarchar(255)
)
BEGIN
	UPDATE center
	SET
	`Name` = p_in_name,
	`Address` = p_in_address,
	`Desc` = p_in_desc,
	`Location` = p_in_location,
	`Phone` = p_in_phone,
	`RegNo` = p_in_regno,
	`AddressMal` = p_in_addressMal,
	`LocationMal` =p_in_locationMal,
	`NameMal` =p_in_nameMal,
	`MedExpiryDays` = p_in_medExpiryDays,
	`MedThresholdCount` =p_in_medThresholdCount,
	`DescMal` = p_in_descMal;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateDiagnosis` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateDiagnosis`(
IN p_in_id INT,
IN p_in_name varchar(100)
)
BEGIN
	UPDATE `diagnosis`
	SET
	`Name` = p_in_name
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateDoctor` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateDoctor`(
 IN p_in_id INT,
 IN p_in_name varchar(100),
 IN p_in_type INT
 )
BEGIN
 	UPDATE `doctor`
 	SET
 	`Name` = p_in_name,
     ConsultantTypeId = p_in_type
 	WHERE `Id` =p_in_id;
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateEquipment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateEquipment`(
IN p_in_id int,
IN p_in_name varchar(200),
IN p_in_name_lower varchar(200),
IN p_in_stock int,
IN p_in_inuse int,
IN p_in_damage int
)
BEGIN

	UPDATE `equipment`
	SET
    `name` = p_in_name,
    `name_lower` = p_in_name_lower,
	`stock` = p_in_stock,
	`damage` = p_in_damage,
	`inuse` = p_in_inuse
	WHERE `Id` = p_in_id;
	
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateExpenseType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateExpenseType`(
IN p_in_id INT,
IN p_in_expensetype varchar(100)
)
BEGIN
	UPDATE `expensetype`
	SET
	`ExpenseType` = p_in_expensetype
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateFamiliy` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateFamiliy`(
IN p_in_id int,
IN p_in_name varchar(200),
IN p_in_relation varchar(45),
IN p_in_age int,
IN p_in_education varchar(200),
IN p_in_maritalStatus varchar(45),
IN p_in_occupation varchar(200),
IN p_in_income decimal(10,2)

)
BEGIN

	UPDATE `patientfamily`
	SET
	`Name` = p_in_name,
	`Relation` = p_in_relation,
	`Age` = p_in_age,
	`Education` = p_in_education,
	`MaritalStatus` = p_in_maritalStatus,
	`Occupation` = p_in_occupation,
	`Income` = p_in_income
	WHERE `Id` = p_in_id;
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateHomeCarePlan` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateHomeCarePlan`(
IN p_in_id int,
IN p_in_type varchar(45),
IN p_in_date datetime
)
BEGIN
	UPDATE `homecareplan`
	SET
	`Type` = p_in_type,
	`Date` = p_in_date
	WHERE `Id` = p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateIncomeType` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateIncomeType`(
IN p_in_id INT,
IN p_in_incometype varchar(100)
)
BEGIN
	UPDATE `incometype`
	SET
	`IncomeType` = p_in_incometype
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateMedicine` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateMedicine`(
IN p_in_id INT,
IN p_in_name varchar(200),
IN p_in_name_lower varchar(200)
)
BEGIN
	UPDATE `medicine`
	SET
	`Name` = p_in_name,
    `NameLower` = p_in_name_lower
	WHERE `Id` = p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateMedicineStock` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateMedicineStock`(
 IN p_in_purid INT,
 IN p_in_mno varchar(20),
 IN p_in_mainDiff int,
 IN p_in_mainNew int,
 IN p_in_subDiff int,
 IN p_in_subNew int,
 IN p_in_txndate datetime,
 IN p_in_rateNew decimal(10,2)
 )
BEGIN
 	
     Declare p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id INT;
     Declare p_med_name varchar(200);
     
     select 
 		s.Main, s.Sub, s.A_kit, s.B_kit, s.MedicineId, m.Name 
         into p_openMain, p_openSub, p_openAKit, p_openBKit, p_m_id, p_med_name
     from medicinestock s
     inner join medicine m on s.MedicineId = m.Id
     where m.Mno = p_in_mno;
     
     update medicinestock 
     set Main = (Main - p_in_mainDiff),
     Sub = (Sub - p_in_subDiff)
     where MedicineId = p_m_id;
     
     update medicinepurchase
     set mainStock = p_in_mainNew,
 		subStock = p_in_subNew,
         rate = p_in_rateNew
     where id = p_in_purid;
 
 	 CALL `spr_AddMedicineHistory`
 		(p_m_id, 
 		p_in_txndate, 
 		p_in_mno, 
 		p_med_name,
 		'Edit', -- txnType
 		'Edit stock', -- desc
 		p_openMain, -- openingMain
         p_openSub, -- openingSub
         p_openAKit, -- openingAKit
         p_openBKit, -- openingBKit
 		0, -- qty
 		(p_openMain - p_in_mainDiff), -- closingMain
 		(p_openSub - p_in_subDiff), -- closingSub
         p_openAKit, -- closingAKit
         p_openBKit, -- closingBKit
         '', -- pno
         '' -- patientName
         );
 
 END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateOP` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateOP`(
IN p_in_opid int,
IN p_in_doctorId int,
IN p_in_psychiatristId int,
IN p_in_psychologistId int,
IN p_in_clinicianId int,
IN p_in_remarks text,
IN p_in_followup text,
IN p_in_nextopdate datetime
)
BEGIN

	UPDATE `op`
	SET
		`DoctorId` = p_in_doctorId,
		`Remarks` = p_in_remarks,
		`FollowUp` = p_in_followup,
		`NextOPDate` = p_in_nextopdate,
		`PsychiatristId` = p_in_psychiatristId,
		`PsychologistId` = p_in_psychologistId,
		`ClinicianId` = p_in_clinicianId
	WHERE `Id` = p_in_opid;
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdatePanjayath` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdatePanjayath`(
IN p_in_id INT,
IN p_in_name varchar(100)
)
BEGIN
	UPDATE `panjayath`
	SET
	`Name` = p_in_name
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdatePatient` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdatePatient`(
IN p_in_id int,
IN p_in_name varchar(200),
IN p_in_age varchar(45),
IN p_in_address varchar(255),
IN p_in_grade varchar(45),
IN p_in_gender varchar(45),
IN p_in_panjayath varchar(100),
IN p_in_wardno varchar(45),
IN p_in_phone1 varchar(45),
IN p_in_phone2 varchar(45),
IN p_in_regdate datetime,
IN p_in_expdate datetime,
IN p_in_dropdate datetime,
IN p_in_volunteer varchar(100),
IN p_in_diagnosis varchar(100),
IN p_in_temp tinyint,
IN p_in_route varchar(100),
IN p_in_homecareplan varchar(45)

)
BEGIN
	UPDATE `patient`
	SET
	`Name` = p_in_name,
	`Age` = p_in_age,
	`Address` = p_in_address,
	`Grade` = p_in_grade,
	`Gender` = p_in_gender,
	`Panjayath` = p_in_panjayath,
	`WardNo` = p_in_wardno,
	`Phone1` = p_in_phone1,
	`Phone2` = p_in_phone2,
	`RegDate` = p_in_regdate,
	`ExpDate` = p_in_expdate,
	`DropDate` = p_in_dropdate,
	`Volunteer` = p_in_volunteer,
	`Diagnosis` = p_in_diagnosis,
	`Temp` = p_in_temp,
	`Route` = p_in_route,
	`HomeCarePlan` = p_in_homecareplan
	WHERE `Id` = p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateRehabilitation` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateRehabilitation`(
IN p_in_id int,
IN p_in_desc varchar(200),
IN p_in_qty int
)
BEGIN
	UPDATE `rehabilitation`
	SET
	`Description` = p_in_desc,
	`Quantity` = p_in_qty
	WHERE `Id` = p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateRoute` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateRoute`(
IN p_in_id INT,
IN p_in_name varchar(100)
)
BEGIN
	UPDATE `route`
	SET
	`Name` = p_in_name
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `spr_UpdateVolunteer` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spr_UpdateVolunteer`(
IN p_in_id INT,
IN p_in_name varchar(100),
IN p_in_location varchar(100),
IN p_in_phone varchar(45),
IN p_in_type int
)
BEGIN
	UPDATE `volunteer`
	SET
	`Name` = p_in_name,
	`Location` = p_in_location,
	`Phone` = p_in_phone,
    VolunteerTypeId = p_in_type
	WHERE `Id` =p_in_id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-11 11:05:36
