const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let stockEntry = new Schema({
  stock: {
    type: Number
  },
  damage: {
    type: Number
  },
  inuse: {
    type: Number
  }
});

let trackerEntry = new Schema({
  patientname: {
    type: String
  },
  qty: {
    type: Number
  },
  outdate: {
    type: Date
  },
  indate: {
    type: Date
  }
});

let Equipment = new Schema(
  {
    eno: {
      type: String
    },
    name: {
      type: String
    },
    name_lower: {
      type: String
    },
    stock: stockEntry,
    tracker: [trackerEntry]
  },
  {
    collection: "equipment"
  }
);

module.exports = mongoose.model("equipment", Equipment);
