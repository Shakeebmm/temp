const mongoose = require("mongoose");
const Schema = mongoose.Schema;

let IncomeType = new Schema(
  {
    incomeType: {
      type: String
    }
  },
  {
    collection: "incomeType"
  }
);

module.exports = mongoose.model("incomeType", IncomeType);
