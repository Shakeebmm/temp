const crypto = require("crypto");
const Cryptr = require("cryptr");

const cryptoHelper = (function() {
  const keyDB = "sLMP*nM2$0789";
  const cipherDB = crypto.createCipher("aes-256-cbc", keyDB);
  const decipherDB = crypto.createDecipher("aes-256-cbc", keyDB);
  const cryptr = new Cryptr("SJuPDE*dT12j$*n");

  let _instance = null;

  const _createCryptoHelperInstance = () => {
    return {
      encryptDB: password => {
        let encryptedPassword = cipherDB.update(password, "utf8", "base64");
        return (encryptedPassword =
          encryptedPassword + cipherDB.final("base64"));
      },
      decryptDB: password => {
        let decryptedPassword = decipherDB.update(password, "base64", "utf8");
        return (decryptedPassword =
          decryptedPassword + decipherDB.final("utf8"));
      },
      encryptField: inputField => {
        return cryptr.encrypt(inputField.toString());
      },
      decryptField: inputField => {
        return cryptr.decrypt(inputField);
      }
    };
  };
  return {
    getCrytoHelperInstance: () => {
      if (_instance == null) {
        _instance = _createCryptoHelperInstance();
      }
      return _instance;
    }
  };
})();

module.exports = cryptoHelper;
